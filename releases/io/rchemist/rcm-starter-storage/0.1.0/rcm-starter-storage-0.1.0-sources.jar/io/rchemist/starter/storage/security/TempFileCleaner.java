/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;
import org.springframework.beans.factory.DisposableBean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 임시파일 cleanup helper — Spring lifecycle ({@link DisposableBean}) 통합으로 application
 * shutdown 시 등록된 모든 임시 path 자동 삭제. {@link
 * io.rchemist.starter.storage.local.LocalFileSystemStorage} 의 in-flight tmp 파일 / 일회성
 * presigned URL 관련 캐시 등 추적 영역.
 *
 * <p>thread-safety: {@code register} / {@code unregister} / {@code cleanupNow} 모두
 * synchronized.
 **/
public class TempFileCleaner implements DisposableBean {

  private final Set<Path> tracked = new LinkedHashSet<>();

  /** 임시 path 등록 — application shutdown 시 자동 삭제 후보로 추적. */
  public synchronized void register(Path path) {
    if (path == null) {
      return;
    }
    tracked.add(path);
  }

  /** 등록 해제 — 명시적 삭제 후 호출. */
  public synchronized void unregister(Path path) {
    tracked.remove(path);
  }

  /** 등록된 path 수. */
  public synchronized int size() {
    return tracked.size();
  }

  /** 즉시 cleanup — 모든 추적 path 삭제 + 추적 해제. shutdown 외 영역에서도 호출 가능. */
  public synchronized int cleanupNow() {
    int deleted = 0;
    for (Path p : tracked) {
      try {
        if (Files.deleteIfExists(p)) {
          deleted++;
        }
      } catch (IOException ignored) {
        // best-effort cleanup
      }
    }
    tracked.clear();
    return deleted;
  }

  /** Spring lifecycle — context shutdown 시 자동 cleanup. */
  @Override
  public void destroy() {
    cleanupNow();
  }
}
