/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Tenant 별 사용량 snapshot (Records).
 *
 * @param tenantId tenant 식별자.
 * @param usedBytes 누적 byte 사용량.
 * @param objectCount 누적 object 수.
 * @param maxBytes 허용 byte cap. {@code -1} = unbounded.
 * @param maxObjects 허용 object cap. {@code -1} = unbounded.
 */
public record QuotaUsage(
    String tenantId, long usedBytes, long objectCount, long maxBytes, long maxObjects) {

  public QuotaUsage {
    if (tenantId == null || tenantId.isBlank()) {
      throw new IllegalArgumentException("tenantId must not be blank");
    }
  }

  /** byte 잔여량. unbounded 면 {@link Long#MAX_VALUE}. */
  public long remainingBytes() {
    return maxBytes < 0 ? Long.MAX_VALUE : Math.max(0, maxBytes - usedBytes);
  }

  /** object 잔여량. unbounded 면 {@link Long#MAX_VALUE}. */
  public long remainingObjects() {
    return maxObjects < 0 ? Long.MAX_VALUE : Math.max(0, maxObjects - objectCount);
  }
}
