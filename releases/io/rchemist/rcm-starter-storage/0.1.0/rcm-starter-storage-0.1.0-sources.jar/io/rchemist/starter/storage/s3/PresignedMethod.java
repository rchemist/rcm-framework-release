/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.s3;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Presigned URL HTTP method 종류. S3 / Azure SAS / GCS V4 signed URL 모두 GET (다운로드) /
 * PUT (직접 업로드) 두 영역만 보편. DELETE / HEAD 는 자주 사용 X — Consumer custom 영역.
 **/
public enum PresignedMethod {

  /** Read 한정 — 다운로드 시나리오. */
  GET,

  /** Direct upload — Consumer 가 backend 우회 직접 PUT. */
  PUT
}
