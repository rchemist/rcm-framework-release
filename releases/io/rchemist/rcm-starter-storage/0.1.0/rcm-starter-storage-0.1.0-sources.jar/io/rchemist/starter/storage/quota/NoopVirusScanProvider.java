/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

import java.io.InputStream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default {@link VirusScanProvider} — fail-open clean. virus scan 미적용 명시 baseline. 운영
 * 환경에서는 ClamAV 등 실제 scanner 어댑터를 Consumer 가 wire 권장 ({@code @Component} 등록 시
 * 자동 양보).
 **/
public class NoopVirusScanProvider implements VirusScanProvider {

  private static final String NAME = "noop";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public ScanResult scan(InputStream content) {
    return ScanResult.clean();
  }
}
