/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.core;

import java.io.InputStream;
import java.util.stream.Stream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Storage SPI baseline — 로컬 / S3 / Azure Blob / GCS / NFS 백엔드 공통 인터페이스. Phase 6.8
 * task #3 의 {@code LocalFileSystemStorage} default impl + task #6 의 S3 SPI 슬롯이 각각
 * implement.
 *
 * <p>method:
 * <ul>
 *   <li>{@link #put(String, InputStream, String, ObjectMetadata)} — 저장 (atomic write 권장).</li>
 *   <li>{@link #open(String)} — 다운로드용 InputStream. 미존재 = {@code ObjectNotFoundException}.</li>
 *   <li>{@link #head(String)} — metadata 만 (content 다운로드 X).</li>
 *   <li>{@link #delete(String)} — 삭제. 미존재 = {@code false}.</li>
 *   <li>{@link #exists(String)} — 존재 여부.</li>
 *   <li>{@link #listKeys(String)} — prefix 매칭 key Stream.</li>
 * </ul>
 *
 * <p>Consumer 가 백엔드 어댑터를 {@code @Component} 로 wire 하면 자동 양보 (
 * {@link org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean}).
 **/
public interface Storage {

  /** Storage backend 식별 이름 (e.g. {@code local} / {@code s3} / {@code gcs}). */
  String name();

  /**
   * 저장 (atomic write 권장 — 동시 read / 부분 write 차단). content stream 은 backend 가 close.
   *
   * @param key backend unique path
   * @param content 입력 stream — backend 가 size + checksum 계산하며 read.
   * @param contentType MIME (null 가능 — backend 가 detect 시도)
   * @param metadata 사용자 정의 attribute (null 안전 → empty)
   * @return 저장된 object 의 identity + metadata
   */
  StorageObject put(String key, InputStream content, String contentType, ObjectMetadata metadata);

  /** 다운로드용 InputStream. caller 가 close 책임. */
  InputStream open(String key);

  /** metadata 만 조회. content download 영역 아님. */
  StorageObject head(String key);

  /** 삭제. 존재했으면 {@code true}, 미존재면 {@code false}. */
  boolean delete(String key);

  /** 존재 여부. */
  boolean exists(String key);

  /** prefix 매칭 key Stream. caller 가 close 책임. */
  Stream<String> listKeys(String prefix);
}
