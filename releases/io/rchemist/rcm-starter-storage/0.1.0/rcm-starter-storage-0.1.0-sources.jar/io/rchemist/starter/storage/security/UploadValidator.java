/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import java.util.Optional;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Upload 안전 검증 — max size + 허용 MIME 화이트리스트 + magic byte 시그니처 매칭. {@link
 * io.rchemist.starter.storage.core.Storage#put} 호출 직전 controller / service 영역에서 호출
 * 권장.
 *
 * <p>검증 단계:
 * <ol>
 *   <li>size 가 {@code maxSizeBytes} 이하인지.</li>
 *   <li>declared {@code contentType} 이 {@code allowedMimeTypes} 안에 있는지 (whitelist 빈
 *       set 이면 모든 MIME 허용).</li>
 *   <li>{@code requireMagicByteMatch=true} 면 header 의 시그니처가 등록되어 있고 declared
 *       MIME 과 호환되는지 (ZIP 컨테이너 family 는 application/zip + Office Open XML 모두
 *       호환).</li>
 * </ol>
 *
 * <p>실패 = {@link UploadValidationException} fail-loud. caller 는 별도 보안 에러 핸들링.
 **/
public final class UploadValidator {

  private final long maxSizeBytes;
  private final Set<String> allowedMimeTypes;
  private final MagicByteRegistry registry;
  private final boolean requireMagicByteMatch;

  public UploadValidator(
      long maxSizeBytes,
      Set<String> allowedMimeTypes,
      MagicByteRegistry registry,
      boolean requireMagicByteMatch) {
    if (maxSizeBytes <= 0) {
      throw new IllegalArgumentException("maxSizeBytes must be positive: " + maxSizeBytes);
    }
    if (registry == null) {
      throw new IllegalArgumentException("registry must not be null");
    }
    this.maxSizeBytes = maxSizeBytes;
    this.allowedMimeTypes = allowedMimeTypes != null ? Set.copyOf(allowedMimeTypes) : Set.of();
    this.registry = registry;
    this.requireMagicByteMatch = requireMagicByteMatch;
  }

  public long maxSizeBytes() {
    return maxSizeBytes;
  }

  public Set<String> allowedMimeTypes() {
    return allowedMimeTypes;
  }

  public boolean requireMagicByteMatch() {
    return requireMagicByteMatch;
  }

  /** 단일 upload 검증. 실패 시 {@link UploadValidationException}. */
  public void validate(String filename, String contentType, long size, byte[] header) {
    if (size > maxSizeBytes) {
      throw new UploadValidationException(
          "upload size %d exceeds max %d (filename=%s)".formatted(size, maxSizeBytes, filename));
    }
    if (!allowedMimeTypes.isEmpty()
        && (contentType == null || !allowedMimeTypes.contains(contentType))) {
      throw new UploadValidationException(
          "MIME %s not in whitelist (filename=%s)".formatted(contentType, filename));
    }
    if (requireMagicByteMatch) {
      Optional<MagicByteSignature> detected = registry.detect(header);
      if (detected.isEmpty()) {
        throw new UploadValidationException(
            "no magic byte signature matched (filename=%s, declared=%s)"
                .formatted(filename, contentType));
      }
      if (!isCompatible(detected.get().mimeType(), contentType)) {
        throw new UploadValidationException(
            "magic byte %s incompatible with declared %s (filename=%s)"
                .formatted(detected.get().mimeType(), contentType, filename));
      }
    }
  }

  /**
   * 시그니처에서 detect 된 MIME 과 declared MIME 호환성 검사. 정확 일치 OR ZIP 컨테이너 family
   * (DOCX/XLSX/PPTX/JAR/일반 ZIP) 처리. declared null 은 호환 처리 (whitelist 단계가 이미 차단).
   */
  private static boolean isCompatible(String detected, String declared) {
    if (declared == null) {
      return true;
    }
    if (detected.equalsIgnoreCase(declared)) {
      return true;
    }
    if (isZipFamily(detected) && isZipFamily(declared)) {
      return true;
    }
    return false;
  }

  private static boolean isZipFamily(String mime) {
    if (mime == null) {
      return false;
    }
    String lower = mime.toLowerCase();
    return lower.equals("application/zip")
        || lower.equals("application/x-zip-compressed")
        || lower.equals("application/java-archive")
        || lower.startsWith("application/vnd.openxmlformats-")
        || lower.startsWith("application/vnd.ms-");
  }
}
