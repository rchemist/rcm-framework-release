/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link QuotaPolicy} default — tenant 별 byte / count tracker. Production 영역은
 * Consumer Redis / DB-backed 어댑터 권장 (multi-instance 분산 영역).
 *
 * <p>Thread-safety: tenant 단위 {@link ConcurrentHashMap} + {@link AtomicLong} → CAS.
 **/
public class InMemoryQuotaPolicy implements QuotaPolicy {

  private final long maxBytes;
  private final long maxObjects;
  private final ConcurrentHashMap<String, AtomicLong> bytes = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, AtomicLong> counts = new ConcurrentHashMap<>();

  /** unbounded default — quota 부재 영역 (Consumer override 우선). */
  public InMemoryQuotaPolicy() {
    this(-1, -1);
  }

  /**
   * @param maxBytes tenant 당 byte cap. {@code -1} = unbounded.
   * @param maxObjects tenant 당 object cap. {@code -1} = unbounded.
   */
  public InMemoryQuotaPolicy(long maxBytes, long maxObjects) {
    this.maxBytes = maxBytes;
    this.maxObjects = maxObjects;
  }

  @Override
  public void checkQuota(String tenantId, long sizeBytes) {
    long usedBytes = bytesFor(tenantId).get();
    long usedCount = countFor(tenantId).get();
    if (maxBytes >= 0 && usedBytes + sizeBytes > maxBytes) {
      throw new QuotaExceededException(
          "tenant %s byte quota exceeded: %d + %d > %d"
              .formatted(tenantId, usedBytes, sizeBytes, maxBytes));
    }
    if (maxObjects >= 0 && usedCount + 1 > maxObjects) {
      throw new QuotaExceededException(
          "tenant %s object quota exceeded: %d + 1 > %d"
              .formatted(tenantId, usedCount, maxObjects));
    }
  }

  @Override
  public void onUpload(String tenantId, long sizeBytes) {
    bytesFor(tenantId).addAndGet(sizeBytes);
    countFor(tenantId).incrementAndGet();
  }

  @Override
  public void onDelete(String tenantId, long sizeBytes) {
    bytesFor(tenantId).addAndGet(-sizeBytes);
    countFor(tenantId).decrementAndGet();
  }

  @Override
  public QuotaUsage usage(String tenantId) {
    return new QuotaUsage(
        tenantId, bytesFor(tenantId).get(), countFor(tenantId).get(), maxBytes, maxObjects);
  }

  private AtomicLong bytesFor(String tenantId) {
    return bytes.computeIfAbsent(tenantId, k -> new AtomicLong(0));
  }

  private AtomicLong countFor(String tenantId) {
    return counts.computeIfAbsent(tenantId, k -> new AtomicLong(0));
  }
}
