/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import io.rchemist.starter.storage.core.exception.StorageSecurityException;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Upload 검증 실패 — max size 초과 / 허용 MIME 외 / magic byte 미일치. {@link
 * UploadValidator#validate} 가 throw.
 **/
public class UploadValidationException extends StorageSecurityException {

  public UploadValidationException(String message) {
    super(message);
  }
}
