/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.s3;

import java.time.Duration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Presigned URL 발급 SPI — S3 / Azure Blob / GCS 백엔드별 sign 알고리즘 (AWS SigV4 / Azure
 * SAS / GCS V4 signed URL) 추상화.
 *
 * <p>baseline 구현은 framework 미포함 — Consumer 가 AWS SDK v2 / Azure SDK / GCS SDK 등을 직접
 * 의존하고 자체 {@link PresignedUrlIssuer} bean 정의. framework default = {@link
 * NoopPresignedUrlIssuer} fail-loud.
 *
 * <p>S3 / Azure / GCS / NFS Storage backend 어댑터도 동일 패턴 — Consumer 가 AWS SDK / Azure
 * SDK / GCS SDK / NFS mount 직접 의존하여 {@link io.rchemist.starter.storage.core.Storage}
 * impl 의 {@code @Component} 등록 (framework jar 자체에 SDK 포함 X).
 **/
public interface PresignedUrlIssuer {

  /** SPI 식별 이름 (e.g. {@code s3} / {@code azure-blob} / {@code gcs}). */
  String name();

  /**
   * Presigned URL 발급.
   *
   * @param key backend object key.
   * @param method HTTP method ({@link PresignedMethod}).
   * @param ttl 유효 기간 (예: {@code Duration.ofMinutes(5)}).
   * @return 발급된 URL + 만료 정보.
   */
  PresignedUrl issue(String key, PresignedMethod method, Duration ttl);
}
