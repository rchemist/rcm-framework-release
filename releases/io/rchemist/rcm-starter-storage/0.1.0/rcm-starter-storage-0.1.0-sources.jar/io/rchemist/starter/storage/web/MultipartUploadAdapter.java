/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.web;

import io.rchemist.core.context.TenantContext;
import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import io.rchemist.starter.storage.core.exception.StorageException;
import io.rchemist.starter.storage.core.exception.StorageSecurityException;
import io.rchemist.starter.storage.quota.QuotaPolicy;
import io.rchemist.starter.storage.quota.ScanResult;
import io.rchemist.starter.storage.quota.VirusScanProvider;
import io.rchemist.starter.storage.security.UploadValidator;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring {@link MultipartFile} → {@link Storage#put} 단일 호출 변환 helper. controller / service
 * 영역에서 한 줄 호출로 *5 단계 안전 fence + 저장* 자동:
 *
 * <ol>
 *   <li>UploadValidator — size + MIME + magic byte.</li>
 *   <li>QuotaPolicy — tenant 별 byte / count cap 사전 검사.</li>
 *   <li>VirusScanProvider — content scan (default = noop fail-open).</li>
 *   <li>KeyGenerator — TenantContext 자동 prefix.</li>
 *   <li>Storage.put — atomic write + checksum.</li>
 *   <li>QuotaPolicy.onUpload — 사용량 +.</li>
 * </ol>
 *
 * <p>의존 {@link UploadValidator} / {@link QuotaPolicy} / {@link VirusScanProvider} / {@link
 * KeyGenerator} / {@link Storage} 는 모두 autoconfig 에서 default bean 등록 — Consumer 가
 * controller 에서 {@code @RestController} + 본 Adapter 의존 + {@code multipartUploadAdapter
 * .upload(file)} 한 줄로 wire 가능.
 **/
public class MultipartUploadAdapter {

  /** Magic byte 검사용 header read 길이 (8 KiB) — 모든 알려진 시그니처 영역 cover. */
  private static final int HEADER_PROBE_BYTES = 8192;

  private final Storage storage;
  private final KeyGenerator keyGenerator;
  private final UploadValidator uploadValidator;
  private final QuotaPolicy quotaPolicy;
  private final VirusScanProvider virusScanner;

  public MultipartUploadAdapter(
      Storage storage,
      KeyGenerator keyGenerator,
      UploadValidator uploadValidator,
      QuotaPolicy quotaPolicy,
      VirusScanProvider virusScanner) {
    if (storage == null
        || keyGenerator == null
        || uploadValidator == null
        || quotaPolicy == null
        || virusScanner == null) {
      throw new IllegalArgumentException("all dependencies must not be null");
    }
    this.storage = storage;
    this.keyGenerator = keyGenerator;
    this.uploadValidator = uploadValidator;
    this.quotaPolicy = quotaPolicy;
    this.virusScanner = virusScanner;
  }

  /**
   * 단일 MultipartFile 업로드. 모든 검증 통과 후 Storage 에 저장 + 사용량 갱신.
   *
   * @param file Spring MultipartFile.
   * @return 저장된 {@link StorageObject} (key/contentType/size/checksum/storedAt).
   */
  public StorageObject upload(MultipartFile file) {
    if (file == null || file.isEmpty()) {
      throw new IllegalArgumentException("file must not be null/empty");
    }
    String tenantId = currentTenantId();
    byte[] content = readContent(file);
    byte[] header = headerOf(content);

    uploadValidator.validate(file.getOriginalFilename(), file.getContentType(), content.length, header);
    quotaPolicy.checkQuota(tenantId, content.length);

    ScanResult scan = virusScanner.scan(new ByteArrayInputStream(content));
    if (!scan.isClean()) {
      throw new StorageSecurityException(
          "virus scan failed (threats=%s, filename=%s)"
              .formatted(scan.threats(), file.getOriginalFilename()));
    }

    String key = keyGenerator.generate(file.getOriginalFilename());
    StorageObject stored =
        storage.put(
            key,
            new ByteArrayInputStream(content),
            file.getContentType(),
            ObjectMetadata.of(
                Map.of(
                    "original-filename",
                    nullSafe(file.getOriginalFilename()),
                    "tenant-id",
                    tenantId)));

    quotaPolicy.onUpload(tenantId, stored.size());
    return stored;
  }

  private static byte[] readContent(MultipartFile file) {
    try {
      return file.getBytes();
    } catch (IOException e) {
      throw new StorageException("failed to read MultipartFile bytes", e);
    }
  }

  private static byte[] headerOf(byte[] content) {
    int len = Math.min(content.length, HEADER_PROBE_BYTES);
    byte[] header = new byte[len];
    System.arraycopy(content, 0, header, 0, len);
    return header;
  }

  private static String currentTenantId() {
    String id = TenantContext.currentTenantIdOrNull();
    return id != null && !id.isBlank() ? id : "anonymous";
  }

  private static String nullSafe(String s) {
    return s != null ? s : "";
  }
}
