/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.core;

import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 저장된 object 의 identity + metadata (Records baseline). Storage 백엔드 (로컬 / S3 / Azure /
 * GCS) 가 공통으로 노출하는 stored object 표상.
 *
 * <p>field:
 * <ul>
 *   <li>{@code key} — backend 안 unique path (e.g. {@code tenant1/2026-05/abc.pdf}).</li>
 *   <li>{@code contentType} — MIME (e.g. {@code application/pdf}). null 가능 (백엔드 미보장).</li>
 *   <li>{@code size} — 바이트. {@code -1} = 미상 (S3 SPI 일부 영역).</li>
 *   <li>{@code checksum} — SHA-256 hex 등. null 가능 (백엔드별 baseline).</li>
 *   <li>{@code metadata} — 사용자 정의 attribute ({@link ObjectMetadata}).</li>
 *   <li>{@code storedAt} — 저장 시점 (UTC). null 가능 (head 영역 미지원 시).</li>
 * </ul>
 *
 * <p>compact constructor — {@code key} 필수 + metadata null → empty 안전 default.
 **/
public record StorageObject(
    String key,
    String contentType,
    long size,
    String checksum,
    ObjectMetadata metadata,
    Instant storedAt) {

  public StorageObject {
    if (key == null || key.isBlank()) {
      throw new IllegalArgumentException("key must not be blank");
    }
    if (metadata == null) {
      metadata = ObjectMetadata.empty();
    }
  }

  /** 최소 정보 factory — head/list 영역 등에서 contentType/checksum/storedAt 미상일 때. */
  public static StorageObject ofKey(String key, long size) {
    return new StorageObject(key, null, size, null, ObjectMetadata.empty(), null);
  }
}
