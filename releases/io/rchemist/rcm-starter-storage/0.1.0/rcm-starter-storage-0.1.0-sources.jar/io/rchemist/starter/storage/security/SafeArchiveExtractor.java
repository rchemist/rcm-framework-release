/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import io.rchemist.starter.storage.core.exception.StorageException;
import io.rchemist.starter.storage.core.exception.StorageSecurityException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Safe ZIP extractor — ZipSlip + size bomb (zip bomb) 방어 default ON.
 *
 * <p>적용 영역:
 * <ul>
 *   <li>ZipSlip — 모든 entry path 를 {@link ZipSlipProtector#safeResolve} 로 해석.</li>
 *   <li>size bomb — 총 압축 해제 크기 ({@code maxTotalSize}) 와 entry 당 크기 ({@code
 *       maxEntrySize}) cap. 초과 시 {@link StorageSecurityException} fail-loud + 임시파일
 *       cleanup.</li>
 *   <li>directory traversal — {@code .} / {@code ..} 절대경로 entry 차단 (ZipSlipProtector 와
 *       이중 fence).</li>
 * </ul>
 *
 * <p>구현 = JDK 표준 {@link ZipInputStream} 기반 (외부 의존 0).
 **/
public final class SafeArchiveExtractor {

  /** entry 당 default cap = 100 MiB. */
  public static final long DEFAULT_MAX_ENTRY_SIZE = 100L * 1024 * 1024;

  /** 총 압축 해제 default cap = 500 MiB. */
  public static final long DEFAULT_MAX_TOTAL_SIZE = 500L * 1024 * 1024;

  private final long maxEntrySize;
  private final long maxTotalSize;

  public SafeArchiveExtractor() {
    this(DEFAULT_MAX_ENTRY_SIZE, DEFAULT_MAX_TOTAL_SIZE);
  }

  public SafeArchiveExtractor(long maxEntrySize, long maxTotalSize) {
    if (maxEntrySize <= 0) {
      throw new IllegalArgumentException("maxEntrySize must be positive: " + maxEntrySize);
    }
    if (maxTotalSize <= 0) {
      throw new IllegalArgumentException("maxTotalSize must be positive: " + maxTotalSize);
    }
    this.maxEntrySize = maxEntrySize;
    this.maxTotalSize = maxTotalSize;
  }

  public long maxEntrySize() {
    return maxEntrySize;
  }

  public long maxTotalSize() {
    return maxTotalSize;
  }

  /**
   * ZIP archive 를 {@code targetDir} 에 안전하게 압축 해제. 위반 entry 발견 시 즉시 throw +
   * 이미 푼 파일도 cleanup.
   *
   * @param archive ZIP InputStream — caller 가 close 책임 (본 메서드는 close 안 함).
   * @param targetDir 압축 해제 대상 directory (자동 생성).
   * @return 압축 해제된 entry 의 절대 path 리스트 (성공 영역만).
   */
  public ExtractionResult extract(InputStream archive, Path targetDir) {
    if (archive == null) {
      throw new IllegalArgumentException("archive must not be null");
    }
    if (targetDir == null) {
      throw new IllegalArgumentException("targetDir must not be null");
    }
    java.util.List<Path> extracted = new java.util.ArrayList<>();
    long totalSize = 0L;
    try {
      Files.createDirectories(targetDir);
      try (ZipInputStream zis = new ZipInputStream(archive)) {
        ZipEntry entry;
        while ((entry = zis.getNextEntry()) != null) {
          Path resolved = ZipSlipProtector.safeResolve(targetDir, entry.getName());
          if (entry.isDirectory()) {
            Files.createDirectories(resolved);
            zis.closeEntry();
            continue;
          }
          Files.createDirectories(resolved.getParent());
          long entrySize = 0L;
          try (OutputStream out = Files.newOutputStream(resolved)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = zis.read(buffer)) != -1) {
              entrySize += read;
              totalSize += read;
              if (entrySize > maxEntrySize) {
                throw new StorageSecurityException(
                    "zip bomb suspected: entry %s exceeds %d bytes"
                        .formatted(entry.getName(), maxEntrySize));
              }
              if (totalSize > maxTotalSize) {
                throw new StorageSecurityException(
                    "zip bomb suspected: total exceeds %d bytes".formatted(maxTotalSize));
              }
              out.write(buffer, 0, read);
            }
          }
          extracted.add(resolved);
          zis.closeEntry();
        }
      }
      return new ExtractionResult(extracted, totalSize);
    } catch (StorageSecurityException e) {
      cleanupExtracted(extracted);
      throw e;
    } catch (IOException e) {
      cleanupExtracted(extracted);
      throw new StorageException("archive extraction failed", e);
    }
  }

  private static void cleanupExtracted(java.util.List<Path> paths) {
    for (Path p : paths) {
      try {
        Files.deleteIfExists(p);
      } catch (IOException ignored) {
        // best-effort cleanup
      }
    }
  }

  /**
   * 압축 해제 결과 — 성공 entry 의 절대 path + 총 byte.
   */
  public record ExtractionResult(java.util.List<Path> entries, long totalBytes) {

    public ExtractionResult {
      entries = java.util.List.copyOf(entries);
    }
  }
}
