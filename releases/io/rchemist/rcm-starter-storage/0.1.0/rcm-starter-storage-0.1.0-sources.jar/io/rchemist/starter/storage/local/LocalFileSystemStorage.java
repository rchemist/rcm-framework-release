/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.local;

import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import io.rchemist.starter.storage.core.exception.ObjectNotFoundException;
import io.rchemist.starter.storage.core.exception.StorageException;
import io.rchemist.starter.storage.core.exception.StorageSecurityException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.stream.Stream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 로컬 파일시스템 백엔드 default {@link Storage} impl. 외부 의존 0 (JDK 표준 {@link
 * java.nio.file.Files} + {@link MessageDigest}).
 *
 * <p>적용 영역:
 * <ul>
 *   <li>atomic write — 임시파일 ({@code .key.tmp.<rand>}) → {@link
 *       StandardCopyOption#ATOMIC_MOVE} 로 최종 path 교체. 부분 write / 동시 read 차단.</li>
 *   <li>SHA-256 checksum — write stream 통과 시점에 {@link MessageDigest} 계산. 추가 read pass
 *       없음.</li>
 *   <li>Path traversal 방어 — {@code key} 가 {@code ../} 등으로 baseDir 밖을 가리키면 {@link
 *       StorageSecurityException} fail-loud.</li>
 *   <li>MIME detection — caller 가 contentType 미지정 시 {@link Files#probeContentType}
 *       fallback (best-effort).</li>
 *   <li>directory 자동 생성 — 부모 디렉터리 부재 시 {@link Files#createDirectories}.</li>
 * </ul>
 **/
public class LocalFileSystemStorage implements Storage {

  private static final String BACKEND_NAME = "local";

  private final Path baseDir;

  public LocalFileSystemStorage(Path baseDir) {
    if (baseDir == null) {
      throw new IllegalArgumentException("baseDir must not be null");
    }
    this.baseDir = baseDir.toAbsolutePath().normalize();
    try {
      Files.createDirectories(this.baseDir);
    } catch (IOException e) {
      throw new StorageException("baseDir create failed: " + this.baseDir, e);
    }
  }

  @Override
  public String name() {
    return BACKEND_NAME;
  }

  @Override
  public StorageObject put(
      String key, InputStream content, String contentType, ObjectMetadata metadata) {
    Path target = resolve(key);
    Path tmp = target.resolveSibling(".tmp." + Long.toHexString(System.nanoTime()));
    try {
      Files.createDirectories(target.getParent());
      MessageDigest digest = sha256();
      long size = 0;
      try (OutputStream out = Files.newOutputStream(tmp)) {
        byte[] buffer = new byte[8192];
        int read;
        while ((read = content.read(buffer)) != -1) {
          digest.update(buffer, 0, read);
          out.write(buffer, 0, read);
          size += read;
        }
      }
      Files.move(
          tmp,
          target,
          StandardCopyOption.ATOMIC_MOVE,
          StandardCopyOption.REPLACE_EXISTING);
      String resolvedContentType = contentType != null ? contentType : detectContentType(target);
      return new StorageObject(
          key,
          resolvedContentType,
          size,
          "sha256-" + HexFormat.of().formatHex(digest.digest()),
          metadata != null ? metadata : ObjectMetadata.empty(),
          Files.getLastModifiedTime(target).toInstant());
    } catch (IOException e) {
      cleanupTmp(tmp);
      throw new StorageException("put failed for key: " + key, e);
    }
  }

  @Override
  public InputStream open(String key) {
    Path target = resolve(key);
    try {
      return Files.newInputStream(target);
    } catch (NoSuchFileException e) {
      throw new ObjectNotFoundException(key, e);
    } catch (IOException e) {
      throw new StorageException("open failed for key: " + key, e);
    }
  }

  @Override
  public StorageObject head(String key) {
    Path target = resolve(key);
    if (!Files.exists(target)) {
      throw new ObjectNotFoundException(key);
    }
    try {
      long size = Files.size(target);
      Instant storedAt = Files.getLastModifiedTime(target).toInstant();
      String contentType = detectContentType(target);
      return new StorageObject(key, contentType, size, null, ObjectMetadata.empty(), storedAt);
    } catch (IOException e) {
      throw new StorageException("head failed for key: " + key, e);
    }
  }

  @Override
  public boolean delete(String key) {
    Path target = resolve(key);
    try {
      return Files.deleteIfExists(target);
    } catch (IOException e) {
      throw new StorageException("delete failed for key: " + key, e);
    }
  }

  @Override
  public boolean exists(String key) {
    return Files.exists(resolve(key));
  }

  @Override
  public Stream<String> listKeys(String prefix) {
    Path scanRoot = baseDir;
    if (prefix != null && !prefix.isBlank()) {
      Path resolved = resolve(prefix);
      if (Files.isDirectory(resolved)) {
        scanRoot = resolved;
      } else if (!Files.exists(resolved.getParent())) {
        return Stream.empty();
      } else {
        scanRoot = resolved.getParent();
      }
    }
    try {
      Path root = scanRoot;
      return Files.walk(root)
          .filter(Files::isRegularFile)
          .map(p -> baseDir.relativize(p).toString().replace('\\', '/'));
    } catch (IOException e) {
      throw new StorageException("listKeys failed for prefix: " + prefix, e);
    }
  }

  /** key → 절대 path 해석 + Path traversal 방어 (baseDir 밖 차단). */
  private Path resolve(String key) {
    if (key == null || key.isBlank()) {
      throw new IllegalArgumentException("key must not be blank");
    }
    Path candidate = baseDir.resolve(key).normalize();
    if (!candidate.startsWith(baseDir)) {
      throw new StorageSecurityException("path traversal blocked: " + key);
    }
    return candidate;
  }

  private static MessageDigest sha256() {
    try {
      return MessageDigest.getInstance("SHA-256");
    } catch (NoSuchAlgorithmException e) {
      throw new StorageException("SHA-256 unavailable", e);
    }
  }

  private static String detectContentType(Path target) {
    try {
      String detected = Files.probeContentType(target);
      return detected != null ? detected : "application/octet-stream";
    } catch (IOException e) {
      return "application/octet-stream";
    }
  }

  private static void cleanupTmp(Path tmp) {
    try {
      Files.deleteIfExists(tmp);
    } catch (IOException ignored) {
      // best-effort cleanup; primary failure 가 이미 throw 됨.
    }
  }
}
