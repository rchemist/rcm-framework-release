/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@code platform.storage.*} prefix 의 baseline yml binding —
 * {@link StorageAutoConfiguration} 의 단일 진입점.
 *
 * <p>{@code enabled} = autoconfig 자체 opt-out flag (default true).
 * 8 영역 (local / s3 / security / magic / zip / tenant / quota / web) nested record —
 * task #3~#9 진입 시 본문 보강. 현재는 task #3 의 {@link Local} baseline.
 **/
@ConfigurationProperties(prefix = "platform.storage")
public record StorageProperties(
    @DefaultValue("true") boolean enabled, @DefaultValue Local local) {

  /**
   * Local file system 백엔드 baseline ({@code platform.storage.local.*}).
   *
   * @param enabled local backend 활성 여부 (default true — 부재 시 fail-loud 회피용 baseline).
   * @param baseDir 로컬 저장 루트. 빈 문자열 → 임시 디렉터리 fallback.
   */
  public record Local(@DefaultValue("true") boolean enabled, @DefaultValue("") String baseDir) {}
}
