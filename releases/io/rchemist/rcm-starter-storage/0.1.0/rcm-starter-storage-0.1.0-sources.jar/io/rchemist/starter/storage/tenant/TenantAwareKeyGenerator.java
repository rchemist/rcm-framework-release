/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.tenant;

import io.rchemist.core.context.TenantContext;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default {@link KeyGenerator} — 전략 기반 path 생성 (FLAT / DATE_HIERARCHICAL / TENANT_DATE).
 *
 * <p>TENANT_DATE (default) 동작:
 * <ol>
 *   <li>{@link TenantContext} ScopedValue 안 tenantId 추출 — 미binding 시 {@code anonymous}
 *       fallback (멀티테넌트 미사용 단일 인스턴스 영역 안전).</li>
 *   <li>현재 날짜 ({@code yyyy-MM}) 추출.</li>
 *   <li>UUID + 원본 filename 의 extension 결합.</li>
 * </ol>
 *
 * <p>예시: filename={@code report.pdf}, tenant={@code acme}, today={@code 2026-05-04}
 * → {@code acme/2026-05/abc123def456.pdf}.
 **/
public class TenantAwareKeyGenerator implements KeyGenerator {

  private static final DateTimeFormatter MONTH_FMT =
      DateTimeFormatter.ofPattern("yyyy-MM", Locale.ROOT);
  private static final String ANONYMOUS_TENANT = "anonymous";

  private final KeyGenerationStrategy strategy;
  private final Clock clock;

  public TenantAwareKeyGenerator() {
    this(KeyGenerationStrategy.TENANT_DATE, Clock.systemUTC());
  }

  public TenantAwareKeyGenerator(KeyGenerationStrategy strategy) {
    this(strategy, Clock.systemUTC());
  }

  public TenantAwareKeyGenerator(KeyGenerationStrategy strategy, Clock clock) {
    if (strategy == null) {
      throw new IllegalArgumentException("strategy must not be null");
    }
    if (clock == null) {
      throw new IllegalArgumentException("clock must not be null");
    }
    this.strategy = strategy;
    this.clock = clock;
  }

  public KeyGenerationStrategy strategy() {
    return strategy;
  }

  @Override
  public String generate(String filename) {
    String uuid = UUID.randomUUID().toString().replace("-", "");
    String ext = extractExtension(filename);
    String basename = ext.isEmpty() ? uuid : uuid + ext;
    return switch (strategy) {
      case FLAT -> basename;
      case DATE_HIERARCHICAL -> month() + "/" + basename;
      case TENANT_DATE -> currentTenantId() + "/" + month() + "/" + basename;
    };
  }

  private String month() {
    return LocalDate.now(clock).format(MONTH_FMT);
  }

  private static String currentTenantId() {
    String id = TenantContext.currentTenantIdOrNull();
    return id != null && !id.isBlank() ? id : ANONYMOUS_TENANT;
  }

  private static String extractExtension(String filename) {
    if (filename == null || filename.isBlank()) {
      return "";
    }
    int dot = filename.lastIndexOf('.');
    if (dot <= 0 || dot == filename.length() - 1) {
      return "";
    }
    String ext = filename.substring(dot);
    // 안전한 ext 만 보존 — alphanumeric only (extension 안 path / control char 차단).
    for (int i = 1; i < ext.length(); i++) {
      char c = ext.charAt(i);
      if (!Character.isLetterOrDigit(c)) {
        return "";
      }
    }
    return ext.toLowerCase(Locale.ROOT);
  }
}
