/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

import java.io.InputStream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Virus scan SPI — ClamAV / Sophos / Microsoft Defender 등 백엔드 추상화. {@link
 * io.rchemist.starter.storage.core.Storage#put} 직전 호출 권장.
 *
 * <p>baseline 구현 = framework 미포함. Consumer 가 자체 ClamAV client 의존 + {@code @Component}
 * 등록. framework default = {@link NoopVirusScanProvider} clean 반환 (운영 환경에서 *명시 의도*
 * 가 없으면 fail-open 영역 — 사용자 결정).
 **/
public interface VirusScanProvider {

  /** SPI 식별 이름 (e.g. {@code clamav} / {@code sophos} / {@code noop}). */
  String name();

  /**
   * Stream scan. caller 가 stream close 책임.
   *
   * @param content scan 대상 stream.
   * @return 결과 ({@link ScanResult#clean()} 또는 {@link ScanResult#infected}).
   */
  ScanResult scan(InputStream content);
}
