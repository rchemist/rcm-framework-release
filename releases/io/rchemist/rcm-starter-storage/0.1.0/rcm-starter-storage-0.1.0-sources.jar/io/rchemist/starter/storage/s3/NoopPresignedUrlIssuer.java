/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.s3;

import io.rchemist.starter.storage.core.exception.StorageException;
import java.time.Duration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default {@link PresignedUrlIssuer} — Consumer 가 backend SDK 어댑터 미설정 시 fail-loud
 * (silent skip 영역 영구 차단). S3 / Azure SAS / GCS V4 signed URL 셋업이 없는데
 * Storage.put 후 presigned URL 을 시도하면 명시 에러 메시지로 노출.
 **/
public class NoopPresignedUrlIssuer implements PresignedUrlIssuer {

  private static final String NAME = "noop";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public PresignedUrl issue(String key, PresignedMethod method, Duration ttl) {
    throw new StorageException(
        "no PresignedUrlIssuer configured — Consumer 가 S3/Azure/GCS 어댑터를 @Component 로 wire 하지 않음 (key=%s, method=%s)"
            .formatted(key, method));
  }
}
