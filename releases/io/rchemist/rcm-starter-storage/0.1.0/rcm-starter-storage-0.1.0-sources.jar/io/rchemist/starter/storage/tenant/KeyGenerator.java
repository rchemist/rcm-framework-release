/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.tenant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Storage object key 생성 SPI — 업로드 시점에 {@code filename} (사용자 입력) 을 받아 backend
 * unique path 로 변환. {@link
 * io.rchemist.starter.storage.core.Storage#put(String, java.io.InputStream, String,
 * io.rchemist.starter.storage.core.ObjectMetadata)} 의 첫 인자에 적용.
 *
 * <p>{@link io.rchemist.starter.storage.core.Storage} 와 분리된 SPI 인 이유:
 * <ul>
 *   <li>backend (local / S3 / GCS) 와 key 생성 정책이 직교 — 같은 LocalFileSystemStorage 라도
 *       Consumer 별로 다른 prefix 정책 가능.</li>
 *   <li>multi-tenant 격리 정책이 storage 백엔드 변경과 독립적 — TenantContext 영역 변동에 견고.</li>
 * </ul>
 **/
public interface KeyGenerator {

  /**
   * 사용자 filename → backend object key.
   *
   * @param filename 원본 파일 이름 (e.g. {@code report.pdf}). null/blank → {@code uuid} 만.
   * @return backend unique path (collision 없음 보장).
   */
  String generate(String filename);
}
