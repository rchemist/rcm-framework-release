/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import java.util.HexFormat;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 파일 시그니처 (Records baseline) — file header 의 byte prefix → MIME type 매핑. {@link
 * MagicByteRegistry} 가 시그니처 collection 으로 묶어 파일 종류 detect.
 *
 * <p>field:
 * <ul>
 *   <li>{@code prefix} — 매칭할 byte sequence (defensive copy).</li>
 *   <li>{@code offset} — header 안 prefix 시작 위치 (대부분 0, MP4 ftyp 같은 영역은 4).</li>
 *   <li>{@code mimeType} — 매칭 시 부여할 MIME ({@code image/png} / {@code application/pdf} 등).</li>
 *   <li>{@code description} — 진단용 사람이 읽는 라벨.</li>
 * </ul>
 *
 * <p>compact constructor — prefix null/empty 차단 + immutable copy. mimeType blank 차단.
 **/
public record MagicByteSignature(byte[] prefix, int offset, String mimeType, String description) {

  public MagicByteSignature {
    if (prefix == null || prefix.length == 0) {
      throw new IllegalArgumentException("prefix must not be empty");
    }
    if (offset < 0) {
      throw new IllegalArgumentException("offset must not be negative: " + offset);
    }
    if (mimeType == null || mimeType.isBlank()) {
      throw new IllegalArgumentException("mimeType must not be blank");
    }
    prefix = prefix.clone();
  }

  /** prefix 의 defensive copy 노출 (immutable contract). */
  @Override
  public byte[] prefix() {
    return prefix.clone();
  }

  /** {@code header} 의 {@code offset} 위치에 prefix 가 매칭되는지. */
  public boolean matches(byte[] header) {
    if (header == null || header.length < offset + prefix.length) {
      return false;
    }
    for (int i = 0; i < prefix.length; i++) {
      if (header[offset + i] != prefix[i]) {
        return false;
      }
    }
    return true;
  }

  /** hex string 으로 prefix 표기 (진단용). */
  public String prefixHex() {
    return HexFormat.of().formatHex(prefix);
  }
}
