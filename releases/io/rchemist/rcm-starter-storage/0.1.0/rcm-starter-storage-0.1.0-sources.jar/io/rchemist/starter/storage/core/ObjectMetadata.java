/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.core;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Storage object 의 사용자 정의 metadata (Map&lt;String,String&gt; — S3 user-defined metadata
 * 나 local file extended attribute 영역 정합). compact constructor 가 입력 Map 을 defensive
 * copy + immutable wrap → Record 가 mutable Map field 에 의해 외부에서 수정되는 상황 차단.
 *
 * <p>baseline 사용:
 * <ul>
 *   <li>{@link #empty()} — metadata 미지정 시 default.</li>
 *   <li>{@link #of(Map)} — 입력 Map 을 LinkedHashMap 으로 copy → 삽입 순서 보존 (사용자가
 *       OrderedMap 적용 영역 정합 — 메모리 {@code project_orderedmap_decision}).</li>
 *   <li>{@link #get(String)} — null 안전 조회.</li>
 * </ul>
 **/
public record ObjectMetadata(Map<String, String> entries) {

  /** compact constructor — null 입력 → 빈 Map, 비어있지 않으면 LinkedHashMap copy + immutable wrap. */
  public ObjectMetadata {
    if (entries == null || entries.isEmpty()) {
      entries = Map.of();
    } else {
      entries = Collections.unmodifiableMap(new LinkedHashMap<>(entries));
    }
  }

  /** 빈 metadata (null 회피용 default). */
  public static ObjectMetadata empty() {
    return new ObjectMetadata(Map.of());
  }

  /** {@link Map} 입력으로부터 immutable copy 생성. */
  public static ObjectMetadata of(Map<String, String> map) {
    return new ObjectMetadata(map);
  }

  /** 단일 key/value 조회. 미존재 = {@code null}. */
  public String get(String key) {
    return entries.get(key);
  }

  /** entry 없으면 true. */
  public boolean isEmpty() {
    return entries.isEmpty();
  }

  /** entry 개수. */
  public int size() {
    return entries.size();
  }
}
