/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Tenant quota SPI — bytes / object count cap. {@link
 * io.rchemist.starter.storage.core.Storage#put} 직전 호출 권장.
 *
 * <p>API:
 * <ul>
 *   <li>{@link #checkQuota} — 사전 검사. 초과 시 {@link QuotaExceededException} fail-loud.</li>
 *   <li>{@link #onUpload} — 성공 후 사용량 증가.</li>
 *   <li>{@link #onDelete} — 삭제 시 사용량 감소.</li>
 *   <li>{@link #usage} — 현재 사용량 snapshot.</li>
 * </ul>
 *
 * <p>Rate limit 영역은 별도 — Phase 5 의 {@code @RateLimit} (Resilience4j) 를 controller / 서비스
 * level 에서 적용 권장.
 **/
public interface QuotaPolicy {

  /** 사전 quota 검사. 초과 시 {@link QuotaExceededException}. */
  void checkQuota(String tenantId, long sizeBytes);

  /** Upload 성공 후 호출 — 사용량 +. */
  void onUpload(String tenantId, long sizeBytes);

  /** Delete 후 호출 — 사용량 −. */
  void onDelete(String tenantId, long sizeBytes);

  /** 현재 사용량 snapshot. */
  QuotaUsage usage(String tenantId);
}
