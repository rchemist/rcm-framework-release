/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.s3;

import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 발급된 Presigned URL (Records baseline) — backend 가 issue 후 application / 클라이언트가
 * 사용하는 자료.
 *
 * <p>field:
 * <ul>
 *   <li>{@code url} — 발급된 절대 URL (HTTPS 권장).</li>
 *   <li>{@code method} — HTTP method ({@link PresignedMethod}).</li>
 *   <li>{@code expiresAt} — 만료 시점 (UTC).</li>
 *   <li>{@code key} — 대상 backend object key.</li>
 * </ul>
 *
 * <p>compact constructor — url / method / expiresAt / key 모두 null 거부.
 **/
public record PresignedUrl(String url, PresignedMethod method, Instant expiresAt, String key) {

  public PresignedUrl {
    if (url == null || url.isBlank()) {
      throw new IllegalArgumentException("url must not be blank");
    }
    if (method == null) {
      throw new IllegalArgumentException("method must not be null");
    }
    if (expiresAt == null) {
      throw new IllegalArgumentException("expiresAt must not be null");
    }
    if (key == null || key.isBlank()) {
      throw new IllegalArgumentException("key must not be blank");
    }
  }

  /** 만료 여부 — 현재 UTC 기준. */
  public boolean isExpired() {
    return Instant.now().isAfter(expiresAt);
  }
}
