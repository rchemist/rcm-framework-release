/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import io.rchemist.starter.storage.core.exception.StorageSecurityException;
import java.nio.file.Path;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * ZipSlip 방어 — archive entry path 가 base directory 를 escape 하는 시도 차단. utility class
 * (instance 불가).
 *
 * <p>참조: <a
 * href="https://snyk.io/research/zip-slip-vulnerability">snyk.io/research/zip-slip-vulnerability</a>
 * — entry name 의 {@code ../../../etc/passwd} 패턴이 분산되어 보고된 라이브러리 50+ 영역.
 *
 * <p>적용 영역:
 * <ul>
 *   <li>{@link #safeResolve} — entry 의 안전 해석. base 밖이면 {@link StorageSecurityException}
 *       fail-loud.</li>
 *   <li>{@link #isSafe} — boolean 검사 only (throw 안 함).</li>
 * </ul>
 **/
public final class ZipSlipProtector {

  private ZipSlipProtector() {}

  /**
   * {@code entryName} 을 {@code baseDir} 안에서 안전하게 해석. canonical path 가 baseDir 안이
   * 아니면 {@link StorageSecurityException} fail-loud.
   *
   * @param baseDir 절대화 + normalize 된 baseline directory.
   * @param entryName archive 안 entry 이름 (e.g. {@code subdir/file.txt} or {@code
   *     ../escape.txt}).
   * @return baseDir 안의 resolved + normalized {@link Path}.
   */
  public static Path safeResolve(Path baseDir, String entryName) {
    if (baseDir == null) {
      throw new IllegalArgumentException("baseDir must not be null");
    }
    if (entryName == null || entryName.isBlank()) {
      throw new IllegalArgumentException("entryName must not be blank");
    }
    Path normalizedBase = baseDir.toAbsolutePath().normalize();
    Path candidate = normalizedBase.resolve(entryName).normalize();
    if (!candidate.startsWith(normalizedBase)) {
      throw new StorageSecurityException(
          "ZipSlip blocked: entry %s escapes baseDir %s".formatted(entryName, normalizedBase));
    }
    return candidate;
  }

  /** {@link #safeResolve} 의 boolean 변형 — entry 가 baseDir 안에 머무르면 true. */
  public static boolean isSafe(Path baseDir, String entryName) {
    try {
      safeResolve(baseDir, entryName);
      return true;
    } catch (StorageSecurityException | IllegalArgumentException e) {
      return false;
    }
  }
}
