/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.core.exception;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 존재하지 않는 key 에 대한 {@code open} / {@code head} / {@code delete} 호출 시. {@link
 * io.rchemist.starter.storage.core.Storage#delete} 는 {@code false} 반환을 우선 채택하므로 본
 * exception 은 read 영역 (open/head) 만 적용 default.
 **/
public class ObjectNotFoundException extends StorageException {

  public ObjectNotFoundException(String key) {
    super("storage object not found: " + key);
  }

  public ObjectNotFoundException(String key, Throwable cause) {
    super("storage object not found: " + key, cause);
  }
}
