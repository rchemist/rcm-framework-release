/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.quota;

import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Virus scan 결과 (Records).
 *
 * @param threats 발견된 위협 식별자 리스트 (e.g. ClamAV signature 이름). 위협 미발견 = empty.
 */
public record ScanResult(List<String> threats) {

  public ScanResult {
    threats = threats != null ? List.copyOf(threats) : List.of();
  }

  /** 위협 미발견 = empty threats. */
  public boolean isClean() {
    return threats.isEmpty();
  }

  /** 위협 미발견 result factory. */
  public static ScanResult clean() {
    return new ScanResult(List.of());
  }

  /** 위협 발견 result factory. */
  public static ScanResult infected(String... threats) {
    return new ScanResult(List.of(threats));
  }
}
