/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.autoconfig;

import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.local.LocalFileSystemStorage;
import io.rchemist.starter.storage.s3.NoopPresignedUrlIssuer;
import io.rchemist.starter.storage.s3.PresignedUrlIssuer;
import io.rchemist.starter.storage.quota.InMemoryQuotaPolicy;
import io.rchemist.starter.storage.quota.NoopVirusScanProvider;
import io.rchemist.starter.storage.quota.QuotaPolicy;
import io.rchemist.starter.storage.quota.VirusScanProvider;
import io.rchemist.starter.storage.security.UploadValidator;
import io.rchemist.starter.storage.web.MultipartUploadAdapter;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import io.rchemist.starter.storage.tenant.TenantAwareKeyGenerator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.web.multipart.MultipartFile;
import io.rchemist.starter.storage.security.MagicByteRegistry;
import io.rchemist.starter.storage.security.SafeArchiveExtractor;
import io.rchemist.starter.storage.security.TempFileCleaner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6.8 task #1 — {@code rcm-starter-storage} 진입점 (Decision #12 옵션 starter).
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>Decision #20 — prefix 없음. starter / 패키지 가 도메인 영역 자체 명시
 *       ({@code io.rchemist.starter.storage}). class 이름 = 도메인 의미 풀네임
 *       ({@code Storage} / {@code LocalFileSystemStorage} / {@code S3StorageProvider} /
 *       {@code KeyGenerator} / {@code MagicByteSignature} / {@code UploadValidator}).</li>
 *   <li>{@code platform.storage.enabled=false} 로 opt-out (default true).</li>
 *   <li>8 inner static config marker — task #2~#9 진입 시 본문 채움
 *       (local / s3 / security / magic / zip / tenant / quota / web).</li>
 * </ul>
 *
 * <p>Phase 5 / 6 / 6.5 / 6.7 의 {@code SecurityAutoConfiguration} /
 * {@code ExternalAutoConfiguration} / {@code KoreanRegionAutoConfiguration} /
 * {@code NotificationAutoConfiguration} 패턴 정합.
 **/
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.storage", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(StorageProperties.class)
public class StorageAutoConfiguration {

  /** Phase 6.8 task #3 — Local file system Storage default impl. */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(
      prefix = "platform.storage.local",
      name = "enabled",
      matchIfMissing = true)
  static class LocalBeans {

    /**
     * Default {@link Storage} bean = {@link LocalFileSystemStorage}. {@code
     * platform.storage.local.baseDir} 가 비어있으면 OS 임시 디렉터리의 {@code rcm-storage}
     * sub-folder fallback (테스트 / 개발 영역). Consumer 가 자체 {@link Storage} bean 정의 시 양보.
     */
    @Bean
    @ConditionalOnMissingBean(Storage.class)
    Storage localFileSystemStorage(StorageProperties properties) {
      Path baseDir = resolveBaseDir(properties.local().baseDir());
      return new LocalFileSystemStorage(baseDir);
    }

    private static Path resolveBaseDir(String configured) {
      if (configured == null || configured.isBlank()) {
        try {
          return Files.createDirectories(
              Paths.get(System.getProperty("java.io.tmpdir"), "rcm-storage"));
        } catch (IOException e) {
          throw new IllegalStateException("default baseDir create failed", e);
        }
      }
      return Paths.get(configured);
    }
  }

  /** Phase 6.8 task #6 — S3 / Azure / GCS / NFS Storage SPI 슬롯 + Presigned URL. */
  @Configuration(proxyBeanMethods = false)
  static class S3Beans {

    /**
     * Default {@link PresignedUrlIssuer} = {@link NoopPresignedUrlIssuer} fail-loud. Consumer
     * 가 AWS SDK v2 / Azure SDK / GCS SDK 어댑터를 {@code @Component} 로 등록 시 양보 ({@link
     * ConditionalOnMissingBean}).
     */
    @Bean
    @ConditionalOnMissingBean(PresignedUrlIssuer.class)
    PresignedUrlIssuer noopPresignedUrlIssuer() {
      return new NoopPresignedUrlIssuer();
    }
  }

  /** Phase 6.8 task #4 — Upload security baseline (max size + MIME whitelist). */
  @Configuration(proxyBeanMethods = false)
  static class SecurityBeans {}

  /** Phase 6.8 task #4 — Magic byte 화이트리스트 (PNG/JPG/PDF/ZIP/DOCX/XLSX 등). */
  @Configuration(proxyBeanMethods = false)
  static class MagicByteBeans {

    /**
     * Default {@link MagicByteRegistry} = {@link MagicByteRegistry#defaults()} 9 종 baseline.
     * Consumer 가 자체 Registry 등록 시 양보 ({@link ConditionalOnMissingBean}).
     */
    @Bean
    @ConditionalOnMissingBean(MagicByteRegistry.class)
    MagicByteRegistry magicByteRegistry() {
      return MagicByteRegistry.defaults();
    }
  }

  /** Phase 6.8 task #5 — ZipSlip 방어 + 임시파일 cleanup lifecycle. */
  @Configuration(proxyBeanMethods = false)
  static class ZipBeans {

    /** Default {@link SafeArchiveExtractor} = 100 MiB / 500 MiB cap. */
    @Bean
    @ConditionalOnMissingBean(SafeArchiveExtractor.class)
    SafeArchiveExtractor safeArchiveExtractor() {
      return new SafeArchiveExtractor();
    }

    /** Default {@link TempFileCleaner} — DisposableBean 자동 cleanup. */
    @Bean
    @ConditionalOnMissingBean(TempFileCleaner.class)
    TempFileCleaner tempFileCleaner() {
      return new TempFileCleaner();
    }
  }

  /** Phase 6.8 task #7 — Multi-tenant key pattern (tenantId/yyyy-MM/uuid). */
  @Configuration(proxyBeanMethods = false)
  static class TenantBeans {

    /** Default {@link KeyGenerator} = {@link TenantAwareKeyGenerator} TENANT_DATE 전략. */
    @Bean
    @ConditionalOnMissingBean(KeyGenerator.class)
    KeyGenerator tenantAwareKeyGenerator() {
      return new TenantAwareKeyGenerator();
    }
  }

  /** Phase 6.8 task #8 — Quota / RateLimit / VirusScan SPI. */
  @Configuration(proxyBeanMethods = false)
  static class QuotaBeans {

    /** Default {@link QuotaPolicy} = {@link InMemoryQuotaPolicy} unbounded. */
    @Bean
    @ConditionalOnMissingBean(QuotaPolicy.class)
    QuotaPolicy inMemoryQuotaPolicy() {
      return new InMemoryQuotaPolicy();
    }

    /** Default {@link VirusScanProvider} = {@link NoopVirusScanProvider} fail-open. */
    @Bean
    @ConditionalOnMissingBean(VirusScanProvider.class)
    VirusScanProvider noopVirusScanProvider() {
      return new NoopVirusScanProvider();
    }
  }

  /** Phase 6.8 task #9 — Web 통합 (MultipartFile → StorageObject 변환 helper). */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(MultipartFile.class)
  static class WebBeans {

    /**
     * Default {@link MultipartUploadAdapter} bean — autoconfig 안 5 의존을 자동 wire (storage /
     * key generator / upload validator / quota policy / virus scanner). Consumer 가 자체
     * UploadValidator bean 정의 시 그것 우선 (기본 validator 는 화이트리스트 unbounded baseline).
     */
    @Bean
    @ConditionalOnBean(Storage.class)
    @ConditionalOnMissingBean({MultipartUploadAdapter.class, UploadValidator.class})
    MultipartUploadAdapter defaultMultipartUploadAdapter(
        Storage storage,
        KeyGenerator keyGenerator,
        QuotaPolicy quotaPolicy,
        VirusScanProvider virusScanner,
        MagicByteRegistry registry) {
      // Default validator = 100 MiB cap + 모든 MIME 허용 (whitelist 빈) + 시그니처 등록 필수.
      // Consumer 가 더 엄격한 정책을 원하면 자체 UploadValidator + MultipartUploadAdapter wire.
      UploadValidator validator =
          new UploadValidator(100L * 1024 * 1024, java.util.Set.of(), registry, true);
      return new MultipartUploadAdapter(
          storage, keyGenerator, validator, quotaPolicy, virusScanner);
    }
  }
}
