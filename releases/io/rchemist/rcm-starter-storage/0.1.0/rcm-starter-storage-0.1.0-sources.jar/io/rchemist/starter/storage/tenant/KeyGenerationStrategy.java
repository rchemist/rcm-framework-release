/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.tenant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Key 생성 전략 — Storage 안 object 의 path 패턴 결정.
 *
 * <ul>
 *   <li>{@link #FLAT} — {@code uuid.ext}. tenant / 시간 영역 무관 (단일 tenant 또는 sandbox).</li>
 *   <li>{@link #DATE_HIERARCHICAL} — {@code yyyy-MM/uuid.ext}. tenant 분리 X.</li>
 *   <li>{@link #TENANT_DATE} — {@code tenantId/yyyy-MM/uuid.ext}. default. {@link
 *       io.rchemist.core.context.TenantContext} 의 ScopedValue 안 tenantId 자동 prefix.</li>
 * </ul>
 **/
public enum KeyGenerationStrategy {

  /** {@code uuid.ext} — 단일 tenant / sandbox. */
  FLAT,

  /** {@code yyyy-MM/uuid.ext} — 시간 분할. */
  DATE_HIERARCHICAL,

  /** {@code tenantId/yyyy-MM/uuid.ext} — multi-tenant default. */
  TENANT_DATE
}
