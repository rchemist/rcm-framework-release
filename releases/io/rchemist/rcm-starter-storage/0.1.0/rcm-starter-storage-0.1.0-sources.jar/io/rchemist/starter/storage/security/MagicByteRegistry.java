/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.storage.security;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 파일 시그니처 화이트리스트. {@link MagicByteRegistry#defaults()} 가 보편적인 baseline 9 종 등록
 * (PNG / JPEG / GIF / PDF / ZIP container / MP4 / MP3 / WAV / RIFF).
 *
 * <p>{@link #detect(byte[])} = header 의 첫 매칭 시그니처 반환 (Optional). Consumer 가 추가
 * 시그니처를 등록하려면 {@link #builder()} 또는 {@link Builder#add} 사용.
 *
 * <p>baseline 결정:
 * <ul>
 *   <li>DOCX / XLSX / PPTX 는 ZIP container 와 시그니처 동일 (PK\x03\x04). 본 registry 는
 *       container 수준 detect 까지만 — Office Open XML 구체 식별은 ZIP 안 [Content_Types].xml
 *       파싱이 필요해 별도 영역.</li>
 *   <li>외부 의존 0 (Apache Tika 등 제외) — 가장 흔한 9 종 만 cover.</li>
 * </ul>
 **/
public final class MagicByteRegistry {

  private final List<MagicByteSignature> signatures;

  private MagicByteRegistry(List<MagicByteSignature> signatures) {
    this.signatures = List.copyOf(signatures);
  }

  /** 등록된 모든 시그니처 (immutable view). */
  public List<MagicByteSignature> signatures() {
    return signatures;
  }

  /** 등록 시그니처 수. */
  public int size() {
    return signatures.size();
  }

  /** {@code header} 매칭 시그니처 첫 번째 반환. 미매칭 = empty. */
  public Optional<MagicByteSignature> detect(byte[] header) {
    if (header == null) {
      return Optional.empty();
    }
    for (MagicByteSignature sig : signatures) {
      if (sig.matches(header)) {
        return Optional.of(sig);
      }
    }
    return Optional.empty();
  }

  /** Empty registry — 시그니처 0 (테스트 영역). */
  public static MagicByteRegistry empty() {
    return new MagicByteRegistry(Collections.emptyList());
  }

  /** baseline 9 종 (PNG / JPEG / GIF / PDF / ZIP / MP4 / MP3 ID3 / MP3 frame / WAV RIFF). */
  public static MagicByteRegistry defaults() {
    return builder()
        .add(
            new MagicByteSignature(
                new byte[] {
                  (byte) 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
                },
                0,
                "image/png",
                "PNG"))
        .add(
            new MagicByteSignature(
                new byte[] {(byte) 0xFF, (byte) 0xD8, (byte) 0xFF}, 0, "image/jpeg", "JPEG"))
        .add(
            new MagicByteSignature(
                new byte[] {0x47, 0x49, 0x46, 0x38}, 0, "image/gif", "GIF (87a/89a)"))
        .add(
            new MagicByteSignature(
                new byte[] {0x25, 0x50, 0x44, 0x46}, 0, "application/pdf", "PDF"))
        .add(
            new MagicByteSignature(
                new byte[] {0x50, 0x4B, 0x03, 0x04},
                0,
                "application/zip",
                "ZIP (incl. DOCX/XLSX/PPTX/JAR)"))
        .add(
            new MagicByteSignature(
                new byte[] {0x66, 0x74, 0x79, 0x70}, 4, "video/mp4", "MP4 (ftyp box)"))
        .add(
            new MagicByteSignature(
                new byte[] {0x49, 0x44, 0x33}, 0, "audio/mpeg", "MP3 (ID3v2 tag)"))
        .add(
            new MagicByteSignature(
                new byte[] {(byte) 0xFF, (byte) 0xFB}, 0, "audio/mpeg", "MP3 (MPEG-1 Layer 3)"))
        .add(
            new MagicByteSignature(
                new byte[] {0x52, 0x49, 0x46, 0x46}, 0, "audio/wav", "RIFF (WAV / AVI)"))
        .build();
  }

  /** Builder — Consumer 가 default + 추가 시그니처 mix. */
  public static Builder builder() {
    return new Builder();
  }

  /** Mutable builder — {@link #build()} 가 immutable Registry 생성. */
  public static final class Builder {
    private final List<MagicByteSignature> entries = new ArrayList<>();

    public Builder add(MagicByteSignature signature) {
      entries.add(signature);
      return this;
    }

    public MagicByteRegistry build() {
      return new MagicByteRegistry(entries);
    }
  }
}
