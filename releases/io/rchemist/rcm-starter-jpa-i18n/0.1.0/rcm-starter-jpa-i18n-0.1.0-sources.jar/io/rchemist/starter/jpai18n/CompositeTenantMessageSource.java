/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import java.util.Locale;
import java.util.Objects;
import org.springframework.context.HierarchicalMessageSource;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 (Decision #32) — {@link DatabaseMessageSource} ▸ file fallback chain.
 *
 * <p>chain 순서:
 * <ol>
 *   <li>{@code primary} = {@link DatabaseMessageSource} — DB lookup + Caffeine cache</li>
 *   <li>{@code parent} = file fallback (Phase 2 baseline {@link
 *       io.rchemist.starter.web.validation.TenantMessageSource} 또는 {@code ResourceBundleMessageSource})
 *       — DB miss 시 자동 인입</li>
 *   <li>{@code parent} 의 자체 fallback chain (TenantMessageSource → delegate ResourceBundleMessageSource)
 *       이 default 까지 자연 진행</li>
 * </ol>
 *
 * <p>{@link DatabaseMessageSource} 가 cache miss 시 {@link NoSuchMessageException} throw 하면 parent 가
 * 인입. parent 도 부재 시 본 source 가 throw 또는 default message 반환 (caller 시그니처 따라).
 **/
public class CompositeTenantMessageSource implements HierarchicalMessageSource {

  private final DatabaseMessageSource primary;
  private MessageSource parent;

  public CompositeTenantMessageSource(DatabaseMessageSource primary, MessageSource parent) {
    this.primary = Objects.requireNonNull(primary, "primary");
    this.parent = parent;
  }

  @Override
  public void setParentMessageSource(MessageSource parent) {
    this.parent = parent;
  }

  @Override
  public MessageSource getParentMessageSource() {
    return parent;
  }

  @Override
  public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
    String hit = tryPrimary(code, args, locale);
    if (hit != null) {
      return hit;
    }
    if (parent != null) {
      return parent.getMessage(code, args, defaultMessage, locale);
    }
    return defaultMessage;
  }

  @Override
  public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
    String hit = tryPrimary(code, args, locale);
    if (hit != null) {
      return hit;
    }
    if (parent != null) {
      return parent.getMessage(code, args, locale);
    }
    throw new NoSuchMessageException(code, locale);
  }

  @Override
  public String getMessage(MessageSourceResolvable resolvable, Locale locale)
      throws NoSuchMessageException {
    try {
      return primary.getMessage(resolvable, locale);
    } catch (NoSuchMessageException e) {
      if (parent != null) {
        return parent.getMessage(resolvable, locale);
      }
      throw e;
    }
  }

  /**
   * primary lookup — cache miss / row 없음 시 {@link NoSuchMessageException} → {@code null} 반환하여
   * caller 가 parent 로 fall through 가능.
   */
  private String tryPrimary(String code, Object[] args, Locale locale) {
    try {
      return primary.getMessage(code, args, locale);
    } catch (NoSuchMessageException e) {
      return null;
    }
  }
}
