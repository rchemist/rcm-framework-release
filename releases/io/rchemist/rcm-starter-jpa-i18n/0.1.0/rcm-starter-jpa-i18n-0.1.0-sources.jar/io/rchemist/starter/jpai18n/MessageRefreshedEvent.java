/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import io.rchemist.core.context.TenantContext;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 — admin GUI / 배치가 메시지 수정 후 publish 하는 cache invalidation 이벤트.
 *
 * <p>{@code tenantId} / {@code localeTag} / {@code code} 가 모두 non-null 이면 단일 key 무효화,
 * 모두 {@code null} 이면 전체 cache 무효화 ({@link #all()}). 일부만 null 인 경우는 invalid — single-key
 * vs all-clear 만 지원 (range invalidation 은 본 task 범위 X, Phase 0.1.x 후속 패턴).
 *
 * <p>multi-instance 환경에서는 본 이벤트를 Redis pub/sub adapter 로 fan-out (Phase 0.1.x 후속 옵션).
 * 본 task = 단일 instance 의 in-process broadcast 만.
 *
 * @param tenantId   tenant 식별자 ({@link TenantContext#SYSTEM_TENANT_ID} 가능, all-clear 시 {@code null})
 * @param localeTag  BCP 47 locale tag (예: ko-KR, all-clear 시 {@code null})
 * @param code       message code (all-clear 시 {@code null})
 */
public record MessageRefreshedEvent(String tenantId, String localeTag, String code) {

  /**
   * 단일 key 무효화 이벤트.
   */
  public static MessageRefreshedEvent of(String tenantId, String localeTag, String code) {
    if (tenantId == null || localeTag == null || code == null) {
      throw new IllegalArgumentException(
          "single-key MessageRefreshedEvent 는 tenantId / localeTag / code 모두 non-null. all-clear "
              + "는 MessageRefreshedEvent.all() 사용");
    }
    return new MessageRefreshedEvent(tenantId, localeTag, code);
  }

  /**
   * 전체 cache 무효화 이벤트.
   */
  public static MessageRefreshedEvent all() {
    return new MessageRefreshedEvent(null, null, null);
  }

  /**
   * single-key vs all-clear 판별. 셋 다 null = all-clear, 셋 다 non-null = single-key.
   */
  public boolean isAllClear() {
    return tenantId == null && localeTag == null && code == null;
  }
}
