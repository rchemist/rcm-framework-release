/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 (Decision #32) — JPA i18n 설정 — Records first.
 *
 * <p>속성 영역:
 * <ul>
 *   <li>{@code tenantSource} — MessageSource 모드 — {@link TenantSource#FILE} (Phase 2 baseline 그대로) /
 *       {@link TenantSource#DATABASE} (DB 단독, parent chain 없음 strict 모드) /
 *       {@link TenantSource#COMPOSITE} (DB ▸ file ▸ default chain, JPA bean 인입 시 default).</li>
 *   <li>{@code cache} — Caffeine cache 설정 (TTL + max-size).</li>
 * </ul>
 *
 * @param tenantSource MessageSource 모드 (default: COMPOSITE)
 * @param cache        Caffeine cache 설정
 */
@ConfigurationProperties("platform.i18n")
public record JpaI18nProperties(
    @DefaultValue("composite") TenantSource tenantSource,
    @DefaultValue Cache cache) {

  /**
   * MessageSource 모드. Decision #32 정합 — 프로젝트마다 가벼운 file vs DB 기반 dynamic 선택 가능.
   */
  public enum TenantSource {
    /** Phase 2 baseline — properties only, JPA 미사용 시 default. */
    FILE,
    /** DB 단독 — strict 모드, miss 시 NoSuchMessageException. parent chain 없음. */
    DATABASE,
    /** DB ▸ file ▸ default chain — 가장 흔한 운영 모드, JPA bean present 시 default. */
    COMPOSITE
  }

  /**
   * Caffeine cache 설정. {@code ttl} = TTL (default 5 분), {@code maxSize} = 최대 entry 수 (default 10000).
   *
   * @param ttl     cache TTL
   * @param maxSize 최대 entry 수
   */
  public record Cache(
      @DefaultValue("PT5M") Duration ttl,
      @DefaultValue("10000") long maxSize) {
  }
}
