/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.rchemist.core.context.TenantContext;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import org.springframework.context.support.AbstractMessageSource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 (Decision #32) — DB-backed MessageSource.
 *
 * <p>{@link AbstractMessageSource} 위에서 {@link MessageRepository} 조회 + Caffeine cache 결합.
 * cache key = {@code tenantId|locale|code} (tenant 별 격리). miss 시 Repository 조회 후 cache fill,
 * miss-and-empty 시에도 {@code Optional.empty()} marker 를 cache 에 저장하여 같은 미존재 코드의 반복
 * 조회 회피 (negative cache).
 *
 * <p>{@link AbstractMessageSource#resolveCode(String, Locale)} 가 hit 시 {@link MessageFormat} 반환,
 * miss 시 {@code null} 반환 — Spring 의 parent chain 자동 인입 (Composite 시 file fallback).
 *
 * <p>tenant 결정 우선순위: (1) {@link TenantContext#currentTenantIdOrNull()} (2) 없거나
 * {@link TenantContext#SYSTEM_TENANT_ID} 일 때 system tenant 직접 조회. cache 도 system tenant 분리 보관.
 **/
public class DatabaseMessageSource extends AbstractMessageSource {

  private final MessageRepository repository;
  private final Cache<String, Optional<MessageFormat>> cache;

  public DatabaseMessageSource(MessageRepository repository, Duration ttl, long maxSize) {
    this.repository = Objects.requireNonNull(repository, "repository");
    this.cache = Caffeine.newBuilder()
        .expireAfterWrite(Objects.requireNonNullElse(ttl, Duration.ofMinutes(5)))
        .maximumSize(maxSize <= 0 ? 10_000 : maxSize)
        .build();
    setUseCodeAsDefaultMessage(false);
  }

  @Override
  protected MessageFormat resolveCode(String code, Locale locale) {
    if (code == null || locale == null) {
      return null;
    }
    String tenantId = resolveTenantId();
    String localeTag = locale.toLanguageTag();
    String key = cacheKey(tenantId, localeTag, code);
    Optional<MessageFormat> hit = cache.getIfPresent(key);
    if (hit != null) {
      return hit.orElse(null);
    }
    Optional<MessageFormat> resolved = lookupAndBuildFormat(tenantId, localeTag, locale, code);
    cache.put(key, resolved);
    return resolved.orElse(null);
  }

  /**
   * Repository 조회 + MessageFormat build. cache 채움은 호출 측 책임.
   */
  private Optional<MessageFormat> lookupAndBuildFormat(
      String tenantId, String localeTag, Locale locale, String code) {
    Optional<Message> entity = repository.findByTenantIdAndLocaleAndCode(tenantId, localeTag, code);
    return entity.map(m -> createMessageFormat(m.getMessage(), locale));
  }

  /**
   * 단일 cache key 무효화. {@link MessageCacheInvalidator} 에서 호출.
   */
  void evict(String tenantId, String localeTag, String code) {
    cache.invalidate(cacheKey(tenantId, localeTag, code));
  }

  /**
   * 전체 cache 무효화. {@link MessageRefreshedEvent#all()} 처리 시.
   */
  void evictAll() {
    cache.invalidateAll();
  }

  /**
   * 외부 (admin / IT) 가 cache 적중 여부 확인용. negative cache 와 hit 동시 노출.
   */
  Optional<Optional<MessageFormat>> peek(String tenantId, String localeTag, String code) {
    return Optional.ofNullable(cache.getIfPresent(cacheKey(tenantId, localeTag, code)));
  }

  private String resolveTenantId() {
    String current = TenantContext.currentTenantIdOrNull();
    return (current == null || current.isBlank()) ? TenantContext.SYSTEM_TENANT_ID : current;
  }

  private static String cacheKey(String tenantId, String localeTag, String code) {
    return tenantId + '|' + localeTag + '|' + code;
  }
}
