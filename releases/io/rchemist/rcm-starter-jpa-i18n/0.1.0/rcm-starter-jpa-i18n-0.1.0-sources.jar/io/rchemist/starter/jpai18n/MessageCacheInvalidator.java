/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import java.util.Objects;
import org.springframework.context.event.EventListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 — {@link MessageRefreshedEvent} listener.
 *
 * <p>{@link MessageRefreshedEvent#isAllClear()} 시 전체 cache 무효화, 그 외 단일 key 무효화.
 * {@link DatabaseMessageSource} 의 package-private {@code evict} / {@code evictAll} 호출.
 **/
public class MessageCacheInvalidator {

  private final DatabaseMessageSource databaseMessageSource;

  public MessageCacheInvalidator(DatabaseMessageSource databaseMessageSource) {
    this.databaseMessageSource = Objects.requireNonNull(databaseMessageSource, "databaseMessageSource");
  }

  @EventListener
  public void onMessageRefreshed(MessageRefreshedEvent event) {
    if (event.isAllClear()) {
      databaseMessageSource.evictAll();
      return;
    }
    databaseMessageSource.evict(event.tenantId(), event.localeTag(), event.code());
  }
}
