/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import io.rchemist.core.marker.Auditable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 (Decision #32) — DB-backed MessageSource entity.
 *
 * <p>(tenantId, locale, code) 3 영역 unique. {@code tenantId} 는 plain column (Hibernate {@code @TenantId}
 * 미부착) — DatabaseMessageSource 가 직접 tenantId 결합 조회 + system-tenant fallback 도 가능해야 하기
 * 때문. multi-tenancy 의 자동 filter 와 분리.
 *
 * <p>{@code message} = MessageFormat 패턴 (예: {@code "환영합니다 {0}"}). Spring AbstractMessageSource 의
 * {@code MessageFormat.format(message, args, locale)} 가 placeholder 치환.
 **/
@Entity
@Table(
    name = "T_MESSAGE",
    comment = "Tenant 별 i18n 메시지 — admin GUI 에서 편집, DatabaseMessageSource 가 Caffeine cache 통해 lookup",
    uniqueConstraints = @UniqueConstraint(
        name = "IX_MESSAGE_TENANT_LOCALE_CODE",
        columnNames = {"TENANT_ID", "LOCALE", "CODE"}),
    indexes = @Index(name = "IDX_MESSAGE_TENANT_LOCALE", columnList = "TENANT_ID,LOCALE"))
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@NoArgsConstructor
public class Message implements Auditable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "MESSAGE_ID", nullable = false, comment = "Message PK")
  private Long id;

  @Column(name = "TENANT_ID", length = 64, nullable = false,
      comment = "Tenant 식별자 (system tenant = __system__ 상수, TenantContext.SYSTEM_TENANT_ID 정합)")
  private String tenantId;

  @Column(name = "LOCALE", length = 32, nullable = false,
      comment = "Locale tag (BCP 47, 예: ko / ko-KR / en / en-US)")
  private String locale;

  @Column(name = "CODE", length = 200, nullable = false,
      comment = "Message code (예: validation.notnull.username)")
  private String code;

  @Column(name = "MESSAGE", length = 4000, nullable = false,
      comment = "Message 패턴 (MessageFormat 형식, {0}/{1} 인덱스 placeholder)")
  private String message;

  @CreatedDate
  @Column(name = "CREATED_AT", nullable = false, updatable = false, comment = "최초 생성 시각")
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT", nullable = false, comment = "최종 수정 시각")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY", length = 64, updatable = false, comment = "최초 생성자")
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY", length = 64, comment = "최종 수정자")
  private String updatedBy;

  public Message(String tenantId, String locale, String code, String message) {
    this.tenantId = tenantId;
    this.locale = locale;
    this.code = code;
    this.message = message;
  }
}
