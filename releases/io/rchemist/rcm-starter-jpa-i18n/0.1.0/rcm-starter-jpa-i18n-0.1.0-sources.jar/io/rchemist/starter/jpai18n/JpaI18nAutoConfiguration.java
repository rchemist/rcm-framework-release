/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import io.rchemist.web.StarterWebAutoConfiguration;
import jakarta.persistence.EntityManager;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 (Decision #32) — JPA i18n autoconfig.
 *
 * <p>{@code platform.i18n.tenant-source} 한 줄 토글:
 * <ul>
 *   <li>{@code file} — Phase 2 baseline 그대로. 본 autoconfig 자체가 비활성 (no beans).</li>
 *   <li>{@code database} — {@link DatabaseMessageSource} 단독 — strict 모드, miss 시 NoSuchMessageException.</li>
 *   <li>{@code composite} (default) — {@link CompositeTenantMessageSource} (DB ▸ file ▸ default chain) —
 *       JPA 의존이 classpath 에 있으면 자동.</li>
 * </ul>
 *
 * <p>{@code messageSource} 표준 bean name 으로 등록 — Spring {@code ApplicationContext} 가 root
 * MessageSource 로 자동 인식. {@code validationMessageSource} (Phase 2, Bean Validation 영역) 는 별도
 * 그대로 유지 — 두 source 의 책임 분리 (validation messages vs application messages).
 *
 * <p>JPA repositories / entity scan 본 starter package limit — Consumer 의 다른 entity 영역과 isolation.
 **/
@AutoConfiguration(after = StarterWebAutoConfiguration.class)
@ConditionalOnClass({EntityManager.class})
@ConditionalOnExpression(
    "!'${platform.i18n.tenant-source:composite}'.equalsIgnoreCase('file')")
@EnableConfigurationProperties(JpaI18nProperties.class)
@EnableJpaRepositories(basePackageClasses = MessageRepository.class)
@EntityScan(basePackageClasses = Message.class)
public class JpaI18nAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public DatabaseMessageSource databaseMessageSource(
      MessageRepository repository, JpaI18nProperties properties) {
    return new DatabaseMessageSource(
        repository, properties.cache().ttl(), properties.cache().maxSize());
  }

  @Bean
  @ConditionalOnMissingBean
  public MessageCacheInvalidator messageCacheInvalidator(DatabaseMessageSource source) {
    return new MessageCacheInvalidator(source);
  }

  /**
   * Database mode — {@link DatabaseMessageSource} 단독 root MessageSource. parent chain 없음 — miss 시
   * NoSuchMessageException 그대로. 운영 strict 모드 (모든 메시지가 DB 진실 원천).
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(
      prefix = "platform.i18n",
      name = "tenant-source",
      havingValue = "database")
  static class DatabaseOnlyMode {

    @Bean(name = "messageSource")
    @ConditionalOnMissingBean(name = "messageSource")
    public MessageSource messageSource(DatabaseMessageSource source) {
      return source;
    }
  }

  /**
   * Composite mode (default) — {@link CompositeTenantMessageSource} = DB ▸ file ▸ default chain. file
   * 영역 = {@code messages} basename {@link ResourceBundleMessageSource} (Spring 표준 convention).
   * Consumer 가 자체 {@code messageSource} bean 적용 시 자동 교체.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(
      prefix = "platform.i18n",
      name = "tenant-source",
      havingValue = "composite",
      matchIfMissing = true)
  static class CompositeMode {

    @Bean(name = "messageSource")
    @ConditionalOnMissingBean(name = "messageSource")
    public MessageSource messageSource(DatabaseMessageSource source) {
      ResourceBundleMessageSource file = new ResourceBundleMessageSource();
      file.setBasename("messages");
      file.setDefaultEncoding("UTF-8");
      file.setUseCodeAsDefaultMessage(false);
      file.setFallbackToSystemLocale(false);
      return new CompositeTenantMessageSource(source, file);
    }
  }
}
