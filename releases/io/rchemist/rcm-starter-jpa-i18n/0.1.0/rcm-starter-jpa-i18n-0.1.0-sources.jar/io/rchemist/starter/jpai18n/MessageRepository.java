/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpai18n;

import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 — Spring Data JPA repository for {@link Message}.
 *
 * <p>{@link DatabaseMessageSource} 가 cache miss 시 {@link #findByTenantIdAndLocaleAndCode(String, String, String)}
 * 단일 조회. paged search 는 admin REST API (Consumer 자체 노출, framework 미제공) 에서 사용.
 **/
public interface MessageRepository extends JpaRepository<Message, Long> {

  Optional<Message> findByTenantIdAndLocaleAndCode(String tenantId, String locale, String code);

  Page<Message> findByTenantId(String tenantId, Pageable pageable);

  Page<Message> findByTenantIdAndLocale(String tenantId, String locale, Pageable pageable);
}
