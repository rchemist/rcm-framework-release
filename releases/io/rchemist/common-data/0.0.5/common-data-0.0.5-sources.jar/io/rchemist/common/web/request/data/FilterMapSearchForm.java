/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.query.ExistsFilterGroup;
import io.rchemist.common.search.data.query.ExistsFilterItem;
import io.rchemist.common.search.service.exception.SearchServiceException;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface FilterMapSearchForm<S> {

  void revertPreservedFilterAndSortCriteria();

  void validateSorts(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException;

  void validateFilters(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException;

  default void preparePreservedFilterAndSortCriteria(Class<?> entityClass, boolean hibernateSearch) {
    createPreservedFilterAndSortCriteria();
    try {
      validateFilters(entityClass, hibernateSearch);
      validateSorts(entityClass, hibernateSearch);
    }catch (Exception e) {
      // nothing to do
    }
  }

  /**
   * 현재 Filter, Sorts 정보를 백업한다.
   * 최초 호출 시점에서 1회만 백업할 수 있다.
   */
  boolean createPreservedFilterAndSortCriteria();

  default S modifyFiltersWithPreservedFilterAndSortCriteria(ModifyFilterAndSortCriteria criteria) {
    createPreservedFilterAndSortCriteria();

    criteria.modify(this);

    return (S) this;
  }

  LinkedHashMap<ConditionOperatorType, FilterItem[]> getFilters();

  void setFilters(LinkedHashMap<ConditionOperatorType, FilterItem[]> filters);

  S setFilterIfAbsent(ConditionOperatorType operatorType, FilterItem... filterItems);

  default LinkedHashMap<ConditionOperatorType, FilterItem[]> addFilters(ConditionOperatorType operatorType, FilterItem... filterItems) {

    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = getFilters();

    if(filters.containsKey(operatorType)) {

      FilterItem[] previous = filters.get(operatorType);

      Map<String, FilterItem> toAddMap = new LinkedHashMap<>();
      for (FilterItem item : filterItems) {
        toAddMap.put(item.getName(), item);
      }

      if (ArrayUtils.isNotEmpty(previous)) {
        for (FilterItem item : previous) {
          for (FilterItem newItem : filterItems) {
            if (StringUtils.equals(item.getName(), newItem.getName())) {
              toAddMap.remove(item.getName());
              break;
            }
          }
        }
      }

      if (MapUtils.isNotEmpty(toAddMap)) {
        FilterItem[] toAdd = toAddMap.values().toArray(new FilterItem[0]);
        FilterItem[] newFilters = ArrayUtils.addAll(previous, toAdd);
        filters.put(operatorType, newFilters);
      }

    } else {
      filters.put(operatorType, filterItems);
    }

    return filters;

  }

  default FilterItem[] getFilterItems(ConditionOperatorType operatorType, String... filterNames) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = getFilters();
    if(MapUtils.isNotEmpty(filters)) {
      List<FilterItem> result = new ArrayList<>();
      for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
        FilterItem[] filterItems = entry.getValue();

        if(ArrayUtils.isNotEmpty(filterItems)) {
          for (FilterItem filterItem : filterItems) {
            if (ArrayUtils.contains(filterNames, filterItem.getName())) {
              if (operatorType == null || operatorType == entry.getKey()) {
                result.add(filterItem);
              }
            }
          }
        }
      }

      if (CollectionUtils.isNotEmpty(result)) {
        return result.toArray(new FilterItem[0]);
      }

    }
    return null;
  }

  void removeFilterItem(ConditionOperatorType operatorType, String filterName);


  default FilterItem[] getFilterItems(@NotNull String type) {
    try {
      ConditionOperatorType operatorType = ConditionOperatorType.valueOf(type);
      return getFilterItems(operatorType);

    } catch (IllegalArgumentException e) {
      return null;
    }
  }

  default FilterItem[] getFilterItems(@NotNull ConditionOperatorType type) {
    return getFilters().get(type);
  }

  default FilterItem getFilterItem(ConditionOperatorType type, String name) {
    FilterItem[] items = getFilterItems(type);
    if(items != null) {
      for(FilterItem item : items) {
        if(item.getName().equals(name)) {
          return item;
        }
      }
    }
    return null;
  }

  default FilterItem getFilterItem(String name) {
    FilterItem[] items = getFilterItems(ConditionOperatorType.AND, name);
    if(items != null) {
      return items[0];
    }
    items = getFilterItems(ConditionOperatorType.OR, name);
    if(items != null) {
      return items[0];
    }
    return null;
  }

  default S filterSingular(ConditionOperatorType conditionOperatorType, QueryConditionType queryConditionType, String name, Object value) {

    if (!queryConditionType.isListCondition()) {

      Object filterValue = value;

      if (value instanceof Object[]) {
        filterValue = ((Object[]) value)[0];
      } else if (value instanceof Collection<?>) {
        filterValue = ((Collection<?>) value).iterator().next();
      }

      return filter(conditionOperatorType, queryConditionType, name, filterValue);

    }

    // not support
    throw new IllegalArgumentException("queryConditionType is not singular condition type");
  }

  default S filterPlural(ConditionOperatorType conditionOperatorType, QueryConditionType queryConditionType, String name, Object value) {
    if (queryConditionType.isListCondition()) {

      if (value instanceof Object[]) {
        return filter(conditionOperatorType, queryConditionType, name, value);
      } else if (value instanceof Collection<?>) {
        return filter(conditionOperatorType, queryConditionType, name, value);
      }

      // 값이 하나로 들어온 경우, 최소한 두개의 값으로 자동 변환한다.
      List<Object> list = new ArrayList<>();
      list.add(value);
      list.add(value);
      return filter(conditionOperatorType, queryConditionType, name, list);

    }

    // not support
    throw new IllegalArgumentException("queryConditionType is not list condition type");

  }


  default S filter(ConditionOperatorType conditionOperatorType, QueryConditionType queryConditionType, String name, Object value) {
    if (getFilters() == null) {
      setFilters(new LinkedHashMap<>());
    }

    FilterItem filterItem;

    if (queryConditionType.isListCondition()) {

      List<Object> values = new ArrayList<>();

      if (value instanceof Collection<?>) {
        values = new ArrayList<>((Collection<?>) value);
      } else if (value instanceof Object[]) {
        values = Arrays.asList((Object[]) value);
      } else {
        values.add(value);
      }

      filterItem = new FilterItem().withName(name).withValues(values.toArray(new Object[0])).withQueryConditionType(queryConditionType);
    } else {
      filterItem = new FilterItem().withName(name).withValue(value).withQueryConditionType(queryConditionType);
    }

    filter(conditionOperatorType, filterItem);

    return (S) this;
  }

  default void filter(ConditionOperatorType conditionOperatorType,
      FilterItem... filterItems) {
    if (filterItems != null && ArrayUtils.isNotEmpty(filterItems)) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = getFilters();
      if (filters.containsKey(conditionOperatorType)) {

        FilterItem[] items = filters.get(conditionOperatorType);
        List<FilterItem> itemList = new ArrayList<>();

        // 새로운 필터 아이템들의 이름 집합 생성
        Set<String> newFilterNames = new HashSet<>();
        for (FilterItem filterItem : filterItems) {
          newFilterNames.add(filterItem.getName());
        }

        // 기존 아이템 중 이름이 겹치지 않는 것만 추가
        for (FilterItem item : items) {
          if (!newFilterNames.contains(item.getName())) {
            itemList.add(item);
          }
        }

        // 새로운 필터 아이템들 모두 추가
        itemList.addAll(Arrays.asList(filterItems));

        filters.put(conditionOperatorType, itemList.toArray(new FilterItem[0]));
      } else {
        filters.put(conditionOperatorType, filterItems);
      }

      setFilters(filters);
    }

  }

  default S filterEquals(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.EQUAL, name, value);
  }

  default S filterNotEquals(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_EQUAL, name, value);
  }

  default S filterNullOrEquals(String name, Object value) {
    filter(ConditionOperatorType.AND, FilterItem.isNullOrEquals(name, value));
    return (S) this;
  }

  default S filterNullOrNotEquals(String name, Object value) {
    filter(ConditionOperatorType.AND, FilterItem.isNullOrNotEquals(name, value));
    return (S) this;
  }

  default S filterEqualsIgnoreCase(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.EQUAL_IGNORECASE, name, value);
  }

  default S filterNotEqualsIgnoreCase(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_EQUAL_IGNORECASE, name, value);
  }

  default S filterLike(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.LIKE, name, value);
  }

  default S filterNotLike(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_LIKE, name, value);
  }

  default S filterGreaterThan(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.GREATER, name, value);
  }

  default S filterGreaterThanOrEqual(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.GREATER_THAN_EQUAL, name, value);
  }

  default S filterNotGreaterThan(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_GREATER, name, value);
  }

  default S filterNotGreaterThanOrEqual(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_GREATER_THAN_EQUAL, name, value);
  }

  default S filterLessThan(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.LESS_THAN, name, value);
  }

  default S filterLessThanOrEqual(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.LESS_THAN_EQUAL, name, value);
  }

  default S filterNotLessThan(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_LESS_THAN, name, value);
  }

  default S filterNotLessThanOrEqual(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_LESS_THAN_EQUAL, name, value);
  }

  default S filterIn(String name, Object value) {
    return filterPlural(ConditionOperatorType.AND, QueryConditionType.IN, name, value);
  }

  default S filterNotIn(String name, Object value) {
    return filterPlural(ConditionOperatorType.AND, QueryConditionType.NOT_IN, name, value);
  }

  default S filterIsNull(String name) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NULL, name, null);
  }

  default S filterIsNotNull(String name) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_NULL, name, null);
  }

  default S filterStartWith(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.START_WITH, name, value);
  }

  default S filterEndWith(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.END_WITH, name, value);
  }

  default S filterNotStartWith(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_START_WITH, name, value);
  }

  default S filterNotEndWith(String name, Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.NOT_END_WITH, name, value);
  }

  default S filterBetween(String name, Object value) {
    return filterPlural(ConditionOperatorType.AND, QueryConditionType.BETWEEN, name, value);
  }

  default S filterNotBetween(String name, Object value) {
    return filterPlural(ConditionOperatorType.AND, QueryConditionType.NOT_BETWEEN, name, value);
  }

  default S filterIdEquals(Object value) {
    return filterSingular(ConditionOperatorType.AND, QueryConditionType.ID_EQUAL, "id", value);
  }

  default S filterOr(FilterItem... items) {
    filter(ConditionOperatorType.OR, items);
    return (S) this;
  }

  default S filterIsNullOrBlank(String name) {
    filter(ConditionOperatorType.OR, FilterItem.isNull(name), FilterItem.equals(name, ""));
    return (S) this;
  }

  default S filterAnd(FilterItem... items) {
    filter(ConditionOperatorType.AND, items);
    return (S) this;
  }

  /**
   * 쿼리 결과에 DISTINCT 를 적용한다.
   * OneToMany join 등으로 인한 중복 결과를 제거할 때 사용한다.
   */
  default S withDistinct() {
    if (this instanceof AbstractSearchForm<?> form) {
      form.setDistinct(true);
    }
    return (S) this;
  }

  /**
   * EXISTS 서브쿼리 필터를 추가한다.
   * 매핑 관계가 없는 엔티티 간에도 단일 쿼리로 존재 여부 필터링이 가능하다.
   *
   * <p>사용 예시:</p>
   * <pre>
   * // SyllabusSelection 중간 테이블을 통해 특정 Syllabus에 연결된 Selection만 필터링
   * searchForm.filterExists(
   *     SyllabusSelection.class, "selection.id", "id",
   *     FilterItem.equals("syllabus.id", syllabusId)
   * );
   * </pre>
   *
   * <p>생성되는 SQL:</p>
   * <pre>
   * WHERE EXISTS (SELECT 1 FROM T_SYLLABUS_SELECTION ss
   *              WHERE ss.SELECTION_ID = s.ID AND ss.SYLLABUS_ID = :val)
   * </pre>
   *
   * @param targetEntityClass 서브쿼리 대상 엔티티 클래스 (중간 테이블 등)
   * @param targetJoinPath    대상 엔티티에서 루트 엔티티를 참조하는 경로 (e.g. "selection.id")
   * @param rootJoinPath      루트 엔티티의 매칭 필드 (e.g. "id")
   * @param conditions        서브쿼리 내 추가 필터 조건 (FilterItem.equals(...) 등)
   * @return this
   */
  default S filterExists(Class<?> targetEntityClass, String targetJoinPath, String rootJoinPath, FilterItem... conditions) {
    if (this instanceof AbstractSearchForm<?> form) {
      form.getExistsFilters().add(new ExistsFilterItem(targetEntityClass, targetJoinPath, rootJoinPath, false, conditions));
    }
    return (S) this;
  }

  /**
   * NOT EXISTS 서브쿼리 필터를 추가한다.
   * filterExists 의 반대 조건으로, 대상 엔티티에 매칭되는 행이 없는 경우를 필터링한다.
   *
   * <p>사용 예시:</p>
   * <pre>
   * // 특정 Syllabus에 연결되지 않은 Selection만 필터링
   * searchForm.filterNotExists(
   *     SyllabusSelection.class, "selection.id", "id",
   *     FilterItem.equals("syllabus.id", syllabusId)
   * );
   * </pre>
   *
   * @param targetEntityClass 서브쿼리 대상 엔티티 클래스
   * @param targetJoinPath    대상 엔티티에서 루트 엔티티를 참조하는 경로
   * @param rootJoinPath      루트 엔티티의 매칭 필드
   * @param conditions        서브쿼리 내 추가 필터 조건
   * @return this
   */
  default S filterNotExists(Class<?> targetEntityClass, String targetJoinPath, String rootJoinPath, FilterItem... conditions) {
    if (this instanceof AbstractSearchForm<?> form) {
      form.getExistsFilters().add(new ExistsFilterItem(targetEntityClass, targetJoinPath, rootJoinPath, true, conditions));
    }
    return (S) this;
  }

  /**
   * 여러 EXISTS 서브쿼리 술어를 OR 로 결합하여 추가한다.
   *
   * <p>JOINED inheritance 처럼 "두 서브타입 중 하나에 매핑된 행" 을 찾을 때처럼,
   * 동일 의미를 가진 EXISTS 술어들을 OR 로 묶어야 하는 케이스를 위해 제공한다.</p>
   *
   * <p>사용 예시 (Admission 루트에 majorCurriculum 이 없고 Freshman / Transfer 서브타입에만 존재):</p>
   * <pre>
   * searchForm.filterExistsOr(
   *     new ExistsFilterItem(Freshman.class, "id", "id", false,
   *         FilterItem.equals("majorCurriculum.id", id)),
   *     new ExistsFilterItem(Transfer.class,  "id", "id", false,
   *         FilterItem.equals("majorCurriculum.id", id))
   * );
   * </pre>
   *
   * <p>생성되는 SQL:</p>
   * <pre>
   * WHERE (EXISTS (SELECT 1 FROM T_ADMISSION_FRESHMAN f
   *                WHERE f.ID = a.ID AND f.MAJOR_CURRICULUM_ID = ?)
   *     OR EXISTS (SELECT 1 FROM T_ADMISSION_TRANSFER t
   *                WHERE t.ID = a.ID AND t.MAJOR_CURRICULUM_ID = ?))
   * </pre>
   *
   * @param items OR 로 묶을 EXISTS 항목들 (각 항목 내부 negated 플래그도 그대로 적용된다)
   * @return this
   */
  default S filterExistsOr(ExistsFilterItem... items) {
    if (this instanceof AbstractSearchForm<?> form && ArrayUtils.isNotEmpty(items)) {
      form.getExistsFilterGroups().add(new ExistsFilterGroup(ConditionOperatorType.OR, items));
    }
    return (S) this;
  }

  /**
   * 여러 EXISTS 서브쿼리 술어를 AND 로 결합하여 추가한다.
   * 의미상 {@link #filterExists} 를 여러 번 호출한 것과 같지만, 그룹화된 것을 명시적으로 표현하고 싶을 때 사용한다.
   *
   * @param items AND 로 묶을 EXISTS 항목들
   * @return this
   */
  default S filterExistsAnd(ExistsFilterItem... items) {
    if (this instanceof AbstractSearchForm<?> form && ArrayUtils.isNotEmpty(items)) {
      form.getExistsFilterGroups().add(new ExistsFilterGroup(ConditionOperatorType.AND, items));
    }
    return (S) this;
  }

  static void mergeFilter(@NotNull ConditionOperatorType condition,
      @NotNull FilterItem item,
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters) {
    if(filters.containsKey(condition)) {
      FilterItem[] items = filters.get(condition);
      List<FilterItem> itemList = new ArrayList<>();
      for(FilterItem filterItem : items) {
        if (!filterItem.equals(item)) {
          itemList.add(filterItem);
        }
      }
      itemList.add(item);
      filters.put(condition, itemList.toArray(new FilterItem[0]));
    } else {
      filters.put(condition, new FilterItem[]{item});
    }
  }



}
