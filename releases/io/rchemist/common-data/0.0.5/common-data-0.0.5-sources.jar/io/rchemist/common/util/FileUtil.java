/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.data.AssetMetadata;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tika.Tika;
import org.apache.tika.mime.MimeTypes;
import org.mozilla.universalchardet.UniversalDetector;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class FileUtil {

  private static final String FILE_EXT_CODE = ".";

  private static final int MEGA_BYTE = 1024 * 1024;
  private static final int KILO_BYTE = 1024;
  private static final BigDecimal MEGA_DECIMAL = new BigDecimal(MEGA_BYTE, new MathContext(1, RoundingMode.HALF_UP));
  private static final BigDecimal KILO_DECIMAL = new BigDecimal(KILO_BYTE, new MathContext(1, RoundingMode.HALF_UP));
  private static final String INVALID_FILENAME_PATTERN = "[<>:\"/\\\\|?*\\x00-\\x1f\\x7f]";

  private static final Set<String> imageExtensions = new HashSet<>();

  static {
    // 이미지 확장자를 여기에 추가
    imageExtensions.add("jpg");
    imageExtensions.add("jpeg");
    imageExtensions.add("png");
    imageExtensions.add("gif");
    imageExtensions.add("bmp");
    imageExtensions.add("webp");
    imageExtensions.add("tiff");
  }



  public static File getFileFromMultiFile(MultipartFile mFile) throws IllegalStateException, IOException{
    File file = new File(mFile.getOriginalFilename());
    mFile.transferTo(file);
    return file;
  }

  public static MultipartFile getMultipartFileFromFile(File file) throws IOException{

    String contentType = Files.probeContentType(file.toPath());

    FileItem fileItem = new DiskFileItem("mainFile", contentType, false, file.getName(), (int) file.length(), file.getParentFile());
    // BUG-026 fix (0.0.10.F): FileInputStream 이 try-with-resources 밖이라 leak.
    try (FileInputStream fis = new FileInputStream(file)) {
      IOUtils.copy(fis, fileItem.getOutputStream());
    }
    return new MultipartFile() {
      @Override
      public String getName() {
        return fileItem.getName();
      }

      @Override
      public String getOriginalFilename() {
        return file.getName();
      }

      @Override
      public String getContentType() {
        return contentType;
      }

      @Override
      public boolean isEmpty() {
        return false;
      }

      @Override
      public long getSize() {
        return fileItem.getSize();
      }

      @Override
      public byte[] getBytes() throws IOException {
        return fileItem.get();
      }

      @Override
      public InputStream getInputStream() throws IOException {
        return fileItem.getInputStream();
      }

      @Override
      public void transferTo(File dest) throws IOException, IllegalStateException {
        FileCopyUtils.copy(this.getInputStream(), Files.newOutputStream(dest.toPath()));
      }
    };
  }

  public static File getFileFromInputStream(InputStream is, String fileName, String tempFilePath) throws IOException {
    String tempFilename = FilenameUtils.concat(tempFilePath, fileName);
    File tempFile = new File(tempFilename);
    if (!tempFile.getParentFile().exists()) {
      if (!tempFile.getParentFile().mkdirs()) {
        if (!tempFile.getParentFile().exists()) {
          throw new RuntimeException("Unable to create parent directories for file: " + tempFilename);
        }
      }
    }

    // BUG-026 fix (0.0.10.F): try-with-resources 누락 — copy 가 throw 시 stream leak.
    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tempFile))) {
      StreamUtils.copy(is, out);
    }
    return tempFile;
  }

  /**
   *
   * @param fileName
   * @param tempFilePath
   * @param text
   * @return
   */
  public static File getFileFromString(String fileName, @Nullable String tempFilePath, String text) throws IOException {
    if(StringUtils.isBlank(tempFilePath))
      tempFilePath = getTempFilePath();

    String tempFilename = FilenameUtils.concat(tempFilePath, fileName);

    // BUG-026 fix (0.0.10.F): try-with-resources 누락 — print 가 throw 시 writer leak.
    try (PrintWriter printWriter = new PrintWriter(new FileWriter(tempFilename))) {
      printWriter.print(text);
    }

    return new File(tempFilename);
  }

  /**
   * Temp directory 를 만들고 path 를 반환
   * @return
   */
  public static String getTempFilePath(){
    File tempFileDir = com.google.common.io.Files.createTempDir();
    return  tempFileDir + File.separator;
  }

  /**
   * 파일 압축 후 압축파일의 full path 리턴
   * @param archiveName 압축 파일 명
   * @param tempFilePath temp 폴더, nullable
   * @param archiveFiles 압축 대상 파일
   * @return
   */
  public static String compress(String archiveName, @Nullable String tempFilePath, Set<String> archiveFiles, int compressLevel) throws IOException {

    String archiveFilePath = getValidFilePath(tempFilePath, archiveName);

    // BUG-026 fix (0.0.10.F): try-with-resources 누락 — 예외 시 fos/zipOut/fis leak.
    try (FileOutputStream fos = new FileOutputStream(archiveFilePath);
         ZipOutputStream zipOut = new ZipOutputStream(fos)) {
      int bufferSize = 64 * 1024;

      zipOut.setLevel(compressLevel);

      byte[] bytes = new byte[bufferSize];

      for(String fileName : archiveFiles){
        try (FileInputStream fis = new FileInputStream(fileName)) {
          String zipFilePath = StringUtils.substringAfter(fileName, tempFilePath);
          zipOut.putNextEntry(new ZipEntry(zipFilePath));

          zipOut.setLevel(compressLevel);

          int length;
          while((length = fis.read(bytes)) >= 0){
            zipOut.write(bytes, 0, length);
          }

          zipOut.closeEntry();
        }
      }

      return getValidFilePath(tempFilePath, archiveName);
    }catch(IOException e){

      File failedFile = new File(archiveFilePath);

      if(failedFile.exists())
        failedFile.delete();

      throw e;
    }
  }

  private static String getValidFilePath(String filePath, String fileName){
    String separator = getSystemDirectorySeparator();
    if(!filePath.endsWith(separator))
      filePath = filePath + separator;

    /**
     * fileName 에 이미 filePath 가 포함되어 있다면
     */
    if(filePath.length() > 1 &&       // filePath 가 "/" 등이 아니고
        filePath.length() < fileName.length() && // fileName 이 filePath 보다 길이가 길고
        StringUtils.equals(filePath, StringUtils.left(fileName, filePath.length()))){
      return fileName;
    }

    return filePath + fileName;

  }

  private static String getSystemDirectorySeparator(){
    return com.google.common.io.Files.createTempDir().separator;
  }


  /**
   * File path 가 "." 으로 시작하면 skip 대상이다
   * @param entry
   * @return
   */
  public static boolean isNotFile(ZipEntry entry) {
    if(entry.isDirectory())
      return true;

    String filePathName = entry.getName();

    // filePath에 "/" 가 있는 경우 .gitignore 와 같은 불필요한 파일들을 제거한다
    if(filePathName.contains("/")){
      String[] checkFileArr = StringUtils.split(filePathName,"/");
      return checkFileArr[checkFileArr.length - 1].startsWith(".");
    }

    return false;
  }

  /**
   * File upload 를 위한 temp path location
   * @return
   */
  public static String getTempFilePathLocation(){
    return getTempFilePath();
  }

  /**
   * File 압축 해제를 위해 InputStream 으로 반환
   * @param zipFile
   * @param entry
   * @return
   */
  public static InputStream getInputStreamFromZipEntry(ZipFile zipFile, ZipEntry entry) {
    try {
      return zipFile.getInputStream(entry);
    } catch (IOException e) {
      ExceptionUtil.printStackTrace(e);
    }
    return null;
  }

  public static void deleteRecursive(File file){
    if(file.isFile()){
      file.delete();
    }else{
      try{
        File[] folders = file.listFiles();

        for(int i = 0; i < folders.length; i++){
          if(folders[i].isFile()){
            folders[i].delete();
          }else{
            deleteRecursive(folders[i]);
          }
          folders[i].delete();
        }
        file.delete();
      }catch (Exception e){
        ExceptionUtil.printStackTrace(e);
        // do nothing
      }
    }
  }

  public static String getProperFileName(String fileName){
    if(StringUtils.isEmpty(fileName))
      return null;

    return fileName.replace("^\\.+", "").replaceAll("[\\\\/:*?\"<>|]", "");
  }

  /**
   * Asset metadata - width, height 구하기
   * @param artifactStream
   * @return
   */
  public static AssetMetadata getImageMetadata(InputStream artifactStream) {
    try {
      AssetMetadata metadata = new AssetMetadata();
      ImageInputStream iis = ImageIO.createImageInputStream(artifactStream);
      Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);
      if (readers.hasNext()) {
        ImageReader reader = readers.next();
        reader.setInput(iis, true);
        metadata.setWidth(reader.getWidth(0));
        metadata.setHeight(reader.getHeight(0));
      }
      return metadata;
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }

  public static String getMimeType(File file) {
    Tika tika = new Tika();
    try {
      return tika.detect(file);
    } catch (IOException e) {
      e.printStackTrace();
      return MimeTypes.OCTET_STREAM;
    }
  }

  public static String getMimeType(URL url) {
    Tika tika = new Tika();
    try {
      return tika.detect(url);
    } catch (IOException e) {
      e.printStackTrace();
      return MimeTypes.OCTET_STREAM;
    }
  }

  public static String getMimeType(String fileName) {
    Tika tika = new Tika();
    try {
      return tika.detect(fileName);
    }catch (Exception e){
      return MimeTypes.OCTET_STREAM;
    }
  }

  public static String getMimeType(InputStream inputStream) {
    Tika tika = new Tika();
    try {
      return tika.detect(inputStream);
    } catch (IOException e) {
      e.printStackTrace();
      return MimeTypes.OCTET_STREAM;
    }
  }

  public static String getFileExtension(String fileName) {
    if(StringUtils.isEmpty(fileName) || !StringUtils.contains(fileName, FILE_EXT_CODE))
      return null;
    return StringUtils.substringAfterLast(fileName, FILE_EXT_CODE);
  }

  public static String getApproximateFileSize(int size){
    if(size == 0)
      return "";

    DecimalFormat df = new DecimalFormat("0.0");

    if(size > MEGA_BYTE){
      return df.format(size / MEGA_DECIMAL.doubleValue()) + "M";
    }else{
      return df.format(size / KILO_DECIMAL.doubleValue()) + "K";
    }
  }

  public static Charset getFileEncodingType(File file){
    Charset charset = null;
    byte[] buf = new byte[4096];

    try (FileInputStream fis = new FileInputStream(file)){
      UniversalDetector detector = new UniversalDetector(null);
      int read = 0;
      while((read = fis.read(buf)) > 0 && !detector.isDone()){
        detector.handleData(buf, 0, read);
      }
      detector.dataEnd();

      String encoding = detector.getDetectedCharset();
      if(encoding != null){
        charset = Charset.forName(encoding);
      }
    }catch (Exception e){
      throw new RuntimeException(e);
    }

    return charset;
  }

  public static String sanitizeFilename(String inputName, boolean startWithSlash) {
    String sanitizeFileName = inputName.replaceAll(INVALID_FILENAME_PATTERN, "_");
    if(startWithSlash)
      sanitizeFileName = "/" + sanitizeFileName;

    return sanitizeFileName;
  }

  /**
   * 파일명이 이미지 파일인지 확인하는 메소드
   * @param fileName 확장자를 포함한 파일명
   * @return 이미지 파일이면 true, 아니면 false
   */
  public static boolean isImageFile(String fileName) {
    if (fileName == null || fileName.isEmpty() || StringUtils.isEmpty(getFileExtension(fileName))) {
      return false;
    }

    // 확장자 추출
    String extension = Objects.requireNonNull(getFileExtension(fileName)).toLowerCase();

    // 이미지 확장자인지 확인
    return imageExtensions.contains(extension);
  }


}
