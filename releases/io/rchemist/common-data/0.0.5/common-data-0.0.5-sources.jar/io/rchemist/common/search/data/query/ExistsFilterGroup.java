/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import java.io.Serializable;
import java.util.Arrays;
import lombok.Getter;

/**
 * 여러 {@link ExistsFilterItem} 을 단일 논리 연산자(AND/OR) 로 묶기 위한 그룹.
 *
 * <p>기본 {@code filterExists()} 는 EXISTS 술어를 항상 AND 로 결합한다.
 * JOINED inheritance 처럼 "두 서브타입 중 하나에 매핑되어 있는 행" 을 찾을 때처럼
 * EXISTS 들을 OR 로 묶어야 하는 경우 본 그룹을 사용한다.</p>
 *
 * <p>사용 예시:</p>
 * <pre>
 * searchForm.filterExistsOr(
 *     new ExistsFilterItem(Freshman.class, "id", "id", false,
 *         FilterItem.equals("majorCurriculum.id", id)),
 *     new ExistsFilterItem(Transfer.class,  "id", "id", false,
 *         FilterItem.equals("majorCurriculum.id", id))
 * );
 * </pre>
 *
 * <p>생성 SQL:</p>
 * <pre>
 * WHERE (EXISTS (SELECT 1 FROM T_ADMISSION_FRESHMAN f
 *                WHERE f.ID = a.ID AND f.MAJOR_CURRICULUM_ID = ?)
 *     OR EXISTS (SELECT 1 FROM T_ADMISSION_TRANSFER  t
 *                WHERE t.ID = a.ID AND t.MAJOR_CURRICULUM_ID = ?))
 * </pre>
 */
@Getter
public class ExistsFilterGroup implements Serializable {

  /** 그룹 내부 EXISTS 항목들을 결합하는 연산자 (AND / OR). */
  private final ConditionOperatorType operator;

  /** 그룹에 포함된 EXISTS 서브쿼리 항목들. */
  private final ExistsFilterItem[] items;

  public ExistsFilterGroup(ConditionOperatorType operator, ExistsFilterItem... items) {
    this.operator = operator;
    this.items = items;
  }

  @Override
  public String toString() {
    return "ExistsGroup{" + operator + ", " + Arrays.toString(items) + '}';
  }

}
