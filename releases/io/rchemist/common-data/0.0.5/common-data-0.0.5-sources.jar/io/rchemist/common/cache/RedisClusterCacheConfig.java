/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.rchemist.common.cache.RedisClusterCacheConfig.RedisClusterConfigEnabled;
import io.rchemist.common.configuration.type.RedisCacheConfigType;
import java.time.Duration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Conditional(RedisClusterConfigEnabled.class)
@Configuration
public class RedisClusterCacheConfig {

  @Value("${spring.data.redis.cluster.port:6379}")
  public int clusterPort;

  @Value("${spring.data.redis.cluster.host:localhost}")
  public String clusterHost;

  @Value("${spring.data.redis.password:}")
  public String password;

  @Value("${spring.data.redis.ssl:false}")
  public boolean useSsl;

  @Value("${spring.data.redis.timeout:30000}")
  private long timeout;

  @Value("${spring.data.redis.connect-timeout:3000}")
  private long connectTimeout;

  static class RedisClusterConfigEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(context.getEnvironment().getProperty("spring.redis.mode"), "SINGLE");
      config = config.toUpperCase();

      try {
        RedisCacheConfigType configType = RedisCacheConfigType.valueOf(config);

        return configType.equals(RedisCacheConfigType.CLUSTER);
      }catch (Exception ex) {
        return false;
      }
    }
  }

  @Bean
  public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
    RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setValueSerializer(new StringRedisSerializer());
    redisTemplate.setConnectionFactory(connectionFactory);
    return redisTemplate;
  }

  @Bean
  public RedisConnectionFactory redisConnectionFactory() {
    LettuceClientConfiguration.LettuceClientConfigurationBuilder lettuceConfigBuilder = LettuceClientConfiguration.builder()
        .commandTimeout(Duration.ofMillis(timeout))
        .clientOptions(LettuceClientOptionsFactory.defaultClientOptions(connectTimeout));
    if(useSsl) lettuceConfigBuilder.useSsl();

    RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();
    redisClusterConfiguration.clusterNode(clusterHost, clusterPort);
    redisClusterConfiguration.setPassword(StringUtils.isNotEmpty(password) ? RedisPassword.of(password) : RedisPassword.none());
    return new LettuceConnectionFactory(redisClusterConfiguration, lettuceConfigBuilder.build());
  }



}
