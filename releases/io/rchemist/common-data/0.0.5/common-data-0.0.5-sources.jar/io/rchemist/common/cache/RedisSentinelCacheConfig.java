/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.lettuce.core.ReadFrom;
import io.rchemist.common.cache.RedisSentinelCacheConfig.RedisSentinelConfigEnabled;
import io.rchemist.common.configuration.type.RedisCacheConfigType;
import java.time.Duration;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis Sentinel 토폴로지용 Lettuce 연결. {@code spring.redis.mode=SENTINEL} 일 때 활성화된다.
 *
 * <p>K8s 환경 (Bitnami helm chart 의 통합 sentinel) 에서 split-brain 으로 인한
 * connection-level 무작위 라우팅 (이슈 #10) 을 방지하기 위해 {@link ReadFrom#MASTER} 강제.
 *
 * <p>설정 예 (application.yml):
 * <pre>
 * spring:
 *   redis:
 *     mode: SENTINEL
 *   data:
 *     redis:
 *       database: 6
 *       password: ${REDIS_PASSWORD}
 *       sentinel:
 *         master: mymaster
 *         nodes:
 *           - host-a:26379
 *           - host-b:26379
 *           - host-c:26379
 * </pre>
 *
 * <p>{@code spring.data.redis.sentinel.nodes} 는 Spring Boot 자체 RedisProperties 와 충돌 없이
 * 사용 가능 — 본 클래스가 직접 파싱한다 (YAML list 는 콤마 join 으로 도착).
 */
@Conditional(RedisSentinelConfigEnabled.class)
@Configuration
public class RedisSentinelCacheConfig {

  @Value("${spring.data.redis.sentinel.master:mymaster}")
  private String masterName;

  @Value("${spring.data.redis.sentinel.nodes:}")
  private List<String> sentinelNodes;

  @Value("${spring.data.redis.sentinel.password:}")
  private String sentinelPassword;

  @Value("${spring.data.redis.password:}")
  private String password;

  @Value("${spring.data.redis.database:0}")
  private int database;

  @Value("${spring.data.redis.timeout:30s}")
  private Duration timeout;

  @Value("${spring.data.redis.connect-timeout:3s}")
  private Duration connectTimeout;

  static class RedisSentinelConfigEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(
          context.getEnvironment().getProperty("spring.redis.mode"), "SINGLE");
      config = config.toUpperCase();

      try {
        return RedisCacheConfigType.valueOf(config).equals(RedisCacheConfigType.SENTINEL);
      } catch (Exception ex) {
        return false;
      }
    }
  }

  @Bean
  public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
    RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setValueSerializer(new StringRedisSerializer());
    redisTemplate.setConnectionFactory(connectionFactory);
    return redisTemplate;
  }

  @Bean
  public RedisConnectionFactory redisConnectionFactory() {
    if (sentinelNodes == null || sentinelNodes.isEmpty()) {
      throw new IllegalStateException(
          "spring.redis.mode=SENTINEL 인데 spring.data.redis.sentinel.nodes 가 비어있습니다");
    }

    RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration();
    sentinelConfig.master(masterName);
    for (String node : sentinelNodes) {
      String trimmed = node.trim();
      if (trimmed.isEmpty()) {
        continue;
      }
      int colon = trimmed.lastIndexOf(':');
      if (colon < 0) {
        throw new IllegalStateException(
            "spring.data.redis.sentinel.nodes 항목은 host:port 형식이어야 합니다: " + node);
      }
      String host = trimmed.substring(0, colon);
      int port = Integer.parseInt(trimmed.substring(colon + 1));
      sentinelConfig.sentinel(host, port);
    }
    sentinelConfig.setDatabase(database);
    if (StringUtils.isNotEmpty(password)) {
      sentinelConfig.setPassword(RedisPassword.of(password));
    }
    if (StringUtils.isNotEmpty(sentinelPassword)) {
      sentinelConfig.setSentinelPassword(RedisPassword.of(sentinelPassword));
    }

    LettuceClientConfiguration.LettuceClientConfigurationBuilder lettuceConfigBuilder =
        LettuceClientConfiguration.builder()
            .commandTimeout(timeout)
            .clientOptions(LettuceClientOptionsFactory.defaultClientOptions(connectTimeout))
            .readFrom(ReadFrom.MASTER);

    return new LettuceConnectionFactory(sentinelConfig, lettuceConfigBuilder.build());
  }
}
