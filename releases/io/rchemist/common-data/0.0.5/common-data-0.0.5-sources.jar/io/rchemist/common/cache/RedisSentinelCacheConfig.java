/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.lettuce.core.ReadFrom;
import io.rchemist.common.cache.RedisSentinelCacheConfig.RedisSentinelConfigEnabled;
import io.rchemist.common.configuration.type.RedisCacheConfigType;
import java.time.Duration;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis Sentinel 토폴로지용 Lettuce 연결. {@code spring.redis.mode=SENTINEL} 일 때 활성화된다.
 *
 * <p>K8s 환경 (Bitnami helm chart 의 통합 sentinel) 에서 split-brain 으로 인한
 * connection-level 무작위 라우팅 (이슈 #10) 을 방지하기 위해 {@link ReadFrom#MASTER} 강제.
 *
 * <p>설정 예 (application.yml — YAML list / comma-string 둘 다 지원):
 * <pre>
 * spring:
 *   redis:
 *     mode: SENTINEL
 *   data:
 *     redis:
 *       database: 6
 *       password: ${REDIS_PASSWORD}
 *       timeout: 3s
 *       connect-timeout: 2s
 *       sentinel:
 *         master: mymaster
 *         nodes:                    # YAML list 또는 comma-string 둘 다 OK
 *           - host-a:26379
 *           - host-b:26379
 *           - host-c:26379
 * </pre>
 *
 * <p>Spring Boot 의 {@link RedisProperties} 를 직접 주입받아 sentinel 좌표를 파싱한다.
 * {@code @Value} 단일 key 바인딩 한계 (YAML list 가 {@code nodes[0]}, {@code nodes[1]} 로
 * flatten 되어 {@code nodes} 단일 key 가 존재하지 않음) 를 회피.
 */
@Conditional(RedisSentinelConfigEnabled.class)
@Configuration
public class RedisSentinelCacheConfig {

  private static final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(30);
  private static final Duration DEFAULT_CONNECT_TIMEOUT = Duration.ofSeconds(3);

  private final RedisProperties redisProperties;

  public RedisSentinelCacheConfig(RedisProperties redisProperties) {
    this.redisProperties = redisProperties;
  }

  static class RedisSentinelConfigEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(
          context.getEnvironment().getProperty("spring.redis.mode"), "SINGLE");
      config = config.toUpperCase();

      try {
        return RedisCacheConfigType.valueOf(config).equals(RedisCacheConfigType.SENTINEL);
      } catch (Exception ex) {
        return false;
      }
    }
  }

  @Bean
  public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {
    RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
    redisTemplate.setKeySerializer(new StringRedisSerializer());
    redisTemplate.setValueSerializer(new StringRedisSerializer());
    redisTemplate.setConnectionFactory(connectionFactory);
    return redisTemplate;
  }

  @Bean
  public RedisConnectionFactory redisConnectionFactory() {
    RedisProperties.Sentinel sentinel = redisProperties.getSentinel();
    if (sentinel == null) {
      throw new IllegalStateException(
          "spring.redis.mode=SENTINEL 인데 spring.data.redis.sentinel.* 설정이 없습니다");
    }
    List<String> nodes = sentinel.getNodes();
    if (nodes == null || nodes.isEmpty()) {
      throw new IllegalStateException(
          "spring.redis.mode=SENTINEL 인데 spring.data.redis.sentinel.nodes 가 비어있습니다");
    }

    RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration();
    sentinelConfig.master(StringUtils.defaultIfBlank(sentinel.getMaster(), "mymaster"));
    for (String node : nodes) {
      String trimmed = node == null ? "" : node.trim();
      if (trimmed.isEmpty()) {
        continue;
      }
      int colon = trimmed.lastIndexOf(':');
      if (colon < 0) {
        throw new IllegalStateException(
            "spring.data.redis.sentinel.nodes 항목은 host:port 형식이어야 합니다: " + node);
      }
      String host = trimmed.substring(0, colon);
      int port = Integer.parseInt(trimmed.substring(colon + 1));
      sentinelConfig.sentinel(host, port);
    }
    sentinelConfig.setDatabase(redisProperties.getDatabase());
    if (StringUtils.isNotEmpty(redisProperties.getPassword())) {
      sentinelConfig.setPassword(RedisPassword.of(redisProperties.getPassword()));
    }
    if (StringUtils.isNotEmpty(sentinel.getPassword())) {
      sentinelConfig.setSentinelPassword(RedisPassword.of(sentinel.getPassword()));
    }

    Duration timeout = redisProperties.getTimeout() != null
        ? redisProperties.getTimeout() : DEFAULT_TIMEOUT;
    Duration connectTimeout = redisProperties.getConnectTimeout() != null
        ? redisProperties.getConnectTimeout() : DEFAULT_CONNECT_TIMEOUT;

    LettuceClientConfiguration.LettuceClientConfigurationBuilder lettuceConfigBuilder =
        LettuceClientConfiguration.builder()
            .commandTimeout(timeout)
            .clientOptions(LettuceClientOptionsFactory.defaultClientOptions(connectTimeout))
            .readFrom(ReadFrom.MASTER);

    return new LettuceConnectionFactory(sentinelConfig, lettuceConfigBuilder.build());
  }
}
