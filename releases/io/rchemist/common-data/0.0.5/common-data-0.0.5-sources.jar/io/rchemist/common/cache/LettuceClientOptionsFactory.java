/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.ClientOptions.DisconnectedBehavior;
import io.lettuce.core.SocketOptions;
import io.lettuce.core.TimeoutOptions;
import java.time.Duration;

/**
 * 3종 Redis*CacheConfig (Standalone/Cluster/MasterReplica) 가 동일한 Lettuce 견고화 옵션
 * 묶음을 공유하기 위한 헬퍼. K8s 환경에서 Redis Pod 재기동/IP 변경 시 60s 행을 방지한다.
 *
 * <p>적용 옵션:
 * <ul>
 *   <li>{@link DisconnectedBehavior#REJECT_COMMANDS} — 연결 끊긴 동안 커맨드를 큐잉하지 않고 즉시 거부</li>
 *   <li>{@code autoReconnect=true} — 연결 복구 시 자동 재접속</li>
 *   <li>{@code SocketOptions.keepAlive=true} — TCP keepalive 로 사 connection 빠른 검출</li>
 *   <li>{@link TimeoutOptions#enabled(Duration)} — 모든 커맨드에 timeout 적용</li>
 * </ul>
 */
final class LettuceClientOptionsFactory {

  private LettuceClientOptionsFactory() {}

  static ClientOptions defaultClientOptions(Duration connectTimeout) {
    SocketOptions socketOptions = SocketOptions.builder()
        .connectTimeout(connectTimeout)
        .keepAlive(true)
        .build();

    return ClientOptions.builder()
        .disconnectedBehavior(DisconnectedBehavior.REJECT_COMMANDS)
        .autoReconnect(true)
        .socketOptions(socketOptions)
        .timeoutOptions(TimeoutOptions.enabled(connectTimeout))
        .build();
  }
}
