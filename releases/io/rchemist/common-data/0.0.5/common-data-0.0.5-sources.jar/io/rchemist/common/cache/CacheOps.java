/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import javax.cache.Cache;
import lombok.extern.slf4j.Slf4j;

/**
 * Race-safe wrappers around {@link javax.cache.Cache} access.
 *
 * <p>JCache spec 은 {@code containsKey(k)} 와 {@code get(k)} 사이에 원자성을 보장하지 않는다.
 * 두 호출 사이에 TTL 만료 / 다른 노드의 remove / Redisson eviction race 가 끼면
 * {@code containsKey=true} 직후 {@code get=null} 이 관측 가능하다. 추가로 Redisson 백엔드는
 * 네트워크 / Redis 장애 시 {@code RuntimeException} 을 던질 수 있다.
 *
 * <p>본 유틸은 이 두 가지 실패 모드를 일관되게 흡수한다:
 * <ul>
 *   <li>cache miss / null 반환 → {@code null}</li>
 *   <li>get / put / remove 호출 중 예외 → {@code warn} 로그 + null/no-op</li>
 * </ul>
 *
 * <p>호출부는 더 이상 {@code containsKey} 를 사용하지 말고 {@link #getOrNull} 또는
 * {@link #getOrCompute} 로 통일한다.
 */
@Slf4j
public final class CacheOps {

  private CacheOps() {}

  /**
   * Race-safe single read. cache 또는 key 가 null 이거나, 캐시 miss, 또는 백엔드 예외 시
   * 모두 {@code null} 을 반환한다.
   */
  public static <V> V getOrNull(Cache<String, V> cache, String key) {
    if (cache == null || key == null) {
      return null;
    }
    try {
      return cache.get(key);
    } catch (Exception e) {
      log.warn("cache read failed cache={} key={}", cacheName(cache), key, e);
      return null;
    }
  }

  /**
   * Read-through. cache hit + non-null 이면 그 값을, 그 외 (miss / null / 예외) 에는
   * {@code loader} 를 호출해 계산하고 결과를 {@link #putQuietly} 로 저장 후 반환한다.
   *
   * <p>{@code loader} 가 throw 한 checked exception 은 그대로 호출자에게 전파된다.
   */
  public static <V, E extends Exception> V getOrCompute(
      Cache<String, V> cache, String key, ThrowingSupplier<V, E> loader) throws E {
    V cached = getOrNull(cache, key);
    if (cached != null) {
      return cached;
    }
    V computed = loader.get();
    putQuietly(cache, key, computed);
    return computed;
  }

  /**
   * Race-safe put. cache / key / value 가 null 이면 no-op. 백엔드 예외는 {@code warn} 로그만
   * 남기고 삼킨다 (caller 가 추가로 처리할 필요 없음).
   */
  public static <V> void putQuietly(Cache<String, V> cache, String key, V value) {
    if (cache == null || key == null || value == null) {
      return;
    }
    try {
      cache.put(key, value);
    } catch (Exception e) {
      log.warn("cache put failed cache={} key={}", cacheName(cache), key, e);
    }
  }

  /**
   * Race-safe remove (invalidate). cache / key null 또는 미존재 키 모두 no-op. 백엔드 예외는
   * {@code warn} 로그만 남기고 삼킨다.
   *
   * <p>{@code containsKey + get + mutate + put} 안티패턴 (다중 노드에서 lost update 발생) 대신
   * 본 메서드로 invalidate 후 다음 read 가 재구성하게 하는 것을 권장한다.
   */
  public static void invalidateQuietly(Cache<String, ?> cache, String key) {
    if (cache == null || key == null) {
      return;
    }
    try {
      cache.remove(key);
    } catch (Exception e) {
      log.warn("cache invalidate failed cache={} key={}", cacheName(cache), key, e);
    }
  }

  private static String cacheName(Cache<?, ?> cache) {
    try {
      return cache.getName();
    } catch (Exception e) {
      return "<unknown>";
    }
  }

  /**
   * Checked exception 을 허용하는 supplier. {@link java.util.function.Supplier} 가
   * checked exception 을 throw 할 수 없어 service 계층의 {@code throws ErrorTypeException}
   * 시그니처와 호환되지 않는 문제를 해소한다.
   */
  @FunctionalInterface
  public interface ThrowingSupplier<V, E extends Exception> {
    V get() throws E;
  }
}
