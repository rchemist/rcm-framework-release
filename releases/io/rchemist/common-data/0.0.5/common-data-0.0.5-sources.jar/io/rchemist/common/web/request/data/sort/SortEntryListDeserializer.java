/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.criteria.JoinType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort.Direction;

/**
 * List<SortEntry>를 역직렬화하는 커스텀 Deserializer
 *
 * 지원하는 JSON 형식:
 *
 * 1. 새로운 배열 형식 (권장):
 * [
 *   {
 *     "fieldName": "subject.type",
 *     "sortInfo": {
 *       "type": "priority",
 *       "priorityValue": "MAJOR_MANDATORY",
 *       "direction": "DESC",
 *       "joinType": "LEFT"
 *     }
 *   }
 * ]
 *
 * 2. 기존 객체 형식 (하위 호환성):
 * {
 *   "createdAt": "DESC",
 *   "subject.type": {
 *     "priorityValue": "MAJOR_MANDATORY",
 *     "direction": "ASC"
 *   }
 * }
 */
@Slf4j
public class SortEntryListDeserializer extends JsonDeserializer<List<SortEntry>> {

    @Override
    public List<SortEntry> getNullValue(DeserializationContext ctxt) {
        return new ArrayList<>();
    }

    @Override
    public List<SortEntry> deserialize(JsonParser parser, DeserializationContext context)
            throws IOException, JsonProcessingException {

        List<SortEntry> result = new ArrayList<>();
        JsonNode rootNode = parser.getCodec().readTree(parser);

        if (rootNode == null) {
            log.debug("sorts field is null, returning empty list");
            return result;
        }

        if (rootNode.isArray()) {
            // 새로운 배열 형식: [{"fieldName": "...", "sortInfo": {...}}]
            deserializeArrayFormat(rootNode, result);

        } else if (rootNode.isObject()) {
            // 기존 객체 형식: {"fieldName": "DESC"} 또는 {"fieldName": {...}}
            deserializeObjectFormat(rootNode, result);

        } else {
            log.warn("Unsupported sorts format: {}, returning empty list", rootNode.getNodeType());
        }

        log.debug("Deserialized {} sort entries", result.size());
        return result;
    }

    /**
     * 새로운 배열 형식 역직렬화
     * [{"fieldName": "...", "sortInfo": {...}}]
     *
     * 평면 형식(flat) 호환:
     * [{"field": "...", "direction": "DESC", "type"?: ..., "joinType"?: ..., "nullsFirst"?: ..., "priorityValue"?: ...}]
     * (@rchemist/listgrid 0.2.x SearchForm#toJSON 이 보내는 형태. fieldName/sortInfo 중첩이 아니라
     *  SortInfo 속성이 항목 최상위에 평면으로 실려온다. fieldName 이 없을 때만 적용한다.)
     */
    private void deserializeArrayFormat(JsonNode arrayNode, List<SortEntry> result) {
        for (JsonNode itemNode : arrayNode) {
            try {
                JsonNode fieldNameNode = itemNode.get("fieldName");
                JsonNode sortInfoNode = itemNode.get("sortInfo");

                if (fieldNameNode == null || !fieldNameNode.isTextual()) {
                    // 평면 형식 호환: {"field": "...", "direction": "..."} (SortInfo 속성은 항목 최상위에 위치)
                    JsonNode flatFieldNode = itemNode.get("field");
                    if (flatFieldNode != null && flatFieldNode.isTextual()) {
                        String flatFieldName = flatFieldNode.asText();
                        result.add(new SortEntry(flatFieldName, parseSortInfoObject(flatFieldName, itemNode)));
                        continue;
                    }
                    log.warn("Missing or invalid fieldName in array item, skipping");
                    continue;
                }

                String fieldName = fieldNameNode.asText();
                SortInfo sortInfo;

                if (sortInfoNode != null && sortInfoNode.isObject()) {
                    sortInfo = parseSortInfoObject(fieldName, sortInfoNode);
                } else {
                    // sortInfo가 없는 경우 기본값으로 DESC
                    log.warn("Missing sortInfo for field '{}', using default DESC", fieldName);
                    sortInfo = new NormalSortInfo(Direction.DESC);
                }

                result.add(new SortEntry(fieldName, sortInfo));

            } catch (Exception e) {
                log.warn("Failed to parse array item: {}", e.getMessage());
            }
        }
    }

    /**
     * 기존 객체 형식 역직렬화 (하위 호환성)
     * {"fieldName": "DESC"} 또는 {"fieldName": {...}}
     */
    private void deserializeObjectFormat(JsonNode objectNode, List<SortEntry> result) {
        Iterator<java.util.Map.Entry<String, JsonNode>> fields = objectNode.fields();

        while (fields.hasNext()) {
            java.util.Map.Entry<String, JsonNode> entry = fields.next();
            String fieldName = entry.getKey();
            JsonNode valueNode = entry.getValue();

            try {
                SortInfo sortInfo = parseSortInfoFromLegacy(fieldName, valueNode);
                result.add(new SortEntry(fieldName, sortInfo));
            } catch (Exception e) {
                log.warn("Failed to parse sort info for field '{}': {}", fieldName, e.getMessage());
                result.add(new SortEntry(fieldName, new NormalSortInfo(Direction.DESC)));
            }
        }
    }

    /**
     * 새로운 형식의 SortInfo 객체 파싱
     */
    private SortInfo parseSortInfoObject(String fieldName, JsonNode sortInfoNode) {
        JsonNode typeNode = sortInfoNode.get("type");
        JsonNode directionNode = sortInfoNode.get("direction");
        JsonNode joinTypeNode = sortInfoNode.get("joinType");
        JsonNode nullsFirstNode = sortInfoNode.get("nullsFirst");

        String type = typeNode != null ? typeNode.asText() : null;
        Direction direction = parseDirection(directionNode, Direction.DESC);
        JoinType joinType = parseJoinType(joinTypeNode);
        Boolean nullsFirst = nullsFirstNode != null ? nullsFirstNode.asBoolean() : null;

        // 우선순위 정렬인 경우
        if ("priority".equals(type)) {
            JsonNode priorityValueNode = sortInfoNode.get("priorityValue");
            if (priorityValueNode == null) {
                log.warn("priorityValue is required for priority sort on field '{}', using normal sort", fieldName);
                return new NormalSortInfo(direction, joinType, nullsFirst);
            }

            Object priorityValue = extractPriorityValue(priorityValueNode);

            if (joinType != null && nullsFirst != null) {
                return new PrioritySortInfo(priorityValue, direction, joinType, nullsFirst);
            } else if (joinType != null) {
                return new PrioritySortInfo(priorityValue, direction, joinType);
            } else {
                return new PrioritySortInfo(priorityValue, direction);
            }
        }

        // 일반 정렬
        if (joinType != null && nullsFirst != null) {
            return new NormalSortInfo(direction, joinType, nullsFirst);
        } else if (joinType != null) {
            return new NormalSortInfo(direction, joinType);
        } else {
            return new NormalSortInfo(direction);
        }
    }

    /**
     * 기존 형식의 SortInfo 파싱 (하위 호환성)
     */
    private SortInfo parseSortInfoFromLegacy(String fieldName, JsonNode valueNode) {
        if (valueNode.isTextual()) {
            // 일반 정렬: "ASC" 또는 "DESC"
            return parseNormalSort(valueNode.asText());

        } else if (valueNode.isObject()) {
            // 객체인 경우 type이나 priorityValue로 구분
            JsonNode typeNode = valueNode.get("type");
            JsonNode priorityValueNode = valueNode.get("priorityValue");
            JsonNode directionNode = valueNode.get("direction");

            if (priorityValueNode != null || "priority".equals(typeNode != null ? typeNode.asText() : null)) {
                // 우선순위 정렬
                return parsePrioritySort(fieldName, valueNode);
            } else {
                // 일반 정렬 (joinType, nullsFirst 포함 가능)
                return parseExtendedNormalSort(valueNode);
            }

        } else {
            log.warn("Unsupported sort value type for field '{}': {}", fieldName, valueNode.getNodeType());
            return new NormalSortInfo(Direction.DESC);
        }
    }

    /**
     * 일반 정렬 파싱 (문자열)
     */
    private NormalSortInfo parseNormalSort(String directionString) {
        if (StringUtils.isBlank(directionString)) {
            return new NormalSortInfo(Direction.DESC);
        }

        try {
            Direction direction = Direction.valueOf(directionString.toUpperCase().trim());
            return new NormalSortInfo(direction);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid direction string '{}', using DESC as default", directionString);
            return new NormalSortInfo(Direction.DESC);
        }
    }

    /**
     * 확장된 일반 정렬 파싱 (joinType, nullsFirst 포함)
     */
    private NormalSortInfo parseExtendedNormalSort(JsonNode objectNode) {
        Direction direction = parseDirection(objectNode.get("direction"), Direction.DESC);
        JoinType joinType = parseJoinType(objectNode.get("joinType"));
        Boolean nullsFirst = objectNode.get("nullsFirst") != null
            ? objectNode.get("nullsFirst").asBoolean()
            : null;

        if (joinType != null && nullsFirst != null) {
            return new NormalSortInfo(direction, joinType, nullsFirst);
        } else if (joinType != null) {
            return new NormalSortInfo(direction, joinType);
        } else {
            return new NormalSortInfo(direction);
        }
    }

    /**
     * 우선순위 정렬 파싱
     */
    private PrioritySortInfo parsePrioritySort(String fieldName, JsonNode objectNode) {
        JsonNode priorityValueNode = objectNode.get("priorityValue");

        if (priorityValueNode == null) {
            throw new IllegalArgumentException("priorityValue is required for priority sort");
        }

        Object priorityValue = extractPriorityValue(priorityValueNode);
        Direction direction = parseDirection(objectNode.get("direction"), Direction.ASC);
        JoinType joinType = parseJoinType(objectNode.get("joinType"));
        Boolean nullsFirst = objectNode.get("nullsFirst") != null
            ? objectNode.get("nullsFirst").asBoolean()
            : null;

        if (joinType != null && nullsFirst != null) {
            return new PrioritySortInfo(priorityValue, direction, joinType, nullsFirst);
        } else if (joinType != null) {
            return new PrioritySortInfo(priorityValue, direction, joinType);
        } else {
            return new PrioritySortInfo(priorityValue, direction);
        }
    }

    /**
     * Direction 파싱
     */
    private Direction parseDirection(JsonNode directionNode, Direction defaultValue) {
        if (directionNode == null || !directionNode.isTextual()) {
            return defaultValue;
        }

        try {
            return Direction.valueOf(directionNode.asText().toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            log.warn("Invalid direction '{}', using {}", directionNode.asText(), defaultValue);
            return defaultValue;
        }
    }

    /**
     * JoinType 파싱
     */
    private JoinType parseJoinType(JsonNode joinTypeNode) {
        if (joinTypeNode == null || !joinTypeNode.isTextual()) {
            return null;
        }

        try {
            return JoinType.valueOf(joinTypeNode.asText().toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            log.warn("Invalid joinType '{}', ignoring", joinTypeNode.asText());
            return null;
        }
    }

    /**
     * priorityValue 추출 (다양한 타입 지원)
     */
    private Object extractPriorityValue(JsonNode priorityValueNode) {
        if (priorityValueNode.isTextual()) {
            return priorityValueNode.asText();
        } else if (priorityValueNode.isNumber()) {
            if (priorityValueNode.isIntegralNumber()) {
                return priorityValueNode.asLong();
            } else {
                return priorityValueNode.asDouble();
            }
        } else if (priorityValueNode.isBoolean()) {
            return priorityValueNode.asBoolean();
        } else if (priorityValueNode.isNull()) {
            return null;
        } else {
            return priorityValueNode.toString();
        }
    }
}
