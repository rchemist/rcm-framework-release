/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.trace;

import java.security.SecureRandom;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #6 — W3C Trace Context (TraceContext, level 1) 의 {@code traceparent} 헤더 영역
 * helper.
 *
 * <p>형식: {@code <version>-<trace-id>-<parent-id>-<trace-flags>}
 * <ul>
 *   <li>version = 2 hex (00 = level 1 baseline)</li>
 *   <li>trace-id = 32 hex (16 byte randomly chosen)</li>
 *   <li>parent-id = 16 hex (= span-id, 8 byte randomly chosen)</li>
 *   <li>trace-flags = 2 hex (01 = sampled)</li>
 * </ul>
 *
 * <p>외부 표준 — 외부 dep 0 (JDK SecureRandom 만). HEX_FORMAT 은 정수 일관성 (소문자 hex 표준).
 **/
public final class Traceparent {

  static final String VERSION_LEVEL_1 = "00";
  static final String FLAGS_SAMPLED = "01";

  private static final SecureRandom RANDOM = new SecureRandom();

  private Traceparent() {}

  /** parent 가 없는 영역 — 신규 traceId / spanId / sampled flag. */
  public static String fresh() {
    return VERSION_LEVEL_1 + "-" + randomHex(16) + "-" + randomHex(8) + "-" + FLAGS_SAMPLED;
  }

  /**
   * parent traceparent header 가 있는 영역 — traceId 보존 + 신규 spanId. flags 보존. parent 영역
   * 형식이 잘못되어 있으면 {@link #fresh()} fallback.
   */
  public static String childOf(String parent) {
    if (parent == null || parent.isBlank()) {
      return fresh();
    }
    String[] parts = parent.split("-");
    if (parts.length != 4 || parts[1].length() != 32 || parts[3].length() != 2) {
      return fresh();
    }
    return parts[0] + "-" + parts[1] + "-" + randomHex(8) + "-" + parts[3];
  }

  private static String randomHex(int byteLength) {
    byte[] bytes = new byte[byteLength];
    RANDOM.nextBytes(bytes);
    StringBuilder sb = new StringBuilder(byteLength * 2);
    for (byte b : bytes) {
      sb.append(String.format("%02x", b & 0xff));
    }
    return sb.toString();
  }
}
