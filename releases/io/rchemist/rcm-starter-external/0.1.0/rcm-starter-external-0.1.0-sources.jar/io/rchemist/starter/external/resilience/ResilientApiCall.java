/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.resilience;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #4 — method-level annotation. 외부 API 호출 method 에 부착 시
 * {@link io.github.resilience4j.retry.Retry} +
 * {@link io.github.resilience4j.circuitbreaker.CircuitBreaker} +
 * {@link io.github.resilience4j.bulkhead.Bulkhead} 가 결합 적용 (Phase 6 task #5 의 aspect).
 *
 * <p>{@code name} = {@link ResilienceProperties} 의 sub-section name. yml 의
 * {@code platform.external.resilience.policies.<name>.*} 영역 override 정합. 미설정 시
 * default policy.
 *
 * <p>Phase 5 의 {@code @RateLimit} 패턴 정합 (name 기반 yml override + AspectJ aspect).
 **/
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ResilientApiCall {

  /** policy name. yml override sub-section 의 key. 비어있으면 default policy. */
  String value() default "";
}
