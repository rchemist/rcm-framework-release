/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.problem;

import java.net.URI;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #8 — 외부 API 4xx / 5xx 응답을 framework 단일 exception 으로 wrap.
 *
 * <p>{@link ProblemDetail} (RFC 7807, Decision #1) 이 응답 body 에 있으면 {@link #problemDetail()}
 * 에 보존 — Consumer 가 catch 후 자기 응답 ProblemDetail 로 forward 가능. 그 외 응답은 raw body
 * string 만 보존.
 *
 * <p>Phase 5 RateLimitExceededException 패턴 정합 — Phase 2 ProblemDetailAdvice 가 framework
 * exception 을 자동 ProblemDetail 로 변환.
 **/
public class ExternalApiException extends RuntimeException {

  private final HttpStatusCode statusCode;
  private final URI requestUri;
  private final ProblemDetail problemDetail;
  private final String responseBody;

  public ExternalApiException(
      HttpStatusCode statusCode,
      URI requestUri,
      ProblemDetail problemDetail,
      String responseBody) {
    super(buildMessage(statusCode, requestUri, problemDetail));
    this.statusCode = statusCode;
    this.requestUri = requestUri;
    this.problemDetail = problemDetail;
    this.responseBody = responseBody;
  }

  public HttpStatusCode statusCode() {
    return statusCode;
  }

  public URI requestUri() {
    return requestUri;
  }

  /** RFC 7807 ProblemDetail body — 응답 영역에 있었으면 non-null, 그 외 null. */
  public ProblemDetail problemDetail() {
    return problemDetail;
  }

  /** raw 응답 body — ProblemDetail 미존재 영역의 원본 string. */
  public String responseBody() {
    return responseBody;
  }

  private static String buildMessage(
      HttpStatusCode status, URI uri, ProblemDetail problemDetail) {
    StringBuilder sb = new StringBuilder()
        .append("external API call ").append(uri).append(" returned ").append(status);
    if (problemDetail != null && problemDetail.getDetail() != null) {
      sb.append(" — ").append(problemDetail.getDetail());
    }
    return sb.toString();
  }
}
