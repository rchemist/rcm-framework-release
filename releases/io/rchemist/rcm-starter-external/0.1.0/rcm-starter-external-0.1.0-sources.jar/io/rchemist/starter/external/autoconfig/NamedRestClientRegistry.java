/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.autoconfig;

import java.util.HashMap;
import java.util.Map;
import org.springframework.web.client.RestClient;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #3 — {@code platform.external.clients.<name>.*} 영역에 정의된 다중 외부 API 의
 * {@link RestClient} 인스턴스 단일 진입점.
 *
 * <p>구성 패턴:
 * <pre>
 * platform.external.clients.payment-api.base-url=https://payment.example.com/api/v1
 * platform.external.clients.payment-api.read-timeout=PT30S
 * platform.external.clients.notification.base-url=https://noti.example.com
 * </pre>
 *
 * <p>Consumer 사용: {@code RestClient client = registry.get("payment-api")}.
 *
 * <p>name 누락 시 {@link IllegalArgumentException} (Fail loud — silent null 거부).
 **/
public class NamedRestClientRegistry {

  private final Map<String, RestClient> clients;

  public NamedRestClientRegistry(Map<String, RestClient> clients) {
    this.clients = new HashMap<>(clients);
  }

  /** 등록된 name 의 {@link RestClient} 반환. 누락 시 {@link IllegalArgumentException}. */
  public RestClient get(String name) {
    RestClient client = clients.get(name);
    if (client == null) {
      throw new IllegalArgumentException(
          "No RestClient registered with name '"
              + name
              + "'. Registered: "
              + clients.keySet()
              + ". Define it via platform.external.clients."
              + name
              + ".base-url=...");
    }
    return client;
  }

  /** 등록된 name 존재 여부 검사 (silent — exception 없음). */
  public boolean contains(String name) {
    return clients.containsKey(name);
  }

  /** 등록된 모든 name (immutable view). */
  public java.util.Set<String> names() {
    return java.util.Set.copyOf(clients.keySet());
  }
}
