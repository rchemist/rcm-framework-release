/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.problem;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.ResponseErrorHandler;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #8 — 외부 API 의 4xx / 5xx 응답을 {@link ExternalApiException} 으로 변환.
 *
 * <p>응답 body 의 {@code Content-Type} 이 {@code application/problem+json} 또는 {@code
 * application/problem+xml} 영역이면 {@link ProblemDetail} 로 deserialize — 그 외 응답은 raw string
 * 그대로 보존.
 *
 * <p>Decision #1 정합 — framework 의 모든 응답 (success / error) 이 ProblemDetail 표준화 가능.
 *
 * <p>Spring 7 의 {@link RestClient.Builder#defaultStatusHandler(ResponseErrorHandler)} 영역으로 등록.
 **/
public class ProblemDetailMappingErrorHandler implements ResponseErrorHandler {

  private final ObjectMapper objectMapper;

  public ProblemDetailMappingErrorHandler(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  @Override
  public boolean hasError(ClientHttpResponse response) throws IOException {
    return response.getStatusCode().isError();
  }

  @Override
  public void handleError(URI url, org.springframework.http.HttpMethod method, ClientHttpResponse response)
      throws IOException {
    HttpStatusCode status = response.getStatusCode();
    String body =
        StreamUtils.copyToString(response.getBody(), StandardCharsets.UTF_8);
    ProblemDetail problemDetail = parseProblemDetail(response.getHeaders().getContentType(), body);
    throw new ExternalApiException(status, url, problemDetail, body);
  }

  /** {@code application/problem+json} 영역 ProblemDetail parse — 실패 시 null fallback. */
  private ProblemDetail parseProblemDetail(MediaType contentType, String body) {
    if (contentType == null || body == null || body.isBlank()) {
      return null;
    }
    if (!isProblemContentType(contentType)) {
      return null;
    }
    try {
      return objectMapper.readValue(body, ProblemDetail.class);
    } catch (Exception e) {
      return null; // 잘못된 ProblemDetail 영역도 raw body 로 fallback
    }
  }

  private static boolean isProblemContentType(MediaType contentType) {
    String type = contentType.getType();
    String subtype = contentType.getSubtype();
    return "application".equalsIgnoreCase(type)
        && ("problem+json".equalsIgnoreCase(subtype) || "problem+xml".equalsIgnoreCase(subtype));
  }
}
