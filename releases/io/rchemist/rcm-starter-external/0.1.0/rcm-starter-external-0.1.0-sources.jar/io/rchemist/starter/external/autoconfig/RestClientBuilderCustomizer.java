/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.autoconfig;

import org.springframework.web.client.RestClient;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #3 — Consumer 가 framework default {@link RestClient.Builder} 에 추가 customization
 * 을 합류시키는 callback SPI.
 *
 * <p>Spring Boot 3.2 의 {@code RestClientCustomizer} 가 Spring Boot 4 의 module split 으로
 * 사라져, framework 자체로 customizer 인터페이스 도입. Consumer 가
 * {@link RestClientBuilderCustomizer} bean 을 정의하면 framework default builder 가 자동 합류 —
 * {@link org.springframework.core.Ordered} / {@link org.springframework.core.annotation.Order}
 * 영역으로 정렬.
 *
 * <p>사용 시나리오:
 * <ul>
 *   <li>모든 outbound 호출에 공통 default header 추가 (User-Agent / X-Tenant)</li>
 *   <li>baseUrl 또는 retry filter 영역의 framework-wide hook</li>
 *   <li>Phase 6 task #6~#7 의 traceparent / correlationId interceptor 가 본 SPI 로 합류</li>
 * </ul>
 *
 * <p>Consumer 가 자체 {@link RestClient.Builder} bean 을 정의하면 framework default 가 자동
 * 양보 — 본 customizer chain 도 그쪽엔 적용 안 됨 (Consumer 책임 영역).
 **/
@FunctionalInterface
public interface RestClientBuilderCustomizer {

  void customize(RestClient.Builder builder);
}
