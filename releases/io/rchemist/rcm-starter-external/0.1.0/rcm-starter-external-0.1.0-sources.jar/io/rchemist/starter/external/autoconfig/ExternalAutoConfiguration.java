/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.autoconfig;

import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;
import io.rchemist.starter.external.resilience.ResilienceInterceptor;
import io.rchemist.starter.external.resilience.ResilienceProperties;
import io.rchemist.starter.external.resilience.ResiliencePolicyResolver;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.observation.ObservationRegistry;
import io.rchemist.starter.external.problem.ProblemDetailMappingErrorHandler;
import io.rchemist.starter.external.trace.CorrelationIdInterceptor;
import io.rchemist.starter.external.trace.TraceparentPropagationInterceptor;
import org.springframework.web.client.ResponseErrorHandler;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #1 — {@code rcm-starter-external} 진입점.
 *
 * <p>baseline 적용 (Decision #20 + 청사진 §2.2):
 * <ul>
 *   <li>Decision #20 — {@code Rcm} prefix 영구 거부. Phase 0 의 stub
 *       {@code RcmStarterExternalAutoConfiguration} 를 본 클래스로 rename.</li>
 *   <li>{@code @ConditionalOnClass(RestClient.class)} — Spring 7 RestClient 가 classpath 에
 *       있을 때만 활성.</li>
 *   <li>{@code platform.external.enabled} = {@code false} 로 opt-out 가능 (default = true).</li>
 *   <li>4 영역 inner static config marker — Phase 6 후속 task 가 하나씩 채움
 *       (task #2 RestClient builder / task #4~#5 Resilience / task #6~#7 Trace /
 *       task #8 Problem).</li>
 * </ul>
 *
 * <p>Phase 5 의 {@code SecurityAutoConfiguration} 패턴 정합 — 단일 진입점 + inner static
 * config 분할 + {@link EnableConfigurationProperties}.
 **/
@AutoConfiguration
@ConditionalOnClass(name = "org.springframework.web.client.RestClient")
@ConditionalOnProperty(prefix = "platform.external", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(ExternalProperties.class)
public class ExternalAutoConfiguration {

  /**
   * Phase 6 task #2 — Apache HttpClient 5 기반 {@link ClientHttpRequestFactory} +
   * {@link RestClient.Builder} 등록. Consumer 자체 bean 정의 시 자동 양보.
   *
   * <p>Spring Boot 4 의 module split 결과 {@code RestClientCustomizer} 인터페이스가 사라져
   * (Spring Boot 3.2 에 있던 것), framework 가 직접 builder bean 을 등록하는 방식으로 전환.
   * Consumer 는 자체 {@link RestClient.Builder} bean 정의 또는 자체
   * {@link ClientHttpRequestFactory} bean 정의로 자유 override.
   *
   * <p>{@link ConditionalOnClass} — Apache HttpClient 5 가 classpath 에 없으면 silent skip.
   **/
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(name = "org.apache.hc.client5.http.classic.HttpClient")
  static class RestClientBeans {

    @Bean
    @ConditionalOnMissingBean
    ClientHttpRequestFactory rcmHttpClient5RequestFactory(ExternalProperties properties) {
      return HttpClient5RequestFactoryFactory.create(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    RestClient.Builder rcmRestClientBuilder(
        ClientHttpRequestFactory requestFactory,
        ObjectProvider<RestClientBuilderCustomizer> customizers) {
      RestClient.Builder builder = RestClient.builder().requestFactory(requestFactory);
      customizers.orderedStream().forEach(c -> c.customize(builder));
      return builder;
    }

    @Bean
    @ConditionalOnMissingBean
    NamedRestClientRegistry rcmNamedRestClientRegistry(
        ExternalProperties properties,
        ObjectProvider<RestClientBuilderCustomizer> customizers) {
      Map<String, RestClient> clients = new LinkedHashMap<>();
      properties
          .clients()
          .forEach(
              (name, namedClient) -> {
                ClientHttpRequestFactory factory =
                    HttpClient5RequestFactoryFactory.create(
                        mergedProperties(properties, namedClient));
                RestClient.Builder builder = RestClient.builder().requestFactory(factory);
                if (namedClient.baseUrl() != null && !namedClient.baseUrl().isBlank()) {
                  builder.baseUrl(namedClient.baseUrl());
                }
                customizers.orderedStream().forEach(c -> c.customize(builder));
                clients.put(name, builder.build());
              });
      return new NamedRestClientRegistry(clients);
    }

    private static ExternalProperties mergedProperties(
        ExternalProperties base, ExternalProperties.NamedClient namedClient) {
      Duration connect =
          namedClient.connectTimeout() != null ? namedClient.connectTimeout() : base.connectTimeout();
      Duration read =
          namedClient.readTimeout() != null ? namedClient.readTimeout() : base.readTimeout();
      return new ExternalProperties(base.enabled(), connect, read, base.pool(), Map.of());
    }
  }

  /**
   * Phase 6 task #4 — {@code @ResilientApiCall} annotation + {@link ResilienceProperties} +
   * {@link ResiliencePolicyResolver} 등록. task #5 가 {@code RetryRegistry} /
   * {@code CircuitBreakerRegistry} / {@code BulkheadRegistry} + aspect 결합 본문 채움.
   *
   * <p>{@link ConditionalOnClass} — Resilience4j Retry 가 classpath 에 없으면 silent skip.
   **/
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(name = "io.github.resilience4j.retry.RetryRegistry")
  @EnableConfigurationProperties(ResilienceProperties.class)
  static class ResilienceBeans {

    @Bean
    @ConditionalOnMissingBean
    ResiliencePolicyResolver rcmResiliencePolicyResolver(ResilienceProperties properties) {
      return new ResiliencePolicyResolver(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    RetryRegistry rcmRetryRegistry() {
      return RetryRegistry.ofDefaults();
    }

    @Bean
    @ConditionalOnMissingBean
    CircuitBreakerRegistry rcmCircuitBreakerRegistry() {
      return CircuitBreakerRegistry.ofDefaults();
    }

    @Bean
    @ConditionalOnMissingBean
    BulkheadRegistry rcmBulkheadRegistry() {
      return BulkheadRegistry.ofDefaults();
    }

    @Bean
    @ConditionalOnMissingBean
    ResilienceInterceptor rcmResilienceInterceptor(
        ResiliencePolicyResolver resolver,
        RetryRegistry retryRegistry,
        CircuitBreakerRegistry circuitBreakerRegistry,
        BulkheadRegistry bulkheadRegistry) {
      return new ResilienceInterceptor(
          resolver, retryRegistry, circuitBreakerRegistry, bulkheadRegistry);
    }
  }

  /**
   * Phase 6 task #6 — W3C traceparent outbound interceptor + RestClientBuilderCustomizer 자동
   * 합류. task #7 (correlationId + Micrometer observation) 가 본 inner config 추가 보강.
   **/
  @Configuration(proxyBeanMethods = false)
  static class TraceBeans {

    @Bean
    @ConditionalOnMissingBean
    TraceparentPropagationInterceptor rcmTraceparentPropagationInterceptor() {
      return new TraceparentPropagationInterceptor();
    }

    @Bean
    @ConditionalOnMissingBean
    CorrelationIdInterceptor rcmCorrelationIdInterceptor() {
      return new CorrelationIdInterceptor();
    }

    @Bean
    @ConditionalOnMissingBean(name = "rcmTraceparentRestClientCustomizer")
    RestClientBuilderCustomizer rcmTraceparentRestClientCustomizer(
        TraceparentPropagationInterceptor interceptor) {
      return builder -> builder.requestInterceptor(interceptor);
    }

    @Bean
    @ConditionalOnMissingBean(name = "rcmCorrelationIdRestClientCustomizer")
    RestClientBuilderCustomizer rcmCorrelationIdRestClientCustomizer(
        CorrelationIdInterceptor interceptor) {
      return builder -> builder.requestInterceptor(interceptor);
    }

    @Bean
    @ConditionalOnMissingBean(name = "rcmObservationRestClientCustomizer")
    RestClientBuilderCustomizer rcmObservationRestClientCustomizer(
        ObjectProvider<ObservationRegistry> observationRegistry) {
      return builder -> {
        ObservationRegistry registry = observationRegistry.getIfAvailable();
        if (registry != null) {
          builder.observationRegistry(registry);
        }
      };
    }
  }

  /**
   * Phase 6 task #8 — 4xx / 5xx 응답 ↔ {@link org.springframework.http.ProblemDetail} 매핑
   * (Decision #1 정합). {@link ProblemDetailMappingErrorHandler} ResponseErrorHandler 등록 +
   * RestClient.Builder.defaultStatusHandler 자동 합류.
   **/
  @Configuration(proxyBeanMethods = false)
  static class ProblemBeans {

    @Bean
    @ConditionalOnMissingBean(ResponseErrorHandler.class)
    ProblemDetailMappingErrorHandler rcmProblemDetailMappingErrorHandler(
        ObjectProvider<ObjectMapper> objectMapper) {
      return new ProblemDetailMappingErrorHandler(
          objectMapper.getIfAvailable(ObjectMapper::new));
    }

    @Bean
    @ConditionalOnMissingBean(name = "rcmProblemDetailRestClientCustomizer")
    RestClientBuilderCustomizer rcmProblemDetailRestClientCustomizer(
        ResponseErrorHandler errorHandler) {
      return builder -> builder.defaultStatusHandler(errorHandler);
    }
  }
}
