/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.resilience;

import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.bulkhead.BulkheadFullException;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.core.functions.CheckedSupplier;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #5 — {@link ResilientApiCall} annotation AOP. Resilience4j Retry / CircuitBreaker /
 * Bulkhead 결합 적용.
 *
 * <p>decorate 결합 순서 (안쪽 → 바깥쪽 = 호출 시 적용 순서):
 * <ol>
 *   <li>Bulkhead — 동시 호출 한도 검사 (한도 초과 시 즉시 거부)</li>
 *   <li>CircuitBreaker — open 상태 시 즉시 거부</li>
 *   <li>Retry — 호출 실패 시 wait 후 재시도</li>
 * </ol>
 *
 * <p>framework-level 거부 ({@link CallNotPermittedException} CB open / {@link BulkheadFullException}
 * 동시 호출 한도 초과) 는 {@link ResilientApiCallException} 으로 wrap — Phase 6 task #8 의
 * ProblemDetail 매핑이 503 으로 변환. 내부 호출 자체의 exception 은 retry 가 마지막에 그대로
 * propagate (외부 API 실패 자체가 의미를 보유 — wrap 없음).
 *
 * <p>Phase 5 {@code RateLimitInterceptor} 패턴 정합 — (name) 별 Retry/CB/Bulkhead instance
 * 캐싱.
 **/
@Aspect
public class ResilienceInterceptor {

  private final ResiliencePolicyResolver resolver;
  private final RetryRegistry retryRegistry;
  private final CircuitBreakerRegistry circuitBreakerRegistry;
  private final BulkheadRegistry bulkheadRegistry;

  private final ConcurrentMap<String, Retry> retryCache = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, CircuitBreaker> cbCache = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, Bulkhead> bhCache = new ConcurrentHashMap<>();

  public ResilienceInterceptor(
      ResiliencePolicyResolver resolver,
      RetryRegistry retryRegistry,
      CircuitBreakerRegistry circuitBreakerRegistry,
      BulkheadRegistry bulkheadRegistry) {
    this.resolver = Objects.requireNonNull(resolver, "resolver");
    this.retryRegistry = Objects.requireNonNull(retryRegistry, "retryRegistry");
    this.circuitBreakerRegistry =
        Objects.requireNonNull(circuitBreakerRegistry, "circuitBreakerRegistry");
    this.bulkheadRegistry = Objects.requireNonNull(bulkheadRegistry, "bulkheadRegistry");
  }

  @Around("@annotation(annotation)")
  public Object intercept(ProceedingJoinPoint pjp, ResilientApiCall annotation) throws Throwable {
    ResolvedPolicy policy = resolver.resolve(annotation.value());
    String compositeName = policy.name().isEmpty() ? "default" : policy.name();

    Retry retry = retryCache.computeIfAbsent(compositeName, k -> retryRegistry.retry(k, retryConfig(policy.retry())));
    CircuitBreaker circuitBreaker =
        cbCache.computeIfAbsent(
            compositeName, k -> circuitBreakerRegistry.circuitBreaker(k, cbConfig(policy.circuitBreaker())));
    Bulkhead bulkhead =
        bhCache.computeIfAbsent(
            compositeName, k -> bulkheadRegistry.bulkhead(k, bhConfig(policy.bulkhead())));

    CheckedSupplier<Object> supplier = pjp::proceed;
    supplier = Bulkhead.decorateCheckedSupplier(bulkhead, supplier);
    supplier = CircuitBreaker.decorateCheckedSupplier(circuitBreaker, supplier);
    supplier = Retry.decorateCheckedSupplier(retry, supplier);

    try {
      return supplier.get();
    } catch (CallNotPermittedException e) {
      throw new ResilientApiCallException(
          compositeName, "circuit breaker open for '" + compositeName + "'", e);
    } catch (BulkheadFullException e) {
      throw new ResilientApiCallException(
          compositeName, "bulkhead full for '" + compositeName + "'", e);
    }
  }

  private static RetryConfig retryConfig(ResilienceProperties.RetryPolicy policy) {
    return RetryConfig.custom()
        .maxAttempts(policy.maxAttempts())
        .waitDuration(policy.waitDuration())
        .build();
  }

  private static CircuitBreakerConfig cbConfig(ResilienceProperties.CircuitBreakerPolicy policy) {
    return CircuitBreakerConfig.custom()
        .failureRateThreshold(policy.failureRateThreshold())
        .slidingWindowSize(policy.slidingWindowSize())
        .waitDurationInOpenState(policy.waitDurationInOpenState())
        .permittedNumberOfCallsInHalfOpenState(policy.permittedCallsInHalfOpenState())
        .build();
  }

  private static BulkheadConfig bhConfig(ResilienceProperties.BulkheadPolicy policy) {
    return BulkheadConfig.custom()
        .maxConcurrentCalls(policy.maxConcurrentCalls())
        .maxWaitDuration(policy.maxWaitDuration())
        .build();
  }
}
