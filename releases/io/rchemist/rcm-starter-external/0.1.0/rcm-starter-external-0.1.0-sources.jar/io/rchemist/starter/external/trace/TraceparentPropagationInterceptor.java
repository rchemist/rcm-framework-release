/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.trace;

import io.rchemist.core.context.RequestContext;
import java.io.IOException;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #6 — outbound RestClient 호출에 W3C {@code traceparent} 헤더 자동 부착.
 *
 * <p>Sourcing 우선순위:
 * <ol>
 *   <li>{@link RequestContext} ScopedValue 가 bound + traceparent 가 non-null → 본 traceId 보존
 *       + 신규 spanId 부여 (downstream child span 정합)</li>
 *   <li>RequestContext 미bound 또는 traceparent null → {@link Traceparent#fresh()} 신규 생성</li>
 * </ol>
 *
 * <p>{@link RequestContext} 의 {@code tracestate} (vendor-specific) 는 있으면 그대로 propagate.
 *
 * <p>본 interceptor 는 {@link io.rchemist.starter.external.autoconfig.RestClientBuilderCustomizer}
 * 영역으로 자동 합류 (autoconfig 의 {@link io.rchemist.starter.external.autoconfig.ExternalAutoConfiguration.TraceBeans}).
 **/
public class TraceparentPropagationInterceptor implements ClientHttpRequestInterceptor {

  static final String HEADER_TRACEPARENT = "traceparent";
  static final String HEADER_TRACESTATE = "tracestate";

  @Override
  public ClientHttpResponse intercept(
      HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
    if (!request.getHeaders().containsHeader(HEADER_TRACEPARENT)) {
      request.getHeaders().set(HEADER_TRACEPARENT, computeTraceparent());
      String tracestate = computeTracestate();
      if (tracestate != null) {
        request.getHeaders().set(HEADER_TRACESTATE, tracestate);
      }
    }
    return execution.execute(request, body);
  }

  private static String computeTraceparent() {
    if (RequestContext.isBound()) {
      RequestContext ctx = RequestContext.current();
      String parent = ctx.traceparent();
      return parent != null ? Traceparent.childOf(parent) : Traceparent.fresh();
    }
    return Traceparent.fresh();
  }

  private static String computeTracestate() {
    if (RequestContext.isBound()) {
      String state = RequestContext.current().tracestate();
      if (state != null && !state.isBlank()) {
        return state;
      }
    }
    return null;
  }
}
