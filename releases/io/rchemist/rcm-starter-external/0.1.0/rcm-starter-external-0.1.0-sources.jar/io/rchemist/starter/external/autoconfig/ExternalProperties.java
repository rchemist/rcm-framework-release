/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.autoconfig;

import java.time.Duration;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #1 + #2 + #3 — {@code platform.external.*} prefix 의 baseline yml binding 단일 지점.
 *
 * <p>{@code enabled} = {@link ExternalAutoConfiguration} 자체 opt-out flag (default true).
 *
 * <p>{@code connectTimeout} / {@code readTimeout} = Apache HttpClient 5 default request config.
 * default 5s connect / 10s read.
 *
 * <p>{@link Pool} = Apache HttpClient 5 의 {@code PoolingHttpClientConnectionManager} 정합.
 *
 * <p>{@code clients} = 다중 외부 API 영역의 named instance map. yml 의
 * {@code platform.external.clients.<name>.base-url=...} 등으로 등록 → {@link NamedRestClientRegistry}
 * 가 자동 wrap. Consumer 가 {@code registry.get("payment-api")} 로 조회.
 **/
@ConfigurationProperties(prefix = "platform.external")
public record ExternalProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("PT5S") Duration connectTimeout,
    @DefaultValue("PT10S") Duration readTimeout,
    @DefaultValue Pool pool,
    @DefaultValue Map<String, NamedClient> clients) {

  /**
   * Apache HttpClient 5 connection pool 설정.
   *
   * @param maxTotal 전체 connection pool 한도. default 100.
   * @param maxPerRoute 호스트 별 connection 한도 (HTTP 1.1 keep-alive 영역). default 20.
   */
  public record Pool(@DefaultValue("100") int maxTotal, @DefaultValue("20") int maxPerRoute) {}

  /**
   * 다중 외부 API 영역의 named client 정의.
   *
   * @param baseUrl 호출 base URL ({@code https://payment.example.com/api/v1}). 필수.
   * @param connectTimeout 본 client 만의 override (null 이면 framework default).
   * @param readTimeout 본 client 만의 override (null 이면 framework default).
   */
  public record NamedClient(String baseUrl, Duration connectTimeout, Duration readTimeout) {}
}
