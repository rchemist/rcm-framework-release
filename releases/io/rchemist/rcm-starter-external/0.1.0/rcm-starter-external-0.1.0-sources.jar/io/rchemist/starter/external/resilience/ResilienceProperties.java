/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.resilience;

import java.time.Duration;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #4 — {@code platform.external.resilience.*} prefix 의 yml binding.
 *
 * <p>{@link Defaults} = framework default policy (annotation 의 name 이 비어있거나 yml override
 * 가 없는 영역 모두 적용). {@code policies} = name 별 override (Phase 5 의 RateLimitProperties.policies
 * 패턴 정합).
 *
 * <p>{@link RetryPolicy} / {@link CircuitBreakerPolicy} / {@link BulkheadPolicy} 3 sub-section —
 * 각자 Resilience4j 의 동일명 config 로 직접 매핑.
 **/
@ConfigurationProperties(prefix = "platform.external.resilience")
public record ResilienceProperties(@DefaultValue Defaults defaults, @DefaultValue Map<String, Policy> policies) {

  /** framework default policy. yml 부재 시 본 default 적용. */
  public record Defaults(
      @DefaultValue RetryPolicy retry,
      @DefaultValue CircuitBreakerPolicy circuitBreaker,
      @DefaultValue BulkheadPolicy bulkhead) {}

  /** name 별 policy override — 정의된 sub-section 만 default 위에 덮어씀 (null = default 유지). */
  public record Policy(RetryPolicy retry, CircuitBreakerPolicy circuitBreaker, BulkheadPolicy bulkhead) {}

  /**
   * Resilience4j {@link io.github.resilience4j.retry.RetryConfig} 정합.
   *
   * @param maxAttempts 최대 시도 (1 = retry 없음). default 3.
   * @param waitDuration retry 사이 wait. default 500ms.
   */
  public record RetryPolicy(
      @DefaultValue("3") int maxAttempts, @DefaultValue("PT0.5S") Duration waitDuration) {}

  /**
   * Resilience4j {@link io.github.resilience4j.circuitbreaker.CircuitBreakerConfig} 정합.
   *
   * @param failureRateThreshold open 으로 전환되는 실패율 (%). default 50.
   * @param slidingWindowSize sliding window 크기 (호출 수). default 100.
   * @param waitDurationInOpenState open → half-open 전환 대기 시간. default 60s.
   * @param permittedCallsInHalfOpenState half-open 영역 허용 호출 수. default 10.
   */
  public record CircuitBreakerPolicy(
      @DefaultValue("50") float failureRateThreshold,
      @DefaultValue("100") int slidingWindowSize,
      @DefaultValue("PT60S") Duration waitDurationInOpenState,
      @DefaultValue("10") int permittedCallsInHalfOpenState) {}

  /**
   * Resilience4j {@link io.github.resilience4j.bulkhead.BulkheadConfig} 정합.
   *
   * @param maxConcurrentCalls 동시 호출 한도. default 25.
   * @param maxWaitDuration 한도 초과 시 대기 시간 (0 = 즉시 거부). default 0.
   */
  public record BulkheadPolicy(
      @DefaultValue("25") int maxConcurrentCalls,
      @DefaultValue("PT0S") Duration maxWaitDuration) {}
}
