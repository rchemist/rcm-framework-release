/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.resilience;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #5 — Resilience4j 의 framework-level 거부 (CircuitBreaker open / Bulkhead full)
 * 를 단일 framework exception 으로 wrap. cause 는 Resilience4j 가 throw 한 native exception 그대로
 * 보존.
 *
 * <p>Phase 6 task #8 의 ProblemDetail 매핑이 본 exception 을 503 (Service Unavailable) 로 변환.
 * 내부 호출 자체의 실패 ({@link java.io.IOException}, retry max 도달 시 마지막 cause 등) 는
 * wrap 하지 않고 그대로 propagate — 그쪽은 자체적으로 의미가 분명.
 **/
public class ResilientApiCallException extends RuntimeException {

  private final String policyName;

  public ResilientApiCallException(String policyName, String message, Throwable cause) {
    super(message, cause);
    this.policyName = policyName;
  }

  public String policyName() {
    return policyName;
  }
}
