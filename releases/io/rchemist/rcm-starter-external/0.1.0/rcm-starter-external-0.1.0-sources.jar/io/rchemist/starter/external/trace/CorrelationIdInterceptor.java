/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.trace;

import io.rchemist.core.context.RequestContext;
import java.io.IOException;
import java.util.UUID;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #7 — outbound RestClient 호출에 {@code X-Correlation-Id} 헤더 자동 부착.
 *
 * <p>Sourcing 우선순위:
 * <ol>
 *   <li>{@link RequestContext} ScopedValue 의 {@code requestId} (Phase 1 §6.1) → propagate</li>
 *   <li>RequestContext 미bound → {@link UUID#randomUUID()} 신규 생성</li>
 * </ol>
 *
 * <p>이미 caller 가 헤더를 명시했으면 덮어쓰지 않음.
 *
 * <p>{@code X-Correlation-Id} = 사실상 표준 (RFC 도입 안 됐으나 광범위 합의). Spring Cloud /
 * Logback MDC 영역 정합. {@code traceparent} (W3C) 와 별도 — 둘 모두 함께 propagate.
 **/
public class CorrelationIdInterceptor implements ClientHttpRequestInterceptor {

  static final String HEADER_CORRELATION_ID = "X-Correlation-Id";

  @Override
  public ClientHttpResponse intercept(
      HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
    if (!request.getHeaders().containsHeader(HEADER_CORRELATION_ID)) {
      request.getHeaders().set(HEADER_CORRELATION_ID, computeCorrelationId());
    }
    return execution.execute(request, body);
  }

  private static String computeCorrelationId() {
    if (RequestContext.isBound()) {
      String requestId = RequestContext.current().requestId();
      if (requestId != null && !requestId.isBlank()) {
        return requestId;
      }
    }
    return UUID.randomUUID().toString();
  }
}
