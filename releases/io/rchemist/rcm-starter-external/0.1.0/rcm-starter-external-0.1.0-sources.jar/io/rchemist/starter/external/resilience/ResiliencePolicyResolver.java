/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.resilience;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #4 — {@code @ResilientApiCall(name)} → {@link ResolvedPolicy} 변환 단일 진입점.
 *
 * <p>우선순위 (Phase 5 RateLimitProperties.resolve 패턴 정합):
 * <ol>
 *   <li>name 이 정의된 yml policies sub-section (sub-policy 별 null 인 영역은 framework default 로 채움)</li>
 *   <li>framework default ({@link ResilienceProperties.Defaults})</li>
 * </ol>
 *
 * <p>name 이 비어있거나 yml 에 없으면 default 만 적용.
 **/
public class ResiliencePolicyResolver {

  private final ResilienceProperties properties;

  public ResiliencePolicyResolver(ResilienceProperties properties) {
    this.properties = properties;
  }

  /** {@code name} 에 해당하는 결합 policy 반환. */
  public ResolvedPolicy resolve(String name) {
    ResilienceProperties.Defaults defaults = properties.defaults();
    if (name == null || name.isBlank()) {
      return new ResolvedPolicy("", defaults.retry(), defaults.circuitBreaker(), defaults.bulkhead());
    }
    ResilienceProperties.Policy override = properties.policies().get(name);
    if (override == null) {
      return new ResolvedPolicy(name, defaults.retry(), defaults.circuitBreaker(), defaults.bulkhead());
    }
    return new ResolvedPolicy(
        name,
        override.retry() != null ? override.retry() : defaults.retry(),
        override.circuitBreaker() != null ? override.circuitBreaker() : defaults.circuitBreaker(),
        override.bulkhead() != null ? override.bulkhead() : defaults.bulkhead());
  }
}
