/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.external.autoconfig;

import java.util.concurrent.TimeUnit;
import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.core5.util.Timeout;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6 task #2 — {@link ExternalProperties} 의 connection pool / timeout 영역을 Apache
 * HttpClient 5 기반 {@link ClientHttpRequestFactory} 로 변환.
 *
 * <p>책임 분리: 본 factory 는 *순수 변환* (Properties → ClientHttpRequestFactory) 만. 등록은
 * {@link ExternalAutoConfiguration.RestClientBeans} 의 {@code @Bean} method 가 책임. 단위 test
 * 가능 (autoconfig context 없이 properties → factory 검증).
 *
 * <p>Apache HttpClient 5 의 default {@link PoolingHttpClientConnectionManager} 는 maxTotal=25 /
 * maxPerRoute=5 — 다중 outbound 영역에서 부족. {@link ExternalProperties.Pool} 적용 (default
 * 100/20).
 **/
public final class HttpClient5RequestFactoryFactory {

  private HttpClient5RequestFactoryFactory() {}

  /** {@link ExternalProperties} 영역의 pool / timeout 값으로 {@link HttpClient} 생성 후 wrap. */
  public static ClientHttpRequestFactory create(ExternalProperties properties) {
    ConnectionConfig connectionConfig =
        ConnectionConfig.custom()
            .setConnectTimeout(Timeout.of(properties.connectTimeout()))
            .build();
    PoolingHttpClientConnectionManager connectionManager =
        PoolingHttpClientConnectionManagerBuilder.create()
            .setMaxConnTotal(properties.pool().maxTotal())
            .setMaxConnPerRoute(properties.pool().maxPerRoute())
            .setDefaultConnectionConfig(connectionConfig)
            .build();
    RequestConfig requestConfig =
        RequestConfig.custom()
            .setResponseTimeout(properties.readTimeout().toMillis(), TimeUnit.MILLISECONDS)
            .build();
    HttpClient httpClient =
        HttpClients.custom()
            .setConnectionManager(connectionManager)
            .setDefaultRequestConfig(requestConfig)
            .build();
    return new HttpComponentsClientHttpRequestFactory(httpClient);
  }
}
