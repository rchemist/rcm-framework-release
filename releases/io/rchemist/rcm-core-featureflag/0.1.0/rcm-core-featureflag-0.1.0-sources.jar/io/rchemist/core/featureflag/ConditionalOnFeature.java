/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Conditional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Bean / @Configuration / @Bean 메서드를 yml feature flag 로 토글하는 meta-annotation.
 * {@code platform.feature.{value}.enabled=true} 일 때만 활성.
 *
 * <p>예시:
 * <pre>{@code
 * @Bean
 * @ConditionalOnFeature("article.export-csv")
 * ArticleCsvExporter csvExporter() { ... }
 * }</pre>
 *
 * <p>매칭 정책 = yml 미명시 = 비활성 (matchIfMissing=false). 명시적 활성화 = 안전한 default.
 * runtime check 는 {@link FeatureFlagService#isEnabled(String)} 사용.
 **/
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Conditional(OnFeatureCondition.class)
public @interface ConditionalOnFeature {

  /** Feature 이름. yml 키 = {@code platform.feature.{value}.enabled}. */
  String value();
}
