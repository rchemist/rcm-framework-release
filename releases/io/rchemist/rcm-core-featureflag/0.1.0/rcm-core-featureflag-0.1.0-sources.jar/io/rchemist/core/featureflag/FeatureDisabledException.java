/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link FeatureFlagService#requireEnabled(String)} 가 비활성 feature 발견 시 throw 하는 unchecked
 * exception. fail-fast 패턴에 사용.
 **/
public class FeatureDisabledException extends RuntimeException {

  private final String featureName;

  public FeatureDisabledException(String featureName) {
    super("Feature is disabled: " + featureName);
    this.featureName = featureName;
  }

  public String featureName() {
    return featureName;
  }
}
