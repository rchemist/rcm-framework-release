/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag;

import org.springframework.core.env.Environment;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * yml-backed default {@link FeatureFlagService}. {@code platform.feature.{name}.enabled} 키를
 * Spring {@link Environment} 에서 직접 lookup — {@link ConditionalOnFeature} 가 wrap 하는
 * {@code @ConditionalOnProperty} 와 동일 yml 구조 (annotation 토글 / runtime 호출 토글이 entry 1 곳
 * 공유).
 *
 * <p>미명시 = false (matchIfMissing=false default 와 정합). Consumer 가 DB / @RefreshScope /
 * per-tenant override 시 본 service 를 {@link FeatureFlagService} Bean 으로 교체 (autoconfig 가
 * {@code @ConditionalOnMissingBean} hook 보장).
 **/
public class YmlFeatureFlagService implements FeatureFlagService {

  private static final String KEY_PREFIX = "platform.feature.";
  private static final String KEY_SUFFIX = ".enabled";

  private final Environment environment;

  public YmlFeatureFlagService(Environment environment) {
    if (environment == null) {
      throw new IllegalArgumentException("environment must not be null");
    }
    this.environment = environment;
  }

  @Override
  public boolean isEnabled(String name) {
    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("feature name must not be null or blank");
    }
    return environment.getProperty(KEY_PREFIX + name + KEY_SUFFIX, Boolean.class, Boolean.FALSE);
  }
}
