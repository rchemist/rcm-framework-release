/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag.autoconfig;

import io.rchemist.core.featureflag.FeatureFlagService;
import io.rchemist.core.featureflag.YmlFeatureFlagService;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * FeatureFlag SPI autoconfig (Decision #33). yml-backed default {@link YmlFeatureFlagService}
 * 등록. consumer override = {@code @ConditionalOnMissingBean(FeatureFlagService.class)} hook —
 * DB-backed / @RefreshScope / per-tenant 등으로 자유 교체.
 **/
@AutoConfiguration
public class FeatureFlagAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean(FeatureFlagService.class)
  FeatureFlagService featureFlagService(Environment environment) {
    return new YmlFeatureFlagService(environment);
  }
}
