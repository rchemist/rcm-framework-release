/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Feature flag toggle 의 진실 원천 SPI (Decision #33). yml-backed default 적용 외에 consumer 가
 * DB-backed / @RefreshScope / per-tenant 등으로 override 가능 (autoconfig 가
 * {@code @ConditionalOnMissingBean} hook).
 *
 * <p>호출 패턴:
 * <pre>{@code
 * if (featureFlag.isEnabled("article.export-csv")) {
 *   // ...
 * }
 * featureFlag.requireEnabled("workflow.parallel"); // throws FeatureDisabledException
 * }</pre>
 *
 * <p>Bean 생성 토글은 {@link ConditionalOnFeature} annotation 사용. service 호출 = runtime check 영역.
 **/
public interface FeatureFlagService {

  /**
   * 주어진 feature 가 활성 상태인지 반환. yml 미명시 = false (matchIfMissing=false default).
   *
   * @param name feature 이름 (e.g. "article.export-csv"). null/blank = IllegalArgumentException
   */
  boolean isEnabled(String name);

  /** {@link #isEnabled(String)} 의 역. */
  default boolean isDisabled(String name) {
    return !isEnabled(name);
  }

  /**
   * fail-fast — disabled 시 {@link FeatureDisabledException} throw.
   * Service entry point 에서 호출하면 분기 누락 사고 차단.
   */
  default void requireEnabled(String name) {
    if (isDisabled(name)) {
      throw new FeatureDisabledException(name);
    }
  }
}
