/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.featureflag;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link ConditionalOnFeature} 의 매칭 로직 — {@code platform.feature.{value}.enabled} 키를
 * environment 에서 직접 lookup. true 일 때만 Bean 생성. {@link YmlFeatureFlagService} 와 동일
 * lookup 경로 보장.
 **/
class OnFeatureCondition implements Condition {

  private static final String KEY_PREFIX = "platform.feature.";
  private static final String KEY_SUFFIX = ".enabled";

  @Override
  public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
    var attrs = metadata.getAnnotationAttributes(ConditionalOnFeature.class.getName());
    if (attrs == null) {
      return false;
    }
    var name = (String) attrs.get("value");
    if (name == null || name.isBlank()) {
      return false;
    }
    var key = KEY_PREFIX + name + KEY_SUFFIX;
    return Boolean.TRUE.equals(context.getEnvironment().getProperty(key, Boolean.class));
  }
}
