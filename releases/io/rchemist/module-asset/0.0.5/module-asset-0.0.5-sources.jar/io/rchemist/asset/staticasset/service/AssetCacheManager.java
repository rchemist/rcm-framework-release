/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.configuration.AssetCacheRegion;
import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.common.cache.CacheOps;
import io.rchemist.common.cache.CommonCacheManager;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.cache.Cache;
import lombok.Getter;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service
public class AssetCacheManager {

  protected final CommonCacheManager commonCacheManager;

  protected final Map<String, String> URL_TO_ID_MAP = new ConcurrentHashMap<>(10000);

  @Getter
  protected final Cache<String, AssetDTO> cache;

  // key is url or filename
  @Getter
  protected final Cache<String, AssetViewDTO> viewCache;

  public AssetCacheManager(CommonCacheManager commonCacheManager) {
    this.commonCacheManager = commonCacheManager;
    this.cache = commonCacheManager.getOrCreateCache(AssetCacheRegion.Asset.DATA, 365 * 60 * 60 * 24, 10000, AssetDTO.class);
    this.viewCache = commonCacheManager.getOrCreateCache(AssetCacheRegion.Asset.VIEW, 365 * 60 * 60 * 24, 10000, AssetViewDTO.class);
  }

  public void evict(String... assetIds){
    if(ArrayUtils.isEmpty(assetIds))
      return;

    for(String assetId : assetIds){
      AssetDTO dto = CacheOps.getOrNull(getCache(), assetId);
      CacheOps.invalidateQuietly(getCache(), assetId);
      if (dto != null) {
        CacheOps.invalidateQuietly(getViewCache(), dto.getUrl());
      }
    }
  }

  // url, filename
  public void evictView(String url){
    CacheOps.invalidateQuietly(getViewCache(), url);
  }

  public void putCache(String id, AssetDTO dto) {
    getCache().put(id, dto);
  }

  public void putViewCache(String url, AssetViewDTO view) {
    getViewCache().put(url, view);
  }

  public String getIdFromUrl(String url){
    if(URL_TO_ID_MAP.containsKey(url)){
      return URL_TO_ID_MAP.get(url);
    }
    return null;
  }

}
