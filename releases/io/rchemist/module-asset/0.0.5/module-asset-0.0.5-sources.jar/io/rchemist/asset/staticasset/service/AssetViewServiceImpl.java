/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.service.extension.AssetServiceExtensionManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.file.data.FileResource;
import io.rchemist.common.file.service.FileService;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Service("rcmAssetViewService")
public class AssetViewServiceImpl implements AssetViewService {

  private final FileService fileService;
  private final AssetCacheManager cacheManager;

  protected final AssetServiceExtensionManager assetServiceExtensionManager;

  private static final String STATIC_RESOURCE_PREFIX = "/" + FileService.getStaticResourcePrefix();

  @Value("${platform.config.asset.browser_cache:true}")
  protected boolean useBrowserCache = true;

  @Value("${platform.config.asset.browser_cache_ttl:604800}")
  protected int browserCacheTtl = 60 * 60 * 24 * 7;

  public AssetViewServiceImpl(
      FileService fileService,
      AssetCacheManager cacheManager, @Qualifier(value = AssetServiceExtensionManager.MANAGER) AssetServiceExtensionManager assetServiceExtensionManager) {
    this.fileService = fileService;
    this.cacheManager = cacheManager;
    this.assetServiceExtensionManager = assetServiceExtensionManager;
  }

  /**
   * AssetView 에서 호출하는 서비스 cdn 에서 asset 서버 쪽으로 파일 갱신 또는 리사이즈 요청이 들어온 경우 s3 에서 해당 파일의 원본을 확인하고 리사이즈 한 후 업로드 한다.
   *
   * @return
   */
  @Override
  public void renderAsset(HttpServletRequest request, HttpServletResponse response)
      throws Exception {

    // 1. request 에서 파일명 확인
    String fileName = getFileName(request);

    if (fileName == null) {
      return;
    }

    Map<String, String> resizeOptions = getAssetResizeOptions(fileName, request);

    String cacheKey = getCacheKey(fileName, resizeOptions);

    AssetViewDTO view;
    if (cacheManager.getViewCache().containsKey(cacheKey)) {
      view = cacheManager.getViewCache().get(fileName);
    } else {
      ExtensionResultHolder<AssetViewDTO> resultHolder = new ExtensionResultHolder<AssetViewDTO>().withResult(new AssetViewDTO());
      assetServiceExtensionManager.getProxy().getAssetView(request, fileName, resizeOptions, resultHolder);
      view = resultHolder.getResult();
      cacheManager.putViewCache(cacheKey, view);
    }

    if (!view.isLocalResource()) {
      try {

        String uri = view.getAbsoluteSource();
        String resourceName = StringUtil.subStringAfter(StringUtil.subStringAfter(
            StringUtil.subStringAfter(uri, "http://"), "https://"), "/");

        String serverName = StringUtil.subStringBefore(uri, resourceName);

        uri = serverName + URLEncoder.encode(resourceName, StandardCharsets.UTF_8);

        if (StringUtils.isNotEmpty(request.getQueryString())) {
          if (StringUtils.contains(uri, "?")) {
            uri = uri + "&" + request.getQueryString();
          } else {
            uri = uri + "?" + request.getQueryString();
          }
        }

        response.sendRedirect(uri);
        return;
      } catch (IOException e) {
        log.warn("Asset redirect failed: file={}, message={}", fileName, e.toString());
        return;
      }
    }

    FileResource resource = fileService.getResourceResource(view.getAbsoluteSource(), view.getFilename(), view.isLocalResource());

    if (resource == null || (resource.getFile() == null && resource.getExternalFilePath() == null)) {
      log.warn("Asset not found: file={}", fileName);
      response.setStatus(HttpServletResponse.SC_NOT_FOUND);
      return;
    }

    String mimeType = view.getMimeType();
    if (mimeType == null) {
      mimeType = FileUtil.getMimeType(view.getFilename());
    }

    response.setContentType(mimeType);
    setBrowserCacheToResponse(request, response, useBrowserCache && !resource.isShouldResize());

    File file = resource.getFile();
    try (OutputStream os = response.getOutputStream()) {

      try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
        while (true) {

          int temp = bis.read();
          if (temp < 0) {
            break;
          } else {
            os.write(temp);
          }
          os.flush();
        }
      }

    } catch (IOException e) {
      // 응답 스트리밍 중 IO 실패 — 대개 클라이언트 연결 종료. 헤더는 이미 전송된 상태일 수 있어 상태 코드 재지정은 보장되지 않음.
      log.warn("Asset stream failed: file={}, message={}", view.getFilename(), e.toString());
      setBrowserCacheToResponse(request, response, false);
    }

  }

  private String getCacheKey(String fileName, Map<String, String> resizeOptions) {

    StringBuilder sb = new StringBuilder();

    sb.append(fileName);

    if (MapUtils.isNotEmpty(resizeOptions)) {
      sb.append(SPLIT_CHAR);

      String resizeOptionValues = AssetViewService.getResizeOptionValues(resizeOptions);

      sb.append(resizeOptionValues);

    }

    return sb.toString();
  }

  private void setBrowserCacheToResponse(HttpServletRequest request, HttpServletResponse response, boolean useBrowserCache) {
    if (!useBrowserCache) {
      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", 0);
    } else {
      response.setHeader("Cache-Control", "public");
      response.setHeader("Pragma", "cache");
      if (!StringUtils.isEmpty(request.getHeader("If-Modified-Since"))) {
        long lastModified = request.getDateHeader("If-Modified-Since");
        Calendar last = Calendar.getInstance();
        last.setTime(new Date(lastModified));
        Calendar check = Calendar.getInstance();
        check.add(Calendar.SECOND, -2 * browserCacheTtl);
        if (check.compareTo(last) < 0) {
          response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
          return;
        }
      } else {
        Calendar check = Calendar.getInstance();
        check.add(Calendar.SECOND, -1 * browserCacheTtl);
        response.setDateHeader("Last-Modified", check.getTimeInMillis());
      }
      Calendar cal = Calendar.getInstance();
      cal.add(Calendar.SECOND, browserCacheTtl);
      response.setDateHeader("Expires", cal.getTimeInMillis());
    }
  }

  private String getFileName(HttpServletRequest request) {

    String uri = request.getRequestURI();

    // resource prefix 가 없다면 asset 에서 다룰 request 정보가 아니다.
    if (!StringUtils.contains(uri, STATIC_RESOURCE_PREFIX)) {
      return null;
    }

    uri = StringUtils.substringAfterLast(uri, STATIC_RESOURCE_PREFIX);

    uri = URLDecoder.decode(uri, StandardCharsets.UTF_8);
    uri = uri.replaceAll("(?i);jsessionid.*?=.*?(?=\\?|$)", "");

    return uri;

  }

  /**
   * 리사이즈 관련 옵션을 확인하고 리사이즈에 필요한 query string 만 map 으로 저장해 전송한다.
   *
   * @return
   */
  private Map<String, String> getAssetResizeOptions(String fileName, HttpServletRequest request) {
    if (!FileUtil.isImageFile(fileName) || MapUtils.isEmpty(request.getParameterMap())) {
      return null;
    }

    Map<String, String> options = new HashMap<>();

    for (String key : request.getParameterMap().keySet()) {
      if (StringUtils.equalsIgnoreCase(key, RESIZE_WIDTH)
          || StringUtils.equalsIgnoreCase(key, RESIZE_HEIGHT)
          || StringUtils.equalsIgnoreCase(key, RESIZE_QUALITY)
      ) {
        // width 와 height 는 1보다 크거나 같은 양의 정수여야 한다.
        Integer value = NumberUtil.getInteger(request.getParameter(key));

        if (value < 1) {
          value = DEFAULT_MIN_WIDTH;
        }
        options.put(key.toLowerCase(), String.valueOf(value));

      } else if (StringUtils.equalsIgnoreCase(key, RESIZE_QUALITY)) {
        // quality 는 0 보다 크고 100 보다 작거나 같아야 한다.
        Integer quality = NumberUtil.getInteger(request.getParameter(key));
        if (quality <= 0) {
          // 0보다 작거나 같으면 기본값 30
          options.put(RESIZE_QUALITY, DEFAULT_RESIZE_QUALITY);
        } else if (quality > 100) {
          // 100 보다 크면 100으로 고정
          options.put(RESIZE_QUALITY, MAX_RESIZE_QUALITY);
        } else {
          options.put(RESIZE_QUALITY, String.valueOf(quality));
        }
      }
    }

    return options;
  }


}
