/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Multi-error fluent 누적 SPI — Decision #24 보강 적용.
 *
 * <p>gjcu {@code Staff.java:192} 의 form 단위 collect 후 sequential throw 패턴 흡수:
 * <pre>{@code
 * ErrorCollector errors = ErrorCollector.create();
 * errors.add("email", USER.EMAIL_DUPLICATE);
 * errors.add("email", VALIDATION.PATTERN);
 * errors.add("password", VALIDATION.SIZE, 8, 32);
 * errors.add(USER.NOT_AUTHORIZED);          // field 없음 (global)
 * errors.throwIfPresent();                  // 누적 있으면 ServiceException multi-error throw
 * }</pre>
 *
 * <p>throwIfPresent 호출 시: 첫 누적 = primary, 나머지 = additionalErrors. 누적 0 = noop.
 */
public final class ErrorCollector {

    private final List<FieldErrorEntry> entries = new ArrayList<>();

    private ErrorCollector() {
    }

    public static ErrorCollector create() {
        return new ErrorCollector();
    }

    public ErrorCollector add(ErrorType errorType) {
        Objects.requireNonNull(errorType, "errorType");
        entries.add(new FieldErrorEntry(null, errorType, null));
        return this;
    }

    public ErrorCollector add(String field, ErrorType errorType) {
        Objects.requireNonNull(errorType, "errorType");
        entries.add(new FieldErrorEntry(field, errorType, null));
        return this;
    }

    public ErrorCollector add(String field, ErrorType errorType, Object... args) {
        Objects.requireNonNull(errorType, "errorType");
        entries.add(new FieldErrorEntry(field, errorType, args));
        return this;
    }

    public boolean isEmpty() {
        return entries.isEmpty();
    }

    public int size() {
        return entries.size();
    }

    /**
     * 누적된 entries 의 immutable snapshot.
     */
    public List<FieldErrorEntry> entries() {
        return Collections.unmodifiableList(new ArrayList<>(entries));
    }

    /**
     * 누적 있으면 multi-error {@link ServiceException} throw, 없으면 noop.
     *
     * <p>첫 entry = primary, 나머지 = additionalErrors. ProblemDetailAdvice 가 catch 시 errors[] 로 flatten.
     */
    public void throwIfPresent() {
        if (entries.isEmpty()) {
            return;
        }
        FieldErrorEntry primary = entries.get(0);
        List<FieldErrorEntry> additional = entries.size() == 1
            ? List.of()
            : List.copyOf(entries.subList(1, entries.size()));
        throw new ServiceException(
            primary.errorType(),
            primary.field(),
            primary.args(),
            additional,
            null
        );
    }
}
