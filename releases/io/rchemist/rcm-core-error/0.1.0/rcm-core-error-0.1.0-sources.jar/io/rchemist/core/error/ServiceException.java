/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.error;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 서비스 계층 비즈니스 예외 base — Consumer 가 도메인별로 extends 하여 사용.
 *
 * <p>Decision #24 적용 — 0.0.5 의 {@code throw new XxxServiceException(field, ErrorType)} 패턴을 코드 변경 0 으로
 * 흡수. Phase 2 의 {@code ProblemDetailAdvice} 가 catch → RFC 7807 ProblemDetail 자동 변환.
 *
 * <p>Decision #24 보강 적용 4 영역:
 * <ul>
 *   <li>field nullable (gjcu 65.2% field 없음)</li>
 *   <li>args (i18n placeholder)</li>
 *   <li>multi-error 누적 ({@code additionalErrors})</li>
 *   <li>{@link ErrorCollector} SPI 와 정합 — primary + additional 합쳐 {@code errors[]} 로 flatten</li>
 * </ul>
 */
public class ServiceException extends RuntimeException {

    private final ErrorType errorType;
    private final String field;
    private final Object[] args;
    private final List<FieldErrorEntry> additionalErrors;

    public ServiceException(ErrorType errorType) {
        this(errorType, null, null, null, null);
    }

    public ServiceException(ErrorType errorType, String field) {
        this(errorType, field, null, null, null);
    }

    public ServiceException(ErrorType errorType, String field, Object... args) {
        this(errorType, field, args, null, null);
    }

    public ServiceException(ErrorType errorType, Throwable cause) {
        this(errorType, null, null, null, cause);
    }

    public ServiceException(ErrorType errorType, String field, Object[] args, Throwable cause) {
        this(errorType, field, args, null, cause);
    }

    /**
     * Multi-error constructor — {@link ErrorCollector} 가 사용.
     *
     * @param errorType primary 에러 (non-null)
     * @param field primary field (null = global)
     * @param args primary args (null = empty)
     * @param additionalErrors 추가 에러 누적 (null = empty)
     * @param cause root cause (null 가능)
     */
    public ServiceException(
        ErrorType errorType,
        String field,
        Object[] args,
        List<FieldErrorEntry> additionalErrors,
        Throwable cause
    ) {
        super(buildMessage(errorType), cause);
        Objects.requireNonNull(errorType, "errorType");
        this.errorType = errorType;
        this.field = field;
        this.args = args == null ? new Object[0] : args.clone();
        this.additionalErrors = additionalErrors == null
            ? List.of()
            : List.copyOf(additionalErrors);
    }

    private static String buildMessage(ErrorType errorType) {
        return errorType == null ? "ServiceException" : errorType.code();
    }

    public ErrorType errorType() {
        return errorType;
    }

    /** primary field — null 가능 (gjcu 65.2% field 없음, Decision #24 보강). */
    public String field() {
        return field;
    }

    /** primary i18n args — never null, but possibly empty. */
    public Object[] args() {
        return args.clone();
    }

    /** 추가 누적 에러 (multi-error) — never null, possibly empty. */
    public List<FieldErrorEntry> additionalErrors() {
        return additionalErrors;
    }

    /**
     * primary + additionalErrors 합쳐 flat 리스트 반환 — ProblemDetail {@code errors[]} 직렬화 시 사용.
     */
    public List<FieldErrorEntry> getAllErrors() {
        if (additionalErrors.isEmpty()) {
            return List.of(new FieldErrorEntry(field, errorType, args));
        }
        List<FieldErrorEntry> all = new ArrayList<>(additionalErrors.size() + 1);
        all.add(new FieldErrorEntry(field, errorType, args));
        all.addAll(additionalErrors);
        return Collections.unmodifiableList(all);
    }

    public boolean isMultiError() {
        return !additionalErrors.isEmpty();
    }
}
