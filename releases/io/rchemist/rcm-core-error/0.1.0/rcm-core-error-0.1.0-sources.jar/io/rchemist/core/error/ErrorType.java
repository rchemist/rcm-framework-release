/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.error;

import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 에러 분류 SPI — Consumer 가 enum 으로 구현 (예: {@code XxxServiceErrorType implements ErrorType}).
 *
 * <p>Decision #24 적용 — Consumer 의 {@code throw new XxxServiceException(field, ErrorType, args)} 패턴
 * 을 코드 변경 0 으로 0.1.0 에 흡수. {@link ServiceException} 가 catch 하여 ProblemDetail 로 자동 변환.
 *
 * <p>Decision #25 정합 — Consumer 의 {@code XxxServiceErrorType extends EnumType<T> implements ErrorType}
 * 패턴도 그대로 흡수.
 */
public interface ErrorType {

    /**
     * 에러 코드 — 예: {@code "USER.NOT_FOUND"} / {@code "ARTICLE.CONTENT_REQUIRED"}.
     * ProblemDetail extension field {@code code} 로 노출.
     */
    String code();

    /**
     * HTTP 응답 상태 — 예: {@link HttpStatus#NOT_FOUND}. ProblemDetail status 로 노출.
     */
    HttpStatus httpStatus();

    /**
     * i18n 메시지 키 — Decision #23 (web-validation) 의 MessageSource lookup 용.
     * default = {@link #code()} 그대로 (별도 messages_*.properties 정의 없으면 코드 자체 노출).
     */
    default String messageKey() {
        return code();
    }
}
