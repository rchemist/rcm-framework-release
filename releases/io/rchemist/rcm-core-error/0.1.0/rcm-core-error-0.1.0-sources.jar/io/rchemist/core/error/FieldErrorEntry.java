/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.error;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 에러 엔트리 — primary + additional 모두 동일한 형태로 누적되어 ProblemDetail 의 {@code errors[]}
 * 배열로 flatten.
 *
 * <p>Decision #24 보강 적용 — field nullable (gjcu 65.2% field 없음). args 도 nullable (i18n placeholder 없는 케이스).
 *
 * @param field 필드명 (null 가능 — global / generic 에러)
 * @param errorType 에러 분류 (non-null)
 * @param args i18n placeholder 인자 (null = empty)
 */
public record FieldErrorEntry(String field, ErrorType errorType, Object[] args) {

    public FieldErrorEntry {
        Objects.requireNonNull(errorType, "errorType");
        if (args == null) {
            args = new Object[0];
        }
    }

    public FieldErrorEntry(String field, ErrorType errorType) {
        this(field, errorType, null);
    }
}
