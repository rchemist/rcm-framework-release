/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.email;

import io.rchemist.starter.notification.core.NotificationProvider;
import io.rchemist.starter.notification.core.NotificationType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Email channel SPI — {@link NotificationProvider} 의 Email 특화. 모든 EmailProvider 구현은
 * {@link NotificationType#EMAIL} 반환.
 *
 * <p>baseline carrier slot:
 * <ul>
 *   <li>{@link SmtpEmailProvider} — Spring {@code JavaMailSender} 기반 SMTP default</li>
 *   <li>Mailgun — Consumer 가 {@code @Component class MailgunEmailProvider implements EmailProvider}
 *       로 wire (REST API + Resilience4j 권장)</li>
 *   <li>Sendgrid — 동일 패턴 (Consumer 측 어댑터)</li>
 *   <li>Naver Cloud Outbound Mailer — 동일</li>
 * </ul>
 **/
public interface EmailProvider extends NotificationProvider<EmailNotification> {

  @Override
  default NotificationType type() {
    return NotificationType.EMAIL;
  }
}
