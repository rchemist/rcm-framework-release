/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 상태 enum — Outbox / Retry / DLQ 라이프사이클 (task #8) + Audit Log (task #9) 공유.
 *
 * <p>상태 전이:
 * <pre>
 *   PENDING (outbox 적재) → SENDING (provider 호출 중) → SENT (성공)
 *                                                  ↘ FAILED → RETRYING → ... → DEAD (최종 실패)
 * </pre>
 **/
public enum NotificationStatus {

  /** Outbox 에 적재되어 발송 대기 중. */
  PENDING,

  /** Provider 호출 진행 중. */
  SENDING,

  /** 발송 성공 (provider 응답 OK). */
  SENT,

  /** 발송 실패 — RetryPolicy 영역 안 (재시도 후보). */
  FAILED,

  /** 재시도 진행 중 (n 회 차). */
  RETRYING,

  /** 최종 실패 — DLQ 적재 (재시도 횟수 소진). */
  DEAD
}
