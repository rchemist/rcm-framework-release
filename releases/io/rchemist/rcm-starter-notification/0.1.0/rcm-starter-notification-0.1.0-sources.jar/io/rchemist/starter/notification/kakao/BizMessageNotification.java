/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationType;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage 발송 요청 — AlimTalk / FriendTalk 공통.
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>{@code to} = 수신자 전화번호 (010-xxxx-xxxx 또는 E.164)</li>
 *   <li>{@code senderKey} = KakaoTalk 비즈니스 채널 식별자 (Plus friend ID)</li>
 *   <li>{@code messageType} = {@link BizMessageType} (AlimTalk / FriendTalk)</li>
 *   <li>{@code templateCode} = 사전 등록 템플릿 (AlimTalk 필수, FriendTalk 옵션)</li>
 *   <li>{@code text} = 본문 (템플릿 변수 치환 결과 또는 자유 본문 — FriendTalk)</li>
 *   <li>{@code variables} = 템플릿 변수 (e.g. {@code {"#{이름}": "홍길동"}})</li>
 *   <li>{@code buttons} = {@link BizMessageButton} 리스트 (최대 5 개 carrier 표준)</li>
 *   <li>{@code imageUrl} = FriendTalk 이미지 URL (1MB 이하 / 가로 500~1500px)</li>
 *   <li>{@code fallback} = {@link SmsFallbackPolicy} (KakaoTalk 미수신 시 SMS 대체)</li>
 * </ul>
 **/
public record BizMessageNotification(
    String to,
    String senderKey,
    BizMessageType messageType,
    String templateCode,
    String text,
    Map<String, String> variables,
    List<BizMessageButton> buttons,
    String imageUrl,
    SmsFallbackPolicy fallback)
    implements Notification {

  public BizMessageNotification {
    Objects.requireNonNull(to, "to required");
    Objects.requireNonNull(senderKey, "senderKey required");
    Objects.requireNonNull(messageType, "messageType required");
    Objects.requireNonNull(text, "text required");
    if (to.isBlank()) {
      throw new IllegalArgumentException("to cannot be blank");
    }
    if (senderKey.isBlank()) {
      throw new IllegalArgumentException("senderKey cannot be blank");
    }
    if (messageType == BizMessageType.ALIM_TALK
        && (templateCode == null || templateCode.isBlank())) {
      throw new IllegalArgumentException("templateCode required for ALIM_TALK");
    }
    variables = variables == null ? Map.of() : Map.copyOf(variables);
    buttons = buttons == null ? List.of() : List.copyOf(buttons);
    fallback = fallback == null ? SmsFallbackPolicy.disabled() : fallback;
  }

  @Override
  public NotificationType type() {
    return NotificationType.BIZ_MESSAGE;
  }

  /** AlimTalk 편의 factory — templateCode 필수, fallback disabled. */
  public static BizMessageNotification alimTalk(
      String to, String senderKey, String templateCode, String text) {
    return new BizMessageNotification(
        to,
        senderKey,
        BizMessageType.ALIM_TALK,
        templateCode,
        text,
        Map.of(),
        List.of(),
        null,
        SmsFallbackPolicy.disabled());
  }

  /** FriendTalk 편의 factory — 자유 텍스트, fallback disabled. */
  public static BizMessageNotification friendTalk(String to, String senderKey, String text) {
    return new BizMessageNotification(
        to,
        senderKey,
        BizMessageType.FRIEND_TALK,
        null,
        text,
        Map.of(),
        List.of(),
        null,
        SmsFallbackPolicy.disabled());
  }
}
