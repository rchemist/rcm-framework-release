/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Provider 응답 — {@link NotificationProvider#send} 의 반환값.
 *
 * <p>{@code providerName} = 발송 carrier 식별 (e.g. {@code "smtp"} / {@code "naver-cloud-sms"} /
 * {@code "kakao-biz"}). {@code providerMessageId} = carrier 가 부여하는 추적 ID (delivery report
 * 조회 영역). {@code status} = {@link NotificationStatus} (SENT 또는 FAILED). {@code error} =
 * FAILED 경우의 reason ({@code null} OK).
 **/
public record NotificationResult(
    String providerName,
    String providerMessageId,
    NotificationStatus status,
    Instant sentAt,
    String error) {

  /** 발송 성공 short-cut. */
  public static NotificationResult sent(String providerName, String providerMessageId) {
    return new NotificationResult(
        providerName, providerMessageId, NotificationStatus.SENT, Instant.now(), null);
  }

  /** 발송 실패 short-cut (재시도 후보). */
  public static NotificationResult failed(String providerName, String error) {
    return new NotificationResult(
        providerName, null, NotificationStatus.FAILED, Instant.now(), error);
  }
}
