/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.autoconfig;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationDispatcher;
import io.rchemist.starter.notification.core.NotificationProvider;
import io.rchemist.starter.notification.email.EmailProvider;
import io.rchemist.starter.notification.email.SmtpEmailProvider;
import io.rchemist.starter.notification.idempotency.DefaultIdempotencyKeyResolver;
import io.rchemist.starter.notification.idempotency.IdempotencyKeyResolver;
import io.rchemist.starter.notification.idempotency.IdempotencyStore;
import io.rchemist.starter.notification.idempotency.InMemoryIdempotencyStore;
import io.rchemist.starter.notification.kakao.BizMessageProvider;
import io.rchemist.starter.notification.kakao.NoopBizMessageProvider;
import io.rchemist.starter.notification.log.InMemoryNotificationLogService;
import io.rchemist.starter.notification.log.NotificationLogService;
import io.rchemist.starter.notification.push.NoopPushProvider;
import io.rchemist.starter.notification.push.PushProvider;
import io.rchemist.starter.notification.sms.NoopSmsProvider;
import io.rchemist.starter.notification.sms.SmsProvider;
import io.rchemist.starter.notification.outbox.DeadLetterQueue;
import io.rchemist.starter.notification.outbox.InMemoryDeadLetterQueue;
import io.rchemist.starter.notification.outbox.InMemoryNotificationOutbox;
import io.rchemist.starter.notification.outbox.NotificationOutbox;
import io.rchemist.starter.notification.outbox.RetryPolicy;
import io.rchemist.starter.notification.template.InMemoryNotificationTemplateRegistry;
import io.rchemist.starter.notification.template.NotificationTemplateRegistry;
import io.rchemist.starter.notification.template.SimpleTemplateRenderer;
import io.rchemist.starter.notification.template.TemplateRenderer;
import java.util.List;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6.7 task #1 — {@code rcm-starter-notification} 진입점 (Decision #11 옵션 starter).
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>Decision #20 — prefix 없음. starter / 패키지 가 도메인 영역 자체 명시
 *       ({@code io.rchemist.starter.notification}). class 이름 = 도메인 의미 풀네임
 *       ({@code Notification} / {@code EmailProvider} / {@code SmsProvider} /
 *       {@code BizMessageProvider} / {@code PushProvider}).</li>
 *   <li>{@code platform.notification.enabled=false} 로 opt-out (default true).</li>
 *   <li>8 inner static config marker — task #3~#9 진입 시 본문 채움
 *       (email / sms / kakao / push / template / outbox / idempotency / log).</li>
 * </ul>
 *
 * <p>Phase 5/6/6.5 의 {@code SecurityAutoConfiguration} / {@code ExternalAutoConfiguration} /
 * {@code KoreanRegionAutoConfiguration} 패턴 정합.
 **/
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.notification", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(NotificationProperties.class)
public class NotificationAutoConfiguration {

  /**
   * Phase 6.7 task #2 — {@link NotificationDispatcher} default bean. Spring context 의 모든
   * {@link NotificationProvider} bean 을 자동 수집 + type 라우팅. Consumer 가 자체 Dispatcher
   * 정의 시 양보.
   */
  @Bean
  @ConditionalOnMissingBean(NotificationDispatcher.class)
  NotificationDispatcher notificationDispatcher(
      List<NotificationProvider<? extends Notification>> providers) {
    return new NotificationDispatcher(providers);
  }

  /** Phase 6.7 task #3 — Email provider (SMTP baseline + HTML/plain + 첨부 + Mailgun/Sendgrid SPI). */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(JavaMailSender.class)
  static class EmailBeans {

    /**
     * SMTP default {@link EmailProvider}. {@link JavaMailSender} bean 이 context 에 있을 때만
     * 활성 (Consumer 가 {@code spring-boot-starter-mail} runtime 의존 + {@code spring.mail.*}
     * 설정 시 자동 등록). Consumer 가 자체 {@link EmailProvider} bean 정의 시 양보.
     */
    @Bean
    @ConditionalOnBean(JavaMailSender.class)
    @ConditionalOnMissingBean(EmailProvider.class)
    EmailProvider smtpEmailProvider(
        JavaMailSender mailSender, NotificationProperties properties) {
      return new SmtpEmailProvider(mailSender, properties.email().defaultFrom());
    }
  }

  /** Phase 6.7 task #4 — SMS provider SPI + 한국 carrier (Naver/NHN/Coolsms/Aligo) plugin slot. */
  @Configuration(proxyBeanMethods = false)
  static class SmsBeans {

    /**
     * SMS Provider default = {@link NoopSmsProvider} fail-loud. Consumer 가 carrier 어댑터를
     * {@code @Component} 로 wire 하면 자동 양보 ({@link ConditionalOnMissingBean}).
     */
    @Bean
    @ConditionalOnMissingBean(SmsProvider.class)
    SmsProvider noopSmsProvider() {
      return new NoopSmsProvider();
    }
  }

  /** Phase 6.7 task #5 — KakaoTalk Bizmessage + AlimTalk + FriendTalk + SMS fallback. */
  @Configuration(proxyBeanMethods = false)
  static class KakaoBeans {

    /**
     * BizMessage Provider default = {@link NoopBizMessageProvider} fail-loud. Consumer 가
     * carrier 어댑터 wire 시 양보.
     */
    @Bean
    @ConditionalOnMissingBean(BizMessageProvider.class)
    BizMessageProvider noopBizMessageProvider() {
      return new NoopBizMessageProvider();
    }
  }

  /** Phase 6.7 task #6 — Push provider (FCM/APNs SPI 골격). */
  @Configuration(proxyBeanMethods = false)
  static class PushBeans {

    /** Push Provider default = {@link NoopPushProvider} fail-loud. Consumer 어댑터 wire 시 양보. */
    @Bean
    @ConditionalOnMissingBean(PushProvider.class)
    PushProvider noopPushProvider() {
      return new NoopPushProvider();
    }
  }

  /** Phase 6.7 task #7 — NotificationTemplate + TemplateRenderer SPI (Mustache default). */
  @Configuration(proxyBeanMethods = false)
  static class TemplateBeans {

    /**
     * 자체 {@link SimpleTemplateRenderer} default — 외부 의존 0 의 {@code {{varName}}} 파서.
     * Consumer 가 Mustache / Thymeleaf / Freemarker 어댑터 wire 시 양보.
     */
    @Bean
    @ConditionalOnMissingBean(TemplateRenderer.class)
    TemplateRenderer simpleTemplateRenderer() {
      return new SimpleTemplateRenderer();
    }

    /**
     * In-memory {@link NotificationTemplateRegistry} default — Consumer 가 startup 시점에
     * {@link InMemoryNotificationTemplateRegistry#register} 호출로 코드 별 다국어 등록. JPA-backed
     * 어댑터 정의 시 양보.
     */
    @Bean
    @ConditionalOnMissingBean(NotificationTemplateRegistry.class)
    NotificationTemplateRegistry inMemoryNotificationTemplateRegistry() {
      return new InMemoryNotificationTemplateRegistry();
    }
  }

  /** Phase 6.7 task #8 — Outbox + Retry + DLQ pattern (VirtualThread 기반 AsyncSender). */
  @Configuration(proxyBeanMethods = false)
  static class OutboxBeans {

    /** In-memory {@link NotificationOutbox} default. Consumer JPA / Kafka 어댑터 wire 시 양보. */
    @Bean
    @ConditionalOnMissingBean(NotificationOutbox.class)
    NotificationOutbox inMemoryNotificationOutbox() {
      return new InMemoryNotificationOutbox();
    }

    /** In-memory {@link DeadLetterQueue} default. */
    @Bean
    @ConditionalOnMissingBean(DeadLetterQueue.class)
    DeadLetterQueue inMemoryDeadLetterQueue() {
      return new InMemoryDeadLetterQueue();
    }

    /** {@link RetryPolicy} default — 3 회 시도, 5s 초기 + 2x exponential, max 5 분. */
    @Bean
    @ConditionalOnMissingBean(RetryPolicy.class)
    RetryPolicy defaultRetryPolicy() {
      return RetryPolicy.defaults();
    }
  }

  /** Phase 6.7 task #9 — Idempotency-Key (중복 발송 차단). */
  @Configuration(proxyBeanMethods = false)
  static class IdempotencyBeans {

    /** SHA-256 기반 default {@link IdempotencyKeyResolver}. */
    @Bean
    @ConditionalOnMissingBean(IdempotencyKeyResolver.class)
    IdempotencyKeyResolver defaultIdempotencyKeyResolver() {
      return new DefaultIdempotencyKeyResolver();
    }

    /** In-memory {@link IdempotencyStore} default. Consumer Redis / JPA 어댑터 wire 시 양보. */
    @Bean
    @ConditionalOnMissingBean(IdempotencyStore.class)
    IdempotencyStore inMemoryIdempotencyStore() {
      return new InMemoryIdempotencyStore();
    }
  }

  /** Phase 6.7 task #9 — NotificationLog audit (0.0.5 NotificationLogService 흡수). */
  @Configuration(proxyBeanMethods = false)
  static class LogBeans {

    /** In-memory {@link NotificationLogService} default. Consumer JPA-backed 어댑터 wire 시 양보. */
    @Bean
    @ConditionalOnMissingBean(NotificationLogService.class)
    NotificationLogService inMemoryNotificationLogService() {
      return new InMemoryNotificationLogService();
    }
  }
}
