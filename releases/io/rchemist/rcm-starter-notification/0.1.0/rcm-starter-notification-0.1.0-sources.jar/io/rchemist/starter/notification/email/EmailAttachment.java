/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.email;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Email 첨부파일 — 파일명 + 바이너리 + MIME contentType.
 *
 * <p>{@code data} = byte[] (immutable copy 강제 — Records compact constructor 에서 방어).
 * 큰 첨부 (수 MB+) 는 {@link io.rchemist.starter.notification.outbox.NotificationOutbox} 적재
 * 영역 외 — Storage starter (Phase 6.8) 의 presigned URL 권장.
 **/
public record EmailAttachment(String filename, byte[] data, String contentType) {

  public EmailAttachment {
    Objects.requireNonNull(filename, "filename required");
    Objects.requireNonNull(data, "data required");
    Objects.requireNonNull(contentType, "contentType required");
    if (filename.isBlank()) {
      throw new IllegalArgumentException("filename cannot be blank");
    }
    data = data.clone();
  }

  @Override
  public byte[] data() {
    return data.clone();
  }
}
