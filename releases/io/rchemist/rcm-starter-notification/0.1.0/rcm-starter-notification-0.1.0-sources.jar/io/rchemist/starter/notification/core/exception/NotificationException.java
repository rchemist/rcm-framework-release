/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core.exception;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 발송 RuntimeException base — 모든 notification 영역 예외의 root.
 *
 * <p>비재시도 실패 (validation / 권한 / config 누락 등) 는 본 예외 또는 sub-class throw.
 * 재시도 가능 실패 ({@link io.rchemist.starter.notification.core.NotificationProvider} 가
 * carrier 5xx / 네트워크 timeout 등) 는 {@link
 * io.rchemist.starter.notification.core.NotificationResult#failed} 로 반환.
 **/
public class NotificationException extends RuntimeException {

  public NotificationException(String message) {
    super(message);
  }

  public NotificationException(String message, Throwable cause) {
    super(message, cause);
  }
}
