/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.email;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 이메일 본문 contentType — TEXT (plain) / HTML.
 *
 * <p>multipart 자동 = {@link EmailAttachment} 첨부 시 SmtpEmailProvider 가 multipart/mixed 자동
 * 적용. {@code contentType} 자체는 본문 영역 (text/plain vs text/html).
 **/
public enum EmailContentType {

  /** text/plain. */
  TEXT,

  /** text/html. */
  HTML
}
