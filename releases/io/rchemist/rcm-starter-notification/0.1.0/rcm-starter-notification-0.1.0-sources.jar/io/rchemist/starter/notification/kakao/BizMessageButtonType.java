/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage 버튼 type — KakaoTalk Bizmessage 콘솔 매트릭스 정합.
 *
 * <p>
 * <ul>
 *   <li>{@link #WL} — Web Link (외부 URL 이동)</li>
 *   <li>{@link #AL} — App Link (앱 deep link, iOS / Android scheme)</li>
 *   <li>{@link #DS} — Delivery Search (배송 조회)</li>
 *   <li>{@link #BK} — Bot Keyword (챗봇 keyword 발화)</li>
 *   <li>{@link #MD} — Message Delivery (전화 걸기)</li>
 *   <li>{@link #CA} — Channel Add (Plus 친구 추가 — FriendTalk 한정)</li>
 * </ul>
 **/
public enum BizMessageButtonType {
  WL,
  AL,
  DS,
  BK,
  MD,
  CA
}
