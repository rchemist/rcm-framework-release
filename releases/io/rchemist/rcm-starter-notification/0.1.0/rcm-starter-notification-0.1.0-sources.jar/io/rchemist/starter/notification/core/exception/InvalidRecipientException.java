/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core.exception;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 수신자 주소 (이메일 / 전화번호 / KakaoTalk 친구토큰 / FCM token) 형식 부정 — 비재시도 실패.
 *
 * <p>Provider 의 send 진입 직전 validation 에서 발견 → 본 예외 throw → 호출자 (Dispatcher)
 * 가 fail-loud 전파. Bean Validation 의 {@code MethodArgumentNotValidException} 처리는 별도
 * 영역 (Phase 2 ProblemDetail 단독 정책 정합).
 **/
public class InvalidRecipientException extends NotificationException {

  public InvalidRecipientException(String message) {
    super(message);
  }

  public InvalidRecipientException(String message, Throwable cause) {
    super(message, cause);
  }
}
