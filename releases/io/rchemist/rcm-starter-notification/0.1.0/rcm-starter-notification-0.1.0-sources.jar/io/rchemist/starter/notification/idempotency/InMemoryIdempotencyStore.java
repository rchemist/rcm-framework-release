/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.idempotency;

import io.rchemist.starter.notification.core.NotificationResult;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link IdempotencyStore} — ConcurrentHashMap 기반 default.
 *
 * <p>한계:
 * <ul>
 *   <li>재시작 시 손실 (durability 0)</li>
 *   <li>단일 instance 한정 — 다중 instance 환경에서는 Redis / JPA 어댑터 필수</li>
 * </ul>
 **/
public class InMemoryIdempotencyStore implements IdempotencyStore {

  private final ConcurrentMap<String, NotificationResult> store = new ConcurrentHashMap<>();

  @Override
  public Optional<NotificationResult> get(String key) {
    Objects.requireNonNull(key, "key required");
    return Optional.ofNullable(store.get(key));
  }

  @Override
  public void put(String key, NotificationResult result) {
    Objects.requireNonNull(key, "key required");
    Objects.requireNonNull(result, "result required");
    store.put(key, result);
  }
}
