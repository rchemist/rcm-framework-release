/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage type — AlimTalk (정보성) / FriendTalk (광고성).
 *
 * <p>
 * <ul>
 *   <li>{@link #ALIM_TALK} — 정보성 (주문 확인 / 배송 안내 / 인증번호 등). 사전 등록 템플릿 필수
 *       (KakaoTalk Bizmessage 콘솔 승인). 광고성 표현 금지</li>
 *   <li>{@link #FRIEND_TALK} — 광고성. 사용자가 Plus 친구 추가 필요. 템플릿 자유 (이미지 / 동영상
 *       / 광고 표기 의무)</li>
 * </ul>
 **/
public enum BizMessageType {

  /** 정보성 알림톡 — 사전 등록 템플릿. */
  ALIM_TALK,

  /** 광고성 친구톡 — Plus 친구 추가 사용자만. */
  FRIEND_TALK
}
