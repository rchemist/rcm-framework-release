/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.sms;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationType;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SMS / LMS / MMS 발송 요청 — 수신번호 + 발신번호 + 본문 + 제목 (LMS/MMS) + messageType.
 *
 * <p>component name {@code messageType} = {@link SmsType} ({@code Notification.type()} 의
 * channel-level enum 과 중복 회피). channel-level type 은 {@link #type()} = SMS 고정.
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>{@code to} / {@code from} = E.164 또는 한국 표준 (010-1234-5678) 모두 OK — Provider
 *       구현체가 carrier 별 정규화. {@code rcm-starter-kr} 의 {@code PhoneNumberFormatter} 활용
 *       권장</li>
 *   <li>{@code text} = 본문 (UTF-8). carrier 가 EUC-KR 변환 + 길이 검증</li>
 *   <li>{@code title} = LMS/MMS 제목 (40 byte / 한글 20 자 이하 carrier 표준). SMS 는 null OK</li>
 *   <li>{@code messageType} = {@link SmsType} (Consumer 명시 → carrier 단가 결정)</li>
 * </ul>
 **/
public record SmsNotification(
    String to, String from, String text, String title, SmsType messageType)
    implements Notification {

  public SmsNotification {
    Objects.requireNonNull(to, "to required");
    Objects.requireNonNull(from, "from required");
    Objects.requireNonNull(text, "text required");
    Objects.requireNonNull(messageType, "messageType required");
    if (to.isBlank()) {
      throw new IllegalArgumentException("to cannot be blank");
    }
    if (from.isBlank()) {
      throw new IllegalArgumentException("from cannot be blank");
    }
  }

  @Override
  public NotificationType type() {
    return NotificationType.SMS;
  }

  /** 단문 SMS 편의 factory — title 없음, messageType SMS. */
  public static SmsNotification sms(String to, String from, String text) {
    return new SmsNotification(to, from, text, null, SmsType.SMS);
  }

  /** 장문 LMS 편의 factory — title + 본문, messageType LMS. */
  public static SmsNotification lms(String to, String from, String title, String text) {
    return new SmsNotification(to, from, text, title, SmsType.LMS);
  }
}
