/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link DeadLetterQueue} — ConcurrentLinkedQueue 기반 default.
 *
 * <p>재시작 시 손실 — production 환경은 JPA-backed / Kafka DLQ 권장.
 **/
public class InMemoryDeadLetterQueue implements DeadLetterQueue {

  private final ConcurrentLinkedQueue<OutboxEntry> queue = new ConcurrentLinkedQueue<>();

  @Override
  public void push(OutboxEntry entry) {
    Objects.requireNonNull(entry, "entry required");
    queue.add(entry);
  }

  @Override
  public List<OutboxEntry> drain() {
    List<OutboxEntry> drained = new ArrayList<>();
    OutboxEntry e;
    while ((e = queue.poll()) != null) {
      drained.add(e);
    }
    return drained;
  }

  @Override
  public int size() {
    return queue.size();
  }
}
