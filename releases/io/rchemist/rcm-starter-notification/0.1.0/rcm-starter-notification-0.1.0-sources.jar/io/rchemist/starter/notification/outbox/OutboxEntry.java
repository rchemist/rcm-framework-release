/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationStatus;
import java.time.Instant;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox 적재 단위 — Notification 1 건 + 발송 라이프사이클 메타.
 *
 * <p>
 * <ul>
 *   <li>{@code id} = outbox 자체 식별자 (UUID 또는 JPA generated)</li>
 *   <li>{@code notification} = 발송 요청 본문</li>
 *   <li>{@code attempts} = 시도 누적 횟수 (0 = 미발송)</li>
 *   <li>{@code status} = {@link NotificationStatus} (PENDING → SENDING → SENT / RETRYING /
 *       DEAD)</li>
 *   <li>{@code lastError} = 최근 실패 reason (null = 정상)</li>
 *   <li>{@code nextAttemptAt} = 다음 시도 시각 (RETRYING 시 backoff 적용)</li>
 * </ul>
 **/
public record OutboxEntry(
    String id,
    Notification notification,
    int attempts,
    NotificationStatus status,
    String lastError,
    Instant nextAttemptAt) {

  public OutboxEntry {
    Objects.requireNonNull(id, "id required");
    Objects.requireNonNull(notification, "notification required");
    Objects.requireNonNull(status, "status required");
    Objects.requireNonNull(nextAttemptAt, "nextAttemptAt required");
    if (attempts < 0) {
      throw new IllegalArgumentException("attempts cannot be negative");
    }
  }

  /** SENDING 상태로 전환된 새 인스턴스 (attempts +1). */
  public OutboxEntry markSending() {
    return new OutboxEntry(
        id, notification, attempts + 1, NotificationStatus.SENDING, lastError, nextAttemptAt);
  }

  /** SENT 상태로 전환된 새 인스턴스. */
  public OutboxEntry markSent() {
    return new OutboxEntry(id, notification, attempts, NotificationStatus.SENT, null, nextAttemptAt);
  }

  /** RETRYING 상태로 전환 + 다음 시도 시각 + 실패 reason. */
  public OutboxEntry markRetrying(String error, Instant nextAttempt) {
    return new OutboxEntry(
        id, notification, attempts, NotificationStatus.RETRYING, error, nextAttempt);
  }

  /** DEAD 상태로 전환 + 실패 reason. */
  public OutboxEntry markDead(String error) {
    return new OutboxEntry(id, notification, attempts, NotificationStatus.DEAD, error, nextAttemptAt);
  }
}
