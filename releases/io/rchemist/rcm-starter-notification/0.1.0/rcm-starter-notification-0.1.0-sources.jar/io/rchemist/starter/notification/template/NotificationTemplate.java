/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.template;

import java.util.Locale;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 템플릿 — code + locale 별 subject / body 보존. 채널 무관 (Email subject + body / SMS LMS
 * title + text / Push title + body 모두 적용).
 *
 * <p>{@code subject} = 헤드라인 (Email subject / LMS title / Push title — 채널 별 의미). null 가능
 * (단순 SMS 본문 만 발송 시).
 *
 * <p>{@code body} = 본문 — 변수 표기는 {@code {{varName}}} ({@link TemplateRenderer} 가 substitution).
 *
 * <p>{@code locale} = 다국어 자동 분기 ({@link NotificationTemplateRegistry} 가
 * code+locale lookup, fallback default locale).
 **/
public record NotificationTemplate(String code, Locale locale, String subject, String body) {

  public NotificationTemplate {
    Objects.requireNonNull(code, "code required");
    Objects.requireNonNull(locale, "locale required");
    Objects.requireNonNull(body, "body required");
    if (code.isBlank()) {
      throw new IllegalArgumentException("code cannot be blank");
    }
  }
}
