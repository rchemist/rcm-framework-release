/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core.exception;

import io.rchemist.starter.notification.core.NotificationType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Dispatcher 가 발송 type 에 해당하는 Provider 를 찾지 못함 — Consumer 가 carrier 어댑터
 * ({@code NaverCloudSmsProvider} 등) 를 {@code @Component} 로 wire 하지 않은 시나리오.
 *
 * <p>fail-loud baseline — silent fail 영구 차단 (메모리 {@code feedback_no_feature_regression}
 * 정합 / 0.0.5 의 silent catch 계열 재발 방지).
 **/
public class ProviderUnavailableException extends NotificationException {

  private final NotificationType type;

  public ProviderUnavailableException(NotificationType type) {
    super(
        "No NotificationProvider registered for type "
            + type
            + ". Wire a Provider bean (e.g. @Component class NaverCloudSmsProvider"
            + " implements NotificationProvider<SmsNotification>).");
    this.type = type;
  }

  public NotificationType type() {
    return type;
  }
}
