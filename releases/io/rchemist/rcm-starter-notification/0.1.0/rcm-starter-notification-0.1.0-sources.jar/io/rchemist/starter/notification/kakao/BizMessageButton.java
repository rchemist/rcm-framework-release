/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage 버튼 — type 별 url / name 매트릭스.
 *
 * <p>편의 factory:
 * <ul>
 *   <li>{@link #webLink(String, String)} — type WL + url</li>
 *   <li>{@link #appLink(String, String, String)} — type AL + iOS scheme + Android scheme</li>
 *   <li>{@link #channelAdd(String)} — type CA, FriendTalk 한정 (Plus 친구 추가)</li>
 *   <li>{@link #call(String, String)} — type MD + 전화번호</li>
 * </ul>
 **/
public record BizMessageButton(
    BizMessageButtonType buttonType, String name, String url, String iosUrl, String androidUrl) {

  public BizMessageButton {
    Objects.requireNonNull(buttonType, "buttonType required");
    Objects.requireNonNull(name, "name required");
    if (name.isBlank()) {
      throw new IllegalArgumentException("name cannot be blank");
    }
  }

  /** Web link 버튼 (type WL). */
  public static BizMessageButton webLink(String name, String url) {
    Objects.requireNonNull(url, "url required");
    return new BizMessageButton(BizMessageButtonType.WL, name, url, null, null);
  }

  /** App link 버튼 (type AL) — iOS scheme + Android scheme. */
  public static BizMessageButton appLink(String name, String iosUrl, String androidUrl) {
    return new BizMessageButton(BizMessageButtonType.AL, name, null, iosUrl, androidUrl);
  }

  /** Channel add 버튼 (type CA) — FriendTalk 한정 Plus 친구 추가. */
  public static BizMessageButton channelAdd(String name) {
    return new BizMessageButton(BizMessageButtonType.CA, name, null, null, null);
  }

  /** 전화 걸기 버튼 (type MD). */
  public static BizMessageButton call(String name, String phoneNumber) {
    Objects.requireNonNull(phoneNumber, "phoneNumber required");
    return new BizMessageButton(BizMessageButtonType.MD, name, phoneNumber, null, null);
  }
}
