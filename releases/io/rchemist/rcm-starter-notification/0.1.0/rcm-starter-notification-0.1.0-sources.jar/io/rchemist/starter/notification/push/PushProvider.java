/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.push;

import io.rchemist.starter.notification.core.NotificationProvider;
import io.rchemist.starter.notification.core.NotificationType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Push channel SPI — FCM / APNS / WEB_PUSH 공통.
 *
 * <p>Consumer 측 어댑터 baseline 패턴:
 * <ul>
 *   <li>FCM — {@code @Component class FcmPushProvider implements PushProvider} +
 *       {@code com.google.firebase:firebase-admin} 의존 + service account JSON</li>
 *   <li>APNS — {@code apns-jakarta} 또는 {@code pushy} 라이브러리 + .p8 인증서</li>
 *   <li>Web Push — {@code web-push-libs/webpush-java} + VAPID key</li>
 * </ul>
 *
 * <p>framework default = {@link NoopPushProvider} fail-loud (어댑터 미설정 차단). Push 는 OS
 * SDK 의존 폭이 커서 framework 본체에 concrete impl 불포함 — 모든 Consumer 가 직접 어댑터 wire.
 **/
public interface PushProvider extends NotificationProvider<PushNotification> {

  @Override
  default NotificationType type() {
    return NotificationType.PUSH;
  }
}
