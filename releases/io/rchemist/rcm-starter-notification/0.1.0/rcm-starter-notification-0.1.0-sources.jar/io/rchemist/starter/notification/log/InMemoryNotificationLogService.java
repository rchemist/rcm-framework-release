/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link NotificationLogService} — synchronized List 기반 default.
 *
 * <p>한계: 재시작 손실 + 단일 instance. production 은 JPA-backed 어댑터 권장.
 **/
public class InMemoryNotificationLogService implements NotificationLogService {

  private final List<NotificationLog> logs = Collections.synchronizedList(new ArrayList<>());

  @Override
  public void record(NotificationLog log) {
    Objects.requireNonNull(log, "log required");
    logs.add(log);
  }

  @Override
  public Optional<NotificationLog> findByIdempotencyKey(String idempotencyKey) {
    Objects.requireNonNull(idempotencyKey, "idempotencyKey required");
    synchronized (logs) {
      return logs.stream()
          .filter(l -> idempotencyKey.equals(l.idempotencyKey()))
          .findFirst();
    }
  }

  @Override
  public List<NotificationLog> findRecent(int limit) {
    if (limit < 0) {
      throw new IllegalArgumentException("limit must be >= 0");
    }
    synchronized (logs) {
      int from = Math.max(0, logs.size() - limit);
      return List.copyOf(logs.subList(from, logs.size()));
    }
  }

  /** 진단용 — 전체 로그 snapshot. */
  public List<NotificationLog> snapshot() {
    synchronized (logs) {
      return List.copyOf(logs);
    }
  }
}
