/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 발송 carrier SPI — Email / SMS / KakaoTalk Bizmessage / Push 4 채널 공통 인터페이스.
 *
 * <p>Consumer 구현 패턴:
 * <pre>{@code
 * @Component
 * class NaverCloudSmsProvider implements NotificationProvider<SmsNotification> {
 *   public String name() { return "naver-cloud-sms"; }
 *   public NotificationType type() { return NotificationType.SMS; }
 *   public NotificationResult send(SmsNotification sms) {
 *     // Naver Cloud SENS API 호출
 *     return NotificationResult.sent(name(), responseMessageId);
 *   }
 * }
 * }</pre>
 *
 * <p>{@link NotificationDispatcher} 가 Spring context 의 모든 {@code NotificationProvider}
 * bean 을 자동 수집 + {@link #type()} 기반 라우팅. 같은 type 에 다중 provider 등록 시 task #8
 * Outbox 의 routing strategy 가 결정 (failover / round-robin / weighted).
 *
 * @param <T> 본 provider 가 발송하는 알림 채널 type
 **/
public interface NotificationProvider<T extends Notification> {

  /** carrier 식별 — 다중 provider 등록 시 구분 (audit log 의 {@code providerName} 영역). */
  String name();

  /** 채널 분기 — Dispatcher 라우팅 키. */
  NotificationType type();

  /**
   * 발송 시도. 성공 시 {@link NotificationResult#sent}, 재시도 후보 실패 시
   * {@link NotificationResult#failed}, 비재시도 실패 (validation / 권한 등) 는
   * {@link io.rchemist.starter.notification.core.exception.NotificationException} throw.
   */
  NotificationResult send(T notification);
}
