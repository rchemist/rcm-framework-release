/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.log;

import io.rchemist.starter.notification.core.NotificationStatus;
import io.rchemist.starter.notification.core.NotificationType;
import java.time.Instant;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 발송 audit log entry — 1 건당 시도 결과 보존.
 *
 * <p>compliance / 추적성 영역:
 * <ul>
 *   <li>{@code recipient} = 수신자 식별자 (이메일 / 전화번호 / KakaoTalk 친구토큰 / FCM token).
 *       PII 마스킹은 Consumer 책임 영역 (e.g. "01****5678") — JPA-backed 어댑터에서 적용 권장</li>
 *   <li>{@code idempotencyKey} = 중복 발송 추적 키 (재시도 시 같은 key 로 다중 entry 가능)</li>
 *   <li>{@code providerMessageId} = carrier 가 부여한 추적 ID (delivery report 조회용)</li>
 *   <li>{@code error} = 실패 시 reason — 성공 시 null</li>
 * </ul>
 *
 * <p>0.0.5 의 {@code NotificationLogService} 패턴 흡수 + 표준화.
 **/
public record NotificationLog(
    String id,
    Instant occurredAt,
    NotificationType type,
    String recipient,
    NotificationStatus status,
    String providerName,
    String providerMessageId,
    String idempotencyKey,
    String error) {

  public NotificationLog {
    Objects.requireNonNull(id, "id required");
    Objects.requireNonNull(occurredAt, "occurredAt required");
    Objects.requireNonNull(type, "type required");
    Objects.requireNonNull(status, "status required");
  }
}
