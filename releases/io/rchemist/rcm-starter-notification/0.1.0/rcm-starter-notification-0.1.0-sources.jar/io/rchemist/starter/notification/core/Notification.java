/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 발송 marker — 4 채널 (Email / SMS / KakaoTalk Bizmessage / Push) 공통 baseline.
 *
 * <p>각 채널 Records (`EmailNotification` / `SmsNotification` / `BizMessageNotification` /
 * `PushNotification`) 가 본 interface 를 implement. {@link NotificationDispatcher} 가
 * {@link #type()} 기반으로 적절한 {@link NotificationProvider} 로 라우팅.
 *
 * <p>Phase 6.7 task #6 이후 sealed interface 로 격상 검토 (모든 4 채널 Records 가 존재 시점).
 **/
public interface Notification {

  /** 채널 식별 — Dispatcher 라우팅 + Audit Log + Idempotency 키 결정 baseline. */
  NotificationType type();
}
