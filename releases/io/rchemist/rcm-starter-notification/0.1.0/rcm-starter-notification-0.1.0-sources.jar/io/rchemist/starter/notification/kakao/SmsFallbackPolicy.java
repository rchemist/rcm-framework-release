/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

import io.rchemist.starter.notification.sms.SmsType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage 발송 실패 시 SMS 자동 fallback policy — 사용자가 KakaoTalk 미수신 (앱
 * 미설치 / 로그아웃 24h 경과 / 차단 등) 시 SMS / LMS 로 대체 발송.
 *
 * <p>편의 factory:
 * <ul>
 *   <li>{@link #disabled()} — fallback 비활성</li>
 *   <li>{@link #sms(String)} — SMS 단문 fallback (90byte 이하)</li>
 *   <li>{@link #lms(String, String)} — LMS 장문 fallback (title + 본문)</li>
 * </ul>
 **/
public record SmsFallbackPolicy(boolean enabled, String text, String title, SmsType messageType) {

  /** fallback 비활성 — Provider 가 KakaoTalk 실패 시 그대로 fail. */
  public static SmsFallbackPolicy disabled() {
    return new SmsFallbackPolicy(false, null, null, null);
  }

  /** SMS 단문 fallback. */
  public static SmsFallbackPolicy sms(String text) {
    return new SmsFallbackPolicy(true, text, null, SmsType.SMS);
  }

  /** LMS 장문 fallback (title + 본문). */
  public static SmsFallbackPolicy lms(String title, String text) {
    return new SmsFallbackPolicy(true, text, title, SmsType.LMS);
  }
}
