/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.push;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Push 플랫폼 — Provider 분기 매트릭스. carrier 별 SDK 의존 분리.
 *
 * <p>
 * <ul>
 *   <li>{@link #FCM} — Firebase Cloud Messaging (Android + iOS + Web 통합 — 권장)</li>
 *   <li>{@link #APNS} — Apple Push Notification Service (iOS only, FCM 미사용 시)</li>
 *   <li>{@link #WEB_PUSH} — Web Push Protocol (RFC 8030, VAPID, 브라우저)</li>
 * </ul>
 **/
public enum PushPlatform {
  FCM,
  APNS,
  WEB_PUSH
}
