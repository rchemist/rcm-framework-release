/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.email;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationType;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Email 발송 요청 — to / cc / bcc / from / subject / body / contentType / attachments.
 *
 * <p>compact constructor 에서 immutable copy + null safety. 다중 수신자 ({@code to} list) +
 * cc / bcc + multipart (HTML 본문 + 첨부) baseline. 250 자리수 / SMTP 헤더 충돌 등의 검증은
 * {@link EmailProvider} 구현체가 carrier 별 적용 (e.g. SMTP RFC 5321 / Mailgun API 제약).
 *
 * <p>편의 factory:
 * <ul>
 *   <li>{@link #simple} — 단일 수신자 + plain text + 기본 발신자</li>
 *   <li>{@link #html} — 단일 수신자 + HTML 본문</li>
 * </ul>
 **/
public record EmailNotification(
    List<String> to,
    List<String> cc,
    List<String> bcc,
    String from,
    String subject,
    String body,
    EmailContentType contentType,
    List<EmailAttachment> attachments)
    implements Notification {

  public EmailNotification {
    Objects.requireNonNull(to, "to list required");
    if (to.isEmpty()) {
      throw new IllegalArgumentException("to list cannot be empty");
    }
    Objects.requireNonNull(subject, "subject required");
    Objects.requireNonNull(body, "body required");
    to = List.copyOf(to);
    cc = cc == null ? List.of() : List.copyOf(cc);
    bcc = bcc == null ? List.of() : List.copyOf(bcc);
    contentType = contentType == null ? EmailContentType.TEXT : contentType;
    attachments = attachments == null ? List.of() : List.copyOf(attachments);
  }

  @Override
  public NotificationType type() {
    return NotificationType.EMAIL;
  }

  /** 단일 수신자 plain text — 기본 발신자 ({@code platform.notification.email.default-from}) 사용. */
  public static EmailNotification simple(String to, String subject, String body) {
    return new EmailNotification(
        List.of(to), List.of(), List.of(), null, subject, body, EmailContentType.TEXT, List.of());
  }

  /** 단일 수신자 HTML — 기본 발신자 사용. */
  public static EmailNotification html(String to, String subject, String htmlBody) {
    return new EmailNotification(
        List.of(to),
        List.of(),
        List.of(),
        null,
        subject,
        htmlBody,
        EmailContentType.HTML,
        List.of());
  }
}
