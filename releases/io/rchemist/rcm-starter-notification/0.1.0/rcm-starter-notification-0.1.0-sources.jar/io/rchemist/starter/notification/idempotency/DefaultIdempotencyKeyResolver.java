/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.idempotency;

import io.rchemist.starter.notification.core.Notification;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SHA-256 기반 default {@link IdempotencyKeyResolver} — type + Records toString() hash 의 앞
 * 16 hex (64-bit) prefix.
 *
 * <p>특성:
 * <ul>
 *   <li>같은 Notification 입력 → 같은 key (Records toString 의 deterministic 정합)</li>
 *   <li>다른 입력 → SHA-256 collision 확률 사실상 0 (16 hex = 64-bit, 평균 2^32 시도 시 1 충돌)</li>
 *   <li>key 길이 16 — DB unique index / Redis key 효율</li>
 * </ul>
 *
 * <p>비즈니스 키 (e.g. orderId + eventType) 가 자연스러운 시나리오는 Consumer override 권장.
 **/
public class DefaultIdempotencyKeyResolver implements IdempotencyKeyResolver {

  @Override
  public String resolve(Notification notification) {
    String input = notification.type().name() + ":" + notification.toString();
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
      StringBuilder hex = new StringBuilder(16);
      for (int i = 0; i < 8; i++) {
        hex.append(String.format("%02x", hash[i]));
      }
      return hex.toString();
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 not available", e);
    }
  }
}
