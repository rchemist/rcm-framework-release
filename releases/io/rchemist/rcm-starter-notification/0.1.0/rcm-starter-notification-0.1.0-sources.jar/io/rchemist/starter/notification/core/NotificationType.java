/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 채널 enum — Dispatcher 라우팅 키 + carrier provider 매트릭스 분기.
 *
 * <p>4 채널 (Email / SMS / KakaoTalk Bizmessage / Push) baseline. Phase 6.7 본문 + 향후
 * 채널 추가는 enum 확장 + Provider SPI 새 구현으로 자연 확장.
 **/
public enum NotificationType {

  /** 이메일 — SMTP / Mailgun / Sendgrid carrier. */
  EMAIL,

  /** SMS / LMS / MMS — 한국 carrier (Naver/NHN/Coolsms/Aligo) + Twilio. */
  SMS,

  /** KakaoTalk Bizmessage (AlimTalk / FriendTalk). */
  BIZ_MESSAGE,

  /** Mobile / Web Push (FCM / APNs / Web Push). */
  PUSH
}
