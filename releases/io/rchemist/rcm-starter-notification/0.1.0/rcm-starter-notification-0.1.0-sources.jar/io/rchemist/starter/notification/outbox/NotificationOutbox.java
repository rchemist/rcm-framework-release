/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import io.rchemist.starter.notification.core.Notification;
import java.time.Instant;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Notification Outbox SPI — 발송 안전성 baseline (durability + at-least-once delivery).
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link InMemoryNotificationOutbox} — 단순 / 테스트 용 (재시작 시 손실). default</li>
 *   <li>JPA-backed — Consumer 가 entity ({@code NotificationOutboxEntity}) + Repository 어댑터
 *       구현 (production 권장 — DB 트랜잭션 + 재시작 안전)</li>
 *   <li>Kafka / RabbitMQ-backed — 분산 외부 큐 어댑터</li>
 * </ul>
 *
 * <p>Decision #8 indexer outbox 메커니즘 정합 — 동일한 *append-then-publish* 패턴.
 **/
public interface NotificationOutbox {

  /** 새 발송 요청 적재 — status = PENDING, attempts = 0, nextAttemptAt = now. */
  String append(Notification notification);

  /**
   * 발송 가능한 다음 entry 폴링 — status PENDING/RETRYING + nextAttemptAt <= now. 반환 시
   * SENDING 상태로 전환 (atomic, claim semantic).
   */
  Optional<OutboxEntry> pollNext();

  /** 발송 성공 — SENT 상태 전환. */
  void markSent(String id);

  /** 재시도 후보 실패 — RETRYING 상태 + nextAttemptAt 적용. */
  void markRetrying(String id, String error, Instant nextAttemptAt);

  /** 최종 실패 — DEAD 상태 (Consumer 가 DLQ 적재 결정). */
  void markDead(String id, String error);

  /** 진단 / 모니터링 — 적재된 entry 수 (모든 status 포함). */
  int size();

  /** 진단 — id 별 entry 조회. */
  Optional<OutboxEntry> findById(String id);
}
