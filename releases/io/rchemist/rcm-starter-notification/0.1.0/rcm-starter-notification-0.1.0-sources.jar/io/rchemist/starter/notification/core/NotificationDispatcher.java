/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.core;

import io.rchemist.starter.notification.core.exception.ProviderUnavailableException;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 발송 진입점 facade — {@link Notification#type()} 기반 라우팅 후 적절한
 * {@link NotificationProvider} 호출.
 *
 * <p>Consumer 사용:
 * <pre>{@code
 * @Service
 * class OrderService {
 *   private final NotificationDispatcher dispatcher;
 *
 *   void onOrderConfirmed(Order order) {
 *     dispatcher.send(new EmailNotification(order.email(), "주문 확인", body));
 *   }
 * }
 * }</pre>
 *
 * <p>다중 Provider 등록 시 (e.g. 2 개 SMS carrier 등록) 의 routing 전략 (failover / round-robin
 * / weighted) 은 task #8 Outbox 영역 — 본 dispatcher 는 baseline 으로 *마지막 등록 wins*.
 *
 * <p>Provider 누락 시 {@link ProviderUnavailableException} fail-loud (silent fail 영구 차단).
 **/
public class NotificationDispatcher {

  private final Map<NotificationType, NotificationProvider<? extends Notification>> providers;

  public NotificationDispatcher(List<? extends NotificationProvider<? extends Notification>> providers) {
    Map<NotificationType, NotificationProvider<? extends Notification>> map =
        new EnumMap<>(NotificationType.class);
    for (NotificationProvider<? extends Notification> p : providers) {
      map.put(p.type(), p);
    }
    this.providers = Map.copyOf(map);
  }

  /** 발송 — type 라우팅 + Provider 호출. */
  @SuppressWarnings("unchecked")
  public <T extends Notification> NotificationResult send(T notification) {
    NotificationProvider<? extends Notification> provider = providers.get(notification.type());
    if (provider == null) {
      throw new ProviderUnavailableException(notification.type());
    }
    return ((NotificationProvider<T>) provider).send(notification);
  }

  /** 등록된 type 매트릭스 — 진단 / actuator 영역. */
  public java.util.Set<NotificationType> registeredTypes() {
    return providers.keySet();
  }
}
