/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.email;

import io.rchemist.starter.notification.core.NotificationResult;
import io.rchemist.starter.notification.core.exception.InvalidRecipientException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.UUID;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.MailException;
import org.springframework.mail.MailParseException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring {@link JavaMailSender} 기반 SMTP Email provider — default {@link EmailProvider}.
 *
 * <p>책임:
 * <ul>
 *   <li>{@link MimeMessage} + {@link MimeMessageHelper} 로 multipart / HTML / 첨부 자동
 *       조립 (charset UTF-8)</li>
 *   <li>{@code from} 부재 시 {@code platform.notification.email.default-from} 활용 (둘 다
 *       부재면 {@link InvalidRecipientException})</li>
 *   <li>{@link MailParseException} / {@link MessagingException} = 비재시도 → InvalidRecipient</li>
 *   <li>그 외 {@link MailException} = 재시도 후보 → {@link NotificationResult#failed}</li>
 * </ul>
 *
 * <p>Consumer 가 자체 EmailProvider bean 정의 시 {@code @ConditionalOnMissingBean} 으로 양보.
 **/
public class SmtpEmailProvider implements EmailProvider {

  private static final String NAME = "smtp";

  private final JavaMailSender mailSender;
  private final String defaultFrom;

  public SmtpEmailProvider(JavaMailSender mailSender, String defaultFrom) {
    this.mailSender = mailSender;
    this.defaultFrom = defaultFrom;
  }

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public NotificationResult send(EmailNotification email) {
    String fromAddress = resolveFrom(email);

    MimeMessage message = mailSender.createMimeMessage();
    try {
      MimeMessageHelper helper =
          new MimeMessageHelper(message, !email.attachments().isEmpty(), "UTF-8");
      helper.setFrom(fromAddress);
      helper.setTo(email.to().toArray(new String[0]));
      if (!email.cc().isEmpty()) {
        helper.setCc(email.cc().toArray(new String[0]));
      }
      if (!email.bcc().isEmpty()) {
        helper.setBcc(email.bcc().toArray(new String[0]));
      }
      helper.setSubject(email.subject());
      helper.setText(email.body(), email.contentType() == EmailContentType.HTML);
      for (EmailAttachment attachment : email.attachments()) {
        helper.addAttachment(
            attachment.filename(),
            new ByteArrayResource(attachment.data()),
            attachment.contentType());
      }
    } catch (MessagingException e) {
      throw new InvalidRecipientException("Invalid email message: " + e.getMessage(), e);
    }

    try {
      mailSender.send(message);
    } catch (MailParseException e) {
      throw new InvalidRecipientException("Email parse error: " + e.getMessage(), e);
    } catch (MailException e) {
      return NotificationResult.failed(NAME, e.getMessage());
    }

    return NotificationResult.sent(NAME, resolveMessageId(message));
  }

  private String resolveFrom(EmailNotification email) {
    if (email.from() != null && !email.from().isBlank()) {
      return email.from();
    }
    if (defaultFrom != null && !defaultFrom.isBlank()) {
      return defaultFrom;
    }
    throw new InvalidRecipientException(
        "From address not provided. Set EmailNotification.from() or"
            + " platform.notification.email.default-from.");
  }

  private String resolveMessageId(MimeMessage message) {
    try {
      String header = message.getMessageID();
      if (header != null && !header.isBlank()) {
        return header;
      }
    } catch (MessagingException ignored) {
      // best-effort — fall back to UUID
    }
    return UUID.randomUUID().toString();
  }
}
