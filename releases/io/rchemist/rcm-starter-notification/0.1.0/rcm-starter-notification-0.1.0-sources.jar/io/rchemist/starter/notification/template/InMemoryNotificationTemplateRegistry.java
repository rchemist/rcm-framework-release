/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.template;

import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link NotificationTemplateRegistry} default — Map 기반 + locale fallback.
 *
 * <p>etymology:
 * <ul>
 *   <li>Consumer 가 Bean configuration 에서 {@code @PostConstruct} 또는 startup runner 로
 *       {@link #register} 호출 — code 별 다국어 등록</li>
 *   <li>{@link #findByCode}: 정확 locale 매치 → fallback default locale → empty</li>
 *   <li>{@link #defaultLocale} = 생성자 인자 (default {@link Locale#KOREAN} — 한국 SI baseline)</li>
 * </ul>
 *
 * <p>thread-safe ({@link ConcurrentHashMap}). 운영 중 hot-reload 영역은 Consumer JPA-backed 어댑터.
 **/
public class InMemoryNotificationTemplateRegistry implements NotificationTemplateRegistry {

  private final Map<String, Map<Locale, NotificationTemplate>> templates = new ConcurrentHashMap<>();
  private final Locale defaultLocale;

  public InMemoryNotificationTemplateRegistry() {
    this(Locale.KOREAN);
  }

  public InMemoryNotificationTemplateRegistry(Locale defaultLocale) {
    this.defaultLocale = Objects.requireNonNull(defaultLocale, "defaultLocale required");
  }

  /** code + locale 별 등록 — 같은 키 재호출 시 덮어쓰기. */
  public void register(NotificationTemplate template) {
    Objects.requireNonNull(template, "template required");
    templates
        .computeIfAbsent(template.code(), c -> new ConcurrentHashMap<>())
        .put(template.locale(), template);
  }

  /** 다중 등록 short-cut. */
  public void registerAll(Collection<NotificationTemplate> all) {
    Objects.requireNonNull(all, "all required");
    all.forEach(this::register);
  }

  @Override
  public Optional<NotificationTemplate> findByCode(String code, Locale locale) {
    Map<Locale, NotificationTemplate> byLocale = templates.get(code);
    if (byLocale == null) {
      return Optional.empty();
    }
    NotificationTemplate exact = byLocale.get(locale);
    if (exact != null) {
      return Optional.of(exact);
    }
    NotificationTemplate fallback = byLocale.get(defaultLocale);
    if (fallback != null) {
      return Optional.of(fallback);
    }
    // 마지막 fallback — 등록된 어떤 locale 이라도
    return byLocale.values().stream().findFirst();
  }

  /** 진단 / 테스트용 — 등록된 code 매트릭스 노출. */
  public Map<String, Map<Locale, NotificationTemplate>> snapshot() {
    Map<String, Map<Locale, NotificationTemplate>> copy = new HashMap<>();
    templates.forEach((code, byLocale) -> copy.put(code, Map.copyOf(byLocale)));
    return Map.copyOf(copy);
  }
}
