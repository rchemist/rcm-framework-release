/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Dead-Letter Queue SPI — 최종 실패 (재시도 횟수 소진 / 비재시도 실패) entry 적재.
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link InMemoryDeadLetterQueue} — ConcurrentLinkedQueue 기반 default</li>
 *   <li>JPA-backed — Consumer 가 entity ({@code NotificationDlqEntity}) + Repository 어댑터</li>
 *   <li>Kafka / SQS DLQ — 분산 외부 큐 어댑터</li>
 * </ul>
 *
 * <p>운영 영역: DLQ 모니터링 + 수동 / 자동 재처리 (drain 후 outbox 재적재).
 **/
public interface DeadLetterQueue {

  /** DLQ 적재. */
  void push(OutboxEntry entry);

  /** DLQ 전수 회수 + 비움 (재처리 영역). */
  List<OutboxEntry> drain();

  /** 진단 / 모니터링. */
  int size();
}
