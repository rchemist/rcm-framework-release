/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.sms;

import io.rchemist.starter.notification.core.NotificationProvider;
import io.rchemist.starter.notification.core.NotificationType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SMS / LMS / MMS channel SPI — {@link NotificationProvider} 의 SMS 특화. 모든 구현은
 * {@link NotificationType#SMS} 반환.
 *
 * <p>한국 carrier slot — Consumer 측 어댑터 baseline 패턴:
 * <ul>
 *   <li>Naver Cloud SENS — {@code @Component class NaverCloudSmsProvider implements SmsProvider}
 *       (REST API + Resilience4j 권장, gjcu 다수 사용)</li>
 *   <li>NHN Cloud — 동일 패턴 (X-Secret-Key + sender 등록 확인)</li>
 *   <li>Coolsms — {@code coolsms-java-sdk} 의존 + apiKey/apiSecret</li>
 *   <li>Aligo — REST API + apiKey/userid</li>
 *   <li>Twilio (해외) — {@code twilio-java} SDK 의존</li>
 * </ul>
 *
 * <p>framework default = {@link NoopSmsProvider} fail-loud (Consumer 어댑터 미설정 → silent fail
 * 영구 차단).
 **/
public interface SmsProvider extends NotificationProvider<SmsNotification> {

  @Override
  default NotificationType type() {
    return NotificationType.SMS;
  }
}
