/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.log;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Notification audit log SPI — 발송 1 건당 1 entry 기록.
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link InMemoryNotificationLogService} — ArrayList 기반 default. 단일 instance + 재시작 손실</li>
 *   <li>JPA-backed — Consumer 가 entity ({@code NotificationLogEntity}, {@code Auditable} marker)
 *       + Repository 어댑터 wire — production 권장</li>
 *   <li>Append-only file / OpenSearch / CloudWatch — 분산 / 장기 보존 영역</li>
 * </ul>
 *
 * <p>0.0.5 {@code NotificationLogService} 패턴 흡수 + Records 표준화.
 **/
public interface NotificationLogService {

  /** audit 적재. */
  void record(NotificationLog log);

  /** idempotency 키 조회 — 부재 시 empty. */
  Optional<NotificationLog> findByIdempotencyKey(String idempotencyKey);

  /** 최근 N 건 조회 — 운영 / 진단 영역. */
  List<NotificationLog> findRecent(int limit);
}
