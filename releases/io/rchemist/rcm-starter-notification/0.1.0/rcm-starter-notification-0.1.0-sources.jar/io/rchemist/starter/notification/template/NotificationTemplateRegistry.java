/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.template;

import java.util.Locale;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 알림 템플릿 저장소 SPI — code + locale 으로 {@link NotificationTemplate} 조회.
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link InMemoryNotificationTemplateRegistry} — Map-backed default. 코드 inline 등록 영역</li>
 *   <li>JPA-backed — Consumer 가 entity (e.g. {@code NotificationTemplateEntity}) + Repository
 *       기반 어댑터 wire (templateCode 변경 시 운영 차원 재배포 회피)</li>
 *   <li>Resource-backed — {@code classpath:templates/<code>_<locale>.txt} 파일 기반 어댑터</li>
 * </ul>
 *
 * <p>locale fallback 정책 — Provider 구현체가 결정 (default {@link InMemoryNotificationTemplateRegistry}
 * 는 요청 locale 부재 시 default locale 로 fallback).
 **/
public interface NotificationTemplateRegistry {

  /**
   * 템플릿 조회 — code + locale.
   *
   * @return 부재 시 {@link Optional#empty()} (Consumer 가 fallback 또는 fail-loud 결정)
   */
  Optional<NotificationTemplate> findByCode(String code, Locale locale);
}
