/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.kakao;

import io.rchemist.starter.notification.core.NotificationProvider;
import io.rchemist.starter.notification.core.NotificationType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * KakaoTalk Bizmessage channel SPI — AlimTalk / FriendTalk 공통.
 *
 * <p>한국 carrier slot — Consumer 측 어댑터 baseline 패턴:
 * <ul>
 *   <li>NHN Cloud Notification — {@code @Component class NhnCloudBizMessageProvider implements
 *       BizMessageProvider} (REST API + accessKey/secretKey + sender 등록)</li>
 *   <li>Solapi (구 Coolsms) — Bizmessage REST API + apiKey/apiSecret</li>
 *   <li>Aligo — KakaoTalk Bizmessage REST API + apiKey</li>
 *   <li>Kakao Bizmessage 직접 (대규모 — 사업자 직계약) — REST API + accessToken</li>
 * </ul>
 *
 * <p>framework default = {@link NoopBizMessageProvider} fail-loud (어댑터 미설정 차단).
 **/
public interface BizMessageProvider extends NotificationProvider<BizMessageNotification> {

  @Override
  default NotificationType type() {
    return NotificationType.BIZ_MESSAGE;
  }
}
