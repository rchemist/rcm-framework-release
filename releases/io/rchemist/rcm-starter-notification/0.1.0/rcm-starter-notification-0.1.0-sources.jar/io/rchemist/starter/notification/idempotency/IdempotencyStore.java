/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.idempotency;

import io.rchemist.starter.notification.core.NotificationResult;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Idempotency cache SPI — key 별 처리 결과 보존.
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link InMemoryIdempotencyStore} — ConcurrentHashMap 기반 default. 단일 인스턴스 한정</li>
 *   <li>Redis-backed — distributed (다중 인스턴스 / 클러스터) 시 권장 (SETNX 기반 atomic claim)</li>
 *   <li>JPA-backed — DB UNIQUE constraint + audit log 결합</li>
 * </ul>
 *
 * <p>주의 — InMemory default 는 race condition 영역 X (단일 instance 한정). 다중 instance 환경
 * (Pod replica) 의 정확한 idempotency 는 Consumer 의 distributed store 가 책임.
 **/
public interface IdempotencyStore {

  /** key 별 처리 결과 조회 — 부재 시 empty. */
  Optional<NotificationResult> get(String key);

  /** key 별 결과 저장 (덮어쓰기). */
  void put(String key, NotificationResult result);
}
