/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@code platform.notification.*} prefix 의 baseline yml binding —
 * {@link NotificationAutoConfiguration} 의 단일 진입점.
 *
 * <p>{@code enabled} = autoconfig 자체 opt-out flag (default true).
 * 8 영역 (email / sms / kakao / push / template / outbox / idempotency / log) nested record —
 * task #3~#9 진입 시 본문 보강 (현재는 task #3 의 {@link Email} baseline).
 **/
@ConfigurationProperties(prefix = "platform.notification")
public record NotificationProperties(
    @DefaultValue("true") boolean enabled, @DefaultValue Email email) {

  /** Email 채널 baseline ({@code platform.notification.email.*}). */
  public record Email(@DefaultValue("") String defaultFrom) {}
}
