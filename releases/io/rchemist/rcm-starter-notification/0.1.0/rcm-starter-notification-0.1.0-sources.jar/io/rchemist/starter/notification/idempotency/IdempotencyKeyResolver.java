/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.idempotency;

import io.rchemist.starter.notification.core.Notification;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Notification 1 건당 idempotency key 결정 SPI — 중복 발송 차단 baseline.
 *
 * <p>baseline:
 * <ul>
 *   <li>{@link DefaultIdempotencyKeyResolver} — type + Records.toString() SHA-256 truncated 16 hex</li>
 *   <li>Consumer override — 비즈니스 키 (e.g. orderId + eventType) 가 더 자연스러운 시나리오</li>
 * </ul>
 *
 * <p>Phase 5 의 Idempotency-Key filter 패턴 정합.
 **/
public interface IdempotencyKeyResolver {

  /** 같은 Notification 입력 → 같은 key 결정 (deterministic). */
  String resolve(Notification notification);
}
