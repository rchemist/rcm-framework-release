/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.sms;

import io.rchemist.starter.notification.core.NotificationResult;
import io.rchemist.starter.notification.core.exception.NotificationException;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SMS Provider 부재 시 default — fail-loud. Consumer 가 carrier 어댑터 (NaverCloudSmsProvider /
 * NhnCloudSmsProvider / CoolsmsProvider / AligoSmsProvider / TwilioSmsProvider) 를
 * {@code @Component} 로 wire 하지 않은 시점의 production 위험 차단.
 *
 * <p>silent fail 영역 영구 차단 (메모리 {@code feedback_no_feature_regression} 정합).
 **/
public class NoopSmsProvider implements SmsProvider {

  private static final String NAME = "noop-sms";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public NotificationResult send(SmsNotification notification) {
    throw new NotificationException(
        "SMS Provider not configured. Wire @Component implementing SmsProvider"
            + " (NaverCloudSmsProvider / NhnCloudSmsProvider / CoolsmsProvider /"
            + " AligoSmsProvider / TwilioSmsProvider).");
  }
}
