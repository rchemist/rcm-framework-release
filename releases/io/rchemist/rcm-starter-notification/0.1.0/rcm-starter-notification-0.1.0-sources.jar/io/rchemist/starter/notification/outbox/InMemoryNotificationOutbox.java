/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationStatus;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link NotificationOutbox} — ConcurrentHashMap 기반 default.
 *
 * <p>주의: 재시작 시 손실 (durability 0). production 환경은 Consumer JPA-backed 어댑터 권장.
 *
 * <p>thread-safe ({@link ConcurrentHashMap} + {@code computeIfPresent} atomic semantic). polling
 * 시 SENDING 전환은 race-free.
 **/
public class InMemoryNotificationOutbox implements NotificationOutbox {

  private final ConcurrentMap<String, OutboxEntry> entries = new ConcurrentHashMap<>();

  @Override
  public String append(Notification notification) {
    String id = UUID.randomUUID().toString();
    Instant now = Instant.now();
    entries.put(id, new OutboxEntry(id, notification, 0, NotificationStatus.PENDING, null, now));
    return id;
  }

  @Override
  public Optional<OutboxEntry> pollNext() {
    Instant now = Instant.now();
    for (OutboxEntry entry : entries.values()) {
      if ((entry.status() == NotificationStatus.PENDING
              || entry.status() == NotificationStatus.RETRYING)
          && !entry.nextAttemptAt().isAfter(now)) {
        OutboxEntry sending = entry.markSending();
        // atomic CAS — 다른 스레드가 동시 polling 시 한쪽만 wins
        boolean replaced = entries.replace(entry.id(), entry, sending);
        if (replaced) {
          return Optional.of(sending);
        }
      }
    }
    return Optional.empty();
  }

  @Override
  public void markSent(String id) {
    entries.computeIfPresent(id, (k, e) -> e.markSent());
  }

  @Override
  public void markRetrying(String id, String error, Instant nextAttemptAt) {
    entries.computeIfPresent(id, (k, e) -> e.markRetrying(error, nextAttemptAt));
  }

  @Override
  public void markDead(String id, String error) {
    entries.computeIfPresent(id, (k, e) -> e.markDead(error));
  }

  @Override
  public int size() {
    return entries.size();
  }

  @Override
  public Optional<OutboxEntry> findById(String id) {
    return Optional.ofNullable(entries.get(id));
  }
}
