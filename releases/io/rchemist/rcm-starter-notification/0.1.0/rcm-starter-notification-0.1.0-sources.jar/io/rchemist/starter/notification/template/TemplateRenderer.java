/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.template;

import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 템플릿 렌더링 SPI — 본문 + 변수 → substituted 결과 String.
 *
 * <p>baseline 구현:
 * <ul>
 *   <li>{@link SimpleTemplateRenderer} — 자체 {@code {{varName}}} 파서. 외부 의존 0. default</li>
 *   <li>Mustache — Consumer 가 {@code com.github.spullara.mustache.java:compiler} 의존 + 어댑터
 *       구현체 wire</li>
 *   <li>Thymeleaf — {@code spring-boot-starter-thymeleaf} 의존 + {@code TemplateEngine} 어댑터</li>
 *   <li>Freemarker — {@code spring-boot-starter-freemarker} 의존 + {@code Configuration} 어댑터</li>
 * </ul>
 *
 * <p>Consumer 가 자체 {@code TemplateRenderer} bean 정의 시 default {@link SimpleTemplateRenderer}
 * 가 양보 ({@code @ConditionalOnMissingBean}).
 **/
public interface TemplateRenderer {

  /**
   * 템플릿 본문에 변수 치환 적용.
   *
   * @param template raw 본문 (e.g. {@code "Hello {{name}}!"})
   * @param variables 변수 map (e.g. {@code {"name": "World"}})
   * @return substituted 결과 (e.g. {@code "Hello World!"})
   */
  String render(String template, Map<String, String> variables);
}
