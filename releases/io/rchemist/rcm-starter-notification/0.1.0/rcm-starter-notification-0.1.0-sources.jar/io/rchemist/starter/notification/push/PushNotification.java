/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.push;

import io.rchemist.starter.notification.core.Notification;
import io.rchemist.starter.notification.core.NotificationType;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Push 알림 발송 요청 — topic 기반 (broadcast) 또는 token 다중 (unicast / multicast).
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>{@code title} = 알림 헤드라인 (lockscreen / notification tray 표시)</li>
 *   <li>{@code body} = 본문 (옵션). data-only push 시 null</li>
 *   <li>{@code platform} = {@link PushPlatform} (FCM / APNS / WEB_PUSH)</li>
 *   <li>{@code topic} = broadcast 발송 (e.g. {@code "all-users"} / {@code "kr-news"}). XOR
 *       tokens — topic 또는 tokens 중 하나만 명시</li>
 *   <li>{@code tokens} = unicast / multicast 발송 (FCM registration token / APNS device token)</li>
 *   <li>{@code data} = custom payload (key/value Map). Provider 가 Push payload 의 {@code data}
 *       필드로 변환</li>
 *   <li>{@code clickAction} = 탭 액션 (URL 또는 앱 deep link)</li>
 *   <li>{@code imageUrl} = 알림 이미지 (지원 플랫폼 한정)</li>
 * </ul>
 *
 * <p>compact constructor 에서 topic XOR tokens 강제 — 둘 다 명시 / 둘 다 부재 시
 * {@link IllegalArgumentException} fail-loud.
 **/
public record PushNotification(
    String title,
    String body,
    PushPlatform platform,
    String topic,
    List<String> tokens,
    Map<String, String> data,
    String clickAction,
    String imageUrl)
    implements Notification {

  public PushNotification {
    Objects.requireNonNull(platform, "platform required");
    boolean hasTopic = topic != null && !topic.isBlank();
    boolean hasTokens = tokens != null && !tokens.isEmpty();
    if (hasTopic == hasTokens) {
      throw new IllegalArgumentException(
          "Either topic or tokens must be specified (exclusive — not both, not neither).");
    }
    tokens = tokens == null ? List.of() : List.copyOf(tokens);
    data = data == null ? Map.of() : Map.copyOf(data);
  }

  @Override
  public NotificationType type() {
    return NotificationType.PUSH;
  }

  /** Topic broadcast 편의 factory — title + body + topic. */
  public static PushNotification toTopic(
      String title, String body, PushPlatform platform, String topic) {
    return new PushNotification(title, body, platform, topic, null, null, null, null);
  }

  /** Single token unicast 편의 factory. */
  public static PushNotification toToken(
      String title, String body, PushPlatform platform, String token) {
    return new PushNotification(title, body, platform, null, List.of(token), null, null, null);
  }

  /** Multi-token multicast 편의 factory. */
  public static PushNotification toTokens(
      String title, String body, PushPlatform platform, List<String> tokens) {
    return new PushNotification(title, body, platform, null, tokens, null, null, null);
  }
}
