/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.sms;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SMS 본문 type — 길이 / 첨부 매트릭스. 한국 carrier 표준 (KT / SKT / LGU+ 정합).
 *
 * <p>
 * <ul>
 *   <li>{@link #SMS} — 단문, EUC-KR 90 byte / 한글 45 자 이하</li>
 *   <li>{@link #LMS} — 장문, 2000 byte / 한글 1000 자 이하</li>
 *   <li>{@link #MMS} — LMS + 이미지/동영상 첨부</li>
 * </ul>
 *
 * <p>실제 분류는 carrier 별 API 가 적용 — 본 enum 은 Consumer 의도 표현 + 메시지 단가 분기.
 **/
public enum SmsType {

  /** 단문 — EUC-KR 90 byte / 한글 45 자 이하. */
  SMS,

  /** 장문 — 2000 byte / 한글 1000 자 이하. */
  LMS,

  /** 장문 + 이미지 첨부. */
  MMS
}
