/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.outbox;

import io.rchemist.starter.notification.core.NotificationDispatcher;
import io.rchemist.starter.notification.core.NotificationResult;
import io.rchemist.starter.notification.core.NotificationStatus;
import io.rchemist.starter.notification.core.exception.NotificationException;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox poll → dispatch → outcome 처리 facade. JDK 25 VirtualThread 친화 (Decision #28
 * VirtualThread default ON 정합) — Consumer 가 {@link Thread#startVirtualThread} + 무한 루프 또는
 * {@code @Scheduled} 으로 wire.
 *
 * <p>본 sender 는 *상태 없는 1-tick* 단위 — Consumer 의 스케줄러 / VirtualThread 가 호출 + 백오프.
 *
 * <p>처리 시나리오:
 * <ul>
 *   <li>{@link NotificationResult#status()} = SENT → {@link NotificationOutbox#markSent}</li>
 *   <li>{@link NotificationResult#status()} = FAILED → 재시도 카운트 비교 → max 미달 시
 *       {@link NotificationOutbox#markRetrying} + 다음 backoff. max 도달 시 {@link DeadLetterQueue}
 *       적재 + {@link NotificationOutbox#markDead}</li>
 *   <li>{@link NotificationException} (비재시도) → DLQ 직행 + DEAD</li>
 *   <li>그 외 RuntimeException → 재시도 후보 처리 (max 도달 시 DEAD)</li>
 * </ul>
 **/
public class AsyncNotificationSender {

  private final NotificationOutbox outbox;
  private final NotificationDispatcher dispatcher;
  private final DeadLetterQueue dlq;
  private final RetryPolicy retryPolicy;

  public AsyncNotificationSender(
      NotificationOutbox outbox,
      NotificationDispatcher dispatcher,
      DeadLetterQueue dlq,
      RetryPolicy retryPolicy) {
    this.outbox = Objects.requireNonNull(outbox, "outbox required");
    this.dispatcher = Objects.requireNonNull(dispatcher, "dispatcher required");
    this.dlq = Objects.requireNonNull(dlq, "dlq required");
    this.retryPolicy = Objects.requireNonNull(retryPolicy, "retryPolicy required");
  }

  /**
   * 1-tick 실행 — 발송 가능한 entry 1 건 polling + 발송 + 결과 반영. 폴링 결과 없으면 false 반환.
   *
   * @return entry 처리됨 = true / 폴링 빈 결과 = false
   */
  public boolean tick() {
    Optional<OutboxEntry> polled = outbox.pollNext();
    if (polled.isEmpty()) {
      return false;
    }
    OutboxEntry entry = polled.get();
    try {
      NotificationResult result = dispatcher.send(entry.notification());
      if (result.status() == NotificationStatus.SENT) {
        outbox.markSent(entry.id());
      } else {
        handleRetryable(entry, result.error());
      }
    } catch (NotificationException e) {
      // 비재시도 실패 — DLQ 직행
      OutboxEntry dead = entry.markDead(e.getMessage());
      dlq.push(dead);
      outbox.markDead(entry.id(), e.getMessage());
    } catch (RuntimeException e) {
      handleRetryable(entry, e.getMessage());
    }
    return true;
  }

  private void handleRetryable(OutboxEntry entry, String error) {
    if (entry.attempts() >= retryPolicy.maxAttempts()) {
      OutboxEntry dead = entry.markDead(error);
      dlq.push(dead);
      outbox.markDead(entry.id(), error);
    } else {
      Instant next = Instant.now().plus(retryPolicy.nextBackoff(entry.attempts()));
      outbox.markRetrying(entry.id(), error, next);
    }
  }
}
