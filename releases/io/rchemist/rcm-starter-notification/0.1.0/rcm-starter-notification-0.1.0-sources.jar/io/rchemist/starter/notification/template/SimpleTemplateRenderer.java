/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.notification.template;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 자체 simple {@code {{varName}}} 템플릿 파서 — 외부 의존 0 default.
 *
 * <p>지원 syntax:
 * <ul>
 *   <li>{@code {{name}}} — 변수 치환</li>
 *   <li>{@code {{ name }}} — whitespace 허용 (양쪽 trim)</li>
 *   <li>변수 부재 시 빈 문자열로 치환 (silent — 권장 X 면 Consumer override)</li>
 * </ul>
 *
 * <p>비지원 (Consumer 가 Mustache / Thymeleaf / Freemarker 어댑터 wire):
 * <ul>
 *   <li>중첩 객체 (예: {@code {{user.name}}})</li>
 *   <li>조건문 (예: {@code {{#if cond}}...{{/if}}})</li>
 *   <li>반복문 (예: {@code {{#each items}}...{{/each}}})</li>
 *   <li>HTML escape</li>
 * </ul>
 **/
public class SimpleTemplateRenderer implements TemplateRenderer {

  private static final Pattern PATTERN = Pattern.compile("\\{\\{\\s*([^{}\\s]+)\\s*}}");

  @Override
  public String render(String template, Map<String, String> variables) {
    if (template == null || template.isEmpty()) {
      return template;
    }
    Map<String, String> safeVars = variables == null ? Map.of() : variables;
    Matcher matcher = PATTERN.matcher(template);
    StringBuilder result = new StringBuilder();
    while (matcher.find()) {
      String key = matcher.group(1);
      String value = safeVars.get(key);
      if (value == null) {
        value = "";
      }
      matcher.appendReplacement(result, Matcher.quoteReplacement(value));
    }
    matcher.appendTail(result);
    return result.toString();
  }
}
