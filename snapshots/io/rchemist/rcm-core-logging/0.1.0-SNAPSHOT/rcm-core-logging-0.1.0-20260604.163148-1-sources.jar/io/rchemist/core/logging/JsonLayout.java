/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.LayoutBase;
import io.rchemist.core.context.RequestContext;
import io.rchemist.core.context.TenantContext;
import io.rchemist.core.context.UserContext;
import java.time.Instant;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Logback JSON Layout — Phase 1 의 ScopedValue 3 키 (RequestContext / TenantContext /
 * UserContext) 와 MDC 를 자동으로 직렬화. timestamp / level / logger / thread / message +
 * tenantId / userId / requestId + MDC + exception.
 **/
public class JsonLayout extends LayoutBase<ILoggingEvent> {

    @Override
    public String doLayout(ILoggingEvent event) {
        StringBuilder sb = new StringBuilder(256);
        sb.append('{');
        appendKv(sb, "timestamp", Instant.ofEpochMilli(event.getTimeStamp()).toString());
        sb.append(',');
        appendKv(sb, "level", event.getLevel().toString());
        sb.append(',');
        appendKv(sb, "logger", event.getLoggerName());
        sb.append(',');
        appendKv(sb, "thread", event.getThreadName());
        sb.append(',');
        appendKv(sb, "message", event.getFormattedMessage());

        if (TenantContext.isBound()) {
            sb.append(',');
            appendKv(sb, "tenantId", TenantContext.current().tenantId());
        }
        if (UserContext.isBound()) {
            sb.append(',');
            appendKv(sb, "userId", UserContext.current().userId());
        }
        if (RequestContext.isBound()) {
            sb.append(',');
            appendKv(sb, "requestId", RequestContext.current().requestId());
        }

        Map<String, String> mdc = event.getMDCPropertyMap();
        if (mdc != null && !mdc.isEmpty()) {
            for (Map.Entry<String, String> e : mdc.entrySet()) {
                sb.append(',');
                appendKv(sb, e.getKey(), e.getValue());
            }
        }

        IThrowableProxy throwable = event.getThrowableProxy();
        if (throwable != null) {
            sb.append(',');
            appendKv(sb, "exception", ThrowableProxyUtil.asString(throwable));
        }

        sb.append('}');
        sb.append(System.lineSeparator());
        return sb.toString();
    }

    private static void appendKv(StringBuilder sb, String key, String value) {
        sb.append('"');
        escape(sb, key);
        sb.append("\":");
        if (value == null) {
            sb.append("null");
        } else {
            sb.append('"');
            escape(sb, value);
            sb.append('"');
        }
    }

    private static void escape(StringBuilder sb, String s) {
        int len = s.length();
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
    }
}
