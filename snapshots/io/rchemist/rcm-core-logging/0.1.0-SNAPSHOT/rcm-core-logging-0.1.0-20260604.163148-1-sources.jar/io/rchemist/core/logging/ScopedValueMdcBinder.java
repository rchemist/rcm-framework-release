/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.logging;

import io.rchemist.core.context.RequestContext;
import io.rchemist.core.context.TenantContext;
import io.rchemist.core.context.UserContext;
import org.slf4j.MDC;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * ScopedValue → SLF4J MDC 브리지 — Phase 1 의 3 ScopedValue 키를 MDC 의 tenantId /
 * userId / requestId 로 publish/clear. Logback 의 %X{...} 패턴 호환 + try-finally
 * runWithMdc helper 제공.
 **/
public final class ScopedValueMdcBinder {

    public static final String MDC_KEY_TENANT_ID = "tenantId";
    public static final String MDC_KEY_USER_ID = "userId";
    public static final String MDC_KEY_REQUEST_ID = "requestId";

    private ScopedValueMdcBinder() {
    }

    public static void publishToMdc() {
        if (TenantContext.isBound()) {
            MDC.put(MDC_KEY_TENANT_ID, TenantContext.current().tenantId());
        }
        if (UserContext.isBound()) {
            MDC.put(MDC_KEY_USER_ID, UserContext.current().userId());
        }
        if (RequestContext.isBound()) {
            MDC.put(MDC_KEY_REQUEST_ID, RequestContext.current().requestId());
        }
    }

    public static void clearFromMdc() {
        MDC.remove(MDC_KEY_TENANT_ID);
        MDC.remove(MDC_KEY_USER_ID);
        MDC.remove(MDC_KEY_REQUEST_ID);
    }

    public static void runWithMdc(Runnable task) {
        try {
            publishToMdc();
            task.run();
        } finally {
            clearFromMdc();
        }
    }
}
