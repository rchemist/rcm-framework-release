/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AdminUserErrorType extends EnumType<AdminUserErrorType> implements ErrorType {

  public static final AdminUserErrorType NOT_FOUND = new AdminUserErrorType("NOT_FOUND", "해당 정보의 관리자가 존재하지 않습니다.", HttpStatus.NOT_FOUND);
  public static final AdminUserErrorType DELETE_ALL_IS_NOT_ACCEPT = new AdminUserErrorType("DELETE_ALL_IS_NOT_ACCEPT", "관리자 정보는 최소한 하나 이상 존재해야 합니다. 모든 관리자 정보를 삭제할 수 없습니다.", HttpStatus.FORBIDDEN);
  public static final AdminUserErrorType INVALID_LOGIN_NAME = new AdminUserErrorType("INVALID_LOGIN_NAME", "아이디를 3자 이상 영문/숫자로 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType INVALID_EMAILADDRESS = new AdminUserErrorType("INVALID_EMAILADDRESS", "이메일 주소를 확인해 주세요.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATED_LOGIN_NAME = new AdminUserErrorType("DUPLICATED_LOGIN_NAME",  "이미 존재하는 아이디 입니다. 다른 아이디를 사용해 주세요.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATED_PERSONAL_CODE = new AdminUserErrorType("DUPLICATED_PERSONAL_CODE", "인증 키 값이 이미 존재합니다. 회원 찾기를 통해 로그인해 주세요.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATE_PASSWORD_IS_NOT_PERMITTED = new AdminUserErrorType("DUPLICATE_PASSWORD_IS_NOT_PERMITTED",
      "최근 6개월 이내에 사용했던 비밀번호를 다시 사용할 수 없습니다.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType INVALID_PASSWORD = new AdminUserErrorType("INVALID_PASSWORD",
      "올바른 비밀번호가 아니거나 형식에 맞지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATED_EMAILADDRESS = new AdminUserErrorType("DUPLICATED_EMAILADDRESS",
      "이미 등록된 이메일 주소 입니다.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType INVALID_PHONENUMBER = new AdminUserErrorType("INVALID_PHONENUMBER",
      "전화번호를 다시 확인하고 숫자만 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATED_SECEDED_LOGIN_NAME = new AdminUserErrorType("DUPLICATED_SECEDED_LOGIN_NAME", "탈퇴한 아이디로 재가입할 수 없습니다. 다른 아이디를 사용해 주세요.", HttpStatus.BAD_REQUEST);
  public static final AdminUserErrorType DUPLICATED_SECEDED_PERSONAL_CODE = new AdminUserErrorType("DUPLICATED_SECEDED_PERSONAL_CODE", "탈퇴 후 재가입 제한 기간이 만료되지 않아 가입할 수 없습니다.", HttpStatus.BAD_REQUEST);

  
  @Getter
  private final int status;

  public AdminUserErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }
}
