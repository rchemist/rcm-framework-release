/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.data;

import io.rchemist.module.jwt.data.Token;
import lombok.Data;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class AuthenticationResult extends Token {

  private Long id;

  private String name;

  private String emailAddress;

  private String image;

  private Boolean active;

  private Boolean firstLogin;

  private Boolean rememberMe;

  public AuthenticationResult withId(Long id) {
    this.id = id;
    return this;
  }

  public AuthenticationResult withName(String name) {
    this.name = name;
    return this;
  }

  public AuthenticationResult withEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  public AuthenticationResult withImage(String image) {
    this.image = image;
    return this;
  }

  public AuthenticationResult withActive(Boolean active) {
    this.active = active;
    return this;
  }

  public AuthenticationResult withFirstLogin(Boolean firstLogin) {
    this.firstLogin = firstLogin;
    return this;
  }

  public AuthenticationResult withRememberMe(Boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

  public AuthenticationResult withToken(Token token) {
    this.accessToken = token.getAccessToken();
    this.refreshToken = token.getRefreshToken();
    this.accessTokenExpiry = token.getAccessTokenExpiry();
    return this;
  }
}
