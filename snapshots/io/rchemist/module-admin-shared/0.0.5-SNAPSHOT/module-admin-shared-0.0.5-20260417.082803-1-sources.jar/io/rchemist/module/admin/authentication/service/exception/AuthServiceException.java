/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service.exception;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AuthServiceException extends ErrorTypeException {

  public AuthServiceException(AuthServiceErrorType errorType) {
    super(errorType);
  }

  public AuthServiceException(AuthServiceErrorType errorType, Throwable cause) {
    super(errorType, cause);
  }

  public AuthServiceException(String fieldName, AuthServiceErrorType errorType) {
    super(fieldName, errorType);
  }

  public AuthServiceException(String message) {
    super(message);
  }

  public AuthServiceException(ErrorDTO error) {
    super(error.getMessage(), error);
  }

}
