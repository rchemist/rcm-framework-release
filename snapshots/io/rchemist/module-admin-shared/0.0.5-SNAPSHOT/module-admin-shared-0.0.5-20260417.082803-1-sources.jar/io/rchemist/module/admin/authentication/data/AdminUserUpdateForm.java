/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.data;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.jpa.domain.data.AttachAssetForm;
import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@AdminEntity(name = "adminUserUpdateForm")
public class AdminUserUpdateForm implements Serializable,
    HasId<AdminUserUpdateForm>,
    UpdateFormWrapper<AdminUserUpdateForm, Long>,
    AbstractAdminUser<AdminUserUpdateForm>,
    AttachAssetForm {

  // 이 값이 지정되어 있으면 명시적으로 지정된 필드만 업데이트 해야 한다.
  private String[] explicitUpdatedFields;

  private String password;

  private String mfaSecret;

  private AttachAsset profile;

  private Boolean active;

  public void validate() throws AdminUserException {

    // override it if you need
    // default validation is AdminUser#validateUpdate

  }


  @Override
  public AttachAsset getAttachAsset() {
    return profile;
  }

  @Override
  public void setAttachAsset(AttachAsset attachAsset) {
    this.profile = attachAsset;
  }

}

