/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AuthServiceErrorType extends EnumType<AuthServiceErrorType> implements ErrorType {

  public static final AuthServiceErrorType LOGIN_FAILED = new AuthServiceErrorType("LOGIN_FAILED", "해당 정보로 로그인할 수 없습니다.", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType NO_COMPANY = new AuthServiceErrorType("NO_COMPANY", "법인 정보가 존재하지 않습니다.", HttpStatus.NOT_FOUND);
  public static final AuthServiceErrorType INVALID_TOKEN = new AuthServiceErrorType("INVALID_TOKEN", "토큰 정보가 유효하지 않습니다.", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType EXPIRED_TOKEN = new AuthServiceErrorType("EXPIRED_TOKEN", "만료된 토큰입니다.", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType INVALID_REGISTER_REQUEST = new AuthServiceErrorType("INVALID_REGISTER_REQUEST", "잘못된 요청입니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType INVALID_LINK_REQUEST = new AuthServiceErrorType("INVALID_LINK_REQUEST", "잘못된 요청입니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType REQUIRED_AGREEMENTS = new AuthServiceErrorType("REQUIRED_AGREEMENTS", "필수 약관에 동의해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DUPLICATED_COMPANY = new AuthServiceErrorType("DUPLICATED_COMPANY", "해당 법인은 이미 회원으로 가입되어 있습니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType ALREADY_MAPPED_PROVIDER_ID = new AuthServiceErrorType("ALREADY_MAPPED_PROVIDER_ID", "해당 소셜 ID는 이미 다른 법인 대표 정보로 등록되어 있습니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DUPLICATED_USER = new AuthServiceErrorType("DUPLICATED_USER", "DUPLICATED_USER", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DUPLICATED_SOCIAL_PROVIDER = new AuthServiceErrorType("DUPLICATED_SOCIAL_PROVIDER", "이 회원은 이미 동일한 SNS로 가입되어 있습니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DUPLICATED_SOCIAL_PROVIDER_ID = new AuthServiceErrorType("DUPLICATED_SOCIAL_PROVIDER_ID", "해당 SNS 계정으로 이미 가입된 정보가 있습니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType USER_NOT_FOUND = new AuthServiceErrorType("USER_NOT_FOUND", "사용자가 존재하지 않습니다.", HttpStatus.NOT_FOUND);
  public static final AuthServiceErrorType INVALID_PHONE_NUMBER = new AuthServiceErrorType("INVALID_PHONE_NUMBER", "전화번호가 유효하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType REQUIRED_COMPANY_NAME = new AuthServiceErrorType("REQUIRED_COMPANY_NAME", "법인명을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType REQUIRED_REGISTRATION_NUMBER = new AuthServiceErrorType("REQUIRED_REGISTRATION_NUMBER", "사업자등록번호를 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType REQUIRED_CERTFILE = new AuthServiceErrorType("REQUIRED_CERTFILE", "공인인증서를 등록해야 합니다", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType FAILED_TO_SAVE_SOCIAL_PROVIDER = new AuthServiceErrorType("FAILED_TO_SAVE_SOCIAL_PROVIDER", "회원에 소셜 계정을 연결 중 오류가 발생했습니다", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final AuthServiceErrorType NOT_AVAILABLE_COMPANY_FOR_USER = new AuthServiceErrorType("NOT_AVAILABLE_COMPANY_FOR_USER", "해당 회사 정보에 접근할 수 없습니다", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType DUPLICATED_LOGIN_NAME = new AuthServiceErrorType("DUPLICATED_LOGIN_NAME", "이미 등록된 로그인 아이디 입니다", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DUPLICATED_EMAIL = new AuthServiceErrorType("DUPLICATED_EMAIL", "이미 등록된 이메일 입니다", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType INVALID_PASSWORD = new AuthServiceErrorType("INVALID_PASSWORD", "비밀번호 생성 규칙에 맞지 않습니다", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType DORMANT_ACCOUNT = new AuthServiceErrorType("DORMANT_ACCOUNT", "휴면 상태 입니다. 먼저 휴면을 해제해야 합니다", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType SECEDED_ACCOUNT = new AuthServiceErrorType("SECEDED_ACCOUNT", "탈퇴한 회원 입니다. 이 계정으로는 로그인할 수 없습니다", HttpStatus.FORBIDDEN);
  public static final AuthServiceErrorType DUPLICATED_CERTIFICATION = new AuthServiceErrorType("DUPLICATED_CERTIFICATION", "이미 가입된 인증서 입니다.", HttpStatus.BAD_REQUEST);
  public static final AuthServiceErrorType REQUIRED_KEYFILE = new AuthServiceErrorType("REQUIRED_KEYFILE", "인증서 값이 der 형태이면 반드시 Key 파일이 필요합니다.", HttpStatus.BAD_REQUEST);;
  public static final AuthServiceErrorType NOT_MATCHED_COMPANY_CERT = new AuthServiceErrorType("NOT_MATCHED_COMPANY_CERT", "해당 기업의 인증서 정보가 아닙니다.", HttpStatus.BAD_REQUEST);;
  @Getter
  private final int status;

  public AuthServiceErrorType(String type, String description, HttpStatus httpStatus) {
    super(type, type, description);
    this.status = httpStatus.value();
  }

  public AuthServiceErrorType() {
    this.status = 500;
  }

}
