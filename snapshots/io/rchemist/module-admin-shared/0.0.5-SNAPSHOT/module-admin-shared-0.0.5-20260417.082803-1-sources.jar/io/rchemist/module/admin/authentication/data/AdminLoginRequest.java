/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.module.admin.authentication.service.exception.AuthServiceErrorType;
import io.rchemist.module.admin.authentication.service.exception.AuthServiceException;
import java.io.Serializable;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@RestData(name = "관리자 로그인 요청")
public class AdminLoginRequest implements Serializable {

  @RestDataField(name = "아이디")
  protected String loginName;

  @RestDataField(name = "비밀번호")
  protected String password;

  @RestDataField(name = "자동로그인 여부")
  protected Boolean rememberMe;

  public void validate() throws AuthServiceException {
    if (StringUtils.isEmpty(loginName)) {
      throw new AuthServiceException("loginName", AuthServiceErrorType.REQUIRED_AGREEMENTS);
    }
    if (StringUtils.isEmpty(password)) {
      throw new AuthServiceException("password", AuthServiceErrorType.REQUIRED_AGREEMENTS);
    }
  }

}
