/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.data;

import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.jpa.domain.data.AttachAssetForm;
import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import lombok.Data;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@AdminEntity(name = "adminUserCreateForm")
@Data
public class AdminUserCreateForm implements Serializable, AttachAssetForm,
    AbstractAdminUser<AdminUserCreateForm>,
    CreateFormWrapper<AdminUserCreateForm> {

  @NotNull
  @Size(min = 3, max = 50)
  @RestDataField(name = "회원 아이디", description = "회원 아이디", example = "rchemist")
  protected String loginName;

  @NotNull
  @Size(min = 3, max = 100)
  @RestDataField(name = "패스워드", description = "패스워드", example = "password")
  protected String password;

  protected String mfaSecret;

  @RestDataField(name = "패스워드 암호화 처리 여부", description = "이미 암호화된 문자열을 전송할 때 이 값을 true 로 설정하면, 본 프로세스에서 암호화 처리를 skip 한다.", example = "true")
  protected Boolean passwordEncoded = false;

  private AttachAsset profile;

  public AdminUserCreateForm withLoginName(String loginName) {
    this.loginName = loginName;
    return this;
  }

  public AdminUserCreateForm withPassword(String password) {
    this.password = password;
    return this;
  }

  public AdminUserCreateForm withPasswordEncoded(Boolean passwordEncoded) {
    this.passwordEncoded = passwordEncoded;
    return this;
  }

  public AdminUserCreateForm withMfaSecret(String mfaSecret) {
    this.mfaSecret = mfaSecret;
    return this;
  }

  @Override
  public AttachAsset getAttachAsset() {
    return profile;
  }

  @Override
  public void setAttachAsset(AttachAsset attachAsset) {
    this.profile = attachAsset;
  }

  public void validate() throws AdminUserException {
    // override it if you need
    // default validation is AdminUser#validateCreate
  }

  public AdminUserCreateForm clone(){
    return new AdminUserCreateForm()
        .withHidden(isHidden())
        .withEmailAddress(getEmailAddress())
        .withLoginName(getLoginName())
        .withName(getName())
        .withPassword(getPassword())
        .withPasswordEncoded(getPasswordEncoded())
        .withPhoneNumber(getPhoneNumber());
  }

}
