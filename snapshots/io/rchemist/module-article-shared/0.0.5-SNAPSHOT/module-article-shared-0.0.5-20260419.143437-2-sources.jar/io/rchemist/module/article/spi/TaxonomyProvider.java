/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.spi;

import java.util.List;

/**
 * SPI boundary that exposes the category / tag axis of an article to the
 * module without hard-coding a particular taxonomy scheme.
 *
 * <p>The default implementation in the article module delegates to the
 * repository's {@code getFeaturedTopicsByAlias} query, preserving the
 * historical "head-label / topic" behavior. Consumers that model categories
 * differently (for example, through a dedicated taxonomy table or the custom
 * field module) can register their own bean to override it.
 *
 * <p>Introduced by the 0.1.0 M3 generalization. See
 * {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
public interface TaxonomyProvider {

  /**
   * List the featured topics (head labels / subcategories) available for a
   * given board alias.
   *
   * @param alias board alias; must not be {@code null}
   * @return non-null ordered list of topic identifiers, possibly empty
   */
  List<String> getFeaturedTopics(String alias);

  /**
   * Validate whether a topic is acceptable under the given board alias.
   *
   * <p>The default implementation returns {@code true} — every topic is
   * accepted. Consumers can tighten validation by overriding this method.
   *
   * @param alias board alias
   * @param topic topic identifier (may be {@code null} or blank for
   *              topic-less articles)
   * @return {@code true} if the pairing is acceptable
   */
  default boolean supportsTopic(String alias, String topic) {
    return true;
  }
}
