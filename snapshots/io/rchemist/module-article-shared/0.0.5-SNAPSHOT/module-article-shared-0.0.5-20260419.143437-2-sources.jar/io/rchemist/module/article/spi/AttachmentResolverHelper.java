/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.spi;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.presentation.HasFileField;
import java.util.Collections;
import java.util.List;

/**
 * Static accessor that resolves the currently registered
 * {@link AttachmentResolver} bean lazily. Used by JPA entities (such as
 * {@code Article}) whose lifecycle sits outside the Spring container.
 *
 * <p>If the Spring context is unavailable (for example, during isolated unit
 * tests) an empty list is returned, so domain code can be exercised without
 * a running container.
 */
public final class AttachmentResolverHelper {

  private static AttachmentResolver cached;

  private AttachmentResolverHelper() {
    // static-only
  }

  /**
   * Lookup the current {@link AttachmentResolver} bean. The reference is
   * memoized after the first successful lookup; tests that need a clean slate
   * can call {@link #reset()}.
   */
  public static AttachmentResolver getResolver() {
    if (cached != null) {
      return cached;
    }
    try {
      cached = ApplicationContextHolder.getBean(AttachmentResolver.class);
    } catch (Exception ignored) {
      // No Spring context, or no bean registered — fall back to no-op.
      cached = new NoOpAttachmentResolver();
    }
    return cached;
  }

  /** Visible for tests. */
  public static void setResolver(AttachmentResolver resolver) {
    cached = resolver;
  }

  /** Visible for tests. */
  public static void reset() {
    cached = null;
  }

  public static List<AttachAsset> resolveNewAttachments(HasFileField<?> form) {
    if (form == null) {
      return Collections.emptyList();
    }
    return getResolver().resolveNewAttachments(form);
  }

  public static List<AttachAsset> resolveNewAttachments(String tenantAlias, HasFileField<?> form) {
    if (form == null) {
      return Collections.emptyList();
    }
    return getResolver().resolveNewAttachments(tenantAlias, form);
  }
}
