/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.spi;

import java.util.Collections;
import java.util.Map;

/**
 * Optional SPI that integrates with the {@code module-custom-field} module
 * (M4) at runtime without introducing a compile-time dependency.
 *
 * <p>The article module's auto-configuration registers a no-op default that
 * simply returns an empty map. When {@code module-custom-field} is on the
 * classpath and its M4 auto-configuration is active, it will publish a
 * concrete bean implementing this interface named
 * {@code articleCustomFieldResolver} — replacing the default.
 *
 * <p>This contract is intentionally minimal so that the two modules can
 * evolve independently. M4 will consume this hook via
 * {@code @ConditionalOnClass(CustomFieldResolver.class)} to remain optional.
 */
public interface CustomFieldResolver {

  /**
   * Resolve the custom field values currently persisted for the given
   * article identifier.
   *
   * @param articleId article primary key
   * @return non-null map keyed by field name, possibly empty
   */
  default Map<String, Object> resolveCustomFields(Long articleId) {
    return Collections.emptyMap();
  }

  /**
   * Persist a set of custom field values against the given article.
   *
   * <p>Default is a no-op; M4 implementations will route writes to the
   * custom-field storage layer.
   *
   * @param articleId article primary key
   * @param values    field name → value map; implementations may reject
   *                  unknown names or coerce values
   */
  default void applyCustomFields(Long articleId, Map<String, Object> values) {
    // no-op default
  }
}
