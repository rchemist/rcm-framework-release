/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class ArticleList implements Serializable {

    private List<ArticleView> list = new ArrayList<>();

    private final LocalDateTime cachedAt = LocalDateTime.now();

    public ArticleList addList(ArticleView... views) {
        list.addAll(List.of(views));
        return this;
    }

    public ArticleList withList(List<ArticleView> list) {
        this.list = list;
        return this;
    }

    public boolean isExpired() {
        return cachedAt.plusMinutes(5).isBefore(LocalDateTime.now());
    }

}
