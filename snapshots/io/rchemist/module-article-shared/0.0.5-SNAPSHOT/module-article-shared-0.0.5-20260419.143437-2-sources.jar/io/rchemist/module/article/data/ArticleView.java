/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.data;

import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAlias;
import io.rchemist.common.persistence.domain.template.presentation.HasAudit;
import io.rchemist.common.persistence.domain.template.presentation.HasFileField;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import java.util.Arrays;
import java.util.Objects;
import lombok.Data;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class ArticleView extends ArticleAbstractForm<ArticleView> implements HasId<ArticleView>, HasAudit<ArticleView>, HasActive<ArticleView>,
    HasAlias<ArticleView>,
    HasFileField<ArticleView> {

  public ArticleView(){

  }

  protected String prevArticleTitle;
  protected Long prevArticleId;
  protected String nextArticleTitle;
  protected Long nextArticleId;

  protected String coverImage;

  protected Integer viewCount;

  protected Boolean assetUploaded;

  protected String topic;

  protected Boolean featured;

  public ArticleView withFeatured(Boolean featured) {
    this.featured = featured;
    return this;
  }

  public ArticleView withCoverImage(String coverImage) {
    this.coverImage = coverImage;
    return this;
  }

  public ArticleView withTopic(String topic) {
    this.topic = topic;
    return this;
  }

  public ArticleView withPrevArticleTitle(String prevArticleTitle) {
    this.prevArticleTitle = prevArticleTitle;
    return this;
  }

  public ArticleView withPrevArticleId(Long prevArticleId) {
    this.prevArticleId = prevArticleId;
    return this;
  }

  public ArticleView withNextArticleTitle(String nextArticleTitle) {
    this.nextArticleTitle = nextArticleTitle;
    return this;
  }

  public ArticleView withNextArticleId(Long nextArticleId) {
    this.nextArticleId = nextArticleId;
    return this;
  }

  public ArticleView withAssetUploaded(Boolean assetUploaded) {
    this.assetUploaded = assetUploaded;
    return this;
  }

  public ArticleView withViewCount(Integer viewCount) {
    this.viewCount = viewCount;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ArticleView faqView = (ArticleView) o;
    return
        Objects.equals(getId(), faqView.getId()) &&
        Objects.deepEquals(getTags(), faqView.getTags()) &&
        Objects.equals(getTitle(), faqView.getTitle()) && Objects.equals(getContent(),
        faqView.getContent());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getId(), Arrays.hashCode(getTags()), getTitle(), getContent());
  }
}
