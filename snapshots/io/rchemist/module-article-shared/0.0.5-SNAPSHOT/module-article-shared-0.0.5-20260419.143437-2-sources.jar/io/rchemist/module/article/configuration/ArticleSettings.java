/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Centralized, tunable knobs for the article module, bound under the
 * {@code platform.article.*} prefix.
 *
 * <p>Introduced by the 0.1.0 M3 generalization so that consumers can override
 * cache TTLs, the default featured-article count, and the prev/next
 * navigation toggle without patching code. The {@code platform.config.article}
 * prefix is reserved for forward compatibility with tenant-scoped settings.
 *
 * <p>See {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "platform.article")
public class ArticleSettings {

  /** Default number of featured / categorized articles when size is unset. */
  @Value("${platform.article.default-featured-size:3}")
  private int defaultFeaturedSize;

  /** TTL (seconds) applied to article list / entity caches. */
  @Value("${platform.article.list-cache-ttl-seconds:86400}")
  private int listCacheTtlSeconds;

  /** Maximum entries in list / entity / unread caches. */
  @Value("${platform.article.cache-max-entries:100}")
  private int cacheMaxEntries;

  /** How long a cached {@code ArticleList} is considered fresh (minutes). */
  @Value("${platform.article.list-cache-fresh-minutes:5}")
  private int listCacheFreshMinutes;

  /**
   * When {@code true}, {@code view(id, null)} resolves prev/next sibling
   * articles. Consumers that do not need navigation can disable the extra
   * queries by setting this to {@code false}.
   */
  @Value("${platform.article.prev-next-enabled:true}")
  private boolean prevNextEnabled;
}
