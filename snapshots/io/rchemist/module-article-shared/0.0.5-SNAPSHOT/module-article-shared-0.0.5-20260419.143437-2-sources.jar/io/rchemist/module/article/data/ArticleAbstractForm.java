/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasFileField;
import io.rchemist.common.persistence.domain.template.presentation.HasHidden;
import io.rchemist.common.persistence.domain.template.presentation.HasNickname;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasUserId;
import io.rchemist.module.article.service.exception.ArticleErrorType;
import io.rchemist.module.article.service.exception.ArticleException;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class ArticleAbstractForm<T> implements HasContents<T>, HasNickname<T>, HasTags<T>,
    HasHidden<T>, HasFileField<T>, HasUserId<T>, HasAttributes<T> {

  @Getter
  @Setter
  protected String topic;

  @Getter
  @Setter
  protected String coverImage;

  @Getter
  @Setter
  protected Boolean featured;

  public T withFeatured(Boolean feature) {
    this.featured = feature;
    return (T) this;
  }

  public T withTopic(String topic) {
    this.topic = topic;
    return (T) this;
  }

  public T withCoverImage(String coverImage) {
    this.coverImage = coverImage;
    return (T) this;
  }

  public void validate() throws ArticleException {
    if (StringUtils.isEmpty(getTitle())) {
      throw new ArticleException(ArticleErrorType.REQUIRED_TITLE);
    }
    if (StringUtils.isEmpty(getContent())) {
      throw new ArticleException(ArticleErrorType.REQUIRED_CONTENT);
    }
  }

}
