/**
 * {@code module-article-shared} — public DTOs, SPIs, and settings for the
 * article module.
 *
 * <p>Generalized in 0.1.0 M3 (DEC-017). The {@code spi} sub-package hosts the
 * SPI surface that decouples article from attachment storage, taxonomy, and
 * custom-field integrations. Default implementations live in
 * {@code module-article}.
 *
 * <p>See {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
package io.rchemist.module.article;
