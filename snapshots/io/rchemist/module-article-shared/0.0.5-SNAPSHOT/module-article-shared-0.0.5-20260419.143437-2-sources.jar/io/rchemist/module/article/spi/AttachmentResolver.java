/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.spi;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.presentation.HasFileField;
import java.util.List;

/**
 * SPI boundary that decouples the article module from any concrete attachment
 * storage implementation (such as {@code module-asset}).
 *
 * <p>A default no-op implementation is provided so that the article module can
 * start up in isolation. Consumers that need real attachment resolution should
 * register their own bean — for example, an adapter around
 * {@code AssetSearchServiceHelper} — and Spring will replace the no-op bean.
 *
 * <p>Introduced by the 0.1.0 M3 generalization. See
 * {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
public interface AttachmentResolver {

  /**
   * Resolve new attachments for the given form using the current request's
   * tenant alias (resolved by the implementation).
   *
   * @param form the form carrying {@code newFiles} metadata
   * @return non-null list of resolved {@link AttachAsset}s, possibly empty
   */
  List<AttachAsset> resolveNewAttachments(HasFileField<?> form);

  /**
   * Resolve new attachments for the given form using an explicit tenant alias.
   *
   * @param tenantAlias explicit tenant alias (may be {@code null} to let the
   *                    implementation fall back to request-scoped resolution)
   * @param form        the form carrying {@code newFiles} metadata
   * @return non-null list of resolved {@link AttachAsset}s, possibly empty
   */
  List<AttachAsset> resolveNewAttachments(String tenantAlias, HasFileField<?> form);
}
