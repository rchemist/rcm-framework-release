/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ArticleErrorType extends EnumType<ArticleErrorType> implements ErrorType {

  public static final ArticleErrorType REQUIRED_ALIAS = new ArticleErrorType("REQUIRED_ALIAS", "게시판 유형을 선택해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final ArticleErrorType REQUIRED_TITLE = new ArticleErrorType("REQUIRED_TITLE", "제목을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final ArticleErrorType REQUIRED_CONTENT = new ArticleErrorType("REQUIRED_CONTENT", "내용을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final ArticleErrorType REQUIRED_ID = new ArticleErrorType("REQUIRED_ID", "ID가 누락되었습니다.", HttpStatus.BAD_REQUEST);
  public static final ArticleErrorType NOT_FOUND = new ArticleErrorType("NOT_FOUND", "게시물이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);

  @Getter
  private final int status;

  public ArticleErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }
}
