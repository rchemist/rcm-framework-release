/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAlias;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.module.article.service.exception.ArticleErrorType;
import io.rchemist.module.article.service.exception.ArticleException;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ArticleCreateForm extends ArticleAbstractForm<ArticleCreateForm> implements HasAlias<ArticleCreateForm>,
    CreateFormWrapper<ArticleCreateForm> {

  @Override
  public void validate() throws ArticleException {
    super.validate();
    if(StringUtils.isEmpty(getAlias())) {
      throw new ArticleException(ArticleErrorType.REQUIRED_ALIAS);
    }
  }
}
