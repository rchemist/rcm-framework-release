/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.postman;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.rchemist.starter.document.core.exception.DocumentException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * OpenAPI 3.x JSON → {@link PostmanCollection} 변환. Decision #15 정합 — Phase 2 의 web-openapi
 * (springdoc) 가 자동 생성한 OpenAPI JSON 을 Postman Collection 으로 변환.
 *
 * <p>매핑:
 * <ul>
 *   <li>{@code info.title} → collection name</li>
 *   <li>{@code info.description} → collection description</li>
 *   <li>{@code info.version} → collection version</li>
 *   <li>{@code servers[0].url} → variable {@code baseUrl}</li>
 *   <li>{@code paths.<path>.<method>} → {@link PostmanItem} 1 개. summary 없으면 method+path
 *       조합으로 name.</li>
 *   <li>{@code parameters} → {@link PostmanItem.PostmanParameter} 변환 (in=path/query 만).</li>
 *   <li>{@code requestBody.content."application/json".example} → raw body.</li>
 * </ul>
 **/
public class OpenApiToPostmanConverter {

  private final ObjectMapper mapper;

  public OpenApiToPostmanConverter() {
    this(new ObjectMapper());
  }

  public OpenApiToPostmanConverter(ObjectMapper mapper) {
    if (mapper == null) {
      throw new IllegalArgumentException("mapper must not be null");
    }
    this.mapper = mapper;
  }

  /** OpenAPI JSON string → PostmanCollection. */
  public PostmanCollection convert(String openApiJson) {
    if (openApiJson == null || openApiJson.isBlank()) {
      throw new IllegalArgumentException("openApiJson must not be blank");
    }
    try {
      JsonNode root = mapper.readTree(openApiJson);
      return convert(root);
    } catch (JsonProcessingException e) {
      throw new DocumentException("OpenAPI JSON parse 실패", e);
    }
  }

  /** OpenAPI JsonNode → PostmanCollection. */
  public PostmanCollection convert(JsonNode root) {
    if (root == null) {
      throw new IllegalArgumentException("root must not be null");
    }
    PostmanCollectionBuilder builder = new PostmanCollectionBuilder();

    JsonNode info = root.path("info");
    builder.name(textOrDefault(info.path("title"), "OpenAPI Collection"));
    builder.description(textOrDefault(info.path("description"), ""));
    builder.version(textOrDefault(info.path("version"), "1.0.0"));

    JsonNode servers = root.path("servers");
    if (servers.isArray() && servers.size() > 0) {
      String url = textOrDefault(servers.get(0).path("url"), "");
      if (!url.isBlank()) {
        builder.variable("baseUrl", url);
      }
    }

    JsonNode paths = root.path("paths");
    if (paths.isObject()) {
      Iterator<Map.Entry<String, JsonNode>> pathIter = paths.fields();
      while (pathIter.hasNext()) {
        Map.Entry<String, JsonNode> pathEntry = pathIter.next();
        String path = pathEntry.getKey();
        JsonNode pathItem = pathEntry.getValue();
        Iterator<Map.Entry<String, JsonNode>> methodIter = pathItem.fields();
        while (methodIter.hasNext()) {
          Map.Entry<String, JsonNode> methodEntry = methodIter.next();
          String method = methodEntry.getKey();
          if (!isHttpMethod(method)) {
            continue;
          }
          builder.addItem(buildItem(method.toUpperCase(), path, methodEntry.getValue()));
        }
      }
    }
    return builder.build();
  }

  private static PostmanItem buildItem(String method, String path, JsonNode operation) {
    String summary = textOrDefault(operation.path("summary"), method + " " + path);
    String description = textOrDefault(operation.path("description"), "");
    String name = description.isBlank() ? summary : summary + " — " + description;

    Map<String, String> headers = new HashMap<>();
    headers.put("Accept", "application/json");

    String body = extractRequestBody(operation);
    if (body != null) {
      headers.put("Content-Type", "application/json");
    }

    List<PostmanItem.PostmanParameter> params = extractParameters(operation);
    String url = "{{baseUrl}}" + path;

    return new PostmanItem(name, method, url, headers, body, params);
  }

  private static String extractRequestBody(JsonNode operation) {
    JsonNode requestBody = operation.path("requestBody");
    if (requestBody.isMissingNode() || requestBody.isNull()) {
      return null;
    }
    JsonNode jsonContent = requestBody.path("content").path("application/json");
    if (jsonContent.isMissingNode()) {
      return null;
    }
    JsonNode example = jsonContent.path("example");
    if (!example.isMissingNode() && !example.isNull()) {
      return example.toString();
    }
    JsonNode examples = jsonContent.path("examples");
    if (examples.isObject() && examples.size() > 0) {
      Iterator<Map.Entry<String, JsonNode>> iter = examples.fields();
      if (iter.hasNext()) {
        JsonNode firstExample = iter.next().getValue().path("value");
        if (!firstExample.isMissingNode()) {
          return firstExample.toString();
        }
      }
    }
    return "{}";
  }

  private static List<PostmanItem.PostmanParameter> extractParameters(JsonNode operation) {
    List<PostmanItem.PostmanParameter> out = new ArrayList<>();
    JsonNode params = operation.path("parameters");
    if (!params.isArray()) {
      return out;
    }
    for (JsonNode p : params) {
      String in = textOrDefault(p.path("in"), "");
      if (!"path".equals(in) && !"query".equals(in)) {
        continue;
      }
      String name = textOrDefault(p.path("name"), "");
      if (name.isBlank()) {
        continue;
      }
      String description = textOrDefault(p.path("description"), "");
      boolean required = p.path("required").asBoolean(false);
      String example = textOrDefault(p.path("example"), "");
      out.add(new PostmanItem.PostmanParameter(name, example, description, required));
    }
    return out;
  }

  private static String textOrDefault(JsonNode node, String fallback) {
    if (node == null || node.isMissingNode() || node.isNull()) {
      return fallback;
    }
    String text = node.asText();
    return text != null ? text : fallback;
  }

  private static boolean isHttpMethod(String method) {
    return switch (method.toLowerCase()) {
      case "get", "post", "put", "delete", "patch", "head", "options", "trace" -> true;
      default -> false;
    };
  }
}
