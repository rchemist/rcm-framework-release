/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.theme;

import io.rchemist.starter.document.annotation.AsciidocTheme;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * @AsciidocTheme 우선 + framework default fallback {@link ThemeResolver}.
 *
 * <p>해석 우선순위:
 * <ol>
 *   <li>{@code documentClass} 의 {@link AsciidocTheme} pdfTheme 가 비어있지 않으면 그 값 사용
 *       ({@code classpath:...} / {@code file:...} prefix 지원).</li>
 *   <li>비어있거나 annotation 미적용 시 {@link DefaultThemeResolver} 의 framework 한국어 default
 *       fallback.</li>
 * </ol>
 *
 * <p>fontDir 은 annotation 우선 + 빈 문자열 시 default resolver 의 fontDir.
 **/
public class AnnotationThemeResolver implements ThemeResolver {

  private static final String CLASSPATH_PREFIX = "classpath:";

  private final ThemeResolver fallback;

  public AnnotationThemeResolver(ThemeResolver fallback) {
    if (fallback == null) {
      throw new IllegalArgumentException("fallback must not be null");
    }
    this.fallback = fallback;
  }

  @Override
  public ResolvedTheme resolve(Class<?> documentClass) {
    AsciidocTheme annotation =
        documentClass != null ? documentClass.getAnnotation(AsciidocTheme.class) : null;
    if (annotation == null) {
      return fallback.resolve(documentClass);
    }
    String yaml = resolveYaml(annotation.pdfTheme());
    String fontDir =
        !annotation.fontDir().isBlank()
            ? annotation.fontDir()
            : fallback.resolve(documentClass).fontDir();
    return new ResolvedTheme(yaml, fontDir);
  }

  private String resolveYaml(String pdfTheme) {
    if (pdfTheme == null || pdfTheme.isBlank()) {
      return PdfThemeResource.defaultThemeYaml();
    }
    String resourcePath =
        pdfTheme.startsWith(CLASSPATH_PREFIX)
            ? pdfTheme.substring(CLASSPATH_PREFIX.length())
            : pdfTheme;
    // 미존재 시 framework default 로 graceful fallback (Consumer 가 misconfig 한 경우 silent skip
    // 차단을 위해 ThemeResolver 영역은 default 로 양보 — Consumer 는 실제 PDF 출력 시점에 폰트
    // 누락 등으로 알게 됨).
    try {
      return PdfThemeResource.loadFromClasspath(resourcePath);
    } catch (RuntimeException e) {
      return PdfThemeResource.defaultThemeYaml();
    }
  }
}
