/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * AsciiDoctor 출력 포맷.
 *
 * <ul>
 *   <li>{@link #PDF} — asciidoctorj-pdf backend.</li>
 *   <li>{@link #HTML} — HTML5 backend (default theme).</li>
 *   <li>{@link #DOCBOOK} — DocBook 5 XML.</li>
 *   <li>{@link #PLAIN} — 변환 없음 (raw AsciiDoc string).</li>
 * </ul>
 **/
public enum AsciidocFormat {
  PDF,
  HTML,
  DOCBOOK,
  PLAIN
}
