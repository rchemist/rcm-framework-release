/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * REST endpoint 문서화 — method 단위 메타데이터. 0.0.5 자산 100% 흡수 (gjcu 96.5% controller =
 * 2313 호출 정합). APT (rcm-apt) 가 OpenAPI {@code @Operation} + {@code @SecurityRequirement} 로
 * 자동 매핑 (Decision #15).
 *
 * @param value endpoint 제목.
 * @param description endpoint 설명.
 * @param stage 개발 단계 (e.g. {@code DRAFT}/{@code STABLE}/{@code DEPRECATED}).
 * @param auth 인증 필수 여부 (true = OAuth2 / JWT 영역, false = public).
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RestEndpoint {

  String value();

  String description() default "";

  String stage() default "STABLE";

  boolean auth() default true;
}
