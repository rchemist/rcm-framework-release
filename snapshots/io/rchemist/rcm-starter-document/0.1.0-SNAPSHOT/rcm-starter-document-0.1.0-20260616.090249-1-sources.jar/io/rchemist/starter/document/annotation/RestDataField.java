/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * DTO field 단위 문서화. 0.0.5 자산 흡수. APT 가 OpenAPI {@code @Schema(description, example,
 * requiredMode)} 로 자동 매핑.
 *
 * @param value field 이름 override (default = field 의 실 이름).
 * @param description 설명.
 * @param example 예시 값.
 * @param required 필수 여부.
 */
@Target({ElementType.FIELD, ElementType.RECORD_COMPONENT, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RestDataField {

  String value() default "";

  String description() default "";

  String example() default "";

  boolean required() default false;
}
