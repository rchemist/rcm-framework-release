/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.theme;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Theme 해석 SPI — class 단위 또는 글로벌로 PDF theme YAML 본문 + font directory 결정.
 *
 * <p>구현 = {@link DefaultThemeResolver} (framework default theme + Consumer override
 * 적용 가능).
 **/
public interface ThemeResolver {

  /**
   * 주어진 클래스 (e.g. {@code @RestDocument} controller) 에 대한 theme 해석.
   *
   * @param documentClass theme 적용 대상 (null = 글로벌 default).
   * @return 해석된 theme.
   */
  ResolvedTheme resolve(Class<?> documentClass);

  /**
   * 해석된 theme — yamlContent + fontDir.
   *
   * @param yamlContent PDF theme YAML 본문.
   * @param fontDir 폰트 directory (asciidoctor-pdf-fontsdir attribute 와 정합). 빈 문자열 OK
   *     (font catalog 의 fallbacks 만 사용).
   */
  record ResolvedTheme(String yamlContent, String fontDir) {

    public ResolvedTheme {
      if (yamlContent == null) {
        throw new IllegalArgumentException("yamlContent must not be null");
      }
      if (fontDir == null) {
        fontDir = "";
      }
    }
  }
}
