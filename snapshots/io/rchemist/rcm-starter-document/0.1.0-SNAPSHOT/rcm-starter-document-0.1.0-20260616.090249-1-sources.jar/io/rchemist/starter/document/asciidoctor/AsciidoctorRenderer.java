/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.asciidoctor;

import io.rchemist.starter.document.core.AsciidocFormat;
import io.rchemist.starter.document.core.exception.DocumentException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.asciidoctor.Asciidoctor;
import org.asciidoctor.Options;
import org.asciidoctor.SafeMode;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * AsciiDoctor JVM 직접 백엔드 (asciidoctorj-pdf 2.x). 0.0.5 의 CLI subprocess 기반 PDF 생성을
 * 격상 — JVM in-process 가 (a) 빠르고 (b) 의존 단순 (외부 ruby / asciidoctor binary 불필요).
 *
 * <p>지원 포맷:
 * <ul>
 *   <li>{@link AsciidocFormat#PLAIN} — raw AsciiDoc UTF-8 bytes pass-through.</li>
 *   <li>{@link AsciidocFormat#HTML} — HTML5 backend.</li>
 *   <li>{@link AsciidocFormat#DOCBOOK} — DocBook 5 backend.</li>
 *   <li>{@link AsciidocFormat#PDF} — asciidoctorj-pdf 2.x (Consumer 가 한국어 폰트 / pdf-theme
 *       wire 권장).</li>
 * </ul>
 *
 * <p>Note: {@link Asciidoctor#create()} 는 무거운 작업 (Ruby runtime startup ~1s) — bean scope =
 * singleton (default).
 **/
public class AsciidoctorRenderer implements DocumentRenderer {

  private static final String NAME = "asciidoctorj";

  private final Asciidoctor asciidoctor;
  private final Path pdfWorkDir;

  public AsciidoctorRenderer() {
    this(Asciidoctor.Factory.create(), tempPdfDir());
  }

  public AsciidoctorRenderer(Asciidoctor asciidoctor, Path pdfWorkDir) {
    if (asciidoctor == null) {
      throw new IllegalArgumentException("asciidoctor must not be null");
    }
    if (pdfWorkDir == null) {
      throw new IllegalArgumentException("pdfWorkDir must not be null");
    }
    this.asciidoctor = asciidoctor;
    this.pdfWorkDir = pdfWorkDir;
  }

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public byte[] render(String adoc, AsciidocFormat format) {
    if (adoc == null) {
      throw new IllegalArgumentException("adoc must not be null");
    }
    if (format == null) {
      throw new IllegalArgumentException("format must not be null");
    }
    return switch (format) {
      case PLAIN -> adoc.getBytes(StandardCharsets.UTF_8);
      case HTML -> renderText(adoc, "html5").getBytes(StandardCharsets.UTF_8);
      case DOCBOOK -> renderText(adoc, "docbook5").getBytes(StandardCharsets.UTF_8);
      case PDF -> renderPdf(adoc);
    };
  }

  private String renderText(String adoc, String backend) {
    Options options =
        Options.builder()
            .safe(SafeMode.UNSAFE)
            .backend(backend)
            .standalone(true)
            .build();
    return asciidoctor.convert(adoc, options);
  }

  private byte[] renderPdf(String adoc) {
    try {
      Files.createDirectories(pdfWorkDir);
      Path tempFile = Files.createTempFile(pdfWorkDir, "doc-", ".pdf");
      try {
        Options options =
            Options.builder()
                .safe(SafeMode.UNSAFE)
                .backend("pdf")
                .standalone(true)
                .toFile(tempFile.toFile())
                .build();
        asciidoctor.convert(adoc, options);
        return Files.readAllBytes(tempFile);
      } finally {
        Files.deleteIfExists(tempFile);
      }
    } catch (IOException e) {
      throw new DocumentException("PDF render failed", e);
    }
  }

  private static Path tempPdfDir() {
    return Path.of(System.getProperty("java.io.tmpdir"), "rcm-document-pdf");
  }
}
