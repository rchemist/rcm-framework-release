/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.dbschema;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * UI 메타데이터 — entity field / Records component 의 사용자 친화 표기 영역. {@code @Comment}
 * (DDL persist) 와 별개로 {@code rcm-listgrid} frontend 의 admin 화면 자동 생성 영역.
 *
 * <p>0.0.5 자산 흡수 + 보존 (Decision #14 보강 정합).
 *
 * @param friendlyName 사용자 표기 이름 (default = field 의 실 이름).
 * @param tooltip mouse-over tooltip.
 * @param helpText form 아래 도움말 텍스트.
 * @param hint placeholder / 부가 안내.
 */
@Target({ElementType.FIELD, ElementType.RECORD_COMPONENT, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface AdminField {

  String friendlyName() default "";

  String tooltip() default "";

  String helpText() default "";

  String hint() default "";
}
