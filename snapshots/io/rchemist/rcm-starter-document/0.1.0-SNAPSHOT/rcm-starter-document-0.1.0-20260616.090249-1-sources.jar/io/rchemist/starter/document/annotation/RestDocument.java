/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * REST 문서화 — controller 단위 메타데이터. 0.0.5 자산 100% 흡수. APT (rcm-apt) 가 컴파일 시점에
 * OpenAPI {@code @Tag} 로 자동 매핑 (Decision #15).
 *
 * @param value 문서 제목.
 * @param description 문서 설명 (빈 문자열 OK).
 * @param order 정렬 순서 (lower = first).
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface RestDocument {

  String value();

  String description() default "";

  int order() default 0;
}
