/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.autoconfig;

import io.rchemist.starter.document.asciidoctor.AsciidoctorRenderer;
import io.rchemist.starter.document.asciidoctor.DocumentRenderer;
import io.rchemist.starter.document.asciidoctor.NoopDocumentRenderer;
import io.rchemist.starter.document.core.DocumentBuilder;
import io.rchemist.starter.document.core.SimpleDocumentBuilder;
import io.rchemist.starter.document.dbschema.DbSchemaDocumentRenderer;
import io.rchemist.starter.document.postman.OpenApiToPostmanConverter;
import io.rchemist.starter.document.postman.PostmanJsonExporter;
import io.rchemist.starter.document.theme.AnnotationThemeResolver;
import io.rchemist.starter.document.theme.DefaultThemeResolver;
import io.rchemist.starter.document.theme.ThemeResolver;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6.9 task #1 — {@code rcm-starter-document} 진입점 (Decision #14 옵션 starter).
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>Decision #20 — prefix 없음. starter / 패키지 가 도메인 영역 자체 명시
 *       ({@code io.rchemist.starter.document}). class 이름 = 도메인 의미 풀네임 ({@code Document}
 *       / {@code DocumentBuilder} / {@code AsciidoctorRenderer} / {@code PostmanCollection}).</li>
 *   <li>{@code platform.document.enabled=false} 로 opt-out (default true).</li>
 *   <li>8 inner static config marker — task #2~#9 진입 시 본문 채움 (core / restAnnotation /
 *       asciidoctor / theme / postman / openApi / dbSchema / endpoint).</li>
 * </ul>
 *
 * <p>Phase 5 / 6 / 6.5 / 6.7 / 6.8 의 *AutoConfiguration 패턴 정합.
 **/
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.document", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(DocumentProperties.class)
public class DocumentAutoConfiguration {

  /** Phase 6.9 task #2 — Document core SPI / Records / DocumentBuilder. */
  @Configuration(proxyBeanMethods = false)
  static class CoreBeans {

    /**
     * Default {@link DocumentBuilder} = {@link SimpleDocumentBuilder} prototype scope. stateful
     * builder 는 호출 별로 신규 인스턴스 가능.
     */
    @Bean
    @Scope("prototype")
    @ConditionalOnMissingBean(DocumentBuilder.class)
    DocumentBuilder simpleDocumentBuilder() {
      return new SimpleDocumentBuilder();
    }
  }

  /** Phase 6.9 task #3 — 5 종 REST 어노테이션 (annotation 영역, no bean). */
  @Configuration(proxyBeanMethods = false)
  static class RestAnnotationBeans {}

  /** Phase 6.9 task #4 — AsciiDoctor backend (PDF/HTML/DocBook). */
  @Configuration(proxyBeanMethods = false)
  static class AsciidoctorBeans {

    /**
     * {@link AsciidoctorRenderer} — asciidoctorj on classpath 시 활성. asciidoctorj 의 ruby
     * runtime startup 비용 (~1s) 이라 singleton scope 권장.
     */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(name = "org.asciidoctor.Asciidoctor")
    static class WhenAsciidoctorPresent {

      @Bean
      @ConditionalOnMissingBean(DocumentRenderer.class)
      DocumentRenderer asciidoctorRenderer() {
        return new AsciidoctorRenderer();
      }
    }

    /** Fallback default — asciidoctorj 미설정 시 fail-loud. */
    @Bean
    @ConditionalOnMissingBean(DocumentRenderer.class)
    DocumentRenderer noopDocumentRenderer() {
      return new NoopDocumentRenderer();
    }
  }

  /** Phase 6.9 task #5~#6 — 한국어 theme baseline + @AsciidocTheme override. */
  @Configuration(proxyBeanMethods = false)
  static class ThemeBeans {

    /**
     * Default {@link ThemeResolver} = {@link AnnotationThemeResolver} wrapping {@link
     * DefaultThemeResolver}. annotation 우선 + framework 한국어 default fallback.
     */
    @Bean
    @ConditionalOnMissingBean(ThemeResolver.class)
    ThemeResolver annotationThemeResolver(DocumentProperties properties) {
      return new AnnotationThemeResolver(new DefaultThemeResolver(properties.theme().fontDir()));
    }
  }

  /** Phase 6.9 task #7 — Postman JSON export. */
  @Configuration(proxyBeanMethods = false)
  static class PostmanBeans {

    @Bean
    @ConditionalOnMissingBean(PostmanJsonExporter.class)
    PostmanJsonExporter postmanJsonExporter() {
      return new PostmanJsonExporter();
    }
  }

  /** Phase 6.9 task #8 — OpenAPI → Postman 변환. */
  @Configuration(proxyBeanMethods = false)
  static class OpenApiBeans {

    @Bean
    @ConditionalOnMissingBean(OpenApiToPostmanConverter.class)
    OpenApiToPostmanConverter openApiToPostmanConverter() {
      return new OpenApiToPostmanConverter();
    }
  }

  /** Phase 6.9 task #9 — DB schema docs (Hibernate @Comment). */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(name = "jakarta.persistence.Entity")
  static class DbSchemaBeans {

    @Bean
    @ConditionalOnMissingBean(DbSchemaDocumentRenderer.class)
    DbSchemaDocumentRenderer dbSchemaDocumentRenderer() {
      return new DbSchemaDocumentRenderer();
    }
  }

  /** Phase 6.9 task — runtime endpoints (옵션). */
  @Configuration(proxyBeanMethods = false)
  static class EndpointBeans {}
}
