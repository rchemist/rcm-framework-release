/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.postman;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Postman Collection v2.1 안 단일 endpoint item (Records).
 *
 * @param name 표시 이름.
 * @param method HTTP method (GET/POST/PUT/DELETE/...).
 * @param url 절대 또는 상대 URL ({@code {{baseUrl}}/api/v1/articles}).
 * @param headers HTTP header map (immutable copy).
 * @param body 요청 body (raw string, JSON 가정 - null OK for GET).
 * @param parameters URL/Query parameters (immutable copy).
 */
public record PostmanItem(
    String name,
    String method,
    String url,
    Map<String, String> headers,
    String body,
    List<PostmanParameter> parameters) {

  public PostmanItem {
    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("name must not be blank");
    }
    if (method == null || method.isBlank()) {
      throw new IllegalArgumentException("method must not be blank");
    }
    if (url == null || url.isBlank()) {
      throw new IllegalArgumentException("url must not be blank");
    }
    headers = headers != null ? Map.copyOf(headers) : Map.of();
    parameters = parameters != null ? List.copyOf(parameters) : List.of();
  }

  /** Path / query parameter (Records). */
  public record PostmanParameter(String name, String value, String description, boolean required) {

    public PostmanParameter {
      if (name == null || name.isBlank()) {
        throw new IllegalArgumentException("name must not be blank");
      }
      if (value == null) {
        value = "";
      }
      if (description == null) {
        description = "";
      }
    }
  }
}
