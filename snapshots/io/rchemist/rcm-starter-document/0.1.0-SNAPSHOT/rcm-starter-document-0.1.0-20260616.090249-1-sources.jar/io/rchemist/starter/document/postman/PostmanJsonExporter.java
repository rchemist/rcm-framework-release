/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.postman;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.rchemist.starter.document.core.exception.DocumentException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Postman Collection v2.1 → JSON 직렬화. 0.0.5 의 {@code DocumentHelper} 자산 흡수.
 *
 * <p>출력 = pretty-printed JSON ({@link SerializationFeature#INDENT_OUTPUT}). Postman 데스크톱
 * 또는 Newman CLI 가 import 해서 사용.
 **/
public class PostmanJsonExporter {

  private final ObjectMapper mapper;

  public PostmanJsonExporter() {
    this(new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT));
  }

  public PostmanJsonExporter(ObjectMapper mapper) {
    if (mapper == null) {
      throw new IllegalArgumentException("mapper must not be null");
    }
    this.mapper = mapper;
  }

  /** Collection → Postman v2.1 JSON string. */
  public String export(PostmanCollection collection) {
    if (collection == null) {
      throw new IllegalArgumentException("collection must not be null");
    }
    Map<String, Object> root = new LinkedHashMap<>();
    root.put("info", buildInfo(collection.info()));
    root.put("item", buildItems(collection.items()));
    if (!collection.variables().isEmpty()) {
      root.put("variable", buildVariables(collection.variables()));
    }
    try {
      return mapper.writeValueAsString(root);
    } catch (JsonProcessingException e) {
      throw new DocumentException("Postman JSON 직렬화 실패", e);
    }
  }

  private static Map<String, Object> buildInfo(PostmanCollection.Info info) {
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("_postman_id", info.postmanId());
    out.put("name", info.name());
    if (!info.description().isBlank()) {
      out.put("description", info.description());
    }
    out.put("schema", PostmanCollection.SCHEMA);
    out.put("_exporter_id", "rcm-starter-document");
    out.put("version", info.version());
    return out;
  }

  private static List<Map<String, Object>> buildItems(List<PostmanItem> items) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (PostmanItem item : items) {
      out.add(buildItem(item));
    }
    return out;
  }

  private static Map<String, Object> buildItem(PostmanItem item) {
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("name", item.name());
    Map<String, Object> request = new LinkedHashMap<>();
    request.put("method", item.method().toUpperCase());
    request.put("header", buildHeaders(item.headers()));
    Map<String, Object> url = new LinkedHashMap<>();
    url.put("raw", item.url());
    request.put("url", url);
    if (item.body() != null && !item.body().isBlank()) {
      Map<String, Object> body = new LinkedHashMap<>();
      body.put("mode", "raw");
      body.put("raw", item.body());
      Map<String, Object> options = new LinkedHashMap<>();
      Map<String, Object> raw = new LinkedHashMap<>();
      raw.put("language", "json");
      options.put("raw", raw);
      body.put("options", options);
      request.put("body", body);
    }
    out.put("request", request);
    if (!item.parameters().isEmpty()) {
      out.put("parameter", buildParameters(item.parameters()));
    }
    return out;
  }

  private static List<Map<String, Object>> buildHeaders(Map<String, String> headers) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (Map.Entry<String, String> entry : headers.entrySet()) {
      Map<String, Object> header = new LinkedHashMap<>();
      header.put("key", entry.getKey());
      header.put("value", entry.getValue());
      header.put("type", "text");
      out.add(header);
    }
    return out;
  }

  private static List<Map<String, Object>> buildParameters(List<PostmanItem.PostmanParameter> params) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (PostmanItem.PostmanParameter p : params) {
      Map<String, Object> param = new LinkedHashMap<>();
      param.put("key", p.name());
      param.put("value", p.value());
      if (!p.description().isBlank()) {
        param.put("description", p.description());
      }
      param.put("required", p.required());
      out.add(param);
    }
    return out;
  }

  private static List<Map<String, Object>> buildVariables(Map<String, String> variables) {
    List<Map<String, Object>> out = new ArrayList<>();
    for (Map.Entry<String, String> entry : variables.entrySet()) {
      Map<String, Object> variable = new LinkedHashMap<>();
      variable.put("key", entry.getKey());
      variable.put("value", entry.getValue());
      out.add(variable);
    }
    return out;
  }
}
