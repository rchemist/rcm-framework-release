/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.dbschema;

import io.rchemist.starter.document.core.DocumentBuilder;
import io.rchemist.starter.document.core.SimpleDocumentBuilder;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Hibernate `@Comment` / JPA 3.2 `@Column.comment` 활용 DB schema 문서 생성. Reflection 기반 —
 * Hibernate Metadata API 가 없어도 entity class 만으로 문서 생성. Consumer 가 controller /
 * service 에서 `dbSchemaDocumentRenderer.renderEntity(Article.class)` 한 호출로 AsciiDoc 표
 * 생성.
 *
 * <p>표 columns: 컬럼 / 타입 / nullable / FK / @Column.comment (또는 Hibernate @Comment) /
 * @AdminField friendlyName.
 *
 * <p>0.0.5 자산 정합 — `/doc/table` runtime endpoint (Decision #15 보강 영역) 가 Phase 6.9 의
 * runtime endpoint (Phase 6.9 task — endpoint 영역) 에서 본 renderer 호출.
 **/
public class DbSchemaDocumentRenderer {

  private static final String[] HEADERS = {
    "Column", "Type", "Nullable", "FK", "Comment", "Friendly Name"
  };

  /** 단일 entity 의 schema 표 → AsciiDoc string. */
  public String renderEntity(Class<?> entityClass) {
    if (entityClass == null) {
      throw new IllegalArgumentException("entityClass must not be null");
    }
    DocumentBuilder builder = new SimpleDocumentBuilder();
    builder.title("DB Schema");
    return renderEntityInto(builder, entityClass).toAsciidoc();
  }

  /** 다중 entity 일괄 — single document. */
  public String renderEntities(Iterable<Class<?>> entityClasses) {
    if (entityClasses == null) {
      throw new IllegalArgumentException("entityClasses must not be null");
    }
    DocumentBuilder builder = new SimpleDocumentBuilder().title("DB Schema");
    for (Class<?> entityClass : entityClasses) {
      renderEntityInto(builder, entityClass);
    }
    return builder.toAsciidoc();
  }

  private DocumentBuilder renderEntityInto(DocumentBuilder builder, Class<?> entityClass) {
    String tableName = resolveTableName(entityClass);
    String heading =
        entityClass.getSimpleName() + (tableName != null ? " (" + tableName + ")" : "");
    builder.section(2, heading, "");

    List<String[]> rows = new ArrayList<>();
    for (Field field : entityClass.getDeclaredFields()) {
      if (field.isSynthetic()) {
        continue;
      }
      rows.add(rowOf(field));
    }
    String[][] rowArray = rows.toArray(new String[0][]);
    builder.table(HEADERS, rowArray);
    return builder;
  }

  private String[] rowOf(Field field) {
    Column column = field.getAnnotation(Column.class);
    JoinColumn joinColumn = field.getAnnotation(JoinColumn.class);
    AdminField admin = field.getAnnotation(AdminField.class);
    boolean isId = field.isAnnotationPresent(Id.class);

    String columnName = resolveColumnName(field, column, joinColumn);
    String type = field.getType().getSimpleName();
    String nullable;
    if (isId) {
      nullable = "no";
    } else if (column != null) {
      nullable = column.nullable() ? "yes" : "no";
    } else if (joinColumn != null) {
      nullable = joinColumn.nullable() ? "yes" : "no";
    } else {
      nullable = "yes";
    }
    String fk = joinColumn != null ? "yes" : "";
    String comment = resolveComment(field, column);
    String friendlyName = admin != null ? admin.friendlyName() : "";
    return new String[] {columnName, type, nullable, fk, comment, friendlyName};
  }

  private static String resolveTableName(Class<?> entityClass) {
    Table table = entityClass.getAnnotation(Table.class);
    if (table != null && !table.name().isBlank()) {
      return table.name();
    }
    if (entityClass.isAnnotationPresent(Entity.class)) {
      return camelToSnakeUpper(entityClass.getSimpleName());
    }
    return null;
  }

  private static String resolveColumnName(Field field, Column column, JoinColumn joinColumn) {
    if (column != null && !column.name().isBlank()) {
      return column.name();
    }
    if (joinColumn != null && !joinColumn.name().isBlank()) {
      return joinColumn.name();
    }
    return camelToSnakeLower(field.getName());
  }

  private static String resolveComment(Field field, Column column) {
    if (column != null && !column.comment().isBlank()) {
      return column.comment();
    }
    // Hibernate @Comment 도 try (org.hibernate.annotations.Comment 가 classpath 에 있으면).
    try {
      Class<?> hibernateComment =
          Class.forName("org.hibernate.annotations.Comment");
      java.lang.annotation.Annotation hibAnnotation =
          field.getAnnotation((Class) hibernateComment);
      if (hibAnnotation != null) {
        java.lang.reflect.Method valueMethod = hibernateComment.getMethod("value");
        Object value = valueMethod.invoke(hibAnnotation);
        return value != null ? value.toString() : "";
      }
    } catch (ReflectiveOperationException ignored) {
      // Hibernate not on classpath or annotation not present — graceful.
    }
    return "";
  }

  private static String camelToSnakeLower(String name) {
    return convert(name).toLowerCase(Locale.ROOT);
  }

  private static String camelToSnakeUpper(String name) {
    return "T_" + convert(name).toUpperCase(Locale.ROOT);
  }

  private static String convert(String name) {
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < name.length(); i++) {
      char c = name.charAt(i);
      if (Character.isUpperCase(c) && i > 0) {
        out.append('_');
      }
      out.append(c);
    }
    return out.toString();
  }
}
