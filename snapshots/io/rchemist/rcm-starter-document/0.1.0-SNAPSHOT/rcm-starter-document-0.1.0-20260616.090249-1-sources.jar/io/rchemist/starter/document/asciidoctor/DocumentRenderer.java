/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.asciidoctor;

import io.rchemist.starter.document.core.AsciidocFormat;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Document rendering SPI — AsciiDoc string → byte[] (PDF/HTML/DocBook). 백엔드 추상화로 0.0.5
 * 의 CLI subprocess 기반 PDF 생성을 JVM 직접 호출 (asciidoctorj-pdf) 으로 격상.
 *
 * <p>구현 = {@link AsciidoctorRenderer} (asciidoctorj 의존 시) 또는 {@link
 * NoopDocumentRenderer} fail-loud (의존 미설정 시).
 **/
public interface DocumentRenderer {

  /** SPI 식별 이름 (e.g. {@code asciidoctorj} / {@code noop}). */
  String name();

  /**
   * Render AsciiDoc string → byte[].
   *
   * @param adoc AsciiDoc 본문.
   * @param format 출력 포맷 ({@link AsciidocFormat}).
   * @return 변환 결과 byte[]. {@link AsciidocFormat#PLAIN} 은 raw bytes pass-through.
   */
  byte[] render(String adoc, AsciidocFormat format);
}
