/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@code platform.document.*} prefix yml binding —
 * {@link DocumentAutoConfiguration} 의 단일 진입점.
 *
 * <p>{@code enabled} = autoconfig 자체 opt-out flag (default true). theme baseline = 한국어
 * 폰트 default (본명조/나눔고딕/D2Coding 외부 reference, Consumer 가 폰트 파일 / pdf-theme override
 * 가능).
 **/
@ConfigurationProperties(prefix = "platform.document")
public record DocumentProperties(@DefaultValue("true") boolean enabled, @DefaultValue Theme theme) {

  /** Theme 영역 — pdf theme 파일 경로 / 폰트 directory 등 ({@code platform.document.theme.*}). */
  public record Theme(
      @DefaultValue("classpath:io/rchemist/starter/document/theme/default-pdf-theme.yml")
          String pdfTheme,
      @DefaultValue("") String fontDir) {}
}
