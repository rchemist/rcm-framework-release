/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default {@link DocumentBuilder} — StringBuilder + Records 백업. 외부 의존 0. AsciiDoc 출력
 * 직접 생성.
 *
 * <p>thread-safety: stateful builder — 단일 thread 영역 사용 권장 (Spring prototype scope).
 **/
public class SimpleDocumentBuilder implements DocumentBuilder {

  private String title = "Untitled";
  private String author;
  private final List<DocumentSection> sections = new ArrayList<>();
  private final Map<String, String> metadata = new LinkedHashMap<>();
  private final StringBuilder buffer = new StringBuilder();

  @Override
  public DocumentBuilder title(String title) {
    if (title == null || title.isBlank()) {
      throw new IllegalArgumentException("title must not be blank");
    }
    this.title = title;
    return this;
  }

  @Override
  public DocumentBuilder author(String author) {
    this.author = author;
    return this;
  }

  @Override
  public DocumentBuilder section(int level, String heading, String content) {
    DocumentSection section = new DocumentSection(level, heading, content != null ? content : "");
    sections.add(section);
    buffer.append("\n").append("=".repeat(level)).append(" ").append(heading).append("\n\n");
    if (content != null && !content.isBlank()) {
      buffer.append(content).append("\n");
    }
    return this;
  }

  @Override
  public DocumentBuilder paragraph(String text) {
    if (text != null && !text.isBlank()) {
      buffer.append("\n").append(text).append("\n");
    }
    return this;
  }

  @Override
  public DocumentBuilder code(String language, String code) {
    String lang = language != null ? language : "";
    buffer.append("\n[source");
    if (!lang.isEmpty()) {
      buffer.append(",").append(lang);
    }
    buffer.append("]\n----\n").append(code != null ? code : "").append("\n----\n");
    return this;
  }

  @Override
  public DocumentBuilder table(String[] headers, String[][] rows) {
    if (headers == null || headers.length == 0) {
      throw new IllegalArgumentException("headers must not be empty");
    }
    buffer.append("\n[options=\"header\"]\n|===\n");
    buffer.append("| ").append(String.join(" | ", headers)).append("\n");
    if (rows != null) {
      for (String[] row : rows) {
        buffer.append("| ").append(String.join(" | ", row)).append("\n");
      }
    }
    buffer.append("|===\n");
    return this;
  }

  @Override
  public DocumentBuilder attribute(String key, String value) {
    if (key == null || key.isBlank()) {
      throw new IllegalArgumentException("attribute key must not be blank");
    }
    metadata.put(key, value != null ? value : "");
    return this;
  }

  @Override
  public Document build() {
    return new Document(title, author, sections, metadata);
  }

  @Override
  public String toAsciidoc() {
    StringBuilder out = new StringBuilder();
    out.append("= ").append(title).append("\n");
    if (author != null && !author.isBlank()) {
      out.append(author).append("\n");
    }
    for (Map.Entry<String, String> entry : metadata.entrySet()) {
      out.append(":").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
    }
    out.append(buffer);
    return out.toString();
  }
}
