/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.postman;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Postman Collection v2.1 (Records). 0.0.5 의 {@code DocumentHelper} Postman JSON export 자산
 * 흡수.
 *
 * @param info collection metadata (name / description / version / postman_id).
 * @param items endpoint 리스트.
 * @param variables 환경 변수 (e.g. {@code baseUrl}).
 */
public record PostmanCollection(Info info, List<PostmanItem> items, Map<String, String> variables) {

  public static final String SCHEMA =
      "https://schema.getpostman.com/json/collection/v2.1.0/collection.json";

  public PostmanCollection {
    if (info == null) {
      throw new IllegalArgumentException("info must not be null");
    }
    items = items != null ? List.copyOf(items) : List.of();
    variables = variables != null ? Map.copyOf(variables) : Map.of();
  }

  /** Collection metadata Records. */
  public record Info(String postmanId, String name, String description, String version) {

    public Info {
      if (name == null || name.isBlank()) {
        throw new IllegalArgumentException("name must not be blank");
      }
      if (postmanId == null || postmanId.isBlank()) {
        postmanId = UUID.randomUUID().toString();
      }
      if (description == null) {
        description = "";
      }
      if (version == null) {
        version = "1.0.0";
      }
    }

    /** {@code name} 만 인자로 받는 minimal factory (id auto / version 1.0.0). */
    public static Info of(String name) {
      return new Info(null, name, "", "1.0.0");
    }
  }
}
