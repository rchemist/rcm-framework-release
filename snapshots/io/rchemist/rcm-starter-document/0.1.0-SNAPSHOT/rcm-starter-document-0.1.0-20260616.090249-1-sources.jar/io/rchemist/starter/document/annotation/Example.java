/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 예시 값 — parameter / field / method 영역 활용. APT 가 OpenAPI {@code @Parameter(example)}
 * / {@code @Schema(example)} 로 자동 매핑.
 *
 * @param value 예시 값 (string 표현).
 * @param description 예시 설명.
 */
@Target({
  ElementType.PARAMETER,
  ElementType.FIELD,
  ElementType.RECORD_COMPONENT,
  ElementType.METHOD
})
@Retention(RetentionPolicy.RUNTIME)
public @interface Example {

  String value();

  String description() default "";
}
