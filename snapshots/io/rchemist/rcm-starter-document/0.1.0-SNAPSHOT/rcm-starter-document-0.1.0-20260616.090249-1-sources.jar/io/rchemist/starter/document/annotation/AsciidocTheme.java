/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 클래스 단위 PDF/HTML theme override — framework 의 한국어 default theme 대신 Consumer 자체
 * theme 적용. {@code @RestDocument} 와 함께 controller / DocumentBuilder factory class 에 부착.
 *
 * @param pdfTheme PDF theme 경로 (classpath:... 또는 file:..., 빈 문자열 = framework default
 *     사용).
 * @param fontDir 폰트 directory (asciidoctor-pdf-fontsdir 정합, 빈 문자열 = catalog fallback).
 * @param css HTML 출력용 custom CSS (file path 또는 inline). 빈 문자열 = default.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface AsciidocTheme {

  String pdfTheme() default "";

  String fontDir() default "";

  String css() default "";
}
