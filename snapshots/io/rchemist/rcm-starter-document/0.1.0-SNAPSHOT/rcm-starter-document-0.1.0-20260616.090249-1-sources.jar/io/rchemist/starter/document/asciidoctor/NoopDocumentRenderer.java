/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.asciidoctor;

import io.rchemist.starter.document.core.AsciidocFormat;
import io.rchemist.starter.document.core.exception.DocumentException;
import java.nio.charset.StandardCharsets;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default {@link DocumentRenderer} — asciidoctorj 의존 미설정 시 활성. {@link
 * AsciidocFormat#PLAIN} 만 raw bytes pass-through, 나머지 (HTML/DOCBOOK/PDF) 는 명시 에러로
 * Consumer 에게 어댑터 wire 안내.
 **/
public class NoopDocumentRenderer implements DocumentRenderer {

  private static final String NAME = "noop";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public byte[] render(String adoc, AsciidocFormat format) {
    if (adoc == null) {
      throw new IllegalArgumentException("adoc must not be null");
    }
    if (format == null) {
      throw new IllegalArgumentException("format must not be null");
    }
    if (format == AsciidocFormat.PLAIN) {
      return adoc.getBytes(StandardCharsets.UTF_8);
    }
    throw new DocumentException(
        "asciidoctorj 미설정 — Consumer 가 `org.asciidoctor:asciidoctorj-pdf` runtime 의존 + AsciidoctorRenderer wire 필요 (format=%s)"
            .formatted(format));
  }
}
