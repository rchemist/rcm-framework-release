/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.theme;

import io.rchemist.starter.document.core.exception.DocumentException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Default PDF theme YAML 의 classpath 접근 helper. {@link
 * #DEFAULT_RESOURCE_PATH} 가 framework 기본 한국어 theme (Noto Sans KR / Nanum Gothic /
 * D2Coding) reference. Consumer 가 자체 yml 사용 시 본 helper 무시.
 **/
public final class PdfThemeResource {

  /** Framework default theme 의 classpath 위치. */
  public static final String DEFAULT_RESOURCE_PATH =
      "io/rchemist/starter/document/theme/default-pdf-theme.yml";

  private PdfThemeResource() {}

  /** Default theme YAML 본문 (UTF-8 string). */
  public static String defaultThemeYaml() {
    return loadFromClasspath(DEFAULT_RESOURCE_PATH);
  }

  /** Classpath 안 임의 path 로부터 YAML 본문 load. 미존재 = {@link DocumentException}. */
  public static String loadFromClasspath(String path) {
    if (path == null || path.isBlank()) {
      throw new IllegalArgumentException("path must not be blank");
    }
    ClassLoader cl = PdfThemeResource.class.getClassLoader();
    try (InputStream stream = cl.getResourceAsStream(path)) {
      if (stream == null) {
        throw new DocumentException("classpath resource not found: " + path);
      }
      return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new DocumentException("failed to load classpath resource: " + path, e);
    }
  }
}
