/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.core;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Document Records — title + sections + metadata.
 *
 * <p>{@link DocumentBuilder} 가 본 Records 를 build, {@code AsciiDoctorRenderer} 가 PDF / HTML
 * 으로 변환.
 *
 * @param title 문서 전체 제목.
 * @param author 저자 (옵션, null OK).
 * @param sections section 리스트.
 * @param metadata 사용자 정의 attribute (header / cover page 적용 자료, immutable copy).
 */
public record Document(
    String title, String author, List<DocumentSection> sections, Map<String, String> metadata) {

  public Document {
    if (title == null || title.isBlank()) {
      throw new IllegalArgumentException("title must not be blank");
    }
    sections = sections != null ? List.copyOf(sections) : List.of();
    metadata = metadata != null ? Map.copyOf(metadata) : Map.of();
  }

  /** {@code title} 만 인자로 받는 minimal factory. */
  public static Document of(String title) {
    return new Document(title, null, List.of(), Map.of());
  }
}
