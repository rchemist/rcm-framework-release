/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.core.exception;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Document 영역 RuntimeException base — render 실패 / asciidoctorj 의존 미설정 / PDF 변환 IO
 * 실패 등.
 **/
public class DocumentException extends RuntimeException {

  public DocumentException(String message) {
    super(message);
  }

  public DocumentException(String message, Throwable cause) {
    super(message, cause);
  }
}
