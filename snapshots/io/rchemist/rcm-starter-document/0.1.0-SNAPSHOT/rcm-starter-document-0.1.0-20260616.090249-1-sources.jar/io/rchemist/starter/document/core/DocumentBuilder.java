/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Document DSL builder — programmatic AsciiDoc 생성 SPI. 0.0.5 의 {@code DocumentBuilder} 자산
 * 흡수.
 *
 * <p>API:
 * <ul>
 *   <li>{@link #title} — 전체 제목 + author 설정.</li>
 *   <li>{@link #section} — heading + 본문 작성.</li>
 *   <li>{@link #paragraph} — 단순 text.</li>
 *   <li>{@link #code} — code block (language hint 포함).</li>
 *   <li>{@link #table} — 표 (headers + 2-D rows).</li>
 *   <li>{@link #attribute} — metadata 추가 (Cover page 등).</li>
 *   <li>{@link #build} — {@link Document} Records 반환.</li>
 *   <li>{@link #toAsciidoc} — raw AsciiDoc string 직접 반환.</li>
 * </ul>
 **/
public interface DocumentBuilder {

  DocumentBuilder title(String title);

  DocumentBuilder author(String author);

  DocumentBuilder section(int level, String heading, String content);

  DocumentBuilder paragraph(String text);

  DocumentBuilder code(String language, String code);

  DocumentBuilder table(String[] headers, String[][] rows);

  DocumentBuilder attribute(String key, String value);

  Document build();

  String toAsciidoc();
}
