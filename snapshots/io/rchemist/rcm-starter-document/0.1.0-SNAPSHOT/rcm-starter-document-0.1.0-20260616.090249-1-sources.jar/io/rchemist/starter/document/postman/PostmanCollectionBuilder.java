/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.document.postman;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Mutable builder — DSL chain 으로 {@link PostmanCollection} build.
 **/
public class PostmanCollectionBuilder {

  private String name = "Untitled";
  private String description = "";
  private String version = "1.0.0";
  private final List<PostmanItem> items = new ArrayList<>();
  private final Map<String, String> variables = new LinkedHashMap<>();

  public PostmanCollectionBuilder name(String name) {
    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("name must not be blank");
    }
    this.name = name;
    return this;
  }

  public PostmanCollectionBuilder description(String description) {
    this.description = description != null ? description : "";
    return this;
  }

  public PostmanCollectionBuilder version(String version) {
    this.version = version != null ? version : "1.0.0";
    return this;
  }

  public PostmanCollectionBuilder addItem(PostmanItem item) {
    if (item == null) {
      throw new IllegalArgumentException("item must not be null");
    }
    items.add(item);
    return this;
  }

  public PostmanCollectionBuilder variable(String key, String value) {
    if (key == null || key.isBlank()) {
      throw new IllegalArgumentException("key must not be blank");
    }
    variables.put(key, value != null ? value : "");
    return this;
  }

  public PostmanCollection build() {
    return new PostmanCollection(
        new PostmanCollection.Info(null, name, description, version), items, variables);
  }
}
