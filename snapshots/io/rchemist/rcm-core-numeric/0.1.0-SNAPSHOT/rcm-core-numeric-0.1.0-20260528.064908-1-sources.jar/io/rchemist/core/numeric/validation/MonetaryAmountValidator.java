/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.validation;

import io.rchemist.core.numeric.money.Money;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link MonetaryAmount} validator — null pass-through (그쪽은 {@code @NotNull} 영역).
 *
 * <p>입력 type 별 처리: Money 면 currency 자동 검증, BigDecimal/Long/Number/String 은
 * 정량 검증만 (currency 옵션은 무시 — 원시 타입에 통화 정보가 없음).
 */
public class MonetaryAmountValidator implements ConstraintValidator<MonetaryAmount, Object> {

  private BigDecimal min;
  private BigDecimal max;
  private String currency;
  private boolean allowNegative;

  @Override
  public void initialize(MonetaryAmount constraintAnnotation) {
    this.min = parseOrNull(constraintAnnotation.min());
    this.max = parseOrNull(constraintAnnotation.max());
    this.currency = constraintAnnotation.currency();
    this.allowNegative = constraintAnnotation.allowNegative();
  }

  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    }
    BigDecimal amount;
    String actualCurrency = null;
    if (value instanceof Money money) {
      amount = money.amount();
      actualCurrency = money.currency().getCurrencyCode();
    } else if (value instanceof BigDecimal bd) {
      amount = bd;
    } else if (value instanceof Number num) {
      amount = new BigDecimal(num.toString());
    } else if (value instanceof CharSequence cs) {
      try {
        amount = new BigDecimal(cs.toString());
      } catch (NumberFormatException e) {
        return false;
      }
    } else {
      return false;
    }
    if (!allowNegative && amount.signum() < 0) {
      return false;
    }
    if (min != null && amount.compareTo(min) < 0) {
      return false;
    }
    if (max != null && amount.compareTo(max) > 0) {
      return false;
    }
    if (!currency.isEmpty() && actualCurrency != null && !currency.equals(actualCurrency)) {
      return false;
    }
    return true;
  }

  private static BigDecimal parseOrNull(String text) {
    if (text == null || text.isEmpty()) {
      return null;
    }
    return new BigDecimal(text);
  }
}
