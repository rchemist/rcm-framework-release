/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.percentage;

import io.rchemist.core.numeric.money.Money;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 비율 immutable Records — 0~1 ratio 정규화 기준 (50% = 0.5).
 *
 * <p>입력 편의를 위해 {@link #of(int)} / {@link #of(double)} 는 *percent 단위* (50 → 0.5),
 * {@link #ofRatio(BigDecimal)} 는 *ratio 단위* (0.5 그대로), {@link #ofBasisPoints(int)} 는
 * *basis point* (100bp = 1% = 0.01) 를 받는다.
 *
 * <p>{@link Money} 와 결합:
 * <pre>{@code
 * Percentage discount = Percentage.of(10);              // 10%
 * Money discounted = price.discount(discount);          // = price * 0.9
 * Money vat = price.multiply(Percentage.of(10));        // = price * 0.1
 * }</pre>
 */
public record Percentage(BigDecimal value) {

  private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
  private static final BigDecimal TEN_THOUSAND = BigDecimal.valueOf(10_000);

  public Percentage {
    Objects.requireNonNull(value, "value");
  }

  /** {@code Percentage.of(10)} = 10% = 0.10 ratio. */
  public static Percentage of(int percent) {
    return new Percentage(BigDecimal.valueOf(percent).divide(HUNDRED, MathContext.DECIMAL64));
  }

  /** {@code Percentage.of(10.5)} = 10.5% = 0.105 ratio. */
  public static Percentage of(double percent) {
    return new Percentage(BigDecimal.valueOf(percent).divide(HUNDRED, MathContext.DECIMAL64));
  }

  /** {@code Percentage.of(BigDecimal.valueOf(10.5))} = 10.5% = 0.105 ratio. */
  public static Percentage of(BigDecimal percent) {
    Objects.requireNonNull(percent, "percent");
    return new Percentage(percent.divide(HUNDRED, MathContext.DECIMAL64));
  }

  /** {@code Percentage.ofRatio(BigDecimal.valueOf(0.5))} = 0.5 ratio = 50%. */
  public static Percentage ofRatio(BigDecimal ratio) {
    return new Percentage(ratio);
  }

  /** {@code Percentage.ofBasisPoints(150)} = 1.50% = 0.015 ratio. 100bp = 1%. */
  public static Percentage ofBasisPoints(int basisPoints) {
    return new Percentage(
        BigDecimal.valueOf(basisPoints).divide(TEN_THOUSAND, MathContext.DECIMAL64));
  }

  public static Percentage zero() {
    return new Percentage(BigDecimal.ZERO);
  }

  /** ratio 단위 (50% → 0.5). 산술용 default. */
  public BigDecimal asRatio() {
    return value;
  }

  /** percent 단위 (0.5 → 50). 표시용. */
  public BigDecimal asPercent() {
    return value.multiply(HUNDRED);
  }

  /** basis point 단위 (0.015 → 150bp). 금융 시나리오. */
  public BigDecimal asBasisPoints() {
    return value.multiply(TEN_THOUSAND);
  }

  public Percentage plus(Percentage other) {
    Objects.requireNonNull(other, "other");
    return new Percentage(value.add(other.value));
  }

  public Percentage minus(Percentage other) {
    Objects.requireNonNull(other, "other");
    return new Percentage(value.subtract(other.value));
  }

  /** {@code Percentage.of(10).applyTo(Money.of(1000))} → {@code Money(100)}. */
  public Money applyTo(Money money) {
    return money.multiply(this);
  }

  /** {@code Percentage.of(10).discount(Money.of(1000))} → {@code Money(900)}. */
  public Money discount(Money money) {
    return money.discount(this);
  }

  /** {@code Percentage.of(10).markup(Money.of(1000))} → {@code Money(1100)}. */
  public Money markup(Money money) {
    return money.markup(this);
  }

  public boolean isZero() {
    return value.signum() == 0;
  }

  public boolean isPositive() {
    return value.signum() > 0;
  }

  public boolean isNegative() {
    return value.signum() < 0;
  }

  @Override
  public String toString() {
    return asPercent().stripTrailingZeros().toPlainString() + "%";
  }
}
