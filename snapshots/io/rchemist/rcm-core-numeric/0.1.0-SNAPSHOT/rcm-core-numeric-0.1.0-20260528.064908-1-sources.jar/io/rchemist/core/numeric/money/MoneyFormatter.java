/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.money;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * locale 기반 통화 표시 — {@link NumberFormat#getCurrencyInstance(Locale)} wrapper.
 *
 * <p>예시:
 * <pre>{@code
 * Money price = Money.of(1_000_000, "KRW");
 * MoneyFormatter.format(price, Locale.KOREA);   // "₩1,000,000"
 * MoneyFormatter.format(price, Locale.US);      // "KRW 1,000,000.00"
 * MoneyFormatter.format(Money.of("12.34", "USD"), Locale.US);  // "$12.34"
 * }</pre>
 */
public final class MoneyFormatter {

  private MoneyFormatter() {}

  /** 시스템 default locale 로 포맷. */
  public static String format(Money money) {
    return format(money, Locale.getDefault());
  }

  public static String format(Money money, Locale locale) {
    Objects.requireNonNull(money, "money");
    Objects.requireNonNull(locale, "locale");
    NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);
    formatter.setCurrency(money.currency());
    formatter.setMinimumFractionDigits(CurrencyScale.scaleOf(money.currency()));
    formatter.setMaximumFractionDigits(CurrencyScale.scaleOf(money.currency()));
    return formatter.format(money.amount());
  }
}
