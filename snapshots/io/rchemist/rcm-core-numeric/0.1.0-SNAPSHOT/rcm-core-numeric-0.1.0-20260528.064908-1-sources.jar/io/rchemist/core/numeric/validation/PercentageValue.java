/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 비율 검증 어노테이션 — Percentage / BigDecimal / Number / String 모두 지원.
 *
 * <p>속성:
 * <ul>
 *   <li>{@code unit} — {@link PercentageUnit#PERCENT}=0~100 단위 / {@link PercentageUnit#RATIO}=0~1 단위 / {@link PercentageUnit#BASIS_POINTS}=0~10000 bp 단위. default PERCENT.</li>
 *   <li>{@code min} / {@code max} — 단위 정합 범위 (default 0 ~ unit 최대값).</li>
 *   <li>{@code allowNegative} — false 면 음수 reject (default false).</li>
 * </ul>
 *
 * <p>예시:
 * <pre>{@code
 * public record DiscountForm(
 *     @PercentageValue(unit = PercentageUnit.PERCENT, max = "100") BigDecimal rate,
 *     @PercentageValue Percentage discount   // 0~100% default
 * ) {}
 * }</pre>
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PercentageValueValidator.class)
public @interface PercentageValue {

  String message() default "{rcm.numeric.percentage.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  PercentageUnit unit() default PercentageUnit.PERCENT;

  String min() default "";

  String max() default "";

  boolean allowNegative() default false;
}
