/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.validation;

import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link PercentageValue} 단위 — 입력 값의 의미 단위를 명시 (검증 범위 / Percentage 변환 기준).
 */
public enum PercentageUnit {
  /** 0~100 (10 = 10%). UI form 입력 default. */
  PERCENT(BigDecimal.valueOf(100)),

  /** 0~1 (0.1 = 10%). 산술 / DB 저장 default. */
  RATIO(BigDecimal.ONE),

  /** 0~10000 bp (1000 = 10%). 금융 / 이자율 default. */
  BASIS_POINTS(BigDecimal.valueOf(10_000));

  private final BigDecimal defaultMax;

  PercentageUnit(BigDecimal defaultMax) {
    this.defaultMax = defaultMax;
  }

  public BigDecimal defaultMax() {
    return defaultMax;
  }
}
