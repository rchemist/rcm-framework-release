/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.validation;

import io.rchemist.core.numeric.percentage.Percentage;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link PercentageValue} validator — null pass-through, 단위별 정량 검증.
 *
 * <p>{@link Percentage} 입력은 *ratio* 단위 정합 (asRatio 가 0~1) → unit 별 환산해서 비교한다.
 */
public class PercentageValueValidator implements ConstraintValidator<PercentageValue, Object> {

  private PercentageUnit unit;
  private BigDecimal min;
  private BigDecimal max;
  private boolean allowNegative;

  @Override
  public void initialize(PercentageValue constraintAnnotation) {
    this.unit = constraintAnnotation.unit();
    this.min = parseOrNull(constraintAnnotation.min());
    this.max = parseOrNull(constraintAnnotation.max());
    if (this.max == null) {
      this.max = unit.defaultMax();
    }
    this.allowNegative = constraintAnnotation.allowNegative();
  }

  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    }
    BigDecimal amount;
    if (value instanceof Percentage pct) {
      amount = scaleFromRatio(pct.asRatio());
    } else if (value instanceof BigDecimal bd) {
      amount = bd;
    } else if (value instanceof Number num) {
      amount = new BigDecimal(num.toString());
    } else if (value instanceof CharSequence cs) {
      try {
        amount = new BigDecimal(cs.toString());
      } catch (NumberFormatException e) {
        return false;
      }
    } else {
      return false;
    }
    if (!allowNegative && amount.signum() < 0) {
      return false;
    }
    if (min != null && amount.compareTo(min) < 0) {
      return false;
    }
    if (max != null && amount.compareTo(max) > 0) {
      return false;
    }
    return true;
  }

  private BigDecimal scaleFromRatio(BigDecimal ratio) {
    return switch (unit) {
      case PERCENT -> ratio.multiply(BigDecimal.valueOf(100));
      case RATIO -> ratio;
      case BASIS_POINTS -> ratio.multiply(BigDecimal.valueOf(10_000));
    };
  }

  private static BigDecimal parseOrNull(String text) {
    if (text == null || text.isEmpty()) {
      return null;
    }
    return new BigDecimal(text);
  }
}
