/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.money;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 통화별 표준 scale + 반올림 정규화 helper.
 *
 * <p>{@link Currency#getDefaultFractionDigits()} 가 KRW=0 / JPY=0 / USD=2 / EUR=2 등을 제공한다.
 * 일부 통화 (예: XAU/금 = -1) 는 음수를 반환하므로 fallback 으로 2 를 적용한다.
 * 모든 입력 amount 는 통화 scale 로 {@link RoundingMode#HALF_UP} 정규화하여 반올림 사고를 자동 차단.
 */
public final class CurrencyScale {

  private CurrencyScale() {}

  public static int scaleOf(Currency currency) {
    Objects.requireNonNull(currency, "currency");
    int defaultScale = currency.getDefaultFractionDigits();
    return defaultScale < 0 ? 2 : defaultScale;
  }

  public static BigDecimal normalize(BigDecimal amount, Currency currency) {
    Objects.requireNonNull(amount, "amount");
    return amount.setScale(scaleOf(currency), RoundingMode.HALF_UP);
  }
}
