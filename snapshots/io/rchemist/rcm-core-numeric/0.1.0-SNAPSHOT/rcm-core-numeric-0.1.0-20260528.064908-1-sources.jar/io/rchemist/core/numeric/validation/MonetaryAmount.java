/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 통화 금액 검증 어노테이션 — Money / BigDecimal / Long / String 모두 지원.
 *
 * <p>예시:
 * <pre>{@code
 * public record OrderForm(
 *     @MonetaryAmount(min = "0", currency = "KRW") BigDecimal price,
 *     @MonetaryAmount(min = "0", allowNegative = false) Money total
 * ) {}
 * }</pre>
 *
 * <p>속성:
 * <ul>
 *   <li>{@code min} / {@code max} — 양수 표현 (BigDecimal 호환). 비어 있으면 검증 X.</li>
 *   <li>{@code currency} — ISO 4217 코드. 비어 있으면 검증 X (Money 타입은 자동, 원시는 free pass).</li>
 *   <li>{@code allowNegative} — false 면 음수 reject (default false).</li>
 * </ul>
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = MonetaryAmountValidator.class)
public @interface MonetaryAmount {

  String message() default "{rcm.numeric.money.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  String min() default "";

  String max() default "";

  String currency() default "";

  boolean allowNegative() default false;
}
