/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.numeric.money;

import io.rchemist.core.numeric.percentage.Percentage;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 통화 + 금액 immutable Records — BigDecimal 정밀도 + 통화별 자동 scale + fluent 산술.
 *
 * <p>BigDecimal 직접 사용 시 산술마다 반올림 인자 명시해야 하는 장황함을 흡수.
 * 모든 amount 는 통화의 표준 scale 로 {@link RoundingMode#HALF_UP} 자동 정규화 → 반올림 사고 차단.
 * 산술 결과도 동일 scale 자동 유지.
 *
 * <p>예시:
 * <pre>{@code
 * Money price = Money.of(10000, "KRW");
 * Money discounted = price.discount(Percentage.of(10));   // 9000 KRW (10% 할인)
 * Money total = price.plus(Money.of(500, "KRW"));         // 10500 KRW
 * Money vat = price.multiply(Percentage.of(10));          // 1000 KRW (부가세 10%)
 * Money perPerson = price.dividedBy(BigDecimal.valueOf(3)); // 3333 KRW (KRW scale=0)
 * }</pre>
 *
 * <p>다른 통화 산술은 {@link IllegalArgumentException} fail-loud (자동 환전 X — 명시 변환만 허용).
 */
public record Money(BigDecimal amount, Currency currency) {

  public Money {
    Objects.requireNonNull(amount, "amount");
    Objects.requireNonNull(currency, "currency");
    amount = CurrencyScale.normalize(amount, currency);
  }

  public static Money of(long amount, Currency currency) {
    return new Money(BigDecimal.valueOf(amount), currency);
  }

  public static Money of(long amount, String currencyCode) {
    return of(amount, Currency.getInstance(currencyCode));
  }

  public static Money of(BigDecimal amount, Currency currency) {
    return new Money(amount, currency);
  }

  public static Money of(BigDecimal amount, String currencyCode) {
    return of(amount, Currency.getInstance(currencyCode));
  }

  public static Money of(String amount, String currencyCode) {
    return of(new BigDecimal(amount), Currency.getInstance(currencyCode));
  }

  public static Money zero(Currency currency) {
    return new Money(BigDecimal.ZERO, currency);
  }

  public static Money zero(String currencyCode) {
    return zero(Currency.getInstance(currencyCode));
  }

  public Money plus(Money other) {
    requireSameCurrency(other);
    return new Money(amount.add(other.amount), currency);
  }

  public Money minus(Money other) {
    requireSameCurrency(other);
    return new Money(amount.subtract(other.amount), currency);
  }

  public Money multiply(BigDecimal factor) {
    Objects.requireNonNull(factor, "factor");
    return new Money(amount.multiply(factor), currency);
  }

  public Money multiply(long factor) {
    return multiply(BigDecimal.valueOf(factor));
  }

  public Money multiply(Percentage percentage) {
    Objects.requireNonNull(percentage, "percentage");
    return new Money(amount.multiply(percentage.value()), currency);
  }

  public Money dividedBy(BigDecimal divisor) {
    Objects.requireNonNull(divisor, "divisor");
    return new Money(
        amount.divide(divisor, CurrencyScale.scaleOf(currency), RoundingMode.HALF_UP), currency);
  }

  public Money dividedBy(long divisor) {
    return dividedBy(BigDecimal.valueOf(divisor));
  }

  /** 할인 — {@code price.discount(Percentage.of(10))} = 10% 깎음. */
  public Money discount(Percentage percentage) {
    Objects.requireNonNull(percentage, "percentage");
    return new Money(amount.multiply(BigDecimal.ONE.subtract(percentage.value())), currency);
  }

  /** 할증 — {@code price.markup(Percentage.of(10))} = 10% 가산. 부가세 가산 등. */
  public Money markup(Percentage percentage) {
    Objects.requireNonNull(percentage, "percentage");
    return new Money(amount.multiply(BigDecimal.ONE.add(percentage.value())), currency);
  }

  public Money negate() {
    return new Money(amount.negate(), currency);
  }

  public Money abs() {
    return new Money(amount.abs(), currency);
  }

  public boolean isZero() {
    return amount.signum() == 0;
  }

  public boolean isPositive() {
    return amount.signum() > 0;
  }

  public boolean isNegative() {
    return amount.signum() < 0;
  }

  public boolean greaterThan(Money other) {
    requireSameCurrency(other);
    return amount.compareTo(other.amount) > 0;
  }

  public boolean lessThan(Money other) {
    requireSameCurrency(other);
    return amount.compareTo(other.amount) < 0;
  }

  private void requireSameCurrency(Money other) {
    Objects.requireNonNull(other, "other");
    if (!currency.equals(other.currency)) {
      throw new IllegalArgumentException(
          "Currency mismatch: " + currency.getCurrencyCode() + " vs " + other.currency.getCurrencyCode());
    }
  }

  @Override
  public String toString() {
    return amount.toPlainString() + " " + currency.getCurrencyCode();
  }
}
