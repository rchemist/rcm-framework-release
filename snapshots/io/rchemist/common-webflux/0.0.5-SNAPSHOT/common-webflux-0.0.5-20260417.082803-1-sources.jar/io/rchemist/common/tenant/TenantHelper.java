/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.tenant;

import io.rchemist.common.tenant.exception.TenantServiceErrorType;
import io.rchemist.common.tenant.exception.TenantServiceException;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.TenantUtil;
import io.rchemist.common.web.request.WebRequestContext;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TenantHelper {

  public static final String DEFAULT_TENANT_ALIAS = TenantUtil.DEFAULT_TENANT_ALIAS;
  public static final String DEFAULT_SITE_ALIAS = "defaultSite";

  public static String getTenantAliasFromWebRequestContext(){
    WebRequestContext requestContext = WebRequestContext.getWebRequestContext();
    return (requestContext == null || !requestContext.isTenantContext()) ? DEFAULT_TENANT_ALIAS
        : requestContext.getTenantAlias();
  }

  public static String getTenantAliasFromWebRequestContextNotNull()
      throws TenantServiceException {
    WebRequestContext requestContext = WebRequestContext.getWebRequestContext();
    if(requestContext == null || !requestContext.isTenantContext())
      throw new TenantServiceException(TenantServiceErrorType.TENANT_NOT_FOUND);
    return requestContext.getTenantAlias();
  }

  public static void validateTenantAlias(String tenantAlias) throws TenantServiceException {
    boolean validate = StringUtils.equals(tenantAlias, getTenantAliasFromWebRequestContext());

    if(!validate){
      throw new TenantServiceException(TenantServiceErrorType.TENANT_NOT_MATCH);
    }

  }

  public static String getSiteAliasFromWebRequestContext(){
    WebRequestContext requestContext = WebRequestContext.getWebRequestContext();
    return (requestContext == null || !requestContext.isTenantContext()) ? DEFAULT_SITE_ALIAS : StringUtil.toString(requestContext.getSiteAlias(), DEFAULT_SITE_ALIAS);
  }

  public static void validateSiteAlias(String tenantAlias, String siteAlias) throws TenantServiceException {
    validateTenantAlias(tenantAlias);

    boolean validate = StringUtils.equals(siteAlias, getSiteAliasFromWebRequestContext());

    if(!validate)
      throw new TenantServiceException(TenantServiceErrorType.SITE_NOT_MATCH);

  }

  public static boolean isTenantAliasEquals(String tenantAlias) {
    String alias = getTenantAliasFromWebRequestContext();
    return StringUtils.equals(alias, tenantAlias);
  }

  public static boolean isSiteAliasEquals(String tenantAlias, String siteAlias) {
    if (!isTenantAliasEquals(tenantAlias)) {
      return false;
    }

    String alias = getSiteAliasFromWebRequestContext();
    return StringUtils.equals(alias, siteAlias);
  }

}
