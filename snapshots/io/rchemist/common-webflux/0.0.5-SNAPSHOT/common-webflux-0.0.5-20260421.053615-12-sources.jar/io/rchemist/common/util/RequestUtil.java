/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.data.ParameterDTO;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.WebRequestContextProcessor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class RequestUtil {

  private static final String HAS_DETECT_DEVICE_TYPE = "checkedDeviceType";
  private static final String DETECT_APP_KEYWORD = "APP_";
  private static final String REDIRECT_URL = "redirect:";
  private static final String REFERER_URL = "Referer";
  private static final String MULTIPART_FORMDATA = "multipart/form-data";
  private static final String USER_AGENT = "User-Agent";
  private static final String[] MOBILE_KEYWORDS = {"Mobile", "Android", "iPhone", "iPod", "BlackBerry", "Windows Phone", "webOS"};
  private static final String[] TABLET_KEYWORDS = {"iPad", "Tablet", "Android.*Tab", "Kindle", "Silk"};
  private static final String[] PC_EXCLUDE_KEYWORDS = {"Mobile", "Android", "iPhone", "iPad"};


  public static ServerHttpRequest getRequest(){
    return getWebRequestFromContext();
  }

  public static Map<String, String[]> getRequestParamArray(String uri, String additionalSplitCode) {
    Map<String, List<String>> paramList = getRequestParamList(uri, additionalSplitCode);
    Map<String, String[]> paramArray = new HashMap<>();
    if( MapUtils.isNotEmpty(paramList)) {
      for(Entry<String, List<String>> entry : paramList.entrySet()) {
        paramArray.put(entry.getKey(), entry.getValue().toArray(new String[entry.getValue().size()]));
      }
    }
    return paramArray;
  }

  /**
   * ?a=100&b=200&c=300&c=400
   */
  public static Map<String, List<String>> getRequestParamList(String uri, String additionalSplitCode){

    if(StringUtils.contains(uri, "?")){
      /**
       * a =100&b=200&c=300&c=400
       **/
      String queryString = StringUtils.substringAfter(uri, "?");

      if(StringUtils.isNotBlank(queryString)){

        boolean additionalSplit = StringUtils.isNotBlank(additionalSplitCode);

        Map<String, List<String>> returnMap = new HashMap<>();


        /**
         * a=100
         * b=200
         * c=300
         * c=400
         */
        String[] params = StringUtils.split(queryString, "&");

        for(String param : params){
          String key;
          List<String> values = new ArrayList<>();

          String defaultSplitCode;

          if(StringUtils.contains(param, "=")){
            defaultSplitCode = "=";
          }else{
            defaultSplitCode = additionalSplitCode;
            additionalSplitCode = null;
          }

          returnMap = getParameterValues(defaultSplitCode, additionalSplitCode, additionalSplit, returnMap, param);
        }

        return returnMap;

      }
    }

    return null;


  }

  private static Map<String, List<String>> getParameterValues(String defaultSplitCode, String additionalSplitCode, boolean additionalSplit, Map<String, List<String>> returnMap, String param) {
    if(StringUtils.isEmpty(defaultSplitCode)){
      return MapUtil.mergeListHashMap(returnMap, param, param, false);
    }else{
      String[] paramValue = StringUtils.split(param, defaultSplitCode);
      // BUG-019 fix (0.0.10.F): "key=" 처럼 value 가 비어있으면 StringUtils.split 가
      // ["key"] 길이 1 을 반환해 paramValue[1] 에서 AIOOBE. 빈 문자열로 보정.
      String key = paramValue[0];
      String rawValue = paramValue.length > 1 ? paramValue[1] : "";
      if(additionalSplit && StringUtils.contains(rawValue, additionalSplitCode)){
        String[] additionalValues = StringUtils.split(rawValue, additionalSplitCode);
        for(String value : additionalValues){
          returnMap = MapUtil.mergeListHashMap(returnMap, key, value, false);
        }
      }else{
        returnMap = MapUtil.mergeListHashMap(returnMap, key, rawValue, false);
      }
      return returnMap;
    }
  }


  public static ServerWebExchange getServerWebExchange() {
    return WebRequestContextProcessor.getServerWebExchange();
  }

  public static String getRefererUrl() {
    ServerWebExchange exchange = getServerWebExchange();
    if (exchange == null)
      return null;
    return exchange.getRequest().getHeaders().getFirst(REFERER_URL);
  }

  public static String getRedirectRefererUrl() {
    return getRedirectRefererUrl("/");
  }

  public static String getRedirectRefererUrl(String defaultPath) {
    String targetUrl = getRefererUrl();
    defaultPath = StringUtil.toString(defaultPath, "/");
    return REDIRECT_URL + (StringUtils.isBlank(targetUrl) ? defaultPath : targetUrl);
  }


  public static String getURLorHeaderParameter(ServerWebExchange exchange, String varName) {
    if (exchange == null || exchange.getRequest() == null) {
      return null;
    }
    String returnValue = exchange.getRequest().getHeaders().getFirst(varName);
    if (returnValue == null) {
      returnValue = exchange.getRequest().getQueryParams().getFirst(varName);
    }
    return returnValue;
  }


  public static Object getAttribute(ServerWebExchange exchange, String attribute) {
    if(exchange == null){
      return null;
    }
    return exchange.getAttributes().get(attribute);
  }


  private static ServerHttpRequest getWebRequestFromContext() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if(context == null || context.getRequest() == null){
      return null;
    }

    return (ServerHttpRequest) context.getRequest();
  }

  public static DeviceType getCurrentDeviceType(ServerWebExchange exchange){
    if(exchange == null)
      return DeviceType.UNIDENTIFIED;

    String userAgent = exchange.getRequest().getHeaders().getFirst(USER_AGENT);
    
    // null 체크 추가
    if(StringUtils.isBlank(userAgent)){
      log.debug("User-Agent is blank, returning UNIDENTIFIED");
      return DeviceType.UNIDENTIFIED;
    }
    
    log.debug("Detecting device type for User-Agent: {}", userAgent);

    // 앱 감지 (APP_ 키워드가 있으면 앱으로 처리)
    if(StringUtils.containsIgnoreCase(userAgent, DETECT_APP_KEYWORD)){
      log.debug("Detected as MOBILE_APP due to APP_ keyword");
      return DeviceType.MOBILE_APP;
    }
    
    // 태블릿 감지 (태블릿을 먼저 체크)
    for(String keyword : TABLET_KEYWORDS){
      if(userAgent.matches(".*" + keyword + ".*")){
        log.debug("Detected as MOBILE (tablet) due to keyword: {}", keyword);
        return DeviceType.MOBILE;
      }
    }
    
    // 모바일 감지
    for(String keyword : MOBILE_KEYWORDS){
      if(StringUtils.containsIgnoreCase(userAgent, keyword)){
        log.debug("Detected as MOBILE due to keyword: {}", keyword);
        return DeviceType.MOBILE;
      }
    }
    
    // PC 제외 키워드 체크 (모바일 키워드가 있으면 PC가 아님)
    for(String keyword : PC_EXCLUDE_KEYWORDS){
      if(StringUtils.containsIgnoreCase(userAgent, keyword)){
        log.debug("Detected as MOBILE due to PC exclude keyword: {}", keyword);
        return DeviceType.MOBILE;
      }
    }
    
    // 위 조건에 해당하지 않으면 PC
    log.debug("Detected as PC (no mobile/tablet keywords found)");
    return DeviceType.PC;
  }

  public static DeviceType getCurrentDeviceTypeFromSession(){
    return getCurrentDeviceTypeFromSession(getServerWebExchange());
  }

  public static DeviceType getCurrentDeviceTypeFromSession(ServerWebExchange exchange){
    if(exchange != null){

      if(getAttribute(exchange, HAS_DETECT_DEVICE_TYPE) != null){
        String deviceType = (String) getAttribute(exchange, HAS_DETECT_DEVICE_TYPE);
        return EnumTypeUtil.getEnumType(DeviceType.class, deviceType, DeviceType.UNIDENTIFIED);
      }else{
        DeviceType deviceType = getCurrentDeviceType(exchange);
        exchange.getAttributes().put(HAS_DETECT_DEVICE_TYPE, deviceType.getType());
        return deviceType;
      }
    }
    return DeviceType.UNIDENTIFIED;
  }

  /**
   * multipart upload 인 경우에는 이 핸들러를 실행하지 않는다.
   * @param contentType
   * @return
   */
  public static boolean isMultipartFormData(String contentType){
    return StringUtils.startsWith(contentType, MULTIPART_FORMDATA);
  }

  public static String getUri(String url, Map<String, String[]> parameters) {
    if(MapUtils.isEmpty(parameters)){
      return url;
    }
    
    StringBuilder urlBuilder = new StringBuilder(url);
    
    // Query string 시작 처리
    if(!StringUtils.contains(url, "?")){
      urlBuilder.append("?useNavigate");
    }else if(url.endsWith("?")){
      urlBuilder.append("useNavigate");
    }

    // 파라미터 추가
    for(Entry<String, String[]> entry : parameters.entrySet()){
      String name = entry.getKey();
      String[] values = entry.getValue();

      urlBuilder.append("&").append(name).append("=");
      
      if(ArrayUtils.isNotEmpty(values)){
        for(int i = 0; i < values.length; i++){
          if(i > 0){
            urlBuilder.append(",");
          }
          urlBuilder.append(values[i]);
        }
      }
    }
    
    return urlBuilder.toString();
  }

  public static ParameterDTO parseParameters(String uri){
    return RequestParameterUtil.parseParameters(uri);
  }

  public static void removeAttribute(ServerWebExchange exchange, String attrName) {
    exchange.getAttributes().remove(attrName);
  }

  public static boolean isSecure() {
    ServerWebExchange exchange = getServerWebExchange();

    if (exchange != null) {
      // Spring 6.1 이후 권장 방법: URI에서 직접 scheme 확인
      return exchange.getRequest().getURI().getScheme() != null 
          && exchange.getRequest().getURI().getScheme().equalsIgnoreCase("https");
    }

    return false;
  }

  public static void addAttribute(ServerWebExchange exchange, String attrName, Object value) {
    exchange.getAttributes().put(attrName, value);
  }
}
