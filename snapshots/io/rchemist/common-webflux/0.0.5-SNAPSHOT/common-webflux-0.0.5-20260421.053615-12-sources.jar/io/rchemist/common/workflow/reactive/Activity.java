/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import org.springframework.core.Ordered;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface Activity<U extends WorkflowContext<?, ?>> extends Ordered {
  String getId();

  void setId(String activityId);

  String getName();

  void setName(String activityName);

  Mono<ActivityResult<U>> execute(U context, ActivityResult<U> prevResult);

  RollbackHandler<U> getRollbackHandler();

  void setRollbackHandler(RollbackHandler<U> rollbackHandler);

  boolean shouldRollback();

  void setRollbackState(U context, Object rollbackState);

  Object getRollbackState(U context);

  void setOrder(int order);

}
