/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.WebRequestContext;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmDeviceTypeResolver")
public class DeviceTypeResolver implements RequestAttributeResolver<DeviceType> {

  public static final String DEVICE_TYPE_ATTR_NAME = "deviceType";

  @Override
  public boolean canHandle(Class<DeviceType> clazz) {
    return clazz.equals(DeviceType.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    DeviceType deviceType = RequestUtil.getCurrentDeviceTypeFromSession(exchange);

    RequestUtil.addAttribute(exchange, DEVICE_TYPE_ATTR_NAME, deviceType);

    context.setDeviceType(deviceType);
  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, DEVICE_TYPE_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.DEVICE_TYPE_RESOLVER;
  }
}
