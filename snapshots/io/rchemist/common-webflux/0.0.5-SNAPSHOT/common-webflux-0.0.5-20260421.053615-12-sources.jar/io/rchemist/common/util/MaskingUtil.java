/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.web.request.WebRequestContext;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 **/
public class MaskingUtil {

  /** The Constant EMAIL_PATTERN. */
  public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

  // BUG-021 fix (0.0.10.F): WebRequestContext null 가능성 — 모든 mask* 메소드에 적용.
  private static boolean shouldMask() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if (context == null) return true;
    if (!context.isAdmin()) return true;
    return !isCsr();
  }

  /**
   * Mask email address.
   *
   * @param email the email
   * @return the string
   */
  public static String maskEmailAddress(String email){
    if (StringUtils.isNotBlank(email) && shouldMask()) {
      return setMaskEmailAddress(email);
    }
    return email;
  }

  public static String setMaskEmailAddress(String email){
    String result = email;

    Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    if(pattern.matcher(email).matches()){
      int i=email.indexOf("@");
      if(email.substring(0,i).length()>2){
        result=email.substring(0,i-2)+"**"+email.substring(i);
      }else{
        result=email.substring(0,i-1)+"**"+email.substring(i);
      }
    }

    return result;
  }

  /**
   * Mask phone number.
   *
   * @param phoneNumber the phone number
   * @return the string
   */
  public static String maskPhoneNumber(String phoneNumber){
    if (shouldMask()) return setMaskPhoneNumber(phoneNumber);
    return phoneNumber;
  }

  public static String setMaskPhoneNumber(String phoneNumber){
    String result = phoneNumber;
    String maskValue="****";

    if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.contains("-")){
      // BUG-020 fix (0.0.10.F): single-dash 시 sb.replace(start>end) IOOBE 회피 +
      // length>1 가드.
      int firstDash = phoneNumber.indexOf("-");
      int lastDash = phoneNumber.lastIndexOf("-");
      if (firstDash < lastDash) {
        String[] parts = phoneNumber.split("-");
        if(parts.length > 1 && parts[1].length() == 3){
          maskValue="***";
        }
        StringBuilder sb=new StringBuilder(phoneNumber);
        sb.replace(firstDash + 1, lastDash, maskValue);
        result=sb.toString();
      }
    }else if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.length()==10){
      result=phoneNumber.replaceFirst(phoneNumber.substring(3, 6),"-***-");
    }else if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.length()>=11){
      result=phoneNumber.replaceFirst(phoneNumber.substring(3, 7),"-****-");
    }

    return result;
  }

  private static Boolean isCsr(){
    // BUG-021 fix: context null 가드 + dead code 정리.
    return false;
  }

  /**
   * Mask user name.
   *
   * @param userName the user name
   * @return the string
   */
  public static String maskUserName(String userName){
    if (shouldMask()) return setMaskUserName(userName);
    return userName;
  }

  public static String setMaskUserName(String userName){
    String result = userName;

    if(StringUtils.isNotBlank(userName) && userName.length()>2){
      result=userName.substring(0,userName.length()-2)+"**";
    }

    return result;
  }

  /**
   * Mask customer name.
   *
   * @param customerName the customer name
   * @return the string
   */
  public static String maskCustomerName(String customerName){
    if (shouldMask()) return setMaskCustomerName(customerName);
    return customerName;
  }

  public static String setMaskCustomerName(String customerName){
    String result = customerName;

    if(StringUtils.isNotBlank(customerName) && customerName.length()>1){
      result=customerName.substring(0, 1) + '*' + customerName.substring(1 + 1);
    }

    return result;
  }

  /**
   * Mask address.
   *
   * @param address the address
   * @return the string
   */
  public static String maskAddress(String address){
    if (shouldMask()) return setMaskAddress(address);
    return address;
  }

  public static String setMaskAddress(String address){
    String result = address;

    if(StringUtils.isNotBlank(address)){
      StringBuilder sb=new StringBuilder();
      for(int i=0;i<address.length();i++){
        sb=sb.append("*");
      }
      result=sb.toString();
    }

    return result;
  }

  /**
   * Mask credit info.
   *
   * @param creditcard the creditcard
   * @return the string
   */
  public static String maskCreditInfo(String creditcard){
    if (shouldMask()) return setMaskCreditInfo(creditcard);
    return creditcard;
  }

  public static String setMaskCreditInfo(String creditcard){
    String result = creditcard;

    if(StringUtils.isNotBlank(creditcard) && creditcard.length()>12){
      result= creditcard.substring(0,4)+ "-****-****-"+creditcard.substring(12);
    }

    return result;
  }

  /**
   * Mask credit card info.
   *
   * @param creditcard the creditcard
   * @return the string
   */
  public static String maskCreditCardInfo(String creditcard){
    if (shouldMask()) return setMaskCreditCardInfo(creditcard);
    return creditcard;
  }

  /**
   * 16 자리 or 12 자리 일 경우 분기 로직 처리
   * <pre>
   * </pre>
   *
   * @Method setMaskCreditCardInfo
   * @param creditcard
   * @return
   */
  public static String setMaskCreditCardInfo(String creditcard){
    StringBuilder sb = new StringBuilder();

    if (StringUtils.isNotBlank(creditcard)) {
      if (creditcard.length() > 12) {
        sb.append(creditcard, 0, 4)
            .append("-")
            .append(creditcard, 4, 7).append("*")
            .append("-")
            .append("****")
            .append("-")
            .append(creditcard.substring(12));
      } else if (creditcard.length() > 10) {
        sb.append(creditcard, 0, 4)
            .append("-")
            .append(creditcard, 4, 7).append("*")
            .append("-")
            .append(creditcard.substring(8))
            .append("-")
            .append("****");
      }
    }

    return sb.toString();
  }

  public static String maskCustomerId(String loginName) {
    if (shouldMask()) return setMaskCustomerId(loginName);
    return loginName;
  }

  public static String setMaskCustomerId(String loginName){
    // BUG-022 fix (0.0.10.F): null / length<=2 IOOBE 가드.
    if (loginName == null || loginName.length() <= 2) {
      return loginName;
    }
    return loginName.substring(0, loginName.length() - 2) + "**";
  }

  public static String setMaskBankAccountNumber(String bankAccountNumber){
    if (StringUtils.isEmpty(bankAccountNumber)) {
      return bankAccountNumber;
    }

    StringBuilder sb = new StringBuilder()
        .append(bankAccountNumber, 0, 4)
        .append("***")
        .append(bankAccountNumber, 7, bankAccountNumber.length()-1)
        .append("*");

    return sb.toString();
  }
}
