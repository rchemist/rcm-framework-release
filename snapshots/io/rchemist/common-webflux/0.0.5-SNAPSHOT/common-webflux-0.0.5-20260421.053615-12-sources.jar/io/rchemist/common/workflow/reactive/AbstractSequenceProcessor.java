/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import io.rchemist.common.workflow.reactive.exception.ReactiveWorkflowException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.core.Ordered;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * <p>
 *   Activity 들을 순차적으로 실행하는 Processor
 *   <br/>
 *   앞선 액티비티가 반환한 ActivityResult 에 따라 다음 액티비티를 실행할지 결정한다.
 *   <br/>
 *   ActivityResult 에서 에러가 감지되면 이후 액티비티를 실행하지 않고 에러 처리를 한다.
 * </p>
 **/
@Slf4j
public abstract class AbstractSequenceProcessor<U extends WorkflowContext<?, ?>, T> implements
  Processor<U, T> {

  public AbstractSequenceProcessor(String processorId) {
    this.processorId = processorId;
  }

  @Getter
  @Setter
  protected String processorId;

  @Getter
  protected List<Activity<U>> activities;

  @Getter
  @Setter
  protected U context;

  @Override
  public void setActivities(List<Activity<U>> activities) {
    if (CollectionUtils.isNotEmpty(activities)) {
      // copy list
      List<Activity<U>> list = new ArrayList<>(activities);
      // sort
      list.sort(Comparator.comparingInt(Ordered::getOrder));
      // rearrange sort order
      this.activities = list.stream()
        .peek(activity -> activity.setOrder(activities.indexOf(activity)))
        .toList();
    } else {
      this.activities = new ArrayList<>();
    }
  }

  @Override
  public Mono<ActivityResult<U>> process(T data) {
    AtomicBoolean errorDetected = new AtomicBoolean(false);
    AtomicBoolean skipForwardActivity = new AtomicBoolean(false);
    AtomicInteger errorIndex = new AtomicInteger(0);
    AtomicReference<ActivityResult<U>> result = new AtomicReference<>();

    U context = createContext(data);

    if (CollectionUtils.isEmpty(getActivities())) {
      return Mono.just(new ActivityResult<>(context, true)
        .withException(
          new ReactiveWorkflowException("No activities found in processor " + getProcessorId(),
            false)));
    }

    List<Activity<U>> activities = getActivities();

    return Flux.fromIterable(activities)
      .flatMap(activity -> {

        if (errorDetected.get() || skipForwardActivity.get()) {
          // 에러가 이미 감지되었으므로 이후 액티비티를 실행하지 않음
          return Mono.empty();
        }

        return Mono.defer(() -> {

          ActivityResult<U> prevResult = result.get();

          if (prevResult != null && prevResult.shouldSkipActivity(activity.getClass())) {
            // 이전 액티비티에서 skip 되었으므로 실행하지 않음
            return Mono.just(prevResult);
          } else {

            return considerSkipActivity(activities, activity, prevResult)
              .switchIfEmpty(
                activity.execute(context, prevResult)
                  .doOnNext(
                    activityResult -> {

                      log.info("Execute activity " + activity.getId() + " in processor " + getProcessorId());

                      // ActivityResult 에서 에러를 확인하고 errorDetected 를 설정
                      if (activityResult.isError()) {
                        errorDetected.set(true);
                        errorIndex.set(activity.getOrder());
                      } else {
                        // 에러는 아니고 이후의 activity 를 skip 하게 해야 한다.
                        if (activityResult.isSkipForwardActivity()) {
                          skipForwardActivity.set(true);
                        } else {
                          result.set(activityResult);
                        }
                      }
                    })
              );


          }
        });

      })
      .collectList()
      .flatMap(results -> {
        // 워크플로우 결과를 종합하는 로직

        if (CollectionUtils.isEmpty(results)) {
          return Mono.just(new ActivityResult<>(context, true)
            .withException(
              new ReactiveWorkflowException("No activities found in processor " + getProcessorId(),
                false)));
        }

        return combineResults(errorDetected.get(), errorIndex.get(), results);
      });
  }

  private Mono<ActivityResult<U>> considerSkipActivity(List<Activity<U>> activities,
    Activity<U> activity, ActivityResult<U> prevResult) {
    if (prevResult != null && prevResult.getSkipUntilActivity() != null) {
      Class<?> skipUntilActivity = prevResult.getSkipUntilActivity();

      Activity<U> untilActivity = activities.stream()
        .filter(a -> a.getClass().equals(skipUntilActivity))
        .findFirst()
        .orElse(null);

      if (untilActivity != null && activity.getOrder() < untilActivity.getOrder()) {
        log.info("Skip activity " + activity.getId() + " because of skipUntilActivity "
          + skipUntilActivity.getName() + " in previous ActivityResult.");
        return Mono.just(prevResult);
      }
    }
    return Mono.empty();
  }

  protected Mono<ActivityResult<U>> combineResults(boolean errorDetected, int errorIndex,
    List<ActivityResult<U>> results) {
    if (errorDetected) {
      // 에러 처리

      List<Activity<U>> activities = new ArrayList<>();
      getActivities().stream()
        .filter(activity -> activity.getOrder() <= errorIndex)
        .forEach(activities::add);

      if (activities.size() > 0) {

        // get last activity context
        ActivityResult<U> finalResult = results.get(results.size() - 1);

        U context = finalResult.getContext();

        // reverse order -> 뒤에서부터 롤백을 처리한다.
        activities.sort((o1, o2) -> o2.getOrder() - o1.getOrder());

        return Flux.fromIterable(activities)
          .filter(Activity::shouldRollback)
          .flatMap(activity -> activity.getRollbackHandler().rollback(context))
          .then(Mono.just(finalResult));

      }

      return Mono.just(new ActivityResult<>(null, true));

    } else {
      return Mono.just(results.get(results.size() - 1));
    }
  }

}
