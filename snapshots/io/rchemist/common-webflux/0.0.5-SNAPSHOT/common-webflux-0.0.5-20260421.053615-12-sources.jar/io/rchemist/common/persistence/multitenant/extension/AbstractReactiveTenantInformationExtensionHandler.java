/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.multitenant.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import io.rchemist.common.web.request.WebRequestContextProcessor;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractReactiveTenantInformationExtensionHandler implements TenantInformationExtensionHandler {

  @Override
  public ExtensionResultStatusType findTenantInformation(
    ExtensionResultHolder<TenantInformation> erh) {

    if (WebRequestContextProcessor.getServerWebExchange() == null) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }

    return findTenantInformation(WebRequestContextProcessor.getServerWebExchange(), erh);
  }

  abstract ExtensionResultStatusType findTenantInformation(ServerWebExchange exchange,
    ExtensionResultHolder<TenantInformation> erh);

}
