/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.configuration.context.filter;

import java.nio.charset.StandardCharsets;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.web.server.WebFilter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
public class Utf8EncodingConfiguration {

  @Bean
  @Order(1) // 필터 순서 지정
  public WebFilter utf8EncodingWebFilter() {
    return (exchange, chain) -> {
      // HTTP 요청의 인코딩을 UTF-8로 설정
      exchange.getRequest().mutate().headers(httpHeaders -> {
        httpHeaders.setAcceptCharset(List.of(StandardCharsets.UTF_8));
      }).build();

      // HTTP 응답의 인코딩을 UTF-8로 설정
      exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
      exchange.getResponse().getHeaders().set("charset", "UTF-8");

      return chain.filter(exchange);
    };
  }

}
