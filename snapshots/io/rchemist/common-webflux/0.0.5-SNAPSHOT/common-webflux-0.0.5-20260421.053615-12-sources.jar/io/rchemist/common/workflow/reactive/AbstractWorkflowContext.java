/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * <p>
 *   워크플로우 액티비티에서 공유하는 컨텍스트
 *   seed 의 값을 변경하면 다음 액티비티에서 변경된 값을 사용할 수 있다.
 * </p>
 **/
public abstract class AbstractWorkflowContext<CONTEXT, U> implements WorkflowContext<CONTEXT, U>{

  @Getter
  @Setter
  protected U seed;

  @Getter
  @Setter
  protected Map<String, Object> rollbackState;

}
