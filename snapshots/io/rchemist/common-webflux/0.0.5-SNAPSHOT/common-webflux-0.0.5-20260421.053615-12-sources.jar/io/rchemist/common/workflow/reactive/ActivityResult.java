/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import io.rchemist.common.workflow.reactive.exception.ReactiveWorkflowException;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class ActivityResult<U extends WorkflowContext<?, ?>> implements Serializable {

  // 에러가 발생했다. 앞으로 남은 모든 액티비티를 skip 한다.
  protected boolean error;

  // 에러는 아니지만 앞으로 남은 모든 액티비티를 skip 한다.
  protected boolean skipForwardActivity;

  // 에러는 아니지만 앞으로 특정 클래스의 액티비티까지 skip 한다.
  protected Class<?> skipUntilActivity;

  // 에러는 아니지만 앞으로 특정 클래스의 액티비티들을 skip 한다.
  protected List<Class<?>> skipActivities;

  protected final U context;

  protected String errorMessage;

  protected ReactiveWorkflowException exception;

  public ActivityResult(U context, boolean error) {
    this.context = context;
    this.error = error;
  }

  public ActivityResult(U context) {
    this(context, false);
  }

  public ActivityResult<U> withErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public ActivityResult<U> withException(ReactiveWorkflowException exception) {
    this.exception = exception;
    this.error = true;
    return this;
  }

  public ActivityResult<U> withError(boolean error) {
    this.error = error;
    return this;
  }

  public ActivityResult<U> withSkipForwardActivity(boolean skipForwardActivity) {
    this.skipForwardActivity = skipForwardActivity;
    return this;
  }

  public ActivityResult<U> withSkipUntilActivity(Class<?> skipUntilActivity) {
    this.skipUntilActivity = skipUntilActivity;
    return this;
  }

  public ActivityResult<U> withSkipActivities(List<Class<?>> skipActivities) {
    this.skipActivities = skipActivities;
    return this;
  }

  public ActivityResult<U> addSkipActivities(Class<?>... skipActivities) {
    this.skipActivities.addAll(List.of(skipActivities));
    return this;
  }

  public boolean shouldSkipActivity(Class<?> activityClass) {
    return isError() || isSkipForwardActivity() || (skipActivities != null && skipActivities.contains(activityClass));
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
      .append("error", error)
      .append("context", context)
      .append("errorMessage", errorMessage)
      .append("exception", exception != null ? exception.getMessage() : null)
      .toString();
  }
}
