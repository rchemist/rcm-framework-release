/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Document.OutputSettings.Syntax;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PdfConverter {

  // 네이버 나눔고딕 URL, font 가 jar 로 묶여 배포될 때 오류가 발생하기 때문에 직접 다운 받게 한다.
  private static final String FONT_PATH = "https://hangeul.pstatic.net/hangeul_static/webfont/NanumGothic/NanumGothic.ttf";

  public static File generate(String filename, String html, List<String> resourcePaths) throws Exception {

    Document document = Jsoup.parse(html);
    document.outputSettings().syntax(Syntax.xml);

    File file = FileService.getFileService().createFile(filename);
    String fontPath = "fonts/NanumGothic-Regular.ttf";

    File font = FileService.getFileService().createFile(fontPath);

    FileUtils.copyURLToFile(
        new URL(FONT_PATH),
        font,
        30000,
        30000);

    try(OutputStream os = new FileOutputStream(file)){

      PdfRendererBuilder builder = new PdfRendererBuilder();
      builder.withUri(filename);
      builder.toStream(os);
      builder.withW3cDocument(new W3CDom().fromJsoup(document), "/src/main/resources");
      builder.useFont(font, "nanum");
      builder.run();

    }

    return file;

  }


}
