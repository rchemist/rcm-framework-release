/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.file.data.FileResource;
import io.rchemist.common.file.data.FileResourcePath;
import io.rchemist.common.file.data.FileUploadResult;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.file.service.extension.FileServiceExtensionManager;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.TSIDUtil;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import java.util.Random;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmFileService")
public class FileService {

  protected final FileServiceExtensionManager extensionManager;

  private static String SEPARATOR = "/";
  private static String STATIC_RESOURCE_PREFIX = "static-resource";
  public static final String RESIZE_PREFIX = "-(resize)-";

  private static final int FILE_BUFFER_SIZE = 8192;

  private static final String DEFAULT_FILE_PATH = System.getProperty("java.io.tmpdir");

  @Value("${platform.config.common.file.temp_path:}")
  protected String tempFilePath;

  @Value("${platform.config.common.file.max_upload_size:1000000000}")
  protected long maxUploadSize;

  public FileService(@Qualifier("rcmFileServiceExtensionManager") FileServiceExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Value("${platform.config.common.file.static_resource_prefix:static-resource}")
  public void setFilePrefix(String staticResourcePrefix){
    FileService.STATIC_RESOURCE_PREFIX = staticResourcePrefix;
  }

  public static String getStaticResourcePrefix(){
    return STATIC_RESOURCE_PREFIX;
  }

  public static String getStaticResourcePrefixWithSeparator(){
    return SEPARATOR + STATIC_RESOURCE_PREFIX;
  }

  public static FileService getFileService(){
    return ApplicationContextHolder.getBean(FileService.class);
  }

  public File createFileFromInputStream(InputStream inputStream, String fileName) throws Exception{
    File uploadFile = createFile(fileName);

    byte[] buffer = new byte[FILE_BUFFER_SIZE];

    try(OutputStream outputStream = new FileOutputStream(uploadFile)){

      int bytes;
      int totalBytes = 0;
      while((bytes = inputStream.read(buffer)) != -1){
        totalBytes += bytes;
        if(totalBytes > maxUploadSize){
          throw new FileServiceException(FileServiceErrorType.EXCEED_MAX_UPLOAD_SIZE);
        }
        outputStream.write(buffer, 0, bytes);
      }
    }

    return uploadFile;

  }

  public File createFile(String fileName) throws Exception{
    FileResourcePath fileResourcePath = createTempFileResourcePath(TenantHelper.getTenantAliasFromWebRequestContext());

    fileName = FilenameUtils.normalize(fileResourcePath.getPath() + File.separator + fileName);

    File uploadFile = new File(fileName);

    if (!uploadFile.getParentFile().exists()) {
      if (!uploadFile.getParentFile().mkdirs()) {
        if (!uploadFile.getParentFile().exists()) {
          throw new FileServiceException(FileServiceErrorType.FAILED_TO_CREATE_TEMP_DIRECTORY);
        }
      }
    }

    return uploadFile;

  }

  public FileUploadResult saveInputStreamToFile(InputStream inputStream, String fileName, String tenantAlias)
      throws FileServiceException, IOException {

    FileResourcePath fileResourcePath = createTempFileResourcePath(tenantAlias);

    fileName = FilenameUtils.normalize(fileResourcePath.getPath() + File.separator + fileName);

    byte[] buffer = new byte[FILE_BUFFER_SIZE];

    File uploadFile = new File(fileName);
    if (!uploadFile.getParentFile().exists()) {
      if (!uploadFile.getParentFile().mkdirs()) {
        if (!uploadFile.getParentFile().exists()) {
          throw new FileServiceException(FileServiceErrorType.FAILED_TO_CREATE_TEMP_DIRECTORY);
        }
      }
    }

    FileUploadResult fileUploadResult = null;

    // make file from inputStream
    try(OutputStream outputStream = new FileOutputStream(uploadFile)){

      int bytes;
      int totalBytes = 0;
      while((bytes = inputStream.read(buffer)) != -1){
        totalBytes += bytes;
        if(totalBytes > maxUploadSize){
          throw new FileServiceException(FileServiceErrorType.EXCEED_MAX_UPLOAD_SIZE);
        }
        outputStream.write(buffer, 0, bytes);
      }

      ExtensionResultHolder<List<FileUploadResult>> result = new ExtensionResultHolder<>();

      ExtensionResultStatusType statusType = extensionManager.getProxy().uploadResources(
          fileResourcePath, List.of(uploadFile), result);

      if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
        List<FileUploadResult> results = result.getResult();
        if(CollectionUtils.isEmpty(results))
          throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);

        fileUploadResult = results.get(0);

      }


    }finally {
      //deleteFileResource(fileResourcePath);
    }

    return fileUploadResult;

  }

  public FileResourcePath createTempFileResourcePath(String tenantAlias) throws FileServiceException {
    String filePath = getFilePath(tenantAlias);
    assert filePath != null;

    FileResourcePath resource = new FileResourcePath(filePath);

    File tempDirectory = new File(resource.getPath());

    if(!tempDirectory.exists()){
      if(!tempDirectory.mkdirs()){
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_CREATE_TEMP_DIRECTORY);
      }
    }

    return resource;
  }

  protected void deleteFileResource(FileResourcePath fileResourcePath) {
    if(fileResourcePath != null){
      File tempDirectory = new File(fileResourcePath.getPath());
      if (tempDirectory.exists()) {
        FileUtils.deleteQuietly(tempDirectory);
      }

      for (int i = 0; i < 2; i++) {
        tempDirectory = tempDirectory.getParentFile();
        if (!tempDirectory.delete()) {
          break;
        }
      }
    }
  }

  protected String getFilePath(String tenantAlias) {
    String path = (StringUtils.isEmpty(tempFilePath)) ? DEFAULT_FILE_PATH
        : tempFilePath;

    tenantAlias = StringUtil.toString(tenantAlias, TenantHelper.DEFAULT_TENANT_ALIAS);
    String siteHash = DigestUtils.md5Hex(tenantAlias);
    path = FilenameUtils.concat(path, siteHash.substring(0, 2));
    path = FilenameUtils.concat(path, tenantAlias);

    Random random = new Random();

    for(int i = 0; i < 2; i++){
      int number = random.nextInt(256);
      path = FilenameUtils.concat(path, Integer.toHexString(number));
    }

    path = FilenameUtils.concat(path, Long.toHexString(Thread.currentThread().getId()));

    return path;
  }

  public FileResource getResourceResource(String fullUrl, String fileName, boolean localResource)
      throws FileServiceException {

    ExtensionResultHolder<FileResource> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType statusType = extensionManager.getProxy().getResource(fullUrl, fileName, localResource, resultHolder);

    if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
      return resultHolder.getResult();
    }

    return null;

  }

  public boolean removeResource(String tenantAlias, String fileName, boolean localResource)
      throws FileServiceException {
    FileResourcePath path = createTempFileResourcePath(tenantAlias);

    ExtensionResultHolder<Boolean> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType statusType = extensionManager.getProxy().removeResource(path, fileName, localResource, resultHolder);

    if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
      return resultHolder.getResult();
    }

    // failed
    // 실패
    return false;

  }

  public static File createFileByUrl(String fileUrl) throws Exception{

    String ext = FileUtil.getFileExtension(fileUrl);
    String fileName = "bulk_"+ TSIDUtil.tsId() + "." + ext;

    File f = new File(fileName);
    FileUtils.copyURLToFile(new URL(UriUtils.encodePath(fileUrl, "UTF-8")), f);

    return f;
  }

}
