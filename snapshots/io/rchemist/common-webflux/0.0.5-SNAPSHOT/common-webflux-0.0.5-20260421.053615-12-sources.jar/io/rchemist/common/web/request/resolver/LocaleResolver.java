/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.util.Locale;
import org.apache.commons.lang3.LocaleUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmLocaleResolver")
public class LocaleResolver implements RequestAttributeResolver<Locale> {

  public static final String LOCALE_ATTR_NAME = "locale";
  public static final String REQUESTED_LOCALE_NAME = "locale";

  @Override
  public boolean canHandle(Class<Locale> clazz) {
    return clazz.equals(Locale.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    Locale locale = exchange.getAttribute(LOCALE_ATTR_NAME);

    if(locale == null){
      locale = getLocaleFromUrl(exchange);
    }

    if(locale == null){
      locale = getLocaleFromSession(exchange);
    }

    if(locale == null){
      locale = Locale.getDefault();
    }

    RequestUtil.addAttribute(exchange, LOCALE_ATTR_NAME, locale);
    context.setLocale(locale);
  }

  protected Locale getLocaleFromSession(ServerWebExchange exchange) {
    return (Locale) RequestUtil.getAttribute(exchange, LOCALE_ATTR_NAME);
  }

  protected Locale getLocaleFromUrl(ServerWebExchange exchange) {
    String localeCode = RequestUtil.getURLorHeaderParameter(exchange, REQUESTED_LOCALE_NAME);
    if(StringUtils.isNotEmpty(localeCode)){
      return LocaleUtils.toLocale(localeCode);
    }
    return null;
  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, LOCALE_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.LOCALE_RESOLVER;
  }
}
