/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.util.BooleanUtil;
import org.springframework.core.Ordered;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

/**
 *
 * 반드시 웹페이지의 request 에서만 실행되어야 하는 필터에 이 인터페이스를 적용한다.
 *
 * 만약 CustomerStateFilter 와 같은 필터가 모든 request 에 반응한다면,
 * js 나 css 를 호출하는 request 에서도 불필요하게 무거운 프로세스가 동작할 수 있다.
 * 이런 문제를 방지하기 위해
 * InspectSpringSecurityChainFilter 에서 springSecurityFilterChain 에 의해 exclusion 으로 설정된 URI 에서는 필터를 실행하지 않는다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface WebPageFilter extends Ordered, WebFilter {

  int PRE_SECURITY_HIGH = -1000000;
  int PRE_SECURITY_MEDIUM = -500000;
  int PRE_SECURITY_LOW = -10000;
  int POST_SECURITY_HIGH = 10000;
  int POST_SECURITY_MEDIUM = 500000;
  int POST_SECURITY_LOW = 1000000;

  String SKIP_WEB_PAGE_FILTER = "SKIP_FILTER";

  default boolean shouldSkipFilter(ServerWebExchange exchange, WebFilterChain filterChain){
    String skipWebPageFilter = exchange.getAttribute(SKIP_WEB_PAGE_FILTER);
    return BooleanUtil.getBooleanValue(skipWebPageFilter, false);
  }


}
