/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ClientIpUtil {

  /**
   * L4 혹은 Proxy 환경에서 Client IP 조회
   * @param request
   * @return
   */
  public static String getClientIp(ServletServerHttpRequest request) {

    final String[] headers = {
      "X-Forwarded-For",
      "X-FORWARDED-FOR",
      "Proxy-Client-IP",
      "WL-Proxy-Client-IP",
      "HTTP_X_FORWARDED_FOR",
      "HTTP_X_FORWARDED",
      "HTTP_X_CLUSTER_CLIENT_IP",
      "HTTP_CLIENT_IP",
      "HTTP_FORWARDED_FOR",
      "HTTP_FORWARDED",
      "HTTP_VIA",
      "REMOTE_ADDR"
    };

    try {
      for (String headerName : headers) {
        String ip = request.getHeaders().getFirst(headerName);
        if (!StringUtils.isBlank(ip) && !"unknown".equalsIgnoreCase(ip)) {
          return ip;
        }
      }

      return request.getRemoteAddress().getAddress().getHostAddress();

    } catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
    }

    return null;
  }

}
