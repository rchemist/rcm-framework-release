/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import io.rchemist.common.util.StringUtil;
import io.rchemist.common.workflow.reactive.exception.ReactiveWorkflowException;
import lombok.Getter;
import lombok.Setter;
import org.springframework.lang.NonNull;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractSequenceActivity<U extends WorkflowContext<?, ?>> implements Activity<U> {

  public AbstractSequenceActivity(int order, String id, String name) {
    this.id = id;
    this.name = name;
    this.order = order;
  }

  @Getter
  @Setter
  protected String id;

  @Getter
  @Setter
  protected String name;

  @Getter
  @Setter
  protected RollbackHandler<U> rollbackHandler;

  @Getter
  @Setter
  protected int order;

  public Mono<ActivityResult<U>> execute(U context, ActivityResult<U> prevResult) {

    if (prevResult != null) {
      if (prevResult.shouldSkipActivity(getClass())) {
        return Mono.just(prevResult);
      }
    }

    return Mono.fromCallable(() -> executeInternal(context))
      .onErrorResume(ReactiveWorkflowException.class, e ->
        Mono.just(new ActivityResult<>(context, true)
          .withErrorMessage(e.getMessage())
          .withException(e)))
      .onErrorResume(e ->
        Mono.just(new ActivityResult<>(context, true)
          .withErrorMessage(e.getMessage())
          .withException(new ReactiveWorkflowException(e.getMessage()))));
  }

  @NonNull
  protected abstract ActivityResult<U> executeInternal(U context);

  @Override
  public boolean shouldRollback() {
    return getRollbackHandler() != null;
  }

  @Override
  public void setRollbackState(U context, Object rollbackState) {
    String activityId = getDefaultRollbackStateId();
    context.addRollbackState(activityId, rollbackState);
  }

  @Override
  public Object getRollbackState(U context) {
    String activityId = getDefaultRollbackStateId();
    return context.getRollbackState().get(activityId);
  }

  private String getDefaultRollbackStateId() {
    return StringUtil.toString(getId(), getClass().getSimpleName() + "_" + getOrder());
  }


}
