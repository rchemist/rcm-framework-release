/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.file.data.FileResource;
import io.rchemist.common.file.data.FileResourcePath;
import io.rchemist.common.file.data.FileUploadResult;
import io.rchemist.common.file.service.exception.FileServiceException;
import java.io.File;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface FileServiceExtensionHandler extends ExtensionHandler {

  ExtensionResultStatusType getResource(String fullUrl,
      String fileName, boolean localResource,
      ExtensionResultHolder<FileResource> result) throws FileServiceException;

  ExtensionResultStatusType uploadResources(FileResourcePath fileResourcePath, List<File> files, ExtensionResultHolder<List<FileUploadResult>> result);

  ExtensionResultStatusType removeResource(FileResourcePath path,
      String url, boolean localResource, ExtensionResultHolder<Boolean> result);


}
