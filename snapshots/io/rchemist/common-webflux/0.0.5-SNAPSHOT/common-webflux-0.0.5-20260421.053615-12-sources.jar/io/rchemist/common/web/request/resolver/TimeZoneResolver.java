/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.util.TimeZone;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmRequestTimeZoneResolver")
@Slf4j
public class TimeZoneResolver implements RequestAttributeResolver<TimeZone> {

  public static final String TIMEZONE_ATTR_NAME = "timezone";
  public static final String REQUESTED_TIMEZONE = "timezone";


  @Override
  public boolean canHandle(Class<TimeZone> clazz) {
    return clazz.equals(TimeZone.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    TimeZone timeZone = exchange.getAttribute(TIMEZONE_ATTR_NAME);

    if(timeZone == null){
      timeZone = getTimeZoneFromRequest(exchange);
    }

    if(timeZone == null){
      timeZone = getTimeZoneFromSession(exchange);
    }

    if(timeZone == null){
      timeZone = TimeZone.getDefault();
    }

    RequestUtil.addAttribute(exchange, TIMEZONE_ATTR_NAME, timeZone);

    context.setTimeZone(timeZone);
  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, TIMEZONE_ATTR_NAME);
  }

  protected TimeZone getTimeZoneFromSession(ServerWebExchange exchange) {
    return (TimeZone) RequestUtil.getAttribute(exchange, TIMEZONE_ATTR_NAME);
  }

  protected TimeZone getTimeZoneFromRequest(ServerWebExchange exchange) {

    String timeZoneCode = RequestUtil.getURLorHeaderParameter(exchange, REQUESTED_TIMEZONE);
    if(StringUtils.isNotEmpty(timeZoneCode)){
      return TimeZone.getTimeZone(timeZoneCode);
    }

    return null;
  }


  @Override
  public int getOrder() {
    return ResolverOrder.TIME_ZONE_RESOLVER;
  }
}
