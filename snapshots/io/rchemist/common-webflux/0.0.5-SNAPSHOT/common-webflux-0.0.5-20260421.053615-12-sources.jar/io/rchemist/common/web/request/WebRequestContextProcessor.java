/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.thread.ThreadLocalManager;
import io.rchemist.common.web.request.resolver.RequestAttributeResolver;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.MessageSource;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmWebRequestContextProcessor")
@Slf4j

public class WebRequestContextProcessor implements WebRequestProcessor{

  protected final MessageSource messageSource;

  protected final List<RequestAttributeResolver> requestAttributeResolvers;

  private static Boolean resolverSorted = false;

  public WebRequestContextProcessor(MessageSource messageSource,
      List<RequestAttributeResolver> requestAttributeResolvers) {
    this.messageSource = messageSource;
    this.requestAttributeResolvers = requestAttributeResolvers;
  }

  private void sortResolvers(){
    Collections.sort(requestAttributeResolvers, Comparator.comparing(Ordered::getOrder));
    resolverSorted = true;
  }

  private List<RequestAttributeResolver> getRequestAttributeResolvers(){
    synchronized (resolverSorted){
      if(!resolverSorted){
        sortResolvers();
      }
      return requestAttributeResolvers;
    }
  }

  @Override
  public void process(ServerWebExchange exchange) {

    WebRequestContext context = new WebRequestContext();
    context.setRequest(exchange.getRequest());
    context.addAttribute(WebRequestProcessor.SERVER_WEB_EXCHANGE, exchange);
    WebRequestContext.setWebRequestContext(context);

    for(RequestAttributeResolver<?> resolver : CollectionUtils.emptyIfNull(getRequestAttributeResolvers())){
      resolver.resolve(exchange, context);
    }

    context.setMessageSource(messageSource);

  }

  @Override
  public void postProcess(ServerWebExchange exchange) {
    ThreadLocalManager.remove();
  }

  protected void clearSessionAttributes(ServerWebExchange exchange){
    // WebRequestContextProcessor.process 로 인해 생성되는 세션 정보를 해제한다.
    // WebRequestContextProcessor 의 코드가 변경될 때 마다 해당하는 추가 코드를 작성한다.

    for(RequestAttributeResolver resolver : CollectionUtils.emptyIfNull(requestAttributeResolvers)){
      resolver.clearSessionAttribute(exchange);
    }
  }


  public static ServerWebExchange getServerWebExchange() {
    return WebRequestContext.getWebRequestContext() == null ? null : WebRequestContext.getWebRequestContext().getAttribute(SERVER_WEB_EXCHANGE);
  }

}
