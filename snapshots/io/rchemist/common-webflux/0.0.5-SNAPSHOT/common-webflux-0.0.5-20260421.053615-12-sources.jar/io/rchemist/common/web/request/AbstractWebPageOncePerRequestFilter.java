/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractWebPageOncePerRequestFilter implements WebPageFilter {

  private final String oncePerRequestFilterKey = getClass().getName() + ".FILTER_APPLIED";

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    if(shouldSkipFilter(exchange)){
      return chain.filter(exchange);
    }else{
      exchange.getAttributes().put(oncePerRequestFilterKey, Boolean.TRUE);
      return doOncePerRequestFilter(exchange, chain);
    }
  }

  protected abstract Mono<Void> doOncePerRequestFilter(ServerWebExchange exchange, WebFilterChain chain);

  protected boolean shouldSkipFilter(ServerWebExchange exchange) {
    return exchange.getAttribute(oncePerRequestFilterKey) != null;
  }

}
