/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.multitenant.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import io.rchemist.common.util.RequestUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = "rcmTenantInformationExtensionManager", priority = 200)
public class ReactiveRetrieveHeaderExtensionHandler extends
  AbstractReactiveTenantInformationExtensionHandler {

  private static final String HEADER_TENANT = "X-TENANT";
  private static final String HEADER_SITE = "X-SITE";

  @Override
  public ExtensionResultStatusType findTenantInformation(ServerWebExchange exchange,
      ExtensionResultHolder<TenantInformation> erh) {

    String tenantAlias = RequestUtil.getURLorHeaderParameter(exchange, HEADER_TENANT);
    String siteAlias = RequestUtil.getURLorHeaderParameter(exchange, HEADER_SITE);

    // tenant id 만 넘어 와도 된다. 각 서비스 로직에서 site id 가 필수라면 해당 로직에서 걸러내면 된다.
    if(StringUtils.isNotEmpty(tenantAlias)){
      erh.setResult(new TenantInformation(tenantAlias, siteAlias));
      return ExtensionResultStatusType.HANDLED;
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
