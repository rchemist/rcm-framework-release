/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface WorkflowContext<CONTEXT, U> extends Serializable, Cloneable {

  U getSeed();

  void setSeed(U seed);

  default CONTEXT withSeed(U seed) {
    setSeed(seed);
    return (CONTEXT) this;
  }

  Map<String, Object> getRollbackState();

  void setRollbackState(Map<String, Object> rollbackState);

  default CONTEXT withRollbackState(Map<String, Object> rollbackState) {
    setRollbackState(rollbackState);
    return (CONTEXT) this;
  }

  default CONTEXT addRollbackState(String key, Object value) {
    if (getRollbackState() == null)
      setRollbackState(new HashMap<>());
    getRollbackState().put(key, value);
    return (CONTEXT) this;
  }

}
