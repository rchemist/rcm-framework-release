/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service;

import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import org.apache.tika.utils.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
public class PasswordHelper implements ApplicationContextAware, ApplicationListener<ApplicationReadyEvent> {

  private static PasswordEncoder passwordEncoder;
  private static ApplicationContext context;

  public static PasswordEncoder getPasswordEncoder(){
    if(passwordEncoder == null){
      passwordEncoder = context.getBean("passwordEncoder", PasswordEncoder.class);
    }
    return passwordEncoder;
  }

  /**
   * password 암호화
   * @param clearPassword
   * @return
   */
  public static String encode(String clearPassword){
    if (StringUtils.isEmpty(clearPassword))
      throw new PlatformSecurityException("password is empty");
    return getPasswordEncoder().encode(clearPassword);
  }

  /**
   * 비밀번호가 같은지 확인
   * @param clearPassword
   * @param encodedPassword
   * @return
   */
  public static boolean equalPassword(String clearPassword, String encodedPassword){
    if (StringUtils.isEmpty(clearPassword))
      throw new PlatformSecurityException("password is empty");

    return getPasswordEncoder().matches(clearPassword, encodedPassword);
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    context = applicationContext;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    context = event.getApplicationContext();
  }

}
