/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.SimpleAuthentication;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SecurityContextExtensionHandler extends ExtensionHandler {

  /**
   * Authentication 을 해석해 SimpleAuthentication 으로 변환한다.
   * common-framework 에는 SpringSecurity 의존성이 없으므로 Object 로 받는다.
   * @param authentication
   * @param resultHolder
   * @return
   */
  ExtensionResultStatusType translateAuthentication(Object authentication, ExtensionResultHolder<SimpleAuthentication> resultHolder);

}
