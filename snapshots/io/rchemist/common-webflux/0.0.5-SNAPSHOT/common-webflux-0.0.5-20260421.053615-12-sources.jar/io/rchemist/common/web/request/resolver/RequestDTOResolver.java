/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.RequestDTO;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmRequestDTOResolver")
public class RequestDTOResolver implements RequestAttributeResolver<RequestDTO> {

  @Override
  public boolean canHandle(Class<RequestDTO> clazz) {
    return clazz.equals(RequestDTO.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    RequestDTO dto;
    if(exchange.getAttribute(RequestDTO.REQUEST_DTO_NAME) != null){
      dto = exchange.getAttribute(RequestDTO.REQUEST_DTO_NAME);
    }else{
      dto = new RequestDTO();
      dto.setDeviceType(RequestUtil.getCurrentDeviceTypeFromSession(exchange));
      dto.setSecure(RequestUtil.isSecure());
      dto.setRequestURI(exchange.getRequest().getURI().getPath());
      dto.setFullUrlWithQuery(exchange.getRequest().getURI().toString());
    }
    RequestUtil.addAttribute(exchange, RequestDTO.REQUEST_DTO_NAME, dto);
    context.setRequestDTO(dto);
  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, RequestDTO.REQUEST_DTO_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.REQUEST_DTO_RESOLVER;
  }
}
