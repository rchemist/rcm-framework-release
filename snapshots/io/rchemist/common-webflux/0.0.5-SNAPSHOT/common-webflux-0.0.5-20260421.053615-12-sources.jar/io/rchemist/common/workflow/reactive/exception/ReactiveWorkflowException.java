/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.workflow.reactive.exception;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ReactiveWorkflowException extends Exception {

  @Getter
  protected final boolean shouldRollback;

  @Getter
  protected final Class<?> activityClass;

  public ReactiveWorkflowException(Class<?> activityClass, Throwable throwable, boolean shouldRollback) {
    super(throwable);
    this.activityClass = activityClass;
    this.shouldRollback = shouldRollback;
  }

  public ReactiveWorkflowException(Class<?> activityClass, Throwable throwable) {
    this(activityClass, throwable, true);
  }

  public ReactiveWorkflowException(Class<?> activityClass, String message, boolean shouldRollback) {
    super(message);
    this.activityClass = activityClass;
    this.shouldRollback = shouldRollback;
  }
  public ReactiveWorkflowException(Class<?> activityClass, String message) {
    this(activityClass, message, true);
  }

  public ReactiveWorkflowException(String message) {
    this(null, message, true);
  }

  public ReactiveWorkflowException(String message, boolean shouldRollback) {
    this(null, message, shouldRollback);
  }
}
