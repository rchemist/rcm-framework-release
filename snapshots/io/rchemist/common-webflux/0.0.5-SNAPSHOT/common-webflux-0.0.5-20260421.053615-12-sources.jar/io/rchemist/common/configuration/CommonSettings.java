/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Setter
@Getter
@Component("rcmCommonSettings")
public class CommonSettings {

  private static CommonSettings commonSettings;

  /**
   * 기본 사이트 이름 - Message provider 에서 사용한다.
   */
  @Value("${platform.config.common.site-name:Rchemist}")
  protected String siteName;

  public static CommonSettings getCommonSettings(){
    if(commonSettings == null){
      commonSettings = ApplicationContextHolder.getBean(CommonSettings.class);
    }
    return commonSettings;
  }
  
}
