/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmWebRequestContextFilter")
@Slf4j
public class WebRequestContextFilter extends AbstractWebPageOncePerRequestFilter {

  protected final WebRequestContextProcessor webRequestContextProcessor;

  private Set<String> ignoreSuffixes;

  public WebRequestContextFilter(WebRequestContextProcessor webRequestContextProcessor) {
    this.webRequestContextProcessor = webRequestContextProcessor;
  }

  @Override
  protected Mono<Void> doOncePerRequestFilter(ServerWebExchange exchange, WebFilterChain chain) {

    if (!shouldProcessURL(exchange, exchange.getRequest().getURI().toString())) {
      return chain.filter(exchange);
    }

    try {
      webRequestContextProcessor.process(exchange);
      return chain.filter(exchange);
    } finally {
      webRequestContextProcessor.postProcess(exchange);
    }

  }

  protected boolean shouldProcessURL(ServerWebExchange exchange, String requestURI) {
    int pos = requestURI.lastIndexOf(".");
    if (pos > 0) {
      String suffix = requestURI.substring(pos);
      return !getIgnoreSuffixes().contains(suffix.toLowerCase());
    }
    return true;
  }

  protected Set<String> getIgnoreSuffixes() {
    if (ignoreSuffixes == null || ignoreSuffixes.isEmpty()) {
      String[] ignoreSuffixList = {".aif", ".aiff", ".asf", ".avi", ".bin", ".bmp", ".css", ".doc",
          ".eps", ".gif", ".hqx", ".js", ".jpg", ".jpeg", ".mid", ".midi", ".mov", ".mp3", ".mpg",
          ".mpeg", ".p65", ".pdf", ".pic", ".pict", ".png", ".ppt", ".psd", ".qxd", ".ram", ".ra",
          ".rm", ".sea", ".sit", ".stk", ".swf", ".tif", ".tiff", ".txt", ".rtf", ".vob", ".wav",
          ".wmf", ".xls", ".xlsx", ".zip"};
      ignoreSuffixes = new HashSet<String>(Arrays.asList(ignoreSuffixList));
    }
    return ignoreSuffixes;
  }


  @Override
  public int getOrder() {
    return WebPageFilter.POST_SECURITY_HIGH;
  }
}
