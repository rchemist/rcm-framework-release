/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.util.Currency;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmCurrencyResolver")
public class CurrencyResolver implements RequestAttributeResolver<Currency> {

  public static final String CURRENCY_ATTR_NAME = "currency";
  public static final String REQUESTED_CURRENCY_CODE = "currency";

  @Value("${platform.config.common.default.currency:KRW}")
  protected String currencyCode;

  @Override
  public boolean canHandle(Class<Currency> clazz) {
    return clazz.equals(Currency.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    Currency currency = exchange.getAttribute(CURRENCY_ATTR_NAME);

    if(currency == null){
      currency = getCurrencyFromUrl(exchange);
    }

    if(currency == null){
      currency = getCurrencyFromSession(exchange);
    }

    if(currency == null){
      currency = Currency.getInstance(currencyCode);
    }

    RequestUtil.addAttribute(exchange, CURRENCY_ATTR_NAME, currency);

    context.setCurrency(currency);

  }

  protected Currency getCurrencyFromSession(ServerWebExchange exchange) {
    return (Currency) RequestUtil.getAttribute(exchange, CURRENCY_ATTR_NAME);
  }

  protected Currency getCurrencyFromUrl(ServerWebExchange exchange) {
    String code = RequestUtil.getURLorHeaderParameter(exchange, REQUESTED_CURRENCY_CODE);
    if(StringUtils.isNotEmpty(code)){
      return Currency.getInstance(code);
    }
    return null;
  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, CURRENCY_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.CURRENCY_RESOLVER;
  }
}
