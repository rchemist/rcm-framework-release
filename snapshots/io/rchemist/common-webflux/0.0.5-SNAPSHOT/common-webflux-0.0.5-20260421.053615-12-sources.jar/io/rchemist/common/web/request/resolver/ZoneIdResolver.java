/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.time.ZoneId;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Service("rcmZoneIdResolver")
public class ZoneIdResolver implements RequestAttributeResolver<ZoneId> {

  public static String ZONE_ID_ATTR_NAME = "zoneId";
  public static String REQUESTED_ZONE_ID = "zoneId";

  @Override
  public boolean canHandle(Class<ZoneId> clazz) {
    return clazz.equals(ZoneId.class);
  }

  @Override
  public void resolve(ServerWebExchange exchange, WebRequestContext context) {

    ZoneId zoneId = exchange.getAttribute(ZONE_ID_ATTR_NAME);

    if(zoneId == null){
      if(RequestUtil.getURLorHeaderParameter(exchange, REQUESTED_ZONE_ID) != null){
        zoneId = ZoneId.of(RequestUtil.getURLorHeaderParameter(exchange, REQUESTED_ZONE_ID));
      }
    }

    zoneId = (zoneId == null) ? ZoneId.systemDefault() : zoneId;
    RequestUtil.addAttribute(exchange, ZONE_ID_ATTR_NAME, zoneId);
    context.setZoneId(zoneId);

  }

  @Override
  public void clearSessionAttribute(ServerWebExchange exchange) {
    RequestUtil.removeAttribute(exchange, ZONE_ID_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.ZONE_ID_RESOLVER;
  }
}
