/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.tenant.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TenantServiceErrorType extends EnumType<TenantServiceErrorType> implements ErrorType {

  public static final TenantServiceErrorType TENANT_NOT_FOUND = new TenantServiceErrorType("TENANT_NOT_FOUND", "Tenant is not found", "Tenant 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType TENANT_NOT_MATCH = new TenantServiceErrorType("TENANT_NOT_MATCH", "Tenant did not match", "잘못된 Tenant 정보를 요청했습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType APIKEY_NOT_MATCH = new TenantServiceErrorType("APIKEY_NOT_MATCH", "Apikey did not match", "잘못된 API KEY 정보를 요청했습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType SITE_NOT_MATCH = new TenantServiceErrorType("SITE_NOT_MATCH", "Site did not match", "잘못된 Site 정보를 요청했습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType TENANT_ALIAS_NOT_FOUND = new TenantServiceErrorType("TENANT_ALIAS_NOT_FOUND", "Tenant alias is not found", "Tenant Alias 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType SITE_ALIAS_NOT_FOUND = new TenantServiceErrorType("SITE_ALIAS_NOT_FOUND", "Site alias is not found", "사이트 Alias 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType DUPLICATED_SITE_ALIAS = new TenantServiceErrorType("DUPLICATED_SITE_ALIAS", "Duplicate site alias.", "사이트 Alias 가 중복되었습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType TENANT_HAS_NO_SITE  = new TenantServiceErrorType("TENANT_HAS_NO_SITE", "Tenant has no site.", "테넌트에 사이트 정보가 등록되지 않았습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType SITE_NOT_FOUND = new TenantServiceErrorType("SITE_NOT_FOUND", "Site not found", "사이트 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType DOMAIN_URL_NOT_FOUND = new TenantServiceErrorType("DOMAIN_URL_NOT_FOUND", "Domain url not found", "사이트에 도메인 URL이 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType NOT_VALID_DOMAIN_URL = new TenantServiceErrorType("NOT_VALID_DOMAIN_URL", "Domain url is not valid", "잘못된 도메인 URL이 입력됐습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType DUPLICATED_URL = new TenantServiceErrorType("DUPLICATED_URL", "Url is duplicated", "같은 URL 을 여러 테넌트와 사이트에 중복해 입력할 수 없습니다.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType NOT_VALID_AVAILABLE_DATES = new TenantServiceErrorType("NOT_VALID_AVAILABLE_DATES", "Available dates are not valid", "시작일과 종료일을 제대로 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final TenantServiceErrorType SITE_AUTH_PROVIDER_NOT_FOUND = new TenantServiceErrorType("SITE_AUTH_PROVIDER_NOT_FOUND", "SiteAuthProvider is not found", "설정된 Provider가 없습니다.", HttpStatus.NOT_FOUND);
  public static final TenantServiceErrorType WRONG_ACCESS = new TenantServiceErrorType("WRONG_ACCESS", "Wrong access", "잘못된 접근입니다.", HttpStatus.BAD_REQUEST);

  @Getter
  protected final int status;

  public TenantServiceErrorType(String type, String friendlyType, String description, HttpStatus httpStatus) {
    super(type, friendlyType, description);
    this.status = httpStatus.value();
  }

}
