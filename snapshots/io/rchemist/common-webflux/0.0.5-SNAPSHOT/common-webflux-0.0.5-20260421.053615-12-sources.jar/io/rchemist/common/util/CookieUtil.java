/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.util.Base64;
import java.util.List;
import java.util.Optional;
import org.apache.commons.collections4.MapUtils;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.util.MultiValueMap;
import org.springframework.util.SerializationUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CookieUtil {

  public static final int DEFAULT_EXPIRY = 7 * 24 * 60 * 60;    // 7일
  public static final int SHORT_EXPIRY = 30 * 60;   // 30분
  public static final String DEFAULT_PATH = "/";

  public static Optional<HttpCookie> getCookie(ServerHttpRequest request, String name) {
    MultiValueMap<String, HttpCookie> cookies = request.getCookies();

    if (MapUtils.isNotEmpty(cookies)) {
      for (List<HttpCookie> cookieList : cookies.values()) {
        for (HttpCookie cookie : cookieList) {
          if (cookie.getName().equals(name)) {
            return Optional.of(cookie);
          }
        }
      }
    }

    return Optional.empty();
  }

  public static String getCookieValue(ServerHttpRequest request, String name, boolean decode){
    Optional<HttpCookie> cookie = getCookie(request, name);
    return cookie.map(httpCookie -> getValue(httpCookie, decode)).orElse(null);
  }

  private static String getValue(HttpCookie cookie, boolean decode){
    return (decode) ? decode(cookie, String.class) : cookie.getValue();
  }


  public static Mono<Void> addCookie(ServerWebExchange exchange, String name, String value){
    return addCookie(exchange, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, false, false, false);
  }

  public static Mono<Void> addSecureCookie(ServerWebExchange exchange, String name, String value){
    return addCookie(exchange, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, true, false, false);
  }

  public static Mono<Void> addHttpOnlyCookie(ServerWebExchange exchange, String name, String value){
    return addCookie(exchange, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, false, true, false);
  }

  public static Mono<Void> addCookie(ServerWebExchange exchange, String path, String name, String value, int maxAge, boolean secure, boolean httpOnly, boolean encode) {
    if(encode){
      value = encode(value);
    }
    ResponseCookie cookie = ResponseCookie.from(name, value)
      .path(path)
      .maxAge(maxAge)
      .secure(secure)
      .httpOnly(httpOnly)
      .build();
    exchange.getResponse().addCookie(cookie);

    return exchange.getResponse().setComplete();
  }

  public static Mono<Void> deleteCookie(ServerWebExchange exchange, String name) {

    ResponseCookie deletedCookie = ResponseCookie.from(name, "")
      .maxAge(0)
      .build();

    exchange.getResponse().addCookie(deletedCookie);
    return exchange.getResponse().setComplete();
  }

  public static String encode(Object object) {
    return Base64.getUrlEncoder()
        .encodeToString(SerializationUtils.serialize(object));
  }

  public static <T> T decode(HttpCookie cookie, Class<T> cls) {
    return cls.cast(SerializationUtils.deserialize(
        Base64.getUrlDecoder().decode(cookie.getValue())));
  }
}

