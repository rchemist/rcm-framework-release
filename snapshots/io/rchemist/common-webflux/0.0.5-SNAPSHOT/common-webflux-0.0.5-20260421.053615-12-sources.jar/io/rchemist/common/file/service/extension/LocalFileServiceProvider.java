/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.file.data.FileResource;
import io.rchemist.common.file.data.FileResourcePath;
import io.rchemist.common.file.data.FileUploadResult;
import io.rchemist.common.file.service.FileService;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.data.AssetMetadata;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = "rcmFileServiceExtensionManager", priority = Integer.MAX_VALUE)
public class LocalFileServiceProvider implements FileServiceExtensionHandler {

  @Override
  public ExtensionResultStatusType getResource(String fullUrl,
      String fileName, boolean localResource,
      ExtensionResultHolder<FileResource> result) throws FileServiceException {

    if(localResource){

      File file = new File(fullUrl);    // local file 의 full url 은 파일의 absolute path 를 의미한다.

      if(file.exists()){
        FileResource resource = new FileResource();
        resource.setFile(file);
        resource.setShouldResize(false);
        resource.setLocalResource(true);
        result.setResult(resource);
        return ExtensionResultStatusType.HANDLED_STOP;
      }else{

        // resize 된 파일일 수도 있다.
        // resize 요청이 처음 들어온 경우에는 원본 파일만 있고 resize 파일은 없을 수도 있기 때문에
        // 파일명에 resize 구분 코드가 있는지 확인하고 있으면 구분 코드를 제외한 원본 파일을 가져온다.

        if(StringUtils.contains(fileName, FileService.RESIZE_PREFIX)){
          String originFileName = StringUtils.substringBeforeLast(fileName, FileService.RESIZE_PREFIX);
          originFileName = originFileName + "." + FilenameUtils.getExtension(fileName);

          file = new File(originFileName);

          if(file.exists()){
            FileResource resource = new FileResource();
            resource.setFile(file);
            resource.setShouldResize(true);
            resource.setLocalResource(true);
            result.setResult(resource);
            return ExtensionResultStatusType.HANDLED_STOP;
          }

        }
      }

      throw new FileServiceException(FileServiceErrorType.FILE_NOT_FOUND);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  @Override
  public ExtensionResultStatusType uploadResources(FileResourcePath fileResourcePath, List<File> files,
      ExtensionResultHolder<List<FileUploadResult>> resultHolder) {

    List<FileUploadResult> result = new ArrayList<>();

    for(File file : files){

      AssetMetadata metadata = new AssetMetadata();

      try {
        metadata = FileUtil.getImageMetadata(new FileInputStream(file));
      } catch (FileNotFoundException e) {
        // skip
      }

      FileUploadResult value = FileUploadResult.builder()
          .fullUrl(file.getAbsolutePath())
          .fileSize(file.length())
          .mimeType(FileUtil.getMimeType(file))
          .assetMetadata(metadata)
          .localResource(true)
          .build();
      result.add(value);



    }

    resultHolder.setResult(result);

    // LocalFileServiceProvider 의 실행 순서가 맨 마지막이므로, 여기까지 그냥 넘어 왔다면 무조건 이 Provider 가 동작한다.
    // 따라서 HANDLED 로 리턴한다.
    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType removeResource(
      FileResourcePath path, String url,
      boolean localResource, ExtensionResultHolder<Boolean> resultHolder) {

    if(localResource){
      String fileName = FilenameUtils.normalize(path.getPath() + File.separator + url);
      File file = new File(fileName);

      boolean result = file.delete();

      resultHolder.setResult(result);

      return ExtensionResultStatusType.HANDLED;
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
