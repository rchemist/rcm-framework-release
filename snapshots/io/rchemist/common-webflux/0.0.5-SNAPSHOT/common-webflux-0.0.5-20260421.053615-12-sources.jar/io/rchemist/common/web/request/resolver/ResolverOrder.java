/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ResolverOrder {

  private ResolverOrder() {
  }

  public static final Integer SITE_AWARE_RESOLVER = 100;
  public static final Integer SECURITY_CONTEXT_RESOLVER = 200;
  public static final Integer LOCALE_RESOLVER = 300;
  public static final Integer CURRENCY_RESOLVER = 400;
  public static final Integer TIME_ZONE_RESOLVER = 500;
  public static final Integer ZONE_ID_RESOLVER = 600;
  public static final Integer REQUEST_DTO_RESOLVER = 700;
  public static final Integer DEVICE_TYPE_RESOLVER = 800;

}
