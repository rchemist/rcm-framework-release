/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.type.RandomCharEnumType;
import io.rchemist.common.util.type.TrieNode;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Map;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.random.RandomDataGenerator;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class RandomUtil {

  @Override
  public Object clone() throws CloneNotSupportedException {
    throw new CloneNotSupportedException();
  }

  /**
   * 기본 정의로 랜덤 문자열 생성하기
   * @return
   * @throws NoSuchAlgorithmException
   */
  public static String generateRandomId() throws NoSuchAlgorithmException{
    return generateRandomId(getDefaultRandomId(), getDefaultLength());
  }

  /**
   * 길이만 지정해 랜덤 문자열 생성하기
   * @param len
   * @return
   * @throws NoSuchAlgorithmException
   */
  public static String generateRandomId(int len) throws NoSuchAlgorithmException{
    return generateRandomId(getDefaultRandomId(), len);
  }

  /**
   * 랜덤 정의해 랜덤 문자열 생성하기
   * @param prng
   * @param len
   * @return
   * @throws NoSuchAlgorithmException
   */
  public static String generateRandomId(String prng, int len) throws NoSuchAlgorithmException {
    return generateRandomId(SecureRandom.getInstance(prng), RandomCharEnumType.CHARACTER, len, true);
  }

  /**
   * 4자리 단위로 랜덤 문자열에 - 붙이기
   * @param sr
   * @param len
   * @return
   */
  public static String generateRandomId(SecureRandom sr, RandomCharEnumType type, int len, boolean hyphen) {
    StringBuilder sb = new StringBuilder();

    char[] chars = type.getChars();

    for (int i = 1; i < len + 1; i++) {
      int index = sr.nextInt(chars.length);
      char c = chars[index];
      sb.append(c);

      if(hyphen){
        if ((i % 4) == 0 && i != 0 && i < len) {
          sb.append('-');
        }
      }
    }

    return sb.toString();
  }

  /**
   * 길이만 지정해 랜덤 문자열 생성하기
   * @param len
   * @return
   * @throws NoSuchAlgorithmException
   */
  public static String generateRandomString(RandomCharEnumType type, int len, boolean hyphen){
    return generateRandomId(getDefaultRandomCode(), type, len, hyphen);
  }

  @SneakyThrows
  private static SecureRandom getDefaultRandomCode() {
    return SecureRandom.getInstance(getDefaultRandomId());
  }

  // default encoding type
  public static String getDefaultRandomId(){
    return "SHA1PRNG";
  }

  protected static int getDefaultLength(){
    return 12;
  }

  public static String getRandomCode(String generator, String prefix) {
    String[] codeTypes = generator.split("-");

    TrieNode trieNode = new TrieNode();

    for(String codeType : codeTypes){
      char[] chars = codeType.toCharArray();
      trieNode.putNodes(chars);
    }

    Iterator<Map.Entry<Integer, TrieNode.Node>> iters = trieNode.getNodes().entrySet().iterator();

    StringBuilder sb = new StringBuilder();
    while(iters.hasNext()){
      Map.Entry<Integer, TrieNode.Node> entry = iters.next();

      TrieNode.Node node = entry.getValue();

      int length = node.getLength();
      RandomCharEnumType type = node.getRandomCharEnumType();

      String splitCode = RandomUtil.generateRandomString(type, length, false);
      sb.append(splitCode);

    }
    String code = sb.toString();

    if(StringUtils.isNotBlank(code)){
      sb = new StringBuilder();
      if(StringUtils.isNotBlank(prefix)){
        // 접두어 붙이기
        sb.append(prefix);
      }

      // 설정단위에 따라 - 표시
      int i = 0;
      for(Integer len : trieNode.getArrayLength()){
        if(i>0){
          sb.append("-");
        }
        sb.append(code, i, i+len);
        i = i + len;
      }
      code = sb.toString();
    }
    return code;
  }

  public static String getRandomNumber(int length){
    if(length < 1){
      length = 1;
    }

    int left = 0;
    int right = 9;

    StringBuilder sb = new StringBuilder();
    for(int i = 0; i < length; i++){
      int random = new RandomDataGenerator().nextInt(left, right);
      sb.append(random);
    }
    return sb.toString();

  }

}
