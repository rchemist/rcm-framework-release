/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class YearMonthUtil {

  public static YearMonth parse(String value){
    if(StringUtils.isNotEmpty(value)){
      try{
        return YearMonth.parse(value);
      }catch (Exception e){
        // value is not formatted
      }
    }
    return null;
  }

  public static List<String> getMonthlyDatesToString(YearMonth dateAtMonth, YearMonth dateAtUntilMonth, boolean restrictToday) {
    List<LocalDate> dates = getMonthlyDates(dateAtMonth, dateAtUntilMonth, restrictToday);

    if(CollectionUtils.isEmpty(dates))
      return null;

    List<String> dateStrings = new ArrayList<>();
    dates.forEach(e -> dateStrings.add(e.toString()));

    return dateStrings;

  }

  public static List<String> getMonthlyString(YearMonth start, YearMonth end) {
    List<String> dates = new ArrayList<>();

    YearMonth startMonth;
    YearMonth endMonth;

    if(start.isBefore(end)) {
      startMonth = start;
      endMonth = end;
    }else {
      startMonth = end;
      endMonth = start;
    }

    while (!startMonth.isAfter(endMonth)) {
      dates.add(startMonth.toString());
      startMonth = startMonth.plusMonths(1);
    }
    return dates;
  }

  /**
   * 주어진 기간 동안 매달 말일을 월간 날짜로 리턴
   * @param dateAtMonth
   * @param dateAtUntilMonth
   * @param restrictToday restrictToday 가 true 면 매달 말일을 리턴하되, 조회일 현재 이번 달의 날짜는 오늘로 한다.
   * @return
   */
  public static List<LocalDate> getMonthlyDates(YearMonth dateAtMonth, YearMonth dateAtUntilMonth, boolean restrictToday) {
    if(dateAtMonth == null && dateAtUntilMonth == null)
      return null;
    if(dateAtMonth == null && dateAtUntilMonth != null){
      dateAtMonth = dateAtUntilMonth;
    }else if(dateAtMonth != null && dateAtUntilMonth == null){
      dateAtUntilMonth = dateAtMonth;
    }

    if(dateAtMonth.equals(dateAtUntilMonth)){
      LocalDate date = dateAtMonth.atEndOfMonth();
      if(date.isAfter(LocalDate.now())){
        return new ArrayList<>(Arrays.asList(date));
      }
    }

    int difference = getDifferenceMonths(dateAtMonth, dateAtUntilMonth);

    List<LocalDate> dates = new ArrayList<>();

    LocalDate today = LocalDate.now();

    for(int i = 0; i <= difference; i++){
      YearMonth yearMonth = YearMonth.of(dateAtMonth.getYear(), dateAtMonth.getMonth());

      if(i > 0){
        yearMonth = yearMonth.plusMonths(Long.valueOf(i));
      }

      LocalDate date = yearMonth.atEndOfMonth();
      if(restrictToday){
        if(date.isAfter(today)){
          if(yearMonth.equals(YearMonth.now())){
            date = today;
          }
        }
      }

      dates.add(date);
    }

    return dates;

  }

  public static int getDifferenceMonths(YearMonth dateAtMonth, YearMonth dateAtUntilMonth){
    if(dateAtMonth == null || dateAtUntilMonth == null)
      return 0;
    return NumberUtil.getInteger(ChronoUnit.MONTHS.between(dateAtMonth, dateAtUntilMonth));
  }

  public static String format(YearMonth value) {
    if(value == null){
      return null;
    }else{
      return value.toString();
    }
  }

  public static LocalDateTime getFirstDate(YearMonth value) {
    if (value == null) {
      return null;
    }
    return LocalDateTime.of(value.getYear(), value.getMonth(), 1, 0, 0);
  }

  public static LocalDateTime getEndDate(YearMonth value) {
    if (value == null) {
      return null;
    }
    return LocalDateTimeUtil.getEndOfMonthDay(LocalDateTime.of(value.getYear(), value.getMonth(), 1, 0, 0));
  }

  public static Integer getDifferences(YearMonth value1, YearMonth value2) {

    YearMonth start;
    YearMonth end;

    if (value1.isAfter(value2)) {
      start = value2;
      end = value1;
    } else if (value2.isAfter(value1)) {
      start = value1;
      end = value2;
    } else {
      return 0;
    }

    int diff = ((end.getYear() - start.getYear()) * 12);

    if (start.getMonthValue() == end.getMonthValue()) {

    } else {
      if (start.getMonthValue() > end.getMonthValue()) {
        diff = diff - end.compareTo(start);
      } else {
        diff = diff + end.compareTo(start);
      }
    }

    return diff;
  }

}
