/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.i18n.service;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.i18n.configuration.PlatformResourceBundleMessageSource;
import io.rchemist.common.i18n.service.extension.MessageSourceExtensionManager;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.MessageSource;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmMessageSourceHelper")
public class MessageSourceHelper implements ApplicationContextAware, ApplicationListener<ApplicationReadyEvent> {

  public static final String NULL_VALUE = "*${null_value}*";

  protected static ApplicationContext applicationContext;

  private static MessageSourceExtensionManager extensionManager;

  public static MessageSourceExtensionManager getExtensionManager() {
    if(extensionManager == null){
      extensionManager = MessageSourceExtensionManager.getExtensionManager();
    }
    return extensionManager;
  }

  public static String getMessage(String code) {
    if(code == null)
      return null;
    return getMessage(code, (Object) null);
  }

  public static String getMessage(String code, Object... args) {
    if(getMessageSource() == null)
      return code;

    Locale locale = getLocale();

    return (getMessageSource() == null) ? code : getMessageSource().getMessage(code, args, locale);
  }

  @Nullable
  private static Locale getLocale() {
    Locale locale = null;

    if(getExtensionManager() != null){
      ExtensionResultHolder<Locale> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = getExtensionManager().getProxy().getLocale(resultHolder);

      if(!status.equals(ExtensionResultStatusType.NOT_HANDLED)){
        locale = resultHolder.getResult();
      }
    }

    if(locale == null && getMessageSource() instanceof PlatformResourceBundleMessageSource){
      locale = ((PlatformResourceBundleMessageSource) getMessageSource()).getDefaultLocale();
    }
    return locale;
  }

  /**
   * @return the "messageSource" bean from the application context
   */
  protected static MessageSource getMessageSource() {
    try{
      return (MessageSource) applicationContext.getBean("messageSource");
    }catch (NullPointerException e){
      // there is no applicationContext
      return null;
    }
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    MessageSourceHelper.applicationContext = applicationContext;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    setApplicationContext(event.getApplicationContext());
  }

  public static String inspectNullValue(String value){
    return (StringUtils.equals(value, NULL_VALUE)) ? null : value;
  }

}
