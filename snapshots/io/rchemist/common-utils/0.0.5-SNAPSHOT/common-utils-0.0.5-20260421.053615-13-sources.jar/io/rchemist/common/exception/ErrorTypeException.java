/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.DefaultServerErrorType;
import io.rchemist.common.exception.error.ErrorBuilder;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.exception.error.ErrorType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.StringUtil;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ErrorTypeException extends Exception implements HasPropertyNameException,
    HasErrorDTOException, HasErrorTypeException {

  public ErrorTypeException(ErrorType errorType){
    super(errorType.getType());
    this.errorType = errorType;
    this.message = errorType.getTranslatedType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeException(Throwable cause){
    if(cause instanceof Exception){
      ErrorDTO error = new ErrorDTO(cause);
      this.error = error;
      this.detailMessage = error.getDetailMessage();
    }
  }

  public ErrorTypeException(ErrorType errorType, Throwable cause) {
    super(errorType.getType(), cause);
    this.errorType = errorType;
    this.message = errorType.getTranslatedType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeException(String message, ErrorDTO errorDTO) {
    super(message);
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = errorDTO;
    this.detailMessage = error.getDetailMessage();
  }

  public ErrorTypeException(String message, Throwable cause) {
    super(message, cause);
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeException(String message) {
    super(message);
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  @Getter
  protected ErrorType errorType;

  protected ErrorDTO error = new ErrorDTO();

  protected String message;

  protected String detailMessage;

  @Getter
  protected String propertyName;

  public ErrorTypeException(String propertyName, String message) {
    super(message);
    this.propertyName = propertyName;
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeException(String propertyName, ErrorType errorType){
    super();
    this.propertyName = propertyName;
    this.errorType = errorType;
    ErrorDTO errorDTO = new ErrorDTO(errorType);
    this.error = errorDTO;
    this.message = errorType.getTranslatedType();
  }

  public ErrorTypeException(ErrorType errorType, String addedMessage) {
    ErrorDTO errorDTO = new ErrorDTO(errorType);
    errorDTO.setMessage(errorType.getTranslatedType() + " : " + addedMessage);
    this.error = errorDTO;
    this.message = errorType.getTranslatedType();
    this.errorType = errorType;
    this.detailMessage = addedMessage;
  }

  public boolean isEqualErrorType(ErrorType compareType) {
    if (this.errorType == null || compareType == null) {
      return false;
    } else {
      if (this.errorType instanceof EnumType<?> && compareType instanceof EnumType<?>) {
        return EnumTypeUtil.equals((EnumType<?>) this.errorType, (EnumType<?>) compareType);
      }
      return this.errorType.isEqualErrorType(compareType);
    }
  }

  public ErrorDTO getError(){
    if(error != null)
      return error;

    return (errorType != null) ? ErrorBuilder.getError(errorType) : null;
  }

  public ErrorTypeException withDetailMessage(String detailMessage) {
    this.detailMessage = detailMessage;
    return this;
  }

  public String getDetailMessage() {
    return StringUtil.toString(detailMessage, getMessage());
  }

  public ErrorTypeException withError(ErrorDTO error) {
    this.error = error;
    return this;
  }

  @Override
  public String getMessage(){
    String message = StringUtil.toString(this.message, this.detailMessage);
    return StringUtil.toString(message, (errorType != null) ? errorType.getTranslatedType() : null);
  }

  public String getErrorTypeToString(){
    if(errorType == null)
      return null;
    return errorType.getType();
  }

  public <T extends ErrorTypeException> T copyException(T destination) {
    destination.error = this.error;
    destination.errorType = this.errorType;
    destination.detailMessage = this.detailMessage;
    destination.message = this.message;
    return destination;
  }

}
