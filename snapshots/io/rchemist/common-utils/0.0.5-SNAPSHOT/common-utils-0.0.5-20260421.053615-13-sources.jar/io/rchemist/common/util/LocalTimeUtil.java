/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class LocalTimeUtil {

  public static final DateTimeFormatter DEFAULT_FORMAT = DateTimeFormatter.ISO_TIME;

  /**
   * yyyy-MM-dd 형태의 문자열을 LocalDate 으로 변환한다.
   * @param date
   * @return
   */
  public static LocalTime parse(String date) {
    return parse(date, null);
  }

  public static LocalTime parse(String date, LocalTime defaultValue) {
    return parse(date, defaultValue, DEFAULT_FORMAT);
  }

  public static LocalTime parse(String date, LocalTime defaultValue, DateTimeFormatter... formatter) {

    if (StringUtils.isEmpty(date)) {
      return defaultValue;
    }

    for (DateTimeFormatter format : formatter) {
      try {
        return LocalTime.parse(date, format);
      } catch (Exception e) {
        // nothing
      }
    }
    return defaultValue;

  }

  public static String format(LocalTime time) {
    return format(time, DEFAULT_FORMAT);
  }

  public static String format(LocalTime time, DateTimeFormatter... formatters) {
    if(time == null)
      return null;
    if(ArrayUtils.isEmpty(formatters)){
      time.format(DEFAULT_FORMAT);
    }else{
      for(DateTimeFormatter formatter : formatters){
        try{
          return time.format(formatter);
        }catch (Exception e){
          // parse error
        }
      }
    }

    return time.toString();

  }




}
