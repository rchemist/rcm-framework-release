/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by hongin
 **/
public class HttpMethodType extends EnumType<HttpMethodType> {

  public static final HttpMethodType GET = new HttpMethodType("GET", "Get");
  public static final HttpMethodType POST = new HttpMethodType("POST", "Post");
  public static final HttpMethodType PUT = new HttpMethodType("PUT", "Put");
  public static final HttpMethodType DELETE = new HttpMethodType("DELETE", "DELETE");
  public static final HttpMethodType PATCH = new HttpMethodType("PATCH", "PATCH");

  public HttpMethodType(String type, String friendlyType) {
    super(type, friendlyType);
  }
}
