/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import static org.apache.commons.io.IOUtils.closeQuietly;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class CloneUtil {

  public static <T extends Serializable> T copy(T input) {
    ByteArrayOutputStream baos = null;
    ObjectOutputStream oos = null;
    ByteArrayInputStream bis = null;
    ObjectInputStream ois = null;
    try {
      baos = new ByteArrayOutputStream();
      oos = new ObjectOutputStream(baos);
      oos.writeObject(input);
      oos.flush();

      byte[] bytes = baos.toByteArray();
      bis = new ByteArrayInputStream(bytes);
      ois = new ObjectInputStream(bis);
      Object result = ois.readObject();
      return (T) result;
    } catch (IOException e) {
      throw new IllegalArgumentException("Object can't be copied", e);
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Unable to reconstruct serialized object due to invalid class definition", e);
    } finally {
      closeQuietly(oos);
      closeQuietly(baos);
      closeQuietly(bis);
      closeQuietly(ois);
    }
  }

}
