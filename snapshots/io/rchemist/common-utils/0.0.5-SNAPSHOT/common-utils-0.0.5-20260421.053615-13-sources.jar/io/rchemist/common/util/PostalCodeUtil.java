/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class PostalCodeUtil {

  /**
   * 두 우편번호 또는 '*'를 포함한 우편번호의 일부가 서로 유사한지 확인한다.
   * 이 메소드는 주어진 패턴과 값이 특정 규칙에 따라 일치하는지 확인하며,
   * 패턴은 '*' 문자로 특정 위치를 대체할 수 있다.
   * 이 메소드는 다음과 같은 테스트를 통과한다:
   *
   * <pre>
   * case#1 postalCode1: 184*, postalCode2: 18450
   * - 패턴 '184*'는 '18450'과 일치함.
   *
   * case#2 postalCode1: 184*, postalCode2: 18*
   * - 패턴 '184*'는 '18*'와 일치함.
   *
   * case#3 postalCode1: 184*, postalCode2: 12345
   * - 패턴 '184*'는 '12345'와 일치하지 않음.
   *
   * case#4 postalCode1: 12*45, postalCode2: 12445
   * - 패턴 '12*45'는 '12445'와 일치함.
   *
   * case#5 postalCode1: 12*45, postalCode2: 12450
   * - 패턴 '12*45'는 '12450'과 일치하지 않음.
   *
   * case#6 postalCode1: 18*50, postalCode2: 18450
   * - 패턴 '18*50'은 '18450'과 일치함.
   *
   * case#7 postalCode1: 18*50, postalCode2: 18550
   * - 패턴 '18*50'은 '18550'과 일치함.
   *
   * case#8 postalCode1: 18*50, postalCode2: 19450
   * - 패턴 '18*50'은 '19450'과 일치하지 않음.
   *
   * case#9 postalCode1: 184*, postalCode2: 18*50
   * - 패턴 '184*'는 '18*50'과 일치함.
   *
   * case#10 postalCode1: 12*45, postalCode2: 13450
   * - 패턴 '12*45'는 '13450'과 일치하지 않음.
   *
   * case#11 postalCode1: 18450, postalCode2: 13450
   * - 패턴 '18450'은 '13450'과 일치하지 않음.
   *
   * case#12 postalCode1: 18450, postalCode2: 18*
   * - 패턴 '18450'은 '18*'과 일치함.
   * </pre>
   *
   * @param postalCode1 첫 번째 우편번호 또는 패턴을 나타내는 문자열.
   * @param postalCode2 두 번째 우편번호 또는 패턴을 나타내는 문자열.
   * @return 두 우편번호 또는 패턴이 유사한지 여부를 나타내는 불리언 값.
   */

  public static boolean isSimilar(String postalCode1, String postalCode2) {

    if (StringUtils.equals(postalCode1, postalCode2)) {
      return true;
    }

    if (StringUtils.isEmpty(postalCode1) || StringUtils.isEmpty(postalCode2)) {
      return false;
    }

    return isMatch(postalCode1, postalCode2) || isMatch(postalCode2, postalCode1);

  }

  private static boolean isMatch(String pattern, String value) {
    // Edge case where pattern is empty
    if (pattern.isEmpty()) {
      return value.isEmpty();
    }

    // Split pattern by '*'
    String[] patternParts = pattern.split("\\*");

    // If pattern starts with '*'
    if (pattern.startsWith("*") && !pattern.endsWith("*")) {
      String prefix = patternParts[1];
      int index = value.indexOf(prefix);
      return index != -1 && index + prefix.length() <= value.length();
    }

    // If pattern ends with '*'
    if (pattern.endsWith("*") && !pattern.startsWith("*")) {
      String suffix = patternParts[patternParts.length - 1];
      if (!value.contains("*")) {
        return value.startsWith(suffix);
      } else {
        String[] valueParts = value.split("\\*");
        if (valueParts[0].length() >= suffix.length()) {
          int index = value.lastIndexOf(suffix);
          return index != -1 && index + suffix.length() == value.length();
        } else {
          return suffix.startsWith(valueParts[0]);
        }
      }

    }

    // If pattern starts and ends with '*'
    if (pattern.startsWith("*") && pattern.endsWith("*")) {
      String innerPattern = pattern.substring(1, pattern.length() - 1);
      return containsPattern(value, innerPattern);
    }

    if (pattern.contains("*") && !value.contains("*")) {
      if (patternParts.length > 1) {
        // * 이 중간에 있다는 뜻이다.
        return value.startsWith(patternParts[0]) && value.endsWith(patternParts[1]);
      }
    }

    // If pattern contains '*' in the middle
    return containsPattern(value, pattern);
  }

  private static boolean containsPattern(String value, String pattern) {
    int start = 0;

    for (int i = 0; i < pattern.length(); i++) {
      char c = pattern.charAt(i);
      if (c == '*') {
        continue;
      }
      int index = value.indexOf(c, start);
      if (index == -1) {
        return false;
      }
      start = index + 1;
    }

    // Check if the rest of the value is acceptable
    return start <= value.length();
  }

  /**
   * 두 우편번호 또는 '*'를 포함한 우편번호의 일부가 유사한지 확인한다.
   * 이 메소드는 주어진 패턴과 값이 특정 규칙에 따라 일치하는지 확인하며,
   * 비교할 때 항상 `postalCode1`은 더 큰 범주의 우편번호여야 한다.
   * 패턴은 '*' 문자로 특정 위치를 대체할 수 있다.
   *
   * @param postalCode 패턴으로 사용할 우편번호 문자열. 이 문자열은 '*' 문자를 포함할 수 있으며, '*'는 아무 문자와도 일치할 수 있다.
   * @param compare 검사할 우편번호 문자열. 이 문자열이 패턴과 일치하는지 확인한다.
   * @return 두 우편번호가 패턴에 의해 정의된 규칙에 따라 일치하면 `true`, 그렇지 않으면 `false`를 반환한다.
   *
   * Address address1 = new Address("184*");
   *     Address address2 = new Address("12*45");
   *     Address address3 = new Address("18*50");
   *     Address address4 = new Address("18450");
   *
   *     // 1. Exact match with wildcard in DB
   *     assertTrue(address1.isSimilarPostalCode("18450"));
   *
   *     // 2. Wildcard in both DB and input
   *     assertFalse(address1.isSimilarPostalCode("18*"));
   *
   *     // 3. No match with different patterns
   *     assertFalse(address1.isSimilarPostalCode("12345"));
   *
   *     // 4. Match with complex pattern in both DB and input
   *     assertTrue(address2.isSimilarPostalCode("12445"));
   *
   *     // 5. No match with different complex patterns
   *     assertFalse(address2.isSimilarPostalCode("12450"));
   *
   *     // 6. Wildcard at the end of input
   *     assertTrue(address3.isSimilarPostalCode("18450"));
   *
   *     // 7. Exact match with full wildcard in DB
   *     assertTrue(address3.isSimilarPostalCode("18550"));
   *
   *     // 8. No match with completely different patterns
   *     assertFalse(address3.isSimilarPostalCode("19450"));
   *
   *     // 9. Full wildcard match
   *     assertFalse(address1.isSimilarPostalCode("18*50"));
   *
   *     // 10. No match with non-matching digits and wildcard
   *     assertFalse(address2.isSimilarPostalCode("13450"));
   *
   *     // 11. No match with non-matching digits and wildcard
   *     assertFalse(address4.isSimilarPostalCode("13450"));
   *
   *     // 12. No match with non-matching digits and wildcard
   *     assertFalse(address4.isSimilarPostalCode("18*"));
   *
   * @param postalCode  기준 우편번호
   * @param compare   비교 대상이 되는 우편번호
   */
  public static boolean isCovered(String postalCode, String compare) {
    // Handle exact match case
    if (postalCode.equals(compare)) {
      return true;
    }

    // Handle wildcard pattern case
    if (postalCode.contains("*")) {
      // Split the pattern by '*'
      String[] parts = postalCode.split("\\*");

      // If the pattern starts with '*'
      if (postalCode.startsWith("*")) {
        // Remove the leading '*' and check if the pattern without '*' is at the end of the value
        return compare.endsWith(parts[parts.length - 1]);
      }

      // If the pattern ends with '*'
      if (postalCode.endsWith("*")) {
        // Remove the trailing '*' and check if the pattern without '*' is at the start of the value
        return compare.startsWith(parts[0]);
      }

      // If the pattern has '*' in the middle
      int index = 0;
      for (int i = 0; i < parts.length - 1; i++) {
        String part = parts[i];
        int foundIndex = compare.indexOf(part, index);

        if (foundIndex == -1) {
          return false;
        }
        index = foundIndex + part.length();
      }

      // Check if the remaining part of the pattern after the last '*' matches the end of the value
      return compare.endsWith(parts[parts.length - 1]);
    }

    // No '*' in the pattern, direct comparison
    return false;
  }

}
