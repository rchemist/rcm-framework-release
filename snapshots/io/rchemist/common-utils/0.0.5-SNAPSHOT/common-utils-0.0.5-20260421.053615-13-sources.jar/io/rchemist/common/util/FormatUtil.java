/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import static java.time.temporal.ChronoField.DAY_OF_MONTH;
import static java.time.temporal.ChronoField.MONTH_OF_YEAR;
import static java.time.temporal.ChronoField.YEAR;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;
import java.util.Date;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class FormatUtil {

  public static final String LOCAL_DATE_ISO = "yyyy-MM-dd";
  public static final String LOCAL_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
  public static final String LOCAL_DATE_TIME_FORMAT_WITHOUT_SECOND = "yyyy-MM-dd HH:mm:ss";
  public static final String DATE_TIME_FORMAT = "yyyy.MM.dd HH:mm:ss";
  public static final String DATE_FORMAT_WITH_TIMEZONE = "yyyy.MM.dd HH:mm:ss Z";
  public static final String DATE_FORMAT_WITHOUT_TIMEZONE = "yyyy.MM.dd'T'HH:mm:ss";
  public static final String DATE_FORMAT_WITHOUT_TIMEZONE_DASH = "yyyy-MM-dd'T'HH:mm:ss";     // platform default - using html5 default input datetime-local
  public static final String DATE_FORMAT_WITHOUT_TIMEZONE_DASH_ON_MINUTE = "yyyy-MM-dd'T'HH:mm";     // 초 단위가 빠진 시각 = html5 에서 정각을 의미
  public static final String DATE_FORMAT_WITHOUT_TIMEZONE_DASH_ON_MINUTE_NO_DASH = "yyyy.MM.dd'T'HH:mm";     // 초 단위가 빠진 시각 = html5 에서 정각을 의미
  public static final String SERIAL = "yyyyMMddHHmmss";     // 모두 붙여서

  public static SimpleDateFormat getDefaultFormat(){
    // 기본 포맷
    return getWithoutTimeZoneFormatDash();
  }

  public static SimpleDateFormat getDateTimeFormat() {
    SimpleDateFormat formatter = new SimpleDateFormat(DATE_TIME_FORMAT);
    formatter.setTimeZone(TimeZoneUtil.getTimeZone());
    return formatter;
  }

  /**
   * Used with dates in rules since they are not stored as a Timestamp type (and thus not converted to a specific database
   * timezone on a save). In order to provide accurate information, the timezone must also be preserved in the MVEL rule
   * expression
   *
   * @return
   */
  public static SimpleDateFormat getTimeZoneFormat() {
    SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_WITH_TIMEZONE);
    formatter.setTimeZone(TimeZoneUtil.getTimeZone());
    return formatter;
  }

  public static SimpleDateFormat getWithoutTimeZoneFormat() {
    SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_WITHOUT_TIMEZONE);
    return formatter;
  }

  public static SimpleDateFormat getWithoutTimeZoneFormatDash() {
    SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT_WITHOUT_TIMEZONE_DASH);
    return formatter;
  }

  public static SimpleDateFormat getIsoLocalDateFormat() {
    return new SimpleDateFormat(LOCAL_DATE_ISO);
  }

  /**
   * Use to produce date Strings in the W3C date format
   *
   * @param date
   * @return
   */
  public static String formatDateUsingW3C(Date date) {
    String w3cDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(date);
    return w3cDate.substring(0, 22) + ":" + w3cDate.substring(22, 24);
  }


  public static String[] getDateTimeFormatter() {
    return new String[]{DATE_FORMAT_WITHOUT_TIMEZONE_DASH, DATE_FORMAT_WITHOUT_TIMEZONE_DASH_ON_MINUTE, DATE_FORMAT_WITHOUT_TIMEZONE_DASH_ON_MINUTE_NO_DASH, LOCAL_DATE_TIME_FORMAT, DATE_TIME_FORMAT, DATE_FORMAT_WITH_TIMEZONE, DATE_FORMAT_WITHOUT_TIMEZONE, LOCAL_DATE_ISO, LOCAL_DATE_TIME_FORMAT_WITHOUT_SECOND};
  }

  public static DateTimeFormatter getLocalDateFormat() {
    return new DateTimeFormatterBuilder()
        .appendValue(YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
        .appendLiteral('-')
        .appendValue(MONTH_OF_YEAR, 2)
        .appendLiteral('-')
        .appendValue(DAY_OF_MONTH, 2)
        .toFormatter();
  }

}
