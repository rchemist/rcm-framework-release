/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.util.type.TimeCompareType;
import io.rchemist.common.util.type.TimeDurationType;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javax.annotation.Nullable;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Setter
public class TimeCompareSource {

  public TimeCompareSource(LocalDateTime dateTime1
      , TimeDurationType durationType
      , TimeCompareType compareType
      , Integer compateValue) {
    this(dateTime1, null, durationType, compareType, compateValue);
  }

  public TimeCompareSource(LocalDateTime dateTime1
      , TimeDurationType durationType
      , TimeCompareType compareType) {
    this(dateTime1, null, durationType, compareType, 0);
  }

  public TimeCompareSource(LocalDateTime dateTime1
                           , LocalDateTime dateTime2
      , TimeDurationType durationType
      , TimeCompareType compareType
  ) {
    this(dateTime1, dateTime2, durationType, compareType, 0);
  }

  public TimeCompareSource(LocalDateTime dateTime1, LocalDateTime dateTime2, TimeDurationType durationType) {
    this(dateTime1, dateTime2, durationType, TimeCompareType.EQUAL, 0);
  }

  public TimeCompareSource(LocalDateTime dateTime1
      , @Nullable LocalDateTime dateTime2
      , TimeDurationType durationType
      , TimeCompareType compareType
      , Integer compareValue) {
    this.dateTime1 = dateTime1;
    // BUG-044 fix: reference the null-safe field, not the parameter.
    this.dateTime2 = (dateTime2 == null) ? LocalDateTime.now() : dateTime2;
    this.compareType = compareType;
    this.durationType = durationType;
    this.compareValue = (compareValue == null) ? 0 : compareValue;

    this.date1 = this.dateTime1.toLocalDate();
    this.date2 = this.dateTime2.toLocalDate();
    this.time1 = this.dateTime1.toLocalTime();
    this.time2 = this.dateTime2.toLocalTime();
  }

  private LocalDateTime dateTime1;
  private LocalDateTime dateTime2;
  private TimeCompareType compareType;
  private TimeDurationType durationType;
  private Integer compareValue;

  private LocalDate date1;
  private LocalDate date2;
  private LocalTime time1;
  private LocalTime time2;


  public boolean evaluate(){

    int value1 = 0;
    int value2 = 0;

    if(durationType.equals(TimeDurationType.YEAR)){
      value1 = date1.getYear();
      value2 = date2.getYear();
    }else if(durationType.equals(TimeDurationType.MONTH)){
      value1 = date1.getMonthValue();
      value2 = date2.getMonthValue();
    }else if(durationType.equals(TimeDurationType.DAY_OF_YEAR)){
      value1 = date1.getDayOfYear();
      value2 = date2.getDayOfYear();
    }else if(durationType.equals(TimeDurationType.DAY_OF_MONTH)){
      value1 = date1.getDayOfMonth();
      value2 = date2.getDayOfMonth();
    }else if(durationType.equals(TimeDurationType.DAY_OF_WEEK)){
      value1 = date1.getDayOfWeek().getValue();
      value2 = date2.getDayOfWeek().getValue();
    }else if(durationType.equals(TimeDurationType.HOUR)){
      value1 = time1.getHour();
      value2 = time2.getHour();
    }else if(durationType.equals(TimeDurationType.MINUTE)){
      value1 = time1.getMinute();
      value2 = time2.getMinute();
    }else if(durationType.equals(TimeDurationType.SECOND)){
      value1 = time1.getSecond();
      value2 = time2.getSecond();
    }else{
      return false;
    }

    return evaluate(value1, value2);

  }

  public int compare(){
    int value1 = 0;
    int value2 = 0;

    if(durationType.equals(TimeDurationType.YEAR)){
      value1 = date1.getYear();
      value2 = date2.getYear();
    }else if(durationType.equals(TimeDurationType.MONTH)){
      value1 = date1.getMonthValue();
      value2 = date2.getMonthValue();
    }else if(durationType.equals(TimeDurationType.DAY_OF_YEAR)){
      value1 = date1.getDayOfYear();
      value2 = date2.getDayOfYear();
    }else if(durationType.equals(TimeDurationType.DAY_OF_MONTH)){
      value1 = date1.getDayOfMonth();
      value2 = date2.getDayOfMonth();
    }else if(durationType.equals(TimeDurationType.DAY_OF_WEEK)){
      value1 = date1.getDayOfWeek().getValue();
      value2 = date2.getDayOfWeek().getValue();
    }else if(durationType.equals(TimeDurationType.HOUR)){
      value1 = time1.getHour();
      value2 = time2.getHour();
    }else if(durationType.equals(TimeDurationType.MINUTE)){
      value1 = time1.getMinute();
      value2 = time2.getMinute();
    }else if(durationType.equals(TimeDurationType.SECOND)){
      value1 = time1.getSecond();
      value2 = time2.getSecond();
    }else{
      return 0;
    }

    return value1 - value2;
  }

  private boolean evaluate(int value1, int value2) {

    int mod = value1 - value2 + compareValue;

    if(compareType.equals(TimeCompareType.EQUAL)){
      return mod == 0;
    }else if(compareType.equals(TimeCompareType.NOT_EQUAL)){
      return mod != 0;
    }else if(compareType.equals(TimeCompareType.EQUAL_SMALLER)){
      return mod >= 0;
    }else if(compareType.equals(TimeCompareType.EQUAL_GREATER)){
      return mod <= 0;
    }else if(compareType.equals(TimeCompareType.SMALLER)){
      return mod > 0;
    }else if(compareType.equals(TimeCompareType.GREATER)){
      return mod < 0;
    }
    return false;
  }

}
