/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.logging.LogLevel;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class ExceptionUtil {

  public static String printException(Throwable e){
    return ExceptionUtils.getStackTrace(e);
  }

  public static void printStackTrace(Throwable e){
    printStackTrace(null, e);
  }

  public static void printStackTrace(String message, Throwable e){
    String summary = StringUtils.isNotEmpty(message) ? message
        : (e != null ? e.getMessage() : "");
    if (e != null) {
      // 스택 트레이스를 WARN 에 함께 출력한다. 콘솔 노이즈는 커지지만 실제
      // 시스템 결함 (ClassTransformException 등) 진단에 스택이 필수.
      log.warn(summary, e);
    } else {
      log.warn(summary);
    }
  }

  public static void printLog(String message) {
    printLog(message, LogLevel.INFO);
  }

  public static void printLog(String message, LogLevel level){
    switch (level) {
      case INFO -> log.info(message);
      case WARN -> log.warn(message);
      case ERROR, FATAL -> log.error(message);
      case DEBUG -> log.debug(message);
      case TRACE -> log.trace(message);
    }
  }


}
