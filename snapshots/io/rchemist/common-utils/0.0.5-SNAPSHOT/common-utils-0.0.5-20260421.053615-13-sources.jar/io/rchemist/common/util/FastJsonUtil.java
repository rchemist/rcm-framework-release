/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import com.alibaba.fastjson.parser.DefaultJSONParser;
import com.alibaba.fastjson.parser.JSONLexer;
import com.alibaba.fastjson.parser.ParserConfig;
import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
import com.alibaba.fastjson.serializer.JSONSerializer;
import com.alibaba.fastjson.serializer.ObjectSerializer;
import com.alibaba.fastjson.serializer.SerializeConfig;
import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.EnumTypeUtil.EnumTypeSerializeData;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class FastJsonUtil {

  static {
    SerializeConfig.getGlobalInstance().put(Instant.class, new InstantAdapter.Serializer());
    ParserConfig.getGlobalInstance().putDeserializer(Instant.class, new InstantAdapter.Deserializer());

    SerializeConfig.getGlobalInstance().put(LocalDate.class, new LocalDateAdapter.Serializer());
    ParserConfig.getGlobalInstance().putDeserializer(LocalDate.class, new LocalDateAdapter.Deserializer());

    SerializeConfig.getGlobalInstance().put(LocalDateTime.class, new LocalDateTimeAdapter.Serializer());
    ParserConfig.getGlobalInstance().putDeserializer(LocalDateTime.class, new LocalDateTimeAdapter.Deserializer());

    SerializeConfig.getGlobalInstance().put(LocalTime.class, new LocalTimeAdapter.Serializer());
    ParserConfig.getGlobalInstance().putDeserializer(LocalTime.class, new LocalTimeAdapter.Deserializer());

  }

  public static String toJson(Object object) {
    if (object == null)
      return null;
    return com.alibaba.fastjson.JSON.toJSONString(object);
  }

  public static <T> T fromJson(String json, Class<T> clazz) {
    if (json == null)
      return null;
    return com.alibaba.fastjson.JSON.parseObject(json, clazz);
  }

  public static class LocalTimeAdapter {
    public static class Serializer implements ObjectSerializer {
      @Override
      public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
        if (object instanceof LocalTime localTime) {
          serializer.write(LocalTimeUtil.format(localTime));
        }
      }
    }

    public static class Deserializer implements ObjectDeserializer {
      @Override
      public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        JSONLexer lexer = parser.getLexer();
        lexer.nextToken();
        String localTimeStr = lexer.stringVal();
        return (T) LocalTimeUtil.parse(localTimeStr);
      }

      @Override
      public int getFastMatchToken() {
        return 0;
      }
    }
  }

  public static class LocalDateTimeAdapter {
    public static class Serializer implements ObjectSerializer {
      @Override
      public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
        if (object instanceof LocalDateTime localDateTime) {
          serializer.write(LocalDateTimeUtil.format(localDateTime));
        }
      }
    }

    public static class Deserializer implements ObjectDeserializer {
      @Override
      public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        JSONLexer lexer = parser.getLexer();
        lexer.nextToken();
        String localDateTimeStr = lexer.stringVal();
        return (T) LocalDateTimeUtil.parse(localDateTimeStr);
      }

      @Override
      public int getFastMatchToken() {
        return 0;
      }
    }
  }

  public static class LocalDateAdapter {
    public static class Serializer implements ObjectSerializer {
      @Override
      public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
        if (object instanceof LocalDate localDate) {
          serializer.write(LocalDateUtil.format(localDate));
        }
      }
    }

    public static class Deserializer implements ObjectDeserializer {
      @Override
      public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        JSONLexer lexer = parser.getLexer();
        lexer.nextToken();
        String localDateStr = lexer.stringVal();
        return (T) LocalDateUtil.parse(localDateStr);
      }

      @Override
      public int getFastMatchToken() {
        return 0;
      }
    }
  }

  public static class InstantAdapter {
    public static class Serializer implements ObjectSerializer {
      @Override
      public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
        if (object instanceof Instant instant) {
          serializer.write(instant.toString());
        }
      }
    }

    public static class Deserializer implements ObjectDeserializer {
      @Override
      public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        JSONLexer lexer = parser.getLexer();
        lexer.nextToken();
        String instantStr = lexer.stringVal();
        return (T) Instant.parse(instantStr);
      }

      @Override
      public int getFastMatchToken() {
        return 0;
      }
    }
  }

  public static class EnumTypeAdapter {

    public static class Serializer implements ObjectSerializer {
      @Override
      public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
        if (object instanceof EnumType<?> enumType) {

          EnumTypeSerializeData data = new EnumTypeSerializeData()
            .withType(enumType.getType())
            .withClassName(enumType.getClass().getName());

          serializer.write(FastJsonUtil.toJson(data));
        }
      }
    }

    public static class Deserializer implements ObjectDeserializer {
      @Override
      public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
        JSONLexer lexer = parser.getLexer();
        lexer.nextToken();
        String instantStr = lexer.stringVal();

        EnumTypeSerializeData data = FastJsonUtil.fromJson(instantStr, EnumTypeSerializeData.class);
        try {
          return EnumTypeUtil.getEnumType(
            (Class<? extends EnumType>) Class.forName(data.getClassName()), data.getType());
        } catch (ClassNotFoundException e) {
          throw new RuntimeException(e);
        }
      }

      @Override
      public int getFastMatchToken() {
        return 0;
      }
    }
  }

}
