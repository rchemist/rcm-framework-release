/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.IOException;
import java.nio.charset.Charset;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
public class ResourceUtil {

  private static final ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

  public static Resource[] getResources(String locationPattern) {
    try {
      return resolver.getResources(locationPattern);
    } catch (IOException e) {
      // silent exception
      return null;
    }
  }

  public static Resource getResource(String locationPattern) {
    Resource[] resources = getResources(locationPattern);
    if (resources == null || resources.length == 0) {
      return null;
    }
    return resources[0];
  }

  public static String getResourceString(String locationPattern, String encoding) {
    Resource resource = getResource(locationPattern);
    if (resource == null) {
      return null;
    }
    try {
      return resource.getContentAsString(Charset.forName(encoding));
    } catch (IOException e) {
      log.error(e.getMessage(), e);
      return null;
    }
  }

  public static String getResourceString(String locationPattern) {
    return getResourceString(locationPattern, Charset.defaultCharset().name());
  }

}
