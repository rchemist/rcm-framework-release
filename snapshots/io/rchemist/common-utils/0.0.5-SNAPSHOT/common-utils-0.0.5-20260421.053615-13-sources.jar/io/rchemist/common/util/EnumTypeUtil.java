/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.enumeration.EnumType;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class EnumTypeUtil {

  public static <T> T getEnumType(Class t, String type, T defaultValue){
    return getEnumType(t, type, defaultValue, 0);
  }

  public static <T> T getEnumType(EnumType<T> type, T defaultValue){
    return type == null ? defaultValue : (T) type;
  }

  public static <T> T getEnumType(Class t, String type, T defaultValue, int retryCount){
    if(retryCount > 2){
      return defaultValue;
    }

    if(StringUtils.isBlank(type)) return defaultValue;
    T returnValue = defaultValue;
    try {
      returnValue = (T) EnumType.class.getDeclaredMethod("getInstance", Class.class, String.class).invoke(t, t, type);
      if(returnValue == null){

        Field[] fields = t.getDeclaredFields();
        for(Field field : fields){
          field.setAccessible(true);
          String name = field.getName();
          try {
            T staticField = (T) t.getField(name).get(null);
          } catch (NoSuchFieldException e) {
            // ExceptionUtil.printStackTrace(e);
          }
        }

        // null 인 경우 field 를 강제로 reflection 한다
        return getEnumType(t, type, defaultValue, ++retryCount);

      }
    } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
      ExceptionUtil.printStackTrace(e);
    }

    return returnValue;
  }

  public static <T> T getEnumType(Class<? extends EnumType> t, String type){
    return getEnumType(t, type, null);
  }

  public static <T> List<T> getExplicitEnumTypes(Class<? extends EnumType<T>> t){
    return EnumType.getTypes(t);
  }

  public static List<EnumType<?>> getEnumTypes(Class<? extends EnumType<?>> clazz) {
    return EnumType.getObjectTypes(clazz);
  }

  public static <T> Map<String, T> getTypeMap(Class<? extends EnumType<T>> t){
    Map<String, T> map = new HashMap<>();
    List<T> types = EnumType.getTypes(t);

    if(CollectionUtils.isNotEmpty(types)){
      for(T type : types){
        map.put(((EnumType<?>) type).getType(), type);
      }
    }
    return map;
  }

  public static boolean equals(EnumType enumType, EnumType compareType){
    if(enumType == null){
      return compareType == null;
    }else{
      if(compareType == null){
        return false;
      }else{
        return enumType.equals(compareType);
      }
    }
  }

  public static boolean equalsAny(EnumType enumType, EnumType... compareTypes){
    if(ArrayUtils.isEmpty(compareTypes))
      return false;
    for(EnumType compareType : compareTypes){
      if(equals(enumType, compareType))
        return true;
    }
    return false;
  }

  public static boolean equalsAny(String type, EnumType... compareTypes){
    if(ArrayUtils.isEmpty(compareTypes))
      return false;
    for(EnumType compareType : compareTypes){
      if(equals(compareType, type))
        return true;
    }
    return false;
  }

  public static boolean equalsAny(EnumType type, String... compareTypes) {
    if(ArrayUtils.isEmpty(compareTypes))
      return false;
    for(String compareType : compareTypes){
      if(equals(type, compareType))
        return true;
    }
    return false;
  }

  public static boolean equals(EnumType<?> enumType, String type) {
    return enumType != null && StringUtils.equals(enumType.getType(), type);
  }

  public static boolean contains(EnumType enumType, EnumType... compareTypes){
    if(ArrayUtils.isEmpty(compareTypes))
      return false;
    for(EnumType compareType : compareTypes){
      if(equals(enumType, compareType))
        return true;
    }
    return false;
  }

  public static boolean contains(String enumType, EnumType... compareTypes){
    if(ArrayUtils.isEmpty(compareTypes))
      return false;
    for(EnumType compareType : compareTypes){
      if(equals(compareType, enumType))
        return true;
    }
    return false;
  }

  /**
   * nullSafe getType()
   * @param type
   * @return
   */
  public static String getType(EnumType type) {
    return (type == null) ? null : type.getType();
  }

  /**
   * nullSafe getTranslatedType()
   * @param type
   * @return
   */
  public static String getTranslatedType(EnumType type){
    return (type == null) ? null : type.getTranslatedType();
  }

  /**
   * List<EnumType> 의 각 type 을 모아 String[] 으로 변환
   * @param enumTypes
   * @return
   */
  public String[] getTypes(List<EnumType> enumTypes){
    if(CollectionUtils.isEmpty(enumTypes))
      return null;
    List<String> types = new ArrayList<>();
    for(EnumType type : enumTypes){
      types.add(type.getType());
    }
    return types.toArray(new String[0]);
  }

  @Getter
  @Setter
  public static class EnumTypeSerializeData implements Serializable {
    protected String type;
    protected String className;

    public EnumTypeSerializeData withType(String type) {
      this.type = type;
      return this;
    }

    public EnumTypeSerializeData withClassName(String className) {
      this.className = className;
      return this;
    }

    @Override
    public String toString() {
      return new ToStringBuilder(this)
        .append("type", type)
        .append("className", className)
        .toString();
    }
  }



}
