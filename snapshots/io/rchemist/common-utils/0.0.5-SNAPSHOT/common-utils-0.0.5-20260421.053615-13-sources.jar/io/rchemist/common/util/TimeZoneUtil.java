/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.util.extension.TimeZoneExtensionManager;
import io.rchemist.common.util.type.TimeZoneType;
import java.time.Instant;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.Collectors;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TimeZoneUtil {
  // zoneOffset, TimeZoneType[]
  private static final Map<String, TimeZoneType[]> VALUES = new LinkedHashMap<>();

  private static TimeZoneExtensionManager extensionManager;

  public static TimeZoneExtensionManager getExtensionManager() {
    if(extensionManager == null){
      extensionManager = TimeZoneExtensionManager.getExtensionManager();
    }
    return extensionManager;
  }

  public static TimeZone getTimeZone(){

    if(getExtensionManager() != null){

      ExtensionResultHolder<TimeZone> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = getExtensionManager().getProxy().getTimeZone(resultHolder);

      if(!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null){
        return resultHolder.getResult();
      }

    }

    return TimeZone.getDefault();

  }

  private static void initialize() {
    var timezoneGroups = ZoneId.getAvailableZoneIds().stream().map(ZoneId::of)
        .collect(Collectors.groupingBy(x -> x.getRules().getOffset(Instant.now())));

    timezoneGroups.entrySet().stream().sorted(Map.Entry.comparingByKey())
        .forEach(entry ->
            VALUES.put(entry.getKey().getId(), entry.getValue().stream()
                .map(zone ->
                    new TimeZoneType(zone.getId(), entry.getKey())).toArray(TimeZoneType[]::new)
            )
        );
  }

  public static Map<String, TimeZoneType[]> getTimezones() {
    // VALUES 에 동시에 접근해도 문제 없도록
    synchronized (VALUES) {
      if (VALUES.isEmpty()) {
        // 최초 진입 시 VALUES 를 만든다.
        initialize();
      }
      return new LinkedHashMap<>(VALUES);
    }
  }




}
