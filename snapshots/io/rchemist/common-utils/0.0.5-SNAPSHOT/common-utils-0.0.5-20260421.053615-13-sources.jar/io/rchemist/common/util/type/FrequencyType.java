/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class FrequencyType extends EnumType<FrequencyType> {

  public static final FrequencyType PER_5_MINUTE = new FrequencyType(1, "PER_5_MINUTE", "Per 5 minute", "5분 당 1회", "global.type.frequency.type.per.5.minute");
  public static final FrequencyType PER_30_MINUTE = new FrequencyType(1, "PER_30_MINUTE", "Every 30 minute", "30분 당 1회", "global.type.frequency.type.per.30.minute");
  public static final FrequencyType PER_1_HOUR = new FrequencyType(1, "PER_1_HOUR", "Per 1 Hour", "1시간 당 1회", "global.type.frequency.type.per.1.hour");
  public static final FrequencyType PER_2_HOUR = new FrequencyType(1, "PER_2_HOUR", "Per 2 Hour", "2시간 당 1회", "global.type.frequency.type.per.2.hour");
  public static final FrequencyType PER_6_HOUR = new FrequencyType(1, "PER_6_HOUR", "Per 6 Hour", "6시간 당 1회", "global.type.frequency.type.per.6.hour");
  public static final FrequencyType PER_12_HOUR = new FrequencyType(1, "PER_12_HOUR", "Per 12 Hour", "12시간 당 1회", "global.type.frequency.type.per.12.hour");
  public static final FrequencyType PER_1_DAY = new FrequencyType(1, "PER_1_DAY", "Per 1 day", "1일 1회", "global.type.frequency.type.per.1.day");


  public FrequencyType(int order, String type, String friendlyType, String description, String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }
}
