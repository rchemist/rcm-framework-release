/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.exception.error;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface ErrorType {

  String GLOBAL_ERROR = "global.type.error.type.error.occurred";

  // EnumType.getType();
  default String getType() {
    return "INTERNAL_SERVER_ERROR";
  }

  // EnumType.getTranslatedType();
  default String getTranslatedType() {
    return null;//BLCMessageUtils.getMessage(GLOBAL_ERROR);
  }

  // ErrorType.getStatus();
  default int getStatus() {
    return 500;   // 500 error is default
  }

  default boolean isEqualErrorType(ErrorType compareType) {
    if (compareType == null)
      return false;
    return StringUtils.equals(getType(), compareType.getType())
        && getStatus() == compareType.getStatus()
        ;
  }

}
