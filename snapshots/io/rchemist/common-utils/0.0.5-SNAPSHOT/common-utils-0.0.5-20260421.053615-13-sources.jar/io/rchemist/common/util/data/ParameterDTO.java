/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ParameterDTO implements Serializable {

  @Getter
  protected final Map<String, String[]> parameterMap = new HashMap<>();

  public void clear(){
    parameterMap.clear();
  }

  public boolean hasParameters(){
    return MapUtils.isNotEmpty(parameterMap);
  }

  public List<String> getParameterNames(){
    return new ArrayList<>(parameterMap.keySet());
  }

  private void setParameterMap(String uriParameters) {
    List<String> values = StringUtil.split(uriParameters, "=");

    String key = values.get(0);
    String[] value = (values.size() == 1) ? new String[]{} : StringUtil.splitArray(values.get(1), ",");

    setParameter(key, value);

  }


  public void setParameter(String key, String[] values){
    if(StringUtils.isNotEmpty(key)){
      if(values == null){
        values = new String[]{};
      }

      if(parameterMap.containsKey(key)){
        // merge
        if(ArrayUtils.isNotEmpty(values)){
          String[] parameter = parameterMap.get(key);
          parameter = ArrayUtils.addAll(parameter, values);
          parameterMap.put(key, parameter);
        }
      }else{
        parameterMap.put(key, values);
      }
    }
  }

  public boolean containsKey(String key){
    return hasParameters() && parameterMap.containsKey(key);
  }

  public String[] getParameters(String key){
    return parameterMap.get(key);
  }

  public String getParameter(String key){
    if(parameterMap.containsKey(key)){

      String[] value = parameterMap.get(key);

      if(ArrayUtils.isEmpty(value)){
        return null;
      }else{
        return value[0];
      }
    }else{
      return null;
    }
  }

  public String getParameterMap(){
    if(hasParameters()){
      StringBuilder sb = new StringBuilder();
      int i = 0;
      for(String parameter : getParameterNames()){
        if(i++ > 0){
          sb.append("&");
        }
        sb.append(parameter).append("=").append(getParameter(parameter));
      }
      return sb.toString();
    }
    return "";
  }

  public static ParameterDTO parseUri(String uri){

    ParameterDTO dto = new ParameterDTO();

    /*
    ["/static-resource/회사로고_가로_검정___3.png?assetKey\u003d536fd326-2444-4817-b57b-f08ad3b522be\u0026fileSize\u003d4899"]
     */

    if(StringUtils.isEmpty(uri))
      return dto;

    uri = StringEscapeUtils.unescapeJava(uri);

    if(!StringUtils.contains(uri, "?"))
      return dto;

    String uriParameters = StringUtils.substringAfter(uri, "?");

    if(StringUtils.contains(uriParameters, "&")){
      List<String> parameterValues = StringUtil.split(uriParameters, "&");
      for(String parameter : parameterValues){
        String unescapedParameter = StringEscapeUtils.unescapeJava(parameter);
        dto.setParameterMap(unescapedParameter);
      }
    }else{
      String unescapedParameter = StringEscapeUtils.unescapeJava(uriParameters);
      dto.setParameterMap(unescapedParameter);
    }
    return dto;
  }

}
