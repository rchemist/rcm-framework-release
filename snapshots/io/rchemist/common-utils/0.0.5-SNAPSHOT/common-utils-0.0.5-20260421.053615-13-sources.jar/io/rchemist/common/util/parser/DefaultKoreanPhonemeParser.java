/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.parser;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class DefaultKoreanPhonemeParser extends AbstractKoreanPhonemeParser {

  private final char CHAEUM_POINT = 0x0000;

  @Override
  protected void processWhenKorean(StringBuilder meanningfulChars,
      char chosung, char jungsung, char jongsung) {

    meanningfulChars.append(chosung).append(jungsung);

    if (jongsung != CHAEUM_POINT) {
      meanningfulChars.append(jongsung);
    }
  }

  @Override
  protected void processWhenNotKorean(StringBuilder meanningfulChars,
      char eachToken) {
    if (Character.isLetterOrDigit(eachToken)) {
      meanningfulChars.append(eachToken);
    }
  }

}
