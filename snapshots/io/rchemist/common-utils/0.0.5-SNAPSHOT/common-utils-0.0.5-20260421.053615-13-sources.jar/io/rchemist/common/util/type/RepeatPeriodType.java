/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.LocalDateTimeUtil;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.MonthDay;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class RepeatPeriodType extends EnumType<RepeatPeriodType> {

  public static final RepeatPeriodType YEARLY = new RepeatPeriodType(100, "YEARLY", "Yearly", "연 1회", "yearly");
  public static final RepeatPeriodType MONTHLY = new RepeatPeriodType(200, "MONTHLY", "Monthly", "월 1회", "monthly");
  public static final RepeatPeriodType PER_MONTHS = new RepeatPeriodType(300, "PER_MONTHS", "Per months", "X개월 마다 1회", "period.months");
  public static final RepeatPeriodType PER_DAYS = new RepeatPeriodType(400, "PER_DAYS", "Per Days", "X일 마다 1회", "period.days");

  @Override
  protected String getPrefix() {
    return "global.type.repeat.period.type.";
  }

  public RepeatPeriodType(int order, String type, String friendlyType, String description, String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }

  /**
   *
   * @param compareDate 비교 대상 날짜 - 기본값은 LocalDateTime.now()
   * @param baseDate  PER_MONTHS, PER_DAYS 의 경우 시작이 되는 기준일
   * @param period   PER_MONTHS , PER_DAYS 에서 PER 에 해당하는 숫자값
   * @param monthDay  YEARLY 의 경우 몇월몇일인지
   * @param rankingDay   MONTHLY 의 경우 몇일인지
   * @return
   */
  public boolean isSuitable(LocalDateTime compareDate, LocalDate baseDate, Integer period, String monthDay, Integer rankingDay){

    if(compareDate == null)
      compareDate = LocalDateTime.now();

    if(getType().equals(YEARLY.getType())){
      if(StringUtils.isEmpty(monthDay))
        return false;

      LocalDate date = compareDate.toLocalDate();

      int month = Integer.valueOf(StringUtils.substringBefore(monthDay, "-"));
      int mDay = Integer.valueOf(StringUtils.substringAfter(monthDay, "-"));

      return (date.getMonthValue() == month && date.getDayOfMonth() == mDay);

    }else if(getType().equals(MONTHLY.getType())){
      LocalDate date = compareDate.toLocalDate();

      if(date.getMonthValue() == 2 && rankingDay > 28){
        LocalDate lastDate = date.with(TemporalAdjusters.lastDayOfMonth());   // 마지막 날로 셋팅
        rankingDay = lastDate.getDayOfMonth();
      }

      return (rankingDay == date.getDayOfMonth());

    }else{

      if(baseDate == null)
        return false;

      LocalDate date = compareDate.toLocalDate();

      Long between = null;

      if(getType().equals(PER_MONTHS.getType())){
        between = ChronoUnit.MONTHS.between(date, baseDate);

      }else if(getType().equals(PER_DAYS.getType())){
        between = ChronoUnit.DAYS.between(date, baseDate);
      }

      if(between != null){
        int gap = Math.abs(between.intValue());
        return gap % period == 0;
      }
    }

    return false;

  }


  public LocalDateTime getSuitableAvailableUntil(LocalDateTime availableAt, LocalDateTime lastRankingDate, LocalDate periodBaseDate, String periodMonthDay, Integer period, Integer rankingDay){
    LocalDateTime availableUntil;

    LocalDateTime now = LocalDateTime.now();

    if(getType().equals(RepeatPeriodType.YEARLY.getType())){
      periodMonthDay = (periodMonthDay == null) ? "01-01" : periodMonthDay;

      int month = Integer.valueOf(StringUtils.substringBefore(periodMonthDay, "-"));
      int day = Integer.valueOf(StringUtils.substringAfter(periodMonthDay, "-"));

      MonthDay target = MonthDay.of(month, day);

      availableUntil = availableAt.withMonth(target.getMonthValue())
          .withDayOfMonth(target.getDayOfMonth())
          .plusYears(1l)
          .minusDays(1l);

      if(availableUntil.isBefore(now)){
        // 미래 날짜가 아닌 경우에는 내년 까지로
        availableUntil = availableUntil.withYear(now.getYear())
                        .plusYears(1l);
      }

    }else if(getType().equals(RepeatPeriodType.MONTHLY.getType())){
      rankingDay = (rankingDay == null) ? 1 : rankingDay;
      availableUntil = availableAt.plusMonths(Long.valueOf(rankingDay));
      if(availableUntil.getMonthValue() == 2 && rankingDay > 28){
        // 2월 29일이면 2월의 마지막 날로
        availableUntil = LocalDateTimeUtil.getEndOfMonthDay(availableUntil);
      }else{
        availableUntil = availableUntil.withDayOfMonth(rankingDay);
      }

      if(availableUntil.isBefore(now)){
        // 미래 날짜가 아닌 경우에는 다음 해 까지로
        availableUntil = availableUntil.withMonth(now.getMonthValue())
                        .plusMonths(1l);
      }

    }else {
      // X 개월마다 한번인 경우
      if(lastRankingDate == null)
        lastRankingDate = periodBaseDate.atTime(LocalTime.MAX);

      if(lastRankingDate.isBefore(availableAt)){
        lastRankingDate = availableAt;
      }

      if(getType().equals(RepeatPeriodType.PER_MONTHS.getType())){
        availableUntil = lastRankingDate.plusMonths(Long.valueOf(period));
      }else{
        availableUntil = lastRankingDate.plusDays(Long.valueOf(period));
      }
      availableUntil = availableUntil.minusDays(1l);    // 마지막 랭킹 산정일은 배치가 동작한 시점을 말하므로 -1 해 줘야 한다.

    }

    return LocalDateTimeUtil.getEndOfDay(availableUntil);

  }
}
