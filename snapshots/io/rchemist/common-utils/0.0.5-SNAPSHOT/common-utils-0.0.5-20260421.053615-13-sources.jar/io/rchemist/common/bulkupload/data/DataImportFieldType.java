package io.rchemist.common.bulkupload.data;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Getter;

/**
 * <p>
 * Project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
public enum DataImportFieldType {

  STRING(String.class),
  INTEGER(Integer.class),
  DOUBLE(Double.class),
  BIG_DECIMAL(BigDecimal.class),
  BOOLEAN(Boolean.class),
  LONG(Long.class),
  LOCAL_DATE(LocalDate.class),
  LOCAL_DATETIME(LocalDateTime.class),
  INSTANT(Instant.class),;

  private final Class<?> typeClass;

  DataImportFieldType(Class<?> typeClass) {
    this.typeClass = typeClass;
  }
}
