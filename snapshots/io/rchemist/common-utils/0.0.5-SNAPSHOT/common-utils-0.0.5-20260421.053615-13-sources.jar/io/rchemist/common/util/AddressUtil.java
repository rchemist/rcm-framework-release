/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class AddressUtil {

  /**
   * 두 주소지의 유사성을 판단한다.
   * 이 메소드는 도로명 주소를 기준으로 주소지의 유사성을 평가한다.
   *
   * 주소의 주요 구성 요소가 포함되는지 여부를 기준으로 유사성을 판단하며,
   * 각 주소의 토큰을 비교하여 포함 관계를 확인한다.
   *
   * 이 메소드는 다음 기준을 충족한다:
   *
   * case 1: address1: 제주특별자치도, address2: 제주특별자치도 제주시 은수길 → true
   *   - 주소 1의 모든 주요 구성 요소가 주소 2에 포함된다.
   *
   * case 2: address1: 제주특별자치도, address2: 제주시 은수길 → false
   *   - 주소 1의 주요 구성 요소가 주소 2에 완전히 포함되지 않는다.
   *
   * case 3: address1: 제주특별자치도, address2: 북제주 은수길 → false
   *   - 주소 1의 주요 구성 요소가 주소 2와 관련이 없다.
   *
   * case 4: address1: 제주특별자치도, address2: 제주특별자치도 제주시 은수길 31-1 (연동) → true
   *   - 주소 1의 주요 구성 요소가 주소 2에 포함된다.
   *
   * case 5: address1: 제주특별자치도, address2: 서울 → false
   *   - 주소 1의 주요 구성 요소가 주소 2에 포함되지 않는다.
   *
   * case 6: address1: 제주특별자치도 제주시 은수길, address2: 은수길 → false
   *   - 주소 1의 주요 구성 요소가 주소 2에 포함되지 않는다.
   *
   * case 7: address1: 제주특별자치도 제주시 은수길, address2: 제주특별자치도 제주시 → true
   *   - 주소 1의 주요 구성 요소가 주소 2에 포함된다.
   *
   * case 8: address1: 제주특별자치도 제주시 은수길, address2: 제주특별자치도 → true
   *   - 주소 1의 주요 구성 요소가 주소 2에 포함된다.
   *
   * @param address1 첫 번째 주소 문자열
   * @param address2 두 번째 주소 문자열
   * @return 두 주소가 유사하면 true, 그렇지 않으면 false
   */
  public static boolean isSimilar(String address1, String address2) {
    return isSimilar(address1, address2, false);
  }

  /**
   *
   * @param address1
   * @param address2
   * @param widerPrevious     address1 이 더 큰 범주의 주소인지에 따라 로직이 달라진다.
   * @return
   */
  public static boolean isSimilar(String address1, String address2, boolean widerPrevious) {
    if (StringUtils.isEmpty(address1) || StringUtils.isEmpty(address2)) {
      return StringUtils.equals(address1, address2);
    }

    int address1Length = StringUtils.length(address1);
    int address2Length = StringUtils.length(address2);

    if (address1Length > address2Length) {
      // 주소 1이 더 길이가 길다는 것은 범주가 더 낮은 주소라는 뜻이다. widerPrevious 가 true 면 그냥 실패 케이스가 된다.
      if (widerPrevious) {
        return false;
      }
      return address1.startsWith(address2);
    } else {
      return address2.startsWith(address1);
    }

  }


}
