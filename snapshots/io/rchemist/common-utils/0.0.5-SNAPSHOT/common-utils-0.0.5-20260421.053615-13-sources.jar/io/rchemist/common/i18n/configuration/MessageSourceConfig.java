/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.i18n.configuration;

import io.rchemist.common.i18n.service.extension.ResourceBundleMessageExtensionManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
public class MessageSourceConfig {

  @Value("${platform.config.message.default.locale:ko}")
  protected String defaultLocale;

  @Value("${platform.config.message.default.cache.second:86400}")
  protected int cacheSecond;

  @Value("${spring.messages.basename:}")
  private String baseName;

  @Autowired
  private Environment environment;

  private final ResourceBundleMessageExtensionManager extensionManager;

  public MessageSourceConfig(ResourceBundleMessageExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Bean
  public MessageSource messageSource(){
    PlatformResourceBundleMessageSource source = new PlatformResourceBundleMessageSource(extensionManager);
    source.setDefaultLocale(getDefaultLocale());
    source.setDefaultEncoding("UTF-8");
    source.setCacheSeconds(cacheSecond);
    source.setFallbackToSystemLocale(true);
    if(StringUtils.isNotEmpty(baseName)){
      String[] baseNames;
      if(StringUtils.contains(baseName, ",")){
        baseNames = StringUtils.split(baseName, ",");
        baseNames = getBasenameFromProperties(baseNames);
      }else{
        baseNames = getBasenameFromProperties(baseName);
      }

      source.setBasenames(baseNames);

    }
    source.setUseCodeAsDefaultMessage(true);
    return source;
  }

  private String[] getBasenameFromProperties(String... baseNames) {
    List<String> replacedBasenames = new ArrayList<>();
    for(String name : baseNames){

      ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
      try {

        String filename = name.endsWith("**") ? name : name + ".properties";

        Resource[] resources = resolver.getResources("classpath*:"+filename);

        if(ArrayUtils.isNotEmpty(resources)){
          for(Resource resource : resources){
            String path = resource.getURI().getPath();

            if(StringUtils.isEmpty(path)){

              String uri = resource.getURI().getRawSchemeSpecificPart();
              if(StringUtils.contains(uri, ".jar!")){
                String messagePath = StringUtils.substringBetween(uri, ".jar!/", ".properties");
                // BOOT-INF/lib/micro-commerce-catalog-0.0.1-SNAPSHOT.jar!/messages/catalog/messages
                if (StringUtils.startsWith(messagePath, "BOOT-INF")){
                  messagePath = StringUtils.substringAfterLast(messagePath, ".jar!/");
                }
                replacedBasenames.add("classpath:"+messagePath);
              }
            }else{
              String messagePath = StringUtils.substringBetween(path, "target/classes/", ".properties");
              replacedBasenames.add("classpath:"+messagePath);
            }
          }
        }

      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    baseNames = replacedBasenames.toArray(new String[0]);
    return baseNames;
  }

  private Locale getDefaultLocale(){
    return new Locale(defaultLocale);
  }

}
