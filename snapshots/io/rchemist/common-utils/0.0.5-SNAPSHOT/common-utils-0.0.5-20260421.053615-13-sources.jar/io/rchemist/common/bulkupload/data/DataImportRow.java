/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.bulkupload.data;

import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.LocalDateUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class DataImportRow implements Serializable {

  public DataImportRow() {
  }

  public DataImportRow(Map<String, DataImportProperty> properties) {
    this.properties = properties;
  }

  public DataImportRow(List<DataImportProperty> properties) {
    if (CollectionUtils.isNotEmpty(properties)) {
      properties.forEach(p -> {
        this.properties.put(p.getName(), p);
      });
    }
  }

  public static DataImportRow create(){
    return new DataImportRow();
  }

  protected Map<String, DataImportProperty> properties = new LinkedHashMap<>();

  public DataImportRow addProperty(String name, String value){
    DataImportProperty property = new DataImportProperty(name, value);
    properties.put(name, property);
    return this;
  }

  public String getStringValue(String name){
    return getStringValue(name, "");
  }

  public String getStringValue(String name, String defaultValue){
    if(properties.containsKey(name)){
      return StringUtil.toString(properties.get(name).getValue(), defaultValue);
    }
    return defaultValue;
  }

  public boolean hasProperties() {
    return MapUtils.isNotEmpty(properties);
  }

  public boolean hasValue(String name) {
    return MapUtils.isNotEmpty(this.properties) && this.properties.containsKey(name);
  }

  public Object getObjectValue(String name) {
    if(properties.containsKey(name)){
      return properties.get(name).getValue();
    }
    return null;
  }

  public String[] getArrayValue(String name) {
    Object value = getObjectValue(name);
    if (value == null) {
      return null;
    }

    if (value.getClass().isArray()) {
      int length = Array.getLength(value);
      String[] result = new String[length];
      for (int i = 0; i < length; i++) {
        Object element = Array.get(value, i);
        result[i] = StringUtil.toString(element);
      }
      return result;
    } else if (value instanceof Collection) {
      Collection collection = (Collection) value;
      String[] result = new String[collection.size()];
      int i = 0;
      for (Object element : collection) {
        result[i] = StringUtil.toString(element);
        i++;
      }
      return result;
    }

    // 배열이 아닌 경우 단일 요소 배열로 반환
    return new String[]{String.valueOf(value)};
  }

  public <T> T[] getArrayValue(DataImportFieldType type, String name) {
    Object value = getObjectValue(name);
    if (value == null) {
      return null;
    }

    if (value.getClass().isArray()) {
      int length = Array.getLength(value);
      T[] result = (T[]) Array.newInstance(type.getTypeClass(), length);
      for (int i = 0; i < length; i++) {
        Object element = Array.get(value, i);
        result[i] = castValue(type, StringUtil.toString(element));
      }
      return result;
    } else if (value instanceof Collection) {
      Collection collection = (Collection) value;
      T[] result = (T[]) Array.newInstance(type.getTypeClass(), collection.size());
      int i = 0;
      for (Object element : collection) {
        result[i] = castValue(type, StringUtil.toString(element));
        i++;
      }
      return result;
    }

    // 배열이 아닌 경우 단일 요소 배열로 만들어 반환
    T[] single = (T[]) Array.newInstance(type.getTypeClass(), 1);
    single[0] = castValue(type, StringUtil.toString(value));
    return single;
  }

  public <T> T getValue(DataImportFieldType type, String name) {
    return getValue(type, name, null);
  }

  @SuppressWarnings("unchecked")
  public <T> T getValue(DataImportFieldType type, String name, T defaultValue) {
    String value = getStringValue(name, null);
    return value == null ? defaultValue : castValue(type, value);
  }

  private <T> T castValue(DataImportFieldType type, String value) {
    if (value == null)
      return null;

    try {
      return switch (type) {
        case STRING -> (T) value;
        case INTEGER -> (T) NumberUtil.getInteger(value);
        case DOUBLE -> (T) NumberUtil.getDouble(value);
        case BOOLEAN -> (T) BooleanUtils.toBooleanObject(value);
        case LONG -> (T) NumberUtil.getLong(value);
        case BIG_DECIMAL -> (T) NumberUtil.getBigDecimal(value);
        case INSTANT -> (T) InstantUtil.parse(value);
        case LOCAL_DATE -> (T) LocalDateUtil.parse(value);
        case LOCAL_DATETIME -> (T) LocalDateTimeUtil.parse(value);
      };
    }catch (Exception e) {
      return null;
    }
  }

  public <T> List<T> getListValue(DataImportFieldType type, String name) {
    T[] values = getArrayValue(type, name);
    return (values == null || ArrayUtils.isEmpty(values)) ? null : List.of(values);
  }

}
