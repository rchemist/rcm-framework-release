/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@EqualsAndHashCode
public class SimplePeriodDTO implements Serializable {

  private static final String SPLIT_CODE = " ~ ";

  public SimplePeriodDTO(LocalDateTime availableAt, LocalDateTime availableUntil) {
    this.availableAt = availableAt;
    this.availableUntil = availableUntil;
  }

  private final LocalDateTime availableAt;

  private final LocalDateTime availableUntil;

  @Override
  public String toString(){
    return StringUtil.merge(availableAt.toString(), SPLIT_CODE, availableUntil.toString());
  }

}
