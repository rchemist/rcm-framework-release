/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.exception;

import io.rchemist.common.exception.ErrorTypeRuntimeException;
import io.rchemist.common.exception.error.ErrorType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PlatformSecurityException extends ErrorTypeRuntimeException {

  public PlatformSecurityException(ErrorType errorType) {
    super(errorType);
  }

  public PlatformSecurityException(ErrorType errorType,
      Throwable cause) {
    super(errorType, cause);
  }

  public PlatformSecurityException(ErrorType errorType, String message) {
    super(errorType, message);
  }

  public PlatformSecurityException(String message, Throwable cause) {
    super(message, cause);
  }

  public PlatformSecurityException(String message) {
    super(message);
  }

  public PlatformSecurityException(String propertyName, ErrorType errorType) {
    super(propertyName, errorType);
  }

  public PlatformSecurityException(String propertyName, String message) {
    super(propertyName, message);
  }

}
