/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class VersionDTO implements Serializable {

  public VersionDTO(Long count, LocalDateTime createdAt) {
    this.count = count;
    this.createdAt = createdAt;
  }

  public VersionDTO(Long count, LocalDateTime createdAt, LocalDateTime updatedAt) {
    this.count = count;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
  }

  public VersionDTO(Long count, LocalDateTime createdAt, LocalDateTime updatedAt, Long subCollectionMaxId, LocalDateTime subCollectionCreatedAt) {
    this.count = count;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
    this.subCollectionMaxId = subCollectionMaxId;
    this.subCollectionCreatedAt = subCollectionCreatedAt;
  }

  public VersionDTO(Long count, LocalDateTime createdAt, LocalDateTime updatedAt, Long subCollectionMaxId, LocalDateTime subCollectionCreatedAt, LocalDateTime subCollectionUpdatedAt) {
    this.count = count;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
    this.subCollectionMaxId = subCollectionMaxId;
    this.subCollectionCreatedAt = subCollectionCreatedAt;
    this.subCollectionUpdatedAt = subCollectionUpdatedAt;
  }

  private final Long count;
  @Getter
  private final LocalDateTime createdAt;

  private LocalDateTime updatedAt;

  private Long subCollectionMaxId;
  private LocalDateTime subCollectionCreatedAt;
  private LocalDateTime subCollectionUpdatedAt;

  private LocalDateTime getUpdatedAt() {
    return (updatedAt == null) ? createdAt : updatedAt;
  }

  @Override
  public String toString(){

    if(count == 0L && createdAt == null && updatedAt == null && subCollectionMaxId == null && subCollectionCreatedAt == null && subCollectionUpdatedAt == null){
      return "0";
    }

    StringBuilder sb = new StringBuilder();

    sb.append(count)
      .append("-")
      .append(createdAt)
      .append("-")
      .append(getUpdatedAt());

    if(subCollectionCreatedAt != null){
      sb.append("-")
        .append(subCollectionCreatedAt);
    }

    if(subCollectionUpdatedAt != null){
      sb.append("-")
        .append(subCollectionUpdatedAt);
    }

    if(subCollectionMaxId != null){
      sb.append("-")
          .append(subCollectionMaxId);
    }

    return String.valueOf(sb.toString().hashCode());
  }

}
