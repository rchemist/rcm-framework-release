/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.lang3.ObjectUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ObjectUtil {

  public static boolean isSameClassAssignable(Object... values) {
    boolean equals = ObjectUtils.allNotNull(values);
    if (equals) {
      Class<?> clazz = null;
      for (Object obj : values) {
        if (clazz == null) {
          clazz = obj.getClass();
        } else {
          return clazz.isAssignableFrom(obj.getClass());
        }
      }
    }
    return equals;
  }

  public static boolean equals(Object one, Object other) {

    if(one == other)
      return true;

    if((one == null && other != null) || (one != null && other == null))
      return false;

    return one.equals(other);

  }
}
