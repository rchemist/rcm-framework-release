/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.type.TimePeriodType;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class InstantUtil {

  public static Instant parse(String instant) {
    if(StringUtils.isEmpty(instant))
      return null;

    if (instant.length() == 10) {
      // yyyy-MM-dd 일 때
      LocalDate localDate = LocalDateUtil.parse(instant);
      return localDate == null ? null : localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
    }

    return Instant.parse(instant);
  }


  /**
   * 검색 필터값으로 사용될 때 until 이 true 면 두번째 날짜라는 뜻이고, 해당 날짜의 23:59:59 로 설정해야 한다.
   * @param instant
   * @param until
   * @return
   */
  public static Instant parse(String instant, boolean until) {
    return parse(instant, until, null);
  }


  public static Instant parse(String instant, boolean until, Instant defaultValue) {
    if(StringUtils.isEmpty(instant))
      return defaultValue;

    Instant value;

    if (instant.length() == 10) {
      // yyyy-MM-dd 일 때 검색 값인 경우 until 여부에 따라 시작일인지 종료일인지 판단해야 한다.
      LocalDate localDate = LocalDateUtil.parse(instant);
      value = localDate == null ? null :
          until ? localDate.atStartOfDay(ZoneId.systemDefault()).plusDays(1).minusSeconds(1).toInstant()
              : localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
      ;
    } else {
      value = Instant.parse(instant);
    }

    return value;

  }



  public static Instant parse(String instant, Instant defaultValue) {
    if(StringUtils.isEmpty(instant))
      return defaultValue;
    return Instant.parse(instant);
  }

  public static Instant parse(String instant, String format) {
    if(StringUtils.isEmpty(instant))
      return null;
    if(StringUtils.isEmpty(format))
      format = "yyyy-MM-dd HH:mm:ss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return LocalDateTime.parse(instant, formatter).atZone(ZoneId.systemDefault()).toInstant();
  }

  public static Instant parse(String instant, String format, Instant defaultValue) {
    if(StringUtils.isEmpty(instant))
      return defaultValue;
    if(StringUtils.isEmpty(format))
      format = "yyyy-MM-dd HH:mm:ss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return LocalDateTime.parse(instant, formatter).atZone(ZoneId.systemDefault()).toInstant();
  }

  public static Instant parse(String instant, String format, ZoneId zoneId) {
    if(StringUtils.isEmpty(instant))
      return null;
    if(StringUtils.isEmpty(format))
      format = "yyyy-MM-dd HH:mm:ss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return LocalDateTime.parse(instant, formatter).atZone(zoneId).toInstant();
  }

  public static Instant parse(String instant, String format, ZoneId zoneId, Instant defaultValue) {
    if(StringUtils.isEmpty(instant))
      return defaultValue;
    if(StringUtils.isEmpty(format))
      format = "yyyy-MM-dd HH:mm:ss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return LocalDateTime.parse(instant, formatter).atZone(zoneId).toInstant();
  }

  public static Instant parse(String instant, DateTimeFormatter formatter) {
    if(StringUtils.isEmpty(instant))
      return null;
    return LocalDateTime.parse(instant, formatter).atZone(ZoneId.systemDefault()).toInstant();
  }

  public static Instant parse(Object instant) {
    if(instant == null)
      return null;
    if(instant instanceof Instant)
      return (Instant) instant;
    if(instant instanceof LocalDateTime)
      return ((LocalDateTime) instant).atZone(ZoneId.systemDefault()).toInstant();
    if(instant instanceof LocalDate)
      return ((LocalDate) instant).atStartOfDay(ZoneId.systemDefault()).toInstant();
    if(instant instanceof Date)
      return ((Date) instant).toInstant();
    if(instant instanceof Long)
      return Instant.ofEpochMilli((Long) instant);
    if(instant instanceof String)
      return parse((String) instant);
    return null;
  }

  public static Instant parse(Object instant, Instant defaultValue) {
    if(instant == null)
      return defaultValue;
    if(instant instanceof Instant)
      return (Instant) instant;
    if(instant instanceof LocalDateTime)
      return ((LocalDateTime) instant).atZone(ZoneId.systemDefault()).toInstant();
    if(instant instanceof LocalDate)
      return ((LocalDate) instant).atStartOfDay(ZoneId.systemDefault()).toInstant();
    if(instant instanceof Date)
      return ((Date) instant).toInstant();
    if(instant instanceof Long)
      return Instant.ofEpochMilli((Long) instant);
    if(instant instanceof String)
      return parse((String) instant);
    return defaultValue;
  }

  public static Instant parseStartOfDayIfAbsentTime(Object instant) {
    if (instant == null)
      return null;
    String value = String.valueOf(instant);
    if (value.length() <= 10) {
      return parseStartOfDay(value);
    }
    return parse(instant);
  }

  public static Instant parseEndOfDayIfAbsentTime(Object instant) {
    if (instant == null)
      return null;
    String value = String.valueOf(instant);
    if (value.length() <= 10) {
      return parseEndOfDay(value);
    }
    return parse(instant);
  }

  public static Instant parseStartOfDay(Object instant) {
    Instant value = parse(instant);
    return value == null ? null : getStartOfDay(value);
  }

  public static Instant parseEndOfDay(Object instant) {
    Instant value = parse(instant);
    return value == null ? null : getEndOfDay(value);
  }


  public static Date getDate(Instant instant) {
    if (instant == null)
      return new Date();    // null safe

    return Date.from(instant);
  }

  /**
   * 기준 날짜가 1년 중 몇주차인지
   *
   * @param dateTime
   * @return
   */
  public static int getWeekOfYear(Instant dateTime) {
    LocalDateTime localDateTime = dateTime.atZone(ZoneId.systemDefault()).toLocalDateTime();
    return LocalDateTimeUtil.getWeekOfYear(localDateTime);
  }

  /**
   * 기준 일자가 속한 주의 첫날(일요일) 반환
   *
   * @param dateTime
   * @return
   */
  public static Instant getFirstDayOfWeek(Instant dateTime) {
    LocalDateTime localDateTime = dateTime.atZone(ZoneId.systemDefault()).toLocalDateTime();
    // BUG-037 fix (0.1.1.G): LocalDateTime has no zone/offset so Instant.from(LocalDateTime)
    // fails with DateTimeException. Convert via ZonedDateTime to obtain a valid Instant.
    LocalDateTime firstDay = LocalDateTimeUtil.getFirstDayOfWeek(localDateTime);
    return firstDay.atZone(ZoneId.systemDefault()).toInstant();
  }

  /**
   * 두 날짜가 같은 년도, 같은 월, 같은 일 인지 TimePeriodType 에 따라 확인
   *
   * @param date1
   * @param date2
   * @param timePeriodType
   * @return
   */
  public static boolean isSamePeriod(Instant date1, Instant date2, TimePeriodType timePeriodType) {
    if (date1 == null && date2 == null || (date1 == null && date2 != null || date1 != null && date1 == null)) {
      return false;
    } else {
      LocalDateTime localDateTime1 = date1.atZone(ZoneId.systemDefault()).toLocalDateTime();
      LocalDateTime localDateTime2 = date2.atZone(ZoneId.systemDefault()).toLocalDateTime();
      return LocalDateTimeUtil.isSamePeriod(localDateTime1, localDateTime2, timePeriodType);
    }
  }


  public static LocalDateTime getLocalDateTime(Instant instant) {
    return getLocalDateTime(instant, null, null);
  }

  public static LocalDateTime getLocalDateTime(Instant instant, LocalDateTime defaultValue) {
    return getLocalDateTime(instant, defaultValue, null);
  }

  public static LocalDateTime getLocalDateTime(Instant instant, LocalDateTime defaultValue, ZoneId zoneId) {
    if (instant == null)
      return defaultValue;
    if (zoneId == null) {
      zoneId = ZoneId.systemDefault();
    }
    return instant.atZone(zoneId).toLocalDateTime();
  }

  public static Instant asInstant(Date date) {
    return Instant.ofEpochMilli(date.getTime());
  }

  public static Instant asInstant(LocalDate localDate) {
    if (localDate == null)
      return null;
    return localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
  }

  public static Instant asInstant(LocalDateTime localDateTime) {
    return asInstant(localDateTime, null);
  }

  public static Instant asInstant(LocalDateTime localDateTime, Instant defaultValue) {
    if (localDateTime == null)
      return defaultValue;
    return localDateTime.atZone(ZoneId.systemDefault()).toInstant();
  }

  public static Instant getEndOfMonth(Instant instant) {
    if (instant == null)
      return null;

    // Instant를 ZonedDateTime으로 변환
    ZonedDateTime zonedDateTime = instant.atZone(ZoneId.systemDefault());

    // ZonedDateTime을 해당 달의 마지막 날의 끝 시간으로 설정
    ZonedDateTime endOfMonth = zonedDateTime
        .withDayOfMonth(zonedDateTime.toLocalDate().lengthOfMonth())
        .with(LocalTime.MAX);

    // ZonedDateTime을 Instant로 다시 변환
    return endOfMonth.toInstant();
  }


  public static boolean isBetween(Instant availableAt, Instant availableUntil) {
    // 현재 날짜와의 비교
    return isBetween(availableAt, availableUntil, null, true);
  }

  public static boolean isBetween(Instant availableAt, Instant availableUntil, boolean defaultValue) {
    // 현재 날짜와의 비교
    return isBetween(availableAt, availableUntil, null, defaultValue);
  }

  public static boolean isBetween(Instant availableAt, Instant availableUntil, Instant compareDate, boolean defaultValue) {
    if (availableAt == null && availableUntil == null) {
      return defaultValue;
    } else {
      Instant now = (compareDate == null) ? Instant.now() : compareDate;
      if (availableAt != null && availableUntil == null) {
        return availableAt.isBefore(now);
      } else if (availableAt == null && availableUntil != null) {
        return availableUntil.isAfter(now);
      }

      // 현재 시각이 AvailableAt 과 AvailableUntil 사이에 있는지 확인
      return availableAt.isBefore(now) && availableUntil.isAfter(now);
    }
  }

  public static Instant getStartOfDay(Instant day) {
    day = (day == null) ? Instant.now() : day;
    return day.truncatedTo(ChronoUnit.DAYS);
  }

  public static Instant getEndOfDay(Instant day) {
    day = (day == null) ? Instant.now() : day;
    return day.plus(1, ChronoUnit.DAYS).truncatedTo(ChronoUnit.DAYS).minus(1, ChronoUnit.MILLIS);
  }

  public static Instant getEndOfMonthDay(Instant day) {
    day = (day == null) ? Instant.now() : day;
    // BUG-038 fix (0.1.1.G): Instant does not support LocalTime fields (NanoOfDay), so the
    // previous `endOfMonth.with(LocalTime.MAX)` call raised UnsupportedTemporalTypeException.
    // `getEndOfMonth(day)` already returns the last day at 23:59:59.999, which satisfies the
    // intended "end of month day" contract.
    return getEndOfMonth(day);
  }

  public static LocalDateTime getEndOfYearDay(LocalDateTime day){
    day = (day == null) ? LocalDateTime.now() : day;
    LocalDate endOfYear = day.toLocalDate().with(TemporalAdjusters.lastDayOfYear());
    return endOfYear.atTime(LocalTime.MAX);
  }


  public static boolean hasElapsed(Instant dateTime, int minute) {
    return hasElapsed(dateTime, Instant.now(), minute);
  }

  public static boolean hasElapsedHours(Instant dateTime, int hours) {
    return hasElapsedHours(dateTime, Instant.now(), hours);
  }

  public static boolean hasElapsedYears(Instant dateTime, int years) {
    return hasElapsedYears(dateTime, Instant.now(), years);
  }

  public static boolean hasElapsedDays(Instant dateTime, int days) {
    return hasElapsedDays(dateTime, Instant.now(), days);
  }

  public static boolean hasElapsedMonths(Instant dateTime, int months) {
    return hasElapsedMonths(dateTime, Instant.now(), months);
  }

  public static boolean hasElapsedSeconds(Instant dateTime, int seconds) {
    if (dateTime == null)
      return true;
    return dateTime.plusSeconds(seconds).isBefore(Instant.now());
  }

  public static boolean hasElapsed(Instant dateTime, Instant compareDate, int minute) {
    if (dateTime == null)
      return true;
    LocalDateTime localDateTime = getLocalDateTime(dateTime);
    LocalDateTime compareDateTime = getLocalDateTime(compareDate);
    return LocalDateTimeUtil.hasElapsed(localDateTime, compareDateTime, minute);
  }

  public static boolean hasElapsedHours(Instant dateTime, Instant compareDate, int hours) {
    if (dateTime == null)
      return true;
    LocalDateTime localDateTime = getLocalDateTime(dateTime);
    LocalDateTime compareDateTime = getLocalDateTime(compareDate);
    return LocalDateTimeUtil.hasElapsedHours(localDateTime, compareDateTime, hours);
  }

  public static boolean hasElapsedYears(Instant dateTime, Instant compareDate, int years) {
    if (dateTime == null)
      return true;
    LocalDateTime localDateTime = getLocalDateTime(dateTime);
    LocalDateTime compareDateTime = getLocalDateTime(compareDate);
    return LocalDateTimeUtil.hasElapsedYears(localDateTime, compareDateTime, years);
  }

  public static boolean hasElapsedDays(Instant dateTime, Instant compareDate, int days) {
    if (dateTime == null)
      return true;
    LocalDateTime localDateTime = getLocalDateTime(dateTime);
    LocalDateTime compareDateTime = getLocalDateTime(compareDate);
    return LocalDateTimeUtil.hasElapsedDays(localDateTime, compareDateTime, days);
  }

  public static boolean hasElapsedMonths(Instant dateTime, Instant compareDate, int months) {
    if (dateTime == null)
      return true;
    LocalDateTime localDateTime = getLocalDateTime(dateTime);
    LocalDateTime compareDateTime = getLocalDateTime(compareDate);
    return LocalDateTimeUtil.hasElapsedMonths(localDateTime, compareDateTime, months);
  }

  public static boolean hasElapsedSeconds(Instant dateTime, Instant compareDate, int seconds) {
    if (dateTime == null)
      return true;
    return dateTime.plusSeconds(seconds).isBefore(compareDate);
  }

  public static Instant toInstant(Calendar calendar) {
    if (calendar == null) {
      return null;
    }
    TimeZone tz = calendar.getTimeZone();
    ZoneId zid = tz == null ? ZoneId.systemDefault() : tz.toZoneId();
    return Instant.from(calendar.toInstant().atZone(zid));
  }

  public static String getTimeAgo(Instant lastDate) {
    return getTimeAgo(lastDate, null, null);
  }

  public static String getTimeAgo(Instant lastDate, Instant compareDate, String timeFormat) {
    if(lastDate == null)
      return "";

    if(compareDate == null)
      compareDate = Instant.now();

    if(InstantUtil.hasElapsedDays(lastDate, compareDate, 1)){
      // 하루 이상 지났으면
      return format(lastDate);
    }else{

      Duration duration = Duration.between(compareDate, lastDate);

      if(InstantUtil.hasElapsedHours(lastDate, compareDate, 1)){
        return format(lastDate, "HH:mm") + " (" + Math.abs(duration.toHours()) + " 시간 전)";
      }else{
        return format(lastDate, "HH:mm") + " (" + Math.abs(duration.toMinutes()) + " 분 전)";
      }

    }
  }

  public static Instant getStartOfMonthDay(Instant compareDate) {
    // Instant를 LocalDate로 변환하여 년도와 월을 얻습니다.
    LocalDate localDate = compareDate.atZone(ZoneId.systemDefault()).toLocalDate();

    // 해당 월의 첫 번째 날짜를 계산합니다.
    LocalDate startOfMonth = LocalDate.of(localDate.getYear(), localDate.getMonth(), 1);

    // 해당 월의 첫 번째 날짜를 Instant로 변환하여 리턴합니다.
    return startOfMonth.atStartOfDay(ZoneId.systemDefault()).toInstant();
  }

  public static boolean isBefore(Instant availableAt, Instant compareDate) {
    if(availableAt == null)
      return (compareDate != null);
    if(compareDate == null)
      return false;
    return availableAt.isBefore(compareDate);
  }

  public static Instant getStartOfYearDay(Instant compareDate) {
    // Instant를 LocalDate로 변환하여 년도를 얻습니다.
    LocalDate localDate = compareDate.atZone(ZoneId.systemDefault()).toLocalDate();

    // 해당 년도의 1월 1일을 계산합니다.
    LocalDate startOfYear = LocalDate.of(localDate.getYear(), 1, 1);

    // 해당 년도의 1월 1일을 Instant로 변환하여 리턴합니다.
    return startOfYear.atStartOfDay(ZoneId.systemDefault()).toInstant();
  }

  /**
   * 앞의 시작일, 종료일이 뒤의 시작일 종료일과 서로 겹치는 구간이 있는지
   * @param availableAt
   * @param availableUntil
   * @param startDate
   * @param endDate
   * @return
   */
  public static boolean isDuplicatedPeriod(Instant availableAt, Instant availableUntil, Instant startDate, Instant endDate) {

    // validate values
    Instant now = Instant.now();
    if(availableAt == null)
      availableAt = now;

    if(startDate == null)
      startDate = now;

    if(availableUntil == null)
      availableUntil = Instant.MAX;

    if(endDate == null)
      endDate = Instant.MAX;

    if(isBetween(startDate, endDate, availableAt, false)){
      // availableAt이 startDate 와 endDate 사이에 있을 때
      return true;
    }

    // availableAt이 startDate 와 endDate 사이에 있을 때
    return isBetween(startDate, endDate, availableUntil, false);

  }

  public static boolean equals(Instant date1, Instant date2) {
    if(date1 == null){
      return date2 == null;
    }else{
      if(date2 == null){
        return false;
      }
    }
    return date1.equals(date2);
  }

  public static String format(Instant date) {
    return date == null ? "" : format(date, null);
  }

  public static String format(Instant date, String format) {
    return format(date, format, ZoneId.systemDefault());
  }

  public static String format(Instant date, String format, ZoneId zoneId) {
    if (date == null)
      return "";
    if (format == null)
      format = "yyyy-MM-dd HH:mm:ss";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
    return formatter.format(date.atZone(zoneId));
  }


  public static Instant getInstant(Object value){
    return getInstant(value, null);
  }
  public static Instant getInstant(Object value, Instant defaultValue) {
    if(value == null)
      return defaultValue;

    Instant instant;

    if(value instanceof LocalDateTime localDateTime){
      instant = localDateTime.atZone(ZoneId.systemDefault()).toInstant();
    }else if(value instanceof Date date){
      instant = date.toInstant();
    }else if(value instanceof Long){
      instant = Instant.ofEpochMilli((Long) value);
    }else{
      String str = String.valueOf(value);
      if(StringUtils.isNumeric(str)) {
        instant = Instant.ofEpochMilli(Long.parseLong(str));
      } else {
        instant = Instant.parse(str);
      }
    }

    return (instant == null) ? defaultValue : instant;

  }

  public static Instant plusYears(Instant instant, long years) {
    if(instant == null)
      return null;
    return instant.plus(years, ChronoUnit.YEARS);
  }

  public static Instant plusMonths(Instant instant, long months) {
    if(instant == null)
      return null;
    return instant.plus(months, ChronoUnit.MONTHS);
  }

  public static Instant plusDays(Instant instant, long days) {
    if(instant == null)
      return null;
    return instant.plus(days, ChronoUnit.DAYS);
  }

  public static Instant plusHours(Instant instant, long hours) {
    if(instant == null)
      return null;
    return instant.plus(hours, ChronoUnit.HOURS);
  }

  public static Instant plusMinutes(Instant instant, long minutes) {
    if(instant == null)
      return null;
    return instant.plus(minutes, ChronoUnit.MINUTES);
  }

  public static Instant plusSeconds(Instant instant, long seconds) {
    if(instant == null)
      return null;
    return instant.plus(seconds, ChronoUnit.SECONDS);
  }

  public static Instant plusMillis(Instant instant, long millis) {
    if(instant == null)
      return null;
    return instant.plus(millis, ChronoUnit.MILLIS);
  }

  public static Instant plusNanos(Instant instant, long nanos) {
    if(instant == null)
      return null;
    return instant.plus(nanos, ChronoUnit.NANOS);
  }

  public static Instant minusYears(Instant instant, long months) {
    if(instant == null)
      return null;
    return instant.minus(months, ChronoUnit.YEARS);
  }

  public static Instant minusMonths(Instant instant, long months) {
    if(instant == null)
      return null;
    return instant.minus(months, ChronoUnit.MONTHS);
  }

  public static Instant minusDays(Instant instant, long days) {
    if(instant == null)
      return null;
    return instant.minus(days, ChronoUnit.DAYS);
  }

  public static Instant minusHours(Instant instant, long hours) {
    if(instant == null)
      return null;
    return instant.minus(hours, ChronoUnit.HOURS);
  }

  public static Instant minusMinutes(Instant instant, long minutes) {
    if(instant == null)
      return null;
    return instant.minus(minutes, ChronoUnit.MINUTES);
  }

  public static Instant minusSeconds(Instant instant, long seconds) {
    if(instant == null)
      return null;
    return instant.minus(seconds, ChronoUnit.SECONDS);
  }

  public static Instant minusMillis(Instant instant, long millis) {
    if(instant == null)
      return null;
    return instant.minus(millis, ChronoUnit.MILLIS);
  }

  public static Instant minusNanos(Instant instant, long nanos) {
    if(instant == null)
      return null;
    return instant.minus(nanos, ChronoUnit.NANOS);
  }

  public static ZonedDateTime getZonedDateTime(Instant instant, String timezone) {
    if (StringUtils.isEmpty(timezone)) {
      timezone = ZoneId.systemDefault().toString();
    }
    try {
      return ZonedDateTime.ofInstant(instant, ZoneId.of(timezone));
    }catch (Exception e) {
      log.warn("Could not parse timezone, {}", timezone);
      return ZonedDateTime.ofInstant(instant, ZoneId.systemDefault());
    }
  }

  public static  ZonedDateTime getZonedDateTime(Instant instant, ZoneId zoneId) {
    if (instant == null)
      instant = Instant.now();
    return ZonedDateTime.ofInstant(instant, zoneId);
  }



}
