/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class EditorJsUtil {

  public static boolean isEditorJsContent(String content){
    try{
      GsonUtil.fromJson(content, EditorJsContent.class);
      return true;
    }catch (Exception e){

      if(StringUtils.isNotEmpty(content)){
        content = StringUtils.replaceEachRepeatedly(content, new String[]{"\r", "\n", " ", "\""}, new String[]{"", "", "", "'"});
        return (content.startsWith("{'time':"));
      }

      return false;
    }
  }

  public static String getSearchableContents(String editorJsContent) {

    try{
      EditorJsContent content = GsonUtil.fromJson(editorJsContent, EditorJsContent.class);
      return content == null ? editorJsContent : content.getSearchableText();
    }catch (Exception e){
      return HtmlUtil.removeTag(editorJsContent);
    }

  }

  @Getter
  @Setter
  public static class EditorJsContent implements Serializable{
    // defaultValue = "{\"time\":"+System.currentTimeMillis()+",\"blocks\":[{\"id\":\""+id+"\",\"type\":\"paragraph\",\"data\":{\"text\":\" \"}}],\"version\":\"2.24.3\"}\n";
    private Long time;
    private List<Block> blocks;
    private String version;

    public String getSearchableText(){
      if(CollectionUtils.isEmpty(blocks))
        return "";
      StringBuilder sb = new StringBuilder();
      for(Block block : blocks){
        sb.append(block.getSearchableText());
      }
      return sb.toString();
    }

  }

  @Getter
  @Setter
  public static class Block implements Serializable{

    private String type;
    private Map<String, String> data;

    public String getSearchableText(){
      if(MapUtils.isEmpty(data))
        return null;
      for(Entry<String, String> entry : data.entrySet()){
        if(entry.getKey().equals("text")){
          return entry.getValue();
        }
      }
      return null;
    }

  }
  /*
  {
    "time": 1656489331025,
    "blocks": [
        {
            "id": "aXEnw6C7z-",
            "type": "paragraph",
            "data": {
                "text": "미모의 베리 베이비시절 사진을 가져왔습니다"
            }
        },
        {
            "id": "NyMYUBYb2J",
            "type": "image",
            "data": {
                "urls": [
                    "/static-resource/CC165EA9-FA78-4A10-8BE2-69F6B252637B.png?assetKey=MQggde1a94510c&fileSize=1536244"
                ],
                "file": {
                    "url": "/static-resource/CC165EA9-FA78-4A10-8BE2-69F6B252637B.png?assetKey=MQggde1a94510c&fileSize=1536244"
                }
            }
        },
        {
            "id": "9UT3T_egL5",
            "type": "image",
            "data": {
                "urls": [
                    "/static-resource/1BC3FA2D-C954-4280-A8E8-D271D154BF8E.png?assetKey=4YOM04a9d0e61c&fileSize=1559784"
                ],
                "file": {
                    "url": "/static-resource/1BC3FA2D-C954-4280-A8E8-D271D154BF8E.png?assetKey=4YOM04a9d0e61c&fileSize=1559784"
                }
            }
        }
    ],
    "version": "2.23.2"
}
   */

}
