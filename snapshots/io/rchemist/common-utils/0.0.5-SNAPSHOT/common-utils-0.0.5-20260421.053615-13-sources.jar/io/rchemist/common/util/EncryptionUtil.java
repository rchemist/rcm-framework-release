/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class EncryptionUtil {

  private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
  private static final int KEY_LENGTH = 32; // 256-bit key
  private static final int IV_LENGTH = 16; // 128-bit IV

  private static final String DEFAULT_KEY = "RchemistMakeProblemEasy!";

  @Value("${platform.config.encrypt.key:}")
  public void setDefaultKey(final String defaultKey) {
    EncryptionUtil.defaultKey = StringUtil.toString(defaultKey, DEFAULT_KEY);
  }

  @Getter
  private static String defaultKey;

  public static String encryptAES256(String origin) throws Exception {
    if (StringUtils.isBlank(origin)) {
      throw new RuntimeException("origin str is blank");
    }

    if (StringUtils.isBlank(defaultKey)) {
      throw new RuntimeException("defaultKey is blank");
    }

    return encryptAES256(origin, defaultKey);
  }

  public static String decryptAES256(String encryptedString) throws Exception {
    if (StringUtils.isBlank(encryptedString)) {
      throw new RuntimeException("encryptedString is blank");
    }

    if (StringUtils.isBlank(defaultKey)) {
      throw new RuntimeException("defaultKey is blank");
    }

    return decryptAES256(encryptedString, defaultKey);
  }

  /**
   * AES 256 암호화
   * @param origin
   * @param key
   * @return
   * @throws Exception
   */
  public static String encryptAES256(String origin, String key) throws Exception{
    key = StringUtils.defaultIfBlank(key, defaultKey);
    String iv = get16byteIv(key);

    Cipher cipher = Cipher.getInstance(ALGORITHM);
    SecretKeySpec keySpec = getSecretKeySpec(key);
    IvParameterSpec ivParameterSpec = getIvParameterSpec(iv);
    cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParameterSpec);

    byte[] encrypted = cipher.doFinal(origin.getBytes(StandardCharsets.UTF_8));

    return Base64.getEncoder().encodeToString(encrypted);
  }


  /**
   * AES 256 복호화
   * @param encryptedString
   * @param key
   * @return
   * @throws Exception
   */
  public static String decryptAES256(String encryptedString, String key) throws Exception {

    key = StringUtils.defaultIfBlank(key, defaultKey);
    String iv = get16byteIv(key);

    Cipher cipher = Cipher.getInstance(ALGORITHM);
    SecretKeySpec keySpec = getSecretKeySpec(key);
    IvParameterSpec ivParameterSpec = getIvParameterSpec(iv);
    cipher.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);

    byte[] decodedBytes = Base64.getDecoder().decode(encryptedString);
    byte[] decrypted = cipher.doFinal(decodedBytes);

    return new String(decrypted, StandardCharsets.UTF_8);
  }

  private static String get16byteIv(String key){
    if(StringUtils.isEmpty(key)){
      return defaultKey.substring(0, 16);
    }
    if(key.length() == 16)
      return key;
    if(key.length() > 16)
      return key.substring(0, 16);
    return StringUtil.fill(key, "r", 16);
  }

  private static SecretKeySpec getSecretKeySpec(String key){
    byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
    SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
    return keySpec;
  }

  private static IvParameterSpec getIvParameterSpec(String iv) {
    byte[] ivBytes = iv.getBytes(StandardCharsets.UTF_8);
    IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);
    return ivParameterSpec;
  }

}
