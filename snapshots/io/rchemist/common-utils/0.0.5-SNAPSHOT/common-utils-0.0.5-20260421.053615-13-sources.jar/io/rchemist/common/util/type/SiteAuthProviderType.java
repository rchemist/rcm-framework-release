/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.StringUtil;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class SiteAuthProviderType extends EnumType<SiteAuthProviderType> {

  public static final SiteAuthProviderType GOOGLE = new SiteAuthProviderType(10, "GOOGLE", "google", "구글", "google"
    , "client_id", "client_secret"
  );
  public static final SiteAuthProviderType NAVER = new SiteAuthProviderType(20, "NAVER", "naver", "네이버", "naver"
      , "client_id", "client_secret"
  );
  public static final SiteAuthProviderType KAKAO = new SiteAuthProviderType(30, "KAKAO", "kakao", "카카오", "kakao"
      , "client_id", "client_secret"
  );
  public static final SiteAuthProviderType TWITTER = new SiteAuthProviderType(40, "TWITTER", "twitter", "트위터", "twitter"
    , "client_id", "client_secret"
  );
  public static final SiteAuthProviderType FACEBOOK = new SiteAuthProviderType(50, "FACEBOOK", "facebook", "페이스북", "facebook"
      , "client_id", "client_secret"
  );

  @Getter
  protected final LinkedHashMap<String, String> fields;

  public SiteAuthProviderType(int order, String type, String friendlyType,
      String description, String messageKey, String... fields) {
    super(order, type, friendlyType, description, messageKey);

    LinkedHashMap<String, String> fieldMap = new LinkedHashMap<>();
    if(ArrayUtils.isNotEmpty(fields)){
      for(String field : fields){
        List<String> fieldList = StringUtil.split(field, "::");
        if(fieldList.size() == 1){
          // 기본값이 없는 경우
          fieldMap.put(fieldList.get(0), "");
        }else{
          fieldMap.put(fieldList.get(0), fieldList.get(1));
        }
      }
    }

    this.fields = fieldMap;
  }

  public SiteAuthProviderType() {
    this.fields = new LinkedHashMap<>();
  }
}
