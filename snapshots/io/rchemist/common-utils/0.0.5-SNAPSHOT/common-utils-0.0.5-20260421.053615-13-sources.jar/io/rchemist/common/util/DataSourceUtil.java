/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 **/
public class DataSourceUtil {

  public static String fixJndiName(String jndiName) {
    return jndiName.startsWith("java:comp/env/") ? jndiName : "java:comp/env/" + jndiName;
  }

  public static DataSource jndiDataSource(String jndiName) {
    try {
      Context ctx = new InitialContext();

      DataSource dataSource = (DataSource) ctx.lookup(jndiName);
      ctx.close();
      return dataSource;

    } catch (NameNotFoundException e) {
      return null;

    } catch (NamingException e) {
      throw new IllegalArgumentException("JNDI error.", e);
    } catch (ClassCastException e) {
      throw new IllegalArgumentException("The JNDI resource is no data source.", e);
    }
  }

}
