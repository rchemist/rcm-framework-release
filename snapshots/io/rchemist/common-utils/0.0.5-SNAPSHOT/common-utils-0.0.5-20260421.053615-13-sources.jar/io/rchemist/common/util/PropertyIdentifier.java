/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.Serializable;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
public class PropertyIdentifier implements Serializable {

  private String prefix;
  private String key;
  private String value;

  @Builder
  private PropertyIdentifier(String key, String value, String[] declaredPrefix, String separator, String defaultPrefix) {
    String prefix = StringUtil.toString(StringUtils.substringBefore(key, separator), defaultPrefix);

    this.key = key;
    this.value = value;
    this.prefix = prefix;

    if (ArrayUtils.contains(declaredPrefix, prefix)) {
      this.key = StringUtils.substringAfter(key, separator);
    } else {
      // this.prefix = defaultPrefix;
    }
  }

  public boolean isBlankKey() {
    return StringUtils.isBlank(key);
  }

  public boolean isBlankPrefix() {
    return StringUtils.isBlank(prefix);
  }

  public void camelCaseToKey() {
    this.key = StringUtil.toUpperCamelCase(this.key, null);
  }

}
