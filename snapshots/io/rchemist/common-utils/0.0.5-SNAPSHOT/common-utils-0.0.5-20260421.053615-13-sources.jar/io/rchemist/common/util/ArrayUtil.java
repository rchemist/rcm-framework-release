/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ArrayUtil {

  public static <T> T[] makeArray(Class<T> clazz, int size) {
    T[] ts = (T[]) Array.newInstance(clazz, size);
    return ts;
  }

  public static <T> T[] addArrayValue(T[] array, T... value) {
    if(ArrayUtils.isEmpty(array))
      return make(value);

    if(ArrayUtils.isEmpty(value))
      return array;

    List<T> origin = CollectionUtil.list(array);
    origin.addAll(CollectionUtil.list(value));

    final T[] returnArray = (T[]) Array.newInstance(array[0].getClass(), origin.size());

    int i = 0;
    Iterator<T> iterator = origin.iterator();
    while (iterator.hasNext()) {
      returnArray[i++] = iterator.next();
    }

    return returnArray;
  }

  public static <T> T[] addArray(T[] array, T... value) {
    if(ArrayUtils.isEmpty(array))
      return make(value);
    return addArrayValue(array, value);
  }

  public static <T> T[] make(T... t) {
    T[] ts = (T[]) makeArray(t[0].getClass(), t.length);
    int i = 0;
    for (T element : t) {
      ts[i] = element;
      i++;
    }
    return ts;
  }

  public static <T> T[] toArray(Class<T> clazz, Collection<T> collections){
    return collections.toArray(makeArray(clazz, collections.size()));
  }

  public static <T> boolean isSameLength(T[]... arr){
    if(ArrayUtils.isEmpty(arr)){
      return false;
    }
    int prevLength = -1;
    for(T[] array : arr){
      if(prevLength > -1){
        if(array == null || prevLength != array.length) return false;
      }
      prevLength = array.length;
    }
    return true;
  }

  public static <T> boolean contains(T[] array, T... objects) {
    if(ArrayUtils.isEmpty(array))
      return false;

    for(T object : array){
      if(ArrayUtils.contains(objects, object)){
        return true;
      }
    }
    return false;
  }

  public static String[] merge(String[] array, String[] added) {
    if(array == null || array.length == 0)
      return added;

    if(added == null || added.length == 0)
      return array;

    List<String> list = CollectionUtil.list(array);
    list.addAll(CollectionUtil.list(added));
    LinkedHashSet<String> set = new LinkedHashSet<>(list);

    return set.toArray(new String[0]);
  }

  public static <T> T[] addToArray(boolean nonDuplicate, T[] array, T... added) {
    if (added == null || added.length == 0) {
      return array;
    }

    if (array == null || array.length == 0) {
      return added;
    }

    List<T> list = new ArrayList<>(Arrays.asList(array));

    if (nonDuplicate) {
      for (T add : added) {
        if (!list.contains(add)) {
          list.add(add);
        }
      }
    } else {
      list.addAll(Arrays.asList(added));
    }

    return list.toArray(Arrays.copyOf(array, list.size()));
  }

  public static <T> T[] addToArray(T[] array, T... added) {
    return addToArray(false, array, added);
  }

  public static <T> T[] addToArray(boolean nonDuplicate, T[] array, Collection<T> added) {
    return addToArray(nonDuplicate, array, added.toArray(Arrays.copyOf(array, 0)));
  }

  public static <T> T[] addToArray(T[] array, Collection<T> added) {
    return addToArray(false, array, added);
  }


  // Remove methods
  public static <T> T[] removeFromArray(T[] array, T... removed) {
    if (array == null || array.length == 0 || removed == null || removed.length == 0) {
      return array;
    }

    List<T> list = new ArrayList<>(Arrays.asList(array));
    list.removeAll(Arrays.asList(removed));

    return list.toArray(Arrays.copyOf(array, list.size()));
  }

  public static <T> T[] removeFromArray(T[] array, Collection<T> removed) {
    return removeFromArray(array, removed.toArray(Arrays.copyOf(array, 0)));
  }

  // Sort methods
  public static <T extends Comparable<? super T>> T[] sortArray(T[] array) {
    if (array == null || array.length == 0) {
      return array;
    }

    List<T> list = new ArrayList<>(Arrays.asList(array));
    Collections.sort(list);

    return list.toArray(Arrays.copyOf(array, list.size()));
  }

  // Contains methods
  public static <T> boolean contains(T[] array, T value) {
    if (array == null || array.length == 0) {
      return false;
    }
    return Arrays.asList(array).contains(value);
  }

  public static <T> boolean containsAny(T[] array, T... values) {
    if (array == null || array.length == 0 || values == null || values.length == 0) {
      return false;
    }
    return Arrays.stream(array).anyMatch(arr -> Arrays.asList(values).contains(arr));
  }


  public static <T> T getFirstElement(T[] files) {
    return files != null && files.length > 0 ? files[0] : null;
  }
}
