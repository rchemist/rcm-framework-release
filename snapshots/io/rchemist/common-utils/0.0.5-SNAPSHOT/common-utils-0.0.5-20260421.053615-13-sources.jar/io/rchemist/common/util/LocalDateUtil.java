/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class LocalDateUtil {

  public static final DateTimeFormatter DEFAULT_FORMAT = DateTimeFormatter.ISO_DATE;

  /**
   * yyyy-MM-dd 형태의 문자열을 LocalDate 으로 변환한다.
   * @param date
   * @return
   */
  public static LocalDate parse(String date) {
    return parse(date, null);
  }

  public static LocalDate parse(String date, LocalDate defaultValue) {
    return parse(date, defaultValue, DEFAULT_FORMAT);
  }

  public static LocalDate parse(String date, LocalDate defaultValue, DateTimeFormatter... formatter) {

    if (StringUtils.isEmpty(date)) {
      return defaultValue;
    }

    for (DateTimeFormatter format : formatter) {
      try {
        return LocalDate.parse(date, format);
      } catch (Exception e) {
        // nothing
      }
    }
    return defaultValue;

  }

  public static String format(LocalDate date) {
    return format(date, false);
  }

  public static String format(LocalDate date, boolean digitOnly) {
    if(digitOnly)
      return format(date, DateTimeFormatter.ofPattern("yyyyMMdd"));
    return format(date, DEFAULT_FORMAT);
  }

  public static String format(LocalDate date, DateTimeFormatter formatter) {
    return (date == null) ? null : date.format(formatter);
  }

  public static String format(String date){
    // 8 자리 숫자를 yyyy-MM-dd 로 바꾼다.
    if(StringUtils.isEmpty(date))
      return date;

    LocalDate localDate;
    if(date.length() == 8){
      localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyyMMdd"));
    }else{
      localDate = parse(date);
    }
    return localDate.toString();
  }

  public static int getDaysDifference(LocalDate dateAt, LocalDate dateAtUntil) {
    if(dateAt == null || dateAtUntil == null)
      return 0;

    return NumberUtil.getInteger(ChronoUnit.DAYS.between(dateAt, dateAtUntil));
  }

  public static List<String> getBetweenDatesToString(LocalDate dateAt, LocalDate dateAtUntil) {
    List<LocalDate> dates = getBetweenDates(dateAt, dateAtUntil);

    if(CollectionUtils.isEmpty(dates))
      return null;

    List<String> dateStrings = new ArrayList<>();
    for(LocalDate date : dates){
      dateStrings.add(date.toString());
    }

    return dateStrings;
  }

  public static List<LocalDate> getBetweenDates(LocalDate dateAt, LocalDate dateAtUntil) {
    List<LocalDate> betweenDates = new ArrayList<>();

    if(dateAt == null && dateAtUntil == null)
      return null;

    if(dateAt == null && dateAtUntil != null){
      betweenDates.add(dateAtUntil);
      return betweenDates;
    }else if((dateAt != null && dateAtUntil == null) || dateAt.isEqual(dateAtUntil)){
      betweenDates.add(dateAt);
      return betweenDates;
    }

    int totalCount = LocalDateUtil.getDaysDifference(dateAt, dateAtUntil);

    betweenDates.add(dateAt);
    for(int i = 1; i <= totalCount; i++){
      LocalDate date = dateAt.plusDays(Long.valueOf(i));
      betweenDates.add(date);
    }
    return betweenDates;
  }

  public static LocalDate getLocalDate(Object value){
    return getLocalDate(value, null);
  }
  public static LocalDate getLocalDate(Object value, LocalDate defaultValue) {
    if(value == null)
      return defaultValue;

    LocalDate localDate;

    if(value instanceof LocalDate){
      localDate = (LocalDate) value;
    }else if(value instanceof Date){
      Date date = (Date) value;
      localDate = new Timestamp(date.getTime()).toLocalDateTime().toLocalDate();
    }else if(value instanceof Long){
      localDate = new Timestamp((Long) value).toLocalDateTime().toLocalDate();
    }else{
      String str = String.valueOf(value);
      localDate = parse(str);
    }

    return (localDate == null) ? defaultValue : localDate;

  }

  /**
   * Check if the given date is within the range [at, until].
   * - If at is null, there is no start date restriction.
   * - If until is null, there is no end date restriction.
   * - If both are null, always returns true.
   * - If date is null, returns false.
   */
  public static boolean isBetween(LocalDate date, LocalDate at, LocalDate until) {
    if (date == null) return false;
    if (at == null && until == null) return true;
    if (at == null) return !date.isAfter(until);
    if (until == null) return !date.isBefore(at);
    return !date.isBefore(at) && !date.isAfter(until);
  }



}
