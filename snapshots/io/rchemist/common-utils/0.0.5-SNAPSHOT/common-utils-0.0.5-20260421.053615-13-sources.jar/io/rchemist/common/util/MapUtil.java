/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class MapUtil {

  /**
   * Value 가 List<V> 인 map 에 대해 key 가 같으면 merge
   * @param map
   * @param key
   * @param value
   * @param <K>
   * @param <V>
   * @return
   */
  public static <K, V> Map<K, List<V>> mergeListHashMap(Map<K, List<V>> map, K key, V value, boolean allowDuplicate){
    List<V> list = new ArrayList<>();
    if(map == null)
      map = new HashMap<>();

    if (map != null){
      if(map.containsKey(key)){
        list = map.get(key);
      }
    }

    boolean add = true;

    if(!allowDuplicate){
      if(list.contains(value)) {
        add = false;
      }
    }

    if(add){
      if(list == null)
        list = new ArrayList<>();

      list.add(value);
      map.put(key, list);
    }

    return map;
  }

  public static <K, V> Map<K, List<V>> mergeListHashMap(Map<K, List<V>> map, K key, List<V> values){

    if(map.containsKey(key)){
      List<V> newValues = map.get(key);
      newValues.addAll(values);

      map.put(key, newValues);
    }else{
      map.put(key, values);
    }

    return map;

  }

  public static class Entry<K, V> {
    private final K key;
    private final V value;

    public Entry(final K key, final V value) {
      this.key = key;
      this.value = value;
    }

    public K getKey() {
      return key;
    }

    public V getValue() {
      return value;
    }
  }

  public static <K, V> Entry<K, V> entry(final K key, final V value) {
    return new Entry(key, value);
  }

  public static <K, V> Entry<K, V> entry(final K key, final V value, final V defaultValue) {
    return new Entry(key, value == null ? defaultValue : value);
  }

  @SafeVarargs
  public static <K, V> Map<K, V> asMap(final Entry<K, V>... entries) {
    return populate(new HashMap<K, V>(), entries);
  }
  public static <K, V> Map<K, V> asLinkedHashMap(final Entry<K, V>... entries) {
    return populate(new LinkedHashMap(), entries);
  }

  public static <K, V> Map<K, V> asOrderedMap(final Entry<K, V>... entries) {
    return populate(new LinkedHashMap<K, V>(), entries);
  }

  public static <K, V> Map<K, V> asUnmodifiableMap(final Entry<K, V>... entries) {
    return Collections.unmodifiableMap(populate(new HashMap<K, V>(), entries));
  }

  public static <K, V> Map<K, V> asUnmodifiableOrderedMap(final Entry<K, V>... entries) {
    return Collections.unmodifiableMap(populate(new LinkedHashMap<K, V>(), entries));
  }

  private static <K, V> Map<K, V> populate(final Map map, final Entry<K, V>... entries) {
    for (final Entry entry : entries) {
      map.put(entry.getKey(), entry.getValue());
    }
    return map;
  }

  public static <K, V> Map<K, V> asMap(final K[] key, final V[] value){
    Map map = new HashMap<K, V>();
    int i = 0;
    for(K k : key){
      map.put(k, value[i++]);
    }
    return map;
  }

  public static <K, V extends Comparable<V>> Map<K, V> sortMap(Map<K, V> map){
    List<Map.Entry<K, V>> list = sortByValue(map);

    map.clear();

    for(Map.Entry<K, V> entry : list){
      map.put(entry.getKey(), entry.getValue());
    }

    return map;
  }

  public static <K, V extends Comparable<V>> List<Map.Entry<K, V>> sortByValue(Map<K, V> map) {
    List<Map.Entry<K, V>> entries = new ArrayList<Map.Entry<K, V>>(map.entrySet());
    Collections.sort(entries, new ByValue<K, V>());
    return entries;
  }

  private static class ByValue<K, V extends Comparable<V>> implements Comparator<Map.Entry<K, V>> {
    public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
      return o1.getValue().compareTo(o2.getValue());
    }
  }

  public static <T, Q, P> List<P> getList(Map<T, Q> map, T key, Class<P> Q){
    if(MapUtils.isNotEmpty(map)
        && map.containsKey(key)
        && map.get(key) != null
        && map.get(key).getClass().isAssignableFrom(List.class)
    ){
      return (List<P>) map.get(key);
    }
    return null;
  }

  /**
   * Map 의 entry.value 를 MapValueMergeType 에 따라 replace 하거나 add
   * Integer 값이 value 인 경우 계속 더해 나가는 작업을 할 수 있다
   * @param map
   * @param key
   * @param value
   * @param mergeType
   * @return
   */
  public static <T, Q> Map<T, Q> merge(Map<T, Q> map, T key, Q value, MapValueMergeType mergeType){
    if(MapUtils.isEmpty(map)){
      map = new HashMap<>();
      map.put(key, value);
    }else{
      if(map.containsKey(key)){
        map.put(key, merge(map.get(key), value, mergeType));
      }else{
        map.put(key, value);
      }
    }

    return map;
  }


  /**
   *
   * @param previous
   * @param now
   * @param mergeType
   * @return
   */
  public static <Q> Q merge(Q previous, Q now, MapValueMergeType mergeType){
    Q value = null;

    if(mergeType.equals(MapValueMergeType.ADDITION)){
      if(previous.getClass().isAssignableFrom(Integer.class) || previous.getClass().isAssignableFrom(int.class)){
        Integer val = ((Integer) previous) + ((Integer) now);
        value = (Q) val;
      }else if(previous.getClass().isAssignableFrom(String.class)){
        StringBuffer sb = new StringBuffer();
        sb.append(previous);
        sb.append(now);
        value = (Q) sb.toString();
      }else if(previous.getClass().isAssignableFrom(BigDecimal.class)){
        value = (Q) ((BigDecimal) previous).add(((BigDecimal) now));
      }else{
        value = now;		// 검출되지 않으면 단순 replace
      }
    }else{
      // 단순 replace
      value = now;
    }

    return value;
  }

  public enum MapValueMergeType {
    REPLACE,
    ADDITION
  }

  public static <T, Q> boolean equals(Map<T, Q> map, Map<T, Q> map2){
    if((MapUtils.isEmpty(map) && MapUtils.isNotEmpty(map2)) || (MapUtils.isNotEmpty(map) && MapUtils.isEmpty(map2))){
      return false;
    }

    try{
      boolean keysEquals = map.keySet().equals(map2.keySet());

      if(!keysEquals){
        return false;
      }

    }catch (Exception e){
      // key 의 type 이 다를 때
      return false;
    }

    try{
      for(Map.Entry<T, Q> entry : map.entrySet()){
        T key = entry.getKey();
        Q value = entry.getValue();
        boolean valueEqual = value.equals(map2.get(key));

        if(!valueEqual){
          return false;
        }
      }
    }catch (Exception e){
      // value 의 type 이 다를 때
      return false;
    }

    return true;

  }

  public static <K, V> Map<K, V> clone(Map<K, V> origin, Map<K, V> target){
    if(MapUtils.isNotEmpty(origin)){
      for(Map.Entry<K, V> entry : origin.entrySet()){
        target.put(entry.getKey(), entry.getValue());
      }
    }
    return target;
  }

  public static <K, V> String toString(Map<K, V> map){
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    if (map != null) {
      for (Map.Entry<K, V> entry : map.entrySet()) {
        sb.append(entry.getKey().toString())
            .append("=")
            .append(valueToString(entry.getValue()))
            .append(", ");
      }
      if (sb.length() > 1) {
        sb.setLength(sb.length() - 2);
      }
    }
    sb.append("}");
    return sb.toString();
  }

  private static <V> String valueToString(V value) {
    if (value == null) {
      return "null";
    }
    if (value instanceof Object[]) {
      return Arrays.toString((Object[]) value);
    } else if (value instanceof Collection<?>) {
      StringBuilder sb = new StringBuilder("[");
      for (Object obj : (Collection<?>) value) {
        if (obj == null) {
          return "null";
        } else {
          sb.append(obj).append(", ");
        }
      }
      return sb.toString();
    } else if (value instanceof Map<?,?>) {
      return toString((Map<?, ?>) value);
    } else {
      return value.toString();
    }
  }


}
