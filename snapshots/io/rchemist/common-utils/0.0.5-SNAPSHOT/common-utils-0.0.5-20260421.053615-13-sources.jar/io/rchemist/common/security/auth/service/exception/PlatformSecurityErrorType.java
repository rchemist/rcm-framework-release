/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PlatformSecurityErrorType extends EnumType<PlatformSecurityErrorType> implements ErrorType {

  public static final PlatformSecurityErrorType TOKEN_MISMATCH = new PlatformSecurityErrorType("TOKEN_MISMATCH", "올바르지 않은 토큰 정보 입니다.", HttpStatus.BAD_REQUEST.value());
  public static final PlatformSecurityErrorType TOKEN_EXPIRED = new PlatformSecurityErrorType("TOKEN_EXPIRED", "만료된 토큰 정보 입니다.", HttpStatus.BAD_REQUEST.value());
  public static final PlatformSecurityErrorType TOKEN_REQUIRED = new PlatformSecurityErrorType("TOKEN_REQUIRED", "먼저 접근 권한을 획득해야 합니다.", HttpStatus.UNAUTHORIZED.value());
  public static final PlatformSecurityErrorType ACCESS_DENIED = new PlatformSecurityErrorType("ACCESS_DENIED", "해당 리소스에 대한 접근 권한이 없습니다.", HttpStatus.FORBIDDEN.value());
  public static final PlatformSecurityErrorType INVALID_PASSWORD = new PlatformSecurityErrorType("INVALID_PASSWORD", "비밀번호가 틀렸습니다.", HttpStatus.FORBIDDEN.value());
  public static final PlatformSecurityErrorType PASSWORD_REQUIRED = new PlatformSecurityErrorType("PASSWORD_REQUIRED", "비밀번호를 입력해야 합니다.", HttpStatus.FORBIDDEN.value());
  public static final PlatformSecurityErrorType NOW_OWNED_DATA = new PlatformSecurityErrorType("NOW_OWNED_DATA", "자신의 데이터만 확인할 수 있습니다.", HttpStatus.FORBIDDEN.value());
  public static final PlatformSecurityErrorType INVALID_SOCIAL_REQUEST = new PlatformSecurityErrorType("INVALID_SOCIAL_REQUEST", "Social login 정보가 올바르지 않습니다.", HttpStatus.BAD_REQUEST.value());
  public static final PlatformSecurityErrorType INVALID_USERNAME_REQUEST = new PlatformSecurityErrorType("INVALID_USERNAME_REQUEST", "Login 정보가 올바르지 않습니다.", HttpStatus.BAD_REQUEST.value());
  public static final PlatformSecurityErrorType NOT_FOUND_USER_SOCIAL = new PlatformSecurityErrorType("NOT_FOUND_USER_SOCIAL", "Social 계정으로 가입된 정보가 없습니다.", HttpStatus.BAD_REQUEST.value());
  public static final PlatformSecurityErrorType NOT_ALLOWED_TENANT_ALIAS = new PlatformSecurityErrorType("NOT_ALLOWED_TENANT_ALIAS", "해당 테넌트의 엔티티에 대한 접근 권한이 없습니다.", HttpStatus.UNAUTHORIZED.value());
  public static final PlatformSecurityErrorType NOT_ALLOWED_NO_ROLES = new PlatformSecurityErrorType("NOT_ALLOWED_TENANT_ALIAS", "해당 정보에 접근할 수 있는 권한이 없습니다.", HttpStatus.FORBIDDEN.value());

  @Getter
  protected final int status;

  public PlatformSecurityErrorType(String type, String friendlyType, int status) {
    super(type, friendlyType);
    this.status = status;
  }
}
