/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.concurrent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class ConcurrentLinkedHashSet<E> {

  private final Map<E, Boolean> map;
  private final ReentrantLock lock = new ReentrantLock();

  /**
   * Default constructor. Creates an empty ConcurrentLinkedHashSet.
   */
  public ConcurrentLinkedHashSet() {
    this.map = Collections.synchronizedMap(new LinkedHashMap<>());
  }

  /**
   * Constructor with initial capacity.
   *
   * @param initialCapacity the initial capacity of the set
   */
  public ConcurrentLinkedHashSet(int initialCapacity) {
    this.map = Collections.synchronizedMap(new LinkedHashMap<>(initialCapacity));
  }

  /**
   * Adds the specified element to this set if it is not already present.
   *
   * @param element element to be added to this set
   * @return true if this set did not already contain the specified element
   */
  public boolean add(E element) {
    lock.lock();
    try {
      return map.putIfAbsent(element, Boolean.TRUE) == null;
    } finally {
      lock.unlock();
    }
  }

  /**
   * Removes the specified element from this set if it is present.
   *
   * @param element element to be removed from this set, if present
   * @return true if this set contained the specified element
   */
  public boolean remove(E element) {
    lock.lock();
    try {
      return map.remove(element) != null;
    } finally {
      lock.unlock();
    }
  }

  /**
   * Checks if this set contains the specified element.
   *
   * @param element element whose presence in this set is to be tested
   * @return true if this set contains the specified element
   */
  public boolean contains(E element) {
    lock.lock();
    try {
      return map.containsKey(element);
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns the number of elements in this set.
   *
   * @return the number of elements in this set
   */
  public int size() {
    lock.lock();
    try {
      return map.size();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Checks if this set is empty.
   *
   * @return true if this set contains no elements
   */
  public boolean isEmpty() {
    lock.lock();
    try {
      return map.isEmpty();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Clears all elements from this set.
   */
  public void clear() {
    lock.lock();
    try {
      map.clear();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns the elements of this set as a list in insertion order.
   *
   * @return a list of elements in insertion order
   */
  public List<E> toList() {
    lock.lock();
    try {
      return new ArrayList<>(map.keySet());
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns a string representation of this set.
   *
   * @return a string representation of this set
   */
  @Override
  public String toString() {
    lock.lock();
    try {
      return map.keySet().toString();
    } finally {
      lock.unlock();
    }
  }

}
