/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ShortenUrlUtil {

  private static final String CODEC = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  private static final char[] charArray = CODEC.toCharArray();
  private static final int base = CODEC.length();

  public static String generate(Long id, int minimumLength){
    var str = new StringBuilder();

    if(id == null || id == 0)
      return String.valueOf(charArray[0]);

    int count = 0;
    while(id > 0){
      str.append(charArray[(int) (id % base)]);
      id = id / base;
      count++;
    }

    if(minimumLength > count){
      minimumLength = minimumLength - count;
      String now = Base64.encodeBase64URLSafeString(Long.toString(System.currentTimeMillis()).getBytes());
      str.append(StringUtil.getRandomString(now, minimumLength));
    }

    return str.reverse().toString();
  }

  public static long decode(String str){
    var chr = str.toCharArray();
    var length = chr.length;

    var decoded = 0;

    var counter = 1;

    for(int i = 0; i < length ; i++){
      decoded += CODEC.indexOf(chr[i]) * Math.pow(base, length - counter);
      counter++;
    }
    return decoded;
  }

  public static String generate(String url){
    boolean secureHttp = StringUtils.containsIgnoreCase(url, "https://");   // 도메인까지 연결된 URL 을 만들 때 이 값을 사용한다.
    url = StringUtil.subStringAfter(url, "://");
    url = Base64.encodeBase64URLSafeString(url.getBytes());

    String now = Base64.encodeBase64URLSafeString(Long.toString(System.currentTimeMillis()).getBytes());

    StringBuilder sb = new StringBuilder();

    sb.append(StringUtil.getRandomString(url, 3));
    sb.append(StringUtil.getRandomString(now, 3));

    return sb.toString();
  }




}
