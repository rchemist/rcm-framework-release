/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.micrometer.common.util.StringUtils;
import java.util.regex.Pattern;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 **/
@Getter
public enum RegexType {
  
  LOGIN_NAME(Regex.LOGIN_NAME, Message.LOGIN_NAME, "platform.config.regex.login-name"),
  PASSWORD(Regex.PASSWORD, Message.PASSWORD, "platform.config.regex.password"),
  EMAIL(Regex.EMAIL, Message.EMAIL, "platform.config.regex.email"),
  NUMBER(Regex.NUMBER, Message.NUMBER, "platform.config.regex.number"),
  PHONE_NUMBER(Regex.PHONE_NUMBER, Message.PHONE_NUMBER, "platform.config.regex.phone-number"),
  WHOLE_NUMBER(Regex.WHOLE_NUMBER, Message.WHOLE_NUMBER, "platform.config.regex.whole-number"),
  ENGLISH(Regex.ENGLISH, Message.ENGLISH, "platform.config.regex.english"),
  DOMAIN(Regex.DOMAIN, Message.DOMAIN, "platform.config.regex.domain"),
  NUMBER_ENGLISH(Regex.NUMBER_ENGLISH, Message.NUMBER_ENGLISH, "platform.config.regex.number-english"),
  NUMBER_ENGLISH_EXT(Regex.NUMBER_ENGLISH_EXT, Message.NUMBER_ENGLISH_EXT, "platform.config.regex.number-english-ext"),
  NUMBER_ENGLISH_COMMA(Regex.NUMBER_ENGLISH_COMMA, Message.NUMBER_ENGLISH_COMMA, "platform.config.regex.number-english-comma"),
  NUMBER_ENGLISH_EXT_COMMA(Regex.NUMBER_ENGLISH_EXT_COMMA, Message.NUMBER_ENGLISH_EXT_COMMA, "platform.config.regex.number-english-ext-comma"),
  NUMBER_ENGLISH_URL(Regex.NUMBER_ENGLISH_URL, Message.NUMBER_ENGLISH_URL, "platform.config.regex.number.english-url"),
  KOREAN(Regex.KOREAN, Message.KOREAN, "platform.config.regex.password"),
  KOREAN_NAME(Regex.KOREAN_NAME, Message.KOREAN_NAME, "platform.config.regex.korean-name"),
  TIME(Regex.TIME, Message.TIME, "platform.config.regex.time"),
  MONTH(Regex.MONTH, Message.MONTH, "platform.config.regex.month"),
  MONTH_DAY(Regex.MONTH_DAY, Message.MONTH_DAY, "platform.config.regex.month-day"),
  HTTP_URL(Regex.HTTP_URL, Message.HTTP_URL, "platform.config.regex.http-url"),
  URL_BODY(Regex.URL_BODY, Message.URL_BODY, "platform.config.regex.url-body");

  RegexType(String regexExpression, String errorMessage){
    this.regexExpression = regexExpression;
    this.errorMessage = errorMessage;   // I18N code
  }

  RegexType(String regexExpression, String errorMessage, String systemProperty){
    this.regexExpression = regexExpression;
    this.errorMessage = errorMessage;   // I18N code
    this.systemProperty = systemProperty;
  }
  
  private final String regexExpression;

  private final String errorMessage;

  private String systemProperty;

  public boolean validate(String value, boolean required) {
    if (StringUtils.isNotEmpty(value)) {
      return Pattern.matches(this.regexExpression, value);
    }
    return !required;
  }

  public static class Regex {

    public static final String ADMIN_LOGIN_NAME = "ADMIN_LOGIN_NAME";   // property 로 셋팅된 loginName regex AdminUserSetting.
    public static final String ADMIN_PASSWORD = "ADMIN_PASSWORD";
    public static final String CUSTOMER_LOGIN_NAME = "CUSTOMER_LOGIN_NAME";
    public static final String CUSTOMER_PASSWORD = "CUSTOMER_PASSWORD";


    public static final String LOGIN_NAME = "^[a-zA-Z]{1}[a-zA-Z0-9_]{4,24}$";
    public static final String PASSWORD = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&()=+~_-])[A-Za-z\\d$@$!%*#?&()=+~_-]{8,}$";
    public static final String EMAIL = "^[_a-zA-Z0-9-]+(.[_a-zA-Z0-9-]+)*@(?:\\w+\\.)+\\w+$";
    public static final String NUMBER = "^[0-9]*$";
    public static final String PHONE_NUMBER = "^[0-9]{10,11}$";
    public static final String WHOLE_NUMBER = "^[-]?(0|[1-9][0-9]*)";
    public static final String ENGLISH = "^[a-zA-Z]*$";
    public static final String DOMAIN = "^((?!-)[A-Za-z0-9-]{1,63}(?<!-)\\.)+[A-Za-z]{2,6}";
    public static final String NUMBER_ENGLISH = "^[a-zA-Z0-9]*$";
    public static final String NUMBER_ENGLISH_EXT = "^[a-zA-Z0-9-_]*$";
    public static final String NUMBER_ENGLISH_COMMA = "^[a-zA-Z0-9.]*$";
    public static final String NUMBER_ENGLISH_EXT_COMMA = "^[a-zA-Z0-9._]*$";
    public static final String NUMBER_ENGLISH_SPECIAL = "^[a-zA-Z0-9.~!@#$%^&*()_+|<>?:{}]*$";
    public static final String NUMBER_ENGLISH_URL = "^[-a-zA-Z0-9._+/]*$";
    public static final String KOREAN = "^[가-힣]*$";
    public static final String KOREAN_NAME = "^[가-힣]{2,5}$";
    public static final String MONTH = "^(19|20)\\d{2}-(0[1-9]|1[012])$";
    public static final String MONTH_DAY = "^(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[0-1])$";
    public static final String TIME = "^([1-9]|[01][0-9]|2[0-3]):([0-5][0-9])$";
    public static final String HTTP_URL = "^(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
    
    public static final String URL_BODY = "^[-a-zA-Z0-9-/]*$";
  }

  public static class Message {

    public static final String LOGIN_NAME = "error.message.regex.loginName";
    public static final String PASSWORD = "error.message.regex.password";
    public static final String EMAIL = "error.message.regex.email";
    public static final String NUMBER = "error.message.regex.number";
    public static final String PHONE_NUMBER = "error.message.regex.phone.number";
    public static final String WHOLE_NUMBER = "error.message.regex.whole.number";
    public static final String ENGLISH = "error.message.regex.english";
    public static final String DOMAIN = "error.message.regex.domain";
    public static final String NUMBER_ENGLISH = "error.message.regex.number.english";
    public static final String NUMBER_ENGLISH_EXT = "error.message.regex.number.english.ext";
    public static final String NUMBER_ENGLISH_COMMA = "error.message.regex.number.english.comma";
    public static final String NUMBER_ENGLISH_EXT_COMMA = "error.message.regex.number.english.ext.comma";
    public static final String NUMBER_ENGLISH_SPECIAL = "error.message.regex.number.english.special";
    public static final String NUMBER_ENGLISH_URL = "error.message.regex.number.english.url";
    public static final String KOREAN = "error.message.regex.korean";
    public static final String KOREAN_NAME = "error.message.regex.korean.name";
    public static final String MONTH = "error.message.regex.month";
    public static final String MONTH_DAY = "error.message.regex.month.day";
    public static final String TIME = "error.message.regex.time";
    public static final String HTTP_URL = "error.message.regex.url";
    public static final String URL_BODY = "error.message.regex.url-main";

  }

  public static RegexType getRegexType(final String type){
    return RegexType.valueOf(type);
  }

}
