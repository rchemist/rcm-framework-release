/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class AppendStringSource implements Serializable {

  private static final String EMPTY = "";

  private String source;
  private final String[] appendStr;
  private final String splitCode;
  private final String defaultValue;
  private AppendPositionType appendPositionType = AppendPositionType.REAR;

  /**
   * 인스턴스는 반드시 TrimAndAppend를 통해서만 생성한다
   *
   * @param t
   */
  private AppendStringSource(TrimAndAppend t) {
    this.source = t.source;
    this.appendStr = t.appendStr;
    this.defaultValue = t.defaultValue;
    this.splitCode = t.splitCode;
    this.appendPositionType = t.appendPositionType;
  }

  public String trimAndAppend() {

    if (ArrayUtils.isNotEmpty(appendStr)) {
      for (String append : appendStr) {
        append = StringUtil.toString(append);
        if (appendPositionType.equals(AppendPositionType.FORE)) {
          source = StringUtils.join(append, splitCode, source);
        } else {
          source = StringUtils.join(source, splitCode, append);
        }
      }
    }

    return StringUtil.toString(source, defaultValue);
  }

  public enum AppendPositionType {
    FORE        // 앞
    , REAR      // 뒤
  }

  /**
   * Builder
   */
  public static class TrimAndAppend {

    private String source;
    private String[] appendStr;
    private String splitCode = ",";   // 기본 구분 코드는 , 이며 재정의 할 수 있다
    private String defaultValue = EMPTY;
    private boolean trim = true;
    private boolean appendEvenBlank = false; // 기본적으로는 append 문자열이 존재하지 않으면 splitCode도 삽입하지 않는다
    private AppendPositionType appendPositionType = AppendPositionType.REAR;

    public TrimAndAppend(String source, boolean appendEvenBlank, String... appendStr) {
      this.source = StringUtil.toString(source);
      this.appendEvenBlank = appendEvenBlank;
      this.appendStr = appendStr;
    }

    public TrimAndAppend defaultValue(String defaultValue) {
      this.defaultValue = defaultValue;
      return this;
    }

    public TrimAndAppend splitCode(String splitCode) {
      this.splitCode = splitCode;
      return this;
    }

    public TrimAndAppend trim(boolean trim) {
      this.trim = trim;
      return this;
    }

    public TrimAndAppend appendEvenBlank(boolean appendEvenBlank) {
      this.appendEvenBlank = appendEvenBlank;
      return this;
    }

    public TrimAndAppend appendPositionType(AppendPositionType appendPositionType) {
      this.appendPositionType = appendPositionType;
      return this;
    }

    public String toString() {
      if (this.trim) {
        this.source = StringUtils.trim(source);
      }

      this.appendStr = StringUtil.trim(appendEvenBlank, trim, appendStr);

      return new AppendStringSource(this).trimAndAppend();
    }
  }

}
