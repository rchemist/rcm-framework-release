/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.concurrent;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.StampedLock;
import java.util.function.Supplier;

/**
 * <p>
 * Project : rcm-framework
 * <p>
 * Created by kunner
 **/

public class ConcurrentMap<K, V> {
  private final Map<K, V> map;
  private final int maxSize;
  private final boolean highPerformance;
  private final StampedLock stampedLock;
  private final ReentrantLock reentrantLock;

  public enum Policy {
    LRU,    // 사용된지 가장 오래된 것을 먼저 삭제
    LFU   // 사용 빈도가 가장 낮은 것을 먼저 삭제
  }

  public ConcurrentMap(int maxSize) {
    this(maxSize, Policy.LRU, false);
  }

  public ConcurrentMap(int maxSize, boolean highPerformance) {
    this(maxSize, Policy.LRU, highPerformance);
  }

  public ConcurrentMap(int maxSize, Policy policy, boolean highPerformance) {
    if (maxSize <= 0) {
      throw new IllegalArgumentException("Max size must be greater than 0");
    }
    this.maxSize = maxSize;
    this.highPerformance = highPerformance;

    if (highPerformance) {
      this.stampedLock = new StampedLock();
      this.reentrantLock = null;
    } else {
      this.stampedLock = null;
      this.reentrantLock = new ReentrantLock();
    }

    if (policy == Policy.LRU) {
      this.map = new LinkedHashMap<>(maxSize, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
          return size() > ConcurrentMap.this.maxSize;
        }
      };
    } else if (policy == Policy.LFU) {
      this.map = new LinkedHashMap<>() {
        private final Map<K, Integer> frequencyMap = new HashMap<>();

        @Override
        public V put(K key, V value) {
          frequencyMap.put(key, frequencyMap.getOrDefault(key, 0) + 1);
          return super.put(key, value);
        }

        @Override
        public V remove(Object key) {
          frequencyMap.remove(key);
          return super.remove(key);
        }

        @Override
        protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
          if (size() > ConcurrentMap.this.maxSize) {
            frequencyMap.entrySet()
                .stream()
                .min(Comparator.comparingInt(Map.Entry::getValue))
                .map(Map.Entry::getKey)
                .ifPresent(frequencyMap::remove);
            return false; // Prevent LinkedHashMap's default eviction
          }
          return false;
        }
      };
    } else {
      throw new IllegalArgumentException("Unsupported policy: " + policy);
    }
  }

  private <R> R withReadLock(Supplier<R> action) {
    if (highPerformance) {
      long stamp = stampedLock.readLock();
      try {
        return action.get();
      } finally {
        stampedLock.unlockRead(stamp);
      }
    } else {
      reentrantLock.lock();
      try {
        return action.get();
      } finally {
        reentrantLock.unlock();
      }
    }
  }

  private <R> R withWriteLock(Supplier<R> action) {
    if (highPerformance) {
      long stamp = stampedLock.writeLock();
      try {
        return action.get();
      } finally {
        stampedLock.unlockWrite(stamp);
      }
    } else {
      reentrantLock.lock();
      try {
        return action.get();
      } finally {
        reentrantLock.unlock();
      }
    }
  }

  public V get(K key) {
    return withReadLock(() -> map.get(key));
  }

  public V put(K key, V value) {
    return withWriteLock(() -> map.put(key, value));
  }

  public V remove(K key) {
    return withWriteLock(() -> map.remove(key));
  }

  public int size() {
    return withReadLock(map::size);
  }

  public void clear() {
    withWriteLock(() -> {
      map.clear();
      return null;
    });
  }

  public boolean containsKey(K key) {
    return withReadLock(() -> map.containsKey(key));
  }
}
