/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.configuration;

import jakarta.annotation.PostConstruct;
import java.util.Map;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmApplicationContextHolder")
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApplicationContextHolder implements ApplicationContextAware {

  private static volatile ApplicationContext context;
  private static final Object lock = new Object();

  public static ApplicationContext getApplicationContext() {
    return context;
  }

  public static <T> Map<String, T> getBeansOfType(Class<T> tClass) {
    if(ArrayUtils.isNotEmpty(context.getBeanNamesForType(tClass))){
      return context.getBeansOfType(tClass);
    }
    throw new NoSuchBeanDefinitionException("There is no bean that class " + tClass.getName());
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    synchronized (lock) {
      if (context == null) {
        context = applicationContext;
      }
    }
  }

  @PostConstruct
  public void init() {
    // This ensures the bean is initialized early in the Spring lifecycle
    // The ApplicationContext will already be set by setApplicationContext at this point
  }

  public static <T> T getBean(Class<T> tClass) throws NoSuchBeanDefinitionException {
    if (context == null) {
      throw new NoSuchBeanDefinitionException("ApplicationContext not initialized yet");
    }
    if (context.getBean(tClass) != null) {
      return (T) context.getBean(tClass);
    }
    throw new NoSuchBeanDefinitionException("There is no bean that class " + tClass.getName());
  }

  public static <T> T getBean(String beanName, Class<T> tClass) throws NoSuchBeanDefinitionException {
    if (context.getBean(beanName) != null) {
      return (T) context.getBean(beanName);
    }
    throw new NoSuchBeanDefinitionException("There is no bean that named " + beanName);
  }
  /*
  public static <T> List<T> getBeans(Class<T> tClass) throws NoSuchBeanDefinitionException {
  }*/
}