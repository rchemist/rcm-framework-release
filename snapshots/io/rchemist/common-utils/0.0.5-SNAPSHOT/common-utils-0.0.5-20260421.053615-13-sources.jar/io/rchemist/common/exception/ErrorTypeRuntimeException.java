/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.exception;

import io.rchemist.common.exception.error.DefaultServerErrorType;
import io.rchemist.common.exception.error.ErrorBuilder;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.exception.error.ErrorType;
import io.rchemist.common.util.StringUtil;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ErrorTypeRuntimeException extends RuntimeException implements HasPropertyNameException,
    HasErrorDTOException, HasErrorTypeException {

  public ErrorTypeRuntimeException(ErrorType errorType){
    super(errorType.getType());
    this.errorType = errorType;
    this.message = errorType.getTranslatedType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeRuntimeException(Throwable cause){
    if(cause instanceof Exception){
      ErrorDTO error = new ErrorDTO(cause);
      this.error = error;
      this.detailMessage = error.getDetailMessage();
    }
  }

  public ErrorTypeRuntimeException(ErrorType errorType, Throwable cause) {
    super(errorType.getType(), cause);
    this.errorType = errorType;
    this.message = errorType.getTranslatedType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeRuntimeException(String message, ErrorDTO errorDTO) {
    super(message);
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = errorDTO;
    this.detailMessage = error.getDetailMessage();
  }

  public ErrorTypeRuntimeException(String message, Throwable cause) {
    super(message, cause);
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeRuntimeException(String message) {
    super(message);
    // BUG-045 fix (0.1.1.K): overridden getMessage() reads this.message field,
    // but single-String ctor previously omitted the assignment (asymmetric with
    // sibling ErrorTypeException(String)). Result: getMessage() returned null
    // when caller passed a plain message. Store it so the override returns it.
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  @Getter
  protected ErrorType errorType;

  protected ErrorDTO error = new ErrorDTO();

  protected String message;

  protected String detailMessage;

  @Getter
  protected String propertyName;

  public ErrorTypeRuntimeException(String propertyName, String message) {
    super(message);
    this.propertyName = propertyName;
    this.message = message;
    this.errorType = new DefaultServerErrorType();
    this.error = new ErrorDTO(errorType);
  }

  public ErrorTypeRuntimeException(String propertyName, ErrorType errorType){
    super();
    this.propertyName = propertyName;
    this.errorType = errorType;
    ErrorDTO errorDTO = new ErrorDTO(errorType);
    this.error = errorDTO;
    this.message = errorType.getTranslatedType();
  }

  public ErrorTypeRuntimeException(ErrorType errorType, String addedMessage) {
    ErrorDTO errorDTO = new ErrorDTO(errorType);
    errorDTO.setMessage(errorType.getTranslatedType() + " : " + addedMessage);
    this.error = errorDTO;
    this.message = errorType.getTranslatedType();
    this.errorType = errorType;
    this.detailMessage = addedMessage;
  }

  public ErrorDTO getError(){
    if(error != null)
      return error;

    return (errorType != null) ? ErrorBuilder.getError(errorType) : null;
  }

  public ErrorTypeRuntimeException withDetailMessage(String detailMessage) {
    this.detailMessage = detailMessage;
    return this;
  }

  public String getDetailMessage() {
    return StringUtil.toString(detailMessage, getMessage());
  }

  public ErrorTypeRuntimeException withError(ErrorDTO error) {
    this.error = error;
    return this;
  }

  @Override
  public String getMessage(){
    String message = StringUtil.toString(this.message, this.detailMessage);
    return StringUtil.toString(message, (errorType != null) ? errorType.getTranslatedType() : null);
  }

  public String getErrorTypeToString(){
    if(errorType == null)
      return null;
    return errorType.getType();
  }


}
