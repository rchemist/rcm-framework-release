/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.LocalDateTimeUtil;
import java.time.LocalDateTime;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class LimitTimePeriodType extends EnumType<LimitTimePeriodType> {

  public static final LimitTimePeriodType UNLIMITED = new LimitTimePeriodType(10, "UNLIMITED", "Unlimited", "제한 없음", "unlimited", false, false);
  public static final LimitTimePeriodType DAYS = new LimitTimePeriodType(100, "DAYS", "Days more", "n 일 동안", "days", true, true);
  public static final LimitTimePeriodType MONTHS = new LimitTimePeriodType(200, "MONTHS", "Months more", "n 개월 동안", "months", true, true);
  public static final LimitTimePeriodType YEARS = new LimitTimePeriodType(300, "YEARS", "Years more", "n 년 동안", "years", true, true);
  public static final LimitTimePeriodType HOURS = new LimitTimePeriodType(400, "HOURS", "Hours more", "n 시간 동안", "hours", true, true);
  public static final LimitTimePeriodType SPECIFIC_DAYS = new LimitTimePeriodType(500, "SPECIFIC_DAYS", "Until specific days", "지정된 날짜까지", "specific.days", false, false);
  public static final LimitTimePeriodType TODAY = new LimitTimePeriodType(600, "TODAY", "Today", "당일", "금일(Today)", true, false);
  public static final LimitTimePeriodType THIS_MONTH = new LimitTimePeriodType(700, "THIS_MONTH", "This month", "금월(This month)", "this.month", true, false);
  public static final LimitTimePeriodType THIS_YEAR = new LimitTimePeriodType(800, "THIS_YEAR", "This year", "금년(This year)", "this.year", true, false);

  @Override
  protected String getPrefix() {
    return "global.type.limit.time.period.type.";
  }

  @Getter
  protected boolean calculateDifference;

  @Getter
  protected boolean shouldCalculate;

  public LimitTimePeriodType(int order, String type, String friendlyType, String description, String messageKey, boolean shouldCalculate, boolean calculateDifference) {
    super(order, type, friendlyType, description, messageKey);
    this.shouldCalculate = shouldCalculate;
    this.calculateDifference = calculateDifference;
  }

  /**
   * 각 설정에 의한 유효기간 마지막 날짜 조회
   * @param compareDate
   * @param difference
   * @return
   */
  public LocalDateTime getAvailableUntil(LocalDateTime compareDate, Long difference){

    if(getType().equals(UNLIMITED.getType())){
      return null;    // null 반환
    }

    if(!isShouldCalculate())
      return compareDate;

    String type = getType();
    compareDate = (compareDate == null) ? LocalDateTime.now() : compareDate;
    LocalDateTime calculatedDate = LocalDateTimeUtil.getEndOfDay(compareDate);

    if(isCalculateDifference()){

      if(difference == null){
        return calculatedDate;
      }else{
        if(type.equals(DAYS.getType())){
          calculatedDate = calculatedDate.plusDays(difference);
        }else if(type.equals(MONTHS.getType())){
          calculatedDate = calculatedDate.plusMonths(difference);
        }else if(type.equals(YEARS.getType())){
          calculatedDate = calculatedDate.plusYears(difference);
        }else if(type.equals(HOURS.getType())){
          calculatedDate = compareDate.plusHours(difference);    // 시간을 더할 때는 초기화하지 않은 날짜로 한다.
        }
      }
    }else{

      if(type.equals(TODAY.getType())){
        calculatedDate = LocalDateTimeUtil.getEndOfDay(calculatedDate);
      }else if(type.equals(THIS_MONTH.getType())){
        calculatedDate = LocalDateTimeUtil.getEndOfMonthDay(calculatedDate);
      }else if(type.equals(THIS_YEAR.getType())){
        calculatedDate = LocalDateTimeUtil.getEndOfYearDay(calculatedDate);
      }

    }
    return calculatedDate;
  }

  /**
   * 기존 적용 횟수 체크 시
   * 각 설정에 의한 적용 기간 시작일 조회
   *
   * @param difference
   * @return
   */
  public LocalDateTime getPreviousPeriodStartedAt(Long difference) {

    String type = getType();
    LocalDateTime now = LocalDateTime.now();
    LocalDateTime today = LocalDateTimeUtil.getStartOfDay(now);

    if(isCalculateDifference()){
      if(difference == null){
        return today;
      }else{
        if(type.equals(DAYS.getType())){
          return today.minusDays(difference);
        }else if(type.equals(MONTHS.getType())){
          return today.minusMonths(difference);
        }else if(type.equals(YEARS.getType())){
          return today.plusYears(difference);
        }else if(type.equals(HOURS.getType())){
          return now.minusHours(difference);    // 시간을 더할 때는 초기화하지 않은 날짜로 한다.
        }
      }
    }else{
      if(type.equals(TODAY.getType())){
        return today;
      }else if(type.equals(THIS_MONTH.getType())){
        return LocalDateTimeUtil.getStartOfMonthDay(today);
      }else if(type.equals(THIS_YEAR.getType())){
        return LocalDateTimeUtil.getStartOfYearDay(today);
      }
    }

    return today;

  }
}
