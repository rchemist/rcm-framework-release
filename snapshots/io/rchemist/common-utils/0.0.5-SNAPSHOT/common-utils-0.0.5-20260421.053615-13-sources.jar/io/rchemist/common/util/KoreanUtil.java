/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.type.KoreanPhonemeParserType;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class KoreanUtil {

  /**
   * 초성만 추출
   * @param str
   * @return
   */
  public static String getConsonants(String str){
    if (StringUtils.isEmpty(str))
      return str;
    return String.valueOf(KoreanPhonemeParserType.CONSONANT.getParser().parse(str));
  }

  // 음소 추출(초성/중성/종성)
  public static String getPhonemes(String str){
    if (StringUtils.isEmpty(str))
      return str;
    return String.valueOf(KoreanPhonemeParserType.PHONEME.getParser().parse(str));
  }

}
