/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.concurrent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class ConcurrentArrayList<E> {
  private final List<E> list;
  private final ReentrantLock lock = new ReentrantLock();

  /**
   * Default constructor. Creates an empty concurrent list.
   */
  public ConcurrentArrayList() {
    this.list = new ArrayList<>();
  }

  /**
   * Constructor with initial capacity.
   *
   * @param initialCapacity the initial capacity of the list
   */
  public ConcurrentArrayList(int initialCapacity) {
    this.list = new ArrayList<>(initialCapacity);
  }

  /**
   * Adds an element to the list.
   *
   * @param element the element to add
   */
  public void add(E element) {
    lock.lock();
    try {
      list.add(element);
    } finally {
      lock.unlock();
    }
  }

  /**
   * Removes an element from the list.
   *
   * @param element the element to remove
   * @return true if the element was removed, false otherwise
   */
  public boolean remove(E element) {
    lock.lock();
    try {
      return list.remove(element);
    } finally {
      lock.unlock();
    }
  }

  /**
   * Gets the element at the specified index.
   *
   * @param index the index of the element to return
   * @return the element at the specified index
   */
  public E get(int index) {
    lock.lock();
    try {
      return list.get(index);
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns the size of the list.
   *
   * @return the size of the list
   */
  public int size() {
    lock.lock();
    try {
      return list.size();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Checks if the list is empty.
   *
   * @return true if the list is empty, false otherwise
   */
  public boolean isEmpty() {
    lock.lock();
    try {
      return list.isEmpty();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Clears all elements from the list.
   */
  public void clear() {
    lock.lock();
    try {
      list.clear();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns a thread-safe view of the list.
   *
   * @return a thread-safe view of the list
   */
  public List<E> asSynchronizedList() {
    return Collections.synchronizedList(list);
  }

  /**
   * Returns a string representation of the list.
   *
   * @return a string representation of the list
   */
  @Override
  public String toString() {
    lock.lock();
    try {
      return list.toString();
    } finally {
      lock.unlock();
    }
  }
}
