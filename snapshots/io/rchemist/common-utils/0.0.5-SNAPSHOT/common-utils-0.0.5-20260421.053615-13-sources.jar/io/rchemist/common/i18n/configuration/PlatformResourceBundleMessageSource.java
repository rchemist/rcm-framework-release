/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.i18n.configuration;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.i18n.service.extension.ResourceBundleMessageExtensionManager;
import java.text.MessageFormat;
import java.util.Locale;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PlatformResourceBundleMessageSource extends ReloadableResourceBundleMessageSource {

  protected final ResourceBundleMessageExtensionManager extensionManager;

  public PlatformResourceBundleMessageSource(ResourceBundleMessageExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Override
  protected MessageFormat resolveCode(String code, Locale locale) {

    ExtensionResultHolder<String> erh = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().resolveMessageCode(code, locale, erh);

    if(!status.equals(ExtensionResultStatusType.NOT_HANDLED)){
      return createMessageFormat(erh.getResult(), locale);
    }

    try{
      return super.resolveCode(code, locale);
    }catch (Exception e){
      return new MessageFormat(code);
    }
  }

  @Override
  protected String resolveCodeWithoutArguments(String code, Locale locale) {

    ExtensionResultHolder<String> erh = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().resolveMessageCode(code, locale, erh);

    if(!status.equals(ExtensionResultStatusType.NOT_HANDLED)){
      return erh.getResult();
    }
    return super.resolveCodeWithoutArguments(code, locale);
  }

  public final Locale getDefaultLocale(){
    return super.getDefaultLocale();
  }

}
