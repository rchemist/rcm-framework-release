/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.bulkupload.data;

import java.io.Serializable;
import java.util.Comparator;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class DataImportError implements Serializable {

  protected Integer row;
  protected String field;
  protected String message;

  public DataImportError withField(String field) {
    this.field = field;
    return this;
  }

  public DataImportError withMessage(String message) {
    this.message = message;
    return this;
  }

  public DataImportError withRow(Integer row) {
    this.row = row;
    return this;
  }
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    DataImportError that = (DataImportError) object;

    return new EqualsBuilder().append(row, that.row)
        .append(field, that.field).append(message, that.message).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(row).append(field).append(message).toHashCode();
  }

  public static class DataImportErrorComparator implements Comparator<DataImportError> {
    @Override
    public int compare(DataImportError o1, DataImportError o2) {
      return Integer.compare(o1.getRow(), o2.getRow());
    }
  }

}