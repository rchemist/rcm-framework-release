package io.rchemist.common.util;

import java.time.DateTimeException;
import java.time.LocalDate;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class YearUtil {

  public static boolean isYear(String year) {
    return isYear(year, true);
  }

  public static boolean isYear(Integer year) {
    return isYear(year, false);
  }

  public static boolean isYear(Integer year, Boolean strict) {
    if (year == null) {
      return false;
    }
    return isYear(String.valueOf(year), strict);
  }

  public static boolean isYear(String year, Boolean strict) {
    if (year == null || year.isEmpty()) {
      return false;
    }

    if (!year.matches("\\d+")) {
      return false;
    }

    if (strict != null && strict) {
      try {
        int y = Integer.parseInt(year);
        LocalDate.of(y, 1, 1);
      } catch (NumberFormatException | DateTimeException e) {
        return false;
      }
    }

    return true;
  }

  public static boolean isYear(String year, Boolean strict, int min, int max) {
    if (!isYear(year, strict)) {
      return false;
    }

    try {
      int y = Integer.parseInt(year);
      return y >= min && y <= max;
    } catch (NumberFormatException e) {
      return false;
    }
  }

}
