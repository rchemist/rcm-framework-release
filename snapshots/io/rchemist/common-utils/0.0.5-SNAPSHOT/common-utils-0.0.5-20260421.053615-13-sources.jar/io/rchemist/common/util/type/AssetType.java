/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum AssetType {

  FILE(1, "파일 업로드")
  , LINK(2, "링크 연결");

  AssetType(int order, String description){
    this.order = order;
    this.description = description;
  }

  private int order;

  @Getter
  private String description;

}
