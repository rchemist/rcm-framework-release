/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.rchemist.common.util;

import static org.apache.commons.lang3.ClassUtils.isPrimitiveWrapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.LoaderClassPath;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.ClassFile;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.SignatureAttribute;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.IntegerMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by kunner
 **/
@Slf4j
public class BytecodeUtil {

  private static final String MANY_TO_MANY = "jakarta.persistence.ManyToMany";
  private static final String MANY_TO_ONE = "jakarta.persistence.ManyToOne";
  private static final String ONE_TO_MANY = "jakarta.persistence.OneToMany";
  private static final String COLUMN = "jakarta.persistence.Column";
  private static final String EMBEDDED = "jakarta.persistence.Embedded";
  private static final String ENTITY = "jakarta.persistence.Entity";

  public static boolean isPrimitiveOrWrapper(Class<?> clazz) {
    return clazz.isPrimitive() || isPrimitiveWrapper(clazz);
  }

  /**
   * 클래스에 선언된 모든 필드를 return
   *
   * @param targetClass
   * @return
   */
  public static Field[] getAllFields(Class<?> targetClass, boolean includeStatic) {
    List<Field> allFields = new ArrayList();
    boolean eof = false;
    Class<?> currentClass = targetClass;
    while (!eof) {
      Field[] fields = currentClass.getDeclaredFields();
      if (ArrayUtils.isNotEmpty(fields)) {
        for (Field field : fields) {
          boolean isStatic = Modifier.isStatic(field.getModifiers());

          if (!includeStatic) {
            if (isStatic) {
              continue;
            }
          }
          allFields.add(field);
        }
      }

      if (currentClass.getSuperclass() != null) {
        currentClass = currentClass.getSuperclass();
      } else {
        eof = true;
      }
    }

    return allFields.toArray(new Field[0]);
  }


  /**
   * Field에 정의된 Annotation 반환
   *
   * @param fieldInfo
   * @return
   */
  public static List<Annotation> getDeclaredAnnotationsOnField(FieldInfo fieldInfo) {
    List<Annotation> annotations = new ArrayList<>();
    List<AttributeInfo> attributes = fieldInfo.getAttributes();
    if (CollectionUtils.isNotEmpty(attributes)) {
      for (AttributeInfo info1 : attributes) {
        if (info1 instanceof AnnotationsAttribute) {
          for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
            annotations.add(anno);
          }
        }
      }
    }
    return annotations;
  }


  /**
   * 특정 필드에 특정 어노테이션이 존재하는지 여부
   *
   * @param ctField
   * @param annotationClass
   * @return
   */
  public static List<Annotation> getDeclaredAnnotationsOnField(CtField ctField, Class<?> annotationClass) {
    return getDeclaredAnnotationsOnFieldByClassName(ctField, annotationClass.getName());
  }

  public static List<Annotation> getDeclaredAnnotationsOnFieldByClassName(CtField ctField, String annotationClassName) {
    FieldInfo fieldInfo = ctField.getFieldInfo();
    List<AttributeInfo> attributes = fieldInfo.getAttributes();
    boolean hasAnnotation = false;
    List<Annotation> annotations = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(attributes)) {
      for (AttributeInfo info1 : attributes) {
        if (info1 instanceof AnnotationsAttribute) {
          for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
            annotations.add(anno);
            if (anno.getTypeName().equals(annotationClassName)) {
              hasAnnotation = true;
            }
          }
        }
      }
    }

    if (hasAnnotation) {
      return annotations;
    }
    return null;
  }

  /**
   * 클래스파일에 지정된 어노테이션을 가져온다
   *
   * @param classFile
   * @param typeClassName
   * @return
   */
  public static Annotation getDeclaredAnnotationOnType(ClassFile classFile, String typeClassName) {
    List<?> attributes = classFile.getAttributes();

    Iterator<?> itr = attributes.iterator();
    CHECK_DO_TRANSFORM:
    while (itr.hasNext()) {
      Object object = itr.next();

      if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
        try {
          Annotation[] annotations = ((AnnotationsAttribute) object).getAnnotations();
          for (Annotation annotation : annotations) {
            if (annotation.getTypeName().equals(typeClassName)) {
              return annotation;
            }
          }
        }catch (Exception e) {
          return null;
        }
      }
    }
    return null;
  }

  /**
   * 현재 load되는 Class에 붙은 어노테이션 중 특정 어노테이션이 있는지
   *
   * @param annotations    Class에 정의된 annotations
   * @param typeClassNames 찾을 typeClass
   * @return
   */
  public static boolean containsAnnotation(Annotation[] annotations, String... typeClassNames) {
    for (Annotation annotation : annotations) {
      return containsAnnotation(annotation, typeClassNames);
    }
    return false;
  }

  /**
   * 현재 load되는 Class에 붙은 어노테이션 중 특정 어노테이션이 있는지
   *
   * @param annotation     annotation
   * @param typeClassNames 찾을 typeClass
   * @return
   */
  public static boolean containsAnnotation(Annotation annotation, String... typeClassNames) {
    return ArrayUtils.contains(typeClassNames, annotation.getTypeName());
  }

  /**
   * 현재 load 되는 Class에 SubCollection 이 정의되어 있는지
   *
   * @param annotations
   * @return
   */
  public static boolean containsSubCollectionAnnotation(Annotation[] annotations) {
    for (Annotation annotation : annotations) {
      if (annotation.getTypeName().equals(ONE_TO_MANY)
          || annotation.getTypeName().equals(MANY_TO_ONE)
          || annotation.getTypeName().equals(MANY_TO_MANY)) {
        return true;
      }
    }
    return false;
  }

  /**
   * 대상 className 이 List, Map, Set 등 인터페이스인 경우 기본 타입 지정
   *
   * @param className
   * @return
   */
  public static String getImplementationType(String className) {
    if (className.equals("java.util.List")) {
      return "java.util.ArrayList";
    } else if (className.equals("java.util.Map")) {
      return "java.util.HashMap";
    } else if (className.equals("java.util.Set")) {
      return "java.util.HashSet";
    } else if (className.contains("[")) {
      return null;
    }

    return className;
  }

  /**
   * transformed 된 메소드의 이름을 unique 하게 하기 위함 이미 동일한 메소드가 class transformed 됐을 때 다시 하지 않도록 할 때 사용한다.
   *
   * @param method
   * @return
   */
  public static String methodDescription(CtMethod method) {
    return method.getDeclaringClass().getName() + "|" + method.getName() + "|" + method.getSignature();
  }


  public static CtClass classFileToCtClass(ClassPool classPool, ClassFile classFile) throws IOException {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    DataOutputStream os = new DataOutputStream(bos);
    classFile.write(os);
    os.close();
    return classPool.makeClass(new ByteArrayInputStream(bos.toByteArray()), false);
  }

  /**
   * CtClass.isFrozen() 일 때도 안전하게 ClassFile 을 리턴한다.
   *
   * @param ctClass
   * @return
   */
  public static ClassFile getClassFileSafety(CtClass ctClass) {
    boolean alreadyFrozen = ctClass.isFrozen();
    if (alreadyFrozen) {
      ctClass.defrost();
    }

    ClassFile classFile = ctClass.getClassFile();

    if (alreadyFrozen) {
      ctClass.freeze();
    }
    return classFile;
  }

  /**
   * 열거된 interfaceClasses 를 모두 implement 한 경우 true 를 반환한다
   *
   * @param className
   * @param interfaceClasses
   * @return
   */
  public static boolean isImplements(String className, Class<?>... interfaceClasses) {
    try {
      CtClass clazz = getDefrostedCtClass(ClassPool.getDefault(), className);

      Set<CtClass> interfaces = getInterfaces(clazz, new HashSet<>());
      Set<CtClass> confirmed = new HashSet<>();
      for (CtClass interClass : interfaces) {
        for (Class<?> intClass : interfaceClasses) {
          if (intClass.getName().equals(interClass.getName())) {
            confirmed.add(interClass);
          }
        }
      }

      return interfaceClasses.length == confirmed.size();

    } catch (Exception e) {
      // nothing
      log.warn("Failed to calculate class implements interface. ClassName is " + className);
    }

    return false;

  }

  /**
   * 클래스에 정의된 모든 인터페이스를 Set 으로 반환한다.
   *
   * @param interfaces
   * @param classPool
   * @param clzName
   * @return
   * @throws ClassNotFoundException
   * @throws NotFoundException
   */
  public static Set<CtClass> getInterfaces(Set<CtClass> interfaces, ClassPool classPool, String clzName) throws ClassNotFoundException, NotFoundException {
    classPool.appendClassPath(new LoaderClassPath(Class.forName(clzName).getClassLoader()));
    CtClass ctClass = classPool.get(clzName);
    return getInterfaces(ctClass, interfaces);
  }

  public static Set<CtClass> getInterfaces(CtClass ctClass, Set<CtClass> interfaces) throws NotFoundException {
    interfaces.add(ctClass);

    if (ArrayUtils.isNotEmpty(ctClass.getInterfaces())) {
      for (CtClass ctInterface : ctClass.getInterfaces()) {
        getInterfaces(ctInterface, interfaces);
      }
    }

    return interfaces;
  }

  public static Set<CtClass> getAllInterfaces(ClassPool classPool, String clzName) throws Exception {
    classPool.appendClassPath(new LoaderClassPath(Class.forName(clzName).getClassLoader()));
    CtClass ctClass = classPool.get(clzName);
    return getAllInterfaces(ctClass);
  }

  /**
   * 대상 클래스와 대상 클래스의 super 클래스를 포함한 모든 인터페이스를 리턴한다.
   *
   * @param targetClass
   * @return
   */
  public static Set<CtClass> getAllInterfaces(CtClass targetClass) throws Exception {
    Set<CtClass> allInterfaces = new HashSet<>();

    // 먼저 이 클래스와 super class 를 대상 클래스로 지정한다.
    // 단, super 클래스가 이미 @Entity 어노테이션을 가진 경우는 대상에서 제외한다.
    Set<CtClass> targetClasses = collectClassHierarchy(targetClass, new HashSet<>(), true);

    // 다음으로 대상 클래스 전체의 인터페이스를 조회한다.
    for (CtClass ctClass : CollectionUtils.emptyIfNull(targetClasses)) {
      allInterfaces = getInterfaces(ctClass, allInterfaces);
    }

    // 마지막으로 인터페이스가 아닌 abstract 이나 기타 class 를 모두 제거한다.
    CollectionUtils.emptyIfNull(allInterfaces).removeIf(clazz -> !clazz.isInterface());

    return allInterfaces;
  }

  public static Set<CtClass> collectClassHierarchy(CtClass ctClass, Set<CtClass> classHierarchy) throws Exception {
    if (ctClass == null || classHierarchy.contains(ctClass)) {
      return new HashSet<>();
    }

    // Add the current class
    classHierarchy.add(ctClass);

    // Collect super class
    CtClass superClass = ctClass.getSuperclass();
    if (superClass != null) {
      return collectClassHierarchy(superClass, classHierarchy);
    }

    // Collect interfaces
    CtClass[] interfaces = ctClass.getInterfaces();
    for (CtClass iface : interfaces) {
      return collectClassHierarchy(iface, classHierarchy);
    }

    return classHierarchy;
  }

  public static Set<CtClass> collectClassHierarchy(CtClass ctClass, Set<CtClass> classHierarchy, boolean excludeEntityClass) throws Exception {
    if (ctClass == null || classHierarchy.contains(ctClass)) {
      return new HashSet<>();
    }


    // Add the current class
    classHierarchy.add(ctClass);

    // Collect super class
    CtClass superClass = ctClass.getSuperclass();
    if (superClass != null) {

      superClass.defrost();

      if (excludeEntityClass) {
        // ctClass 에 @Entity 어노테이션이 있는지 확인하고 있으면 빈 HashSet 을 리턴한다.
        Annotation entityAnnotation = getDeclaredAnnotationOnType(superClass.getClassFile(), ENTITY);
        if (entityAnnotation == null) {
          return collectClassHierarchy(superClass, classHierarchy, true);
        }
      }

    }

    // Collect interfaces
    CtClass[] interfaces = ctClass.getInterfaces();
    for (CtClass iface : interfaces) {
      return collectClassHierarchy(iface, classHierarchy);
    }

    return classHierarchy;
  }

  public static Set<CtClass> collectSuperClass(CtClass ctClass) throws Exception {
    Set<CtClass> classes = collectClassHierarchy(ctClass, new HashSet<>());
    if (CollectionUtils.isEmpty(classes)) {
      return classes;
    }
    Iterator<CtClass> iterator = classes.iterator();
    while (iterator.hasNext()) {
      CtClass superClass = iterator.next();
      // 인터페이스와 자기 자신은 제외한다.
      if (superClass.isInterface() || superClass.getName().equals(ctClass.getName())) {
        iterator.remove();
      }
    }
    return classes;
  }

  public static CtClass getDefrostedCtClass(ClassPool classPool, String className) throws NotFoundException {
    CtClass ctClass = classPool.get(className);
    boolean freeze = ctClass.isFrozen();
    if (freeze) {
      ctClass.defrost();
    }
    return ctClass;
  }

  public static Class getClassByName(String className) {
    return getClassByName(className, true);
  }

  public static Class getClassByName(String className, boolean throwException) {
    try {
      return Class.forName(className);
    } catch (ClassNotFoundException e) {
      if (throwException) {
        return null;
        // throw new RuntimeException();
      } else {
        // suppressed exception
        return null;
      }
    }
  }

  public static <T> T getTargetObject(Object proxy, Class<T> targetClass) throws Exception {
    if (AopUtils.isJdkDynamicProxy(proxy)) {
      return (T) ((Advised) proxy).getTargetSource().getTarget();
    } else {
      return (T) proxy; // expected to be cglib proxy then, which is simply a specialized class
    }
  }

  /**
   * 어노테이션에서 특정 프로퍼티의 값을 String 으로 리턴한다.
   *
   * @param annotation
   * @param propertyName
   * @return
   */
  public static String getStringValue(Annotation annotation, String propertyName) {
    MemberValue value = annotation.getMemberValue(propertyName);
    if (value != null) {
      return ((StringMemberValue) value).getValue();
    } else {
      return null;
    }
  }

  /**
   * 어노테이션에서 특정 프로퍼티의 값을 Boolean 으로 리턴한다.
   *
   * @param annotation
   * @param propertyName
   * @return
   */
  public static Boolean getBooleanValue(Annotation annotation, String propertyName) {
    MemberValue value = annotation.getMemberValue(propertyName);
    if (value != null) {
      return ((BooleanMemberValue) value).getValue();
    } else {
      return null;
    }
  }

  /**
   * 어노테이션에서 특정 프로퍼티의 값을 Integer 로 리턴한다.
   *
   * @param annotation
   * @param propertyName
   * @return
   */
  public static Integer getIntegerValue(Annotation annotation, String propertyName) {
    MemberValue value = annotation.getMemberValue(propertyName);
    if (value != null) {
      return ((IntegerMemberValue) value).getValue();
    } else {
      return null;
    }
  }

  public static int getIntValue(Annotation annotation, String propertyName, int defaultValue) {
    Integer value = getIntegerValue(annotation, propertyName);
    return (value == null) ? defaultValue : value;
  }

  public static Field getSingleField(Class<?> clazz, String fieldName) throws IllegalStateException {
    try {
      return clazz.getDeclaredField(fieldName);
    } catch (NoSuchFieldException nsf) {
      // Try superclass
      if (clazz.getSuperclass() != null) {
        return getSingleField(clazz.getSuperclass(), fieldName);
      }

      return null;
    }
  }


  public static byte[] getClassFileBuffer(Class<?> clazz) {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    ObjectOutputStream out = null;
    try {
      out = new ObjectOutputStream(bos);
      out.writeObject(clazz);
      out.flush();
      return bos.toByteArray();
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    } finally {
      try {
        bos.close();
      } catch (IOException ex) {
        // ignore close exception
      }
    }
  }

  public static boolean isAssignableFrom(CtClass clazz, String superClassName) {

    if (clazz.getName().equals(superClassName)) {
      return true;
    }

    try {
      if (clazz.getSuperclass() == null) {
        return false;
      } else {
        return isAssignableFrom(clazz.getSuperclass(), superClassName);
      }
    } catch (NotFoundException e) {
      // null
    }

    return false;

  }

  /**
   * FieldInfo의 getDescriptor() 에서 클래스를 꺼내올 때, descriptor 를 제대로 된 클래스 이름으로 변환하는 메소드
   *
   * @param className
   * @return
   */
  public static String getProperClassName(String className, boolean normalize) {
    if (normalize) {
      return RegExUtils.removeAll(StringUtils.removeStart(
          StringUtils.replace(className, "/", ".")
          , "L"), ";");
    } else {
      return StringUtils.join("L", StringUtils.replace(className, ".", "/"), ";");
    }

  }

  public static Class getProperClass(String className, boolean normalize) {
    String name = getProperClassName(className, normalize);
    return getClassByName(name);
  }

  public static String getAnnotationTypeName(FieldInfo fieldInfo) {
    List<Annotation> annotations = getDeclaredAnnotationsOnField(fieldInfo);
    for (Annotation annotation : annotations) {
      if (annotation.getTypeName().equals(ONE_TO_MANY)) {
        return ONE_TO_MANY;
      } else if (annotation.getTypeName().equals(MANY_TO_ONE)) {
        return MANY_TO_ONE;
      } else if (annotation.getTypeName().equals(MANY_TO_MANY)) {
        return MANY_TO_MANY;
      } else if (annotation.getTypeName().equals(EMBEDDED)) {
        return EMBEDDED;
      }
    }
    return COLUMN;
  }

  public static List<Annotation> getDeclaredAnnotationsOnMethod(MethodInfo info) {
    List<Annotation> annotations = new ArrayList<>();
    List<AttributeInfo> attributes = info.getAttributes();
    if (CollectionUtils.isNotEmpty(attributes)) {
      for (AttributeInfo info1 : attributes) {
        if (info1 instanceof AnnotationsAttribute) {
          for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
            annotations.add(anno);
          }
        }
      }
    }
    return annotations;
  }

  public static List<Annotation> getDeclaredAnnotationsOnFieldByClassName(CtMethod ctMethod, String annotationClassName) {
    MethodInfo methodInfo = ctMethod.getMethodInfo();
    List<AttributeInfo> attributes = methodInfo.getAttributes();
    boolean hasAnnotation = false;
    List<Annotation> annotations = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(attributes)) {
      for (AttributeInfo info1 : attributes) {
        if (info1 instanceof AnnotationsAttribute) {
          for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
            annotations.add(anno);
            if (anno.getTypeName().equals(annotationClassName)) {
              hasAnnotation = true;
            }
          }
        }
      }
    }

    if (hasAnnotation) {
      return annotations;
    }
    return null;
  }

  /**
   * Infer target entity class from field's generic type signature
   * Used when @OneToMany annotation doesn't specify targetEntity
   */
  public static Class<?> inferTargetEntityFromFieldType(FieldInfo fieldInfo) {
    String className = inferTargetEntityClassNameFromFieldType(fieldInfo);
    if (className != null) {
      try {
        return Class.forName(className);
      } catch (ClassNotFoundException e) {
        log.warn("Failed to load inferred target entity class: {}", className);
      }
    }
    return null;
  }

  /**
   * Infer target entity class name from field's generic type signature without loading the class
   * Used when @OneToMany annotation doesn't specify targetEntity
   */
  public static String inferTargetEntityClassNameFromFieldType(FieldInfo fieldInfo) {
    try {
      // Get field signature attribute for generic type information
      SignatureAttribute signatureAttr = (SignatureAttribute) fieldInfo.getAttribute(SignatureAttribute.tag);

      if (signatureAttr != null) {
        String signature = signatureAttr.getSignature();

        // Parse signature like "Ljava/util/List<Lio/rchemist/common/search/data/testdata/TestEntity;>;"
        // or "Ljava/util/Map<Ljava/lang/String;Lkr/ac/gjcu/admission/domain/AdmissionAttribute;>;"
        // Extract the generic type parameter
        if (signature.contains("<") && signature.contains(">")) {
          int startIndex = signature.indexOf('<') + 1;
          int endIndex = signature.lastIndexOf('>');

          if (startIndex > 0 && endIndex > startIndex) {
            String genericType = signature.substring(startIndex, endIndex);

            // Check if this is a Map type (has two type parameters separated by semicolon)
            if (signature.contains("java/util/Map") && genericType.contains(";")) {
              // For Map, we need the second type parameter (value type)
              // genericType is like "Ljava/lang/String;Lkr/ac/gjcu/admission/domain/AdmissionAttribute;"
              int semicolonIndex = genericType.indexOf(';');
              if (semicolonIndex > 0 && semicolonIndex < genericType.length() - 1) {
                // Extract everything after the first semicolon
                genericType = genericType.substring(semicolonIndex + 1);
              }
            }

            // Convert JVM signature format to class name
            // "Lio/rchemist/common/search/data/testdata/TestEntity;" -> "io.rchemist.common.search.data.testdata.TestEntity"
            if (genericType.startsWith("L") && genericType.endsWith(";")) {
              String className = genericType.substring(1, genericType.length() - 1).replace('/', '.');
              return className;
            }
          }
        }
      }

      // Fallback: try to infer from field descriptor
      String descriptor = fieldInfo.getDescriptor();

      // For simple cases like List or Set without explicit generic info in descriptor
      // This is a best-effort approach
      Class<?> fieldType = BytecodeUtil.getProperClass(descriptor, true);

      if (fieldType != null && (java.util.Collection.class.isAssignableFrom(fieldType) || java.util.Map.class.isAssignableFrom(fieldType))) {
        log.warn("Cannot infer target entity from field '{}' - no generic type information available. Please specify targetEntity explicitly in @OneToMany annotation.", fieldInfo.getName());
      }

    } catch (Exception e) {
      log.warn("Failed to infer target entity from field '{}': {}", fieldInfo.getName(), e.getMessage());
    }

    return null;
  }
}
