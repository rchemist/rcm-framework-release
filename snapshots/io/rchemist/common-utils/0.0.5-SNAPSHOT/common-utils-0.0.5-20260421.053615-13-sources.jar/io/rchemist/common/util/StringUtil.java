/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import com.google.common.base.Ascii;
import com.google.common.base.CaseFormat;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@SuppressWarnings("unused")
public class StringUtil {

  public static boolean isBlank(String str) {
    if(StringUtils.isBlank(str)) return true;
    return StringUtils.equals(str, "null") || StringUtils.equals(str, "NULL");
  }

  public static boolean containsAny(String str, String... compare){
    if(str == null || str.isEmpty())
      return ArrayUtils.isEmpty(compare);

    if(ArrayUtils.isEmpty(compare))
      return false;

    return StringUtils.containsAnyIgnoreCase(str, compare);
  }

  public static String startWithUpperCase(String str){
    if(StringUtils.isEmpty(str))
      return str;
    return StringUtils.upperCase(String.valueOf(str.charAt(0))) + StringUtils.substring(str, 1);
  }

  public static boolean startsWith(String str, String... compare){
    if(ArrayUtils.isEmpty(compare))
      return false;
    for(String com : compare){
      if(StringUtils.startsWith(str, com)){
        return true;
      }
    }
    return false;
  }

  public static String camelCaseToSnakeCase(String camel, boolean upperCase){
    camel = StringUtils.replace(camel, "-", "_");
    StringBuilder sb = new StringBuilder();
    int length = camel.length();

    for(int i = 0; i < length; ++i) {
      if (Ascii.isUpperCase(camel.charAt(i)) && !sb.isEmpty()) {
        sb.append("_");
      }
      sb.append((upperCase) ? Ascii.toUpperCase(camel.charAt(i)) : Ascii.toLowerCase(camel.charAt(i)));
    }

    return sb.toString();
  }

  /**
   * 주어진 문자열을 대문자의 CAMEL CASE로 변경한다
   *
   * @param value
   * @param defaultValue
   * @return
   */
  public static String toUpperCamelCase(String value, String defaultValue) {
    if(StringUtils.isNotEmpty(value)){
      // 첫글자를 대문자로 변경
      String first = value.substring(0, 1);
      first = first.toUpperCase();
      value = first + value.substring(1);
    }
    return CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, StringUtil.toString(value, defaultValue));
  }

  public static String toUpperCamelCase(String value) {
    return toUpperCamelCase(value, value);
  }

  /**
   * 주어진 문자열을 lowerCamelCase로 변환한다.
   * 기본적으로는 com.google.common.base.CaseFormat 를 사용한다.
   * 단, separatorChars 가 있다면 해당 구분자를 기준으로 camelCase 처리 한다.
   *
   * @param value
   * @param defaultValue
   * @param separatorChars
   * @return
   */
  public static String toLowerCamelCase(String value, String defaultValue, String separatorChars) {
    if (StringUtils.isNotBlank(separatorChars)) {
      String[] strs = StringUtils.split(StringUtils.lowerCase(value), separatorChars);
      String lowerCamel = strs[0];
      for (int i = 1; i < strs.length; i++) {
        lowerCamel = StringUtils.join(lowerCamel, StringUtils.upperCase(StringUtils.substring(strs[i], 0, 1)), StringUtils.substring(strs[i], 1));
      }
      return lowerCamel;
    } else {
      return CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_CAMEL, StringUtil.toString(value, defaultValue));
    }
  }

  public static String toLowerCamelCase(String value) {
    return toLowerCamelCase(value, value, "_");
  }


  public static String[] trim(String... array) {
    return trim(false, true, array);
  }

  public static String[] trim(boolean includeEmpty, String... array) {
    return trim(includeEmpty, true, array);
  }

  /**
   * String[] 에서 null 을 제거해 Trim 후 반환한다
   *
   * @param includeEmpty
   * @param array
   * @return
   */
  public static String[] trim(boolean includeEmpty, boolean trim, String... array) {
    return Arrays.stream(array)
        .filter(Objects::nonNull)
        .map(
            e -> getString(e, trim)
        )
        .filter(e1 -> isNotBlank(e1, includeEmpty))
        .toArray(String[]::new);
  }

  private static String getString(String e, boolean trim) {
    return (trim) ? (StringUtils.isBlank(e)) ? e : StringUtils.trim(e) : e;
  }

  private static boolean isNotBlank(String e, boolean include) {
    return (include) || StringUtils.isNotBlank(e);
  }

  public static String merge(String... strings) {
    if(ArrayUtils.isEmpty(strings))
      return null;
    return Arrays.stream(strings)
        .filter(Objects::nonNull)         // null check 추가
        .collect(Collectors.joining());
  }

  public static String mergeWithSplitCode(String delimiter, String... strings){
    if(ArrayUtils.isEmpty(strings))
      return null;
    return Arrays.stream(strings)
        .filter(Objects::nonNull)         // null check 추가
        .collect(Collectors.joining(StringUtil.toString(delimiter)));
  }

  public static String mergeWithWordFix(String delimiter, String prefix, String postFix, String... strings){
    if(ArrayUtils.isEmpty(strings))
      return null;

    // set default value to not null
    delimiter = StringUtil.toString(delimiter);
    prefix = StringUtil.toString(prefix);
    postFix = StringUtil.toString(postFix);

    StringBuilder sb = new StringBuilder();
    int i = 0;
    for(String str : strings){
      if(StringUtils.isNotEmpty(str)){
        if(i>0){
          sb.append(delimiter);
        }
        sb.append(prefix);
        sb.append(str);
        sb.append(postFix);
      }
      i++;
    }
    return sb.toString();
  }

  /**
   * 엔터, 줄바꿈, "|" 와 같은 문자를 "," 로 치환한 다음, "," 를 기준으로 split 한다
   * @param str
   * @param allowSpace
   * @return
   */
  public static String[] getMultipleStringValues(final String str, boolean allowSpace){
    List<String> result = new ArrayList<>();

    if(str != null && !str.equals("")){
      List<String> searchStr = CollectionUtil.list("\r\n", "\r", "\n", "|");
      if(allowSpace){
        searchStr.add(" ");
      }

      String[] arr = getSplitStrings(str, searchStr.toArray(new String[0]));

      Arrays.stream(arr).forEachOrdered(s -> {
        if (StringUtils.isNotBlank(s) || allowSpace) {
          result.add(s);
        }
      });
    }

    return (CollectionUtils.isNotEmpty(result)) ? result.toArray(new String[0]) : new String[0];
  }

  private static String[] getSplitStrings(String str, String[] search) {
    String replaced = StringUtils.replaceEachRepeatedly(str, search, Arrays.stream(search).map(s -> ",").toArray(String[]::new));
    return StringUtils.split(replaced, ",");
  }

  public static String getExceptionStackTrace(Exception exception) {
    StringWriter stringWriter = new StringWriter();
    try{
      PrintWriter printWriter = new PrintWriter(stringWriter);
      exception.printStackTrace(printWriter);
      return stringWriter.toString();
    }catch(Exception e){
      return StringUtil.toString(exception.getMessage(), null);
    }
  }

  public static String[] splitWithNonEmpty(String str, String splitCode) {
    String replaced = StringUtils.replace(str, " ", "");   // 공백 치환
    replaced = StringUtils.remove(replaced, "\r");
    replaced = StringUtils.remove(replaced, "\n");
    replaced = (StringUtils.endsWith(replaced, splitCode)) ? StringUtils.removeEnd(replaced, splitCode) : replaced;
    return splitArray(replaced, splitCode);
  }

  public static String[] splitWithTrim(String str, String splitCode, boolean includeEmpty) {
    String[] values = StringUtils.split(str, splitCode);
    if(ArrayUtils.isNotEmpty(values)){
      List<String> newValues = new ArrayList<>();
      for(String value : values){
        String trimmed;
        if(includeEmpty){
          trimmed = StringUtils.trim(value);
        }else{
          trimmed = StringUtils.trimToNull(value);

        }

        if(trimmed != null){
          newValues.add(value);
        }
      }
      return newValues.toArray(new String[0]);
    }
    return new String[]{};
  }

  public static String[] splitArray(String strArray, String splitCode){
    if(StringUtils.isEmpty(strArray))
      return null;
    splitCode = StringUtil.toString(splitCode, ",");

    if(StringUtils.contains(strArray, splitCode)){
      return StringUtils.splitByWholeSeparatorPreserveAllTokens(strArray, splitCode);

    }else{
      return new String[]{strArray};
    }
  }

  @SuppressWarnings("null")
  public static List<String> split(String strArray, String splitCode){
    List<String> list = new ArrayList<>();
    if(StringUtils.isEmpty(strArray))
      return list;

    String[] array = splitArray(strArray, splitCode);

    if(array == null)
      return list;

    for(String arr : array){
      String value = StringUtils.trim(arr);
      if(StringUtils.isNotEmpty(value)){
        list.add(StringUtils.trim(arr));
      }

    }

    return list;
  }

  public static String merge(List<? extends Serializable> list, String splitCode) {
    if(CollectionUtils.isEmpty(list))
      return null;
    splitCode = StringUtil.toString(splitCode, ",");
    StringBuilder sb = new StringBuilder();
    int i = 0;
    for(Object id : list){
      if(i > 0){
        sb.append(splitCode);
      }
      sb.append(id);
      i++;
    }
    return sb.toString();
  }

  public static <T> T fromJson(String json, Class<T> objectClass) {
    if(json == null)
      return null;
    return GsonUtil.fromJson(json, objectClass);
  }

  public static <T> String toJson(T object) {
    if(object ==  null)
      return null;
    String json = GsonUtil.toJson(object);
    return StringEscapeUtils.unescapeJava(json);
  }

  public static <T> String toJson(T object, boolean includeNull) {
    if(object ==  null)
      return null;

    if(includeNull){
      return GsonUtil.toJson(object);
    }else{
      return GsonUtil.toJson(object);
    }
  }

  @SuppressWarnings("unused")
  public static String mergeIfAbsence(String text, String prefix, String postfix, boolean mergeIfNull){
    if(!mergeIfNull && text == null){
      return null;
    }

    text = StringUtil.toString(text);   // to null safe
    prefix = StringUtil.toString(prefix);
    postfix = StringUtil.toString(postfix);

    if(!StringUtils.startsWith(text, prefix)){
      text = prefix + text;
    }

    if(!StringUtils.endsWith(text, postfix)){
      text = text + postfix;
    }

    return text;
  }

  public static String fill(String s, int length) {
    return String.valueOf(s).repeat(Math.max(0, length));
  }

  public static String fill(String str, String fill, int length){
    if(StringUtils.isEmpty(str))
      return fill(fill, length);
    if(str.length() >= length)
      return str;
    return fill(fill, length - str.length()) + str;
  }

  public static String sanitize(String string) {
    if (string == null) {
      return "NULL";
    }
    String sanitized = string.replace('\n', '_').replace('\r', '_');
    return Jsoup.clean(sanitized, Safelist.none());
  }

  public static boolean equalsAny(String string, String... strs) {
    if(string == null || ArrayUtils.isEmpty(strs)){
      return false;
    }

    for(String str : strs){
      if(StringUtils.equals(string, str)){
        return true;
      }
    }

    return false;
  }

  public static boolean isNotEmptyAtLeastOne(String... strings){
    if(ArrayUtils.isEmpty(strings))
      return false;

    for(String string : strings){
      if(StringUtils.isNotEmpty(string)){
        return true;
      }
    }

    return false;
  }

  public static boolean isNotEmpty(String... strings) {
    if(ArrayUtils.isEmpty(strings))
      return false;

    for(String string : strings){
      if(StringUtils.isEmpty(string)){
        return false;
      }
    }

    return true;
  }

  public static boolean isBlankAtLeastOne(String... strs){
    if(ArrayUtils.isEmpty(strs))
      return true;
    for(String str : strs){
      if(StringUtils.isBlank(str)){
        return true;
      }
    }
    return false;
  }

  public static String subStringBefore(String name, String prefix) {
    return subStringBefore(name, prefix, null);
  }
  public static String subStringBefore(String name, String prefix, String defaultStr) {
    if(!StringUtils.contains(name, prefix)){
      return (defaultStr == null) ? name : defaultStr;
    }else{
      return StringUtils.substringBefore(name, prefix);
    }
  }

  public static String subStringBeforeLast(String name, String prefix) {
    return subStringBeforeLast(name, prefix, null);
  }

  public static String subStringBeforeLast(String name, String prefix, String defaultStr) {
    if(!StringUtils.contains(name, prefix)){
      return (defaultStr == null) ? name : defaultStr;
    }else{
      return StringUtils.substringBeforeLast(name, prefix);
    }
  }

  public static String subStringAfter(String name, String prefix) {
    return subStringAfter(name, prefix, null);
  }

  public static String subStringAfter(String name, String prefix, String defaultStr) {
    if(!StringUtils.contains(name, prefix)){
      return (defaultStr == null) ? name : defaultStr;
    }else{
      return StringUtils.substringAfter(name, prefix);
    }
  }

  public static String subStringAfterLast(String name, String prefix) {
    return subStringAfterLast(name, prefix, null);
  }
  public static String subStringAfterLast(String name, String prefix, String defaultStr) {
    if(!StringUtils.contains(name, prefix)){
      return (defaultStr == null) ? name : defaultStr;
    }else{
      return StringUtils.substringAfterLast(name, prefix);
    }
  }

  public static Map<String, String> splitMap(String metaHeader, String lineSeparator, String columnSeparator) {
    Map<String, String> headers = new HashMap<>();
    for(String line : split(metaHeader, lineSeparator)){
      List<String> items = split(line, columnSeparator);
      String key = items.get(0);
      String value = "";
      if(items.size() > 1){
        value = items.get(1);
      }
      headers.put(key, value);
    }
    return headers;
  }

  public static String between(String str, String start, String end) {
    str = subStringAfter(str, start);
    str = subStringBefore(str, end);
    return str;
  }

  public static String removeBetween(String str, String start, String end) {
    if(StringUtils.isEmpty(str))
      return str;
    if(StringUtils.isNotEmpty(start)){
      str = StringUtils.removeStart(str, start);
    }

    if(StringUtils.isNotEmpty(end)){
      str = StringUtils.removeEnd(str, end);
    }
    return str;
  }

  public static String trimBytes(String str, int byteLength){
    return trimBytes(str, StandardCharsets.UTF_8, byteLength);
  }

  public static String trimBytes(String str, Charset charset, int maxByteLength){
    byte[] bytes = str.getBytes(charset);
    int current = 0;
    for(int i = 0; i< str.length() -1; i++){
      if(isDoubleByteCharacter(str.substring(i, i+1))){
        if(current + 2 > maxByteLength){
          break;
        }
        current += 2;
      }else{
        if(current + 1 > maxByteLength){
          break;
        }
        current += 1;
      }
    }
    return new String(bytes, 0, current);
  }

  public static boolean isDoubleByteCharacter(String str){
    for(int i = 0; i < str.length(); i++){
      if(Character.getType(str.charAt(i)) == Character.OTHER_LETTER){
        return true;
      }
    }
    return false;
  }

  public static String getRandomString(String str, int length){
    StringBuilder sb = new StringBuilder();

    char[] chars = str.toCharArray();
    for(int i = 0; i < length; i++){
      sb.append(chars[(int) (Math.random() * chars.length)]);
    }

    return sb.toString();
  }

  public static String cleanXss(String value){
    if(StringUtils.isBlank(value))
      return value;

    return Jsoup.clean(value, Safelist.relaxed());
  }


  public static String replaceExactMatch(String str, String compare, String replace) {
    if(StringUtils.equals(str, compare)){
      return replace;
    }else{
      return str;
    }
  }

  public static String splitAndGetNotEmptyLast(String origin, String matched){
    List<String> list = split(origin, matched);

    if(CollectionUtils.isEmpty(list))
      return "";

    if(list.size() == 1)
      return origin;

    int max = list.size() -1;

    return getNotEmptyString(list, max);


  }

  public static String getNotEmptyString(List<String> list, int max) {
    if(StringUtils.isNotBlank(list.get(max))){
      return list.get(max);
    }else{
      if(max == 0){
        return "";
      }else{
        max--;
        return getNotEmptyString(list, max);
      }
    }
  }

  public static String appendEndIfMissed(String originStr, String character) {
    if(!originStr.endsWith(character)){
      return originStr + character;
    }else{
      return originStr;
    }
  }

  public static String getString(Object value) {

    if(value == null)
      return null;

    if(value instanceof String){
      return (String) value;
    }else{
      return String.valueOf(value);
    }

  }

  private static final String EMPTY_STRING = "";

  public static String toString(Object value) {
    return toString(value, EMPTY_STRING);
  }

  /**
   * 문자열이 null 이거나 empty 이면 defaultValue 를 반환한다.
   * apache 의 StringUtils.defaultString 이 Objects.toString 으로 변경이 되어 isEmpty 에 대한 처리를 하지 못한다.
   * @param value
   * @param defaultValue
   * @return
   */
  public static String toString(Object value, String defaultValue) {
    String strValue = getString(value);

    if (strValue == null || strValue.isEmpty())
      return defaultValue;

    return strValue;
  }


  /**
   * 주어진 문자열이 정규식인지 확인
   * @param regex
   * @return
   */
  public static boolean isRegexPattern(String regex) {
    try {
      Pattern.compile(regex);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

}
