/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 **/
public class DateUtil {

  private final static String SIMPLE_DATE_FORMAT = "yyyyMMdd";
  public static final String COMPATIBILITY_FORMAT = "MM/dd/yy HH:mm a Z";
  public static final String DATE_FORMAT = "MM/dd/yyyy HH:mm";

  public static Date getDate(Object value){
    return getDate(value, new Date());
  }

  public static Date getDate(Object value, Date defaultValue){
    Date date;
    try{
      if(value instanceof Date){
        date = (Date) value;
      }else if(value instanceof LocalDateTime) {
        date = LocalDateTimeUtil.getDate((LocalDateTime) value);
      }else if(value instanceof String){
        date = parseDate((String) value, defaultValue);
      }else{
        date = defaultValue;
      }
    }catch (Exception e){
      date = defaultValue;
    }
    return date;
  }

  public static Date parseDate(String date, Date defaultValue)  {
    Date parsedDate;
    try {
      parsedDate = FormatUtil.getTimeZoneFormat().parse(date);
    } catch (Exception e) {

      TimeZone timeZone = TimeZoneUtil.getTimeZone();

      try {
        SimpleDateFormat formatter = new SimpleDateFormat(COMPATIBILITY_FORMAT);
        formatter.setTimeZone(timeZone);
        parsedDate = formatter.parse(date);
      } catch (Exception e1) {
        try {
          SimpleDateFormat formatter = new SimpleDateFormat(SIMPLE_DATE_FORMAT);
          formatter.setTimeZone(timeZone);
          parsedDate = formatter.parse(date);
        } catch (Exception e2) {
          parsedDate = defaultValue;
        }
      }
    }
    return parsedDate;
  }

  public static String format(Date date, String format) {
    if(date == null) {
      return "";
    }

    SimpleDateFormat sdf;
    if(StringUtils.isBlank(format)) {
      sdf = new SimpleDateFormat(SIMPLE_DATE_FORMAT);
    } else {
      sdf = new SimpleDateFormat(format);
    }

    return sdf.format(date);
  }

  /**
   * 현재 날짜가 두 날짜 사이에 존재하는지 확인, 두 날짜 모두 null 인 경우 defaultValue 반환
   * @param targetDate : 비교 대상 날짜
   * @param availableAt : 비교 날짜 시작일
   * @param availableUntil : 비교 날짜 종료일
   * @param defaultValue
   * @return
   */
  public static Boolean compare(Date targetDate, Date availableAt, Date availableUntil, Boolean defaultValue){
    if(targetDate==null) {
      targetDate = new Date();
    }

    LocalDateTime dateTime = LocalDateTimeUtil.asLocalDateTime(targetDate);
    LocalDateTime datetime1;
    LocalDateTime datetime2;
    if(availableAt!=null&&availableUntil!=null){
      datetime1 = LocalDateTimeUtil.asLocalDateTime(availableAt);
      datetime2 = LocalDateTimeUtil.asLocalDateTime(availableUntil);
    }else{
      if(availableAt!=null){
        availableUntil = targetDate;
        datetime1 = LocalDateTimeUtil.asLocalDateTime(availableAt);
        datetime2 = LocalDateTimeUtil.asLocalDateTime(availableUntil);
      }else{
        // 모두 null 일 때는 defaultValue
        return defaultValue;
      }

    }

    Boolean bool = dateTime.isAfter(datetime1) && (dateTime.isBefore(datetime2) || dateTime.isEqual(datetime2));
    return bool;
  }

  /**
   *
   * @param date
   * @param minute
   * @return
   */
  public static Boolean compare(Date date, Integer minute){
    if(date==null) date = new Date();

    int min = 1000*60;
    Long c1 = date.getTime();				// 비교 대상 시각
    Long c2 = (new Date()).getTime();		// 현재 시각

    Long c3 = (c2 - c1)/min;
    return (c3<=minute);

  }

  public static Date getDate(Date date, Date defaultDate){
    return (date == null) ? defaultDate : date;
  }


  public static Date parseDateWithFormat(String value, String format){
    try {
      return org.apache.commons.lang3.time.DateUtils.parseDate(String.valueOf(value), format);
    } catch (ParseException e) {
      ExceptionUtil.printStackTrace(e);
    }
    return null;
  }

  public static Date add(Date date, int calendarField, int amount) {
    if (date == null) {
      throw new IllegalArgumentException("The date must not be null");
    }
    Calendar c = Calendar.getInstance();
    c.setTime(date);
    c.add(calendarField, amount);
    return c.getTime();
  }

  public static Date min(Date date) {
    return LocalDateTimeUtil.getDate(LocalDateTimeUtil.asLocalDate(date).atTime(LocalTime.MIN));
  }

  public static Date max(Date date) {
    return LocalDateTimeUtil.getDate(LocalDateTimeUtil.asLocalDate(date).atTime(LocalTime.MAX));
  }

}
