/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class IdList<ID> implements Serializable {

  public IdList() {

  }

  public boolean contains(ID id) {
    if (id == null) {
      return false;
    }
    if (ids == null || ids.isEmpty()) {
      return false;
    }
    return ids.contains(id);
  }

  public IdList<ID> add(ID id) {
    if (id == null) {
      return this;
    }
    if (ids == null) {
      ids = new ArrayList<>();
      ids.add(id);
      return this;
    }

    if (ids.contains(id)) {
      return this;
    }

    ids.add(id);
    return this;
  }

  public IdList<ID> remove(ID id) {
    if (id == null) {
      return this;
    }
    if (ids == null || ids.isEmpty()) {
      return this;
    }
    if (ids.contains(id)) {
      ids.remove(id);
    }
    return this;
  }

  public IdList(List<ID> ids) {
    this.ids = ids;
  }

  public IdList(ID... ids) {
    this.ids = List.of(ids);
  }

  private List<ID> ids;

  private String cause;

  public IdList<ID> withCause(String cause) {
    this.cause = cause;
    return this;
  }

  public IdList<ID> withIds(List<ID> ids) {
    this.ids = ids;
    return this;
  }

  public boolean isEmpty(){
    return CollectionUtils.isEmpty(ids);
  }

  public ID[] toArray(){
    if (CollectionUtils.isEmpty(ids))
      return null;
    return (ID[]) ids.toArray();
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    IdList<?> idList = (IdList<?>) object;

    return new EqualsBuilder().append(ids, idList.ids)
        .append(cause, idList.cause).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(ids).append(cause).toHashCode();
  }
}
