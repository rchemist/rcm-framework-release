/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.util.ArrayUtil;
import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
public class TrieNode{

  protected TreeMap<Integer, Node> nodes = new TreeMap<>();
  protected Integer[] arrayLength;

  public TrieNode putNode(char ch){
    if(MapUtils.isNotEmpty(nodes)){
      Map.Entry<Integer, Node> entry = nodes.lastEntry();

      Node node = entry.getValue();
      if(node.getCharacter() == ch){
        // 같으면 len을 늘려 준다
        node.setLength(node.getLength()+1);
      }else{
        int seq = node.getSequence()+1;
        nodes.put(seq, new Node(seq, 1, ch));
      }

    }else{
      nodes.put(1, new Node(1, 1, ch));
    }

    return this;
  }

  public TrieNode putNodes(char[] chars) {
    for(char ch : chars){
      putNode(ch);
    }
    this.arrayLength = ArrayUtil.addArray(this.arrayLength, chars.length);
    return this;
  }

  @Getter
  @Setter
  @AllArgsConstructor
  public class Node implements Serializable {

    private static final long serialVersionUID = -8109356488324005663L;

    protected int sequence;
    protected int length;
    protected char character;

    public RandomCharEnumType getRandomCharEnumType(){
      switch (String.valueOf(character)){
        case "@" : {return RandomCharEnumType.ALPHABET;}
        case "#" : {return RandomCharEnumType.NUMERIC;}
        case "!" : {return RandomCharEnumType.SPECIAL;}
        case "*" : {return RandomCharEnumType.CHARACTER;}
        case "^" : {return RandomCharEnumType.CHARACTER_SPECIAL;}
      }
      return RandomCharEnumType.CHARACTER;
    }

  }

}