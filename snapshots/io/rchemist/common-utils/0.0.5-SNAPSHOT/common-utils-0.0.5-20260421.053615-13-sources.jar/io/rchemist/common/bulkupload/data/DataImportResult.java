/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.bulkupload.data;

import io.rchemist.common.bulkupload.data.DataImportError.DataImportErrorComparator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter(AccessLevel.PRIVATE)
public class DataImportResult implements Serializable {

  public DataImportResult() {
    this(0);
  }

  public DataImportResult(Integer requested){
    this.requested = requested;
  }

  protected final Integer requested;

  protected Integer created = 0;

  protected Integer updated = 0;

  protected Integer failed = 0;

  protected List<DataImportError> errors = new ArrayList<>();

  public DataImportResult withCreated(Integer created) {
    this.created = created;
    return this;
  }

  public DataImportResult withUpdated(Integer updated) {
    this.updated = updated;
    return this;
  }

  public DataImportResult addCreated(Integer created){
    if(created != null && created > 0){
      this.created = this.created + created;
    }
    return this;
  }

  public DataImportResult addUpdated(Integer updated){
    if(updated != null && updated > 0){
      this.updated = this.updated + updated;
    }
    return this;
  }

  public DataImportResult addFailed(Integer failed){
    if(failed != null && failed > 0){
      this.failed = this.failed + failed;
    }
    return this;
  }

  public DataImportResult withFailed(Integer failed) {
    this.failed = failed;
    return this;
  }

  public DataImportResult withErrors(
      List<DataImportError> errors) {
    this.errors = errors;
    return this;
  }

  public boolean hasError() {
    return CollectionUtils.isNotEmpty(this.errors);
  }

  public DataImportResult addError(DataImportError... errors) {
    if (errors != null && ArrayUtils.isNotEmpty(errors)) {
      this.errors.addAll(List.of(errors));
      this.errors.sort(new DataImportErrorComparator());
    }
    return this;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    DataImportResult that = (DataImportResult) object;

    return new EqualsBuilder().append(requested, that.requested)
        .append(created, that.created).append(updated, that.updated).append(failed, that.failed)
        .append(errors, that.errors).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(requested).append(created).append(updated)
        .append(failed).append(errors).toHashCode();
  }

  @Override
  public String toString() {
    return "DataImportResult{" +
        "requested=" + requested +
        ", created=" + created +
        ", updated=" + updated +
        ", failed=" + failed +
        ", errors=" + errors +
        '}';
  }
}
