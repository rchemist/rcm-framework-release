/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ZipUtil {

  public static void compress(String path, String outputFileName) throws IOException {

    File file = new File(path);

    String[] files;

    if (file.isDirectory()) {
      files = file.list();
    } else {
      files = new String[1];
      files[0] = file.getName();
    }

    int size = 2048;
    byte[] buf = new byte[size];

    String outZipNm = path + outputFileName;
    FileInputStream fis = null;
    ZipArchiveOutputStream zos = null;
    BufferedInputStream bis = null;

    try {
      zos = new ZipArchiveOutputStream(new BufferedOutputStream(new FileOutputStream(outZipNm)));
      for (int i = 0; i < files.length; i++) {
        if (new File(path + "/" + files[i]).isDirectory()) {
          continue;
        }

        zos.setEncoding("UTF-8");
        fis = new FileInputStream(path + "/" + files[i]);
        bis = new BufferedInputStream(fis, size);
        zos.putArchiveEntry(new ZipArchiveEntry(files[i]));

        int len;
        while ((len = bis.read(buf, 0, size)) != -1) {
          zos.write(buf, 0, len);
        }

        bis.close();
        fis.close();
        zos.closeArchiveEntry();
      }
      zos.close();
    } catch (FileNotFoundException e) {
      ExceptionUtil.printStackTrace(e);
    } finally {
      if (zos != null) zos.close();
      if (fis != null) fis.close();
      if (bis != null) bis.close();
    }
  }

  public static void decompress(String zipFileName, String directory) throws Exception {

    File zipFile = new File(zipFileName);
    FileInputStream fis = null;
    ZipInputStream zis = null;
    ZipEntry zipentry;

    try {
      fis = new FileInputStream(zipFile);
      zis = new ZipInputStream(fis);
      while ((zipentry = zis.getNextEntry()) != null) {
        String filename = zipentry.getName();
        File file = new File(directory, filename);

        if (zipentry.isDirectory()) {
          file.mkdirs();
        } else {
          createFile(file, zis);
        }
      }
    } catch (Throwable throwable) {
      throw throwable;
    } finally {
      if (zis != null) zis.close();
      if (fis != null) fis.close();
    }

  }

  private static void createFile(File file, ZipInputStream zis) throws Exception {
    File parentDir = new File(file.getParent());
    if (!parentDir.exists()) {
      parentDir.mkdirs();
    }
    try (FileOutputStream fos = new FileOutputStream(file)) {
      byte[] buffer = new byte[256];
      int size = 0;
      while ((size = zis.read(buffer)) > 0) {
        fos.write(buffer, 0, size);
      }
    } catch (Throwable e) {
      throw e;
    }
  }

}
