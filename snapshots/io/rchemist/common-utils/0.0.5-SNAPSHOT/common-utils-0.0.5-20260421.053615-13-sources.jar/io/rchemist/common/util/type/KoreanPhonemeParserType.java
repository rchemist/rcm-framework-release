/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.util.parser.DefaultKoreanPhonemeParser;
import io.rchemist.common.util.parser.KoreanConsonantParser;
import io.rchemist.common.util.parser.KoreanPhonemeParser;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class KoreanPhonemeParserType implements Serializable {

  private static final Map<String, KoreanPhonemeParserType> TYPES = new ConcurrentHashMap<>();

  public static final KoreanPhonemeParserType PHONEME = new KoreanPhonemeParserType("PHONEME", "자음 모음", new DefaultKoreanPhonemeParser());
  public static final KoreanPhonemeParserType CONSONANT = new KoreanPhonemeParserType("CONSONANT", "초성", new KoreanConsonantParser());


  protected String type;
  protected String friendlyType;
  protected KoreanPhonemeParser parser;

  public KoreanPhonemeParserType(String type, String friendlyType, KoreanPhonemeParser parser) {
    this.type = type;
    this.friendlyType = friendlyType;
    this.parser = parser;
    TYPES.put(type, this);
  }


  public KoreanPhonemeParser getParser() {
    return parser;
  }

  public String getType() {
    return type;
  }

  public String getFriendlyType() {
    return friendlyType;
  }

  public static KoreanPhonemeParserType getKoreanPhonemeParserType(String type){
    return TYPES.get(type);
  }

  public static boolean containsKey(String type){
    return TYPES.containsKey(type);
  }

}
