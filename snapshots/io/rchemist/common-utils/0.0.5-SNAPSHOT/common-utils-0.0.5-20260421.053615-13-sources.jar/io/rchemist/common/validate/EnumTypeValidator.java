/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.validate;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class EnumTypeValidator implements ConstraintValidator<ValidEnumType, String> {

  private ValidEnumType annotation;

  @Override
  public void initialize(ValidEnumType constraintAnnotation) {
    this.annotation = constraintAnnotation;
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {

    boolean result = false;

    List<EnumType<?>> types = EnumTypeUtil.getEnumTypes(this.annotation.enumTypeClass());
    for(EnumType<?> type : CollectionUtils.emptyIfNull(types)){
      if(type.getType().equals(value)){
        result = true;
        break;
      }
    }

    return result;
  }
}
