/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <p>
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * </p>
 **/
public class MessageDigestUtil {

  public static String digest(String algorithm, String message, int radix){
    String digest;
    try {
      MessageDigest md = MessageDigest.getInstance(algorithm);
      byte[] messageDigest = md.digest(message.getBytes());
      BigInteger number = new BigInteger(1, messageDigest);
      digest = number.toString(radix);
    } catch (NoSuchAlgorithmException e) {
      throw new RuntimeException(e);
    }
    return digest;
  }

}
