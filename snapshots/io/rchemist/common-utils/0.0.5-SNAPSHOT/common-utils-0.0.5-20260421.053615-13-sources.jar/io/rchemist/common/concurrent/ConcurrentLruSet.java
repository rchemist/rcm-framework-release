/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.concurrent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class ConcurrentLruSet<E> {

  private final LinkedHashMap<E, Boolean> map;
  private final ReentrantLock lock = new ReentrantLock();
  private final int maxSize;
  private final boolean moveToTop;

  /**
   * Constructor with a specified maximum size and behavior.
   *
   * @param maxSize    the maximum number of elements the set can hold
   * @param moveToTop  if true, most recently accessed elements move to the top
   */
  public ConcurrentLruSet(int maxSize, boolean moveToTop) {
    if (maxSize <= 0) {
      throw new IllegalArgumentException("Max size must be greater than 0");
    }
    this.maxSize = maxSize;
    this.moveToTop = moveToTop;

    // Initialize the LinkedHashMap with appropriate order
    this.map = new LinkedHashMap<>(16, 0.75f, !moveToTop) {
      @Override
      protected boolean removeEldestEntry(Map.Entry<E, Boolean> eldest) {
        return size() > ConcurrentLruSet.this.maxSize;
      }
    };
  }

  /**
   * Adds the specified element to this set.
   *
   * @param element the element to add
   * @return true if the element was added, false if it was already present
   */
  public boolean add(E element) {
    lock.lock();
    try {
      return map.put(element, Boolean.TRUE) == null;
    } finally {
      lock.unlock();
    }
  }

  /**
   * Removes the specified element from this set.
   *
   * @param element the element to remove
   * @return true if the element was removed, false otherwise
   */
  public boolean remove(E element) {
    lock.lock();
    try {
      return map.remove(element) != null;
    } finally {
      lock.unlock();
    }
  }

  /**
   * Checks if the set contains the specified element.
   *
   * @param element the element to check
   * @return true if the set contains the element, false otherwise
   */
  public boolean contains(E element) {
    lock.lock();
    try {
      boolean exists = map.containsKey(element);
      if (exists && moveToTop) {
        // Reinsert the element to move it to the top
        map.remove(element);
        map.put(element, Boolean.TRUE);
      }
      return exists;
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns the current size of the set.
   *
   * @return the size of the set
   */
  public int size() {
    lock.lock();
    try {
      return map.size();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Checks if the set is empty.
   *
   * @return true if the set is empty, false otherwise
   */
  public boolean isEmpty() {
    lock.lock();
    try {
      return map.isEmpty();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Clears all elements from the set.
   */
  public void clear() {
    lock.lock();
    try {
      map.clear();
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns the elements in the set as a list in LRU order.
   *
   * @return a list of elements in LRU order
   */
  public List<E> toList() {
    lock.lock();
    try {
      return new ArrayList<>(map.keySet());
    } finally {
      lock.unlock();
    }
  }

  /**
   * Returns a string representation of this set.
   *
   * @return a string representation of this set
   */
  @Override
  public String toString() {
    lock.lock();
    try {
      return map.keySet().toString();
    } finally {
      lock.unlock();
    }
  }

}
