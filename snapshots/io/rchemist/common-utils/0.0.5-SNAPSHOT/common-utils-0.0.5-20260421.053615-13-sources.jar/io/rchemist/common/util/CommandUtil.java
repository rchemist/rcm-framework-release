/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.File;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.Executor;
import org.apache.commons.exec.PumpStreamHandler;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CommandUtil {

  public static void executeCommandLine(CommandLine cmdLine, File workingDirectory, Integer timeout, String... arguments) throws Exception{
    if(ArrayUtils.isNotEmpty(arguments)){
      for(String argument: arguments){
        cmdLine.addArgument(argument);
      }
    }
    Executor executor = new DefaultExecutor();

    PumpStreamHandler streamHandler = new PumpStreamHandler(System.out);
    if(timeout != null){
      streamHandler.setStopTimeout(timeout);
    }

    if(workingDirectory != null){
      executor.setWorkingDirectory(workingDirectory);
    }

    executor.setStreamHandler(streamHandler);

    executor.execute(cmdLine);
  }

  public static void execute(File command, File workingDirectory, Integer timeout, String... arguments) throws Exception{
    executeCommandLine(new CommandLine(command), workingDirectory, timeout, arguments);
  }

  public static void execute(String command, File workingDirectory, Integer timeout, String... arguments) throws Exception {
    executeCommandLine(new CommandLine(command), workingDirectory, timeout, arguments);
  }

}
