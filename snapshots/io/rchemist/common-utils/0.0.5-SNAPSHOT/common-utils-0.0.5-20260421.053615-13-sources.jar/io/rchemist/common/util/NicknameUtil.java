/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * <p>
 * project : headless-cms
 * <p>
 * Created by kunner
 **/
public class NicknameUtil {

  private static final List<String> ADJECTIVES = Arrays.asList("가벼운", "강력한", "강한", "거친", "건강한", "경쾌한", "고약한", "고요한", "과감한", "교활한", "귀여운", "길쭉한", "깊은", "날씬한", "낮은", "낯선", "냉정한", "넓은", "네모난", "높은", "느긋한", "느린", "느릿한", "단단한", "단순한", "달콤한", "독특한", "둔한", "둥근", "따뜻한", "딱딱한", "똑똑한", "뚜렷한", "뜨거운", "마른", "맑은", "매운", "멋진", "명랑한", "명석한", "못생긴", "무거운", "미묘한", "복잡한", "부서진", "빛나는", "빠른", "사랑의", "산뜻한", "상큼한", "새로운", "소박한", "소심한", "솔직한", "순수한", "슬픈", "시원한", "신비의", "씩씩한", "아픈", "악동", "얕은", "어두운", "어두운", "연약한", "예리한", "예민한", "예쁜", "오래된", "온화한", "용감한", "우아한", "웃기는", "유쾌한", "음울한", "재밌는", "재빠른", "정직한", "조용한", "좁은", "즐거운", "지루한", "진지한", "차가운", "차분한", "친근한", "친절한", "침울한", "통통한", "퉁명한", "튼튼한", "푸른", "푹신한", "한가한", "행복한", "향기의", "화려한", "환한", "활기찬", "활발한");

  private static final List<String> NOUNS = Arrays.asList("강물", "강아지", "거북이", "고래", "고양이", "공원", "공주", "괴물", "구름", "국화", "군인", "궁수", "금강석", "기린", "기사", "기사단", "까마귀", "나무", "나비", "낙타", "눈꽃", "늑대", "닌자", "다람쥐", "다리", "다이아", "당근", "도깨비", "도시", "도적", "독수리", "돌고래", "돌고래", "동굴", "두더지", "드래곤", "들판", "로봇", "루비", "마법사", "마을", "목련", "무사", "문어", "물개", "민들레", "바다", "바람", "부엉이", "불꽃", "사령관", "사막", "사슴", "사신", "사자", "산호", "상어", "성기사", "수달", "수정", "시내", "악마", "암살자", "언덕", "얼룩말", "여우", "여치", "연꽃", "왕자", "요정", "용사", "원숭이", "유니콘", "유령", "은하수", "장미", "전사", "정글", "조개", "좀비", "진주", "참새", "천사", "초원", "치타", "코끼리", "탐정", "태양", "토끼", "판다", "펭귄", "폭포", "표범", "하늘", "해마", "해변", "해적", "해적", "호랑이", "호수");

  private static final Random RANDOM = new Random();

  public static String getRandomNickname() {
    return getRandomNickname(false, true);
  }

  public static String getRandomNickname(boolean postfix, boolean limitLength) {
    while (true) {
      String adjective = ADJECTIVES.get(RANDOM.nextInt(ADJECTIVES.size()));
      String noun = NOUNS.get(RANDOM.nextInt(NOUNS.size()));
      String nickname = adjective + " " +  noun;
      if (limitLength) {
        // 최대 5글자를 넘어서는 안 된다.
        if (nickname.length() <= 6) {
          if (postfix) {
            return nickname + RANDOM.nextInt(90) + 10;
          }
          return nickname;
        }
      } else {
        return postfix ? nickname + RANDOM.nextInt(90) + 10 : nickname;
      }
    }
  }


}
