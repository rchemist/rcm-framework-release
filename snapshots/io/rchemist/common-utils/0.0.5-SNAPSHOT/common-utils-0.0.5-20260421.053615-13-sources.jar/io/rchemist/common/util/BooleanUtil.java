/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class BooleanUtil {

  public static Boolean getBooleanValue(String str, Boolean defaultValue){
    Boolean bool = BooleanUtils.toBooleanObject(str);
    return (bool == null) ? defaultValue : bool;
  }

  public static Boolean getBooleanValue(Boolean bool, Boolean defaultValue){
    return (bool == null) ? defaultValue : bool;
  }

  public static Boolean getBooleanValue(Object obj, Boolean defaultValue){

    if(obj == null)
      return defaultValue;

    if(obj instanceof Boolean)
      return (Boolean) obj;

    if(obj.getClass().equals(boolean.class)){
      return Boolean.valueOf((boolean) obj);
    }

    if(obj instanceof String)
      return getBooleanValue(String.valueOf(obj), defaultValue);

    if(obj instanceof Integer || obj.getClass().equals(int.class)){
      return BooleanUtils.toBoolean(Integer.valueOf(String.valueOf(obj)));    // o is false, other is true
    }

    return defaultValue;

  }

  public static boolean isBoolean(Object value) {
    if(value == null)
      return false;
    if(value instanceof Boolean || boolean.class.isAssignableFrom(value.getClass())){
      return true;
    }
    return false;
  }
}
