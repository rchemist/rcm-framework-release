/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.bulkupload.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class DataExportRequest<S> implements Serializable {

  public DataExportRequest(S searchForm, LinkedHashMap<String, String> properties) {
    this.searchForm = searchForm;
    this.properties = properties;
  }

  protected S searchForm;

  protected String cause;

  protected LinkedHashMap<String, String> properties;

  protected List<String> selectedItemIds;

  public DataExportRequest<S> withCause(String cause) {
    this.cause = cause;
    return this;
  }

  public DataExportRequest<S> withSearchForm(S searchForm) {
    this.searchForm = searchForm;
    return this;
  }

  public DataExportRequest<S> withSelectedItemIds(List<String> selectedItemIds) {
    this.selectedItemIds = selectedItemIds;
    return this;
  }

  public List<Long> getSelectedItemIdsAsLong() {
    List<Long> ids = new ArrayList<>();
    for (String id : selectedItemIds) {
      if(StringUtils.isNumeric(id)) {
        ids.add(Long.valueOf(id));
      }
    }
    return ids;
  }
}
