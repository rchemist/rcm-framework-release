/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class PropertyUtil {

  public static boolean isNotBlank(Properties properties) {
    return properties != null && properties.size() > 0;
  }

  public static boolean isBlank(Properties properties) {
    return !isNotBlank(properties);
  }

  /**
   * 복수의 프로퍼티를 순차로 merge
   *
   * @param overwrite
   * @param properties
   * @return
   */
  public static Properties merge(boolean overwrite, Properties... properties) {

    if (overwrite) {
      return Stream.of(properties)
          .collect(Properties::new, Map::putAll, Map::putAll);
    } else {

      Properties origin = null;
      Properties[] sources = new Properties[0];
      for (int i = 0; i < properties.length; i++) {
        if (isNotBlank(properties[i])) {
          origin = properties[i];
          System.arraycopy(properties, i, sources, properties.length - 1, properties.length - i);
          break;
        }
      }

      if (isBlank(origin)) {
        return new Properties();
      } else {
        if (ArrayUtils.isEmpty(sources)) {
          return origin;
        } else {

          final Properties finalOrigin = origin;

          for (int i = 0; i < sources.length; i++) {
            Properties source = sources[i];
            if (isNotBlank(source)) {
              source.forEach((k, v) -> {
                mergePropertyValue(finalOrigin, k, v, true);
              });
            }
          }

          return finalOrigin;
        }
      }
    }
  }

  public static Properties mergePropertyValue(Properties finalOrigin, Object k, Object v, boolean overwrite) {
    if (overwrite || !finalOrigin.containsKey(k)) {
      finalOrigin.put(k, v);
    }
    return finalOrigin;
  }

  public static Properties replace(Properties properties, String originKey, String replaceKey, boolean removeOrigin) {
    if (properties.getProperty(originKey) != null) {
      if (properties.getProperty(replaceKey) == null) {
        properties.put(replaceKey, properties.getProperty(originKey));
      }
      if (removeOrigin) {
        properties.remove(originKey);
      }
    }
    return properties;
  }

  public static Properties remove(Properties properties, String originKey) {
    if (properties.getProperty(originKey) != null) {
      properties.remove(originKey);
    }
    return properties;
  }

  /**
   * 구분자를 "." 로 자동으로 셋팅해 #separateByPrefixUsingSeparator 를 호출한다
   *
   * @param properties
   * @param declaredPrefix
   * @return
   */
  public static Map<String, Properties> separateByPrefix(String defaultPrefix, Properties properties, String... declaredPrefix) {
    return separateByPrefixUsingSeparator(".", defaultPrefix, properties, declaredPrefix);
  }

  /**
   * Properties 의 모든 key 를 확인해 key의 문자열이 declaredPrefix 로 시작하는지 확인해
   * 같은 prefix 를 가진 Properties 끼리 모은다
   *
   * @param separator
   * @param properties
   * @param declaredPrefix
   * @return
   */
  public static Map<String, Properties> separateByPrefixUsingSeparator(String separator, String defaultPrefix, Properties properties, String... declaredPrefix) {

    Iterator<Map.Entry<Object, Object>> iterators = properties.entrySet().iterator();
    Map<String, Properties> parsedProps = new HashMap<>();
    while (iterators.hasNext()) {

      Map.Entry<Object, Object> entry = iterators.next();

      String key = (String) entry.getKey();
      String value = (String) entry.getValue();

      PropertyIdentifier identifier =
          PropertyIdentifier.builder()
              .key(key)
              .value(value)
              .declaredPrefix(declaredPrefix)
              .defaultPrefix(defaultPrefix)
              .separator(separator)
              .build();

      if(ArrayUtils.contains(declaredPrefix, identifier.getPrefix())){
        parsedProps = separateProperty(parsedProps, identifier);
      }
    }

    return parsedProps;
  }

  private static Map<String, Properties> separateProperty(Map<String, Properties> map, PropertyIdentifier identifier) {
    if (!identifier.isBlankKey()) {
      Properties props;
      if (!identifier.isBlankPrefix()) {
        if (map.containsKey(identifier.getPrefix())) {
          props = map.get(identifier.getPrefix());
          props.put(identifier.getKey(), identifier.getValue());
        } else {
          props = new Properties();
          props.setProperty(identifier.getKey(), identifier.getValue());
        }
        map.put(identifier.getPrefix(), props);
      }
    }
    return map;
  }

}
