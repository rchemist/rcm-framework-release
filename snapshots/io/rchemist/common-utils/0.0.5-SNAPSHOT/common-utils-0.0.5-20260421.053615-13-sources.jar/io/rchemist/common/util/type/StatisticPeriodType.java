/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class StatisticPeriodType extends EnumType<StatisticPeriodType> {

  public static final StatisticPeriodType HOURLY = new StatisticPeriodType(1, "HOURLY", "Hourly", "1시간 당", "global.type.order.aggregate.type.hourly", true);
  public static final StatisticPeriodType DAILY = new StatisticPeriodType(2, "DAILY", "Daily", "1일 당", "global.type.order.aggregate.type.daily", true);
  public static final StatisticPeriodType WEEKLY = new StatisticPeriodType(3, "WEEKLY", "Weekly", "1주 당(Sun-Sat)", "global.type.order.aggregate.type.weekly", false);
  public static final StatisticPeriodType MONTHLY = new StatisticPeriodType(4, "MONTHLY", "Monthly", "1개월 당", "global.type.order.aggregate.type.monthly", false);
  public static final StatisticPeriodType YEARLY = new StatisticPeriodType(5, "YEARLY", "Yearly", "1년 당", "global.type.order.aggregate.type.yearly", false);

  /**
   * 이 OrderAggregateType 의 집계를 처리할 때,
   * 주문 데이터에서 집계할지(true), 기존에 쌓인 OrderAggregate 에서 집계할지(false)
   */
  @Getter
  private final boolean aggregateFromOrder;

  public StatisticPeriodType(int order, String type, String friendlyType, String description, String messageKey, boolean aggregateFromOrder) {
    super(order, type, friendlyType, description, messageKey);
    this.aggregateFromOrder = aggregateFromOrder;
  }
}
