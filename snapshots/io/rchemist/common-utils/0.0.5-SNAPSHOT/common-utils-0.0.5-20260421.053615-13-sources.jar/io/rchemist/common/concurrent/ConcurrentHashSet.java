/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.concurrent;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class ConcurrentHashSet<E> {

  private final ConcurrentHashMap<E, Boolean> map;

  /**
   * Default constructor. Creates a set with default initial capacity.
   */
  public ConcurrentHashSet() {
    this.map = new ConcurrentHashMap<>();
  }

  /**
   * Constructor with initial capacity.
   *
   * @param initialCapacity the initial capacity of the set
   */
  public ConcurrentHashSet(int initialCapacity) {
    this.map = new ConcurrentHashMap<>(initialCapacity);
  }

  /**
   * Adds the specified element to this set if it is not already present.
   *
   * @param element element to be added to this set
   * @return true if this set did not already contain the specified element
   */
  public boolean add(E element) {
    return map.putIfAbsent(element, Boolean.TRUE) == null;
  }

  /**
   * Removes the specified element from this set if it is present.
   *
   * @param element object to be removed from this set, if present
   * @return true if this set contained the specified element
   */
  public boolean remove(E element) {
    return map.remove(element) != null;
  }

  /**
   * Returns true if this set contains the specified element.
   *
   * @param element element whose presence in this set is to be tested
   * @return true if this set contains the specified element
   */
  public boolean contains(E element) {
    return map.containsKey(element);
  }

  /**
   * Returns the number of elements in this set.
   *
   * @return the number of elements in this set
   */
  public int size() {
    return map.size();
  }

  /**
   * Returns true if this set contains no elements.
   *
   * @return true if this set contains no elements
   */
  public boolean isEmpty() {
    return map.isEmpty();
  }

  /**
   * Removes all of the elements from this set.
   */
  public void clear() {
    map.clear();
  }

  /**
   * Returns a thread-safe view of this set as a standard Java Set.
   *
   * @return a thread-safe view of this set
   */
  public Set<E> toSet() {
    return Collections.newSetFromMap(map);
  }

  /**
   * Returns a thread-safe view of this set's elements as a Collection.
   *
   * @return a Collection of the elements in this set
   */
  public Collection<E> asCollection() {
    return map.keySet();
  }

  /**
   * Returns a string representation of this set.
   *
   * @return a string representation of this set
   */
  @Override
  public String toString() {
    return map.keySet().toString();
  }

}
