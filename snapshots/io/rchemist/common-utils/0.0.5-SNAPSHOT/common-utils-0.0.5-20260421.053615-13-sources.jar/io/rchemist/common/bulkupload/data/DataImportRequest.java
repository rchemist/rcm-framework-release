/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.bulkupload.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Slf4j
public class DataImportRequest implements Serializable {

  protected String cause;

  protected List<DataImportRow> rows = new ArrayList<>();

  protected Boolean refreshViewOnFinish = false;

  public DataImportRequest(List<String> headerFields, List<String[]> contents) {

    for (String[] items : CollectionUtils.emptyIfNull(contents)) {
      DataImportRow row = new DataImportRow();
      int fieldOrder = 0;
      for (String item : items) {
        row.addProperty(headerFields.get(fieldOrder++), item);
      }
      addRow(row);
    }

  }

  public DataImportRequest addRow(DataImportRow row) {
    if (row.hasProperties()) {
      this.rows.add(row);
    }
    return this;
  }

  protected int pageSize = 50;

  public DataImportRequest withRefreshViewOnFinish(Boolean refreshViewOnFinish) {
    this.refreshViewOnFinish = refreshViewOnFinish;
    return this;
  }

  public DataImportRequest withCause(String cause) {
    this.cause = cause;
    return this;
  }

  public DataImportResult requestImport(DataImportProcessor process) {
    int page = 0;

    DataImportResult result = new DataImportResult(this.rows.size());

    while (true) {

      List<DataImportRow> rows = getRowsByPageNumber(page);

      if (CollectionUtils.isEmpty(rows)) {
        break;
      }

      Integer prevCreated = result.getCreated();
      Integer prevUpdated = result.getUpdated();
      Integer prevFailed = result.getFailed();
      List<DataImportError> prevErrors = new ArrayList<>(result.getErrors());

      try {
        DataImportResult partResult = process.process(page, pageSize, rows);

        if (partResult == null) {
          continue;
        }

        result.addCreated(partResult.getCreated());
        result.addUpdated(partResult.getUpdated());
        result.addFailed(partResult.getFailed());

        if (partResult.hasError()) {
          result.addError(partResult.getErrors().toArray(new DataImportError[0]));
        }

      } catch (Exception e) {
        String errorMessage = getErrorMessage(page);

        // 에러가 나더라도 한 줄만 나야 한다.
        result = new DataImportResult(this.rows.size())
            .withCreated(prevCreated)
            .withUpdated(prevUpdated)
            .withFailed(prevFailed)
            .withErrors(prevErrors)
            .addFailed(rows.size())
            .addError(new DataImportError().withRow(0).withMessage(errorMessage));
      }

      page++;

    }

    return result;

  }

  private String getErrorMessage(int page) {
    String errorMessage = ((page * pageSize) + 1) + " ~ ";

    if (((page + 1) * pageSize) > this.rows.size()) {
      // 현재 페이지의 마지막 까지라면
      errorMessage += (this.rows.size()) + "번째 ";
    } else {
      errorMessage += (page * pageSize) + "번째 ";
    }
    errorMessage += "데이터를 입력 중 오류가 발생 했습니다.";
    return errorMessage;
  }

  public List<DataImportRow> getRowsByPageNumber(int page) {
    if (CollectionUtils.isEmpty(rows)) {
      return rows;
    }
    if (rows.size() < pageSize) {
      if (page > 0) {
        return null;
      } else {
        return rows;
      }
    }

    int totalCount = rows.size();
    int step = page * pageSize;

    if (step > totalCount) {
      return null;
    } else if (totalCount < step + pageSize) {
      return rows.subList(step, totalCount - 1);
    } else {
      return rows.subList(step, step + pageSize);
    }
  }

  public DataImportRow getRow(int rowNumber) {
    return getRow(null, rowNumber);
  }

  public DataImportRow getRow(Integer page, int rowNumber) {
    List<DataImportRow> rows = page != null ? getRowsByPageNumber(page) : getRows();
    try {
      return rows.get(rowNumber);
    } catch (Exception e) {
      log.warn("There is no row page: {}, {}", page, rowNumber);
      return null;
    }
  }

  public boolean hasData() {
    return CollectionUtils.isNotEmpty(rows);
  }

  public boolean isRefreshViewOnFinish() {
    return BooleanUtils.toBoolean(refreshViewOnFinish);
  }
}
