/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import lombok.Getter;

/**
 * I, L, 1, 0, Q, U, V 등 사람들이 혼동할만한 문자는 제거한다
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum RandomCharEnumType {

  ALPHABET(new char[] {
      'A', 'B', 'C', 'D', 'E', 'F', 'G',
      'H', 'J', 'K', 'M', 'N', 'P', 'R',
      'S', 'T', 'W', 'X', 'Y', 'Z'
  }),
  NUMERIC(new char[] {
      '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'
  }),
  SPECIAL(new char[]{
    '@','$','!','%','*','#','?','&','(',')','=','+','~','_','-'
  }),
  CHARACTER(new char[] {
      'A', 'B', 'C', 'D', 'E', 'F', 'G',
      'H', 'J', 'K', 'M', 'N', 'P', 'R',
      'S', 'T', 'W', 'X', 'Y', 'Z',
      '2', '3', '4', '5', '6', '7', '8', '9' }),
  CHARACTER_SPECIAL(new char[]{
      'A', 'B', 'C', 'D', 'E', 'F', 'G',
      'H', 'J', 'K', 'M', 'N', 'P', 'R',
      'S', 'T', 'W', 'X', 'Y', 'Z',
      '2', '3', '4', '5', '6', '7', '8', '9',
      '@','$','!','%','*','#','?','&','(',')','=','+','~','_','-'
  });

  @Getter
  private final char[] chars;

  RandomCharEnumType(char[] chars){
    this.chars = chars;
  }


}
