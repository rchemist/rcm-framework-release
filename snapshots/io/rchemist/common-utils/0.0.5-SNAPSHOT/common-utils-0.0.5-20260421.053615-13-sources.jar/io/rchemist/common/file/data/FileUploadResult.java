/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.data;

import io.rchemist.common.util.data.AssetMetadata;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileUploadResult implements Serializable {

  // 로컬에 저장된 파일이면 url 이 달라지지 않을 것이지만, cloud 에 저장된 파일이라면 cloud 의 cdn 정보를 포함된 url 을 전달한다.
  private String fullUrl;
  // 로컬에 저장된 파일인지 Cloud 에 저장된 파일인지
  private boolean localResource = false;
  // 실제 업로드된 파일 사이즈
  private long fileSize;

  private String mimeType;

  private AssetMetadata assetMetadata = new AssetMetadata();

}
