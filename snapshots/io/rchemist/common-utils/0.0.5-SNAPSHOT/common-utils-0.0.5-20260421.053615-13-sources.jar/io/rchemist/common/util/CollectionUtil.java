/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import jakarta.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by kunner
 **/
public class CollectionUtil {

  public static <T> List<T> getArrayList(Class<T> clazz) {
    return new ArrayList<>();
  }

  public static <T> List<T> getTypedList(Collection<T> inputCollection,
      TypedPredicate<T> predicate) {
    ArrayList<T> list = new ArrayList<T>(inputCollection.size());
    CollectionUtils.select(inputCollection, predicate, list);
    return list;
  }

  public static <T> List<T> list(T... t) {
    if (t == null) {
      return new ArrayList<>();
    }
    return Stream.of(t).collect(Collectors.toList());
  }

  public static <T> List<T> create(boolean nullable, T... tt) {
    if (nullable) {
      return list(tt);
    } else {
      List<T> list = new ArrayList<>();
      for (T t : tt) {
        if (t != null) {
          list.add(t);
        }
      }
      return list;
    }
  }


  @Nullable
  public static <T> T getFirst(Collection<T> resultList) {
    return getFirst(resultList, null);
  }

  @Nullable
  public static <T> T getFirst(Collection<T> resultList, Comparator<T> sort) {
    if (CollectionUtils.isNotEmpty(resultList)) {
      if (sort == null) {
        return resultList.stream().findFirst().orElse(null);
      }
      return resultList.stream().min(sort).orElse(null);
    }
    return null;
  }

  @Nullable
  public static <T> T getLast(Collection<T> resultList) {
    return getLast(resultList, null);
  }

  @Nullable
  public static <T> T getLast(Collection<T> resultList, Comparator<T> sort) {
    if (CollectionUtils.isNotEmpty(resultList)) {
      if (sort == null) {
        return resultList.stream().skip(resultList.size() - 1).findFirst().orElse(null);
      }
      return resultList.stream().max(sort).orElse(null);
    }
    return null;
  }

  @Nullable
  public static <T> T get(Collection<T> resultList) {
    return get(resultList, 0);
  }

  @Nullable
  public static <T> T get(Collection<T> resultList, int index) {
    return get(resultList, index, null);
  }

  @Nullable
  public static <T> T get(Collection<T> resultList, int index, Comparator<T> sort) {
    if (CollectionUtils.isNotEmpty(resultList)) {
      if (sort == null) {
        return resultList.stream().skip(index).findFirst().orElse(null);
      }
      return resultList.stream().skip(index).min(sort).orElse(null);
    }
    return null;
  }

  public static <T> boolean isContains(Collection<T> set1, Collection<T> set2, int minimumCount) {

    int containCount = 0;
    if (!(isEmpty(set1) || isEmpty(set2))) {

      if ((set1.size() > set2.size())) {
        containCount = getContainCount(containCount, set2, set1, minimumCount);
      } else {
        containCount = getContainCount(containCount, set1, set2, minimumCount);
      }

    }

    return minimumCount <= containCount;
  }

  private static <T> int getContainCount(int containCount, Collection<T> compareSet,
      Collection<T> targetSet, int minimumCount) {
    for (T s : compareSet) {
      if (targetSet.contains(s)) {
        containCount++;
        if (containCount >= minimumCount) {
          return containCount;
        }
      }
    }
    return containCount;
  }

  private static <T> boolean isEmpty(Collection<T> set1) {
    return set1 == null || set1.isEmpty() || set1.size() == 0;
  }

  public static <T> List<T> getPagedList(List<T> sourceList, int page, int pageSize) {
    if (pageSize < 0 || page < 0) {
      throw new IllegalArgumentException("invalid page size: " + pageSize);
    }

    int fromIndex = page * pageSize;
    if (sourceList == null || sourceList.size() < fromIndex) {
      return Collections.emptyList();
    }

    return sourceList.subList(fromIndex, Math.min(fromIndex + pageSize, sourceList.size()));
  }

  public static <T> List<T> getDistinctList(List<T> list) {
    if (list == null || list.isEmpty()) {
      return Collections.emptyList();
    }
    Set<T> set = new LinkedHashSet<>(list);
    return new ArrayList<>(set);
  }

}
