/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import java.time.ZoneId;
import java.time.ZoneOffset;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter(AccessLevel.PRIVATE)
@NoArgsConstructor
public class TimeZoneType {

  private String zoneId;

  private String offsetId;

  public TimeZoneType(String zoneId, ZoneOffset zoneOffset) {
    this.zoneId = zoneId;
    this.offsetId = zoneOffset.getId();
  }

  public ZoneOffset getZoneOffset() {
    return ZoneOffset.of(offsetId);
  }

  public ZoneId getZoneId() {
    return ZoneId.of(zoneId);
  }

}
