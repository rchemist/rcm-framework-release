/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * Map<String, 엔티티 RuleXref> 로 되어 있는 정보를 String 으로 변환하고, 다시 String 을 Map<String, String> 으로 변환
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class InlineRuleUtil {

  public static final String FIELD_SPLIT = ":::";
  public static final String LINE_SPLIT = "|||";
  public static final String RULE_SPLIT = "^^^";
  public static final String MATCH_RULE = "MATCH_RULE";
  public static final String KEY = "KEY";

  public static Map<String, String> getRuleValueMap(String inlineRuleValue) {
    if(StringUtils.isBlank(inlineRuleValue))
      return null;

    String[] ruleValues = StringUtils.split(inlineRuleValue, RULE_SPLIT);
    Map<String, String> ruleMap = new HashMap<>();

    for(String ruleValue : ruleValues){
      String key = null;
      String value = null;

      String[] fields = StringUtils.split(ruleValue, LINE_SPLIT);

      for(String field : fields){
        String[] fieldValues = StringUtils.split(field, FIELD_SPLIT);
        // BUG-014 fix (0.0.10.E): 구분자 누락된 malformed field 를 skip 해
        // ArrayIndexOutOfBoundsException 을 방지한다.
        if (fieldValues == null || fieldValues.length < 2) {
          continue;
        }
        if(StringUtils.contains(field, MATCH_RULE)){
          value = fieldValues[1];
        } else {
          key = fieldValues[1];
        }
      }

      if (key != null) {
        ruleMap.put(key, value);
      }

    }

    return ruleMap;
  }

  public static String getInlineRuleValue(String matchRule, String key){
    // BUG-014 fix (0.0.10.E): KEY 와 key 값 사이의 FIELD_SPLIT 가 누락되어 있어
    // 이 메서드로 생성된 inline rule 은 getRuleValueMap 에서 파싱 불가였다.
    // 의도된 포맷: "MATCH_RULE:::<matchRule>|||KEY:::<key>"
    return StringUtil.merge(MATCH_RULE, FIELD_SPLIT, matchRule, LINE_SPLIT, KEY, FIELD_SPLIT, key);
  }

}
