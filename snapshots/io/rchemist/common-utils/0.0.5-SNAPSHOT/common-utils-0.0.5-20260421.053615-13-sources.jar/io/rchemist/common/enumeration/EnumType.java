/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.enumeration;

import com.alibaba.fastjson.parser.ParserConfig;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;
import com.google.common.base.Ascii;
import com.google.common.base.MoreObjects;
import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.util.FastJsonUtil.EnumTypeAdapter;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NonNull;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
public abstract class EnumType<T> implements Serializable, Comparable<EnumType<T>> {

  /**
   * 이 클래스를 extends해 생성된 Custom EnumType 유형을 TYPES에 저장한다.
   * EnumType#getInstance(String key) 를 사용해 인스턴스 객체를 꺼내올 때 사용한다.
   */
  protected static final Map<String, LinkedHashMap<String, EnumType<?>>> TYPES = new ConcurrentHashMap<>();

  private static final String MESSAGE_KEY_PREFIX = "global.type";

  /**
   * 어떤 Type이 SubType을 가진 경우
   *
   * Key: type.getClass().getName() + type
   * Values: subTypes
   */
  protected static final Map<String, LinkedHashMap<String, EnumType<?>>> SUB_TYPES = new ConcurrentHashMap<>();   // null 허용 불가

  @JsonValue
  protected @NonNull String type;
  protected @NonNull String friendlyType;

  protected int order;
  /**
   * 식별용 정보, key/value 외에는 모두 nullable 이다
   */
  @Getter(AccessLevel.NONE)
  protected String description;
  /**
   * i18n 다국어 메시지용 messageProperties와 연동되는 key값
   */
  @Getter(AccessLevel.NONE)
  protected String messageKey;

  @Getter(AccessLevel.NONE)
  protected String translatedType;

  @JsonIgnore
  protected String appropriateMessageKey;

  public String getDescription(){
    return StringUtil.toString(description, friendlyType);
  }

  public String getMessageKey(){
    String messageKey = this.messageKey;

    if(StringUtils.isNotEmpty(messageKey) && !StringUtils.startsWith(messageKey, MESSAGE_KEY_PREFIX)){
      // global.type.user.restriction.type.ipaddress 형태가 되어야 한다.
      messageKey = getAppropriateMessageKey();
    }

    return StringUtil.toString(messageKey, friendlyType);
  }

  protected String getAppropriateMessageKey(){

    if(appropriateMessageKey == null){
      String name = getClass().getSimpleName();
      StringBuilder sb = new StringBuilder();
      sb.append(MESSAGE_KEY_PREFIX);
      int length = name.length();

      for(int i = 0; i < length; ++i) {
        if (Ascii.isUpperCase(name.charAt(i)) && sb.length() > 0) {
          sb.append(".");
        }
        sb.append(Ascii.toLowerCase(name.charAt(i)));
      }

      sb.append(".")
          .append(messageKey);

      appropriateMessageKey = sb.toString();
    }

    return appropriateMessageKey;
  }

  public String getTranslatedType(){
    // message key 로 번역된 문자열을 리턴한다
    String messageKey = getMessageKey();
    String translated = MessageSourceHelper.getMessage(messageKey);
    return (StringUtils.equals(messageKey, translated)) ? getDescription() : translated;
  }

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   * @param type
   * @param friendlyType
   * @param description
   * @param messageKey
   */
  public EnumType(int order, String type, String friendlyType, String description, String messageKey) {
    this.order = order;
    this.friendlyType = friendlyType;
    this.description = description;
    this.messageKey = mixPrefix(messageKey);
    setType(type);
  }

  private String mixPrefix(String messageKey) {
    return getPrefix() + messageKey;
  }

  /**
   * message key 를 등록할 때 prefix 를 자동으로 붙여 준다
   * @return
   */
  protected String getPrefix() {
    // override here
    return "";
  }

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   * @param type
   * @param friendlyType
   * @param description
   */
  public EnumType(String type, String friendlyType, String description) {
    this(100, type, friendlyType, description, friendlyType);
  }

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   * description 과 messageKey 를 하나로 사용하는 경우 이 생성자를 이용한다.
   * @param type
   * @param friendlyType
   */
  public EnumType(int order, String type, String friendlyType) {
    this(order, type, friendlyType, friendlyType, friendlyType);
  }

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   * order 에 무관한 Type 인 경우 이 생성자를 이용한다 - Admin 에 노출되지 않는 경우 주로 이 생성자를 사용한다
   * @param type
   * @param friendlyType
   */
  public EnumType(String type, String friendlyType) {
    this(100, type, friendlyType, friendlyType, friendlyType);
  }

  /**
   * key로 등록된 EnumType이 존재하는지 확인 후 있으면 해당 인스턴스를 리턴한다.
   * @param key
   * @param <T>
   * @return
   */
  public static <T> T getInstance(@NonNull final Class<?> clazz, String key) {
    if(key == null)
      return null;

    return getInstance(clazz.getName(), key);
  }

  public static <T> T getInstance(@NonNull final String className, String key) {
    if(key == null)
      return null;

    if (TYPES.containsKey(className)) {
      if (TYPES.get(className).containsKey(key)) {
        return (T) TYPES.get(className).get(key);
      } else if (TYPES.get(className).containsKey(key.toUpperCase())) {
        return (T) TYPES.get(className).get(key.toUpperCase());
      }
    }
    return null;
  }

  public static <T> T getInstanceFromFriendlyType(@NonNull final Class<?> clazz, final String friendlyType) {
    if(friendlyType == null)
      return null;

    String className = clazz.getName();
    LinkedHashMap<String, EnumType<?>> instances = new LinkedHashMap<>();
    if (TYPES.containsKey(className)) {
      instances = TYPES.get(className);
    }

    if(MapUtils.isNotEmpty(instances)){
      for (Map.Entry<String, EnumType<?>> entry : instances.entrySet()) {
        if (entry.getValue().getFriendlyType().equalsIgnoreCase(friendlyType)) {
          return (T) entry.getValue();
        }
      }
    }
    return null;
  }

  public static <T> T getParentEnumType(@NonNull EnumType<T> enumType){
    return (T) TYPES.entrySet().stream().filter(entry -> enumType.isMember(enumType)).findFirst().map(Map.Entry::getValue).orElse(null);
  }

  /**
   * Type의 하위 Type을 추가한다.
   * @param enumType
   * @return
   */
  public <E> T addSubTypes(EnumType<E>... enumType) {
    String key = getSubTypeMapKey();

    LinkedHashMap<String, EnumType<?>> subTypeMap;

    if(SUB_TYPES.containsKey(key)){
      subTypeMap = SUB_TYPES.get(key);
    }else{
      subTypeMap = new LinkedHashMap<>();
    }

    for(EnumType<E> subType : enumType){
      subTypeMap.put(subType.getType(), subType);
    }

    if(subTypeMap.size() > 1){
      List<EnumType> subTypes = new ArrayList<>(subTypeMap.values());
      subTypes.sort(EnumType::compareTo);
      subTypeMap.clear();
      for(EnumType<E> subType : subTypes){
        subTypeMap.put(subType.getType(), subType);
      }
    }

    SUB_TYPES.put(key, subTypeMap);

    return (T) this;
  }

  private String getSubTypeMapKey() {
    String key = getClass().getName() + "-" + type;
    return key;
  }

  public <E> boolean isMember(EnumType<E> enumType){
    if(!SUB_TYPES.containsKey(getClass().getName()))
      return false;
    String key = getSubTypeMapKey();
    LinkedHashMap<String, EnumType<?>> typeMap = SUB_TYPES.get(key);
    return typeMap.containsKey(enumType.getType());
  }

  private void setType(final String type) {
    this.type = type;

    LinkedHashMap<String, EnumType<?>> values = new LinkedHashMap<>();
    String className = getClass().getName();
    if (TYPES.containsKey(className)) {
      values = TYPES.get(className);
      if(values.containsKey(type)) {
        this.order = values.get(type).getOrder();
        this.friendlyType = values.get(type).getFriendlyType();
        this.description = values.get(type).getDescription();
        this.messageKey = values.get(type).getMessageKey();
      }
    }

    values.put(type, this);

    // Map 정렬
    List<EnumType<?>> types = new ArrayList<>(values.values());
    types.sort(EnumType::compareTo);

    LinkedHashMap<String, EnumType<?>> sorted = new LinkedHashMap<>();

    for(EnumType<?> enumType : types){
      sorted.put(enumType.getType(), enumType);
    }

    TYPES.put(className, sorted);

    try {
      SerializeConfig.getGlobalInstance().put(getClass(), new EnumTypeAdapter.Serializer());
      ParserConfig.getGlobalInstance().putDeserializer(getClass(), new EnumTypeAdapter.Deserializer());
    }catch (Exception e) {
      // ignore
    }

  }

  public <E> boolean containsSubType(EnumType<E>... enumType) {
    if(!SUB_TYPES.containsKey(getClass().getName()))
      return false;
    LinkedHashMap<String, EnumType<?>> typeMap = SUB_TYPES.get(getClass().getName());
    return CollectionUtils.containsAny(typeMap.values(), enumType);
  }

  public LinkedHashMap<String, EnumType<?>> getSubTypes(){
    String key = getSubTypeMapKey();
    if(SUB_TYPES.containsKey(key)){
      return SUB_TYPES.get(key);
    }
    return null;
  }

  public static <T> List<T> getTypes(final Class<? extends EnumType<T>> clazz){
    String className = clazz.getName();
    if(TYPES.containsKey(className)){

      List<T> list = new ArrayList<>();

      for (EnumType<?> enumType : TYPES.get(className).values()) {
        list.add((T) enumType);
      }

      return list;
    }
    return null;
  }


  public static List<EnumType<?>> getObjectTypes(final Class<? extends EnumType<?>> clazz){
    String className = clazz.getName();
    if(TYPES.containsKey(className)){
      return new ArrayList<>(TYPES.get(className).values());
    }
    return null;
  }




  /**
   * TYPES 정렬
   * @param other
   * @return
   */
  public int compareTo(EnumType other){
    if(this.getOrder() > other.getOrder()){
      return 1;
    }else if(this.getOrder() < other.getOrder()) {
      return -1;
    } else {
      // order is equal -> key 로 asc sort
      return this.getType().compareTo(other.getType());
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (!getClass().isAssignableFrom(obj.getClass()))
      return false;
    EnumType<T> other = (EnumType<T>) obj;
    return StringUtils.equals(getType(), other.getType());
  }

  @Override
  public int hashCode() {
    return type != null ? type.hashCode() : 0;
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("type", type)
        .toString();
  }

  // for jackson deserialize. 굳이 복잡하게 갈 것 없이 그냥 SpringCache 를 사용하는 대상인 경우 private NoArgsConstructor 를 넣어 주자.
  // EnumType 을 새로 선언하는 경우는 절대 사용하지 말 것.
  protected EnumType(){

  }

}
