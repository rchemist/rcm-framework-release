/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.io.Serializable;
import lombok.Getter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class PasswordUtil {

  private static final String lowerAlphabet = "abcdefghijklmnopqrstuvwxyz";
  private static final String upperAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  private static final String number = "0123456789";
  private static final String specialChar = "!@#$%^&*()_+-";

  public static String generatePassword(int length, boolean lowerFirst, boolean includeUpperCase, boolean includeNumber, boolean includeSpecial) {
    return new PasswordCreateContext(length, lowerFirst, includeUpperCase, includeNumber, includeSpecial).getPassword();
  }

  public static String generatePassword() {
    // 8자 짜리 기본 비밀번호 리턴
    return generatePassword(8, false, true, true, true);
  }

  public static String generatePassword(int length) {
    return generatePassword(length, true, true, true, true);
  }

  private static class PasswordCreateContext implements Serializable {

    private boolean useNumber = false;
    private boolean useSpecial = false;
    private boolean useUpper = false;
    private final int length;

    private final boolean lowerFirst;

    private final boolean includeNumber;

    private final boolean includeUpperCase;

    private final boolean includeSpecial;

    @Getter
    private String password;

    public PasswordCreateContext(int length, boolean lowerFirst, boolean includeUpperCase, boolean includeNumber, boolean includeSpecial) {
      this.length = length;
      this.lowerFirst = lowerFirst;
      this.includeUpperCase = includeUpperCase;
      this.includeNumber = includeNumber;
      this.includeSpecial = includeSpecial;
      generatePassword();
    }

    private void generatePassword() {
      StringBuilder sb = new StringBuilder();

      while (sb.length() < this.length) {

        if (sb.isEmpty()) {
          if (lowerFirst) {
            sb.append(StringUtil.getRandomString(lowerAlphabet, 1));
          } else {
            sb.append(StringUtil.getRandomString(upperAlphabet, 1));
          }
        } else {

          // 숫자, 특수문자를 반드시 2번째 글자로 추가한다.
          if (this.includeNumber && !this.useNumber) {
            sb.append(StringUtil.getRandomString(number, 1));
            this.useNumber = true;
          } else if (this.includeSpecial && !this.useSpecial) {
            sb.append(StringUtil.getRandomString(specialChar, 1));
            this.useSpecial = true;
          } else if (this.includeUpperCase && !this.useUpper){
            sb.append(StringUtil.getRandomString(upperAlphabet, 1));
            this.useUpper = true;
          } else {
            sb.append(StringUtil.getRandomString(lowerAlphabet, length - sb.length()));
          }

        }
      }

      this.password = sb.toString();
    }

  }

}