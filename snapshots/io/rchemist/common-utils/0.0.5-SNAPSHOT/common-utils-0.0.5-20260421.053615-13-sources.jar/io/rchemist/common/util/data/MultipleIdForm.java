/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MultipleIdForm implements Serializable {

  private Long[] ids;

  public MultipleIdForm withIds(Long[] ids) {
    this.ids = ids;
    return this;
  }

  public MultipleIdForm addId(Long... id) {
    Set<Long> set = new HashSet<>();

    if (ArrayUtils.isNotEmpty(id)) {
      set.addAll(Arrays.asList(id));
    }

    if (ArrayUtils.isNotEmpty(ids)) {
      set.addAll(Arrays.asList(ids));
    }

    this.ids = set.toArray(new Long[0]);

    return this;
  }

  public MultipleIdForm withIds(List<Long> ids){
    this.ids = ids.toArray(Long[]::new);
    return this;
  }

  public boolean isEmpty(){
    return ArrayUtils.isEmpty(ids);
  }

  public static MultipleIdForm create(List<String> ids){
    MultipleIdForm form = new MultipleIdForm();

    for(String id : ids){
      Long idValue = Long.valueOf(id);
      form.addId(idValue);
    }

    return form;
  }

}