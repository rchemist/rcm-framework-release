/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class NumberUtil {

  public static Integer getIntegerFromObjectValue(Object value){
    return getIntegerFromObjectValue(value, null);
  }

  public static Integer getIntegerFromObjectValue(Object value, Integer defaultValue){

    if(value == null)
      return defaultValue;

    if(value instanceof Long longValue){
      return getInteger(longValue);
    }else if(value instanceof String strValue) {
      return getInteger(strValue);
    }

    return getInteger(String.valueOf(value));
  }


  public static Integer getInteger(Long longValue) {
    return getInteger(longValue, null);
  }

  public static Integer getInteger(Long longValue, Integer defaultValue) {
    if (longValue == null) {
      return defaultValue;
    }
    return getInteger(String.valueOf(longValue), defaultValue);
  }

  public static Integer getInteger(String str, Integer defaultValue) {
    return getInteger(str, defaultValue, true);
  }

  public static Integer getInteger(String str, Integer defaultValue, Boolean tryMore, Boolean throwException){
    // BUG-027 fix (0.0.10.F): Boolean 파라미터 null 시 auto-unboxing NPE 방지.
    boolean tryMoreFlag = Boolean.TRUE.equals(tryMore);
    boolean throwExceptionFlag = Boolean.TRUE.equals(throwException);

    if (StringUtils.isBlank(str)){
      if(throwExceptionFlag){
        throw new RuntimeException("Input value is null");
      }else{
        return defaultValue;
      }
    }


    try {
      // try Integer first
      return Integer.valueOf(str);
    } catch (Exception e) {
      if (tryMoreFlag) {
        try {
          // try BigDecimal then
          return new BigDecimal(str).intValue();
        } catch (Exception e1) {
          try {
            // at last, try Double
            return Double.valueOf(str).intValue();
          } catch (Exception ee) {
            // do nothing
            if(throwExceptionFlag){
              throw ee;
            }
          }
        }
      }else{
        if(throwExceptionFlag){
          throw e;
        }
      }
      return defaultValue;
    }
  }

  public static Integer getInteger(String str, Integer defaultValue, Boolean tryMore) {
    return getInteger(str, defaultValue, tryMore, false);
  }

  public static Integer getInteger(String str) {
    return getInteger(str, 0);
  }

  public static Long getLong(String str) {
    return getLong(str, 0L);
  }

  public static Long getLong(String str, Long defaultValue) {
    return getLong(str, defaultValue, false);
  }

  public static Long getLong(String str, Long defaultValue, Boolean throwException) {
    // BUG-027 fix (0.0.10.F): throwException null 시 unboxing NPE.
    boolean throwExceptionFlag = Boolean.TRUE.equals(throwException);
    try{
      return (StringUtils.isBlank(str)) ? defaultValue : Long.valueOf(str);
    }catch (Exception e){
      if(!throwExceptionFlag){
        return defaultValue;
      }
      throw e;
    }
  }

  public static Long getLong(Double doubleValue){
    if(doubleValue == null)
      return null;
    Integer d = doubleValue.intValue();
    return getLong(d, null);
  }

  public static Long getLong(Object value){
    return getLong(value, null);
  }

  public static Long getLong(Object value, Long defaultValue){
    if(value == null)
      return defaultValue;
    if(value instanceof Long){
      return (Long) value;
    }else{
      return getLong(String.valueOf(value), defaultValue);
    }
  }


  public static Long getLong(Integer number) {
    return getLong(number, 0L);
  }

  public static Long getLong(Integer number, Long defaultValue) {
    return getLong(number, defaultValue, false);
  }

  public static Long getLong(Integer number, Long defaultValue, Boolean throwException) {
    try{

      if(number == null){
        return defaultValue;
      }else{
        return Long.valueOf(String.valueOf(number));
      }
    }catch (Exception e){
      if(!throwException){
        return defaultValue;
      }
      throw e;
    }
  }

  public static Integer getInteger(Integer number) {
    return getInteger(number, 0);
  }

  public static Integer getInteger(Integer number, Integer defaultValue) {
    return (number == null) ? defaultValue : number;
  }

  public static int safeSubtract(Integer number, Integer... subtractedValues) {
    int result = getInteger(number, 0);

    if (subtractedValues != null) {
      for (Integer subtracted : subtractedValues) {
        if (subtracted != null) {
          result = result - subtracted;
        }
      }
    }

    return Math.max(result, 0);
  }

  public static int safeAdd(Integer number, Integer... addedValues) {
    int result = getInteger(number, 0);

    if (addedValues != null) {
      for (Integer addedValue : addedValues) {
        if (addedValue != null) {
          result = result + getInteger(addedValue);
        }
      }
    }

    return Math.max(result, 0);
  }

  public static boolean isPositive(Integer number) {
    return number != null && number > 0;
  }

  public static boolean isNegative(Integer number) {
    return number != null && number < 0;
  }


  public static Double getDouble(Object doubleValue){
    if(doubleValue == null)
      return null;
    if(Double.class.isAssignableFrom(doubleValue.getClass()))
      return (Double) doubleValue;
    String value = String.valueOf(doubleValue);
    return getDouble(value);
  }
  public static Double getDouble(String doubleValue) {
    return getDouble(doubleValue, (double) 0);
  }

  public static Double getDouble(String doubleValue, Double defaultValue) {
    return (StringUtils.isBlank(doubleValue)) ? defaultValue : Double.valueOf(doubleValue);
  }

  public static BigDecimal getBigDecimal(BigDecimal number, BigDecimal defaultValue) {
    if (number == null) {
      return defaultValue;
    } else {
      return number;
    }
  }

  public static BigDecimal getBigDecimal(String str){
    return getBigDecimal(str, null);
  }

  public static BigDecimal getBigDecimal(String str, BigDecimal defaultValue){
    try{
      return new BigDecimal(str);
    }catch (Exception e){
      // suppress error
    }
    return defaultValue;
  }

  public static BigDecimal getBigDecimal(Number one, Number other) {
    if (one == null) {
      if (other != null) {
        return new BigDecimal(other.toString());
      } else {
        return null;
      }
    } else {
      return new BigDecimal(one.toString());
    }
  }


  public static Double getPercentage(Number numerator, Number denominator){
    return getPercentage(numerator, denominator, null, 1, null);
  }

  public static Double getPercentage(Number numerator, Number denominator, String decimalFormat, int fractionDigits, RoundingMode roundingMode){
    if(numerator == null || numerator.intValue() == 0)
      return (double) 0;

    if(denominator == null || denominator.intValue() == 0)
      return 100.0;

    DecimalFormat df;
    try{
      df = new DecimalFormat((decimalFormat == null) ?  "0.00" : decimalFormat);
    }catch (Exception e){
      // wrong decimal format, use default
      df = new DecimalFormat("0.00");
    }

    Double numeratorValue = numerator.doubleValue();
    Double denominatorValue = denominator.doubleValue();

    Double proportion = numeratorValue / denominatorValue * 100;

    df.setMaximumFractionDigits(fractionDigits);
    df.setRoundingMode((roundingMode == null) ? RoundingMode.HALF_UP : roundingMode);

    return Double.valueOf(df.format(proportion));

  }

  public static boolean isNumeric(Object obj){
    try {
      return NumberUtils.isCreatable(String.valueOf(obj));
    }catch (NumberFormatException e){
      return false;
    }
  }

  public static Float getFloat(String value){
    return getFloat(value, (float) 0);
  }

  public static Float getFloat(String value, Float defaultValue) {
    try{
      return Float.valueOf(value);
    }catch (Exception e){
      return defaultValue;
    }
  }

  public static boolean isLess(BigDecimal one, BigDecimal two){
    if(one == null || two == null)
      return false;
    // one less than two
    return one.compareTo(two) < 0;
  }

  public static boolean isGreater(BigDecimal one, BigDecimal two){
    if(one == null || two == null)
      return false;
    // onw greater than two
    return one.compareTo(two) > 0;
  }

  public static boolean isEqual(BigDecimal one, BigDecimal two){
    if(one == null || two == null)
      return false;
    return one.equals(two);
  }

  public static Integer getInteger(BigDecimal number) {
    if(number == null)
      return null;
    return number.intValue();
  }

  public static String toString(Integer value) {
    if(value == null)
      return "";
    return value.toString();
  }

  public static String toString(Long value) {
    if(value == null){
      return "";
    }else{
      return String.valueOf(value);
    }
  }

  public static Integer validateAndSetDefault(Integer value, Integer defaultValue, Integer minValue, Integer maxValue){
    if(value == null){
      return defaultValue;
    }

    if(value < minValue)
      return minValue;

    if(value > maxValue)
      return maxValue;

    return value;
  }

  public static Integer getMin(Integer... numbers) {
    return Arrays.stream(numbers)
        .filter(Objects::nonNull)
        .min(Comparator.naturalOrder())
        .orElse(null);
  }

  public static Integer getMax(Integer... numbers) {
    return Arrays.stream(numbers)
        .filter(Objects::nonNull)
        .max(Comparator.naturalOrder())
        .orElse(null);
  }

  public static int min(int... numbers) {
    return Arrays.stream(numbers).min().orElseThrow();
  }

  public static int max(int... numbers) {
    return Arrays.stream(numbers).max().orElseThrow();
  }

}
