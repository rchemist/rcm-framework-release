/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class GsonUtil {

  public static final Gson GSON = new GsonBuilder()
    .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
    .registerTypeAdapter(LocalDate.class, new LocalDateAdapter())
    .registerTypeAdapter(Instant.class, new InstantAdapter())
    .registerTypeAdapter(LocalTime.class, new LocalTimeAdapter()).create();

  public static <T> String toJson(T t) {
    return GSON.toJson(t);
  }

  public static <T> T fromJson(String json, Class type) {
    if (StringUtils.isBlank(json))
      return null;
    return (T) GSON.fromJson(json, type);
  }

  public static String getJsonFieldValue(String json, String field) {
    JsonObject jsonObject = GSON.fromJson(json, JsonObject.class);
    if(jsonObject.has(field)){
      return jsonObject.get("field").getAsString();
    }
    return null;
  }

  public static Map<String, String> getAttributes(String attributeJson){
    ObjectMapper mapper = new ObjectMapper();
    try {

      JsonNode obj = mapper.readTree(attributeJson);
      return getJsonValues(obj, "", new HashMap<>());

    } catch (IOException e) {
      ExceptionUtil.printStackTrace(e);
      return null;
    }
  }

  private static Map<String, String> getJsonValues(JsonNode obj, String prefix, Map<String, String> values) {
    Iterator<Entry<String, JsonNode>> iterator = obj.fields();
    while(iterator.hasNext()){
      Map.Entry<String, JsonNode> node = iterator.next();

      String key = StringUtil.toString(prefix) + node.getKey();
      JsonNode nodeValue = node.getValue();

      if(nodeValue.isValueNode()){
        values.put(key, nodeValue.asText());
      } else {
        values = getJsonValues(nodeValue, key + ".", values);
      }

    }
    return values;
  }

  public static String getStringValue(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      return document.get(key).getAsString();
    }
    return null;
  }

  public static Long getLongValue(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      return document.get(key).getAsLong();
    }
    return null;
  }

  public static Integer getIntegerValue(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      return document.get(key).getAsInt();
    }
    return null;
  }

  public static boolean getBooleanValue(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      return document.get(key).getAsBoolean();
    }
    return false;
  }

  public static List<String> getListString(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      List<String> values = new ArrayList<>();
      JsonElement valueElement = document.get(key);
      if(valueElement.isJsonArray()){
        JsonArray array = valueElement.getAsJsonArray();
        for (JsonElement element : array) {
          String value = element.getAsString();
          values.add(value);
        }
      }else{
        values.add(valueElement.getAsString());
      }

      return values;
    }
    return new ArrayList<>();
  }

  public static List<Long> getListLong(JsonObject document, String key){
    if(document != null && document.keySet().contains(key)){
      List<Long> values = new ArrayList<>();
      JsonElement valueElement = document.get(key);
      if(valueElement.isJsonArray()){
        JsonArray array = valueElement.getAsJsonArray();
        for (JsonElement element : array) {
          Long value = element.getAsLong();
          values.add(value);
        }
      }else{
        values.add(valueElement.getAsLong());
      }

      return values;
    }
    return new ArrayList<>();
  }

  public static class LocalDateTimeAdapter extends TypeAdapter<LocalDateTime> {
    @Override
    public void write(JsonWriter out, LocalDateTime value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        out.value(LocalDateTimeUtil.format(value));
      }
    }

    @Override
    public LocalDateTime read(JsonReader in) throws IOException {
      if (in.hasNext()) {
        String value = in.nextString();
        return LocalDateTimeUtil.parse(value);
      }
      return null;
    }
  }

  public static class LocalDateAdapter extends TypeAdapter<LocalDate> {
    @Override
    public void write(JsonWriter out, LocalDate value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        out.value(LocalDateUtil.format(value));
      }
    }

    @Override
    public LocalDate read(JsonReader in) throws IOException {
      if (in.hasNext()) {
        String value = in.nextString();
        return LocalDateUtil.parse(value);
      }
      return null;
    }
  }

  public static class LocalTimeAdapter extends TypeAdapter<LocalTime> {
    @Override
    public void write(JsonWriter out, LocalTime value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        out.value(LocalTimeUtil.format(value));
      }
    }

    @Override
    public LocalTime read(JsonReader in) throws IOException {
      if (in.hasNext()) {
        String value = in.nextString();
        return LocalTimeUtil.parse(value);
      }
      return null;
    }
  }

  public static class InstantAdapter extends TypeAdapter<Instant> {

    @Override
    public void write(JsonWriter out, Instant value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        out.value(value.toString());
      }
    }

    @Override
    public Instant read(JsonReader in) throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      if (in.hasNext()) {
        String value = in.nextString();
        return Instant.parse(value);
      }
      return null;
    }
  }


}
