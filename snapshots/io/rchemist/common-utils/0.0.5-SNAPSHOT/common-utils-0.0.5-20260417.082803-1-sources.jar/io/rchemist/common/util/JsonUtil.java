/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import io.rchemist.common.configuration.SerializeConfig;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
public class JsonUtil {

  private static final ObjectMapper OBJECT_MAPPER;

  static {
    // SerializeConfig를 사용하여 ObjectMapper 초기화
    try {
      SerializeConfig config = new SerializeConfig();
      OBJECT_MAPPER = config.objectMapper();
      log.debug("JsonUtil initialized with SerializeConfig ObjectMapper");
    } catch (Exception e) {
      log.warn("Failed to initialize ObjectMapper with SerializeConfig, using default ObjectMapper", e);
      throw new RuntimeException("Failed to initialize JsonUtil", e);
    }
  }

  /**
   * 현재 사용중인 ObjectMapper를 반환합니다.
   *
   * @return ObjectMapper 인스턴스
   */
  public static ObjectMapper getObjectMapper() {
    return OBJECT_MAPPER;
  }

  /**
   * TypeFactory 인스턴스를 반환합니다.
   *
   * @return TypeFactory 인스턴스
   */
  public static TypeFactory getTypeFactory() {
    return OBJECT_MAPPER.getTypeFactory();
  }

  /**
   * 객체를 JSON 문자열로 변환합니다.
   *
   * @param obj 변환할 객체
   * @return JSON 문자열, 변환 실패 시 null
   */
  public static String toJson(Object obj) {
    if (obj == null) {
      return null;
    }
    
    try {
      return OBJECT_MAPPER.writeValueAsString(obj);
    } catch (JsonProcessingException e) {
      log.warn("Failed to convert object to JSON: {}", e.getMessage(), e);
      return null;
    }
  }

  /**
   * JSON 문자열을 지정된 클래스 타입의 객체로 변환합니다.
   *
   * @param json  JSON 문자열
   * @param clazz 변환할 클래스 타입
   * @param <T>   반환 타입
   * @return 변환된 객체, 변환 실패 시 null
   */
  public static <T> T fromJson(String json, Class<T> clazz) {
    if (json == null || json.trim().isEmpty() || clazz == null) {
      return null;
    }
    
    try {
      return OBJECT_MAPPER.readValue(json, clazz);
    } catch (JsonProcessingException e) {
      log.warn("Failed to convert JSON to object: {}", e.getMessage(), e);
      return null;
    }
  }

  /**
   * JSON 문자열을 TypeReference를 사용하여 복잡한 제네릭 타입의 객체로 변환합니다.
   *
   * @param json          JSON 문자열
   * @param typeReference 타입 참조
   * @param <T>           반환 타입
   * @return 변환된 객체, 변환 실패 시 null
   */
  public static <T> T fromJson(String json, TypeReference<T> typeReference) {
    if (json == null || json.trim().isEmpty() || typeReference == null) {
      return null;
    }
    
    try {
      return OBJECT_MAPPER.readValue(json, typeReference);
    } catch (JsonProcessingException e) {
      log.warn("Failed to convert JSON to object with TypeReference: {}", e.getMessage(), e);
      return null;
    }
  }

  /**
   * JSON 문자열을 JavaType을 사용하여 복잡한 제네릭 타입의 객체로 변환합니다.
   *
   * @param json     JSON 문자열
   * @param javaType 자바 타입
   * @param <T>      반환 타입
   * @return 변환된 객체, 변환 실패 시 null
   */
  public static <T> T fromJson(String json, JavaType javaType) {
    if (json == null || json.trim().isEmpty() || javaType == null) {
      return null;
    }
    
    try {
      return OBJECT_MAPPER.readValue(json, javaType);
    } catch (JsonProcessingException e) {
      log.warn("Failed to convert JSON to object with JavaType: {}", e.getMessage(), e);
      return null;
    }
  }

}
