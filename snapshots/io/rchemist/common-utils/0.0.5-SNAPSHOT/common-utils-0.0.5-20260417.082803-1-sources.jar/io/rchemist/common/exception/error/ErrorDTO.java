/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.exception.error;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;
import io.rchemist.common.exception.HasErrorDTOException;
import io.rchemist.common.exception.HasErrorTypeException;
import io.rchemist.common.exception.HasPropertyNameException;
import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.MapUtil;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorDTO implements Serializable {

  public static final int STATUS_OK = 200; // 정상
  public static final int STATUS_NOT_FOUND = 404;  // not found entity or field, etc
  public static final int STATUS_INVALID = 422;    // validation error

  public ErrorDTO(){
  }

  public ErrorDTO(Throwable e){

    ExceptionUtil.printStackTrace(e);

    setError(true);

    if(e instanceof HasErrorDTOException ex){
      ErrorDTO error = ex.getError();

      if (e instanceof HasPropertyNameException nameException) {
        if (StringUtils.isNotEmpty(nameException.getPropertyName()) && StringUtils.isNotEmpty(e.getMessage())) {
          error.addFieldError(nameException.getPropertyName(), e.getMessage());
        }
      }

      this.message = (StringUtils.isNotEmpty(e.getMessage())) ? e.getMessage() : error.getMessage();

      if(error.isError()){
        this.errorType = error.getErrorType();
        this.serviceErrorType = error.getServiceErrorType();
        this.status = error.getStatus();
        this.detailMessage = error.getDetailMessage();
        this.attributes = error.getAttributes();
        this.fieldError = error.getFieldError();
        this.error = error.isError();

      }else{

        if (e instanceof HasErrorTypeException ee) {
          this.errorType = ee.getErrorTypeToString();
          this.serviceErrorType = ee.getErrorType();
          this.status = 500;
          this.detailMessage = ee.getDetailMessage();
        }

      }



    }else{
      this.status = HttpStatus.INTERNAL_SERVER_ERROR.value();
      if(StringUtils.isNotBlank(e.getMessage())){
        this.message = e.getMessage();
      }else{
        this.message = HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
      }
    }

    if(status >= 500){
      ExceptionUtil.printStackTrace(e);
    }

    if(StringUtils.isBlank(this.detailMessage)){
      this.detailMessage = ExceptionUtil.printException(e);
    }
  }

  public ErrorDTO(BindingResult error) {
    if(error.hasErrors()){

      setError(true);
      setStatus(HttpStatus.BAD_REQUEST.value());

      if(error.hasFieldErrors()){
        for(FieldError fl : error.getFieldErrors()){
          String field = fl.getField();
          Object errorValue = fl.getRejectedValue();
          addFieldError(field, MessageSourceHelper.getMessage(String.valueOf(errorValue)));
        }
      }

      if(error.getGlobalError() != null){
        setMessage(error.getGlobalError().getDefaultMessage());
      }else{
        setMessage(MessageSourceHelper.getMessage(ErrorType.GLOBAL_ERROR));
      }

    }
  }

  public ErrorDTO(ErrorType errorType){
    this.status = errorType.getStatus();
    this.errorType = errorType.getType();
    this.serviceErrorType = errorType;
    this.message = errorType.getTranslatedType();
    setError(true);
  }

  public ErrorDTO(String message, int status){
    this.message = message;
    this.status = status;
    setError(true);
  }

  @Setter(AccessLevel.PROTECTED)
  private boolean error = false;

  private int status = 200;    // 200, 4XX, 5XX

  private String errorType;

  private String message;

  @JsonIgnore
  private ErrorType serviceErrorType;

  @JsonIgnore
  @Expose(serialize = false, deserialize = false)
  private String detailMessage;

  private Map<String, List<String>> fieldError = new HashMap<>();

  @JsonIgnore
  @Expose(serialize = false, deserialize = false)
  private Map<String, String> attributes = new HashMap<>();

  public void setStatus(int status){
    withStatus(status);
  }

  public ErrorDTO withStatus(int status) {
    this.status = status;
    if(status >= 400){
      setError(true);
    }
    return this;
  }

  public ErrorDTO withMessage(String message) {
    this.message = message;
    return this;
  }

  public ErrorDTO withDetailMessage(String detailMessage) {
    this.detailMessage = detailMessage;
    return this;
  }

  public ErrorDTO withFieldError(Map<String, List<String>> fieldError) {
    this.fieldError = fieldError;
    return this;
  }

  public ErrorDTO withAttributes(Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public ErrorDTO withTranslatedMessage(String messageCode){
    this.message = MessageSourceHelper.getMessage(messageCode);
    return this;
  }

  public boolean isError(){
    return (StringUtils.isNotBlank(message)
        || status != 200
        || MapUtils.isNotEmpty(fieldError));
  }

  public ErrorDTO addFieldError(String fieldName, String message){
    setError(true);
    if(fieldError == null) fieldError = new HashMap<>();
    fieldError = MapUtil.mergeListHashMap(fieldError, fieldName, message, true);
    status = STATUS_INVALID;
    return this;
  }

  public ErrorDTO addAttribute(String key, String value){
    setError(true);
    if(attributes == null)
      attributes = new HashMap<>();
    attributes.put(key, value);
    return this;
  }

  @Override
  public String toString() {
    return toJson();
  }

  public String toStringDetails(){
    return ReflectionToStringBuilder.toString(this,
        ToStringStyle.SHORT_PREFIX_STYLE);
  }

  public String toJson(){
    Map<String, Object> map = new HashMap<>();
    map.put("status", status);
    map.put("error", error);
    if(StringUtils.isNotEmpty(message)){
      map.put("message", message);
    }
    if(StringUtils.isNotEmpty(errorType)){
      map.put("code", errorType);
    }else{
      map.put("code", HttpStatus.valueOf(status).getReasonPhrase());
    }
    return StringUtil.toJson(map);
  }

  public ErrorType getServiceErrorType(){
    return serviceErrorType;
  }

  public ErrorDTO clone() {
    ErrorDTO clone = new ErrorDTO();
    clone.setError(this.error);
    clone.setStatus(this.status);
    clone.setErrorType(this.errorType);
    clone.setMessage(this.message);
    clone.setServiceErrorType(this.serviceErrorType);
    clone.setDetailMessage(this.detailMessage);

    Map<String, List<String>> fieldError = this.fieldError.entrySet().stream().collect(
      Collectors.toMap(Entry::getKey, entry -> new ArrayList<>(entry.getValue()), (a, b) -> b));
    clone.setFieldError(fieldError);

    clone.setAttributes(new HashMap<>(this.attributes));
    return clone;
  }

}
