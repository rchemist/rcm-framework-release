/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * Map<String, 엔티티 RuleXref> 로 되어 있는 정보를 String 으로 변환하고, 다시 String 을 Map<String, String> 으로 변환
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class InlineRuleUtil {

  public static final String FIELD_SPLIT = ":::";
  public static final String LINE_SPLIT = "|||";
  public static final String RULE_SPLIT = "^^^";
  public static final String MATCH_RULE = "MATCH_RULE";
  public static final String KEY = "KEY";

  public static Map<String, String> getRuleValueMap(String inlineRuleValue) {
    if(StringUtils.isBlank(inlineRuleValue))
      return null;

    String[] ruleValues = StringUtils.split(inlineRuleValue, RULE_SPLIT);
    Map<String, String> ruleMap = new HashMap<>();

    for(String ruleValue : ruleValues){
      String key = null;
      String value = null;

      String[] fields = StringUtils.split(ruleValue, LINE_SPLIT);

      for(String field : fields){
        String[] fieldValues = StringUtils.split(field, FIELD_SPLIT);
        if(StringUtils.contains(field, MATCH_RULE)){
          value = fieldValues[1];
        } else {
          key = fieldValues[1];
        }
      }

      ruleMap.put(key, value);

    }

    return ruleMap;
  }

  public static String getInlineRuleValue(String matchRule, String key){
    return StringUtil.merge(MATCH_RULE, FIELD_SPLIT, matchRule, LINE_SPLIT, KEY, key);
  }

}
