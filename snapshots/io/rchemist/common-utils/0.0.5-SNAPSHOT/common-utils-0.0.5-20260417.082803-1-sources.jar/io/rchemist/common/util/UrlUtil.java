/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.exception.ErrorTypeRuntimeException;
import io.rchemist.common.util.type.RegexType;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.regex.Pattern;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class UrlUtil {

  private static final String UTF_8 = "UTF-8";

  public static boolean hasProtocol(String url){
    return url != null && StringUtils.contains(url, "://");
  }

  /**
   * HTTP 또는 HTTPS 를 포함한 URL 인지
   * @param url
   * @return
   */
  public static boolean isHttpUrl(String url){
    if(StringUtils.isEmpty(url))
      return false;
    return Pattern.compile(RegexType.HTTP_URL.getRegexExpression()).matcher(url).matches();
  }

  public static String getValidatedUrl(String url, String defaultUrl, boolean useProtocol, boolean secured){
    if(StringUtils.isBlank(url)){
      if(StringUtils.isBlank(defaultUrl))
        throw new UnsupportedOperationException("Url is missing");
      return getValidatedUrl(defaultUrl, null, useProtocol, secured);
    }

    // protocol
    if(!useProtocol){
      if(StringUtils.contains(url, "://")){
        return getValidatedUrl(StringUtils.substringAfter(url, "://"), defaultUrl, useProtocol, secured);
      }
    }else{
      if(secured){
        if(StringUtils.startsWithIgnoreCase(url, "http://")){
          return getValidatedUrl("https://" + StringUtils.substringAfter(url, "://"), defaultUrl, useProtocol, secured);
        } else {
          return getValidatedUrl("http://" + StringUtils.substringAfter(url, "://"), defaultUrl, useProtocol, secured);
        }
      }
    }

    if(StringUtils.endsWith(url, "/")){
      return StringUtils.substringBeforeLast(url, "/");
    }

    return url;

  }

  public static String getValidatedMergeUrl(String domainUrl, String fullUrl){
    // 도메인 네임에 http:// 가 붙어 있지 않으면 http:// 추가
    if(!StringUtils.startsWithIgnoreCase(domainUrl, "http")){
      domainUrl = "http://"+domainUrl;
    }
    // 도메인 네임의 끝과 fullUrl의 시작에 / 가 중복되어 있으면
    if(StringUtils.endsWith(domainUrl, "/") && StringUtils.startsWith(fullUrl, "/")){
      domainUrl = StringUtils.substringBeforeLast(domainUrl, "/");		// 도메인 네임의 맨 뒤에 있는 / 를 제거한다
    }
    return domainUrl + fullUrl;
  }

  /**
   * URI 뒤의 ? 이후를 제거한다
   * @param uri
   * @return
   */
  public static String getUriWithoutParameters(String uri){
    return (uri == null) ? null : StringUtils.substringBefore(uri, "?");
  }

  /**
   * 상대경로인 경우 / 로 시작하되, 끝의 / 는 뺀다.
   * @param uri
   * @return
   */
  public static String getValidateRelativeUrl(String uri){
    return getValidateRelativeUrl(uri, true);
  }

  public static String getValidateRelativeUrl(String uri, boolean removeQueryParameters){
    if(StringUtils.isEmpty(uri) || hasProtocol(uri) || uri.equals("/"))
      return uri;

    String prefix = uri;
    if(StringUtils.contains(uri, "?")){
      prefix = StringUtils.substringBeforeLast(prefix, "?");
    }

    // 맨 뒤에 / 가 있으면 변경
    String replaced = (StringUtils.endsWith(prefix, "/")) ? StringUtils.substringBeforeLast(prefix, "/") : prefix;

    if(removeQueryParameters){
      return replaced;
    }else{
      return StringUtils.replace(uri, prefix, replaced);
    }
  }

  @SneakyThrows
  public static String grabUrlContent(String url){
    URL openUrl = new URL(url);

    BufferedReader reader = new BufferedReader(new InputStreamReader(openUrl.openStream()));

    StringBuilder sb = new StringBuilder();

    String inputLine;
    while((inputLine = reader.readLine()) != null){
      sb.append(inputLine);
    }
    return sb.toString();
  }

  public static String getAvailableUrl(String url, boolean includeProtocol) {
    // 값이 없거나 / 면 그대로 리턴
    if (StringUtils.isBlank(url) || url.startsWith("/")) {
      return url;
    }

    if (includeProtocol) {
      // includeProtocol 인 경우 맨 앞에 http: 또는 https:
      String protocol = StringUtils.substringBefore(url, ":");
      if (StringUtils.startsWith(url, "http") && StringUtils.startsWith(protocol, "http")) {
        return url;
      }
    } else {
      // 프로토콜이 아닌 url에 : 이 붙은 경우에는 그대로 리턴
      if ((url.contains(":") && !url.contains("?")) || url.indexOf('?', url.indexOf(':')) != -1) {
        return url;
      }
    }
    return "/" + url;
  }

  public static String getDomainPrefix(String domain){
    String domainPrefix = "";
    try{
      int pos = domain.indexOf('.');
      if (pos >= 0) {
        domainPrefix = domain.substring(0, pos);
      } else {
        domainPrefix = "";
      }
    }catch(Exception e){
      // surpress exception
    }

    return domainPrefix;
  }
  /**
   * URI 를 절대경로에 맞게 변환해 전달한다.
   * @param path
   * @return
   */
  public static String getAbsoluteURIString(String path) {
    if(path == null || path.equals("") || path.startsWith("/")) {
      return path;
    } else if ((path.contains(":") && !path.contains("?")) || path.indexOf('?', path.indexOf(':')) != -1) {
      return path;
    } else {
      return "/" + path;
    }
  }

  /**
   * 쿼리스트링을 제거한 URL 만 리턴한다
   * @param uri
   * @return
   */
  public static String getRefineUrl(String uri) {
    if(StringUtils.contains(uri, "?")){
      return StringUtils.substringBefore(uri, "?");
    }else{
      return uri;
    }
  }

  private static final String SLASH = "/";

  /**
   * UrlMapping 에서 사용하도록 / 로 시작하고 / 로 끝나지 않도록 한다.
   * @param url
   * @return
   */
  public static String validateUrlMapping(String url) {
    if (StringUtils.isNotEmpty(url)) {
      if (!StringUtils.startsWith(url, SLASH)) {
        url = SLASH + url;
      }
      if (StringUtils.endsWith(url, SLASH)) {
        url = url.substring(0, url.length() - 1);
      }
      if (!RegexType.URL_BODY.validate(url, true)) {
        throw new ErrorTypeRuntimeException(RegexType.URL_BODY.getErrorMessage(), "url");
      }
    }
    return url;
  }

  public static String getValidatedSlug(String slug) {
    if (slug != null && !slug.isEmpty()) {
      // 문자열에서 /로 시작하거나 끝나면 제거
      slug = slug.replaceAll("^/|/$", "");

      // 문자열에 공백이 있으면 - 로 변경
      slug = slug.replaceAll("\\s+", "-");

      // 한글, 영문 대문자, 소문자, 숫자, 대시를 제외한 모든 특수 문자를 제거
      slug = slug.replaceAll("[^a-zA-Z0-9가-힣-]", "");

      // 연속된 -를 하나로 줄임
      slug = slug.replaceAll("-+", "-");

      // 시작과 끝의 불필요한 대시 제거
      slug = slug.replaceAll("^-|-$", "");

      // 모든 문자열을 소문자로 변환
      slug = slug.toLowerCase();
    }
    return slug;
  }


  public static String encode(String url) {
    return encode(url, UTF_8);
  }

  public static String encode(String url, String charset) {
    if (StringUtils.isEmpty(charset))
      charset = UTF_8;

    try {
      return java.net.URLEncoder.encode(url, charset);
    } catch (Exception e) {
      return url;
    }
  }

  public static String decode(String url) {
    return decode(url, UTF_8);
  }

  public static String decode(String url, String charset) {
    if (StringUtils.isEmpty(charset))
      charset = UTF_8;

    try {
      return java.net.URLDecoder.decode(url, charset);
    } catch (Exception e) {
      return url;
    }
  }

  /**
   * slug 가 중복됐을 때 중복 방지를 위해 slug 에 숫자값을 높여 줄 수 있다.
   * @param slug
   * @return
   */
  public static String appendSlugPostfix(String slug) {
    if (NumberUtil.isNumeric(StringUtils.substringAfterLast(slug, "-"))) {
      // 뒤에 붙은게 숫자다.
      Integer number = NumberUtil.getInteger(StringUtils.substringAfterLast(slug, "-"));
      return StringUtils.substringBeforeLast(slug, "-") + "-" + (number + 1);
    } else {
      return slug + "-1";
    }
  }



}
