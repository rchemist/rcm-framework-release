/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.type.TimePeriodType;
import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class LocalDateTimeUtil {

  public static LocalDateTime parse(String localDateTime) {
    if(StringUtils.isEmpty(localDateTime))
      return null;

    for(String format : FormatUtil.getDateTimeFormatter()){
      try{
        return parse(localDateTime, format);
      }catch(Exception e){
        // nothing
      }
    }
    return null;
  }

  public static LocalDateTime parseFilterValue(String localDateTime, boolean until) {
    if(StringUtils.isEmpty(localDateTime))
      return null;

    LocalDateTime value = null;

    for(String format : FormatUtil.getDateTimeFormatter()){
      try{
        value = parse(localDateTime, format);
        break;
      }catch(Exception e){
        // nothing
      }
    }

    if (until && StringUtils.length(localDateTime) <= 10) {
      return getEndOfDay(value);
    }

    return value;
  }



  public static LocalDateTime parse(Object object) {
    if(object == null)
      return null;
    if(object instanceof LocalDateTime)
      return (LocalDateTime) object;
    if(object instanceof Instant)
      return LocalDateTime.ofInstant((Instant) object, ZoneId.systemDefault());
    if(object instanceof LocalDate)
      return ((LocalDate) object).atStartOfDay();
    if(object instanceof Date)
      return asLocalDateTime((Date) object);
    if(object instanceof Long)
      return LocalDateTime.ofInstant(Instant.ofEpochMilli((Long) object), ZoneId.systemDefault());
    if(object instanceof String)
      return parse((String) object);
    return null;
  }

  public static LocalDateTime parse(String localDateTime, String dateTimeFormatter) {
    return LocalDateTime.parse(localDateTime, DateTimeFormatter.ofPattern(dateTimeFormatter));
  }

  public static LocalDateTime parseStartOfDayIfAbsentTime(Object object) {
    if (object == null)
      return null;
    String value = String.valueOf(object);
    if (value.length() <= 10) {
      return parseStartOfDay(value);
    }
    return parse(object);
  }

  public static LocalDateTime parseEndOfDayIfAbsentTime(Object object) {
    if (object == null)
      return null;
    String value = String.valueOf(object);
    if (value.length() <= 10) {
      return parseEndOfDay(value);
    }
    return parse(object);
  }

  public static LocalDateTime parseStartOfDay(Object object) {
    LocalDateTime value = parse(object);
    return value == null ? null : getStartOfDay(value);
  }

  public static LocalDateTime parseEndOfDay(Object object) {
    LocalDateTime value = parse(object);
    return value == null ? null : getEndOfDay(value);
  }

  public static Date getDate(LocalDateTime localDateTime) {
    if (localDateTime == null)
      return new Date();    // null safe

    return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
  }

  public static String format(LocalDateTime localDateTime, String format) {
    if (localDateTime == null) {
      return "";
    }
    try{
      return localDateTime.format(DateTimeFormatter.ofPattern(format));
    }catch (Exception e){
      try{
        for(String form : FormatUtil.getDateTimeFormatter()){
          return localDateTime.format(DateTimeFormatter.ofPattern(form));
        }
      }catch (Exception ee){
        // nothing
      }
    }
    return localDateTime.toString();
  }

  /**
   * 기준 날짜가 1년 중 몇주차인지
   *
   * @param dateTime
   * @return
   */
  public static int getWeekOfYear(LocalDateTime dateTime) {

    int firstDayOfWeek = dateTime.withDayOfYear(1).getDayOfWeek().getValue();
    int nowDayOfWeek = dateTime.getDayOfYear();

    return Integer.valueOf((nowDayOfWeek - (firstDayOfWeek - 1)) / 7) + 1;
  }

  /**
   * 기준 일자가 속한 주의 첫날(일요일) 반환
   *
   * @param dateTime
   * @return
   */
  public static LocalDateTime getFirstDayOfWeek(LocalDateTime dateTime) {
    Long minusDays = Long.valueOf(dateTime.getDayOfWeek().getValue() - 1);
    return dateTime.minusDays(minusDays);
  }

  /**
   * 두 날짜가 같은 년도, 같은 월, 같은 일 인지 TimePeriodType 에 따라 확인
   *
   * @param date1
   * @param date2
   * @param timePeriodType
   * @return
   */
  public static boolean isSamePeriod(LocalDateTime date1, LocalDateTime date2, TimePeriodType timePeriodType) {
    if (date1 == null && date2 == null || (date1 == null && date2 != null || date1 != null && date1 == null)) {
      return false;
    } else {

      if (timePeriodType.equals(TimePeriodType.YEAR)) {
        return date1.getYear() == date2.getYear();
      } else {
        if (date1.getYear() == date2.getYear()) {
          if (timePeriodType.equals(TimePeriodType.MONTH)) {
            return date1.getMonthValue() == date2.getMonthValue();
          } else if (timePeriodType.equals(TimePeriodType.DAY)) {
            return (date1.getDayOfYear() == date2.getDayOfYear());
          }
        }
      }
    }
    return false;
  }


  public static LocalDateTime getLocalDateTime(LocalDateTime localDateTime) {
    return getLocalDateTime(localDateTime, LocalDateTime.now());
  }

  public static LocalDateTime getLocalDateTime(LocalDateTime localDateTime, LocalDateTime defaultValue) {
    return (localDateTime == null) ? defaultValue : localDateTime;
  }

  public static LocalDate asLocalDate(Date date) {
    return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
  }

  public static LocalDateTime asLocalDateTime(Date date) {
    return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
  }

  public static LocalDate getEndOfMonth(LocalDateTime localDateTime) {
    return localDateTime.toLocalDate().with(TemporalAdjusters.lastDayOfMonth());
  }

  public static boolean isBetween(LocalDateTime availableAt, LocalDateTime availableUntil) {
    // 현재 날짜와의 비교
    return isBetween(availableAt, availableUntil, null, true);
  }

  public static boolean isBetween(LocalDateTime availableAt, LocalDateTime availableUntil, boolean defaultValue) {
    // 현재 날짜와의 비교
    return isBetween(availableAt, availableUntil, null, defaultValue);
  }

  public static boolean isBetween(LocalDateTime availableAt, LocalDateTime availableUntil, LocalDateTime compareDate, boolean defaultValue) {
    if (availableAt == null && availableUntil == null) {
      return defaultValue;
    } else {
      LocalDateTime now = (compareDate == null) ? LocalDateTime.now() : compareDate;
      if (availableAt != null && availableUntil == null) {
        return availableAt.isBefore(now);
      } else if (availableAt == null && availableUntil != null) {
        return availableUntil.isAfter(now);
      }

      // 현재 시각이 AvailableAt 과 AvailableUntil 사이에 있는지 확인
      return availableAt.isBefore(now) && availableUntil.isAfter(now);
    }
  }

  /**
   * Dao 에서 날짜 캐싱할 때 사용한다. cachedDate가  오차 허용치 dateResolutionNano 이내의 날짜인 경우 해당 날짜를, 아닌 경우 현재 시각을 반환한다
   *
   * @param cachedDate
   * @param dateResolutionNano
   * @return
   */
  public static LocalDateTime getCurrentLocalDateTimeWithinTimeResolution(LocalDateTime cachedDate, Long dateResolutionNano) {
    LocalDateTime now = LocalDateTime.now();

    if (cachedDate.plusNanos(dateResolutionNano).isBefore(now)) {
      return now;
    } else {
      return cachedDate;
    }
  }

  public static LocalDateTime getStartOfDate(LocalDate date){
    if(date == null)
      return getStartOfDay(null);
    return date.atStartOfDay();
  }

  public static LocalDateTime getEndOfDate(LocalDate date){
    if(date == null)
      return getEndOfDay(null);
    return date.atStartOfDay().with(LocalTime.MAX);
  }

  public static LocalDateTime getStartOfDay(LocalDateTime day) {
    day = (day == null) ? LocalDateTime.now() : day;
    return day.with(LocalTime.MIN);
  }

  public static LocalDateTime getEndOfDay(LocalDateTime day) {
    day = (day == null) ? LocalDateTime.now() : day;
    return day.with(LocalTime.MAX);
  }

  public static LocalDateTime getEndOfMonthDay(LocalDateTime day) {
    day = (day == null) ? LocalDateTime.now() : day;
    LocalDate endOfMonth = getEndOfMonth(day);
    return endOfMonth.atTime(LocalTime.MAX);
  }

  public static LocalDateTime getEndOfYearDay(LocalDateTime day){
    day = (day == null) ? LocalDateTime.now() : day;
    LocalDate endOfYear = day.toLocalDate().with(TemporalAdjusters.lastDayOfYear());
    return endOfYear.atTime(LocalTime.MAX);
  }


  public static LocalDateTime parseSafe(String dateTimeString) {
    return parseSafe(null, dateTimeString, null);
  }

  public static LocalDateTime parseSafe(String dateTimeString, String... formatter) {
    return parseSafe(null, dateTimeString, formatter);
  }

  public static LocalDateTime parseSafe(String dateTimeString, LocalDateTime defaultValue) {
    return parseSafe(defaultValue, dateTimeString, null);
  }

  public static LocalDateTime parseSafe(LocalDateTime defaultValue, String dateTimeString, String... formatter) {

    if (StringUtils.isBlank(dateTimeString))
      return (defaultValue == null) ? LocalDateTime.now() : defaultValue;

    try {
      if (ArrayUtils.isNotEmpty(formatter)) {
        for (String format : formatter) {
          try {
            return parse(dateTimeString, format);
          } catch (Exception e) {
            // nothing to do, just retry next format
          }
        }
      }
    } catch (Exception e) {
      // nothing to do, go on belows
    }

    for (String format : FormatUtil.getDateTimeFormatter()) {
      try {
        return parse(dateTimeString, format);
      } catch (Exception ee) {
        // nothing;
      }
    }

    // 날짜만 들어온 경우: yyyy-MM-dd 또는 yyyy.MM.dd 와 같이
    if(dateTimeString.length() == 10)
      return parseSafe(defaultValue, dateTimeString + " 00:00:00", formatter);

    if(dateTimeString.length() == 8){
      dateTimeString = dateTimeString.substring(0, 4) + "." + dateTimeString.substring(4, 6) + "." + dateTimeString.substring(6, 8)
          + " 00:00:00";
      return parseSafe(defaultValue, dateTimeString, formatter);
    }

    return (defaultValue == null) ? LocalDateTime.now() : defaultValue;
  }

  public static boolean hasElapsed(LocalDateTime dateTime, int minute) {
    return hasElapsed(dateTime, LocalDateTime.now(), minute);
  }

  public static boolean hasElapsedHours(LocalDateTime dateTime, int hours) {
    return hasElapsedHours(dateTime, LocalDateTime.now(), hours);
  }

  public static boolean hasElapsedYears(LocalDateTime dateTime, int years) {
    return hasElapsedYears(dateTime, LocalDateTime.now(), years);
  }

  public static boolean hasElapsedDays(LocalDateTime dateTime, int days) {
    return hasElapsedDays(dateTime, LocalDateTime.now(), days);
  }

  public static boolean hasElapsedMonths(LocalDateTime dateTime, int months) {
    return hasElapsedMonths(dateTime, LocalDateTime.now(), months);
  }

  public static boolean hasElapsedSeconds(LocalDateTime dateTime, int seconds) {
    if (dateTime == null)
      return true;
    return dateTime.plusSeconds(seconds).isBefore(LocalDateTime.now());
  }

  public static boolean hasElapsed(LocalDateTime dateTime, LocalDateTime compareDate, int minute) {
    if (dateTime == null)
      return true;
    return dateTime.plusMinutes(minute).isBefore(compareDate);
  }

  public static boolean hasElapsedHours(LocalDateTime dateTime, LocalDateTime compareDate, int hours) {
    if (dateTime == null)
      return true;
    return dateTime.plusHours(hours).isBefore(compareDate);
  }

  public static boolean hasElapsedYears(LocalDateTime dateTime, LocalDateTime compareDate, int years) {
    if (dateTime == null)
      return true;
    return dateTime.plusYears(years).isBefore(compareDate);
  }

  public static boolean hasElapsedDays(LocalDateTime dateTime, LocalDateTime compareDate, int days) {
    if (dateTime == null)
      return true;
    return dateTime.plusDays(days).isBefore(compareDate);
  }

  public static boolean hasElapsedMonths(LocalDateTime dateTime, LocalDateTime compareDate, int months) {
    if (dateTime == null)
      return true;
    return dateTime.plusMonths(months).isBefore(compareDate);
  }

  public static boolean hasElapsedSeconds(LocalDateTime dateTime, LocalDateTime compareDate, int seconds) {
    if (dateTime == null)
      return true;
    return dateTime.plusSeconds(seconds).isBefore(compareDate);
  }

  public static LocalDateTime toLocalDateTime(Calendar calendar) {
    if (calendar == null) {
      return null;
    }
    TimeZone tz = calendar.getTimeZone();
    ZoneId zid = tz == null ? ZoneId.systemDefault() : tz.toZoneId();
    return LocalDateTime.ofInstant(calendar.toInstant(), zid);
  }

  public static String getTimeAgo(LocalDateTime lastDate) {
    return getTimeAgo(lastDate, null, null);
  }

  public static String getTimeAgo(LocalDateTime lastDate, LocalDateTime compareDate, String timeFormat) {
    if(lastDate == null)
      return "";

    if(compareDate == null)
      compareDate = LocalDateTime.now();

    if(LocalDateTimeUtil.hasElapsedDays(lastDate, compareDate, 1)){
      // 하루 이상 지났으면
      return LocalDateTimeUtil.format(lastDate, (timeFormat == null) ? FormatUtil.DATE_FORMAT_WITHOUT_TIMEZONE_DASH : timeFormat);
    }else{

      Duration duration = Duration.between(compareDate, lastDate);

      if(LocalDateTimeUtil.hasElapsedHours(lastDate, compareDate, 1)){
        return LocalDateTimeUtil.format(lastDate, "HH:mm") + " (" + Math.abs(duration.toHours()) + " 시간 전)";
      }else{
        return LocalDateTimeUtil.format(lastDate, "HH:mm") + " (" + Math.abs(duration.toMinutes()) + " 분 전)";
      }

    }
  }

  public static LocalDateTime getStartOfMonthDay(LocalDateTime compareDate) {
    LocalDate day = compareDate.toLocalDate().with(TemporalAdjusters.firstDayOfMonth());
    return day.atTime(LocalTime.MIN);
  }

  public static boolean isBefore(LocalDateTime availableAt, LocalDateTime compareDate) {
    if(availableAt == null)
      return (compareDate != null);
    if(compareDate == null)
      return false;
    return availableAt.isBefore(compareDate);
  }

  public static LocalDateTime getStartOfYearDay(LocalDateTime compareDate) {
    LocalDate day = compareDate.toLocalDate().with(TemporalAdjusters.firstDayOfYear());
    return day.atTime(LocalTime.MIN);
  }

  public static LocalDate getStartOfWeekDay(LocalDate startDate) {
    DayOfWeek dow = startDate.getDayOfWeek();
    if(dow.getValue() == 7)
      return startDate;
    return startDate.minusDays(Long.valueOf(dow.getValue()));
  }

  public static LocalDate getEndOfWeekDay(LocalDate start) {
    DayOfWeek dow = start.getDayOfWeek();
    if(dow.getValue() == 6)
      return start;

    int gap = (dow.getValue() == 7) ? 6 : (6 - dow.getValue());

    return start.plusDays(gap - 1) ;
  }

  /**
   * 두 날짜 간에 월 차이를 가지고 시작월 ~ 종료월 간에 매월 1일 날짜로 날짜 목록을 만든다.
   * 월간 MAU 집계 할 때 시작월 ~ 종료월 을 구할 때 사용한다.
   *
   * startDate 가 endDate 보다 크면 두 날짜의 값을 바꾼다.
   *
   * @param startDate
   * @param endDate
   * @param priorEnddate        두 날짜 간의 월 차이가 maxMonthlyTerms 보다 클 때 어느 날짜에 우선권이 있는지 - true 면 종료일 기준으로 시작일을 당긴다.
   * @param maxMonthlyTerms   두 날짜간의 월 차이를 최대 몇까지 할지 - 이 차이를 벗어 나면 priorEndDate 값을 사용해 보정한다.
   * @param strictTerm 두 날짜의 월간 간격이 지정된 maxMonthlyTerms 와 같지 않으면 같게 조정한다.
   * @return
   */
  public static List<LocalDate> getMonthlyTermedLocalDates(LocalDate startDate, LocalDate endDate, boolean priorEnddate, int maxMonthlyTerms, boolean strictTerm) {
    List<LocalDate> targetDates = new ArrayList<>();

    YearMonth start = YearMonth.from(startDate);
    YearMonth end = YearMonth.from(endDate);

    if(start.equals(end)){
      start = start.minusMonths(maxMonthlyTerms -1);
    }

    if(start.isAfter(end)){
      YearMonth newEnd = YearMonth.of(start.getYear(), start.getMonth());
      start = end;
      end = newEnd;
    }

    startDate = start.atDay(1);
    endDate = end.atDay(1);

    int gap = Long.valueOf((ChronoUnit.MONTHS.between(startDate, endDate))).intValue();

    if(gap > maxMonthlyTerms){
      if(priorEnddate){
        startDate = startDate.plusMonths(gap-maxMonthlyTerms+1);
      }else{
        endDate = endDate.minusMonths(gap-maxMonthlyTerms+1);
      }
    }else{
      if(strictTerm){
        int gapMonth = maxMonthlyTerms - gap -1;

        if(priorEnddate){
          startDate = startDate.minusMonths(gapMonth);
        }else{
          endDate = endDate.plusMonths(gapMonth);
        }
      }
    }

    while(true){
      if(startDate.isAfter(endDate)) {
        break;
      }

      targetDates.add(startDate);

      startDate = startDate.plusMonths(1l);
    }

    return targetDates;
  }

  public static List<LocalDate> getWeeklyTermedLocalDates(LocalDate startDate, LocalDate endDate, boolean priorEnddate, int maxWeeklyTerms, boolean strictTerm) {
    List<LocalDate> targetDates = new ArrayList<>();
    startDate = LocalDateTimeUtil.getStartOfWeekDay(startDate);
    endDate = LocalDateTimeUtil.getEndOfWeekDay(endDate);

    if(startDate.isAfter(endDate)){
      LocalDate newEndDate = LocalDate.of(startDate.getYear(), startDate.getMonth(), startDate.getDayOfMonth());
      startDate = LocalDateTimeUtil.getStartOfWeekDay(endDate);
      endDate = LocalDateTimeUtil.getEndOfWeekDay(newEndDate);
    }

    long gap = ((ChronoUnit.DAYS.between(startDate, endDate)+1) / 7);
    if(gap > maxWeeklyTerms){
      int gapWeeks = Long.valueOf(gap).intValue() - maxWeeklyTerms;
      if(strictTerm){
        if(gapWeeks > maxWeeklyTerms){
          gapWeeks = gapWeeks + 1;
        }
        /*if(gapWeeks < maxWeeklyTerms){
          gapWeeks = maxWeeklyTerms - gapWeeks;
        }*/
      }

      int gapDays = (gapWeeks ) * 7;

      if(priorEnddate){
        startDate = startDate.plusDays(gapDays);
      }else{
        endDate = endDate.minusDays(gapDays);
      }
    }else if(maxWeeklyTerms > gap){
      if(strictTerm){
        gap = gap + 1;

        // gap 이 차이가 있으면 무조건 조정한다.
        if(priorEnddate){
          startDate = startDate.minusDays((maxWeeklyTerms - gap) * 7);
        }else{
          endDate = endDate.plusDays((maxWeeklyTerms - gap) * 7);
        }
      }
    }/*else if(maxWeeklyTerms == gap){
      if(priorEnddate){
        startDate = startDate.plusDays(7);
      }else{
        endDate = endDate.minusDays(7);
      }
    }*/


    while(true){
      if(!startDate.isBefore(endDate)) {
        break;
      }

      targetDates.add(startDate);

      startDate = startDate.plusDays(7l);   // 일주일 후로 이동
    }
    return targetDates;
  }


  public static List<LocalDate> getDailyTermedLocalDates(LocalDate startDate, LocalDate endDate, boolean priorEnddate, int maxDailyTerms, boolean strictTerm) {
    List<LocalDate> targetDates = new ArrayList<>();

    if(startDate.isAfter(endDate)){
      LocalDate newEndDate = LocalDate.of(startDate.getYear(), startDate.getMonth(), startDate.getDayOfMonth());
      startDate = endDate;
      endDate = newEndDate;
    }

    long gap = ((ChronoUnit.DAYS.between(startDate, endDate))+1);
    if(gap > maxDailyTerms){
      if(priorEnddate){
        startDate = endDate.minusDays(maxDailyTerms-1);
      }else{
        endDate = startDate.plusDays(maxDailyTerms-1);
      }
    }else{
      if(strictTerm){
        if(gap < maxDailyTerms){
          // gap 이 차이가 있으면 무조건 조정한다.
          int gapDays = maxDailyTerms - Long.valueOf(gap).intValue();
          if(priorEnddate){
            startDate = startDate.minusDays(gapDays);
          }else{
            endDate = endDate.plusDays(gapDays);
          }
        }
      }
    }


    while(true){
      if(startDate.isAfter(endDate)) {
        break;
      }

      targetDates.add(startDate);

      startDate = startDate.plusDays(1l);   // 1일 후로 이동
    }
    return targetDates;
  }

  /**
   * 앞의 시작일, 종료일이 뒤의 시작일 종료일과 서로 겹치는 구간이 있는지
   * @param availableAt
   * @param availableUntil
   * @param startDate
   * @param endDate
   * @return
   */
  public static boolean isDuplicatedPeriod(LocalDateTime availableAt, LocalDateTime availableUntil, LocalDateTime startDate, LocalDateTime endDate) {

    // validate values
    LocalDateTime now = LocalDateTime.now();
    if(availableAt == null)
      availableAt = now;

    if(startDate == null)
      startDate = now;

    if(availableUntil == null)
      availableUntil = LocalDateTime.MAX;

    if(endDate == null)
      endDate = LocalDateTime.MAX;

    if(isBetween(startDate, endDate, availableAt, false)){
      // availableAt이 startDate 와 endDate 사이에 있을 때
      return true;
    }

    // availableAt이 startDate 와 endDate 사이에 있을 때
    return isBetween(startDate, endDate, availableUntil, false);

  }

  public static boolean equals(LocalDateTime date1, LocalDateTime date2) {
    if(date1 == null){
      if(date2 != null){
        return false;
      }
    }else{
      if(date2 == null){
        return false;
      }
    }
    return date1.equals(date2);
  }

  public static String format(LocalDateTime date) {
    return format(date, FormatUtil.DATE_FORMAT_WITHOUT_TIMEZONE_DASH);
  }


  public static LocalDateTime getLocalDateTime(Object value){
    return getLocalDateTime(value, null);
  }
  public static LocalDateTime getLocalDateTime(Object value, LocalDateTime defaultValue) {
    if(value == null)
      return defaultValue;

    LocalDateTime localDateTime = null;

    if(value instanceof LocalDateTime){
      localDateTime = (LocalDateTime) value;
    }else if(value instanceof Date){
      Date date = (Date) value;
      localDateTime = new Timestamp(date.getTime()).toLocalDateTime();
    }else if(value instanceof Long){
      localDateTime = new Timestamp((Long) value).toLocalDateTime();
    }else{
      String str = String.valueOf(value);
      localDateTime = parse(str);
    }

    return (localDateTime == null) ? defaultValue : localDateTime;

  }
}
