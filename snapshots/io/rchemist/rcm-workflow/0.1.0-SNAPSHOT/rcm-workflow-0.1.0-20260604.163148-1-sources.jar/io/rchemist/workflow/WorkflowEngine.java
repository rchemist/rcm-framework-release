/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — Workflow 진입점 (RFC 23 §3.5 정합).
 *
 * <p>Phase 7 MVP scope — sequential 실행:
 * <ol>
 *   <li>{@link WorkflowDefinition#steps()} 순서대로 실행</li>
 *   <li>각 step 의 output → 다음 step 의 input (Skip 영역은 input 그대로 propagate)</li>
 *   <li>첫 Failure 시 — compensation 이 있으면 *마지막 input* 으로 호출 + compensationResult 보존</li>
 *   <li>{@link WorkflowResult} 발행 — finalResult + stepHistory + compensationResult</li>
 * </ol>
 *
 * <p>§B1-4 — 단계별 (per-step) saga 보상 추가. Failure(compensateRequired=true) 시 이전에
 * Success 한 step 의 {@link WorkflowStep#compensate(Object, WorkflowContext)} 를 *역순* 으로 호출.
 * definition-level compensation 은 그 후에 호출 (보존).
 **/
public class WorkflowEngine {

  private final WorkflowMetricsRegistry metrics;

  public WorkflowEngine() {
    this(null);
  }

  /**
   * §B1-6 — registry 인입 시 매 실행마다 카운터 기록. null 허용 (기본 standalone 영역). auto-config
   * 가 registry bean 영역 wire 시 actuator endpoint 와 정합.
   */
  public WorkflowEngine(WorkflowMetricsRegistry metrics) {
    this.metrics = metrics;
  }

  /** workflow 실행. {@code def} + {@code input} → {@link WorkflowResult}. */
  @SuppressWarnings({"unchecked", "rawtypes"})
  public <I, O> WorkflowResult<O> run(WorkflowDefinition<I, O> def, I input) {
    WorkflowContext context =
        new WorkflowContext(def.name(), UUID.randomUUID().toString(), Map.of(), Instant.now());

    List<StepResult<?>> history = new ArrayList<>();
    List<StepCompletion> successful = new ArrayList<>();
    List<StepResult<?>> stepCompensations = new ArrayList<>();
    Object current = input;
    StepResult<?> finalResult = null;
    StepResult<?> compensationResult = null;

    for (WorkflowStep<?, ?> step : def.steps()) {
      WorkflowStep raw = step;
      StepResult<?> result = raw.execute(current, context);
      history.add(result);

      if (result instanceof StepResult.Failure<?> failure) {
        finalResult = result;
        if (failure.compensateRequired()) {
          // 역순 per-step compensation
          for (int i = successful.size() - 1; i >= 0; i--) {
            StepCompletion completion = successful.get(i);
            WorkflowStep stepRef = completion.step();
            StepResult<Void> compRes = stepRef.compensate(completion.output(), context);
            stepCompensations.add(compRes);
          }
          // definition-level compensation (보존)
          if (def.compensation().isPresent()) {
            WorkflowStep compensation = def.compensation().get();
            compensationResult = compensation.execute(current, context);
          }
        }
        break;
      } else if (result instanceof StepResult.Skip<?>) {
        finalResult = result;
        break;
      } else if (result instanceof StepResult.Success<?> success) {
        current = success.output();
        finalResult = result;
        successful.add(new StepCompletion(step, success.output()));
      }
    }

    WorkflowResult<O> result =
        new WorkflowResult<>(
            (StepResult<O>) finalResult, history, compensationResult, stepCompensations);
    if (metrics != null) {
      boolean compFired = !stepCompensations.isEmpty() || compensationResult != null;
      metrics.record(def.name(), result.succeeded(), compFired);
    }
    return result;
  }

  private record StepCompletion(WorkflowStep<?, ?> step, Object output) {}
}
