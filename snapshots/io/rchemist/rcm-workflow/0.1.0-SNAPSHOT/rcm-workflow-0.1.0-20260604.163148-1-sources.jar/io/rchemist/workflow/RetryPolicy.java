/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-1 — {@link RetryableStep} 의 재시도 정책. 최대 시도 회수 + 초기 지연 + backoff 배수.
 *
 * <p>fixed(N, delay) = 동일 지연 N회. exponential(N, initial, mult) = initial × mult^k.
 *
 * @param maxAttempts 총 시도 회수 (≥ 1, 1 = 재시도 없음)
 * @param initialDelayMillis 첫 재시도 직전 sleep (≥ 0)
 * @param backoffMultiplier 다음 지연 배수 (> 0, 1.0 = fixed)
 **/
public record RetryPolicy(int maxAttempts, long initialDelayMillis, double backoffMultiplier) {

  public RetryPolicy {
    if (maxAttempts < 1) {
      throw new IllegalArgumentException("maxAttempts must be ≥ 1, got " + maxAttempts);
    }
    if (initialDelayMillis < 0) {
      throw new IllegalArgumentException(
          "initialDelayMillis must be ≥ 0, got " + initialDelayMillis);
    }
    if (backoffMultiplier <= 0) {
      throw new IllegalArgumentException(
          "backoffMultiplier must be > 0, got " + backoffMultiplier);
    }
  }

  /** 동일 지연 fixed delay. */
  public static RetryPolicy fixed(int maxAttempts, long delayMillis) {
    return new RetryPolicy(maxAttempts, delayMillis, 1.0);
  }

  /** 지연 = initial × multiplier^(attempt-1). attempt 1 ~ N-1 사이 적용. */
  public static RetryPolicy exponential(
      int maxAttempts, long initialDelayMillis, double backoffMultiplier) {
    return new RetryPolicy(maxAttempts, initialDelayMillis, backoffMultiplier);
  }
}
