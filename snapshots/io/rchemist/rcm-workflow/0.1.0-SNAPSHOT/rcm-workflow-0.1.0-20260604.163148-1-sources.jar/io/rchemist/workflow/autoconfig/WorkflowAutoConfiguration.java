/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow.autoconfig;

import io.rchemist.workflow.WorkflowEngine;
import io.rchemist.workflow.WorkflowMetricsRegistry;
import io.rchemist.workflow.WorkflowsEndpoint;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 (Decision #2 옵션 D 자체 DSL) — {@link WorkflowEngine} 자동 등록. Consumer 가 자체
 * WorkflowEngine bean 정의 시 {@link ConditionalOnMissingBean} 자동 양보. T9-14a (2026-05-04) — 본
 * auto-config 미존재 시 Consumer 가 직접 @Bean 으로 wire 해야 했던 누락 fix.
 *
 * <p>§B1-6 — {@link WorkflowMetricsRegistry} + {@link WorkflowsEndpoint} 추가. endpoint 는 actuator
 * classpath (Endpoint annotation 영역) 가 있을 때만 활성.
 **/
@AutoConfiguration
public class WorkflowAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public WorkflowMetricsRegistry workflowMetricsRegistry() {
    return new WorkflowMetricsRegistry();
  }

  @Bean
  @ConditionalOnMissingBean
  public WorkflowEngine workflowEngine(WorkflowMetricsRegistry workflowMetricsRegistry) {
    return new WorkflowEngine(workflowMetricsRegistry);
  }

  @Bean
  @ConditionalOnClass(Endpoint.class)
  @ConditionalOnMissingBean
  public WorkflowsEndpoint workflowsEndpoint(
      ListableBeanFactory beanFactory, WorkflowMetricsRegistry workflowMetricsRegistry) {
    return new WorkflowsEndpoint(beanFactory, workflowMetricsRegistry);
  }
}
