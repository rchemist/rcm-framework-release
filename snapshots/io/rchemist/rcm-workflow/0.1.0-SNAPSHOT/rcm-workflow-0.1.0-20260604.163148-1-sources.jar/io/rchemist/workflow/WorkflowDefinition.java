/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — Workflow 단위 정의 (RFC 23 §3.1 정합).
 *
 * <p>Phase 7 MVP scope — sequential step pipeline + 단일 compensation. step 은 *순서 보존*
 * (List.of() 패턴) 영역. compensation 은 첫 Failure 시 호출 (모든 후속 step 건너뜀).
 *
 * @param name workflow 식별자 (engine 의 lookup key)
 * @param inputType pipeline 진입 input type (검증 영역)
 * @param outputType 마지막 step 의 output type (검증 영역)
 * @param steps 순차 실행 step 목록 — 첫 step 의 input = pipeline input
 * @param compensation 첫 Failure 영역 보상 step (선택)
 **/
public record WorkflowDefinition<I, O>(
    String name,
    Class<I> inputType,
    Class<O> outputType,
    List<WorkflowStep<?, ?>> steps,
    Optional<WorkflowStep<?, ?>> compensation) {

  public WorkflowDefinition {
    Objects.requireNonNull(name, "name");
    Objects.requireNonNull(inputType, "inputType");
    Objects.requireNonNull(outputType, "outputType");
    steps = List.copyOf(Objects.requireNonNull(steps, "steps"));
    Objects.requireNonNull(compensation, "compensation");
    if (steps.isEmpty()) {
      throw new IllegalArgumentException("workflow '" + name + "' must have at least 1 step");
    }
  }

  /** compensation 부재 영역의 Builder helper — caller 영역의 boilerplate 회피. */
  public static <I, O> WorkflowDefinition<I, O> of(
      String name, Class<I> inputType, Class<O> outputType, List<WorkflowStep<?, ?>> steps) {
    return new WorkflowDefinition<>(name, inputType, outputType, steps, Optional.empty());
  }
}
