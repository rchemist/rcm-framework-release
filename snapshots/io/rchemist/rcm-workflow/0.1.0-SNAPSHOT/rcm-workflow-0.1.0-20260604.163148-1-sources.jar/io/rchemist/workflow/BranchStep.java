/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.Objects;
import java.util.function.BiPredicate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-2 — predicate 기반 분기 step. {@link #when(BiPredicate, WorkflowStep, WorkflowStep)} =
 * 항상 한쪽 branch 실행. {@link #optional(BiPredicate, WorkflowStep)} = predicate true 시 step
 * 실행 / false 시 input 그대로 passthrough (I = O 영역만 가능).
 *
 * <p>predicate 영역 throws = {@code Failure(cause, false)} 변환 — 후속 step 진행 없이
 * compensation 결정은 caller / engine 영역.
 *
 * <p>현 engine 의 {@link StepResult.Skip} 영역 = pipeline halt 동작 정합 — 본 BranchStep 은
 * Skip 사용 X. 항상 Success / Failure 반환.
 **/
public final class BranchStep<I, O> implements WorkflowStep<I, O> {

  private final BiPredicate<I, WorkflowContext> predicate;
  private final WorkflowStep<I, O> thenStep;
  private final WorkflowStep<I, O> elseStep;

  private BranchStep(
      BiPredicate<I, WorkflowContext> predicate,
      WorkflowStep<I, O> thenStep,
      WorkflowStep<I, O> elseStep) {
    this.predicate = Objects.requireNonNull(predicate, "predicate");
    this.thenStep = Objects.requireNonNull(thenStep, "thenStep");
    this.elseStep = Objects.requireNonNull(elseStep, "elseStep");
  }

  /** 두 branch 모두 명시 — predicate true → thenStep / false → elseStep. */
  public static <I, O> BranchStep<I, O> when(
      BiPredicate<I, WorkflowContext> predicate,
      WorkflowStep<I, O> thenStep,
      WorkflowStep<I, O> elseStep) {
    return new BranchStep<>(predicate, thenStep, elseStep);
  }

  /**
   * predicate true 시 step 실행 / false 시 input passthrough. I = T 영역만 가능 (passthrough 의
   * type-safe 영역).
   */
  public static <T> BranchStep<T, T> optional(
      BiPredicate<T, WorkflowContext> predicate, WorkflowStep<T, T> step) {
    return new BranchStep<>(
        predicate, Objects.requireNonNull(step, "step"), (input, ctx) -> new StepResult.Success<>(input));
  }

  @Override
  public StepResult<O> execute(I input, WorkflowContext context) {
    boolean go;
    try {
      go = predicate.test(input, context);
    } catch (Throwable t) {
      return new StepResult.Failure<>(t, false);
    }
    return go ? thenStep.execute(input, context) : elseStep.execute(input, context);
  }

  @Override
  public String name() {
    return "branch(" + thenStep.name() + "|" + elseStep.name() + ")";
  }
}
