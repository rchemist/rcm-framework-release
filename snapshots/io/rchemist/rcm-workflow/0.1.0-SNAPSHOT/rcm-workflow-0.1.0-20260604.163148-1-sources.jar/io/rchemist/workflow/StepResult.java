/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — {@link WorkflowStep#execute(Object, WorkflowContext)} 의 sealed 결과.
 *
 * <p>3 종 (RFC 23 §3.4 정합):
 * <ul>
 *   <li>{@link Success} — output 보유 + pipeline 다음 step 진행</li>
 *   <li>{@link Failure} — cause 보존 + compensateRequired flag (true 시 compensation 호출)</li>
 *   <li>{@link Skip} — 다음 step 으로 건너뜀 + 이전 input 그대로 propagate (caller 책임)</li>
 * </ul>
 *
 * <p>Sealed type — 향후 추가 결과 type 신설 시 명시적 결정 영역.
 **/
public sealed interface StepResult<O> permits StepResult.Success, StepResult.Failure, StepResult.Skip {

  record Success<O>(O output) implements StepResult<O> {
    public Success {
      // null output 허용 — 의도된 void step 영역
    }
  }

  record Failure<O>(Throwable cause, boolean compensateRequired) implements StepResult<O> {
    public Failure {
      java.util.Objects.requireNonNull(cause, "cause");
    }
  }

  record Skip<O>() implements StepResult<O> {}
}
