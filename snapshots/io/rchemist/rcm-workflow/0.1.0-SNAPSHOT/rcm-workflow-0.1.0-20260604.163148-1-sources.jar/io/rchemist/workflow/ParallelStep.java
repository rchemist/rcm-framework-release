/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-3 — N 개 sub-step 을 VirtualThread executor 로 동시 실행. 동일 input 을 모든 sub-step 에
 * 전달, 결과 {@code List<O>} 를 *제출 순서* 보존하여 aggregate.
 *
 * <p>Result 정책:
 * <ul>
 *   <li>모두 Success → {@code Success(List<O>)} 제출 순서 보존</li>
 *   <li>1 개 이상 Failure → {@code Failure(aggregate, compensateRequired = OR)}.
 *     첫 Failure 의 cause = primary, 나머지는 {@link Throwable#addSuppressed(Throwable)}.</li>
 *   <li>Skip → {@code Failure(IllegalStateException("step skipped in parallel"), false)} 변환.
 *     parallel context 에서 Skip 의 의미가 모호하므로 명시적 Failure 로 격상.</li>
 *   <li>Timeout 만료 → {@code Failure(TimeoutException, false)}. 미완료 Future 는 cancel.</li>
 * </ul>
 *
 * <p>JDK 25 VirtualThread default ON 정합 — {@link Executors#newVirtualThreadPerTaskExecutor()}
 * 사용. ScopedValue 영역 인입 시 carrier thread 영역 정합.
 **/
public final class ParallelStep<I, O> implements WorkflowStep<I, List<O>> {

  private final List<WorkflowStep<I, O>> steps;
  private final Duration timeout;

  private ParallelStep(List<WorkflowStep<I, O>> steps, Duration timeout) {
    Objects.requireNonNull(steps, "steps");
    if (steps.isEmpty()) {
      throw new IllegalArgumentException("ParallelStep requires at least 1 sub-step");
    }
    this.steps = List.copyOf(steps);
    this.timeout = timeout;
  }

  /** timeout 없이 모든 sub-step 완료까지 대기. */
  public static <I, O> ParallelStep<I, O> of(List<WorkflowStep<I, O>> steps) {
    return new ParallelStep<>(steps, null);
  }

  /** timeout 만료 시 미완료 future cancel + Failure 반환. */
  public static <I, O> ParallelStep<I, O> of(List<WorkflowStep<I, O>> steps, Duration timeout) {
    return new ParallelStep<>(steps, Objects.requireNonNull(timeout, "timeout"));
  }

  @Override
  public StepResult<List<O>> execute(I input, WorkflowContext context) {
    try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
      List<Future<StepResult<O>>> futures = new ArrayList<>(steps.size());
      for (WorkflowStep<I, O> step : steps) {
        futures.add(executor.submit(() -> step.execute(input, context)));
      }

      long deadlineNanos = timeout == null ? Long.MAX_VALUE : System.nanoTime() + timeout.toNanos();

      List<O> outputs = new ArrayList<>(steps.size());
      Throwable primary = null;
      boolean compensateRequired = false;

      for (Future<StepResult<O>> future : futures) {
        StepResult<O> result;
        try {
          if (timeout == null) {
            result = future.get();
          } else {
            long remaining = deadlineNanos - System.nanoTime();
            if (remaining <= 0) {
              throw new TimeoutException("ParallelStep timeout");
            }
            result = future.get(remaining, TimeUnit.NANOSECONDS);
          }
        } catch (TimeoutException te) {
          cancelAll(futures);
          return new StepResult.Failure<>(te, false);
        } catch (InterruptedException ie) {
          Thread.currentThread().interrupt();
          cancelAll(futures);
          return new StepResult.Failure<>(ie, false);
        } catch (ExecutionException ee) {
          Throwable cause = ee.getCause() == null ? ee : ee.getCause();
          if (primary == null) {
            primary = cause;
          } else {
            primary.addSuppressed(cause);
          }
          continue;
        }

        if (result instanceof StepResult.Success<O> s) {
          outputs.add(s.output());
        } else if (result instanceof StepResult.Failure<O> f) {
          if (primary == null) {
            primary = f.cause();
          } else {
            primary.addSuppressed(f.cause());
          }
          compensateRequired = compensateRequired || f.compensateRequired();
        } else if (result instanceof StepResult.Skip<O>) {
          IllegalStateException skipped =
              new IllegalStateException("step skipped in parallel context");
          if (primary == null) {
            primary = skipped;
          } else {
            primary.addSuppressed(skipped);
          }
        }
      }

      if (primary != null) {
        return new StepResult.Failure<>(primary, compensateRequired);
      }
      return new StepResult.Success<>(List.copyOf(outputs));
    }
  }

  private static void cancelAll(List<? extends Future<?>> futures) {
    for (Future<?> f : futures) {
      f.cancel(true);
    }
  }

  @Override
  public String name() {
    return "parallel(" + steps.size() + ")";
  }
}
