/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-1 — 외부 호출 / 일시적 장애 영역 {@link WorkflowStep} 자동 재시도 wrapper. delegate 의
 * Failure 결과 시 {@link RetryPolicy} 에 따라 재호출. Success / Skip 은 즉시 반환 (재시도 X).
 *
 * <p>compensateRequired flag = 마지막 attempt 의 Failure 그대로 propagate — engine 의 compensation
 * 결정 영역 보존.
 *
 * <p>backoff sleep 중 InterruptedException 영역 = Failure(InterruptedException, false) 반환 +
 * thread interrupt 상태 보존 (Java 표준 관례 정합).
 **/
public final class RetryableStep<I, O> implements WorkflowStep<I, O> {

  private final WorkflowStep<I, O> delegate;
  private final RetryPolicy policy;

  private RetryableStep(WorkflowStep<I, O> delegate, RetryPolicy policy) {
    this.delegate = Objects.requireNonNull(delegate, "delegate");
    this.policy = Objects.requireNonNull(policy, "policy");
  }

  /** delegate step + policy 결합. */
  public static <I, O> RetryableStep<I, O> wrap(WorkflowStep<I, O> delegate, RetryPolicy policy) {
    return new RetryableStep<>(delegate, policy);
  }

  @Override
  public StepResult<O> execute(I input, WorkflowContext context) {
    StepResult<O> last = null;
    long delay = policy.initialDelayMillis();
    for (int attempt = 1; attempt <= policy.maxAttempts(); attempt++) {
      last = delegate.execute(input, context);
      if (!(last instanceof StepResult.Failure<O>)) {
        return last;
      }
      if (attempt == policy.maxAttempts()) {
        return last;
      }
      if (delay > 0) {
        try {
          Thread.sleep(delay);
        } catch (InterruptedException ie) {
          Thread.currentThread().interrupt();
          return new StepResult.Failure<>(ie, false);
        }
      }
      delay = (long) (delay * policy.backoffMultiplier());
    }
    return last;
  }

  @Override
  public String name() {
    return "retry(" + policy.maxAttempts() + ")→" + delegate.name();
  }
}
