/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-6 — workflow 실행 통계 카운터 (per-workflow name). engine 이 record* 호출, endpoint 가
 * snapshot() 으로 노출. ConcurrentHashMap + AtomicLong = lock-free 영역.
 **/
public final class WorkflowMetricsRegistry {

  private final ConcurrentHashMap<String, Counters> byName = new ConcurrentHashMap<>();

  /** {@link WorkflowEngine} 에서 매 실행마다 호출. */
  public void record(String workflowName, boolean success, boolean compensationFired) {
    Counters c = byName.computeIfAbsent(workflowName, k -> new Counters());
    c.executions.incrementAndGet();
    if (success) {
      c.successes.incrementAndGet();
    } else {
      c.failures.incrementAndGet();
    }
    if (compensationFired) {
      c.compensations.incrementAndGet();
    }
  }

  /** snapshot — endpoint 노출 영역. */
  public Map<String, Snapshot> snapshot() {
    Map<String, Snapshot> out = new java.util.LinkedHashMap<>();
    byName.forEach((name, c) -> out.put(name, c.snapshot()));
    return Collections.unmodifiableMap(out);
  }

  private static final class Counters {
    final AtomicLong executions = new AtomicLong();
    final AtomicLong successes = new AtomicLong();
    final AtomicLong failures = new AtomicLong();
    final AtomicLong compensations = new AtomicLong();

    Snapshot snapshot() {
      return new Snapshot(executions.get(), successes.get(), failures.get(), compensations.get());
    }
  }

  /** 카운터 immutable snapshot. */
  public record Snapshot(long executions, long successes, long failures, long compensations) {}
}
