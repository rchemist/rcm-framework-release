/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — Workflow 단위 실행 영역의 immutable context.
 *
 * <p>{@code attributes} 는 step 간 공유 영역 — 본 Record 는 *immutable copy* 보장 (방어 복사).
 * step 이 새 attribute 를 추가하려면 {@link #withAttribute(String, Object)} 로 신규 context 생성.
 *
 * <p>RFC 23 §3.3 정합. {@code workflowId} = {@link WorkflowDefinition#name()}, {@code executionId}
 * = engine 이 부여하는 고유 ID (UUID).
 **/
public record WorkflowContext(
    String workflowId, String executionId, Map<String, Object> attributes, Instant startedAt) {

  public WorkflowContext {
    Objects.requireNonNull(workflowId, "workflowId");
    Objects.requireNonNull(executionId, "executionId");
    Objects.requireNonNull(startedAt, "startedAt");
    attributes = attributes == null ? Map.of() : Map.copyOf(attributes);
  }

  /** 신규 attribute 추가된 새로운 context 발행. 원본 context 는 보존. */
  public WorkflowContext withAttribute(String key, Object value) {
    Map<String, Object> next = new HashMap<>(attributes);
    next.put(Objects.requireNonNull(key, "key"), value);
    return new WorkflowContext(workflowId, executionId, next, startedAt);
  }

  /** type-safe 조회 helper. 누락 시 null. */
  @SuppressWarnings("unchecked")
  public <T> T attribute(String key) {
    return (T) attributes.get(key);
  }
}
