/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import io.rchemist.extension.ExtensionPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — Workflow 단위 step SPI.
 *
 * <p>RFC 23 §3.2 정합. {@code @ExtensionPoint} 부착 — Phase 7 #2 의 {@code /actuator/extensions}
 * 자동 발견 영역. Consumer 의 step 빈 등록 시 운영 영역에서 가시.
 *
 * <p>Functional interface — Consumer 영역에서 lambda 영역 사용 가능. 명명 영역 override 시
 * {@link #name()} default 영역 보강.
 **/
@ExtensionPoint("workflow step")
@FunctionalInterface
public interface WorkflowStep<I, O> {

  StepResult<O> execute(I input, WorkflowContext context);

  /** step 영역 식별 — 기본 simple class name. lambda 영역의 경우 caller override 권장. */
  default String name() {
    return getClass().getSimpleName();
  }

  /**
   * §B1-4 — Saga 단계별 보상. engine 이 후속 step Failure (compensateRequired=true) 시
   * 본 step 의 output 을 인자로 호출. 호출 순서 = 실행 역순 (가장 최근 Success → 첫 Success).
   *
   * <p>default = no-op {@code Success(null)}. side-effect 없는 step (검증 / 변환 등) 은
   * default 그대로. 외부 reservation / DB write / 결제 등은 override 권장.
   */
  default StepResult<Void> compensate(O completedOutput, WorkflowContext context) {
    return new StepResult.Success<>(null);
  }
}
