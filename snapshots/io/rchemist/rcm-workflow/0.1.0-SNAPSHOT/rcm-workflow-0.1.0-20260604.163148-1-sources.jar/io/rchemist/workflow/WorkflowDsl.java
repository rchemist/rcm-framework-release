/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiPredicate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-5 — fluent builder. raw {@code new WorkflowDefinition<>(...) + List.of(...)} 대체.
 *
 * <pre>
 * WorkflowDsl.start("order-saga", Order.class, Order.class)
 *     .step(validate)
 *     .optional((o, ctx) -&gt; o.totalAmount &gt; 100_000, riskCheck)
 *     .step(reserve)
 *     .retry(RetryPolicy.fixed(3, 50), charge)
 *     .step(finalize)
 *     .compensateWith(refundAndRelease)
 *     .build();
 * </pre>
 *
 * <p>step 간 type 검증 영역 = caller 책임 (raw {@code WorkflowStep<?, ?>} 구성). engine 의 erasure
 * 정합 — pipeline 의 type-safety 영역은 inputType/outputType 의 진단 영역만.
 **/
public final class WorkflowDsl<I, O> {

  private final String name;
  private final Class<I> inputType;
  private final Class<O> outputType;
  private final List<WorkflowStep<?, ?>> steps = new ArrayList<>();
  private WorkflowStep<?, ?> compensation;

  private WorkflowDsl(String name, Class<I> inputType, Class<O> outputType) {
    this.name = Objects.requireNonNull(name, "name");
    this.inputType = Objects.requireNonNull(inputType, "inputType");
    this.outputType = Objects.requireNonNull(outputType, "outputType");
  }

  /** 신규 builder 시작. */
  public static <I, O> WorkflowDsl<I, O> start(
      String name, Class<I> inputType, Class<O> outputType) {
    return new WorkflowDsl<>(name, inputType, outputType);
  }

  /** raw step 추가. */
  public WorkflowDsl<I, O> step(WorkflowStep<?, ?> step) {
    steps.add(Objects.requireNonNull(step, "step"));
    return this;
  }

  /** {@link RetryableStep#wrap(WorkflowStep, RetryPolicy)} 결합 — Failure 시 자동 재시도. */
  public <X, Y> WorkflowDsl<I, O> retry(RetryPolicy policy, WorkflowStep<X, Y> step) {
    steps.add(RetryableStep.wrap(step, policy));
    return this;
  }

  /** {@link BranchStep#when(BiPredicate, WorkflowStep, WorkflowStep)} 결합. */
  public <X, Y> WorkflowDsl<I, O> branch(
      BiPredicate<X, WorkflowContext> predicate,
      WorkflowStep<X, Y> thenStep,
      WorkflowStep<X, Y> elseStep) {
    steps.add(BranchStep.when(predicate, thenStep, elseStep));
    return this;
  }

  /** {@link BranchStep#optional(BiPredicate, WorkflowStep)} 결합 — false 시 input passthrough. */
  public <X> WorkflowDsl<I, O> optional(
      BiPredicate<X, WorkflowContext> predicate, WorkflowStep<X, X> step) {
    steps.add(BranchStep.optional(predicate, step));
    return this;
  }

  /** {@link ParallelStep#of(List)} 결합 — N step 동시 실행. */
  public <X, Y> WorkflowDsl<I, O> parallel(List<WorkflowStep<X, Y>> parallelSteps) {
    steps.add(ParallelStep.of(parallelSteps));
    return this;
  }

  /** {@link ParallelStep#of(List, Duration)} 결합 — N step 동시 실행 + timeout. */
  public <X, Y> WorkflowDsl<I, O> parallel(
      List<WorkflowStep<X, Y>> parallelSteps, Duration timeout) {
    steps.add(ParallelStep.of(parallelSteps, timeout));
    return this;
  }

  /** definition-level compensation 설정 (per-step compensate 와 별도). */
  public WorkflowDsl<I, O> compensateWith(WorkflowStep<?, ?> compensation) {
    this.compensation = Objects.requireNonNull(compensation, "compensation");
    return this;
  }

  /** {@link WorkflowDefinition} 발행. step 0 거부. */
  public WorkflowDefinition<I, O> build() {
    return new WorkflowDefinition<>(
        name, inputType, outputType, List.copyOf(steps), Optional.ofNullable(compensation));
  }
}
