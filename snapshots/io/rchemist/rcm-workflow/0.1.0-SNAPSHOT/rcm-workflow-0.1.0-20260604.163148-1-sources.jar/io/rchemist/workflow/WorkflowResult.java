/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 7 task #4 — Workflow 실행 결과 (RFC 23 §3.5 정합).
 *
 * <p>§B1-4 — {@code stepCompensations} 추가 (per-step saga 보상 결과, 역순). 0.1.0 그린필드 영역
 * 으로 backward-compat shim 없이 추가.
 *
 * @param finalResult 마지막 step (또는 첫 Failure / Skip 시 그 시점) 의 결과
 * @param stepHistory step 별 결과 순서 보존 (디버깅 / 감사 영역)
 * @param compensationResult definition-level compensation 호출 영역 — 부재 시 null (compensation 미실행)
 * @param stepCompensations 단계별 (per-step) 보상 결과 — 실행 *역순* (마지막 Success → 첫 Success).
 *     compensateRequired=true Failure 시에만 호출. happy path / no-compensate Failure = empty.
 **/
public record WorkflowResult<O>(
    StepResult<O> finalResult,
    List<StepResult<?>> stepHistory,
    StepResult<?> compensationResult,
    List<StepResult<?>> stepCompensations) {

  public WorkflowResult {
    Objects.requireNonNull(finalResult, "finalResult");
    stepHistory = List.copyOf(Objects.requireNonNull(stepHistory, "stepHistory"));
    stepCompensations = List.copyOf(Objects.requireNonNull(stepCompensations, "stepCompensations"));
  }

  /** 단순 success 영역 식별 — pipeline 의 마지막 step 이 Success. */
  public boolean succeeded() {
    return finalResult instanceof StepResult.Success<?>;
  }
}
