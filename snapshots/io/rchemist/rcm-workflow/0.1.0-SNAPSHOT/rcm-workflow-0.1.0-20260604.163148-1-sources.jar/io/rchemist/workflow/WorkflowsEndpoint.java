/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.workflow;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * §B1-6 — Spring Boot Actuator endpoint /actuator/workflows. 등록된 모든
 * {@link WorkflowDefinition} bean 노출 (name / inputType / outputType / step 목록 /
 * hasCompensation) + {@link WorkflowMetricsRegistry} snapshot 카운터.
 *
 * <p>{@link Endpoint} = compileOnly actuator 의존이라 runtime 시 actuator classpath 영역만 활성.
 **/
@Endpoint(id = "workflows")
public class WorkflowsEndpoint {

  private final ListableBeanFactory beanFactory;
  private final WorkflowMetricsRegistry metrics;

  public WorkflowsEndpoint(ListableBeanFactory beanFactory, WorkflowMetricsRegistry metrics) {
    this.beanFactory = Objects.requireNonNull(beanFactory, "beanFactory");
    this.metrics = Objects.requireNonNull(metrics, "metrics");
  }

  @ReadOperation
  @SuppressWarnings("rawtypes")
  public Map<String, Object> workflows() {
    Map<String, WorkflowDefinition> defs = beanFactory.getBeansOfType(WorkflowDefinition.class);
    Map<String, WorkflowMetricsRegistry.Snapshot> snap = metrics.snapshot();

    List<Map<String, Object>> entries = new ArrayList<>();
    for (Map.Entry<String, WorkflowDefinition> entry : defs.entrySet()) {
      WorkflowDefinition def = entry.getValue();
      Map<String, Object> info = new LinkedHashMap<>();
      info.put("bean", entry.getKey());
      info.put("name", def.name());
      info.put("inputType", def.inputType().getName());
      info.put("outputType", def.outputType().getName());
      info.put(
          "steps",
          def.steps().stream().map(s -> ((WorkflowStep<?, ?>) s).name()).toList());
      info.put("stepCount", def.steps().size());
      info.put("hasCompensation", def.compensation().isPresent());
      WorkflowMetricsRegistry.Snapshot s =
          snap.getOrDefault(def.name(), new WorkflowMetricsRegistry.Snapshot(0, 0, 0, 0));
      Map<String, Long> metricsMap = new LinkedHashMap<>();
      metricsMap.put("executions", s.executions());
      metricsMap.put("successes", s.successes());
      metricsMap.put("failures", s.failures());
      metricsMap.put("compensations", s.compensations());
      info.put("metrics", metricsMap);
      entries.add(info);
    }
    return Map.of("workflows", entries);
  }
}
