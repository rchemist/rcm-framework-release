/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

import java.time.Instant;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox 적재 이벤트 본문 — entity 색인 / 삭제 요청 1 건.
 *
 * <p>{@code entityType} = entity 의 fully qualified class name (Outbox 가 entity 인스턴스 자체를
 * 안 들고 *지연 fetch* 하는 패턴 — DB-backed outbox 일 때 영속 스키마 stable). {@code entityId} =
 * primary key (Long / String / TSID 등 toString-safe).
 *
 * <p>{@code tenantId} = multi-tenant 색인 분리 (null = single-tenant). {@code occurredAt} = 적재
 * 시각 (lag metric 산출 = now - occurredAt).
 **/
public record SearchIndexEvent(
    String entityType,
    String entityId,
    SearchIndexOperation operation,
    String tenantId,
    Instant occurredAt) {

  public SearchIndexEvent {
    Objects.requireNonNull(entityType, "entityType required");
    Objects.requireNonNull(entityId, "entityId required");
    Objects.requireNonNull(operation, "operation required");
    Objects.requireNonNull(occurredAt, "occurredAt required");
  }

  /** INDEX 이벤트 factory — single-tenant. */
  public static SearchIndexEvent index(Class<?> entityType, Object entityId) {
    return new SearchIndexEvent(
        entityType.getName(), String.valueOf(entityId), SearchIndexOperation.INDEX, null, Instant.now());
  }

  /** INDEX 이벤트 factory — multi-tenant. */
  public static SearchIndexEvent index(Class<?> entityType, Object entityId, String tenantId) {
    return new SearchIndexEvent(
        entityType.getName(),
        String.valueOf(entityId),
        SearchIndexOperation.INDEX,
        tenantId,
        Instant.now());
  }

  /** DELETE 이벤트 factory — single-tenant. */
  public static SearchIndexEvent delete(Class<?> entityType, Object entityId) {
    return new SearchIndexEvent(
        entityType.getName(),
        String.valueOf(entityId),
        SearchIndexOperation.DELETE,
        null,
        Instant.now());
  }
}
