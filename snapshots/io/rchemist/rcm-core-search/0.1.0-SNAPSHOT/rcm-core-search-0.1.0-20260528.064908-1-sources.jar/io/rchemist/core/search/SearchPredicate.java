/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Search predicate sealed marker — {@link FilterItem} + {@link UnmappedJoin} 의 공통 super.
 *
 * <p>Phase 3 의 {@code SearchRequestPlanner} 가 sealed exhaustive switch 로 JPQL/Criteria 변환
 * (청사진 §5.5.4 + §5.5.6). 0.1.0 의 sealed 가치 = pattern matching + 컴파일 시점 exhaustive 검증.
 */
public sealed interface SearchPredicate permits FilterItem, UnmappedJoin {
}
