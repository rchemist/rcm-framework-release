/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index;

import io.rchemist.core.marker.Indexable;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link EntityIndexer} runtime registry — entity class → indexer 매핑.
 *
 * <p>등록 — Spring autoconfig (옵션 starter `rcm-starter-search-elasticsearch` 가 인입한
 * `ElasticsearchEntityIndexer<E>` Bean 들을 자동 register) 또는 명시 {@link #register} API. 같은
 * class 두 번 등록 = 마지막 등록자 우선 (덮어쓰기 허용 — test 격리 용).
 *
 * <p>{@link EntityMetadataRegistry} 와 동일 패턴. thread-safe.
 **/
public final class EntityIndexerRegistry {

  private static final ConcurrentMap<Class<?>, EntityIndexer<?>> REGISTRY = new ConcurrentHashMap<>();

  private EntityIndexerRegistry() {
  }

  /** entity class 와 indexer 등록. */
  public static <E extends Indexable> void register(Class<E> entityClass, EntityIndexer<E> indexer) {
    if (entityClass == null || indexer == null) {
      throw new IllegalArgumentException("entityClass and indexer must not be null");
    }
    REGISTRY.put(entityClass, indexer);
  }

  /** entity class 의 indexer lookup — 미적용 = {@link Optional#empty()}. */
  @SuppressWarnings("unchecked")
  public static <E extends Indexable> Optional<EntityIndexer<E>> find(Class<E> entityClass) {
    if (entityClass == null) {
      return Optional.empty();
    }
    return Optional.ofNullable((EntityIndexer<E>) REGISTRY.get(entityClass));
  }

  /** indexer 강제 lookup — 미적용 시 fail loud. */
  public static <E extends Indexable> EntityIndexer<E> require(Class<E> entityClass) {
    return EntityIndexerRegistry.<E>find(entityClass)
        .orElseThrow(() -> new IllegalStateException(
            "EntityIndexer not registered for class: "
                + (entityClass == null ? "null" : entityClass.getName())
                + ". Ensure rcm-starter-search-elasticsearch (or other search starter) is on the classpath."));
  }

  /** 등록된 모든 indexer (actuator endpoint / bulk reindex 진입). */
  public static Collection<EntityIndexer<?>> all() {
    return Collections.unmodifiableCollection(REGISTRY.values());
  }

  /** 등록 해제 (test 격리). */
  public static void unregister(Class<?> entityClass) {
    if (entityClass != null) {
      REGISTRY.remove(entityClass);
    }
  }

  /** 등록 수. */
  public static int size() {
    return REGISTRY.size();
  }

  /** 모든 등록 초기화 (test 격리). */
  public static void clear() {
    REGISTRY.clear();
  }
}
