/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

import java.time.Instant;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Search index outbox SPI — 색인 안전성 baseline (durability + at-least-once delivery + lag metric).
 *
 * <p>baseline 구현체:
 * <ul>
 *   <li>{@link InMemorySearchIndexOutbox} — 단순 / 테스트 / single-instance default.
 *       재시작 시 손실</li>
 *   <li>JPA-backed — Consumer 가 entity ({@code SearchIndexOutboxEntity}) + Repository 어댑터
 *       구현. production 권장 (DB 트랜잭션 + 재시작 안전 + 분산 노드 공유)</li>
 * </ul>
 *
 * <p>색인 진행 패턴 — 별도 worker 가 polling: pollNext → ES bulk → markIndexed/Retrying/Dead.
 * idempotency = upsert + delete-no-op 보장 ({@link
 * io.rchemist.core.search.index.EntityIndexer} 계약) → at-least-once 안전.
 *
 * <p>lag metric = {@link #pendingCount()} 가 0 이상이면 lag 발생. {@code /actuator/search-indexes}
 * 엔드포인트가 노출.
 **/
public interface SearchIndexOutbox {

  /** 새 색인 이벤트 적재 — status PENDING, attempts 0, nextAttemptAt now. id 반환. */
  String append(SearchIndexEvent event);

  /** polling — PENDING/RETRYING + nextAttemptAt <= now 인 entry 1 건 atomic claim (INDEXING 전환). */
  Optional<SearchIndexEntry> pollNext();

  /** 성공 — INDEXED 전환 (terminal). */
  void markIndexed(String id);

  /** 재시도 — RETRYING 전환 + nextAttemptAt + lastError. */
  void markRetrying(String id, String error, Instant nextAttemptAt);

  /** 최종 실패 — DEAD 전환 (terminal). DLQ 적재는 Consumer 결정. */
  void markDead(String id, String error);

  /** 진단 — 적재된 모든 entry 수 (모든 status 포함). */
  int size();

  /** lag metric — terminal 아닌 entry 수 (PENDING + INDEXING + RETRYING). 0 = lag 없음. */
  int pendingCount();

  /** 진단 — id 별 entry 조회. */
  Optional<SearchIndexEntry> findById(String id);
}
