/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 표준 JPA CriteriaDelete wire format — Phase 3 task #6j. {@code DELETE WHERE ...}.
 *
 * @param where  WHERE 영역 = SearchRequest filter 재사용. {@code null} 또는 빈 filters = 전체 삭제 위험
 *               → IT 영역에서 실수 방지용 명시 안전.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record BulkDeleteRequest(SearchRequest where) {

  public BulkDeleteRequest {
    Objects.requireNonNull(where, "where (전체 삭제 위험 회피용 — 명시 SearchRequest 박아라)");
  }

  /** "전체 삭제" 명시 helper — 전부 삭제 의도 영역. */
  public static BulkDeleteRequest all() {
    SearchRequest empty = new SearchRequest(0, Integer.MAX_VALUE, LogicalOperator.AND,
        new LinkedHashMap<>(), List.of(), List.of(), null, null, null, null, null,
        null, null, null, List.of(), List.of());
    return new BulkDeleteRequest(empty);
  }
}
