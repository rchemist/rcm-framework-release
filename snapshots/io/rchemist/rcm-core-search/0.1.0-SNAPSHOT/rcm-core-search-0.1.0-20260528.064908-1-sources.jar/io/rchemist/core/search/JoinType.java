/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * JOIN 종류 — 0.0.5 {@code FilterItem.withJoinType(JoinType)} 흡수 (청사진 §5.5.6).
 *
 * <p>{@link #INNER} 가 default — entity 직접 매핑 영역. {@link #LEFT} 는 ManyToOne / OneToOne nullable
 * + sort 영역에 명시. {@link #RIGHT} 는 0.0.5 호환 위해 보존 (실제 사용은 드물다).
 */
public enum JoinType {
    INNER,
    LEFT,
    RIGHT
}
