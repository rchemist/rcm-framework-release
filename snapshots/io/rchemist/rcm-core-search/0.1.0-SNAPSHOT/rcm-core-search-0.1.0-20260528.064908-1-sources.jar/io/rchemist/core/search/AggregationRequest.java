/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SQL 표준 GROUP BY + 집계 + HAVING wire format — Phase 3 task #6f. {@link SearchRequest} 의 filter /
 * sort 영역 재사용 + 집계 영역 추가.
 *
 * <p>예시: published=true 만 필터 + author 별 viewCount 합 집계 + 합 1000 초과만 (having):
 * <pre>{@code
 * AggregationRequest req = new AggregationRequest(
 *     List.of("author.name"),
 *     List.of(Aggregation.sum("viewCount"), Aggregation.count("id")),
 *     List.of(FilterItem.of("sum_viewCount", QueryConditionType.GREATER_THAN, "1000")),
 *     SearchRequest.builder().filterEquals("published", true).build());
 * }</pre>
 *
 * @param groupBy     GROUP BY 컬럼 (entity property path). null/empty 시 전체 집계 (single row).
 * @param aggregations 집계 항목 (최소 1개)
 * @param having      HAVING predicate. {@link FilterItem} 의 {@code name} 은 aggregation alias 또는
 *                    groupBy 컬럼.
 * @param baseSearch  filter / sort / pagination 영역 (null 가능 — 빈 SearchRequest 동등).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AggregationRequest(
    List<String> groupBy,
    List<Aggregation> aggregations,
    List<FilterItem> having,
    SearchRequest baseSearch
) {

  public AggregationRequest {
    groupBy = groupBy == null ? List.of() : List.copyOf(groupBy);
    Objects.requireNonNull(aggregations, "aggregations");
    if (aggregations.isEmpty()) {
      throw new IllegalArgumentException("aggregations must not be empty");
    }
    aggregations = List.copyOf(aggregations);
    having = having == null ? List.of() : List.copyOf(having);
    if (baseSearch == null) {
      // 빈 SearchRequest — Records 의 compact constructor 가 default 자동 채움.
      baseSearch = new SearchRequest(0, Integer.MAX_VALUE, LogicalOperator.AND,
          new LinkedHashMap<>(), List.of(), List.of(), null, null, null, null, null,
          null, null, null, List.of(), List.of());
    }
  }

  /** 단순 — groupBy + aggregations 만 (filter / having 없음). */
  public static AggregationRequest of(List<String> groupBy, List<Aggregation> aggregations) {
    return new AggregationRequest(groupBy, aggregations, null, null);
  }

  /** filter 결합 — search 의 filter 도 같이. */
  public static AggregationRequest withFilter(
      List<String> groupBy, List<Aggregation> aggregations, SearchRequest baseSearch
  ) {
    return new AggregationRequest(groupBy, aggregations, null, baseSearch);
  }
}
