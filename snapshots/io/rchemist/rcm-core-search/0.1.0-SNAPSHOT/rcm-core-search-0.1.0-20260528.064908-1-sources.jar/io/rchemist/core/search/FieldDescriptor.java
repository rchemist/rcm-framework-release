/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Type-safe field descriptor — 0.0.5 {@code RegisterEntityBeanPropertyDTO} 흡수 (청사진 §5.5.4 +
 * §5.5.5). APT {@code EntityMetadataProcessor} 가 entity 의 각 필드별로 자동 생성, runtime reflection 0.
 *
 * <p>generic 정보 보존 — IDE 자동 완성 + 컴파일 시 type 일치 검증 + GraalVM native 호환 baseline.
 *
 * @param name           필드명 (entity property name, e.g. {@code "title"} / {@code "author"})
 * @param type           필드 타입 (e.g. {@code String.class} / {@code Long.class})
 * @param entityClass    소속 entity class
 * @param classification {@link FilterClassification} 자동 분류
 * @param searchable     검색 화이트리스트 (Phase 3 의 {@code SearchRequestPlanner} 가 강제 — false 면 400)
 * @param sortable       sort 화이트리스트 (Phase 3 의 {@code SortValidator} 강제)
 * @param indexed        {@code @SearchField} 또는 {@link io.rchemist.core.marker.Searchable}
 *                       추가 marker 기반 (Phase 4 search engine 통합 영역)
 * @param autoMarker     marker (Auditable / SoftDelete / TenantAlias) 자동 주입 필드 표시
 * @param <E> entity class
 * @param <V> field value type
 */
public record FieldDescriptor<E, V>(
    String name,
    Class<V> type,
    Class<E> entityClass,
    FilterClassification classification,
    boolean searchable,
    boolean sortable,
    boolean indexed,
    boolean autoMarker
) {

  public FieldDescriptor {
    Objects.requireNonNull(name, "name");
    Objects.requireNonNull(type, "type");
    Objects.requireNonNull(entityClass, "entityClass");
    Objects.requireNonNull(classification, "classification");
  }

  /** 단축 — searchable=true / sortable=true / indexed=false / autoMarker=false. */
  public static <E, V> FieldDescriptor<E, V> of(
      String name, Class<V> type, Class<E> entityClass, FilterClassification classification
  ) {
    return new FieldDescriptor<>(name, type, entityClass, classification,
        true, true, false, false);
  }

  /** {@link FilterClassification#JSON_ATTRIBUTE} 영역 단축 — searchable, sortable=false (jsonb path). */
  public static <E> FieldDescriptor<E, Object> jsonAttribute(
      String name, Class<E> entityClass
  ) {
    return new FieldDescriptor<>(name, Object.class, entityClass, FilterClassification.JSON_ATTRIBUTE,
        true, false, false, false);
  }

  /** marker 자동 주입 필드 단축 (createdAt / updatedAt / tenantId / deleted 등). */
  public static <E, V> FieldDescriptor<E, V> autoMarker(
      String name, Class<V> type, Class<E> entityClass
  ) {
    return new FieldDescriptor<>(name, type, entityClass, FilterClassification.COLUMN,
        true, true, false, true);
  }
}
