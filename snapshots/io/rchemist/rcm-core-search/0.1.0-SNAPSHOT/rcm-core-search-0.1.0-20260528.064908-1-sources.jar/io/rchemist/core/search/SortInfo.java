/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Sort 추상 — 0.0.5 {@code SortInfo} sealed 흡수 (청사진 §5.5.6).
 *
 * <p>두 구현 — {@link NormalSortInfo} (단순) / {@link PrioritySortInfo} ({@code CASE WHEN} 우선순위).
 * Phase 3 {@code OrderByBuilder} 가 sealed exhaustive switch 로 JPQL ORDER BY 변환.
 *
 * <p>JoinType + nullsFirst 모두 보존 (0.0.5 동등 — INNER default + DB null ordering default).
 *
 * <p>Jackson type 정보 — wire format 에 {@code "type": "NORMAL" | "PRIORITY"} property. 명시 없으면
 * {@code priorityValue} 가 있으면 PRIORITY, 아니면 NORMAL 자동 추론은 deserializer 미지원이므로 frontend
 * 가 명시 적용.
 */
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = "type",
    defaultImpl = NormalSortInfo.class)
@JsonSubTypes({
    @JsonSubTypes.Type(value = NormalSortInfo.class, name = "NORMAL"),
    @JsonSubTypes.Type(value = PrioritySortInfo.class, name = "PRIORITY")
})
public sealed interface SortInfo permits NormalSortInfo, PrioritySortInfo {
    String field();
    Direction direction();
    JoinType joinType();
    Boolean nullsFirst();
}
