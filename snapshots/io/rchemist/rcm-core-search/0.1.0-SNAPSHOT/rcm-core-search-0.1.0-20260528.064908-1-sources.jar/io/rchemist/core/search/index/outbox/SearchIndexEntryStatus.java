/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox entry 라이프사이클 — PENDING → INDEXING → INDEXED / RETRYING / DEAD.
 *
 * <p>state machine:
 * <ul>
 *   <li>PENDING — 적재 직후 baseline. polling 대상</li>
 *   <li>INDEXING — pollNext 가 atomic claim — 동시 발송 race 차단</li>
 *   <li>INDEXED — 색인 성공 (terminal)</li>
 *   <li>RETRYING — 실패 후 backoff 대기. polling 재진입</li>
 *   <li>DEAD — RetryPolicy.maxAttempts 초과 (terminal). DLQ 적재 후보</li>
 * </ul>
 **/
public enum SearchIndexEntryStatus {
  PENDING,
  INDEXING,
  INDEXED,
  RETRYING,
  DEAD
}
