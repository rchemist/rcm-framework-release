/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Entity view mode baseline — Phase 0.1.0 GA Gate T0-5 (G-A-7) 신규.
 *
 * <p>0.0.5 자산 흡수 — {@code GET /{id}?viewType=VIEW|EDIT|DETAIL|MOBILE} controller 단일 endpoint
 * 가 view mode 별 도메인 응답 형태 분기. service / controller 가 자체 매핑 (e.g. EDIT 는 입력 form
 * 친화 / DETAIL 은 풍부 metadata 결합 / MOBILE 은 lightweight payload).
 *
 * <p>4 baseline value 외 도메인별 추가 enum 가 필요할 경우 — 보통은 4 종으로 충분하나, 도메인별
 * 별도 enum 신설 (`OrderViewType.SUMMARY`, etc.) 도 자유 (프레임워크 강제 X).
 *
 * <p>Decision #31 정합 — {@code GET /{id}} (단순) / {@code GET /{id}?viewType=...} (mode 분기)
 * 양쪽 모두 baseline 지원.
 */
public enum EntityViewType {

  /** 일반 보기 — read-only, 표준 ReadDTO (default). */
  VIEW,

  /** 편집 보기 — 입력 form 친화 형태 (validation hints / 사용자 권한 필드 노출). */
  EDIT,

  /** 상세 보기 — 풍부 metadata 결합 (관련 entity / audit history / 통계 결합). */
  DETAIL,

  /** 모바일 보기 — lightweight payload (필수 필드만, 큰 텍스트 / image 메타 제거). */
  MOBILE
}
