/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Search index 색인 operation — INDEX (upsert) / DELETE (id 기반 삭제).
 *
 * <p>0.1.0 baseline 2 종. 0.2.0+ partial update / nested array op 등 확장 시 enum 추가.
 **/
public enum SearchIndexOperation {
  INDEX,
  DELETE
}
