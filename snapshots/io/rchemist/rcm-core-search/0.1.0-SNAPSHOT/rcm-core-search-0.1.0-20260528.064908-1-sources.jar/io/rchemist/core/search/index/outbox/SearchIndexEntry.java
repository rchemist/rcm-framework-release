/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

import java.time.Instant;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox 적재 단위 — {@link SearchIndexEvent} + 라이프사이클 메타.
 *
 * <p>transition 메서드 (markIndexing / markIndexed / markRetrying / markDead) = 새 인스턴스 반환
 * (record 불변성 정합).
 **/
public record SearchIndexEntry(
    String id,
    SearchIndexEvent event,
    int attempts,
    SearchIndexEntryStatus status,
    String lastError,
    Instant nextAttemptAt) {

  public SearchIndexEntry {
    Objects.requireNonNull(id, "id required");
    Objects.requireNonNull(event, "event required");
    Objects.requireNonNull(status, "status required");
    Objects.requireNonNull(nextAttemptAt, "nextAttemptAt required");
    if (attempts < 0) {
      throw new IllegalArgumentException("attempts cannot be negative");
    }
  }

  /** INDEXING 상태 + attempts +1. */
  public SearchIndexEntry markIndexing() {
    return new SearchIndexEntry(
        id, event, attempts + 1, SearchIndexEntryStatus.INDEXING, lastError, nextAttemptAt);
  }

  /** INDEXED 상태 — terminal. lastError 초기화. */
  public SearchIndexEntry markIndexed() {
    return new SearchIndexEntry(
        id, event, attempts, SearchIndexEntryStatus.INDEXED, null, nextAttemptAt);
  }

  /** RETRYING 상태 + 다음 시도 시각 + 실패 reason. */
  public SearchIndexEntry markRetrying(String error, Instant nextAttempt) {
    return new SearchIndexEntry(
        id, event, attempts, SearchIndexEntryStatus.RETRYING, error, nextAttempt);
  }

  /** DEAD 상태 — terminal. */
  public SearchIndexEntry markDead(String error) {
    return new SearchIndexEntry(
        id, event, attempts, SearchIndexEntryStatus.DEAD, error, nextAttemptAt);
  }
}
