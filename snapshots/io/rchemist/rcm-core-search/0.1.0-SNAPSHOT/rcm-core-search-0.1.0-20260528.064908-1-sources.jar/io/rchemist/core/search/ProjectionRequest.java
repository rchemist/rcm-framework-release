/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 특정 필드만 SELECT — Tuple / DTO 형태 — Phase 3 task #6g.
 *
 * <p>두 영역:
 * <ol>
 *   <li>{@link #fields} 만 — Tuple / Map<String, Object> 결과 (alias = field path)</li>
 *   <li>{@link #dtoClass} 추가 — Constructor projection. {@code fields} 의 type 이 dto constructor
 *       인자 순서와 일치해야 (fail-loud)</li>
 * </ol>
 *
 * <p>예시:
 * <pre>{@code
 * // Tuple 영역
 * ProjectionRequest req = ProjectionRequest.fields(
 *     List.of("id", "title", "author.name"), baseSearch);
 *
 * // DTO constructor 영역
 * ProjectionRequest req = ProjectionRequest.toDto(
 *     ArticleSummary.class, List.of("id", "title", "author.name"), baseSearch);
 * }</pre>
 *
 * @param fields    SELECT 영역 (entity property paths)
 * @param dtoClass  null = Tuple / Map 결과. non-null = constructor projection
 * @param baseSearch filter / sort / pagination 영역 (null 가능)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ProjectionRequest(
    List<String> fields,
    Class<?> dtoClass,
    SearchRequest baseSearch
) {

  public ProjectionRequest {
    Objects.requireNonNull(fields, "fields");
    if (fields.isEmpty()) {
      throw new IllegalArgumentException("fields must not be empty");
    }
    fields = List.copyOf(fields);
    if (baseSearch == null) {
      baseSearch = new SearchRequest(0, Integer.MAX_VALUE, LogicalOperator.AND,
          new LinkedHashMap<>(), List.of(), List.of(), null, null, null, null, null,
          null, null, null, List.of(), List.of());
    }
  }

  /** Tuple / Map 영역 — DTO 없이 fields 만. */
  public static ProjectionRequest fields(List<String> fields, SearchRequest baseSearch) {
    return new ProjectionRequest(fields, null, baseSearch);
  }

  /** Constructor projection 영역 — fields 가 DTO constructor 인자 순서와 일치. */
  public static ProjectionRequest toDto(
      Class<?> dtoClass, List<String> fields, SearchRequest baseSearch
  ) {
    return new ProjectionRequest(fields, dtoClass, baseSearch);
  }
}
