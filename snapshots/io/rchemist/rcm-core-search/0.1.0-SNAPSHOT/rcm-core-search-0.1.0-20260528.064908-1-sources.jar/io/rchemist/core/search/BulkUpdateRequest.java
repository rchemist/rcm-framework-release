/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 표준 JPA CriteriaUpdate wire format — Phase 3 task #6j. {@code SET col = value WHERE ...} 의 wire
 * 표현. {@code where} 의 filter 영역은 {@link SearchRequest} 재사용.
 *
 * @param set    {@code field path → string value}. ValueCoercer 가 entity field type 으로 자동 변환.
 *               root column 만 (다단 path X — JPA standard CriteriaUpdate 한계).
 * @param where  WHERE 영역 = 표준 SearchRequest 의 filter 영역 (sort / pagination / fetchJoins 무시)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record BulkUpdateRequest(
    Map<String, String> set,
    SearchRequest where
) {

  public BulkUpdateRequest {
    Objects.requireNonNull(set, "set");
    if (set.isEmpty()) {
      throw new IllegalArgumentException("set must not be empty");
    }
    set = Map.copyOf(set);
    if (where == null) {
      where = new SearchRequest(0, Integer.MAX_VALUE, LogicalOperator.AND,
          new LinkedHashMap<>(), List.of(), List.of(), null, null, null, null, null,
          null, null, null, List.of(), List.of());
    }
  }
}
