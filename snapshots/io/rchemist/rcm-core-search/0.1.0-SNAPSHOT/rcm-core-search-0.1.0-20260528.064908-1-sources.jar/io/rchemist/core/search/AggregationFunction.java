/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SQL 표준 집계 함수 — JPA Criteria + 모든 DBMS (PG/MySQL/MSSQL) 동등 지원 (Phase 3 task #6f).
 *
 * <p>모든 함수는 SQL:2003 표준 — DBMS 무관 일관 결과.
 */
public enum AggregationFunction {

  /** COUNT(*) 또는 COUNT(field) — null 제외. */
  COUNT,

  /** COUNT(DISTINCT field) — 중복 제거 후 개수. */
  COUNT_DISTINCT,

  /** SUM(field) — Number 타입 합. */
  SUM,

  /** AVG(field) — Number 타입 평균 (Double 반환). */
  AVG,

  /** MIN(field) — 최소값 (Comparable). */
  MIN,

  /** MAX(field) — 최대값 (Comparable). */
  MAX
}
