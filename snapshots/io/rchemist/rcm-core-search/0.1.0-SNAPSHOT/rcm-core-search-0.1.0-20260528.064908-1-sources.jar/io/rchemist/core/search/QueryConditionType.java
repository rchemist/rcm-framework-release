/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * SearchRequest 의 24 종 condition type — 0.0.5 {@code QueryConditionType} 1:1 흡수 (메모리
 * {@code feedback_no_feature_regression} 정합). frontend {@code rcm-listgrid} 의 SearchForm 직렬화
 * 형식과 wire format 정합 (Phase 2 task #4 적용).
 *
 * <p>24 종 분류:
 * <ul>
 *   <li>Equality 2 — EQUAL / NOT_EQUAL</li>
 *   <li>Collection 2 — IN / NOT_IN</li>
 *   <li>Pattern 2 — LIKE / NOT_LIKE</li>
 *   <li>Comparison 4 — GREATER_THAN / GREATER_THAN_EQUAL / LESS_THAN / LESS_THAN_EQUAL</li>
 *   <li>Range 1 — BETWEEN</li>
 *   <li>Null/Blank 4 — IS_NULL / IS_NOT_NULL / IS_BLANK / IS_NOT_BLANK</li>
 *   <li>Null-or 2 — NULL_OR_EQUAL / NULL_OR_BLANK</li>
 *   <li>InRange 2 — IN_RANGE / NOT_IN_RANGE</li>
 *   <li>Date 3 — DATE_BEFORE / DATE_AFTER / DATE_BETWEEN</li>
 *   <li>Special 2 — JSON_CONTAINS / EXISTS</li>
 * </ul>
 */
public enum QueryConditionType {
    /* Equality 2 */
    EQUAL,
    NOT_EQUAL,

    /* Collection 2 */
    IN,
    NOT_IN,

    /* Pattern 2 */
    LIKE,
    NOT_LIKE,

    /* Comparison 4 */
    GREATER_THAN,
    GREATER_THAN_EQUAL,
    LESS_THAN,
    LESS_THAN_EQUAL,

    /* Range 1 */
    BETWEEN,

    /* Null/Blank 4 */
    IS_NULL,
    IS_NOT_NULL,
    IS_BLANK,
    IS_NOT_BLANK,

    /* Null-or 2 */
    NULL_OR_EQUAL,
    NULL_OR_BLANK,

    /* InRange 2 — 0.0.5 의 numeric range 검색 (gjcu LectureSearchIndex 패턴) */
    IN_RANGE,
    NOT_IN_RANGE,

    /* Date 3 */
    DATE_BEFORE,
    DATE_AFTER,
    DATE_BETWEEN,

    /* Special 2 — JSON 필드 자동 인식 + EXISTS sub-query */
    JSON_CONTAINS,
    EXISTS;

    /** 24 종 (Phase 2 task #4 적용 — 0.0.5 wire format 1:1 흡수). */
    public static int total() {
        return values().length;
    }
}
