/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index;

import io.rchemist.core.marker.Indexable;
import java.util.Collection;
import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 외부 검색엔진(Elasticsearch / Solr 등) 색인 SPI — {@link Indexable} entity 의 *색인 / 삭제 /
 * 일괄 색인* 단일 진입점.
 *
 * <p>구현체는 옵션 starter (`rcm-starter-search-elasticsearch` 등) 가 제공. 등록 = Spring autoconfig
 * 또는 명시 {@link EntityIndexerRegistry#register(Class, EntityIndexer)}. 동일 entity 는 단일
 * indexer 만 (덮어쓰기 허용 = 마지막 등록자 우선).
 *
 * <p>idempotency — `index(entity)` 호출은 *upsert* 의미 (동일 id 두 번 호출 = 동일 결과).
 * `delete(id)` = 존재하지 않는 id 도 정상 (no-op). 이 보장이 outbox 의 retry / replay 안전성 근거.
 *
 * @param <E> Indexable entity 타입
 **/
public interface EntityIndexer<E extends Indexable> {

  /** 등록 lookup key — entity 의 runtime class. */
  Class<E> entityType();

  /**
   * 외부 검색엔진의 index / collection 이름.
   *
   * <p>default = entity simple class name lowercase. 구현체 / consumer 는 override 또는
   * `@SearchIndex` annotation (#B2-5 후보) 으로 재정의.
   */
  default String indexName() {
    return entityType().getSimpleName().toLowerCase(Locale.ROOT);
  }

  /** 단일 entity 색인 — upsert 의미. */
  void index(E entity);

  /** id 기반 삭제 — 존재하지 않는 id 도 정상(no-op). */
  void delete(Object id);

  /**
   * 일괄 색인 — bulk API 진입점. baseline default = loop {@link #index} (구현체가 override 권장,
   * ES bulk API 활용 시 1~2 자릿수 throughput).
   */
  default void indexBatch(Collection<E> entities) {
    if (entities == null || entities.isEmpty()) {
      return;
    }
    for (E entity : entities) {
      index(entity);
    }
  }
}
