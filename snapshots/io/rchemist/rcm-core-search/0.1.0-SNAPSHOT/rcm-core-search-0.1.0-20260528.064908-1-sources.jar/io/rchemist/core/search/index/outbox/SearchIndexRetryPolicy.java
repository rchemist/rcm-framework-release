/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

import java.time.Duration;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 색인 재시도 정책 — exponential backoff + maxAttempts cap.
 *
 * <p>{@link #defaults()} = 5 회 시도 (10s → 20s → 40s → 80s → max 60s, 2x), max 60 초. ES
 * cluster 일시적 (network blip / GC pause) 5 분 내 회복 가정.
 **/
public record SearchIndexRetryPolicy(
    int maxAttempts, Duration initialBackoff, double multiplier, Duration maxBackoff) {

  public SearchIndexRetryPolicy {
    Objects.requireNonNull(initialBackoff, "initialBackoff required");
    Objects.requireNonNull(maxBackoff, "maxBackoff required");
    if (maxAttempts < 1) {
      throw new IllegalArgumentException("maxAttempts must be >= 1");
    }
    if (multiplier < 1.0) {
      throw new IllegalArgumentException("multiplier must be >= 1.0");
    }
    if (initialBackoff.isNegative() || initialBackoff.isZero()) {
      throw new IllegalArgumentException("initialBackoff must be positive");
    }
    if (maxBackoff.compareTo(initialBackoff) < 0) {
      throw new IllegalArgumentException("maxBackoff must be >= initialBackoff");
    }
  }

  /** ES baseline default — 5 회 시도, 10s 초기 + 2x exponential, max 60s. */
  public static SearchIndexRetryPolicy defaults() {
    return new SearchIndexRetryPolicy(5, Duration.ofSeconds(10), 2.0, Duration.ofSeconds(60));
  }

  /**
   * 다음 시도까지의 backoff 계산 — {@code attempt} = 직전 실패 시도 횟수 (1-based).
   *
   * <p>{@code initialBackoff × multiplier^(attempt - 1)} 적용 + maxBackoff cap.
   */
  public Duration nextBackoff(int attempt) {
    if (attempt < 1) {
      throw new IllegalArgumentException("attempt must be >= 1");
    }
    double millis = initialBackoff.toMillis() * Math.pow(multiplier, attempt - 1);
    long capped = Math.min((long) millis, maxBackoff.toMillis());
    return Duration.ofMillis(capped);
  }

  /** maxAttempts 도달 여부 — RETRYING 시 DEAD 전환 판단. */
  public boolean isExhausted(int attempts) {
    return attempts >= maxAttempts;
  }
}
