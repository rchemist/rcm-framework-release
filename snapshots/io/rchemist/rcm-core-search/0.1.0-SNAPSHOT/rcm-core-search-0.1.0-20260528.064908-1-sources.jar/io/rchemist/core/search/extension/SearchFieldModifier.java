/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.extension;

import io.rchemist.core.search.FilterItem;
import io.rchemist.extension.ExtensionPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Search filter 가상/계산/JSON 필드 → 실제 entity 경로 매핑 ExtensionPoint.
 *
 * <p>Consumer 가 Spring bean 으로 등록하면 {@code SearchRequestPlanner} 가 매 {@link FilterItem} 평가 시점에
 * {@link #supports(Class, FilterItem)} 차례 호출. true 반환 시 {@link #modify(FilterItem, Class)} 결과로
 * 원본 교체.
 *
 * <p>전형 사용:
 * <ul>
 *   <li>{@code attributes.color} 같은 JSON path → {@code attributes->>'color'} 로 변환</li>
 *   <li>가상 필드 {@code authorName} → {@code author.name} 실제 path</li>
 *   <li>계산 필드 {@code totalPrice} → {@code (price * quantity)} JPQL 식</li>
 * </ul>
 *
 * <p>{@link SortFieldModifier} 와 짝 — sort 측은 별도 ExtensionPoint.
 **/
@ExtensionPoint("Search filter 가상/계산/JSON 필드 → 실제 entity 경로 매핑")
public interface SearchFieldModifier {

    /** 본 modifier 가 해당 entity 의 해당 filter 를 처리할 수 있는지. */
    boolean supports(Class<?> entityType, FilterItem filter);

    /**
     * 원본 filter 를 변환된 filter 로 매핑. {@code FilterItem} 은 immutable Records — withName / withValue
     * 등 fluent API 활용 (in-place 변환 X).
     */
    FilterItem modify(FilterItem original, Class<?> entityType);
}
