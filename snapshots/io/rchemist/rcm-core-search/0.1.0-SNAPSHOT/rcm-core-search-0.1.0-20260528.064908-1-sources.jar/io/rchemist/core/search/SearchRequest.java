/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * universal search wire format — 0.0.5 {@code AbstractSearchForm} + {@code FilterMapSearchForm} 의
 * *모든 필드/메서드* 1:1 흡수 (청사진 §5.5.3 + §5.5.6 + §5.5.7, 메모리
 * {@code feedback_no_feature_regression} 정합).
 *
 * <p>frontend {@code rcm-listgrid} SearchForm 직렬화 형태 그대로 wire format. POST body (default,
 * JSON) + GET query string (단순 케이스). Phase 2 task #4 적용.
 *
 * <p>Records 의 immutability 자연 — 매 {@code with*()} 가 *새 SearchRequest* 반환. concurrent 안전 +
 * test fixture 친화. 33 종 fluent filter 메서드는 {@link Builder} 위에 적용.
 *
 * <p>0.0.5 흡수 매핑 (§5.5.7):
 * <ul>
 *   <li>{@code page / pageSize} → JPA Pageable 변환은 Phase 3 영역</li>
 *   <li>{@code sorts: LinkedHashMap<String, Direction>} → {@link #sorts} 순서 보장</li>
 *   <li>{@code searchTerm + quickSearchFields} → quickSearch OR 전개</li>
 *   <li>{@code viewDetail / entityViewType} → DTO 형태 (LIST vs VIEW)</li>
 *   <li>{@code exactMatch} → startsWith vs equal (회원가입 중복확인)</li>
 *   <li>{@code ignoreCache / cacheTTL} → search 결과 cache</li>
 *   <li>{@code shouldReturnEmpty} → fast path (빈 결과 직행)</li>
 *   <li>{@code forceFetchFromDB} → Hibernate Search 우회 강제</li>
 *   <li>{@code mappedJoinFilters / unmappedJoins} → JOIN 영역 (Phase 3 자동 분리)</li>
 *   <li>{@code additionalContext} → overrideSearchForm 확장</li>
 *   <li>{@code preserve() / restore()} → service-layer userId/tenantId 강제 주입 + 복원</li>
 * </ul>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SearchRequest(
    Integer page,
    Integer pageSize,
    LogicalOperator operator,
    LinkedHashMap<LogicalOperator, List<FilterItem>> filters,
    List<SortInfo> sorts,
    List<String> quickSearchFields,
    String searchTerm,
    Boolean viewDetail,
    Boolean exactMatch,
    Boolean ignoreCache,
    Boolean shouldReturnEmpty,
    Boolean forceFetchFromDB,
    Long cacheTTL,
    Map<String, Object> additionalContext,
    List<FilterItem> mappedJoinFilters,
    List<UnmappedJoin> unmappedJoins
) {

    public SearchRequest {
        if (operator == null) {
            operator = LogicalOperator.AND;
        }
        if (filters == null) {
            filters = new LinkedHashMap<>();
        } else {
            // Defensive copy — inner list 도 unmodifiable 로 적용 (Records immutability 자연).
            LinkedHashMap<LogicalOperator, List<FilterItem>> copy = new LinkedHashMap<>();
            for (Map.Entry<LogicalOperator, List<FilterItem>> e : filters.entrySet()) {
                copy.put(e.getKey(), List.copyOf(e.getValue()));
            }
            filters = copy;
        }
        sorts = sorts == null ? List.of() : List.copyOf(sorts);
        quickSearchFields = quickSearchFields == null ? List.of() : List.copyOf(quickSearchFields);
        additionalContext = additionalContext == null
            ? Map.of() : Map.copyOf(additionalContext);
        mappedJoinFilters = mappedJoinFilters == null ? List.of() : List.copyOf(mappedJoinFilters);
        unmappedJoins = unmappedJoins == null ? List.of() : List.copyOf(unmappedJoins);
        if (pageSize == null || pageSize <= 0) {
            pageSize = 20;
        }
        if (page == null || page < 0) {
            page = 0;
        }
        if (viewDetail == null) {
            viewDetail = Boolean.FALSE;
        }
        if (exactMatch == null) {
            exactMatch = Boolean.FALSE;
        }
        if (ignoreCache == null) {
            ignoreCache = Boolean.FALSE;
        }
        if (shouldReturnEmpty == null) {
            shouldReturnEmpty = Boolean.FALSE;
        }
        if (forceFetchFromDB == null) {
            forceFetchFromDB = Boolean.FALSE;
        }
    }

    /** 빈 SearchRequest (page=0, pageSize=20, AND, no filters). */
    public static SearchRequest empty() {
        return new Builder().build();
    }

    /** Builder 진입 — 기본 page=0, pageSize=20, operator=AND. */
    public static Builder builder() {
        return new Builder();
    }

    /** 모든 (top-level + subFilters) FilterItem leaf 수집 — Phase 3 의 {@code SearchRequestPlanner} 가 사용. */
    public List<FilterItem> allFilters() {
        List<FilterItem> all = new ArrayList<>();
        for (List<FilterItem> ops : filters.values()) {
            collectLeaves(ops, all);
        }
        return all;
    }

    private static void collectLeaves(List<FilterItem> items, List<FilterItem> sink) {
        for (FilterItem item : items) {
            if (item.hasSubFilters()) {
                for (List<FilterItem> sub : item.subFilters().values()) {
                    collectLeaves(sub, sink);
                }
            } else {
                sink.add(item);
            }
        }
    }

    /**
     * 백업 — service-layer userId/tenantId 강제 주입 후 fetch → 응답으로 frontend 에 돌려줄 때 *원래 client
     * filter 만* 보내는 영역 (0.0.5 {@code createPreservedFilterAndSortCriteria} 흡수, 청사진 §5.5.6).
     */
    public SearchRequest preserve() {
        return new SearchRequest(
            page, pageSize, operator,
            new LinkedHashMap<>(filters),
            List.copyOf(sorts),
            List.copyOf(quickSearchFields),
            searchTerm, viewDetail, exactMatch, ignoreCache, shouldReturnEmpty, forceFetchFromDB,
            cacheTTL, Map.copyOf(additionalContext),
            List.copyOf(mappedJoinFilters), List.copyOf(unmappedJoins));
    }

    /** {@link #preserve()} 결과를 그대로 반환 — Records 자연 immutability 라 별도 복원 로직 불필요. */
    public SearchRequest restore() {
        return this;
    }

    /**
     * FETCH JOIN 영역 — N+1 회피용 EAGER fetch path 명시 (Phase 3 task #6i).
     * {@code additionalContext} 의 reserved key {@code __fetchJoins__} 에 list 형태로 박는다.
     */
    @SuppressWarnings("unchecked")
    public List<String> fetchJoins() {
        Object v = additionalContext == null ? null : additionalContext.get(FETCH_JOINS_KEY);
        if (v instanceof List<?> list) {
            List<String> out = new ArrayList<>(list.size());
            for (Object o : list) {
                if (o instanceof String s) {
                    out.add(s);
                }
            }
            return List.copyOf(out);
        }
        return List.of();
    }

    /** {@link #additionalContext} 안에서 fetchJoins list 의 reserved key. */
    public static final String FETCH_JOINS_KEY = "__fetchJoins__";

    /** search 결과 cache key — operator + filters + sorts + page/size 단순 hash (Phase 3 정교화). */
    public String cacheKey() {
        return Integer.toHexString(Objects.hash(
            operator, filters, sorts, page, pageSize, searchTerm, quickSearchFields,
            viewDetail, exactMatch));
    }

    /** Builder 로 변환 (with*() 패턴 위해서). */
    public Builder toBuilder() {
        Builder b = new Builder()
            .page(page == null ? 0 : page)
            .pageSize(pageSize == null ? 20 : pageSize)
            .operator(operator)
            .searchTerm(searchTerm)
            .viewDetail(Boolean.TRUE.equals(viewDetail))
            .exactMatch(Boolean.TRUE.equals(exactMatch))
            .ignoreCache(Boolean.TRUE.equals(ignoreCache))
            .shouldReturnEmpty(Boolean.TRUE.equals(shouldReturnEmpty))
            .forceFetchFromDB(Boolean.TRUE.equals(forceFetchFromDB))
            .cacheTTL(cacheTTL);
        b.filters.putAll(filters);
        b.sorts.addAll(sorts);
        b.quickSearchFields.addAll(quickSearchFields);
        b.additionalContext.putAll(additionalContext);
        b.mappedJoinFilters.addAll(mappedJoinFilters);
        b.unmappedJoins.addAll(unmappedJoins);
        return b;
    }

    /** {@code page} 만 갈아끼운 새 Records. */
    public SearchRequest withPage(int newPage) {
        return toBuilder().page(newPage).build();
    }

    /** {@code pageSize} 만 갈아끼운 새 Records. */
    public SearchRequest withPageSize(int newSize) {
        return toBuilder().pageSize(newSize).build();
    }

    /** boolean accessor — null safe Boolean 자동 변환 (Records 자체는 nullable). */
    public boolean isViewDetail() {
        return Boolean.TRUE.equals(viewDetail);
    }

    public boolean isExactMatch() {
        return Boolean.TRUE.equals(exactMatch);
    }

    public boolean isIgnoreCache() {
        return Boolean.TRUE.equals(ignoreCache);
    }

    public boolean isShouldReturnEmpty() {
        return Boolean.TRUE.equals(shouldReturnEmpty);
    }

    public boolean isForceFetchFromDB() {
        return Boolean.TRUE.equals(forceFetchFromDB);
    }

    // -----------------------------------------------------------------------
    // Builder — 33 종 fluent filter method (청사진 §5.5.6 적용, 0.0.5 1:1 흡수)
    // -----------------------------------------------------------------------

    /**
     * SearchRequest fluent builder — 33 종 filter method + sort method + paging method 모두 적용.
     *
     * <p>Builder 자체는 mutable (fluent chain) — {@code build()} 이후 Records 의 자연 immutability.
     */
    public static final class Builder {

        private int page = 0;
        private int pageSize = 20;
        private LogicalOperator operator = LogicalOperator.AND;
        private final LinkedHashMap<LogicalOperator, List<FilterItem>> filters = new LinkedHashMap<>();
        private final List<SortInfo> sorts = new ArrayList<>();
        private final List<String> quickSearchFields = new ArrayList<>();
        private String searchTerm;
        private boolean viewDetail;
        private boolean exactMatch;
        private boolean ignoreCache;
        private boolean shouldReturnEmpty;
        private boolean forceFetchFromDB;
        private Long cacheTTL;
        private final Map<String, Object> additionalContext = new LinkedHashMap<>();
        private final List<FilterItem> mappedJoinFilters = new ArrayList<>();
        private final List<UnmappedJoin> unmappedJoins = new ArrayList<>();

        public Builder page(int page) {
            this.page = page;
            return this;
        }

        public Builder pageSize(int pageSize) {
            this.pageSize = pageSize;
            return this;
        }

        public Builder operator(LogicalOperator operator) {
            this.operator = operator == null ? LogicalOperator.AND : operator;
            return this;
        }

        public Builder searchTerm(String searchTerm) {
            this.searchTerm = searchTerm;
            return this;
        }

        public Builder quickSearchFields(Collection<String> fields) {
            this.quickSearchFields.clear();
            if (fields != null) {
                this.quickSearchFields.addAll(fields);
            }
            return this;
        }

        public Builder viewDetail(boolean viewDetail) {
            this.viewDetail = viewDetail;
            return this;
        }

        public Builder exactMatch(boolean exactMatch) {
            this.exactMatch = exactMatch;
            return this;
        }

        public Builder ignoreCache(boolean ignoreCache) {
            this.ignoreCache = ignoreCache;
            return this;
        }

        public Builder shouldReturnEmpty(boolean shouldReturnEmpty) {
            this.shouldReturnEmpty = shouldReturnEmpty;
            return this;
        }

        public Builder forceFetchFromDB(boolean forceFetchFromDB) {
            this.forceFetchFromDB = forceFetchFromDB;
            return this;
        }

        public Builder cacheTTL(Long cacheTTL) {
            this.cacheTTL = cacheTTL;
            return this;
        }

        public Builder additionalContext(String key, Object value) {
            this.additionalContext.put(key, value);
            return this;
        }

        /**
         * FETCH JOIN 한 path 추가 — N+1 회피 (Phase 3 task #6i). 다중 호출 가능.
         *
         * <p>경고: collection (OneToMany / ManyToMany) {@code List} 타입은 한 query 안 *1 개만* fetch 가능
         * (Hibernate {@code MultipleBagFetchException}). {@code Set} 타입은 다중 fetch OK.
         */
        @SuppressWarnings("unchecked")
        public Builder fetchJoin(String path) {
            if (path == null || path.isBlank()) {
                return this;
            }
            List<String> existing = (List<String>) this.additionalContext.computeIfAbsent(
                FETCH_JOINS_KEY, k -> new ArrayList<String>());
            existing.add(path);
            return this;
        }

        /** 다수 fetch path 한 번에. */
        public Builder fetchJoins(Collection<String> paths) {
            if (paths == null) {
                return this;
            }
            for (String p : paths) {
                fetchJoin(p);
            }
            return this;
        }

        public Builder addUnmappedJoin(UnmappedJoin join) {
            if (join != null) {
                this.unmappedJoins.add(join);
            }
            return this;
        }

        public Builder addMappedJoinFilter(FilterItem item) {
            if (item != null) {
                this.mappedJoinFilters.add(item);
            }
            return this;
        }

        // ----------------- Sort fluent ----------------------------------

        public Builder withSort(String field, Direction direction) {
            return addSort(NormalSortInfo.of(field, direction));
        }

        public Builder addSort(String field, Direction direction) {
            return addSort(NormalSortInfo.of(field, direction));
        }

        public Builder addSort(String field, Direction direction, JoinType joinType) {
            return addSort(NormalSortInfo.of(field, direction, joinType));
        }

        public Builder addSort(String field, Direction direction, JoinType joinType, Boolean nullsFirst) {
            return addSort(new NormalSortInfo(field, direction, joinType, nullsFirst));
        }

        public Builder addLeftJoinSort(String field, Direction direction) {
            return addSort(NormalSortInfo.of(field, direction, JoinType.LEFT));
        }

        public Builder withPrioritySort(String field, Object priorityValue, Direction direction) {
            return addSort(PrioritySortInfo.of(field, priorityValue, direction));
        }

        public Builder addPrioritySort(
            String field, Object priorityValue, Direction direction, JoinType joinType, Boolean nullsFirst
        ) {
            return addSort(new PrioritySortInfo(field, priorityValue, direction, joinType, nullsFirst));
        }

        public Builder addLeftJoinPrioritySort(String field, Object priorityValue, Direction direction) {
            return addSort(new PrioritySortInfo(field, priorityValue, direction, JoinType.LEFT, null));
        }

        public Builder addSort(SortInfo sort) {
            if (sort != null) {
                this.sorts.add(sort);
            }
            return this;
        }

        public Builder removeSortStartWith(String prefix) {
            this.sorts.removeIf(s -> s.field() != null && s.field().startsWith(prefix));
            return this;
        }

        // ----------------- 33 fluent filter (청사진 §5.5.6) -----------------

        /** #1 filterEquals — gjcu 26 회 top 사용 (privilege enforcement). */
        public Builder filterEquals(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.EQUAL, toStr(value)));
        }

        /** #2 filterNotEquals. */
        public Builder filterNotEquals(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NOT_EQUAL, toStr(value)));
        }

        /** #3 filterEqualsIgnoreCase — wire format = NOT_EQUAL + flag (Phase 3 builder 가 처리). */
        public Builder filterEqualsIgnoreCase(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.EQUAL,
                    null, null, null, null, null));
        }

        /** #4 filterNotEqualsIgnoreCase. */
        public Builder filterNotEqualsIgnoreCase(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.NOT_EQUAL,
                    null, null, null, null, null));
        }

        /** #5 filterNullOrEquals. */
        public Builder filterNullOrEquals(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NULL_OR_EQUAL, toStr(value)));
        }

        /** #6 filterNullOrNotEquals — wire format = NULL_OR_EQUAL + not flag. */
        public Builder filterNullOrNotEquals(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.NULL_OR_EQUAL,
                    Boolean.TRUE, null, null, null, null));
        }

        /** #7 filterIn. */
        public Builder filterIn(String field, Collection<?> values) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.IN, toStrList(values)));
        }

        /** #8 filterNotIn. */
        public Builder filterNotIn(String field, Collection<?> values) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NOT_IN, toStrList(values)));
        }

        /** #9 filterLike. */
        public Builder filterLike(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.LIKE, toStr(value)));
        }

        /** #10 filterNotLike. */
        public Builder filterNotLike(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NOT_LIKE, toStr(value)));
        }

        /** #11 filterStartWith. */
        public Builder filterStartWith(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.LIKE, toStr(value) + "%"));
        }

        /** #12 filterNotStartWith. */
        public Builder filterNotStartWith(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NOT_LIKE, toStr(value) + "%"));
        }

        /** #13 filterEndWith. */
        public Builder filterEndWith(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.LIKE, "%" + toStr(value)));
        }

        /** #14 filterNotEndWith. */
        public Builder filterNotEndWith(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.NOT_LIKE, "%" + toStr(value)));
        }

        /** #15 filterGreaterThan. */
        public Builder filterGreaterThan(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.GREATER_THAN, toStr(value)));
        }

        /** #16 filterGreaterThanOrEqual. */
        public Builder filterGreaterThanOrEqual(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.GREATER_THAN_EQUAL, toStr(value)));
        }

        /** #17 filterNotGreaterThan — wire format = GREATER_THAN + not flag. */
        public Builder filterNotGreaterThan(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.GREATER_THAN,
                    Boolean.TRUE, null, null, null, null));
        }

        /** #18 filterNotGreaterThanOrEqual. */
        public Builder filterNotGreaterThanOrEqual(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.GREATER_THAN_EQUAL,
                    Boolean.TRUE, null, null, null, null));
        }

        /** #19 filterLessThan. */
        public Builder filterLessThan(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.LESS_THAN, toStr(value)));
        }

        /** #20 filterLessThanOrEqual. */
        public Builder filterLessThanOrEqual(String field, Object value) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.LESS_THAN_EQUAL, toStr(value)));
        }

        /** #21 filterNotLessThan. */
        public Builder filterNotLessThan(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.LESS_THAN,
                    Boolean.TRUE, null, null, null, null));
        }

        /** #22 filterNotLessThanOrEqual. */
        public Builder filterNotLessThanOrEqual(String field, Object value) {
            return addFilter(operator,
                new FilterItem(field, toStr(value), null, QueryConditionType.LESS_THAN_EQUAL,
                    Boolean.TRUE, null, null, null, null));
        }

        /** #23 filterBetween. */
        public Builder filterBetween(String field, Object from, Object to) {
            return addFilter(operator,
                FilterItem.of(field, QueryConditionType.BETWEEN, List.of(toStr(from), toStr(to))));
        }

        /** #24 filterNotBetween. */
        public Builder filterNotBetween(String field, Object from, Object to) {
            return addFilter(operator,
                new FilterItem(field, null, List.of(toStr(from), toStr(to)),
                    QueryConditionType.BETWEEN, Boolean.TRUE, null, null, null, null));
        }

        /** #25 filterIsNull. */
        public Builder filterIsNull(String field) {
            return addFilter(operator,
                new FilterItem(field, null, null, QueryConditionType.IS_NULL,
                    null, null, null, null, null));
        }

        /** #26 filterIsNotNull. */
        public Builder filterIsNotNull(String field) {
            return addFilter(operator,
                new FilterItem(field, null, null, QueryConditionType.IS_NOT_NULL,
                    null, null, null, null, null));
        }

        /** #27 filterIsNullOrBlank. */
        public Builder filterIsNullOrBlank(String field) {
            return addFilter(operator,
                new FilterItem(field, null, null, QueryConditionType.NULL_OR_BLANK,
                    null, null, null, null, null));
        }

        /** #28 filterIdEquals — ManyToOne ID 단축 (가장 흔한 privilege 패턴, gjcu 26 회 top). */
        public Builder filterIdEquals(Object idValue) {
            return filterEquals("id", idValue);
        }

        /** #29 filterOr — 명시 OR 합성 (n FilterItem 을 OR group 으로). */
        public Builder filterOr(FilterItem... items) {
            for (FilterItem item : items) {
                if (item != null) {
                    addFilter(LogicalOperator.OR, item);
                }
            }
            return this;
        }

        /** #30 filterAnd — 명시 AND 합성. */
        public Builder filterAnd(FilterItem... items) {
            for (FilterItem item : items) {
                if (item != null) {
                    addFilter(LogicalOperator.AND, item);
                }
            }
            return this;
        }

        /** #31 filterNot — 명시 NOT 합성. */
        public Builder filterNot(FilterItem... items) {
            for (FilterItem item : items) {
                if (item != null) {
                    addFilter(LogicalOperator.NOT, item);
                }
            }
            return this;
        }

        /** #32 filter — generic (operator + condition + name + value). */
        public Builder filter(LogicalOperator op, QueryConditionType type, String name, Object value) {
            return addFilter(op == null ? operator : op,
                FilterItem.of(name, type, toStr(value)));
        }

        /** #33 filter — generic with explicit JoinType (LEFT JOIN 등). */
        public Builder filter(
            LogicalOperator op, QueryConditionType type, String name, Object value, JoinType joinType
        ) {
            FilterItem item = new FilterItem(name, toStr(value), null, type, null, null,
                joinType, null, null);
            return addFilter(op == null ? operator : op, item);
        }

        // ----------------- Modification + utility (0.0.5 동일) -----------------

        /** {@code removeFilter(field)} — 동일 이름 filter 제거. */
        public Builder removeFilter(String field) {
            for (List<FilterItem> ops : filters.values()) {
                ops.removeIf(item -> Objects.equals(item.name(), field));
            }
            return this;
        }

        /** {@code removeFilters(operator, ...names)} — 특정 operator 의 여러 이름 제거. */
        public Builder removeFilters(LogicalOperator op, String... names) {
            List<FilterItem> ops = filters.get(op);
            if (ops != null) {
                List<String> namesList = List.of(names);
                ops.removeIf(item -> namesList.contains(item.name()));
            }
            return this;
        }

        /** {@code removeFiltersExcludeNames(operator, ...names)} — names 제외하고 모두 제거. */
        public Builder removeFiltersExcludeNames(LogicalOperator op, String... names) {
            List<FilterItem> ops = filters.get(op);
            if (ops != null) {
                List<String> keep = List.of(names);
                ops.removeIf(item -> !keep.contains(item.name()));
            }
            return this;
        }

        /** {@code removeFilterItem(operator, name)} — 첫 매칭만 제거. */
        public Builder removeFilterItem(LogicalOperator op, String name) {
            List<FilterItem> ops = filters.get(op);
            if (ops != null) {
                for (int i = 0; i < ops.size(); i++) {
                    if (Objects.equals(ops.get(i).name(), name)) {
                        ops.remove(i);
                        break;
                    }
                }
            }
            return this;
        }

        /** {@code setFilterIfAbsent(operator, ...items)} — 같은 이름 있으면 덮지 않음. */
        public Builder setFilterIfAbsent(LogicalOperator op, FilterItem... items) {
            List<FilterItem> ops = filters.computeIfAbsent(op, k -> new ArrayList<>());
            for (FilterItem item : items) {
                boolean exists = ops.stream().anyMatch(e -> Objects.equals(e.name(), item.name()));
                if (!exists) {
                    ops.add(item);
                }
            }
            return this;
        }

        /** {@code hasFilter(field)} — 존재 여부. */
        public boolean hasFilter(String field) {
            for (List<FilterItem> ops : filters.values()) {
                for (FilterItem item : ops) {
                    if (Objects.equals(item.name(), field)) {
                        return true;
                    }
                }
            }
            return false;
        }

        /** 내부: operator group 에 item 추가. */
        public Builder addFilter(LogicalOperator op, FilterItem item) {
            filters.computeIfAbsent(op, k -> new ArrayList<>()).add(item);
            return this;
        }

        public SearchRequest build() {
            return new SearchRequest(
                page, pageSize, operator,
                new LinkedHashMap<>(filters),
                List.copyOf(sorts),
                List.copyOf(quickSearchFields),
                searchTerm, viewDetail, exactMatch, ignoreCache, shouldReturnEmpty, forceFetchFromDB,
                cacheTTL, Map.copyOf(additionalContext),
                List.copyOf(mappedJoinFilters), List.copyOf(unmappedJoins));
        }

        private static String toStr(Object o) {
            return o == null ? null : o.toString();
        }

        private static List<String> toStrList(Collection<?> values) {
            if (values == null) {
                return List.of();
            }
            List<String> out = new ArrayList<>(values.size());
            for (Object o : values) {
                out.add(o == null ? null : o.toString());
            }
            return out;
        }
    }
}
