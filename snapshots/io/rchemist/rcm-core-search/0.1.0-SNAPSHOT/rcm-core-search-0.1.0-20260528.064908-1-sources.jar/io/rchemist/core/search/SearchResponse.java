/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.rchemist.core.error.ErrorType;
import io.rchemist.core.error.FieldErrorEntry;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 풍부한 list endpoint 응답 wire format — Phase 0.1.0 GA Gate T0-5 (G-A-7) 신규.
 *
 * <p>0.0.5 {@code ResponseListWrapper} 1:1 흡수 (메모리 {@code feedback_no_feature_regression} 정합):
 * <ul>
 *   <li>{@code content}                     — 결과 list ({@code Page<T>.getContent()} 정합)</li>
 *   <li>{@code page / pageSize / totalElements / totalPages} — 페이징 메타 ({@code Page<T>} 정합)</li>
 *   <li>{@code sorts: List<SortInfo>}        — 적용 sort echo (NormalSortInfo + PrioritySortInfo)</li>
 *   <li>{@code searchRequest: SearchRequest} — 원래 client request echo ({@code preserve()} cycle 결과)</li>
 *   <li>{@code attributes: Map<String,Object>} — 추가 도메인 정보 (facet count / aggregation / 통계)</li>
 *   <li>{@code errors: List<FieldErrorEntry>} — list-level 부분 에러 (치명 에러는 ProblemDetail 별개 영역)</li>
 * </ul>
 *
 * <p>Decision #1 *envelope 폐기* 와 *list-specific 풍부 응답* 은 별개 영역 — 성공 응답의 list-specific
 * 메타정보 (sorts echo / searchRequest echo / attributes / 부분 에러) 는 envelope 와 무관.
 *
 * <p>Records 의 immutability 자연 — 모든 {@code with*()} 가 새 SearchResponse 반환. concurrent 안전.
 *
 * <p>Decision #31 정합 endpoint 매트릭스 — {@code GET /} (단순 query string) /
 * {@code POST /search} (고급 SearchRequest) / {@code POST /count} 모두 본 응답 변환.
 *
 * @param <T> content element 타입 (보통 ReadDTO)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SearchResponse<T>(
    List<T> content,
    int page,
    int pageSize,
    long totalElements,
    int totalPages,
    List<SortInfo> sorts,
    SearchRequest searchRequest,
    Map<String, Object> attributes,
    List<FieldErrorEntry> errors
) {

  public SearchResponse {
    content = content == null ? List.of() : List.copyOf(content);
    if (pageSize <= 0) {
      pageSize = 20;
    }
    if (page < 0) {
      page = 0;
    }
    if (totalElements < 0L) {
      totalElements = 0L;
    }
    if (totalPages < 0) {
      totalPages = computeTotalPages(totalElements, pageSize);
    }
    sorts = sorts == null ? List.of() : List.copyOf(sorts);
    attributes = attributes == null ? Map.of() : Map.copyOf(attributes);
    errors = errors == null ? List.of() : List.copyOf(errors);
  }

  private static int computeTotalPages(long totalElements, int pageSize) {
    if (totalElements <= 0L || pageSize <= 0) {
      return 0;
    }
    return (int) ((totalElements + pageSize - 1L) / (long) pageSize);
  }

  /** 빈 응답 (페이징 0 / sorts 0 / errors 0). */
  public static <T> SearchResponse<T> empty() {
    return new SearchResponse<>(List.of(), 0, 20, 0L, 0,
        List.of(), null, Map.of(), List.of());
  }

  /**
   * 단순 응답 — content + 페이징 메타만. sorts/searchRequest/attributes/errors 는 비움.
   * {@code totalPages} 는 자동 계산.
   */
  public static <T> SearchResponse<T> of(
      List<T> content, int page, int pageSize, long totalElements
  ) {
    return new SearchResponse<>(content, page, pageSize, totalElements,
        computeTotalPages(totalElements, pageSize),
        List.of(), null, Map.of(), List.of());
  }

  /**
   * SearchRequest echo 가 결합된 응답 — service-layer {@code preserve()} 후 결과 echo.
   * sorts 는 SearchRequest 의 sorts 를 자동 echo.
   */
  public static <T> SearchResponse<T> of(
      List<T> content, long totalElements, SearchRequest searchRequest
  ) {
    int pageSize = searchRequest != null && searchRequest.pageSize() != null
        ? searchRequest.pageSize() : 20;
    int page = searchRequest != null && searchRequest.page() != null
        ? searchRequest.page() : 0;
    List<SortInfo> sorts = searchRequest == null ? List.of() : searchRequest.sorts();
    return new SearchResponse<>(content, page, pageSize, totalElements,
        computeTotalPages(totalElements, pageSize),
        sorts, searchRequest, Map.of(), List.of());
  }

  /** {@code attributes} 1 key 추가 — 새 SearchResponse 반환 (Records immutability). */
  public SearchResponse<T> withAttribute(String key, Object value) {
    LinkedHashMap<String, Object> next = new LinkedHashMap<>(attributes);
    next.put(key, value);
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        sorts, searchRequest, next, errors);
  }

  /** {@code attributes} 통째 갱신 — 새 SearchResponse 반환. */
  public SearchResponse<T> withAttributes(Map<String, Object> next) {
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        sorts, searchRequest, next, errors);
  }

  /** {@code sorts} 통째 갱신 — 새 SearchResponse 반환. */
  public SearchResponse<T> withSorts(List<SortInfo> next) {
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        next, searchRequest, attributes, errors);
  }

  /** {@code searchRequest} echo 갱신 — preserve cycle 후 호출. */
  public SearchResponse<T> withSearchRequest(SearchRequest next) {
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        sorts, next, attributes, errors);
  }

  /** {@code errors} 통째 갱신 — 새 SearchResponse 반환. */
  public SearchResponse<T> withErrors(List<FieldErrorEntry> next) {
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        sorts, searchRequest, attributes, next);
  }

  /** {@code errors} 1 entry 추가 — field nullable (global / generic 에러 OK). */
  public SearchResponse<T> addError(String field, ErrorType errorType, Object... args) {
    java.util.List<FieldErrorEntry> next = new java.util.ArrayList<>(errors);
    next.add(new FieldErrorEntry(field, errorType, args == null || args.length == 0 ? null : args));
    return new SearchResponse<>(content, page, pageSize, totalElements, totalPages,
        sorts, searchRequest, attributes, next);
  }

  /**
   * content element 타입 변환 — entity → ReadDTO 같은 controller-layer 변환에 사용.
   * 페이징 / sorts / searchRequest / attributes / errors 는 그대로 유지.
   *
   * @param mapper element 변환 함수
   * @param <R>    변환 후 타입
   * @return 변환된 새 SearchResponse
   */
  public <R> SearchResponse<R> map(Function<? super T, ? extends R> mapper) {
    java.util.List<R> mapped = new java.util.ArrayList<>(content.size());
    for (T element : content) {
      mapped.add(mapper.apply(element));
    }
    return new SearchResponse<>(mapped, page, pageSize, totalElements, totalPages,
        sorts, searchRequest, attributes, errors);
  }
}
