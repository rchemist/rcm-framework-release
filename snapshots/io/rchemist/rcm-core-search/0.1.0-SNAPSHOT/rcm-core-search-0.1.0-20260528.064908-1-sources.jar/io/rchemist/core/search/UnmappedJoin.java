/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * JPA entity 직접 매핑 안 된 영역의 자연스러운 검색 — 0.0.5 {@code UnmappedJoinItem} 흡수 (청사진 §5.5.6).
 *
 * <p>활용 시나리오:
 * <ul>
 *   <li>Article 검색 + 해당 Article 에 댓글 단 User role = ADMIN (Article ↔ User 직접 매핑 0)</li>
 *   <li>대학 검색 + 졸업생 통계 entity 의 평균 점수 80+</li>
 * </ul>
 *
 * <p>Phase 3 의 {@code PredicateBuilder} 가 이를 만나면 {@code query.from(targetEntityClass)} +
 * 명시 join criterion → SubQuery 자동 생성 (0.0.5 {@code PredicateMerger.mergeUnmappedConditions()}
 * 동등). sealed {@link SearchPredicate} 영역.
 *
 * @param targetEntityClass SubQuery 의 entity (별도 매핑 영역)
 * @param joinAlias JPA criteria alias (cached join path 식별용)
 * @param joinCondition ON 조건 (sealed predicate)
 * @param additionalFilter SubQuery 안 추가 WHERE (nullable)
 */
public record UnmappedJoin(
    Class<?> targetEntityClass,
    String joinAlias,
    SearchPredicate joinCondition,
    SearchPredicate additionalFilter
) implements SearchPredicate {

    public UnmappedJoin {
        Objects.requireNonNull(targetEntityClass, "targetEntityClass");
        Objects.requireNonNull(joinAlias, "joinAlias");
        Objects.requireNonNull(joinCondition, "joinCondition");
    }
}
