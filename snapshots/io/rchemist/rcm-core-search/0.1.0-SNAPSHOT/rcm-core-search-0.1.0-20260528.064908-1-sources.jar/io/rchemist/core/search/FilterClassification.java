/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Filter 영역 분류 — 0.0.5 {@code RegisterEntityBeanPropertyDTO.getPropertyType()} (`@OneToMany.class.getName()`
 * 등) 흡수 (청사진 §5.5.4). {@code SearchRequestPlanner} 가 exhaustive switch 로 자동 routing —
 * column 은 root 위 predicate, MANY_TO_ONE 은 INNER JOIN, ONE_TO_MANY 는 mappedJoinFilters 로 분리,
 * JSON_ATTRIBUTE 는 jsonb path 로.
 *
 * <p>0.1.0 의 가치 = compile-time exhaustive 검증 + APT 가 적용하는 자동 분류. runtime reflection 0.
 */
public enum FilterClassification {

  /** 단순 column (Phase 3 의 root predicate). */
  COLUMN,

  /** Embedded (e.g. {@code @Embeddable Address}) — root path 그대로 통과. */
  EMBEDDED,

  /** ManyToOne 연관 — 자동 INNER JOIN (청사진 §5.5.6). */
  MANY_TO_ONE,

  /** OneToMany / ManyToMany — mappedJoinFilters 자동 분리 (SubQuery / DISTINCT 영역). */
  ONE_TO_MANY,

  /** JSON column 의 attribute path (e.g. {@code attributes.lang}) — jsonb path 자동. */
  JSON_ATTRIBUTE,

  /** 미인식 (entity metadata 부재 또는 화이트리스트 외). {@code SearchRequestPlanner} 가 400 으로 fail loud. */
  UNKNOWN;

  /** 6 종 (Phase 3 task #6 적용). */
  public static int total() {
    return values().length;
  }
}
