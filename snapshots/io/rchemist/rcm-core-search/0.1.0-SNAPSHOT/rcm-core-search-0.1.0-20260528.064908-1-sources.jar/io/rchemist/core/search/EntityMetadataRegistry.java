/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Runtime entity metadata registry — APT {@code EntityMetadataProcessor} 가 컴파일 시점에 적용한
 * {@link EntityMetadata} 구현체 lookup 영역 (청사진 §5.5.4 + §5.5.5). 0.0.5
 * {@code EntityBeanContext.getRegisterEntityBean(class)} 흡수.
 *
 * <p>등록 영역 — APT 가 생성하는 {@code <Entity>_Metadata} 클래스의 static initializer 또는
 * starter-jpa autoconfig 의 classpath scan hook 이 호출. baseline 은 명시 {@link #register} API.
 *
 * <p>thread-safe — {@link ConcurrentHashMap} 기반.
 */
public final class EntityMetadataRegistry {

  private static final ConcurrentMap<Class<?>, EntityMetadata<?>> REGISTRY = new ConcurrentHashMap<>();

  private EntityMetadataRegistry() {
  }

  /** entity class 와 metadata 등록 — 같은 class 는 한 번만 (덮어쓰기 허용). */
  public static <T> void register(Class<T> entityClass, EntityMetadata<T> metadata) {
    if (entityClass == null || metadata == null) {
      throw new IllegalArgumentException("entityClass and metadata must not be null");
    }
    REGISTRY.put(entityClass, metadata);
  }

  /** entity class 의 metadata lookup — 미적용 = {@link Optional#empty()}. */
  @SuppressWarnings("unchecked")
  public static <T> Optional<EntityMetadata<T>> find(Class<T> entityClass) {
    if (entityClass == null) {
      return Optional.empty();
    }
    return Optional.ofNullable((EntityMetadata<T>) REGISTRY.get(entityClass));
  }

  /** entity class 의 metadata 강제 lookup — 미적용 시 fail loud. */
  public static <T> EntityMetadata<T> require(Class<T> entityClass) {
    return EntityMetadataRegistry.<T>find(entityClass)
        .orElseThrow(() -> new IllegalStateException(
            "EntityMetadata not registered for class: "
                + (entityClass == null ? "null" : entityClass.getName())
                + ". Ensure the entity implements Searchable and rcm-apt is configured as annotationProcessor."));
  }

  /** 등록 해제 (test 격리 용). */
  public static void unregister(Class<?> entityClass) {
    if (entityClass != null) {
      REGISTRY.remove(entityClass);
    }
  }

  /** 등록된 entity class 수. */
  public static int size() {
    return REGISTRY.size();
  }

  /** 모든 등록 영역 초기화 (test 격리 용). */
  public static void clear() {
    REGISTRY.clear();
  }
}
