/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단순 sort — 0.0.5 {@code NormalSortInfo} 1:1 흡수 (청사진 §5.5.6).
 *
 * @param field 필드명 (entity property path, e.g. {@code "createdAt"} / {@code "author.name"})
 * @param direction ASC / DESC (null = ASC default)
 * @param joinType ManyToOne/OneToMany 명시 JOIN (null = INNER default)
 * @param nullsFirst NULLS FIRST (true) / LAST (false) / DB default (null)
 */
public record NormalSortInfo(
    String field,
    Direction direction,
    JoinType joinType,
    Boolean nullsFirst
) implements SortInfo {

    public NormalSortInfo {
        Objects.requireNonNull(field, "field");
        if (direction == null) {
            direction = Direction.ASC;
        }
        if (joinType == null) {
            joinType = JoinType.INNER;
        }
    }

    /** field + direction 단축 (joinType=INNER, nullsFirst=DB default). */
    public static NormalSortInfo of(String field, Direction direction) {
        return new NormalSortInfo(field, direction, JoinType.INNER, null);
    }

    /** field + direction + joinType 단축 (nullsFirst=DB default). */
    public static NormalSortInfo of(String field, Direction direction, JoinType joinType) {
        return new NormalSortInfo(field, direction, joinType, null);
    }
}
