/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.index.outbox;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * In-memory {@link SearchIndexOutbox} — ConcurrentHashMap 기반 default.
 *
 * <p>주의: 재시작 시 손실 (durability 0). production = JPA-backed 어댑터 권장.
 *
 * <p>thread-safe — pollNext 의 INDEXING 전환은 {@link ConcurrentMap#replace(Object, Object,
 * Object)} CAS 로 race-free.
 **/
public class InMemorySearchIndexOutbox implements SearchIndexOutbox {

  private final ConcurrentMap<String, SearchIndexEntry> entries = new ConcurrentHashMap<>();

  @Override
  public String append(SearchIndexEvent event) {
    String id = UUID.randomUUID().toString();
    Instant now = Instant.now();
    entries.put(id, new SearchIndexEntry(id, event, 0, SearchIndexEntryStatus.PENDING, null, now));
    return id;
  }

  @Override
  public Optional<SearchIndexEntry> pollNext() {
    Instant now = Instant.now();
    for (SearchIndexEntry entry : entries.values()) {
      if ((entry.status() == SearchIndexEntryStatus.PENDING
              || entry.status() == SearchIndexEntryStatus.RETRYING)
          && !entry.nextAttemptAt().isAfter(now)) {
        SearchIndexEntry indexing = entry.markIndexing();
        if (entries.replace(entry.id(), entry, indexing)) {
          return Optional.of(indexing);
        }
      }
    }
    return Optional.empty();
  }

  @Override
  public void markIndexed(String id) {
    entries.computeIfPresent(id, (k, e) -> e.markIndexed());
  }

  @Override
  public void markRetrying(String id, String error, Instant nextAttemptAt) {
    entries.computeIfPresent(id, (k, e) -> e.markRetrying(error, nextAttemptAt));
  }

  @Override
  public void markDead(String id, String error) {
    entries.computeIfPresent(id, (k, e) -> e.markDead(error));
  }

  @Override
  public int size() {
    return entries.size();
  }

  @Override
  public int pendingCount() {
    int count = 0;
    for (SearchIndexEntry e : entries.values()) {
      // lag metric = 아직 INDEXED / DEAD 가 아닌 모든 entry (PENDING + INDEXING + RETRYING)
      if (e.status() != SearchIndexEntryStatus.INDEXED
          && e.status() != SearchIndexEntryStatus.DEAD) {
        count++;
      }
    }
    return count;
  }

  @Override
  public Optional<SearchIndexEntry> findById(String id) {
    return Optional.ofNullable(entries.get(id));
  }

  /** 모든 entry 초기화 (test 격리). */
  public void clear() {
    entries.clear();
  }
}
