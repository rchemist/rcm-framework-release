/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search.extension;

import io.rchemist.core.search.SortInfo;
import io.rchemist.extension.ExtensionPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Sort 가상/계산/JSON 필드 → 실제 entity 경로 매핑 ExtensionPoint. {@link SearchFieldModifier} 와 짝.
 *
 * <p>Consumer 가 Spring bean 으로 등록하면 {@code OrderByBuilder} 가 매 {@link SortInfo} 변환 시점에
 * {@link #supports(Class, SortInfo)} 차례 호출. true 반환 시 {@link #modify(SortInfo, Class)} 결과로 원본
 * 교체. 변환 결과의 {@code field()} 가 실제 JPQL 평가에 사용됨.
 *
 * <p>전형 사용:
 * <ul>
 *   <li>JSON path 정렬 — {@code attributes.score} → {@code (attributes->>'score')::numeric}</li>
 *   <li>가상 sort key — {@code popularity} → {@code (viewCount + commentCount * 5)}</li>
 *   <li>locale 별 정렬 — {@code title} → {@code title_ko} / {@code title_en} (request locale 따라)</li>
 * </ul>
 **/
@ExtensionPoint("Sort 가상/계산/JSON 필드 → 실제 entity 경로 매핑")
public interface SortFieldModifier {

    /** 본 modifier 가 해당 entity 의 해당 sort 를 처리할 수 있는지. */
    boolean supports(Class<?> entityType, SortInfo sort);

    /**
     * 원본 sort 를 변환된 sort 로 매핑. {@code SortInfo} 는 sealed — 구현체 (NormalSortInfo /
     * PrioritySortInfo) 의 record 컴포넌트 일부만 갈아끼우려면 새 인스턴스 생성.
     */
    SortInfo modify(SortInfo original, Class<?> entityType);
}
