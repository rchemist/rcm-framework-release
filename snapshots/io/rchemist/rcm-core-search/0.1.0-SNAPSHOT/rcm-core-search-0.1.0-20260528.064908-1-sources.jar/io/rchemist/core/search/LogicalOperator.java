/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Filter tree 의 논리 연산자 — 0.0.5 {@code ConditionOperatorType} 흡수.
 *
 * <p>frontend wire format 의 {@code "AND" / "OR" / "NOT"} key 와 1:1 정합 (청사진 §5.5.2).
 */
public enum LogicalOperator {
    AND,
    OR,
    NOT
}
