/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 우선순위 sort — 0.0.5 {@code PrioritySortInfo} 1:1 흡수 (청사진 §5.5.6).
 *
 * <p>{@code CASE WHEN field = priorityValue THEN 0 ELSE 1 END} JPQL 자동 — 특정 값이 *가장 위* 로
 * 정렬되는 영역 (예: {@code status = 'URGENT'} 위에 다른 status). Phase 3
 * {@code OrderByBuilder} 가 변환.
 *
 * @param field 필드명
 * @param priorityValue 우선 값 ({@code field == priorityValue} 인 row 가 정렬 우선)
 * @param direction 동일 priority 내 보조 정렬 방향
 * @param joinType ManyToOne/OneToMany 명시 JOIN (null = INNER default)
 * @param nullsFirst NULLS FIRST (true) / LAST (false) / DB default (null)
 */
public record PrioritySortInfo(
    String field,
    Object priorityValue,
    Direction direction,
    JoinType joinType,
    Boolean nullsFirst
) implements SortInfo {

    public PrioritySortInfo {
        Objects.requireNonNull(field, "field");
        Objects.requireNonNull(priorityValue, "priorityValue");
        if (direction == null) {
            direction = Direction.ASC;
        }
        if (joinType == null) {
            joinType = JoinType.INNER;
        }
    }

    /** field + priorityValue + direction 단축. */
    public static PrioritySortInfo of(String field, Object priorityValue, Direction direction) {
        return new PrioritySortInfo(field, priorityValue, direction, JoinType.INNER, null);
    }
}
