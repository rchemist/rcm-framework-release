/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 집계 항목 — Phase 3 task #6f.
 *
 * @param function 집계 함수 ({@link AggregationFunction})
 * @param field    대상 필드 (entity property path, {@code "*"} = COUNT(*) 동등)
 * @param alias    결과 alias — Tuple lookup key. null 시 {@code function_field} 자동.
 */
public record Aggregation(
    AggregationFunction function,
    String field,
    String alias
) {

  public Aggregation {
    Objects.requireNonNull(function, "function");
    Objects.requireNonNull(field, "field");
    if (alias == null || alias.isBlank()) {
      alias = function.name().toLowerCase() + "_" + field.replace('.', '_').replace('*', 'a');
    }
  }

  /** count(*) shortcut. */
  public static Aggregation countAll() {
    return new Aggregation(AggregationFunction.COUNT, "*", "count_all");
  }

  /** count(field). */
  public static Aggregation count(String field) {
    return new Aggregation(AggregationFunction.COUNT, field, null);
  }

  /** count(distinct field). */
  public static Aggregation countDistinct(String field) {
    return new Aggregation(AggregationFunction.COUNT_DISTINCT, field, null);
  }

  /** sum(field). */
  public static Aggregation sum(String field) {
    return new Aggregation(AggregationFunction.SUM, field, null);
  }

  /** avg(field). */
  public static Aggregation avg(String field) {
    return new Aggregation(AggregationFunction.AVG, field, null);
  }

  /** min(field). */
  public static Aggregation min(String field) {
    return new Aggregation(AggregationFunction.MIN, field, null);
  }

  /** max(field). */
  public static Aggregation max(String field) {
    return new Aggregation(AggregationFunction.MAX, field, null);
  }
}
