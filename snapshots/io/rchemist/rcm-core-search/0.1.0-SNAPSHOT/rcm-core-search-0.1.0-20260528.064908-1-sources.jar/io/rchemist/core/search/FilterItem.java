/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 filter 엔트리 — 0.0.5 {@code FilterItem} 1:1 흡수 (청사진 §5.5.3).
 *
 * <p>frontend SearchForm 직렬화 형태 그대로 wire format. {@code value} 는 single, {@code values} 는
 * IN/BETWEEN multiple. {@code subFilters} 가 채워지면 중첩 트리 (e.g. quickSearch OR 전개) — null/빈
 * map 이면 leaf.
 *
 * <p>sealed {@link SearchPredicate} 영역 — {@code SearchRequestPlanner} 가 exhaustive switch 로 처리.
 *
 * @param name 필드명 (entity property path, e.g. {@code "title"} / {@code "author.name"} /
 *     {@code "attributes.lang"} JSON path 자동 인식). {@code "_quickSearch"} 같은 가상 필드도 허용.
 * @param value 단일 값 (LIKE / EQ / NOT_EQ / GT / LT 등)
 * @param values multiple 값 (IN / NOT_IN / BETWEEN / IN_RANGE 등)
 * @param queryConditionType 24 종 condition (null = EQUAL default)
 * @param not NOT 토글 (null = false). top-level NOT 영역과 별개 — 단일 filter 단의 부정.
 * @param subFilters 중첩 AND/OR 트리 (null = leaf)
 * @param joinType ManyToOne/OneToMany 등 명시 JOIN (null = INNER default)
 * @param fieldType 자동 채움 (validate 후 — APT 가 컴파일 시점에 적용, runtime 에서 추가 채워질 수 있음)
 * @param jsonFilter JSON 필드 자동 인식 (기본 null = 자동 추론)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record FilterItem(
    String name,
    String value,
    List<String> values,
    QueryConditionType queryConditionType,
    Boolean not,
    LinkedHashMap<LogicalOperator, List<FilterItem>> subFilters,
    JoinType joinType,
    Class<?> fieldType,
    Boolean jsonFilter
) implements SearchPredicate {

    /** 모든 nullable 필드 default 적용 — name 만 필수. */
    public FilterItem {
        Objects.requireNonNull(name, "name");
        if (queryConditionType == null) {
            queryConditionType = QueryConditionType.EQUAL;
        }
        if (values == null) {
            values = List.of();
        } else {
            values = List.copyOf(values);
        }
        if (subFilters != null) {
            // defensive copy — Records 자연 immutability 보존.
            LinkedHashMap<LogicalOperator, List<FilterItem>> copy = new LinkedHashMap<>();
            for (Map.Entry<LogicalOperator, List<FilterItem>> e : subFilters.entrySet()) {
                copy.put(e.getKey(), List.copyOf(e.getValue()));
            }
            subFilters = copy;
        }
    }

    /** name + value 단축 (default EQUAL). */
    public static FilterItem of(String name, String value) {
        return new FilterItem(name, value, null, QueryConditionType.EQUAL,
            null, null, null, null, null);
    }

    /** name + condition + value 단축. */
    public static FilterItem of(String name, QueryConditionType type, String value) {
        return new FilterItem(name, value, null, type, null, null, null, null, null);
    }

    /** name + condition + values 단축 (IN / BETWEEN). */
    public static FilterItem of(String name, QueryConditionType type, List<String> values) {
        return new FilterItem(name, null, values, type, null, null, null, null, null);
    }

    /** sub-filter 트리 단축. */
    public static FilterItem subTree(
        String name,
        QueryConditionType type,
        LinkedHashMap<LogicalOperator, List<FilterItem>> subFilters
    ) {
        return new FilterItem(name, null, null, type, null, subFilters, null, null, null);
    }

    /** {@link #subFilters} 가 채워졌는지 (leaf 여부 판정). */
    public boolean hasSubFilters() {
        return subFilters != null && !subFilters.isEmpty();
    }

    /** {@link #joinType} 만 갈아끼운 새 Records (immutability 자연). */
    public FilterItem withJoinType(JoinType type) {
        return new FilterItem(name, value, values, queryConditionType, not, subFilters,
            type, fieldType, jsonFilter);
    }

    /** {@link #queryConditionType} 만 갈아끼운 새 Records. */
    public FilterItem withQueryConditionType(QueryConditionType type) {
        return new FilterItem(name, value, values, type, not, subFilters,
            joinType, fieldType, jsonFilter);
    }

    /** {@link #name} 만 갈아끼운 새 Records (SearchFieldModifier 가 가상 필드 → 실제 필드 매핑 시 사용). */
    public FilterItem withName(String newName) {
        return new FilterItem(newName, value, values, queryConditionType, not, subFilters,
            joinType, fieldType, jsonFilter);
    }

    /** {@link #value} 만 갈아끼운 새 Records. */
    public FilterItem withValue(String newValue) {
        return new FilterItem(name, newValue, values, queryConditionType, not, subFilters,
            joinType, fieldType, jsonFilter);
    }
}
