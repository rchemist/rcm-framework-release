/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.search;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Entity metadata — 0.0.5 {@code RegisterEntityBeanDTO} 흡수 (청사진 §5.5.4). APT
 * {@code EntityMetadataProcessor} 가 entity 마다 컴파일 시점에 자동 생성하는 진실 원천.
 *
 * <p>{@code SearchRequestPlanner} 가 본 인터페이스 활용 — validateFilters / mappedJoinFilters /
 * columnFilters / jsonFilters 자동 분리, JPA Path/Join 자동 변환 (청사진 §5.5.5).
 *
 * <p>runtime reflection 0 — APT 가 generated source 로 적용, JIT 친화 + GraalVM native 호환 baseline.
 *
 * @param <T> entity class
 */
public interface EntityMetadata<T> {

  /** entity class. */
  Class<T> entityClass();

  /** entity simple name. */
  String entityName();

  /** 모든 필드 — APT 가 컴파일 시점에 적용. */
  List<FieldDescriptor<T, ?>> fields();

  /** 화이트리스트 안 필드 검색 — 미존재 = {@link Optional#empty()}. */
  Optional<FieldDescriptor<T, ?>> findField(String name);

  /** searchable 필드 이름 set — {@code SearchRequestPlanner} 가 화이트리스트 검증. */
  default Set<String> searchableFields() {
    Set<String> out = new LinkedHashSet<>();
    for (FieldDescriptor<T, ?> f : fields()) {
      if (f.searchable()) {
        out.add(f.name());
      }
    }
    return out;
  }

  /** sortable 필드 이름 set — {@code SortValidator} 가 화이트리스트 검증. */
  default Set<String> sortableFields() {
    Set<String> out = new LinkedHashSet<>();
    for (FieldDescriptor<T, ?> f : fields()) {
      if (f.sortable()) {
        out.add(f.name());
      }
    }
    return out;
  }

  /** indexed 필드 set — Phase 4 search engine 통합 영역. */
  default Set<String> indexFields() {
    Set<String> out = new LinkedHashSet<>();
    for (FieldDescriptor<T, ?> f : fields()) {
      if (f.indexed()) {
        out.add(f.name());
      }
    }
    return out;
  }

  /** JSON column 이름 set — {@code attributes} 같은 jsonb 컬럼 자동 인식. */
  default Set<String> jsonAttributes() {
    Set<String> out = new LinkedHashSet<>();
    for (FieldDescriptor<T, ?> f : fields()) {
      if (f.classification() == FilterClassification.JSON_ATTRIBUTE) {
        out.add(f.name());
      }
    }
    return out;
  }

  /** {@link FilterClassification} 자동 분류 — JSON path 가 prefix 매칭이라 별도 fallback. */
  default FilterClassification classify(String name) {
    if (name == null || name.isEmpty()) {
      return FilterClassification.UNKNOWN;
    }
    Optional<FieldDescriptor<T, ?>> exact = findField(name);
    if (exact.isPresent()) {
      return exact.get().classification();
    }
    int dot = name.indexOf('.');
    if (dot > 0) {
      String head = name.substring(0, dot);
      Optional<FieldDescriptor<T, ?>> jsonRoot = findField(head);
      if (jsonRoot.isPresent()
          && jsonRoot.get().classification() == FilterClassification.JSON_ATTRIBUTE) {
        return FilterClassification.JSON_ATTRIBUTE;
      }
      if (jsonRoot.isPresent()
          && jsonRoot.get().classification() == FilterClassification.MANY_TO_ONE) {
        return FilterClassification.MANY_TO_ONE;
      }
      if (jsonRoot.isPresent()
          && jsonRoot.get().classification() == FilterClassification.ONE_TO_MANY) {
        return FilterClassification.ONE_TO_MANY;
      }
      if (jsonRoot.isPresent()
          && jsonRoot.get().classification() == FilterClassification.EMBEDDED) {
        return FilterClassification.EMBEDDED;
      }
    }
    return FilterClassification.UNKNOWN;
  }

  /** {@code attributes.lang} 같은 JSON path 의 root 매칭 — 0.0.5 {@code isAttributeField} 흡수. */
  default boolean isJsonAttribute(String name) {
    if (name == null || name.isEmpty()) {
      return false;
    }
    int dot = name.indexOf('.');
    String head = dot > 0 ? name.substring(0, dot) : name;
    return findField(head)
        .map(f -> f.classification() == FilterClassification.JSON_ATTRIBUTE)
        .orElse(false);
  }

  /** JSON path 의 root field 반환 — 0.0.5 {@code isAttributeFieldName} 흡수. */
  default Optional<FieldDescriptor<T, ?>> findJsonField(String name) {
    if (name == null || name.isEmpty()) {
      return Optional.empty();
    }
    int dot = name.indexOf('.');
    String head = dot > 0 ? name.substring(0, dot) : name;
    Optional<FieldDescriptor<T, ?>> root = findField(head);
    if (root.isPresent()
        && root.get().classification() == FilterClassification.JSON_ATTRIBUTE) {
      return root;
    }
    return Optional.empty();
  }

  /** JSON column 존재 여부 — 0.0.5 {@code hasAttributeFields} 흡수. */
  default boolean hasJsonAttributes() {
    return !jsonAttributes().isEmpty();
  }
}
