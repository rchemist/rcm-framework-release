/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.io.Serializable;

/**
 * Result of a successful OTP issuance.
 *
 * <p>0.1.0 M2 generalization.
 */
public final class OtpIssueResult implements Serializable {

  private static final long serialVersionUID = 1L;

  private final OtpRecord record;
  private final boolean delivered;
  private final String deliveryReference;

  public OtpIssueResult(OtpRecord record, boolean delivered, String deliveryReference) {
    this.record = record;
    this.delivered = delivered;
    this.deliveryReference = deliveryReference;
  }

  public OtpRecord getRecord() {
    return record;
  }

  public boolean isDelivered() {
    return delivered;
  }

  public String getDeliveryReference() {
    return deliveryReference;
  }
}
