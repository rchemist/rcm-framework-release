/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

/**
 * SPI for delivering a generated OTP to the end-user through a specific
 * channel (SMS, email, push, etc).
 *
 * <p>Each {@code OtpChannel} bean declares its {@link #getType()} so the core
 * service can select the right one at issuance time. When multiple beans
 * declare the same type, the first one registered wins and the others are
 * ignored with a warning.
 *
 * <p>0.1.0 M2 generalization. Replaces the prior {@code
 * OnetimePasswordServiceExtensionHandler#sendMessage} coupling.
 */
public interface OtpChannel {

  /** The channel identifier this implementation handles (e.g. {@link OtpChannelType#SMS}). */
  String getType();

  /**
   * Deliver the OTP.
   *
   * @param request the original issuance request
   * @param record  the persisted record (includes code and expiry)
   * @return a delivery-specific reference (provider message id, tracking token, etc.) or {@code null}
   */
  String send(OtpIssueRequest request, OtpRecord record);
}
