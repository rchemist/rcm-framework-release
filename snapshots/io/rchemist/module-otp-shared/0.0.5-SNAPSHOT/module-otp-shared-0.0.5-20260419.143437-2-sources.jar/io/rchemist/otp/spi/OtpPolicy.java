/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.io.Serializable;
import java.time.Duration;
import java.util.Objects;

/**
 * Policy describing how an OTP is generated and when it expires.
 *
 * <p>Returned by {@link OtpPolicyProvider} and consumed by the OTP service at
 * issuance time. Immutable. All fields must be positive.
 */
public final class OtpPolicy implements Serializable {

  private static final long serialVersionUID = 1L;

  private final int codeLength;
  private final boolean digitsOnly;
  private final Duration expiration;
  private final int maxRetryCount;
  private final Duration retryWindow;

  public OtpPolicy(int codeLength, boolean digitsOnly, Duration expiration,
      int maxRetryCount, Duration retryWindow) {
    if (codeLength < 1) {
      throw new IllegalArgumentException("codeLength must be >= 1");
    }
    if (expiration == null || expiration.isZero() || expiration.isNegative()) {
      throw new IllegalArgumentException("expiration must be > 0");
    }
    if (maxRetryCount < 1) {
      throw new IllegalArgumentException("maxRetryCount must be >= 1");
    }
    if (retryWindow == null || retryWindow.isZero() || retryWindow.isNegative()) {
      throw new IllegalArgumentException("retryWindow must be > 0");
    }
    this.codeLength = codeLength;
    this.digitsOnly = digitsOnly;
    this.expiration = expiration;
    this.maxRetryCount = maxRetryCount;
    this.retryWindow = retryWindow;
  }

  public int getCodeLength() {
    return codeLength;
  }

  public boolean isDigitsOnly() {
    return digitsOnly;
  }

  public Duration getExpiration() {
    return expiration;
  }

  public int getMaxRetryCount() {
    return maxRetryCount;
  }

  public Duration getRetryWindow() {
    return retryWindow;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof OtpPolicy)) {
      return false;
    }
    OtpPolicy that = (OtpPolicy) o;
    return codeLength == that.codeLength
        && digitsOnly == that.digitsOnly
        && maxRetryCount == that.maxRetryCount
        && Objects.equals(expiration, that.expiration)
        && Objects.equals(retryWindow, that.retryWindow);
  }

  @Override
  public int hashCode() {
    return Objects.hash(codeLength, digitsOnly, expiration, maxRetryCount, retryWindow);
  }

  @Override
  public String toString() {
    return "OtpPolicy{codeLength=" + codeLength
        + ", digitsOnly=" + digitsOnly
        + ", expiration=" + expiration
        + ", maxRetryCount=" + maxRetryCount
        + ", retryWindow=" + retryWindow
        + '}';
  }
}
