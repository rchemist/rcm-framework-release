/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class OnetimePasswordErrorType extends EnumType<OnetimePasswordErrorType> implements ErrorType {

  public static final OnetimePasswordErrorType USER_ID_REQUIRED = new OnetimePasswordErrorType("USER_ID_REQUIRED", "USER ID 정보가 필요합니다.", "user.id.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType USER_NOT_FOUND = new OnetimePasswordErrorType("USER_NOT_FOUND", "USER가 존재하지 않습니다.", "user.not.found", HttpStatus.NOT_FOUND);
  public static final OnetimePasswordErrorType TARGET_REQUIRED = new OnetimePasswordErrorType("TARGET_REQUIRED", "OTP 수신자 정보가 필요합니다.", "target.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType ID_REQUIRED = new OnetimePasswordErrorType("ID_REQUIRED", "ID 정보가 필요합니다.", "id.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType OTP_REQUIRED = new OnetimePasswordErrorType("OTP_REQUIRED", "OTP 코드를 입력해야 합니다.", "otp.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType AUTH_TYPE_REQUIRED = new OnetimePasswordErrorType("AUTH_TYPE_REQUIRED", "권한 요청 정보가 필요합니다.", "auth.type.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType NOTIFICATION_TYPE_REQUIRED = new OnetimePasswordErrorType("NOTIFICATION_TYPE_REQUIRED", "메시지 유형을 지정해야 합니다.", "notification.type.required", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType OTP_NOT_FOUND = new OnetimePasswordErrorType("OTP_NOT_FOUND", "등록되지 않은 OTP 코드입니다.", "otp.not.found", HttpStatus.NOT_FOUND);
  public static final OnetimePasswordErrorType EXPIRED = new OnetimePasswordErrorType("EXPIRED", "만료된 OTP 코드입니다.", "expired", HttpStatus.BAD_REQUEST);
  public static final OnetimePasswordErrorType EXCEED_MAX_RETRY_COUNT = new OnetimePasswordErrorType("EXCEED_MAX_RETRY_COUNT", "요청 한도를 초과했습니다.", "exceed.max.retry.count", HttpStatus.FORBIDDEN);

  @Getter
  private final int status;

  public OnetimePasswordErrorType(String type, String description, String messageKey, HttpStatus status) {
    super(100, type, type, description, messageKey);
    this.status = status.value();
  }

  public OnetimePasswordErrorType() {
    this.status = 500;
  }
}
