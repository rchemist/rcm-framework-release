/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

/**
 * SPI returning the OTP policy for a given issuance context.
 *
 * <p>Consumers may register multiple beans to provide per-channel or per-purpose
 * policies. The default implementation reads global settings from {@code
 * platform.otp.*}.
 *
 * <p>0.1.0 M2 generalization.
 */
@FunctionalInterface
public interface OtpPolicyProvider {

  /**
   * Resolve the policy to apply when issuing an OTP.
   *
   * @param request the issuance request (non-null)
   * @return a non-null policy
   */
  OtpPolicy resolve(OtpIssueRequest request);
}
