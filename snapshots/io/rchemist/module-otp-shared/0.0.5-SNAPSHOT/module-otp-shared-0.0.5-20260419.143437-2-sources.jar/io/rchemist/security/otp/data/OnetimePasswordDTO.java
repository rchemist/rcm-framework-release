/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.data;

import io.rchemist.common.util.InstantUtil;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.io.Serializable;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OnetimePasswordDTO implements Serializable {

  protected String id;
  protected String userId;
  protected OnetimePasswordType type;
  protected String otpCode;
  protected Instant availableAt;
  protected Instant availableUntil;

  public OnetimePasswordDTO withId(String id) {
    this.id = id;
    return this;
  }

  public OnetimePasswordDTO withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public OnetimePasswordDTO withType(OnetimePasswordType type) {
    this.type = type;
    return this;
  }

  public OnetimePasswordDTO withOtpCode(String otpCode) {
    this.otpCode = otpCode;
    return this;
  }

  public OnetimePasswordDTO withAvailableAt(Instant availableAt) {
    this.availableAt = availableAt;
    return this;
  }

  public OnetimePasswordDTO withAvailableUntil(Instant availableUntil) {
    this.availableUntil = availableUntil;
    return this;
  }

  public boolean isAvailableNow(){
    return InstantUtil.isBetween(getAvailableAt(), getAvailableUntil());
  }

}
