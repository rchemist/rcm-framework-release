/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.io.Serializable;

/**
 * Result of an OTP verification attempt.
 *
 * <p>0.1.0 M2 generalization.
 */
public final class OtpVerifyResult implements Serializable {

  private static final long serialVersionUID = 1L;

  /** Reason codes for verification outcomes. */
  public enum Reason {
    VERIFIED,
    NOT_FOUND,
    EXPIRED,
    MISMATCH,
    ALREADY_CONSUMED,
    INACTIVE
  }

  private final boolean verified;
  private final Reason reason;
  private final OtpRecord record;

  public OtpVerifyResult(boolean verified, Reason reason, OtpRecord record) {
    this.verified = verified;
    this.reason = reason;
    this.record = record;
  }

  public boolean isVerified() {
    return verified;
  }

  public Reason getReason() {
    return reason;
  }

  public OtpRecord getRecord() {
    return record;
  }

  public static OtpVerifyResult verified(OtpRecord record) {
    return new OtpVerifyResult(true, Reason.VERIFIED, record);
  }

  public static OtpVerifyResult notFound() {
    return new OtpVerifyResult(false, Reason.NOT_FOUND, null);
  }

  public static OtpVerifyResult expired(OtpRecord record) {
    return new OtpVerifyResult(false, Reason.EXPIRED, record);
  }

  public static OtpVerifyResult mismatch(OtpRecord record) {
    return new OtpVerifyResult(false, Reason.MISMATCH, record);
  }

  public static OtpVerifyResult alreadyConsumed(OtpRecord record) {
    return new OtpVerifyResult(false, Reason.ALREADY_CONSUMED, record);
  }

  public static OtpVerifyResult inactive(OtpRecord record) {
    return new OtpVerifyResult(false, Reason.INACTIVE, record);
  }
}
