/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.util.List;
import java.util.Optional;

/**
 * SPI for OTP persistence.
 *
 * <p>Implementations are responsible only for storage concerns — issuance logic,
 * policy evaluation, and channel delivery live in the core service. The JPA
 * implementation ({@code JpaOtpStorage}) is wired by default when the
 * JPA-backed bean is on the classpath; otherwise the in-memory implementation
 * is used.
 *
 * <p>Implementations MUST be thread-safe. Implementations SHOULD purge records
 * older than the configured retention. {@link #consume(String)} MUST mark the
 * record as consumed atomically — a second call on the same id must return
 * empty (one-time property).
 *
 * <p>0.1.0 M2 generalization.
 */
public interface OtpStorage {

  /** Persist the given record. Returns the stored record (implementations may populate ids). */
  OtpRecord save(OtpRecord record);

  /** Find by primary id. */
  Optional<OtpRecord> findById(String id);

  /**
   * Return the most recent non-deactivated, non-consumed record for the
   * user+purpose tuple, or empty.
   *
   * <p>Contract: "active" here means the record has neither been explicitly
   * deactivated ({@link #deactivate(String)}) nor consumed
   * ({@link #consume(String)}). Expiration (time-window) filtering is NOT
   * required — the core service performs that check at verify time — so
   * implementations do not need to share a clock with the service.
   */
  Optional<OtpRecord> findActive(String tenantAlias, String userId, String purpose);

  /** Return all records for the user+purpose tuple regardless of state. */
  List<OtpRecord> findAll(String tenantAlias, String userId, String purpose);

  /**
   * Mark the record with the given id as consumed. Returns the updated record,
   * or empty when not found or already consumed. Implementations MUST make
   * this call atomic: two concurrent consumers of the same id must see only
   * one successful return.
   */
  Optional<OtpRecord> consume(String id);

  /** Mark the record as inactive (soft invalidation, still stored for audit). */
  Optional<OtpRecord> deactivate(String id);
}
