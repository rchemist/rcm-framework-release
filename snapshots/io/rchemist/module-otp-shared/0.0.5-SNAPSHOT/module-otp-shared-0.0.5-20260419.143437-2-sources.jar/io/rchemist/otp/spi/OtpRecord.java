/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * Storage-neutral representation of a persisted OTP.
 *
 * <p>Returned by {@link OtpStorage} reads. Immutable once constructed. A record
 * is considered {@code active} when it has not been consumed and has not
 * expired, and available when {@code availableAt <= now <= availableUntil}.
 *
 * <p>0.1.0 M2 generalization.
 */
public final class OtpRecord implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String id;
  private final String tenantAlias;
  private final String userId;
  private final String targetAddress;
  private final String purpose;
  private final String channelType;
  private final String code;
  private final Instant availableAt;
  private final Instant availableUntil;
  private final boolean active;
  private final boolean consumed;

  private OtpRecord(Builder b) {
    this.id = b.id;
    this.tenantAlias = b.tenantAlias;
    this.userId = b.userId;
    this.targetAddress = b.targetAddress;
    this.purpose = b.purpose;
    this.channelType = b.channelType;
    this.code = b.code;
    this.availableAt = b.availableAt;
    this.availableUntil = b.availableUntil;
    this.active = b.active;
    this.consumed = b.consumed;
  }

  public String getId() {
    return id;
  }

  public String getTenantAlias() {
    return tenantAlias;
  }

  public String getUserId() {
    return userId;
  }

  public String getTargetAddress() {
    return targetAddress;
  }

  public String getPurpose() {
    return purpose;
  }

  public String getChannelType() {
    return channelType;
  }

  public String getCode() {
    return code;
  }

  public Instant getAvailableAt() {
    return availableAt;
  }

  public Instant getAvailableUntil() {
    return availableUntil;
  }

  public boolean isActive() {
    return active;
  }

  public boolean isConsumed() {
    return consumed;
  }

  /** True when the record is active, not consumed, and the current instant lies in the availability window. */
  public boolean isAvailableAt(Instant now) {
    if (!active || consumed) {
      return false;
    }
    if (availableAt != null && now.isBefore(availableAt)) {
      return false;
    }
    if (availableUntil != null && now.isAfter(availableUntil)) {
      return false;
    }
    return true;
  }

  public Builder toBuilder() {
    return new Builder()
        .id(this.id)
        .tenantAlias(this.tenantAlias)
        .userId(this.userId)
        .targetAddress(this.targetAddress)
        .purpose(this.purpose)
        .channelType(this.channelType)
        .code(this.code)
        .availableAt(this.availableAt)
        .availableUntil(this.availableUntil)
        .active(this.active)
        .consumed(this.consumed);
  }

  public static Builder builder() {
    return new Builder();
  }

  public static final class Builder {
    private String id;
    private String tenantAlias;
    private String userId;
    private String targetAddress;
    private String purpose;
    private String channelType;
    private String code;
    private Instant availableAt;
    private Instant availableUntil;
    private boolean active = true;
    private boolean consumed = false;

    public Builder id(String id) { this.id = id; return this; }
    public Builder tenantAlias(String tenantAlias) { this.tenantAlias = tenantAlias; return this; }
    public Builder userId(String userId) { this.userId = userId; return this; }
    public Builder targetAddress(String targetAddress) { this.targetAddress = targetAddress; return this; }
    public Builder purpose(String purpose) { this.purpose = purpose; return this; }
    public Builder channelType(String channelType) { this.channelType = channelType; return this; }
    public Builder code(String code) { this.code = code; return this; }
    public Builder availableAt(Instant availableAt) { this.availableAt = availableAt; return this; }
    public Builder availableUntil(Instant availableUntil) { this.availableUntil = availableUntil; return this; }
    public Builder active(boolean active) { this.active = active; return this; }
    public Builder consumed(boolean consumed) { this.consumed = consumed; return this; }

    public OtpRecord build() {
      return new OtpRecord(this);
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof OtpRecord)) {
      return false;
    }
    OtpRecord that = (OtpRecord) o;
    return Objects.equals(id, that.id);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(id);
  }

  @Override
  public String toString() {
    return "OtpRecord{id=" + id
        + ", userId=" + userId
        + ", purpose=" + purpose
        + ", channelType=" + channelType
        + ", availableUntil=" + availableUntil
        + ", active=" + active
        + ", consumed=" + consumed
        + '}';
  }
}
