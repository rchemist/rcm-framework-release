/**
 * Channel/storage-neutral OTP SPI introduced in 0.1.0 M2.
 *
 * <p>Consumers integrate with this package rather than the legacy
 * {@code io.rchemist.security.otp.*} types. The legacy types are retained
 * as JPA-oriented adapters but delegate to the types declared here.
 *
 * <p>Entry point: {@link io.rchemist.otp.spi.OtpService}.
 *
 * <p>Extension points:
 * <ul>
 *   <li>{@link io.rchemist.otp.spi.OtpChannel} — delivery (SMS/Email/TOTP/Push)</li>
 *   <li>{@link io.rchemist.otp.spi.OtpStorage} — persistence (in-memory default, JPA optional)</li>
 *   <li>{@link io.rchemist.otp.spi.OtpPolicyProvider} — expiration + retry policy</li>
 *   <li>{@link io.rchemist.otp.spi.OtpCodeGenerator} — code generation (numeric default)</li>
 * </ul>
 *
 * <p>Reference: {@code documents/refactor/15b-0.1.0-m2-otp-generalization.md}.
 */
package io.rchemist.otp.spi;
