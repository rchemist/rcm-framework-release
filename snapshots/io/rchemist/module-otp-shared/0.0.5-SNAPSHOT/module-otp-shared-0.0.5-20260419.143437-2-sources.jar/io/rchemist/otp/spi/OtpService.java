/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.util.Optional;

/**
 * Channel/storage-neutral OTP service contract.
 *
 * <p>This is the primary entry-point introduced in 0.1.0 M2. The legacy
 * {@code OnetimePasswordManageService} remains as a thin JPA-oriented adapter
 * but delegates to this service for all policy + storage + channel concerns.
 *
 * <p>Contract:
 * <ul>
 *   <li>{@link #issue(OtpIssueRequest)} — deactivates any prior active record
 *       for the same tuple, generates a new code using the configured policy,
 *       persists it via the {@link OtpStorage}, and dispatches via the
 *       matching {@link OtpChannel}. Returns the new record in the result.</li>
 *   <li>{@link #verify(String, String)} — returns a {@link OtpVerifyResult} and
 *       MUST mark the record as consumed on a successful verification
 *       (one-time property). A second verify of the same id returns
 *       {@link OtpVerifyResult.Reason#ALREADY_CONSUMED}.</li>
 *   <li>{@link #findById(String)} — read-only lookup.</li>
 * </ul>
 */
public interface OtpService {

  /** Issue a new OTP. */
  OtpIssueResult issue(OtpIssueRequest request);

  /** Verify the supplied code against the record with the given id. Atomic consume on success. */
  OtpVerifyResult verify(String id, String code);

  /** Read the record without mutating state. */
  Optional<OtpRecord> findById(String id);
}
