/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

/**
 * Unchecked exception thrown by OTP core flows when a request is malformed
 * or a retry-rate policy is violated. Verification failures are reported via
 * {@link OtpVerifyResult} rather than thrown.
 *
 * <p>0.1.0 M2 generalization.
 */
public class OtpException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  /** Machine-readable reason codes. */
  public enum Reason {
    TARGET_REQUIRED,
    PURPOSE_REQUIRED,
    ID_REQUIRED,
    CODE_REQUIRED,
    CHANNEL_NOT_FOUND,
    EXCEED_MAX_RETRY_COUNT
  }

  private final Reason reason;

  public OtpException(Reason reason) {
    super(reason.name());
    this.reason = reason;
  }

  public OtpException(Reason reason, String message) {
    super(message);
    this.reason = reason;
  }

  public OtpException(Reason reason, String message, Throwable cause) {
    super(message, cause);
    this.reason = reason;
  }

  public Reason getReason() {
    return reason;
  }
}
