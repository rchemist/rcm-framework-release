/**
 * Legacy OTP shared types (pre-0.1.0). Retained as back-compat sidecars. The
 * channel/storage-neutral replacement lives at {@link io.rchemist.otp.spi}
 * (introduced by 0.1.0 M2).
 *
 * <p>See {@code documents/refactor/15b-0.1.0-m2-otp-generalization.md}.
 */
package io.rchemist.security.otp;
