/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.data;

import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.security.otp.service.exception.OnetimePasswordErrorType;
import io.rchemist.security.otp.service.exception.OnetimePasswordException;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Setter
@Getter
public class OtpRequest implements Serializable {

  // dont use
  private OtpRequest(){

  }

  public static OtpRequest createByUserId(String tenantAlias, String userId, OnetimePasswordType onetimePasswordType, NotificationType notificationType){
    OtpRequest request = new OtpRequest();
    request.setTenantAlias(tenantAlias);
    request.userId = userId;
    request.onetimePasswordType = onetimePasswordType;
    request.notificationType = notificationType;
    return request;
  }

  public static OtpRequest createByTargetAddress(String tenantAlias, String targetAddress, OnetimePasswordType onetimePasswordType, NotificationType notificationType){
    OtpRequest request = new OtpRequest();
    request.setTenantAlias(tenantAlias);
    request.targetAddress = targetAddress;
    request.onetimePasswordType = onetimePasswordType;
    request.notificationType = notificationType;
    return request;
  }

  protected String tenantAlias;

  protected String userId;

  protected String targetAddress;    // user 정보가 없다면 targetAddress 에 정보를 직접 넣는다.

  protected OnetimePasswordType onetimePasswordType;

  @Setter
  protected NotificationType notificationType;      // nullable

  public OtpRequest withNotificationType(
      NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }

  public boolean shouldSendMessage(){
    return notificationType != null;
  }

  public void validate() throws OnetimePasswordException {
    if(userId == null && targetAddress == null)
      throw new OnetimePasswordException(OnetimePasswordErrorType.TARGET_REQUIRED);
    if(onetimePasswordType == null)
      throw new OnetimePasswordException(OnetimePasswordErrorType.AUTH_TYPE_REQUIRED);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("userId", userId)
        .append("targetAddress", targetAddress)
        .append("onetimePasswordType", onetimePasswordType.getType())
        .append("notificationType", (notificationType == null) ? "" : notificationType.getType())
        .toString();
  }
}
