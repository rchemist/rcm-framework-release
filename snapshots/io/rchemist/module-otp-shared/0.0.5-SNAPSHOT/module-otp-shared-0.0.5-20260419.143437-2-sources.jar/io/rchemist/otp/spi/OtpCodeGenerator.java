/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

/**
 * SPI for generating the OTP code string.
 *
 * <p>Default implementation emits numeric codes of the configured length.
 * TOTP consumers can plug in an RFC 6238 implementation.
 *
 * <p>0.1.0 M2 generalization.
 */
@FunctionalInterface
public interface OtpCodeGenerator {

  /**
   * Generate a code for the given policy + issuance context.
   *
   * @param request the issuance request
   * @param policy  the resolved policy
   * @return a non-null, non-empty code string
   */
  String generate(OtpIssueRequest request, OtpPolicy policy);
}
