/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.spi;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Channel/storage-agnostic OTP issuance request.
 *
 * <p>Either {@link #getUserId()} or {@link #getTargetAddress()} must be populated
 * (validated by the core service). {@link #getPurpose()} is a caller-defined
 * string identifier (e.g. {@code FIND_USER}, {@code LOGIN_MFA}, {@code
 * PHONE_VERIFY}). {@link #getChannelType()} selects the delivery channel; when
 * null the {@code platform.otp.default-channel} setting applies.
 *
 * <p>0.1.0 M2 generalization — supersedes {@code OtpRequest} as the neutral
 * request shape. {@code OtpRequest} is retained for back-compat and converted
 * at the adapter boundary.
 */
public final class OtpIssueRequest implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String tenantAlias;
  private final String userId;
  private final String targetAddress;
  private final String purpose;
  private final String channelType;
  private final Map<String, Object> attributes;

  private OtpIssueRequest(Builder b) {
    this.tenantAlias = b.tenantAlias;
    this.userId = b.userId;
    this.targetAddress = b.targetAddress;
    this.purpose = b.purpose;
    this.channelType = b.channelType;
    this.attributes = b.attributes == null
        ? Collections.emptyMap()
        : Collections.unmodifiableMap(new HashMap<>(b.attributes));
  }

  public String getTenantAlias() {
    return tenantAlias;
  }

  public String getUserId() {
    return userId;
  }

  public String getTargetAddress() {
    return targetAddress;
  }

  public String getPurpose() {
    return purpose;
  }

  public String getChannelType() {
    return channelType;
  }

  public Map<String, Object> getAttributes() {
    return attributes;
  }

  /** True when at least one of user id / target address is set. */
  public boolean hasTarget() {
    return (userId != null && !userId.isEmpty())
        || (targetAddress != null && !targetAddress.isEmpty());
  }

  public static Builder builder() {
    return new Builder();
  }

  public static final class Builder {
    private String tenantAlias;
    private String userId;
    private String targetAddress;
    private String purpose;
    private String channelType;
    private Map<String, Object> attributes;

    public Builder tenantAlias(String tenantAlias) {
      this.tenantAlias = tenantAlias;
      return this;
    }

    public Builder userId(String userId) {
      this.userId = userId;
      return this;
    }

    public Builder targetAddress(String targetAddress) {
      this.targetAddress = targetAddress;
      return this;
    }

    public Builder purpose(String purpose) {
      this.purpose = purpose;
      return this;
    }

    public Builder channelType(String channelType) {
      this.channelType = channelType;
      return this;
    }

    public Builder attribute(String key, Object value) {
      if (this.attributes == null) {
        this.attributes = new HashMap<>();
      }
      this.attributes.put(key, value);
      return this;
    }

    public Builder attributes(Map<String, Object> values) {
      if (values != null) {
        if (this.attributes == null) {
          this.attributes = new HashMap<>();
        }
        this.attributes.putAll(values);
      }
      return this;
    }

    public OtpIssueRequest build() {
      return new OtpIssueRequest(this);
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof OtpIssueRequest)) {
      return false;
    }
    OtpIssueRequest that = (OtpIssueRequest) o;
    return Objects.equals(tenantAlias, that.tenantAlias)
        && Objects.equals(userId, that.userId)
        && Objects.equals(targetAddress, that.targetAddress)
        && Objects.equals(purpose, that.purpose)
        && Objects.equals(channelType, that.channelType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tenantAlias, userId, targetAddress, purpose, channelType);
  }

  @Override
  public String toString() {
    return "OtpIssueRequest{tenantAlias=" + tenantAlias
        + ", userId=" + userId
        + ", targetAddress=" + targetAddress
        + ", purpose=" + purpose
        + ", channelType=" + channelType
        + '}';
  }
}
