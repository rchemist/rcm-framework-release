/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.otp.spi;

/**
 * Channel type identifier for OTP delivery.
 *
 * <p>0.1.0 M2 generalization. Channel identifiers are string constants so that
 * consumers can introduce new channel types (e.g. {@code TOTP}, {@code PUSH},
 * {@code WEBAUTHN}) without modifying this module. The values below are the
 * built-in channel identifiers.
 */
public final class OtpChannelType {

  /** No-op channel. Logs issuance but performs no actual delivery. Default when no channel beans are configured. */
  public static final String NOOP = "NOOP";

  /** Short Message Service. */
  public static final String SMS = "SMS";

  /** Email delivery. */
  public static final String EMAIL = "EMAIL";

  /** Time-based one-time password (RFC 6238). */
  public static final String TOTP = "TOTP";

  /** Push notification. */
  public static final String PUSH = "PUSH";

  private OtpChannelType() {
    // no instances
  }
}
