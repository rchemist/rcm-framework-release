/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.notification.service.type.NotificationTemplateType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class OnetimePasswordType extends EnumType<OnetimePasswordType> {

  // 임시 확인용 - 일반적인 의미의 OTP
  public static final OnetimePasswordType ONETIME_PASSWORD = new OnetimePasswordType(1, "ONETIME_PASSWORD", "Onetime password", "onetime.password", NotificationTemplateType.ONE_TIME_PASSWORD, false);

  // Admin / Customer 로그인 정보 찾기
  public static final OnetimePasswordType FIND_CUSTOMER = new OnetimePasswordType(2, "FIND_USER", "Find user credentials", "find.user", NotificationTemplateType.USER_FIND_ID_OR_PASSWORD, true);
  public static final OnetimePasswordType FIND_ADMIN = new OnetimePasswordType(3, "FIND_ADMIN", "Find Admin credentials", "find.admin", NotificationTemplateType.ADMIN_FIND_ID_OR_PASSWORD, true);

  @Getter
  public NotificationTemplateType notificationTemplateType = NotificationTemplateType.ONE_TIME_PASSWORD;

  @Getter
  public boolean requestCredentials = false;

  public OnetimePasswordType(int order, String type, String friendlyType,
      String messageKey, NotificationTemplateType notificationTemplateType, boolean requestCredentials) {
    super(order, type, friendlyType, friendlyType, messageKey);
    this.notificationTemplateType = notificationTemplateType;
    this.requestCredentials = requestCredentials;
  }

  public OnetimePasswordType() {
  }
}
