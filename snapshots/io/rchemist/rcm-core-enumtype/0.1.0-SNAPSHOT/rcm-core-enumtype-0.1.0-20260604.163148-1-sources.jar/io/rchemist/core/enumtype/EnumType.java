/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 확장 가능한 enum-like abstract base — Java enum 의 *확장 불가 / Jackson 직렬화 ordinal 기본* 한계 해소.
 *
 * <p>Decision #25 정합 — 0.0.5 의 {@code EnumType<T extends EnumType<T>>} 패턴 그대로 흡수. Consumer 가
 * {@code class XxxServiceErrorType extends EnumType<XxxServiceErrorType> implements ErrorType} 형태로
 * 사용. {@link io.rchemist.core.enumtype.EnumTypeUserType} (Hibernate 7) + Jackson Serializer/Deserializer
 * 와 짝.
 *
 * <p>구현 패턴 — Consumer 가 정적 상수로 instance 선언:
 * <pre>{@code
 * public final class StaffStatus extends EnumType<StaffStatus> {
 *     public static final StaffStatus ACTIVE   = new StaffStatus("ACTIVE",   "활성");
 *     public static final StaffStatus INACTIVE = new StaffStatus("INACTIVE", "비활성");
 *     private StaffStatus(String name, String description) { super(name, description); }
 * }
 * }</pre>
 *
 * <p>인스턴스는 생성 시점에 {@link #INSTANCES} 에 자동 등록되므로 클래스 init (e.g.
 * {@code StaffStatus.ACTIVE} 참조) 1 회로 전체 lookup 가능. 나중에 추가된 인스턴스도 자동 누적.
 *
 * @param <T> Self-bound — 구현체 타입 자체
 **/
public abstract class EnumType<T extends EnumType<T>> {

    private static final Map<Class<?>, Map<String, EnumType<?>>> INSTANCES = new ConcurrentHashMap<>();

    private final String name;
    private final String description;

    protected EnumType(String name) {
        this(name, name);
    }

    protected EnumType(String name, String description) {
        this.name = Objects.requireNonNull(name, "EnumType.name 은 null 불허");
        this.description = description == null ? name : description;
        register();
    }

    @SuppressWarnings("unchecked")
    private void register() {
        INSTANCES.computeIfAbsent(getClass(), k -> Collections.synchronizedMap(new LinkedHashMap<>()))
                .put(name, this);
    }

    public final String name() {
        return name;
    }

    public String description() {
        return description;
    }

    /**
     * i18n MessageSource lookup 키. default = {@link #name()}. Consumer override 가능.
     */
    public String messageKey() {
        return name;
    }

    /**
     * 이름으로 instance 찾기. 못 찾으면 {@code defaultValue} 반환 (null 도 허용).
     *
     * <p>구현체 클래스가 한 번도 init 되지 않은 상태라면 {@link #INSTANCES} 에 등록 자체가 안 됐을 수 있음 —
     * 이때는 {@link Class#forName(String)} 등으로 강제 init 또는 {@link #values(Class)} 호출 전 명시 init 필요.
     */
    @SuppressWarnings("unchecked")
    public static <T extends EnumType<T>> T getInstance(Class<T> type, String name, T defaultValue) {
        if (type == null || name == null) {
            return defaultValue;
        }
        forceInit(type);
        Map<String, EnumType<?>> bucket = INSTANCES.get(type);
        if (bucket == null) {
            return defaultValue;
        }
        EnumType<?> hit = bucket.get(name);
        return hit == null ? defaultValue : (T) hit;
    }

    /**
     * 이름으로 instance 찾기. 못 찾으면 {@link IllegalArgumentException} (Fail loud, charter §1 원칙 5).
     */
    public static <T extends EnumType<T>> T valueOf(Class<T> type, String name) {
        T hit = getInstance(type, name, null);
        if (hit == null) {
            throw new IllegalArgumentException("Unknown EnumType instance: " + type.getName() + "." + name);
        }
        return hit;
    }

    /**
     * 등록된 모든 instance — 등록 순서 (LinkedHashMap) 보존.
     */
    @SuppressWarnings("unchecked")
    public static <T extends EnumType<T>> List<T> values(Class<T> type) {
        if (type == null) {
            return List.of();
        }
        forceInit(type);
        Map<String, EnumType<?>> bucket = INSTANCES.get(type);
        if (bucket == null) {
            return List.of();
        }
        synchronized (bucket) {
            return List.copyOf((List<T>) List.copyOf(bucket.values()));
        }
    }

    private static void forceInit(Class<?> type) {
        try {
            Class.forName(type.getName(), true, type.getClassLoader());
        }
        catch (ClassNotFoundException e) {
            // 동일 ClassLoader 의 reflective lookup — 실제로 throw 안 남.
            throw new IllegalStateException("Cannot init " + type.getName(), e);
        }
    }

    @Override
    public final boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return name.equals(((EnumType<?>) o).name);
    }

    @Override
    public final int hashCode() {
        return Objects.hash(getClass(), name);
    }

    @Override
    public final String toString() {
        return name;
    }
}
