/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype;

import com.fasterxml.jackson.annotation.JsonFormat;
import tools.jackson.databind.BeanDescription;
import tools.jackson.databind.DeserializationConfig;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.SerializationConfig;
import tools.jackson.databind.ValueDeserializer;
import tools.jackson.databind.ValueSerializer;
import tools.jackson.databind.deser.Deserializers;
import tools.jackson.databind.module.SimpleModule;
import tools.jackson.databind.ser.Serializers;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Jackson 3 module — {@link EnumType} 추상 base 의 *모든 하위 타입* 에 대해 단일
 * {@link EnumTypeJsonSerializer} / {@link EnumTypeJsonDeserializer} 자동 매칭.
 *
 * <p>표준 {@link SimpleModule#addSerializer} / {@link SimpleModule#addDeserializer} 는 *exact-match*
 * 라 Consumer 의 구체 EnumType 하위 (예: {@code PaymentStatus}) 가 자동 hit 안 됨. 본 module 은 SPI
 * {@link Serializers} / {@link Deserializers} 를 직접 구현해 *base type {@link EnumType} 의 모든 하위 타입*
 * 을 단일 serializer/deserializer 로 dispatch.
 *
 * <p>Decision #25 — Consumer 가 정적 상수 추가만으로 새 EnumType 인스턴스를 등록하면 Jackson 측은
 * 자동 직렬화. ObjectMapper 별도 register 불필요.
 **/
public class EnumTypeJacksonModule extends SimpleModule {

    private static final long serialVersionUID = 1L;

    public EnumTypeJacksonModule() {
        super("EnumTypeJacksonModule");
    }

    @Override
    public void setupModule(SetupContext context) {
        super.setupModule(context);
        context.addSerializers(new EnumTypeSerializers());
        context.addDeserializers(new EnumTypeDeserializers());
    }

    private static final class EnumTypeSerializers extends Serializers.Base {
        private final EnumTypeJsonSerializer serializer = new EnumTypeJsonSerializer();

        @Override
        public ValueSerializer<?> findSerializer(SerializationConfig config, JavaType type,
                                                 BeanDescription.Supplier beanDescRef,
                                                 JsonFormat.Value formatOverrides) {
            if (type != null && EnumType.class.isAssignableFrom(type.getRawClass())) {
                return serializer;
            }
            return null;
        }
    }

    private static final class EnumTypeDeserializers extends Deserializers.Base {
        @Override
        public ValueDeserializer<?> findBeanDeserializer(JavaType type, DeserializationConfig config,
                                                         BeanDescription.Supplier beanDescRef) {
            if (type != null && EnumType.class.isAssignableFrom(type.getRawClass())) {
                return new EnumTypeJsonDeserializer();
            }
            return null;
        }

        @Override
        public boolean hasDeserializerFor(DeserializationConfig config, Class<?> valueType) {
            return valueType != null && EnumType.class.isAssignableFrom(valueType);
        }
    }
}
