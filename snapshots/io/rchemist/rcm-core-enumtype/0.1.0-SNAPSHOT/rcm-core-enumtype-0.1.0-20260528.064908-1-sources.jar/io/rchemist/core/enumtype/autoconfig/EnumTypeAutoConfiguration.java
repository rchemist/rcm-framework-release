/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype.autoconfig;

import io.rchemist.core.enumtype.EnumTypeJacksonModule;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import tools.jackson.databind.JacksonModule;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * EnumType autoconfig (Decision #25) — {@link EnumTypeJacksonModule} 를 Spring Boot 4 Jackson
 * auto-config 에 자동 등록.
 *
 * <p>{@link EnumTypeJacksonModule} 가 SPI ({@link tools.jackson.databind.ser.Serializers} /
 * {@link tools.jackson.databind.deser.Deserializers}) 로 모든 {@link io.rchemist.core.enumtype.EnumType}
 * 하위 타입을 *base 단일 serializer/deserializer* 로 dispatch — Consumer 가 새 정적 상수만 추가하면
 * 자동 직렬화. base package 와 무관.
 *
 * <p>Spring Boot Jackson auto-config 가 모든 {@link JacksonModule} bean 을 ObjectMapper 에 자동 register.
 **/
@AutoConfiguration
@ConditionalOnClass(name = "tools.jackson.databind.ValueSerializer")
public class EnumTypeAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean(name = "enumTypeJacksonModule")
  JacksonModule enumTypeJacksonModule() {
    return new EnumTypeJacksonModule();
  }
}
