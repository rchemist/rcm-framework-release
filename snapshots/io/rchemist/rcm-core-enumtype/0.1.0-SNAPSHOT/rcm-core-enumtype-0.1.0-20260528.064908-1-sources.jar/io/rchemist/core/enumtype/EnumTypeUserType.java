/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Objects;
import java.util.Properties;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Hibernate 7 {@link UserType} — {@link EnumType} 인스턴스를 DB VARCHAR (= {@link EnumType#name()}) 로 저장.
 *
 * <p>Decision #25 정합 — JPA 표준 {@code @Enumerated(EnumType.STRING)} 은 *Java enum 전용*. 본 UserType 은
 * *EnumType 추상 클래스 (확장 가능)* 영역. Consumer entity 영역에서:
 * <pre>{@code
 * @Type(value = EnumTypeUserType.class, parameters = @Parameter(name = "enumClass", value = "..."))
 * private StaffStatus status;
 * }</pre>
 **/
@SuppressWarnings("rawtypes")
public class EnumTypeUserType implements UserType<EnumType>, ParameterizedType {

    public static final String PARAM_ENUM_CLASS = "enumClass";

    private Class<? extends EnumType> enumClass;

    @Override
    public void setParameterValues(Properties parameters) {
        Objects.requireNonNull(parameters, "EnumTypeUserType parameters 누락");
        String className = parameters.getProperty(PARAM_ENUM_CLASS);
        if (className == null || className.isBlank()) {
            throw new IllegalArgumentException(
                    "EnumTypeUserType: " + PARAM_ENUM_CLASS + " parameter 가 필요합니다.");
        }
        try {
            Class<?> clazz = Class.forName(className, true, Thread.currentThread().getContextClassLoader());
            if (!EnumType.class.isAssignableFrom(clazz)) {
                throw new IllegalArgumentException(
                        "EnumTypeUserType: " + className + " 은 EnumType 의 하위 타입이 아닙니다.");
            }
            @SuppressWarnings("unchecked")
            Class<? extends EnumType> casted = (Class<? extends EnumType>) clazz;
            this.enumClass = casted;
        }
        catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("EnumTypeUserType: 클래스 미발견 " + className, e);
        }
    }

    @Override
    public int getSqlType() {
        return Types.VARCHAR;
    }

    @Override
    public Class<EnumType> returnedClass() {
        return EnumType.class;
    }

    @Override
    public boolean equals(EnumType x, EnumType y) {
        return Objects.equals(x, y);
    }

    @Override
    public int hashCode(EnumType x) {
        return x == null ? 0 : x.hashCode();
    }

    @Override
    @SuppressWarnings("unchecked")
    public EnumType nullSafeGet(ResultSet rs, int position, WrapperOptions options) throws SQLException {
        String name = rs.getString(position);
        if (name == null || rs.wasNull()) {
            return null;
        }
        return EnumType.getInstance((Class) enumClass, name, null);
    }

    @Override
    public void nullSafeSet(PreparedStatement st, EnumType value, int index, WrapperOptions options)
            throws SQLException {
        if (value == null) {
            st.setNull(index, Types.VARCHAR);
        }
        else {
            st.setString(index, value.name());
        }
    }

    @Override
    public EnumType deepCopy(EnumType value) {
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(EnumType value) {
        return value == null ? null : value.name();
    }

    @Override
    @SuppressWarnings("unchecked")
    public EnumType assemble(Serializable cached, Object owner) {
        if (cached == null) {
            return null;
        }
        return EnumType.getInstance((Class) enumClass, (String) cached, null);
    }

    @Override
    public EnumType replace(EnumType detached, EnumType managed, Object owner) {
        return detached;
    }

    Class<? extends EnumType> getEnumClass() {
        return enumClass;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EnumTypeUserType other)) {
            return false;
        }
        return Objects.equals(enumClass, other.enumClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(enumClass);
    }
}
