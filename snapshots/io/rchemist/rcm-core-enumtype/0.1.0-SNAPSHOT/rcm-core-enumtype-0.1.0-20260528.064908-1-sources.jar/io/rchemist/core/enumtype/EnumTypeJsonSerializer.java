/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype;

import org.springframework.boot.jackson.JacksonComponent;
import tools.jackson.core.JacksonException;
import tools.jackson.core.JsonGenerator;
import tools.jackson.databind.SerializationContext;
import tools.jackson.databind.ValueSerializer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Jackson 3 ValueSerializer — {@link EnumType} 인스턴스를 {@code "name()"} JSON String 으로 직렬화.
 *
 * <p>Decision #25 정합 — JPA 표준 enum 의 *ordinal default* 영구 회피. {@link JacksonComponent} (Spring
 * Boot 4 — 3.x 의 {@code @JsonComponent} 이름 갱신) 가 Spring Boot Jackson auto-config 에 자동 등록.
 * Consumer base package 가 {@code io.rchemist.core.enumtype} 와 다른 경우는
 * {@link io.rchemist.core.enumtype.autoconfig.EnumTypeAutoConfiguration} 의 Jackson Module bean 으로 정합.
 *
 * <p>Spring Boot 4 = Jackson 3 ({@code tools.jackson.databind}) — Jackson 2 ({@code com.fasterxml.jackson.*})
 * 와 패키지 분리.
 **/
@JacksonComponent
public class EnumTypeJsonSerializer extends ValueSerializer<EnumType<?>> {

    @Override
    public void serialize(EnumType<?> value, JsonGenerator gen, SerializationContext ctxt)
            throws JacksonException {
        if (value == null) {
            gen.writeNull();
        }
        else {
            gen.writeString(value.name());
        }
    }

    @Override
    public Class<?> handledType() {
        return EnumType.class;
    }
}
