/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.enumtype;

import org.springframework.boot.jackson.JacksonComponent;
import tools.jackson.core.JacksonException;
import tools.jackson.core.JsonParser;
import tools.jackson.databind.BeanProperty;
import tools.jackson.databind.DatabindException;
import tools.jackson.databind.DeserializationContext;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.ValueDeserializer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Jackson 3 ValueDeserializer — JSON String → {@link EnumType} 인스턴스 lookup.
 *
 * <p>Decision #25 정합 — Jackson 3 의 {@link ValueDeserializer#createContextual} 로 target field 의
 * 구체 타입을 해상. lookup 결과 못 찾으면 {@link DatabindException} (Fail loud, charter §1 원칙 5).
 *
 * <p>Spring Boot 4 = Jackson 3 ({@code tools.jackson.databind}) — Jackson 2 와 패키지 분리.
 **/
@JacksonComponent
public class EnumTypeJsonDeserializer extends ValueDeserializer<EnumType<?>> {

    private final Class<? extends EnumType> enumClass;

    public EnumTypeJsonDeserializer() {
        this(null);
    }

    private EnumTypeJsonDeserializer(Class<? extends EnumType> enumClass) {
        this.enumClass = enumClass;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public ValueDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) {
        JavaType type = property == null ? ctxt.getContextualType() : property.getType();
        Class<?> raw = type == null ? null : type.getRawClass();
        if (raw == null || !EnumType.class.isAssignableFrom(raw)) {
            throw DatabindException.from(ctxt,
                    "EnumTypeJsonDeserializer: target type 이 EnumType 의 하위가 아닙니다: " + raw);
        }
        return new EnumTypeJsonDeserializer((Class<? extends EnumType>) raw);
    }

    @Override
    public EnumType<?> deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException {
        String name = p.getValueAsString();
        if (name == null || name.isBlank()) {
            return null;
        }
        if (enumClass == null) {
            throw DatabindException.from(ctxt,
                    "EnumTypeJsonDeserializer: enumClass 미해상 (createContextual 미호출).");
        }
        @SuppressWarnings({"rawtypes", "unchecked"})
        EnumType hit = EnumType.getInstance((Class) enumClass, name, null);
        if (hit == null) {
            throw DatabindException.from(ctxt,
                    "Unknown EnumType instance: " + enumClass.getName() + "." + name);
        }
        return hit;
    }
}
