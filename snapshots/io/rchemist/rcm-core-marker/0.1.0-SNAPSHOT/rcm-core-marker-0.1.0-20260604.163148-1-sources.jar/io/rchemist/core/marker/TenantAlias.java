/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.marker;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Multitenant marker — entity 의 tenantId 노출. Hibernate 7 {@code @TenantId} 어노테이션을
 * entity 의 tenant 필드에 부착하면 framework 가 SELECT/UPDATE/DELETE 시 자동으로
 * {@code WHERE tenant_id = :resolvedTenantId} 를 덧붙임 (DISCRIMINATOR 전략 default).
 *
 * <p><b>Singleton seed row 패턴 (전역 default policy)</b> — 모든 tenant 가 공유하는 단일
 * default row (예: {@code T_RECOMMENDATION_POLICY}, {@code T_AUTO_GRADING_POLICY}) 는
 * 반드시 {@code TENANT_ID = '__system__'} 로 적재해야 함
 * ({@code TenantContext.SYSTEM_TENANT_ID} 상수 정합 — {@code rcm-core-context} 모듈).
 *
 * <pre>{@code
 * // 1) seed row 적재 (Flyway / data initializer)
 * INSERT INTO T_RECOMMENDATION_POLICY (id, tenant_id, ...) VALUES (1, '__system__', ...);
 *
 * // 2) seed 조회/upsert — TenantContext.callAsSystem / runAsSystem 으로 wrap
 * RecommendationPolicy policy = TenantContext.callAsSystem(() ->
 *     repository.findById(SEED_POLICY_ID).orElseThrow());
 * }</pre>
 *
 * <p>{@code TENANT_ID = NULL} 적재 금지 — resolver 가 항상 비-null 문자열을 반환하므로
 * ({@code TenantContext} 미바인딩 시 {@code SYSTEM_TENANT_ID} fallback) Hibernate 자동 필터의
 * {@code resolvedTenantId} 가 NULL 과 매칭되지 않아 SELECT 가 0 rows 반환하고 후속 upsert 가
 * PK/UK 충돌을 일으킴. 자세한 사용 패턴은 {@code documents/24-consumer-migration-guide.md} §4.3 참고.
 **/
public interface TenantAlias {

    String getTenantId();
}
