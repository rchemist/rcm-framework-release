/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.marker.dbschema;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 단일 entity field 의 DB schema 메타 — Phase 0.1.0 GA Gate T0-7 (Decision #14 보강) 신규.
 *
 * <p>{@link DbSpec} 의 {@code fields()} list element. APT {@code DbSpecProcessor} 가 컴파일 시점에
 * 모든 영역 추출 (jakarta.persistence + Hibernate {@code @Comment} 표준).
 *
 * <p>도메인 서술은 {@code @Comment} 단일 영역 — DDL {@code COMMENT ON COLUMN} 자동 + 본 record 의
 * {@code comment} field 자동 매핑. UI / form 메타데이터 (friendlyName / tooltip / helpText) 는
 * {@link io.rchemist.starter.document.dbschema.AdminField} 별개 영역.
 *
 * @param fieldName    Java 필드명 (e.g. {@code "createdAt"})
 * @param columnName   DB 컬럼명 ({@code @Column(name)} or 자연 변환, e.g. {@code "created_at"})
 * @param javaType     Java 타입 FQN (e.g. {@code "java.time.Instant"})
 * @param sqlType      DB 타입 (자연 추론, e.g. {@code "TIMESTAMP"} / {@code "VARCHAR"} / {@code "BIGINT"})
 *                     — null 가능 (자연 추론 실패 시)
 * @param length       {@code @Column(length)} 또는 -1 (적용 없음)
 * @param nullable     {@code @Column(nullable)} default true
 * @param primaryKey   {@code @Id} 부착 여부
 * @param comment      {@code @Comment} (Hibernate) 의 value, null 가능
 */
public record DbFieldSpec(
    String fieldName,
    String columnName,
    String javaType,
    String sqlType,
    int length,
    boolean nullable,
    boolean primaryKey,
    String comment
) {
}
