/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.marker.dbschema;

import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Entity 의 DB schema 메타 SPI — Phase 0.1.0 GA Gate T0-7 (Decision #14 보강) 신규. 0.0.5 의
 * {@code TableAnalyzeProvider} 흡수 — runtime 의 reflection-based 영역을 compile-time APT 로 옮김.
 *
 * <p>APT {@code DbSpecProcessor} 가 컴파일 시점에 entity 마다 {@code {Entity}_DbSpec implements
 * DbSpec<{Entity}>} 자동 생성. {@code starter-document} 가 본 SPI 활용해 AsciiDoctor / Markdown DB
 * schema docs 자동 생성.
 *
 * <p>도메인 서술 영역은 {@code @Comment} (Hibernate) 단일 — DDL {@code COMMENT ON ...} 자동 +
 * APT 가 본 SPI 의 comment field 자동 채움. {@code starter-document} 의 {@code @AdminField}
 * (frontend admin UI metadata) 는 별개 영역.
 *
 * @param <E> entity 타입
 */
public interface DbSpec<E> {

  /** 매핑된 entity Class. */
  Class<E> entityClass();

  /** entity 단순 이름 (e.g. {@code "Article"}). */
  String entityName();

  /** DB table 이름 ({@code @Table(name)} or 자연 변환). */
  String tableName();

  /** {@code @Comment} (Hibernate) table-level comment, null 가능. */
  String tableComment();

  /** 모든 field 메타 — 선언 순서 그대로 (LinkedHashMap 정합). */
  List<DbFieldSpec> fields();

  /** 이름으로 field lookup. */
  default Optional<DbFieldSpec> findField(String name) {
    for (DbFieldSpec f : fields()) {
      if (f.fieldName().equals(name)) {
        return Optional.of(f);
      }
    }
    return Optional.empty();
  }

  /** primary key field list (보통 1 개, composite 시 N 개). */
  default List<DbFieldSpec> primaryKeys() {
    return fields().stream().filter(DbFieldSpec::primaryKey).toList();
  }
}
