/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.marker;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 외부 검색엔진(Elasticsearch / Solr 등) 색인 대상 marker — denormalized index 패턴.
 *
 * <p>{@link Searchable} 과 차이: Searchable = DB LIKE/EQ 검색 (universal SearchRequest 진입),
 * Indexable = 외부 검색엔진 색인 (EntityIndexer SPI 진입). 둘 다 동시에 부착 가능 (예:
 * ArticleSearchIndex implements Searchable, Indexable — DB fallback + ES primary).
 *
 * <p>실제 색인 동작은 {@code rcm-starter-search-elasticsearch} (옵션 starter) 가 등록한
 * EntityIndexer 가 담당. Marker 만 의존 = consumer 의 core 모듈은 ES 의존 X (지연 결합).
 **/
public interface Indexable {
}
