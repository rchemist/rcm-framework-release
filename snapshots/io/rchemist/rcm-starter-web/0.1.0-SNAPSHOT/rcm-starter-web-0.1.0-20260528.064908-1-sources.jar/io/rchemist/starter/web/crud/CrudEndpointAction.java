/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpMethod;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — {@link AbstractCrudController} 8 endpoint + 1 discovery 의 PDP action enum.
 * {@link DefaultAccessRoute} 자동 매핑 시 (HTTP method + path 의 마지막 segment) 영역으로 derive.
 *
 * <p>action 명 = PDP {@code (resource, action)} pair 의 action 부분. 매트릭스:
 * <ul>
 *   <li>{@code POST}   + base               → {@link #CREATE}     ("create")</li>
 *   <li>{@code GET}    + base               → {@link #LIST}       ("list")</li>
 *   <li>{@code POST}   + {@code /search}    → {@link #SEARCH}     ("search")</li>
 *   <li>{@code POST}   + {@code /count}     → {@link #COUNT}      ("count")</li>
 *   <li>{@code GET}    + {@code /{id}}      → {@link #READ}       ("read")</li>
 *   <li>{@code PUT}    + {@code /{id}}      → {@link #UPDATE}     ("update")</li>
 *   <li>{@code DELETE} + {@code /{id}}      → {@link #DELETE}     ("delete")</li>
 *   <li>{@code DELETE} + base               → {@link #BULK_DELETE} ("bulkDelete")</li>
 *   <li>{@code GET}    + {@code /search/schema} → {@link #SEARCH_SCHEMA} ("searchSchema")</li>
 * </ul>
 *
 * <p>path 의 *마지막 의미 segment* 만 본다 — consumer 의 {@code @RequestMapping("/api/v1/articles")}
 * 의 prefix 는 무관, {@link AbstractCrudController} 메소드의 {@code @PostMapping("/search")} 같은
 * 메소드 레벨 path 만 본다.
 **/
public enum CrudEndpointAction {

  /** {@code POST /} — create. */
  CREATE("create"),
  /** {@code GET /} — 단순 목록. */
  LIST("list"),
  /** {@code POST /search} — 고급 검색. */
  SEARCH("search"),
  /** {@code POST /count} — 검색 조건 만족 count. */
  COUNT("count"),
  /** {@code GET /{id}} — find by id. */
  READ("read"),
  /** {@code PUT /{id}} — update. */
  UPDATE("update"),
  /** {@code DELETE /{id}} — single delete. */
  DELETE("delete"),
  /** {@code DELETE /} — bulk delete (RFC 9110 정합, body). */
  BULK_DELETE("bulkDelete"),
  /** {@code GET /search/schema} — schema discovery. */
  SEARCH_SCHEMA("searchSchema");

  private final String actionName;

  CrudEndpointAction(String actionName) {
    this.actionName = actionName;
  }

  /**
   * PDP {@code (resource, action)} pair 의 action 문자열.
   *
   * @return action 문자열 (예: {@code create} / {@code list})
   */
  public String actionName() {
    return actionName;
  }

  /**
   * (HTTP method, 메소드 레벨 path) → 매트릭스 lookup. 매칭 없으면 {@link Optional#empty()} 반환 →
   * 호출 advice 가 *자동 매핑 안 함 (no-op)*. method 가 multi-mapped 인 경우 (드물지만 Spring 표준
   * 허용) 첫 매칭 본다 — baseline 은 단일.
   *
   * <p>본 helper 는 path 의 정확 매칭만 본다 — `/` (empty), `/search`, `/count`, `/{id}`,
   * `/search/schema` 5 종. consumer 가 {@link AbstractCrudController} 의 8 endpoint 외 별도
   * endpoint 를 controller 에 추가한 경우 = no-op (consumer 가 명시 {@code @AccessRoute} 부착하면
   * 그쪽 우선 영역).
   *
   * @param httpMethod  HTTP method (POST / GET / PUT / DELETE)
   * @param methodPaths 메소드 레벨 {@code @RequestMapping#path} 영역 (보통 1 개, 비어 있으면 base
   *                    {@code /} 동등)
   * @return 매트릭스 매칭 시 {@link CrudEndpointAction}, 아니면 empty
   */
  public static Optional<CrudEndpointAction> resolve(
      HttpMethod httpMethod, List<String> methodPaths) {
    if (httpMethod == null) {
      return Optional.empty();
    }
    String path = normalizePath(methodPaths);
    boolean isBase = path.isEmpty() || "/".equals(path);

    if (HttpMethod.POST.equals(httpMethod)) {
      if (isBase) {
        return Optional.of(CREATE);
      }
      if ("/search".equals(path)) {
        return Optional.of(SEARCH);
      }
      if ("/count".equals(path)) {
        return Optional.of(COUNT);
      }
      return Optional.empty();
    }

    if (HttpMethod.GET.equals(httpMethod)) {
      if (isBase) {
        return Optional.of(LIST);
      }
      if ("/{id}".equals(path)) {
        return Optional.of(READ);
      }
      if ("/search/schema".equals(path)) {
        return Optional.of(SEARCH_SCHEMA);
      }
      return Optional.empty();
    }

    if (HttpMethod.PUT.equals(httpMethod)) {
      if ("/{id}".equals(path)) {
        return Optional.of(UPDATE);
      }
      return Optional.empty();
    }

    if (HttpMethod.DELETE.equals(httpMethod)) {
      if (isBase) {
        return Optional.of(BULK_DELETE);
      }
      if ("/{id}".equals(path)) {
        return Optional.of(DELETE);
      }
      return Optional.empty();
    }

    return Optional.empty();
  }

  private static String normalizePath(List<String> methodPaths) {
    if (methodPaths == null || methodPaths.isEmpty()) {
      return "";
    }
    String first = methodPaths.get(0);
    if (first == null) {
      return "";
    }
    return first.trim();
  }
}
