/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import io.rchemist.core.context.RequestContext;
import io.rchemist.core.context.TenantContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #24 — Spring Security 의 {@link AccessDeniedException} (403) / {@link AuthenticationException}
 * (401) 을 RFC 7807 ProblemDetail 로 매핑하는 분리 {@code @RestControllerAdvice}.
 *
 * <p>본 클래스는 {@code @ConditionalOnClass} 으로 Spring Security classpath gate 가 적용된 별도
 * {@code @Configuration} (예: {@link io.rchemist.web.StarterWebAutoConfiguration} 의 nested static
 * {@code SecurityAwareAdviceConfiguration}) 에서만 등록 → Spring Security 미포함 consumer 의 부팅
 * introspection 단계 {@code NoClassDefFoundError} 영구 회피 (Issue #22 분리 idiom 정합).
 *
 * <p>{@link ProblemDetailAdvice} 의 catch-all {@code handleUnexpected(Exception)} 보다 좁은 매칭
 * (구체적 클래스 매칭) → Spring 의 {@code ExceptionHandlerMethodResolver} 가 자동 우선 매칭. 본
 * advice 는 {@link Ordered#HIGHEST_PRECEDENCE} 부착으로 Consumer 자체 advice 보다 *뒤* 가 아닌
 * 명시적 *앞* 순서 → consumer 가 자체 처리 안 한 경우만 framework default 응답.
 *
 * <p>extension fields: {@code code} / {@code traceId} / {@code tenantId} ({@link ProblemDetailAdvice}
 * 와 동일 schema).
 **/
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class SecurityExceptionHandlers {

  public static final String ACCESS_DENIED_CODE = "ACCESS.DENIED";
  public static final String AUTHENTICATION_REQUIRED_CODE = "ACCESS.AUTHENTICATION_REQUIRED";

  @ExceptionHandler(AccessDeniedException.class)
  public ProblemDetail handleAccessDenied(AccessDeniedException ex) {
    ProblemDetail pd =
        ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, ACCESS_DENIED_CODE);
    pd.setTitle(ACCESS_DENIED_CODE);
    pd.setProperty("code", ACCESS_DENIED_CODE);
    applyContextProperties(pd);
    return pd;
  }

  @ExceptionHandler(AuthenticationException.class)
  public ProblemDetail handleAuthentication(AuthenticationException ex) {
    ProblemDetail pd =
        ProblemDetail.forStatusAndDetail(HttpStatus.UNAUTHORIZED, AUTHENTICATION_REQUIRED_CODE);
    pd.setTitle(AUTHENTICATION_REQUIRED_CODE);
    pd.setProperty("code", AUTHENTICATION_REQUIRED_CODE);
    applyContextProperties(pd);
    return pd;
  }

  private void applyContextProperties(ProblemDetail pd) {
    String traceId = RequestContext.currentRequestIdOrNull();
    if (traceId != null) {
      pd.setProperty("traceId", traceId);
    }
    String tenantId = TenantContext.currentTenantIdOrNull();
    if (tenantId != null) {
      pd.setProperty("tenantId", tenantId);
    }
  }
}
