/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — class-level marker. {@link AbstractCrudController} extends 한 consumer controller 가
 * 1 부착 → 8 endpoint 자동 PDP 매핑 (rcm-starter-security 의 access 영역 advice 가 fallback path
 * 안에서 lookup + action 자동 derive).
 *
 * <p>적용:
 * <ul>
 *   <li>{@link #resourcePrefix()} + {@link #entityName()} → {@code resource = prefix.entity}
 *       자동 합성 (예: {@code Learning.Course})</li>
 *   <li>action = 8 endpoint 매트릭스 자동 derive
 *       (POST / = create, GET / = list, POST /search = search, POST /count = count,
 *        GET /{id} = read, PUT /{id} = update, DELETE /{id} = delete, DELETE / = bulkDelete,
 *        GET /search/schema = searchSchema)</li>
 *   <li>메소드 레벨 {@code @AccessRoute} 명시 시 그쪽 우선 (override 보존)</li>
 *   <li>rcm-starter-security 미의존 consumer 가 부착해도 silent skip (어노테이션 자체는 본 web 영역,
 *       advice 영역만 security 의존)</li>
 * </ul>
 *
 * <p>의도 — consumer 가 모든 controller 의 8 endpoint method override + 각각 명시 부착 강제 영역
 * (보일러 8N + 누락 위험) 해소. 1 부착 = 8 endpoint 자동 PDP enforce.
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DefaultAccessRoute {

  /**
   * resource prefix — 도메인 그룹핑 (BC / module / submodule 정합).
   *
   * @return prefix (예: {@code Learning} / {@code Showcase} / {@code Cms})
   */
  String resourcePrefix();

  /**
   * entity 이름 — controller 가 관할하는 도메인 entity (보통 {@code @RequestMapping} path 의 단수형).
   *
   * @return entity 이름 (예: {@code Course} / {@code Article} / {@code Member})
   */
  String entityName();
}
