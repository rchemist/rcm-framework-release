/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0.
 */
package io.rchemist.web;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;

/**
 * RCM Framework — Web starter 진입점.
 *
 * Phase 0 = 빈 골격. 후속 Phase 2 에서 ProblemDetail / Page / traceparent /
 * 보안 헤더 / multipart 안전 default / @SearchQuery argument resolver 등 추가.
 */
@AutoConfiguration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class RcmStarterWebAutoConfiguration {
}
