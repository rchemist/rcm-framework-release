/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — Phase 2 task #6 web-openapi 자동 설정.
 *
 * <p>역할:
 * <ul>
 *   <li>springdoc-openapi-starter-webmvc-ui 3.0.x baseline — {@code /swagger-ui.html} +
 *       {@code /v3/api-docs} 자동 노출 (springdoc 자체 auto-config 가 활성, 이 모듈은 추가 영역만 적용)</li>
 *   <li>{@link OpenAPI} default Bean — Consumer 가 별도 정의 안 했을 때 framework 표준 title 적용.
 *       Consumer 는 {@code @Bean OpenAPI} 로 자유 override (ConditionalOnMissingBean)</li>
 *   <li>{@link RestEndpointOperationCustomizer} 등록 — {@link RestEndpoint} 메소드 자동 인식 →
 *       {@code Operation.summary/description/tag/deprecated/operationId} 자동 합산</li>
 * </ul>
 *
 * <p>비-담당 (Phase 후속):
 * <ul>
 *   <li>{@code @RestData} / {@code @RestDataField} → springdoc Schema 통합 — Phase 후속 또는
 *       Phase 9 archetype 진입 시점 (task #6 본문 적용: APT metadata 생성만, 깊은 통합 보류)</li>
 *   <li>{@code @Example} → springdoc Parameter example — Phase 후속</li>
 *   <li>{@code Searchable} marker → SearchRequest schema 자동 — Phase 1 task #5 의 Entity_Search
 *       metadata 위에 Phase 후속 customizer 적용</li>
 * </ul>
 *
 * <p>opt-out: yml {@code platform.openapi.enabled=false} (default true).
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.springdoc.core.customizers.OperationCustomizer")
@ConditionalOnProperty(prefix = "platform.openapi", name = "enabled", havingValue = "true",
    matchIfMissing = true)
public class OpenApiAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public OpenAPI rcmDefaultOpenApi() {
    return new OpenAPI().info(new Info()
        .title("RCM Framework API")
        .description("RCM Framework 기반 RESTful API 문서 (springdoc-openapi 3.x)")
        .version("v1"));
  }

  @Bean
  @ConditionalOnMissingBean
  public RestEndpointOperationCustomizer restEndpointOperationCustomizer() {
    return new RestEndpointOperationCustomizer();
  }
}
