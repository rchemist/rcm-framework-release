/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.util;

import org.owasp.html.PolicyFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 (Decision #29 Q2) — HTML 문자열 제어 utility. OWASP Java HTML Sanitizer 기반.
 *
 * <p>{@link HtmlPolicies} 의 baseline 정책 + {@link #strip(String)} / {@link #truncate(String, int)} /
 * {@link #escape(String)} / {@link #unescape(String)} 5 method. EditorJsUtil 영구 거부 (Decision #29 Q2).
 *
 * <p>모든 method = static, null fail-soft, OWASP 기본 검증 (XSS / event handler / javascript: scheme).
 **/
public final class HtmlSanitizer {

  private HtmlSanitizer() {
    throw new UnsupportedOperationException("static utility");
  }

  /** {@link HtmlPolicies} 의 baseline 정책 적용. policy = null 또는 input = null 이면 null 반환. */
  public static String sanitize(String html, PolicyFactory policy) {
    if (html == null) {
      return null;
    }
    if (policy == null) {
      throw new IllegalArgumentException("policy");
    }
    return policy.sanitize(html);
  }

  /** 모든 tag 제거 — text node 만 추출. {@link HtmlPolicies#PLAIN_TEXT} 단축. */
  public static String strip(String html) {
    if (html == null) {
      return null;
    }
    if (html.isEmpty()) {
      return html;
    }
    return HtmlPolicies.PLAIN_TEXT.sanitize(html);
  }

  /** {@link #strip(String)} 후 max 길이로 자름. unescape 한 자연 문자열 기준. */
  public static String truncate(String html, int max) {
    if (max < 0) {
      throw new IllegalArgumentException("max < 0: " + max);
    }
    if (html == null) {
      return null;
    }
    if (max == 0) {
      return "";
    }
    String stripped = strip(html);
    String unescaped = unescape(stripped);
    if (unescaped == null || unescaped.length() <= max) {
      return unescaped;
    }
    return unescaped.substring(0, max);
  }

  /** HTML special chars escape ({@code <}, {@code >}, {@code &}, {@code "}, {@code '}). */
  public static String escape(String text) {
    if (text == null) {
      return null;
    }
    StringBuilder sb = new StringBuilder(text.length() + 16);
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      switch (c) {
        case '<' -> sb.append("&lt;");
        case '>' -> sb.append("&gt;");
        case '&' -> sb.append("&amp;");
        case '"' -> sb.append("&quot;");
        case '\'' -> sb.append("&#39;");
        default -> sb.append(c);
      }
    }
    return sb.toString();
  }

  /** {@link #escape(String)} 의 역연산 — 5 entity reverse. */
  public static String unescape(String text) {
    if (text == null) {
      return null;
    }
    if (text.indexOf('&') < 0) {
      return text;
    }
    return text.replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
        .replace("&amp;", "&");
  }
}
