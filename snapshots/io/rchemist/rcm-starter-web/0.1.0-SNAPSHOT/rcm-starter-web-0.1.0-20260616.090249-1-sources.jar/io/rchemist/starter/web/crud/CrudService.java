/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import io.rchemist.core.search.EntityViewType;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SearchResponse;
import java.util.Map;
import org.springframework.data.domain.Page;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #7 적용 — {@link AbstractCrudController} 가 의존하는 service-side SPI. Phase 3 의
 * {@code AbstractCrudService} 가 구현 (entity / repository / cache / multi-tenant 자동 결합).
 *
 * <p>얇은 base 5 규칙 정합 — service 자체의 hook 메서드는 비즈니스 결정 5 종 (create / find / search /
 * update / delete) + 단순 metadata (searchSchema). protected hook 0, generic 4 type, 추상은 모두
 * 비즈니스.
 *
 * <p>Phase 0.1.0 GA Gate T0-6 (Decision #31 정합) — 4 신규 default method 추가:
 * <ul>
 *   <li>{@link #searchResponse(SearchRequest)} — 풍부 응답 변환 (Page → SearchResponse + sorts/echo).
 *       Phase 3 의 AbstractCrudService 가 본격 override (preserve / restore cycle 포함)</li>
 *   <li>{@link #count(SearchRequest)} — 검색 조건 만족 count (default = search 의 totalElements,
 *       Phase 3 가 efficient COUNT(*) 본격 override)</li>
 *   <li>{@link #bulkDelete(BulkDeleteRequest)} — bulk 삭제 (default = ids loop, Phase 3 가
 *       deleteAllByIdInBatch + cache evict 본격 override)</li>
 *   <li>{@link #find(Object, EntityViewType)} — view mode 분기 lookup (default = viewType 무시 +
 *       {@link #find(Object)} 위임, Consumer 가 도메인별 override)</li>
 * </ul>
 *
 * <p>Phase 2 시점은 SPI 만 적용 — test 가 mock impl 로 검증. Phase 3 task 3.9 의
 * {@code AbstractCrudService} 가 표준 구현 + cache (Decision #7 의 2-tier region 자동) + tenant
 * (Decision #17) + outbox (Decision #8) 자동 결합.
 *
 * @param <E>          entity 타입 (JPA entity 또는 domain object)
 * @param <ID>         entity 식별자 타입
 * @param <CreateForm> create endpoint 의 request body Records
 * @param <UpdateForm> update endpoint 의 request body Records
 **/
public interface CrudService<E, ID, CreateForm, UpdateForm> {

  /**
   * 신규 entity 생성 — {@code POST /} 가 호출.
   *
   * @param form valid create 폼 (Bean Validation 검증 후)
   * @return 영속화된 entity (ID 포함)
   */
  E create(CreateForm form);

  /**
   * 단건 lookup — {@code GET /{id}} 가 호출.
   *
   * @param id entity 식별자
   * @return 발견된 entity
   * @throws io.rchemist.core.error.ServiceException
   *         {@link CrudErrorType#NOT_FOUND} (또는 Consumer 의 도메인별 NOT_FOUND ErrorType)
   *         — base 가 자체 throw 가능 + service 가 자체 throw 가능 (둘 다 advice 가 동일 처리)
   */
  E find(ID id);

  /**
   * view mode 분기 lookup — {@code GET /{id}?viewType=VIEW|EDIT|DETAIL|MOBILE} 가 호출.
   * default = viewType 무시 + {@link #find(Object)} 위임. Consumer 가 도메인별 override 자유
   * (e.g. EDIT mode = entity + 사용자 권한 필드 + validation hints / DETAIL mode = 관련 entity 결합 등).
   *
   * @param id       entity 식별자
   * @param viewType view mode (null = VIEW default 동등)
   * @return 발견된 entity (viewType 별 다른 형태일 수 있음 — DTO 변환은 controller 책임)
   */
  default E find(ID id, EntityViewType viewType) {
    return find(id);
  }

  /**
   * 검색 + 페이징 — {@code GET /} 가 호출. {@code SearchRequest} 의 page/pageSize 자체에 적용 (별도
   * Pageable 분리 거부, 중복 적용 회피, ambiguity 적용 결정).
   *
   * @param request 0.0.5 모든 필드 흡수한 SearchRequest (Decision §5.5)
   * @return Spring Data {@link Page} — total / number / size / content
   */
  Page<E> search(SearchRequest request);

  /**
   * 풍부 응답 검색 — {@code GET /} (단순) + {@code POST /search} (고급) 가 호출. Decision #31 정합 +
   * Phase 0.1.0 GA Gate T0-5 baseline.
   *
   * <p>default 구현 = {@link #search(SearchRequest)} 위임 + page meta 매핑 + sorts/searchRequest echo.
   * Phase 3 의 AbstractCrudService 가 본격 override — preserve / restore cycle (서버 강제 주입 filter
   * 복원) + facet / aggregation attributes 결합.
   *
   * @param request SearchRequest (page/pageSize/filters/sorts)
   * @return content + 페이징 메타 + sorts/searchRequest echo + attributes Map + errors
   */
  default SearchResponse<E> searchResponse(SearchRequest request) {
    Page<E> page = search(request);
    return new SearchResponse<>(
        page.getContent(),
        page.getNumber(),
        page.getSize(),
        page.getTotalElements(),
        page.getTotalPages(),
        request == null ? java.util.List.of() : request.sorts(),
        request,
        java.util.Map.of(),
        java.util.List.of());
  }

  /**
   * 검색 조건 만족 count — {@code POST /count} 가 호출. Decision #31 정합.
   *
   * <p>default 구현 = {@link #search(SearchRequest)} 의 {@code totalElements}. Phase 3 의
   * AbstractCrudService 가 본격 override — Specification + COUNT(*) 직접 query (content fetch 회피).
   *
   * @param request SearchRequest (page/pageSize 무시 — filters / quickSearch 만 사용)
   * @return 매칭 count
   */
  default long count(SearchRequest request) {
    return search(request).getTotalElements();
  }

  /**
   * 부분 또는 전체 갱신 — {@code PUT /{id}} 가 호출.
   *
   * @param id   대상 entity 식별자
   * @param form valid update 폼
   * @return 갱신된 entity
   */
  E update(ID id, UpdateForm form);

  /**
   * 삭제 — {@code DELETE /{id}} 가 호출. soft / hard 결정은 Consumer 의 service 책임.
   *
   * @param id 대상 entity 식별자
   */
  void delete(ID id);

  /**
   * bulk 삭제 — {@code DELETE /} + body 가 호출. Decision #31 (RFC 9110 *서버 명시 지원* 영역) 정합.
   *
   * <p>default 구현 = ids 마다 {@link #delete(Object)} loop. Phase 3 의 AbstractCrudService 가 본격
   * override — {@code deleteAllByIdInBatch} + cache evict 일괄 처리.
   *
   * @param request {ids: List&lt;ID&gt;, revisionEntityName: String?} (ids non-empty 강제)
   */
  default void bulkDelete(BulkDeleteRequest<ID> request) {
    java.util.Objects.requireNonNull(request, "request");
    for (ID id : request.ids()) {
      delete(id);
    }
  }

  /**
   * Phase 2 baseline — {@code GET /search/schema} 가 호출 (Decision #31 정합 — `_search` underscore
   * prefix 영구 거부, was {@code /_search/schema}). entity 의 검색 가능 필드 + 타입 메타데이터 반환.
   * Phase 1 APT 의 {@code Entity_Search} 활용 또는 reflection fallback.
   *
   * <p>응답 shape: {@code { "entity": "...", "fields": [...], "types": { "field": "FQN" } }}.
   * 단순 Map — 도메인 자유 확장 가능.
   *
   * @return 검색 schema metadata
   */
  Map<String, Object> searchSchema();
}
