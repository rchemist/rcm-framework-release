/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — URI path prefix 기반 tenant 식별. {@code pathPrefix} = {@code /t/} default.
 * 예: {@code /t/acme/articles} → {@code acme}. prefix 미일치 시 빈 Optional.
 **/
public class PathPrefixTenantContextFilterResolver implements TenantContextFilterResolver {

  private final String pathPrefix;

  public PathPrefixTenantContextFilterResolver(String pathPrefix) {
    this.pathPrefix = pathPrefix.endsWith("/") ? pathPrefix : pathPrefix + "/";
  }

  @Override
  public Optional<String> resolveTenantId(HttpServletRequest request) {
    String uri = request.getRequestURI();
    if (uri == null || !uri.startsWith(pathPrefix)) {
      return Optional.empty();
    }
    String remainder = uri.substring(pathPrefix.length());
    int slash = remainder.indexOf('/');
    String segment = slash < 0 ? remainder : remainder.substring(0, slash);
    return segment.isBlank() ? Optional.empty() : Optional.of(segment);
  }
}
