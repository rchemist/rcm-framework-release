/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — 0.0.5 의 {@code @RestData} 시그니처 흡수. 클래스/Records 단위 OpenAPI Schema
 * 메타데이터 명시 어노테이션. APT 가 컴파일 시점에 metadata 추출 (Phase 후속 customizer 활용).
 *
 * <ul>
 *   <li>{@link #name()} — Schema name (빈 값이면 simple class name 자동)</li>
 *   <li>{@link #description()} — Schema description (DTO 목적 설명)</li>
 * </ul>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface RestData {

  /** Schema name — 빈 값이면 simple class name 자동. */
  String name() default "";

  /** Schema description. */
  String description() default "";
}
