/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.web;

import io.rchemist.starter.web.autoconfig.MultipartSafetyFilter;
import io.rchemist.starter.web.autoconfig.MultipartSafetyProperties;
import io.rchemist.starter.web.autoconfig.ProblemDetailAdvice;
import io.rchemist.starter.web.autoconfig.SecurityHeadersFilter;
import io.rchemist.starter.web.autoconfig.SecurityHeadersProperties;
import io.rchemist.starter.web.context.HeaderTenantContextFilterResolver;
import io.rchemist.starter.web.context.PathPrefixTenantContextFilterResolver;
import io.rchemist.starter.web.context.RequestContextFilter;
import io.rchemist.starter.web.context.SubdomainTenantContextFilterResolver;
import io.rchemist.starter.web.context.TenantContextFilter;
import io.rchemist.starter.web.context.TenantContextFilterResolver;
import io.rchemist.starter.web.context.WebTenantProperties;
import io.rchemist.starter.web.json.TsidJacksonModule;
import io.rchemist.starter.web.search.SearchRequestArgumentResolver;
import io.rchemist.starter.web.validation.TenantMessageSource;
import io.rchemist.starter.web.validation.ValidationMessageProperties;
import java.util.List;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import tools.jackson.databind.JacksonModule;
import tools.jackson.databind.ObjectMapper;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * rcm-starter-web 진입점 — Phase 2 task #1 + #2 + #3 + #4 + #5 적용.
 *
 * <ul>
 *   <li>{@link ProblemDetailAdvice} 등록 (Decision #1 + #23 + #24, RFC 7807 자동 변환)</li>
 *   <li>{@link RequestContextFilter} 등록 (Phase 2 task #2 — traceparent + X-Request-Id +
 *       ScopedValue + MDC 자동 인입, 청사진 §6 적용)</li>
 *   <li>{@link SecurityHeadersFilter} 등록 (Phase 2 task #3 — 5 종 보안 응답 헤더 default 적용,
 *       청사진 §9 task 2.3)</li>
 *   <li>{@link MultipartSafetyFilter} 등록 (Phase 2 task #3 — multipart 안전 default 적용,
 *       청사진 §9 task 2.4: Path traversal / 매직바이트 / ZIP Slip / max-file-size)</li>
 *   <li>web-validation 5 영역 (task #5, Decision #23) — {@code validationMessageSource} (baseline +
 *       Korean default) + {@link TenantMessageSource} wrapper (multi-tenant hook, Phase 3 결합) 등록</li>
 *   <li>VirtualThread default 적용 (사용자 결정 2026-05-03,
 *       {@code VirtualThreadDefaultPropertiesPostProcessor} 가
 *       {@code spring.threads.virtual.enabled=true} 를 SB 4 opt-in default 로 적용)</li>
 * </ul>
 *
 * <p>후속 task #6~#8 에서 web-openapi / 5 starter 의존 동기 추가.
 **/
@AutoConfiguration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@EnableConfigurationProperties({
    SecurityHeadersProperties.class,
    MultipartSafetyProperties.class,
    ValidationMessageProperties.class,
    WebTenantProperties.class
})
public class StarterWebAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ProblemDetailAdvice problemDetailAdvice(
        TenantMessageSource validationMessageSource,
        @org.springframework.beans.factory.annotation.Value(
            "${management.endpoints.web.base-path:/actuator}") String actuatorBasePath) {
        ProblemDetailAdvice advice = new ProblemDetailAdvice(validationMessageSource);
        // issue #65 — actuator 경로 예외는 도메인 catch-all 이 가로채지 않도록 base-path 인입.
        advice.setActuatorBasePath(actuatorBasePath);
        return advice;
    }

    /**
     * Phase 2 task #2 적용 — {@link RequestContextFilter} bean. Bean name 은
     * {@code rcmRequestContextFilter} 로 명시 (Spring MVC 의 {@code WebMvcAutoConfiguration} 도
     * {@code requestContextFilter} 이름의 Servlet filter 자동 등록 — Spring 7 + SB 4.0.6 baseline 에서
     * BeanDefinitionOverrideException 회피).
     */
    @Bean(name = "rcmRequestContextFilter")
    @ConditionalOnMissingBean(name = "rcmRequestContextFilter")
    public RequestContextFilter rcmRequestContextFilter() {
        return new RequestContextFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public SecurityHeadersFilter securityHeadersFilter(SecurityHeadersProperties properties) {
        return new SecurityHeadersFilter(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public MultipartSafetyFilter multipartSafetyFilter(MultipartSafetyProperties properties) {
        return new MultipartSafetyFilter(properties);
    }

    /**
     * Phase 2 task #4 적용 — {@link SearchRequestArgumentResolver} 자동 등록 + Spring MVC 의 argument
     * resolver chain 에 plug-in. {@code @ConditionalOnMissingBean} 으로 Consumer 가 자체 resolver
     * 제공 시 자동 교체.
     */
    @Bean
    @ConditionalOnMissingBean
    public SearchRequestArgumentResolver searchRequestArgumentResolver(ObjectMapper objectMapper) {
        return new SearchRequestArgumentResolver(objectMapper);
    }

    @Bean
    public WebMvcConfigurer searchRequestWebMvcConfigurer(
        SearchRequestArgumentResolver searchRequestArgumentResolver
    ) {
        return new WebMvcConfigurer() {
            @Override
            public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
                resolvers.add(searchRequestArgumentResolver);
            }
        };
    }

    /**
     * Phase 2 task #5 적용 — Bean Validation baseline 메시지 source. UTF-8 / fallback 미지정 / cache forever.
     * basenames 는 {@link ValidationMessageProperties#basenames()} 그대로. 사용자 정의
     * {@code validation-messages_*.properties} 추가 시 자동 합쳐짐 (Spring ResourceBundleMessageSource 가
     * basename 별 properties 합산).
     *
     * <p>bean name = {@code validationMessageSource} — 다른 {@link MessageSource}
     * (예: 사용자 application.properties / messages.properties 의 main MessageSource) 와 충돌 회피.
     */
    @Bean(name = "validationMessageSource")
    @ConditionalOnMissingBean(name = "validationMessageSource")
    public MessageSource validationMessageSource(ValidationMessageProperties properties) {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasenames(properties.basenames().toArray(new String[0]));
        source.setDefaultEncoding("UTF-8");
        source.setUseCodeAsDefaultMessage(false);
        source.setFallbackToSystemLocale(false);
        source.setDefaultLocale(properties.resolvedDefaultLocale());
        return source;
    }

    /**
     * Phase 2 task #5 적용 — {@link TenantMessageSource} wrapper. {@code tenantSpecific=false} (Phase 2 baseline)
     * 일 때는 delegate 그대로, {@code tenantSpecific=true} (Phase 3 진입) 일 때는 tenant 별 properties 우선 lookup.
     */
    @Bean
    @ConditionalOnMissingBean
    public TenantMessageSource tenantMessageSource(
        @org.springframework.beans.factory.annotation.Qualifier("validationMessageSource") MessageSource validationMessageSource,
        ValidationMessageProperties properties
    ) {
        return new TenantMessageSource(validationMessageSource, properties);
    }

    /**
     * Phase 3 task #4 적용 — {@link TenantContextFilterResolver} 자동 등록 (Decision #17). yml
     * {@code platform.tenant.resolver} 단일 active resolver 선택 — HEADER (default) / SUBDOMAIN /
     * PATH_PREFIX / SPI 4 종. Consumer 가 자체 {@link TenantContextFilterResolver} bean 적용 시 자동
     * 교체 ({@code @ConditionalOnMissingBean}). yml resolver=SPI 시 Consumer bean 필수 (없으면 fail loud).
     */
    @Bean
    @ConditionalOnMissingBean(TenantContextFilterResolver.class)
    public TenantContextFilterResolver tenantContextFilterResolver(WebTenantProperties properties) {
        return switch (properties.resolver()) {
            case HEADER -> new HeaderTenantContextFilterResolver(properties.header());
            case SUBDOMAIN -> new SubdomainTenantContextFilterResolver(properties.subdomainIndex());
            case PATH_PREFIX -> new PathPrefixTenantContextFilterResolver(properties.pathPrefix());
            case SPI -> throw new IllegalStateException(
                "platform.tenant.resolver=SPI 시 Consumer 가 자체 TenantContextFilterResolver bean 적용 필수");
        };
    }

    /**
     * Phase 3 task #4 적용 — {@link TenantContextFilter} bean. {@link RequestContextFilter} chain 다음
     * (Order = HIGHEST_PRECEDENCE + 15). request 진입 시 active resolver 로 tenant 식별 → {@link
     * io.rchemist.core.context.TenantContext} ScopedValue chain → downstream.
     */
    @Bean(name = "rcmTenantContextFilter")
    @ConditionalOnMissingBean(name = "rcmTenantContextFilter")
    public TenantContextFilter rcmTenantContextFilter(TenantContextFilterResolver resolver) {
        return new TenantContextFilter(resolver);
    }

    /**
     * issue #28/#62 — {@link TsidJacksonModule} 자동 등록 영역.
     *
     * <p>본 inner class 는 *클래스 레벨* {@link ConditionalOnClass}({@code
     * io.rchemist.starter.jpa.id.TsidGenerator}) 으로 gate. Spring Boot 가 ASM 으로 어노테이션을 읽고
     * 클래스 자체를 미로드 → {@code rcm-starter-jpa} 미포함 consumer 의 introspection 단계 {@code
     * NoClassDefFoundError} 회피 (issue #22 의 분리 idiom 영역 정합).
     *
     * <p>{@link TsidJacksonModule} 은 {@link JacksonModule} 로 등록 — Spring Boot 4 Jackson 3 auto-config
     * 가 모든 {@link JacksonModule} bean 을 ObjectMapper 에 자동 register.
     */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(io.rchemist.starter.jpa.id.TsidGenerator.class)
    static class TsidJacksonBeans {

        @Bean
        @ConditionalOnMissingBean(name = "tsidJacksonModule")
        JacksonModule tsidJacksonModule() {
            return new TsidJacksonModule();
        }
    }
}
