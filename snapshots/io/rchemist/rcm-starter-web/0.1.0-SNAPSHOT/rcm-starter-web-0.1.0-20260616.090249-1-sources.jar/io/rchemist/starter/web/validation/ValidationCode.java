/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (3) — 에러 코드 자동 추출의 *명시 옵션*.
 *
 * <p>Bean Validation 어노테이션 위에 본 어노테이션을 함께 적용하면 {@link ValidationCodeExtractor} 가
 * annotation type 변환 ({@code @NotBlank} → {@code VALIDATION.NOT_BLANK}) 대신 본 {@code value()} 를 우선 사용.
 *
 * <p>적용 위치:
 * <ul>
 *   <li>{@code FIELD} — DTO field 별 명시 (예: {@code @ValidationCode("USER.EMAIL_FORMAT")} + {@code @Email}).</li>
 *   <li>{@code METHOD} — getter 등에 명시.</li>
 *   <li>{@code PARAMETER} — controller method param 명시.</li>
 *   <li>{@code ANNOTATION_TYPE} — 사용자 정의 constraint annotation 위에 적용 (전역 default 적용).</li>
 * </ul>
 */
@Target({FIELD, METHOD, PARAMETER, ANNOTATION_TYPE})
@Retention(RUNTIME)
public @interface ValidationCode {

    /** 명시 에러 코드 — 예: {@code "USER.EMAIL_FORMAT"}. */
    String value();
}
