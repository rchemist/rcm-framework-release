/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import io.rchemist.core.context.RequestContext;
import io.rchemist.core.context.TenantContext;
import io.rchemist.core.error.ErrorType;
import io.rchemist.core.error.FieldErrorEntry;
import io.rchemist.core.error.ServiceException;
import io.rchemist.starter.web.search.SearchRequestParser;
import io.rchemist.starter.web.validation.DomainFriendlyKeyResolver;
import io.rchemist.starter.web.validation.TenantMessageSource;
import io.rchemist.starter.web.validation.ValidationCodeExtractor;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #1 + #23 + #24 통합 entry point — 모든 예외를 RFC 7807 ProblemDetail 로 변환.
 *
 * <p>Phase 2 task #1 baseline + task #5 web-validation 5 영역 결합:
 * <ul>
 *   <li>{@link ServiceException} → 4xx ProblemDetail (Decision #24, Consumer throw 패턴 100% 보존)</li>
 *   <li>{@link MethodArgumentNotValidException} → 400 ProblemDetail (Decision #23) —
 *       {@link ValidationCodeExtractor} 자동 코드 추출 + {@link DomainFriendlyKeyResolver} 3 단계 lookup +
 *       {@link TenantMessageSource} tenant 별 우선 + baseline 한국어 메시지 fallback</li>
 *   <li>{@link ConstraintViolationException} → 400 ProblemDetail (path 단위 violations + 동일 5 영역 결합)</li>
 *   <li>{@link Exception} → 500 ProblemDetail ({@code SYSTEM.UNEXPECTED}, message 비노출)</li>
 * </ul>
 *
 * <p>extension fields: {@code code} / {@code field} / {@code errors[]} / {@code fieldErrors} (frontend
 * {@code EntityFieldError} 호환) / {@code traceId} / {@code tenantId}.
 */
@RestControllerAdvice
public class ProblemDetailAdvice {

    public static final String SYSTEM_UNEXPECTED_CODE = "SYSTEM.UNEXPECTED";
    public static final String VALIDATION_FAILED_CODE = "VALIDATION.FAILED";
    public static final String SEARCH_USE_POST_BODY_CODE = "SEARCH.USE_POST_BODY";

    /** issue #65 — actuator management base-path default. {@code management.endpoints.web.base-path}. */
    public static final String DEFAULT_ACTUATOR_BASE_PATH = "/actuator";

    private TenantMessageSource messageSource;
    private String actuatorBasePath = DEFAULT_ACTUATOR_BASE_PATH;

    /**
     * Phase 2 task #1 baseline 호환 (no-arg). messageSource 미인입 시 message lookup 미수행 — 코드 자체 detail 노출.
     * production 경로는 {@link #ProblemDetailAdvice(TenantMessageSource)} bean 사용.
     */
    public ProblemDetailAdvice() {
        this(null);
    }

    public ProblemDetailAdvice(TenantMessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /**
     * Spring autowire 진입 — {@code @Import(ProblemDetailAdvice.class)} 로 등록된 단일 instance 에 후-주입.
     * TenantMessageSource bean 부재 시 message lookup 비활성 (baseline 동작 유지).
     */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    public void setMessageSource(TenantMessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /**
     * issue #65 — actuator management base-path 주입 (default {@code /actuator}). actuator 경로 예외는
     * 도메인 catch-all 이 {@code SYSTEM.UNEXPECTED} 로 가공하지 않고 그대로 위임하도록 구분하는 데 사용.
     */
    public void setActuatorBasePath(String actuatorBasePath) {
        if (actuatorBasePath != null && !actuatorBasePath.isBlank()) {
            this.actuatorBasePath = actuatorBasePath;
        }
    }

    @ExceptionHandler(ServiceException.class)
    public ProblemDetail handleServiceException(ServiceException ex) {
        ErrorType primary = ex.errorType();
        HttpStatus status = primary.httpStatus();
        String detail = resolveErrorTypeMessage(primary, ex.args());
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, detail);
        pd.setTitle(primary.code());
        pd.setProperty("code", primary.code());
        if (ex.field() != null) {
            pd.setProperty("field", ex.field());
        }

        List<FieldErrorEntry> all = ex.getAllErrors();
        applyServiceErrors(pd, all);
        applyContextProperties(pd);
        return pd;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        String headline = resolveCode(VALIDATION_FAILED_CODE, null);
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, headline);
        pd.setTitle(VALIDATION_FAILED_CODE);
        pd.setProperty("code", VALIDATION_FAILED_CODE);

        List<Map<String, Object>> errors = new ArrayList<>();
        Map<String, List<String>> fieldErrors = new LinkedHashMap<>();

        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            String field = fe.getField();
            String code = ValidationCodeExtractor.extract(fe);
            String message = resolveFieldErrorMessage(fe);
            errors.add(buildErrorEntry(field, code, message));
            fieldErrors.computeIfAbsent(field, k -> new ArrayList<>()).add(message);
        }
        for (var goe : ex.getBindingResult().getGlobalErrors()) {
            String code = ValidationCodeExtractor.extractGlobal(goe.getCode());
            String defaultMsg = goe.getDefaultMessage();
            String message = defaultMsg == null ? code : defaultMsg;
            errors.add(buildErrorEntry(null, code, message));
        }

        pd.setProperty("errors", errors);
        pd.setProperty("fieldErrors", fieldErrors);
        applyContextProperties(pd);
        return pd;
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ProblemDetail handleConstraintViolation(ConstraintViolationException ex) {
        String headline = resolveCode(VALIDATION_FAILED_CODE, null);
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, headline);
        pd.setTitle(VALIDATION_FAILED_CODE);
        pd.setProperty("code", VALIDATION_FAILED_CODE);

        List<Map<String, Object>> errors = new ArrayList<>();
        Map<String, List<String>> fieldErrors = new LinkedHashMap<>();

        for (ConstraintViolation<?> cv : ex.getConstraintViolations()) {
            String field = lastNode(cv.getPropertyPath());
            String code = ValidationCodeExtractor.extract(cv);
            String message = resolveConstraintViolationMessage(cv);
            errors.add(buildErrorEntry(field, code, message));
            if (field != null) {
                fieldErrors.computeIfAbsent(field, k -> new ArrayList<>()).add(message);
            }
        }

        pd.setProperty("errors", errors);
        pd.setProperty("fieldErrors", fieldErrors);
        applyContextProperties(pd);
        return pd;
    }

    @ExceptionHandler(SearchRequestParser.ComplexQueryException.class)
    public ProblemDetail handleComplexSearchQuery(SearchRequestParser.ComplexQueryException ex) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(
            HttpStatus.BAD_REQUEST,
            ex.getMessage() == null ? SEARCH_USE_POST_BODY_CODE : ex.getMessage());
        pd.setTitle(SEARCH_USE_POST_BODY_CODE);
        pd.setProperty("code", SEARCH_USE_POST_BODY_CODE);
        applyContextProperties(pd);
        return pd;
    }

    /**
     * Phase 0.1.0 GA Gate T0-6 — body 파싱 실패 (잘못된 JSON / Records compact constructor
     * IllegalArgumentException wrapped via Jackson ValueInstantiationException). Spring 의 default
     * 매핑은 catch-all 로 가로채여 500 으로 떨어지므로 명시 처리.
     */
    @ExceptionHandler(org.springframework.http.converter.HttpMessageNotReadableException.class)
    public ProblemDetail handleHttpMessageNotReadable(
        org.springframework.http.converter.HttpMessageNotReadableException ex) {
        String detail = ex.getMostSpecificCause() != null
            ? ex.getMostSpecificCause().getMessage() : ex.getMessage();
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,
            detail == null ? "REQUEST.BODY_INVALID" : detail);
        pd.setTitle("REQUEST.BODY_INVALID");
        pd.setProperty("code", "REQUEST.BODY_INVALID");
        applyContextProperties(pd);
        return pd;
    }

    /**
     * Phase 0.1.0 GA Gate T0-6 — path / query parameter 변환 실패 (잘못된 enum 값 / Long 파싱 실패 등).
     * Spring 의 default 매핑은 catch-all 로 가로채여 500 으로 떨어지므로 명시 처리.
     */
    @ExceptionHandler(org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class)
    public ProblemDetail handleMethodArgumentTypeMismatch(
        org.springframework.web.method.annotation.MethodArgumentTypeMismatchException ex) {
        String name = ex.getName();
        String required = ex.getRequiredType() == null ? "?" : ex.getRequiredType().getSimpleName();
        String detail = "Parameter '" + name + "' must be of type " + required;
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, detail);
        pd.setTitle("REQUEST.PARAM_TYPE_MISMATCH");
        pd.setProperty("code", "REQUEST.PARAM_TYPE_MISMATCH");
        pd.setProperty("field", name);
        applyContextProperties(pd);
        return pd;
    }

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleUnexpected(Exception ex, HttpServletRequest request) throws Exception {
        // issue #65 — actuator(management) 엔드포인트 경로의 예외는 도메인 SYSTEM.UNEXPECTED 로 가공하지
        // 않고 그대로 전파한다. catch-all 이 actuator 응답을 가로채면 운영 health probe 가 실제 상태/오류를
        // 못 읽고 무조건 500 SYSTEM.UNEXPECTED 만 받게 되어 진단 불가 → Spring/actuator 기본 처리에 위임.
        if (isActuatorRequest(request)) {
            throw ex;
        }
        // issue #59 — Spring 표준 status-carrying 예외(ResponseStatusException / ErrorResponseException /
        // HttpRequestMethodNotSupportedException 등 ErrorResponse 구현체)는 운반 status 를 존중.
        // ErrorResponse 는 Throwable 이 아닌 interface 라 @ExceptionHandler 로 직접 못 잡으므로 catch-all
        // 진입 후 instanceof 로 위임.
        if (ex instanceof ErrorResponse errorResponse) {
            return handleErrorResponse(errorResponse);
        }
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(
            HttpStatus.INTERNAL_SERVER_ERROR, SYSTEM_UNEXPECTED_CODE);
        pd.setTitle(SYSTEM_UNEXPECTED_CODE);
        pd.setProperty("code", SYSTEM_UNEXPECTED_CODE);
        applyContextProperties(pd);
        return pd;
    }

    /**
     * 현재 요청이 actuator management base-path 하위인지 판정. context-path 가 있으면 제거 후 비교
     * (예: context-path {@code /app} + base-path {@code /actuator} → {@code /app/actuator/**} 도 인식).
     */
    private boolean isActuatorRequest(HttpServletRequest request) {
        if (request == null) {
            return false;
        }
        String uri = request.getRequestURI();
        if (uri == null) {
            return false;
        }
        String contextPath = request.getContextPath();
        String path = contextPath != null && !contextPath.isEmpty() && uri.startsWith(contextPath)
            ? uri.substring(contextPath.length()) : uri;
        return path.equals(actuatorBasePath) || path.startsWith(actuatorBasePath + "/");
    }

    /**
     * issue #59 — {@link ErrorResponse} 구현체의 운반된 HTTP status + ProblemDetail body 를 그대로 존중.
     * 도메인 전용 예외({@link ServiceException} / validation 류)는 각자 더 구체적 핸들러가 우선하므로 본
     * 경로로 오지 않는다.
     */
    private ProblemDetail handleErrorResponse(ErrorResponse ex) {
        ProblemDetail pd = ex.getBody();
        Map<String, Object> props = pd.getProperties();
        if (props == null || !props.containsKey("code")) {
            // consumer frontend 호환 — code 부재 시 status 기반 기본값 (운반 status 보존).
            pd.setProperty("code", String.valueOf(pd.getStatus()));
        }
        applyContextProperties(pd);
        return pd;
    }

    // ---------------------------------------------------------------------
    // helpers — message resolution + applyServiceErrors + buildErrorEntry
    // ---------------------------------------------------------------------

    private void applyServiceErrors(ProblemDetail pd, List<FieldErrorEntry> all) {
        List<Map<String, Object>> errors = new ArrayList<>(all.size());
        Map<String, List<String>> fieldErrors = new LinkedHashMap<>();

        for (FieldErrorEntry e : all) {
            String code = e.errorType().code();
            String message = resolveErrorTypeMessage(e.errorType(), e.args());
            errors.add(buildErrorEntry(e.field(), code, message));
            if (e.field() != null) {
                fieldErrors.computeIfAbsent(e.field(), k -> new ArrayList<>()).add(message);
            }
        }
        pd.setProperty("errors", errors);
        pd.setProperty("fieldErrors", fieldErrors);
    }

    private Map<String, Object> buildErrorEntry(String field, String code, String message) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("field", field);
        entry.put("code", code);
        entry.put("message", message);
        return entry;
    }

    /**
     * {@link ErrorType} 의 messageKey 를 우선 lookup → 부재 시 code 자체.
     */
    private String resolveErrorTypeMessage(ErrorType errorType, Object[] args) {
        if (errorType == null) {
            return null;
        }
        String key = errorType.messageKey();
        return resolveCode(key, args);
    }

    /**
     * Spring binding result {@link FieldError} 의 message resolution. 우선순위:
     * <ol>
     *   <li>{@link DomainFriendlyKeyResolver} 3 단계 lookup (entity/property/constraint)</li>
     *   <li>fqn fallback (jakarta.validation.constraints.X.message)</li>
     *   <li>Spring 의 default message (annotation 의 {@code message()} 속성)</li>
     *   <li>code 자체</li>
     * </ol>
     */
    private String resolveFieldErrorMessage(FieldError fe) {
        Locale locale = currentLocale();
        Object[] args = fe.getArguments();
        if (messageSource != null) {
            List<String> candidates = DomainFriendlyKeyResolver.resolve(fe);
            String resolved = messageSource.resolveFirst(candidates, args, locale);
            if (resolved != null && !candidates.isEmpty()
                && !resolved.equals(candidates.get(candidates.size() - 1))
                && !containsNamedPlaceholder(resolved)) {
                // 첫 hit 또는 fqn fallback hit — placeholder 미잔존 시 우선 적용.
                return resolved;
            }
            // 모두 미스 또는 named placeholder 잔존 → defaultMessage 적용 (Hibernate interpolation 결과).
        }
        String defaultMsg = fe.getDefaultMessage();
        if (defaultMsg != null && !defaultMsg.isBlank()) {
            return defaultMsg;
        }
        return ValidationCodeExtractor.extract(fe);
    }

    private String resolveConstraintViolationMessage(ConstraintViolation<?> cv) {
        Locale locale = currentLocale();
        Object[] args = null;
        if (messageSource != null) {
            List<String> candidates = DomainFriendlyKeyResolver.resolve(cv);
            String resolved = messageSource.resolveFirst(candidates, args, locale);
            if (resolved != null && !candidates.isEmpty()
                && !resolved.equals(candidates.get(candidates.size() - 1))
                && !containsNamedPlaceholder(resolved)) {
                return resolved;
            }
        }
        String defaultMsg = cv.getMessage();
        if (defaultMsg != null && !defaultMsg.isBlank()) {
            return defaultMsg;
        }
        return ValidationCodeExtractor.extract(cv);
    }

    /**
     * Hibernate-style {@code {name}} placeholder 잔존 검사 — Spring MessageFormat 으로는 처리 불가, 본 메시지는
     * {@code defaultMessage} (Hibernate 가 interpolate 한 결과) 우선 적용.
     */
    private boolean containsNamedPlaceholder(String s) {
        if (s == null) {
            return false;
        }
        int open = s.indexOf('{');
        while (open >= 0) {
            int close = s.indexOf('}', open + 1);
            if (close < 0) {
                return false;
            }
            String inside = s.substring(open + 1, close);
            // 숫자만 (= MessageFormat 가 interpolate 했어야 할 인덱스, 미interpolate 된 상태) 또는 named — 둘 다 처리 부재
            // 시그널. 단 문자가 영문자로 시작하면 named placeholder.
            if (!inside.isEmpty() && Character.isLetter(inside.charAt(0))) {
                return true;
            }
            open = s.indexOf('{', close + 1);
        }
        return false;
    }

    /**
     * 단일 code 의 message lookup — fallback 으로 code 자체 반환.
     */
    private String resolveCode(String code, Object[] args) {
        if (code == null) {
            return null;
        }
        if (messageSource == null) {
            return code;
        }
        return messageSource.getMessage(code, args, code, currentLocale());
    }

    private Locale currentLocale() {
        Locale locale = LocaleContextHolder.getLocale();
        return locale == null ? Locale.getDefault() : locale;
    }

    private void applyContextProperties(ProblemDetail pd) {
        String traceId = RequestContext.currentRequestIdOrNull();
        if (traceId != null) {
            pd.setProperty("traceId", traceId);
        }
        String tenantId = TenantContext.currentTenantIdOrNull();
        if (tenantId != null) {
            pd.setProperty("tenantId", tenantId);
        }
    }

    private String lastNode(Path path) {
        if (path == null) {
            return null;
        }
        String last = null;
        for (Path.Node node : path) {
            last = node.getName();
        }
        return last;
    }
}
