/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — HTTP 헤더 기반 tenant 식별. {@code X-Tenant-Id} default header 명, yml override
 * 가능. blank 시 빈 Optional.
 **/
public class HeaderTenantContextFilterResolver implements TenantContextFilterResolver {

  private final String headerName;

  public HeaderTenantContextFilterResolver(String headerName) {
    this.headerName = headerName;
  }

  @Override
  public Optional<String> resolveTenantId(HttpServletRequest request) {
    String value = request.getHeader(headerName);
    return (value == null || value.isBlank()) ? Optional.empty() : Optional.of(value);
  }
}
