/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.json;

import io.rchemist.starter.jpa.id.TsidGenerator;
import java.util.List;
import tools.jackson.databind.BeanDescription;
import tools.jackson.databind.SerializationConfig;
import tools.jackson.databind.ValueSerializer;
import tools.jackson.databind.introspect.AnnotatedMember;
import tools.jackson.databind.module.SimpleModule;
import tools.jackson.databind.ser.BeanPropertyWriter;
import tools.jackson.databind.ser.ValueSerializerModifier;
import tools.jackson.databind.ser.std.ToStringSerializer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #28 — {@link TsidGenerator} 부착 {@code Long} PK field 를 JSON String 으로 직렬화하는 Jackson 3
 * 모듈. JS {@code Number} 의 53-bit 안전 정수 한계 (TSID = 64-bit) 우회.
 *
 * <p>적용 영역: {@code Long} (wrapper) 필드만. {@code String} / {@code TSID} 타입은 이미 Crockford
 * base32 13 char 라 53-bit 한계 무관.
 *
 * <p>동작: {@link ValueSerializerModifier} 가 bean introspection 시 각 property writer 를 순회하면서
 * {@link AnnotatedMember#hasAnnotation(Class)} 로 {@link TsidGenerator} 부착 여부 검사. 부착 +
 * {@code Long} 타입 일 때 {@link ToStringSerializer#instance} 를 강제 할당.
 *
 * <p>역방향 (deserialize) 은 Jackson 기본 {@code Long} deserializer 가 JSON String 도 자동 파싱하므로
 * 별도 처리 불요.
 *
 * <p>Spring Boot 4 = Jackson 3 ({@code tools.jackson.databind}) — Jackson 2 ({@code com.fasterxml.jackson.*})
 * 의 {@code BeanSerializerModifier} 가 Jackson 3 에서 {@link ValueSerializerModifier} 로 갱신.
 **/
public class TsidJacksonModule extends SimpleModule {

    private static final long serialVersionUID = 1L;

    public TsidJacksonModule() {
        super("TsidJacksonModule");
        setSerializerModifier(new TsidSerializerModifier());
    }

    /**
     * {@link TsidGenerator} 부착 {@code Long} field 영역에 한해 {@link ToStringSerializer} 강제 할당.
     * 이외 property 는 기본 serializer 유지 (조건 부합 시만 교체 — 광범위 부작용 0).
     */
    static final class TsidSerializerModifier extends ValueSerializerModifier {

        private static final long serialVersionUID = 1L;

        @Override
        public List<BeanPropertyWriter> changeProperties(
            SerializationConfig config,
            BeanDescription.Supplier beanDescRef,
            List<BeanPropertyWriter> beanProperties) {
            for (BeanPropertyWriter writer : beanProperties) {
                AnnotatedMember member = writer.getMember();
                if (member == null) {
                    continue;
                }
                if (!member.hasAnnotation(TsidGenerator.class)) {
                    continue;
                }
                Class<?> raw = writer.getType().getRawClass();
                if (Long.class.isAssignableFrom(raw)) {
                    @SuppressWarnings({"unchecked", "rawtypes"})
                    ValueSerializer<Object> stringSer = (ValueSerializer) ToStringSerializer.instance;
                    writer.assignSerializer(stringSer);
                }
            }
            return beanProperties;
        }
    }
}
