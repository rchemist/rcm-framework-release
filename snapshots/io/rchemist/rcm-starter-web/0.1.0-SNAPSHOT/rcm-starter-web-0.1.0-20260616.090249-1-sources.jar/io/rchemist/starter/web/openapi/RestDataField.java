/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — 0.0.5 의 {@code @RestDataField} 시그니처 흡수. 필드 단위 OpenAPI Schema
 * property 메타데이터. APT 가 추출, 런타임 customizer 가 springdoc Schema 에 합산.
 *
 * <ul>
 *   <li>{@link #description()} — 필드 설명</li>
 *   <li>{@link #required()} — required 여부 (default false)</li>
 *   <li>{@link #example()} — 예시 값</li>
 * </ul>
 *
 * <p>Records 의 component / Lombok 영역의 field 양쪽 모두 적용 가능.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.RECORD_COMPONENT})
public @interface RestDataField {

  /** 필드 설명. */
  String description() default "";

  /** Required 여부 — default false. */
  boolean required() default false;

  /** 예시 값. */
  String example() default "";
}
