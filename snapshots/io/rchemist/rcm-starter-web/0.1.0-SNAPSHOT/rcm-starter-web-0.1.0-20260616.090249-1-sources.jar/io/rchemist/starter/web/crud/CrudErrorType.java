/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import io.rchemist.core.error.ErrorType;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * web-crud-base 영역의 baseline {@link ErrorType} — {@link AbstractCrudController} 가 NotFound /
 * Duplicate 등 5 표준 endpoint 동작 중 자주 throw 하는 코드.
 *
 * <p>Decision #7 적용 — Consumer 의 도메인별 {@code XxxServiceErrorType} 와 별개로 framework 자체의
 * baseline 코드 적용. {@link AbstractCrudController#findById} 의 NotFound 처리 + Consumer 가
 * 직접 throw 가능 (예: duplicate 검사 시 {@code throw new ServiceException(CrudErrorType.DUPLICATE,
 * "email")}).
 *
 * <p>web 영역 한정 — {@code core/rcm-core-error} 까지 노출 안 함 (도메인별 baseline 폐기 회피, web 영역
 * 의 CRUD baseline 한정).
 **/
public enum CrudErrorType implements ErrorType {

  /** 단건 lookup 실패 — {@code GET /{id}} 가 자동 throw. HTTP 404. */
  NOT_FOUND("CRUD.NOT_FOUND", HttpStatus.NOT_FOUND),

  /** 중복 충돌 — Consumer 가 직접 throw (예: 이메일 중복). HTTP 409. */
  DUPLICATE("CRUD.DUPLICATE", HttpStatus.CONFLICT),

  /** 비즈니스 규칙 위반 — Consumer 가 직접 throw. HTTP 422 (Spring 7 deprecation 정합 — UNPROCESSABLE_CONTENT). */
  UNPROCESSABLE("CRUD.UNPROCESSABLE", HttpStatus.UNPROCESSABLE_CONTENT);

  private final String code;
  private final HttpStatus status;

  CrudErrorType(String code, HttpStatus status) {
    this.code = code;
    this.status = status;
  }

  @Override
  public String code() {
    return code;
  }

  @Override
  public HttpStatus httpStatus() {
    return status;
  }
}
