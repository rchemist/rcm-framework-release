/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 2 task #3 — 보안 응답 헤더 default 적용 (Decision #1 후속). 각 헤더는 yml override 가능
 * ({@code platform.web.security-headers.*}). null 또는 빈 문자열로 설정 시 해당 헤더는 응답에 박지 않음
 * (개별 opt-out). {@link #enabled()} = false 시 filter 자체 skip.
 *
 * <ul>
 *   <li>Content-Security-Policy: default-src 'self' (strict default)</li>
 *   <li>Strict-Transport-Security: max-age=31536000; includeSubDomains (1 year)</li>
 *   <li>X-Frame-Options: DENY</li>
 *   <li>X-Content-Type-Options: nosniff</li>
 *   <li>Referrer-Policy: strict-origin-when-cross-origin</li>
 * </ul>
 *
 * @param contentSecurityPolicy CSP 헤더 값 (null/empty = opt-out)
 * @param strictTransportSecurity HSTS 헤더 값 (null/empty = opt-out)
 * @param xFrameOptions X-Frame-Options 값 (null/empty = opt-out)
 * @param xContentTypeOptions X-Content-Type-Options 값 (null/empty = opt-out)
 * @param referrerPolicy Referrer-Policy 값 (null/empty = opt-out)
 * @param enabled filter 활성화 여부 (default true)
 */
@ConfigurationProperties("platform.web.security-headers")
public record SecurityHeadersProperties(
    @DefaultValue("default-src 'self'") String contentSecurityPolicy,
    @DefaultValue("max-age=31536000; includeSubDomains") String strictTransportSecurity,
    @DefaultValue("DENY") String xFrameOptions,
    @DefaultValue("nosniff") String xContentTypeOptions,
    @DefaultValue("strict-origin-when-cross-origin") String referrerPolicy,
    @DefaultValue("true") boolean enabled
) {

  /** strict default 적용 — Phase 2 task #3, 청사진 §9 task 2.3. */
  public static final String DEFAULT_CSP = "default-src 'self'";
  public static final String DEFAULT_HSTS = "max-age=31536000; includeSubDomains";
  public static final String DEFAULT_X_FRAME_OPTIONS = "DENY";
  public static final String DEFAULT_X_CONTENT_TYPE_OPTIONS = "nosniff";
  public static final String DEFAULT_REFERRER_POLICY = "strict-origin-when-cross-origin";

  /** No-arg factory — yml 부재 시 모든 default 적용 + enabled=true. */
  public static SecurityHeadersProperties defaults() {
    return new SecurityHeadersProperties(
        DEFAULT_CSP,
        DEFAULT_HSTS,
        DEFAULT_X_FRAME_OPTIONS,
        DEFAULT_X_CONTENT_TYPE_OPTIONS,
        DEFAULT_REFERRER_POLICY,
        true);
  }
}
