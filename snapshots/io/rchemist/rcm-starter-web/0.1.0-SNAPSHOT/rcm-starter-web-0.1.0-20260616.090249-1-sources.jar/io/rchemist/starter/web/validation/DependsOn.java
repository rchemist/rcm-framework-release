/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (5) — 종속 필드 표시. field A 가 *채워질 때만* 본 필드의 검증을 강제 / 활성. Bean Validation 표준
 * 어노테이션 (예: {@code @NotBlank}) 와 결합하여 *조건부 필수* 를 표현.
 *
 * <p>예: {@code @DependsOn("paymentMethod") @NotBlank private String cardNumber;} — paymentMethod 가
 * 채워졌을 때만 cardNumber 가 필수.
 *
 * <p>실제 평가 엔진 결합은 Phase 3 의 advisor 에서 — 본 어노테이션은 Phase 2 baseline 적용 (marker + reflection
 * inspection). {@link ValidationRule} SPI 와도 결합 가능.
 */
@Target({FIELD, METHOD})
@Retention(RUNTIME)
public @interface DependsOn {

    /** 의존 필드명 — 본 필드가 채워질 때만 본 어노테이션 적용 필드의 검증이 활성. */
    String value();

    /** 활성 조건 — default {@link Mode#NOT_NULL_OR_BLANK}. */
    Mode mode() default Mode.NOT_NULL_OR_BLANK;

    /** 에러 코드 — 명시 부재 시 {@code "VALIDATION.DEPENDS_ON"} default. */
    String code() default "VALIDATION.DEPENDS_ON";

    /** 메시지 또는 message key — 명시 부재 시 {@code code} 그대로. */
    String message() default "";

    /** 종속 활성 모드 — 의존 필드의 어떤 상태에서 본 필드가 필수가 되는지 표현. */
    enum Mode {
        /** 의존 필드가 null 도 blank 도 아닐 때 (default). */
        NOT_NULL_OR_BLANK,
        /** 의존 필드가 non-null 일 때 (blank 허용). */
        NOT_NULL,
        /** 의존 필드가 null 일 때 (음의 종속). */
        IS_NULL
    }
}
