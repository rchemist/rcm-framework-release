/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.util;

import jakarta.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 — best-effort client IP 추출. RFC 7239 {@code Forwarded} > {@code
 * X-Forwarded-For} > {@code X-Real-IP} > {@link HttpServletRequest#getRemoteAddr()}.
 *
 * <p>각 후보 IP 는 {@link #isValidIp(String)} 로 IPv4 / IPv6 literal 검증 — invalid 면 다음 chain.
 * 모든 chain 이 invalid 이면 {@code request.getRemoteAddr()} 그대로 (network layer 신뢰).
 *
 * <p>차이점 — {@code rcm-starter-security} 의 {@code RemoteAddressResolver} = {@code
 * TrustedProxyFilter} 통과 후 신뢰 chain 가정. 본 utility = trust 가정 0, 단순 best-effort. 보안 영역
 * (rate limit / idempotency) = security 의 resolver, 일반 영역 (logging / audit) = 본 utility.
 **/
public final class ClientIpResolver {

  private static final Pattern IPV4 =
      Pattern.compile("^(?:(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d)$");
  private static final Pattern IPV6 = Pattern.compile("^[0-9a-fA-F:]+$");

  private ClientIpResolver() {
    throw new UnsupportedOperationException("static utility");
  }

  /** Chain 적용 — Forwarded > X-Forwarded-For > X-Real-IP > remoteAddr. */
  public static String resolve(HttpServletRequest request) {
    String forwarded = parseForwarded(request.getHeader("Forwarded"));
    if (forwarded != null && isValidIp(forwarded)) {
      return forwarded;
    }
    String xff = parseXForwardedFor(request.getHeader("X-Forwarded-For"));
    if (xff != null && isValidIp(xff)) {
      return xff;
    }
    String real = trim(request.getHeader("X-Real-IP"));
    if (real != null && isValidIp(real)) {
      return real;
    }
    return request.getRemoteAddr();
  }

  /** RFC 7239 {@code Forwarded: for=...} 의 첫 번째 {@code for} value 추출. quoted IPv6 unwrap. */
  static String parseForwarded(String header) {
    if (header == null || header.isBlank()) {
      return null;
    }
    String[] elements = header.split(",");
    for (String element : elements) {
      for (String pair : element.split(";")) {
        String trimmed = pair.trim();
        if (trimmed.regionMatches(true, 0, "for=", 0, 4)) {
          String value = trimmed.substring(4).trim();
          if (value.startsWith("\"") && value.endsWith("\"") && value.length() >= 2) {
            value = value.substring(1, value.length() - 1);
          }
          if (value.startsWith("[")) {
            int closeBracket = value.indexOf(']');
            if (closeBracket > 0) {
              return value.substring(1, closeBracket);
            }
          }
          int colon = value.lastIndexOf(':');
          if (colon > 0 && value.indexOf(':') == colon) {
            return value.substring(0, colon);
          }
          return value;
        }
      }
    }
    return null;
  }

  /** {@code X-Forwarded-For: client, proxy1, proxy2} 의 첫 번째 IP. */
  static String parseXForwardedFor(String header) {
    if (header == null || header.isBlank()) {
      return null;
    }
    int comma = header.indexOf(',');
    String first = (comma < 0 ? header : header.substring(0, comma)).trim();
    return first.isEmpty() ? null : first;
  }

  /** IPv4 literal (0-255 dotted) 또는 IPv6 literal (hex + colon) 검증. DNS lookup 0. */
  public static boolean isValidIp(String s) {
    if (s == null || s.isBlank()) {
      return false;
    }
    if (IPV4.matcher(s).matches()) {
      return true;
    }
    if (s.contains(":") && IPV6.matcher(s).matches() && s.length() >= 2) {
      return s.indexOf(':') != s.lastIndexOf(':') || s.contains("::");
    }
    return false;
  }

  private static String trim(String s) {
    if (s == null) {
      return null;
    }
    String t = s.trim();
    return t.isEmpty() ? null : t;
  }
}
