/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.aot;

import io.rchemist.core.error.FieldErrorEntry;
import io.rchemist.core.error.ServiceException;
import io.rchemist.core.search.BulkDeleteRequest;
import io.rchemist.core.search.EntityViewType;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.NormalSortInfo;
import io.rchemist.core.search.PrioritySortInfo;
import io.rchemist.core.search.QueryConditionType;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SearchResponse;
import io.rchemist.core.search.SortInfo;
import io.rchemist.core.search.UnmappedJoin;
import org.springframework.aot.hint.MemberCategory;
import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;
import org.springframework.http.ProblemDetail;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T0-8 (Decision #4) — AOT / GraalVM native image baseline. {@link
 * RuntimeHintsRegistrar} SPI 가 Spring 의 {@code META-INF/spring/aot.factories} 자동 발견 → AOT 컴파일
 * 시점에 framework core wire-format / 응답 / 예외 type 들을 reflection 등록.
 *
 * <p>등록 영역 (Records / sealed / enum / Records 응답 / 예외 wire format):
 * <ul>
 *   <li>SearchRequest + SortInfo (sealed) + NormalSortInfo + PrioritySortInfo + FilterItem +
 *       UnmappedJoin + BulkDeleteRequest — universal SearchRequest wire format (Decision §5.5)</li>
 *   <li>SearchResponse + EntityViewType — Decision #31 정합 풍부 응답</li>
 *   <li>QueryConditionType + LogicalOperator — enum (24 condition + AND/OR/NOT)</li>
 *   <li>ProblemDetail + FieldErrorEntry + ServiceException — Decision #1 + #24 ProblemDetail wire
 *       format (Spring 가 ProblemDetail 자체는 자동, FieldErrorEntry / ServiceException 명시)</li>
 * </ul>
 *
 * <p>Consumer 도메인 entity / Records / 응답 DTO 는 Spring Boot 의 {@code @RegisterReflection} 또는
 * Consumer 자체의 {@link RuntimeHintsRegistrar} 등록 — framework 가 알 수 없음. 본 hook 은
 * *framework 자체 wire-format 만* baseline.
 *
 * <p>Phase 0.2.0 + AOT 트랙 보강 — entity_metadata (APT generated) 자동 reflection 등록 등 자동 SPI
 * 확장 영역.
 */
public class FrameworkRuntimeHints implements RuntimeHintsRegistrar {

  @Override
  public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
    // SearchRequest wire format + Records (Decision §5.5 + Decision #31)
    registerWithMembers(hints, SearchRequest.class);
    registerWithMembers(hints, SearchResponse.class);
    registerWithMembers(hints, FilterItem.class);
    registerWithMembers(hints, UnmappedJoin.class);
    registerWithMembers(hints, BulkDeleteRequest.class);

    // SortInfo sealed hierarchy
    registerWithMembers(hints, SortInfo.class);
    registerWithMembers(hints, NormalSortInfo.class);
    registerWithMembers(hints, PrioritySortInfo.class);

    // Enums (24 condition + AND/OR/NOT + 4 view mode)
    registerWithMembers(hints, QueryConditionType.class);
    registerWithMembers(hints, LogicalOperator.class);
    registerWithMembers(hints, EntityViewType.class);

    // ProblemDetail wire format (Decision #1 + #24)
    registerWithMembers(hints, ProblemDetail.class);
    registerWithMembers(hints, FieldErrorEntry.class);
    registerWithMembers(hints, ServiceException.class);
  }

  /** type 의 *모든 reflection 영역* (생성자 / public 메서드 / Records component) 등록. */
  private static void registerWithMembers(RuntimeHints hints, Class<?> type) {
    hints.reflection().registerType(type,
        MemberCategory.INVOKE_DECLARED_CONSTRUCTORS,
        MemberCategory.INVOKE_DECLARED_METHODS,
        MemberCategory.ACCESS_DECLARED_FIELDS);
  }
}
