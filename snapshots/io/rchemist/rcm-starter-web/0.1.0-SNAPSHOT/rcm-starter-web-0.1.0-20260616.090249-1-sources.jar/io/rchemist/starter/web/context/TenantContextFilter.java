/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import io.rchemist.core.context.TenantContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — {@link TenantContextFilter} (Decision #17). request 진입 시 단일 active resolver
 * 로 tenant id 추출 → {@link TenantContext} ScopedValue chain. 미식별 시 {@link
 * TenantContext#SYSTEM_TENANT_ID} fallback (Background 영역 정합).
 *
 * <p>{@link Order} = {@link Ordered#HIGHEST_PRECEDENCE} {@code +15} — {@link RequestContextFilter}
 * (HIGHEST+10) 다음. RequestContext 가 traceId / X-Request-Id 적용 후 본 filter 가 TenantContext
 * 적용 → downstream chain 두 ScopedValue 모두 인입.
 **/
@Order(Ordered.HIGHEST_PRECEDENCE + 15)
public class TenantContextFilter extends OncePerRequestFilter {

  private final TenantContextFilterResolver resolver;

  public TenantContextFilter(TenantContextFilterResolver resolver) {
    this.resolver = resolver;
  }

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    String tenantId = resolver.resolveTenantId(request).orElse(TenantContext.SYSTEM_TENANT_ID);
    TenantContext ctx = new TenantContext(tenantId, null);

    ServletException[] servletEx = new ServletException[1];
    IOException[] ioEx = new IOException[1];
    RuntimeException[] runtimeEx = new RuntimeException[1];

    TenantContext.runWith(
        ctx,
        () -> {
          try {
            chain.doFilter(request, response);
          } catch (ServletException e) {
            servletEx[0] = e;
          } catch (IOException e) {
            ioEx[0] = e;
          } catch (RuntimeException e) {
            runtimeEx[0] = e;
          }
        });

    if (servletEx[0] != null) {
      throw servletEx[0];
    }
    if (ioEx[0] != null) {
      throw ioEx[0];
    }
    if (runtimeEx[0] != null) {
      throw runtimeEx[0];
    }
  }
}
