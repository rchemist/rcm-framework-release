/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — 0.0.5 의 {@code @Example} 시그니처 흡수. parameter 단위 OpenAPI Parameter
 * example 메타데이터. APT 가 추출, 런타임 customizer 가 springdoc Operation parameter 에 합산.
 *
 * <ul>
 *   <li>{@link #name()} — 예시 이름 (Swagger UI 의 예시 라벨)</li>
 *   <li>{@link #value()} — 예시 값</li>
 *   <li>{@link #summary()} — 예시 요약</li>
 * </ul>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.PARAMETER)
public @interface Example {

  /** 예시 이름. */
  String name() default "";

  /** 예시 값. */
  String value() default "";

  /** 예시 요약. */
  String summary() default "";
}
