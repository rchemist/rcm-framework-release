/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 2 task #3 — multipart 안전 default 적용 (청사진 §9 task 2.4). yml override
 * ({@code platform.web.multipart-safety.*}). {@link #enabled()} = false 시 filter 자체 skip.
 *
 * <ul>
 *   <li>Path traversal 차단 — filename canonicalize, {@code ../} / null byte / 절대경로 reject</li>
 *   <li>매직바이트 검증 — Content-Type 과 파일 매직바이트 매칭 (image/jpeg / image/png / application/pdf
 *       / application/zip)</li>
 *   <li>ZIP Slip 차단 — application/zip 또는 .zip 확장자 entry path 검증</li>
 *   <li>max-file-size / max-request-size — 단일 파일 / 전체 요청 size 제한</li>
 * </ul>
 *
 * @param enabled filter 활성화 여부 (default true)
 * @param maxFileSize 단일 파일 max byte (default 10MB, 0 또는 음수 = unlimited)
 * @param maxRequestSize 전체 multipart request max byte (default 50MB, 0 또는 음수 = unlimited)
 * @param checkMagicBytes 매직바이트 검증 활성화 (default true)
 * @param checkZipSlip ZIP slip 차단 활성화 (default true)
 * @param magicBytes contentType → magic bytes hex string mapping (예 "FFD8" = JPEG)
 */
@ConfigurationProperties("platform.web.multipart-safety")
public record MultipartSafetyProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("10485760") long maxFileSize,
    @DefaultValue("52428800") long maxRequestSize,
    @DefaultValue("true") boolean checkMagicBytes,
    @DefaultValue("true") boolean checkZipSlip,
    Map<String, String> magicBytes
) {

  /** 10 MB. */
  public static final long DEFAULT_MAX_FILE_SIZE = 10L * 1024 * 1024;

  /** 50 MB. */
  public static final long DEFAULT_MAX_REQUEST_SIZE = 50L * 1024 * 1024;

  /** 표준 매직바이트 4 종 적용 — yml 로 추가 가능. */
  public MultipartSafetyProperties {
    if (magicBytes == null || magicBytes.isEmpty()) {
      magicBytes = defaultMagicBytes();
    }
  }

  /**
   * 표준 매직바이트 default 4 종:
   * <ul>
   *   <li>image/jpeg = FF D8</li>
   *   <li>image/png = 89 50 4E 47</li>
   *   <li>application/pdf = 25 50 44 46</li>
   *   <li>application/zip = 50 4B 03 04</li>
   * </ul>
   */
  public static Map<String, String> defaultMagicBytes() {
    Map<String, String> m = new LinkedHashMap<>();
    m.put("image/jpeg", "FFD8");
    m.put("image/png", "89504E47");
    m.put("application/pdf", "25504446");
    m.put("application/zip", "504B0304");
    return m;
  }

  /** No-arg factory — yml 부재 시 default 적용 + enabled=true. */
  public static MultipartSafetyProperties defaults() {
    return new MultipartSafetyProperties(
        true,
        DEFAULT_MAX_FILE_SIZE,
        DEFAULT_MAX_REQUEST_SIZE,
        true,
        true,
        defaultMagicBytes());
  }
}
