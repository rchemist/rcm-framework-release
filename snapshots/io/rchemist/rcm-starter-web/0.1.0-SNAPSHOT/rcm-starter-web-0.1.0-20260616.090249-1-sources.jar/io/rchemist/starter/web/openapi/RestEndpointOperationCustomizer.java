/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import io.swagger.v3.oas.models.Operation;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.web.method.HandlerMethod;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — {@link RestEndpoint} 자동 인식 후 springdoc 의 {@link Operation} 객체 갱신.
 *
 * <p>매핑 규칙 (0.0.5 호출 패턴 100% 보존):
 * <ul>
 *   <li>{@link RestEndpoint#summary()} → {@link Operation#summary(String)} (비어있을 때만)</li>
 *   <li>{@link RestEndpoint#description()} → {@link Operation#description(String)} (비어있을 때만)</li>
 *   <li>{@link RestEndpoint#tag()} → {@link Operation#addTagsItem(String)} (이미 적용된 tag 와 합산)</li>
 *   <li>{@link RestEndpoint#deprecated()} → {@link Operation#setDeprecated(Boolean)}</li>
 *   <li>{@link RestEndpoint#operationId()} → {@link Operation#operationId(String)} (비어있을 때만)</li>
 * </ul>
 *
 * <p>적용 영역 외 (Operation 의 parameters / responses / requestBody) 는 springdoc 의 표준 처리 그대로
 * — Spring MVC annotation ({@code @PathVariable} / {@code @RequestBody} / 반환 타입) 을 직접 inspect.
 *
 * <p>OperationCustomizer 는 startup 시점 1 회 reflection (charter §1 원칙 7 trade-off, task #6 본문 명시).
 * 컴파일 타임 reflection 0 정책은 {@link RestEndpointProcessor} (APT) 영역.
 */
public class RestEndpointOperationCustomizer implements OperationCustomizer {

  @Override
  public Operation customize(Operation operation, HandlerMethod handlerMethod) {
    RestEndpoint endpoint = handlerMethod.getMethodAnnotation(RestEndpoint.class);
    if (endpoint == null) {
      return operation;
    }
    if (!endpoint.summary().isEmpty()
        && (operation.getSummary() == null || operation.getSummary().isEmpty())) {
      operation.summary(endpoint.summary());
    }
    if (!endpoint.description().isEmpty()
        && (operation.getDescription() == null || operation.getDescription().isEmpty())) {
      operation.description(endpoint.description());
    }
    if (!endpoint.tag().isEmpty()) {
      // Consumer 가 명시한 tag 가 우선 — springdoc default (controller class name kebab-case) 대신
      // 명시값 단독 list 로 적용. Consumer 의 0.0.5 호출 패턴 정합.
      operation.setTags(new java.util.ArrayList<>(java.util.List.of(endpoint.tag())));
    }
    if (endpoint.deprecated()) {
      operation.setDeprecated(true);
    }
    if (!endpoint.operationId().isEmpty()) {
      // 명시값 우선 — springdoc 가 default 로 메소드명을 set 하므로 비어있을 때 조건은 거의 X.
      // Consumer 가 명시한 ID 가 있으면 override (0.0.5 호출 패턴 정합).
      operation.operationId(endpoint.operationId());
    }
    return operation;
  }
}
