/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import io.rchemist.core.context.TenantContext;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.context.HierarchicalMessageSource;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (4) — tenant 별 properties wrapper. Decision #17 정합 (multi-tenant 3 전략 baseline).
 *
 * <p>동작 모델:
 * <ul>
 *   <li>{@code tenantSpecific=false} (Phase 2 baseline) — delegate {@link MessageSource} 그대로 위임.</li>
 *   <li>{@code tenantSpecific=true} (Phase 3 진입 시) — {@link TenantContext#currentTenantIdOrNull()} 가
 *       있으면 tenant 별 {@link ResourceBundleMessageSource} 우선 lookup → 부재 시 default delegate fallback.
 *       tenant 별 source 는 {@code tenantBasenamePattern} 의 {@code {tenant}} placeholder 로 build (예:
 *       {@code validation-messages-acme}). cache 는 ConcurrentHashMap 으로 lazy 적용.</li>
 * </ul>
 *
 * <p>본 wrapper 는 {@link MessageSource} 를 implements 하므로 Spring 의 모든 MessageSource 사용 지점에서 그대로
 * inject 가능 — {@link ResourceBundleMessageSource} 와 substitutable.
 */
public class TenantMessageSource implements MessageSource {

    private final MessageSource delegate;
    private final ValidationMessageProperties properties;
    private final Map<String, MessageSource> tenantSources = new ConcurrentHashMap<>();
    private final String defaultEncoding;

    public TenantMessageSource(MessageSource delegate, ValidationMessageProperties properties) {
        this.delegate = Objects.requireNonNull(delegate, "delegate");
        this.properties = Objects.requireNonNull(properties, "properties");
        this.defaultEncoding = "UTF-8";
    }

    /**
     * 후보 message key list 를 순회하면서 첫 번째 hit 메시지를 반환. 모두 미스 시 마지막 key 의 fallback (코드 자체) 반환.
     *
     * <p>args 가 non-null 일 때 MessageFormat 가 적용 — properties 의 placeholder 는 {@code {0}, {1}} 인덱스
     * 형식이어야 함 (Spring 표준). Hibernate Validator 식 named placeholder ({@code {min}, {max}}) 가 properties 에
     * 적용되어 있으면 args 인자로 인해 NumberFormatException 발생할 수 있어 *args 가 named placeholder 를 만나면 args=null
     * 로 retry* 하여 안전 fallback.
     *
     * @param keys 우선순위 순서의 후보 list
     * @param args i18n placeholder 인자
     * @param locale locale (null = default)
     * @return 첫 hit 메시지 또는 마지막 key 그대로
     */
    public String resolveFirst(List<String> keys, Object[] args, Locale locale) {
        Locale resolved = locale == null ? properties.resolvedDefaultLocale() : locale;
        if (keys == null || keys.isEmpty()) {
            return null;
        }
        for (int i = 0; i < keys.size() - 1; i++) {
            String key = keys.get(i);
            String msg = lookupOrNull(key, args, resolved);
            if (msg != null) {
                return msg;
            }
        }
        // 마지막 key 는 fqn fallback. 부재 시 key 자체 반환 (NoSuchMessageException 회피).
        String last = keys.get(keys.size() - 1);
        String msg = lookupOrNull(last, args, resolved);
        return msg == null ? last : msg;
    }

    private String lookupOrNull(String key, Object[] args, Locale locale) {
        // 1) tenant-specific 우선
        if (properties.tenantSpecific()) {
            String tenantId = TenantContext.currentTenantIdOrNull();
            if (tenantId != null && !tenantId.isBlank()
                && !TenantContext.SYSTEM_TENANT_ID.equals(tenantId)) {
                MessageSource tenantSource = tenantSources.computeIfAbsent(tenantId, this::buildTenantSource);
                String msg = safeGetMessage(tenantSource, key, args, locale);
                if (msg != null && !msg.isBlank()) {
                    return msg;
                }
            }
        }
        // 2) default delegate
        return safeGetMessage(delegate, key, args, locale);
    }

    /**
     * MessageSource lookup with NumberFormatException safety. Hibernate-style {@code {min}/{max}} named
     * placeholder 가 properties 에 적용되어 있을 때 args 비어있지 않으면 MessageFormat NumberFormatException 발생 →
     * args=null 로 retry 하여 raw 메시지 반환 (placeholder 가 literal 로 노출되지만 fallback 으로 defaultMessage 로
     * 외부 caller 가 전환 가능).
     */
    private String safeGetMessage(MessageSource source, String key, Object[] args, Locale locale) {
        try {
            return source.getMessage(key, args, locale);
        } catch (NoSuchMessageException e) {
            return null;
        } catch (IllegalArgumentException e) {
            // NumberFormatException → IllegalArgumentException (MessageFormat 의 {min} 같은 이름은 숫자로 파싱 실패).
            // args=null 로 retry — placeholder 가 literal 로 남지만 외부 caller 의 fallback 영역.
            try {
                return source.getMessage(key, null, locale);
            } catch (NoSuchMessageException ignored) {
                return null;
            }
        }
    }

    private MessageSource buildTenantSource(String tenantId) {
        ResourceBundleMessageSource src = new ResourceBundleMessageSource();
        String basename = properties.tenantBasenamePattern().replace("{tenant}", tenantId);
        src.setBasenames(basename);
        src.setDefaultEncoding(defaultEncoding);
        src.setUseCodeAsDefaultMessage(false);
        src.setFallbackToSystemLocale(false);
        if (delegate instanceof HierarchicalMessageSource hierarchical) {
            // delegate 가 hierarchical 이면 parent 로 묶어 default fallback 자동
            src.setParentMessageSource(hierarchical);
        } else {
            src.setParentMessageSource(delegate);
        }
        return src;
    }

    // -----------------------------------------------------------------
    // MessageSource implementation — delegate-first 단일 호출 (resolveFirst 와 별개로 plain lookup)
    // -----------------------------------------------------------------

    @Override
    public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
        String msg = lookupOrNull(code, args, locale == null ? properties.resolvedDefaultLocale() : locale);
        return msg == null ? defaultMessage : msg;
    }

    @Override
    public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
        String msg = lookupOrNull(code, args, locale == null ? properties.resolvedDefaultLocale() : locale);
        if (msg == null) {
            throw new NoSuchMessageException(code, locale);
        }
        return msg;
    }

    @Override
    public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException {
        return delegate.getMessage(resolvable, locale == null ? properties.resolvedDefaultLocale() : locale);
    }
}
