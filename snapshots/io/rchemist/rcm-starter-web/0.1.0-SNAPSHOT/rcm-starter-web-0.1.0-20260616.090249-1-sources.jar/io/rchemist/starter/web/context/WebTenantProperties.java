/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — Multi-tenant request 단 식별 영역 yml (Decision #17). starter-web 한정 —
 * starter-jpa 의 strategy / column 영역과 분리 (같은 yml prefix {@code platform.tenant} 두 record
 * 적용).
 *
 * <p>{@code resolver} = {@code HEADER|SUBDOMAIN|PATH_PREFIX|SPI} (Phase 3 baseline 4 종, JWT_CLAIM
 * 은 Phase 5 security 영역). {@code header} = X-Tenant-Id default. {@code subdomainIndex} = host
 * 의 segment index 0-based. {@code pathPrefix} = URI prefix (예: {@code /t/} → {@code /t/foo/...}
 * 의 {@code foo} tenant).
 **/
@ConfigurationProperties(prefix = "platform.tenant")
public record WebTenantProperties(
    @DefaultValue("HEADER") Resolver resolver,
    @DefaultValue("X-Tenant-Id") String header,
    @DefaultValue("0") int subdomainIndex,
    @DefaultValue("/t/") String pathPrefix) {

  public enum Resolver {
    HEADER,
    SUBDOMAIN,
    PATH_PREFIX,
    SPI
  }
}
