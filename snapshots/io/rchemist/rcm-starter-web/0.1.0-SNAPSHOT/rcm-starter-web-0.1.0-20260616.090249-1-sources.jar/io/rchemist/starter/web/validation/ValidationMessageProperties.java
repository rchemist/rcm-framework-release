/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import java.util.List;
import java.util.Locale;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * web-validation 5 영역 통합 (Decision #23) 의 Configuration Properties — Records first.
 *
 * <p>속성 영역:
 * <ul>
 *   <li>{@code basenames} — ResourceBundle basenames (default: {@code validation-messages}).
 *       Consumer 가 자체 properties 추가 가능.</li>
 *   <li>{@code defaultLocale} — fallback locale (default: ko).</li>
 *   <li>{@code tenantSpecific} — tenant 별 properties lookup 활성 (default: false; Phase 2 baseline 단일 tenant
 *       기본값. Phase 3 multi-tenant 진입 시 true 로 전환).</li>
 *   <li>{@code tenantBasenamePattern} — tenant 별 properties 의 basename pattern.
 *       {@code {tenant}} placeholder = tenantId 치환. default: {@code validation-messages-{tenant}}.</li>
 * </ul>
 *
 * @param basenames ResourceBundle basename list
 * @param defaultLocale fallback locale
 * @param tenantSpecific tenant 별 lookup 활성 여부
 * @param tenantBasenamePattern tenant 별 basename 패턴
 */
@ConfigurationProperties("platform.web.validation")
public record ValidationMessageProperties(
    @DefaultValue("validation-messages") List<String> basenames,
    @DefaultValue("ko") String defaultLocale,
    @DefaultValue("false") boolean tenantSpecific,
    @DefaultValue("validation-messages-{tenant}") String tenantBasenamePattern) {

    public Locale resolvedDefaultLocale() {
        return Locale.forLanguageTag(defaultLocale);
    }
}
