/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.search;

import io.rchemist.core.search.SearchRequest;
import tools.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import java.io.InputStream;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring MVC argument resolver — controller method param 이 {@link SearchRequest} 면 자동 binding.
 *
 * <p>청사진 §5.5.1 + Phase 2 task #4 적용:
 * <ul>
 *   <li>POST + JSON body (default, frontend SearchForm 형식 정합) → Jackson 으로 deserialize</li>
 *   <li>GET + query string (단순 검색만) → {@link SearchRequestParser} 위임</li>
 *   <li>복잡한 GET → {@link SearchRequestParser.ComplexQueryException} → 400 ProblemDetail
 *       (advice 가 처리, code = {@code SEARCH.USE_POST_BODY})</li>
 * </ul>
 *
 * <p>{@code @RequestBody} / {@code @ModelAttribute} 어노테이션 *없이도* 자동 인식 — controller 의
 * sample method signature 가 {@code Page<T> search(SearchRequest req)} 인 패턴 정합.
 */
public class SearchRequestArgumentResolver implements HandlerMethodArgumentResolver {

    private final ObjectMapper objectMapper;

    public SearchRequestArgumentResolver(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return SearchRequest.class.equals(parameter.getParameterType());
    }

    @Override
    public Object resolveArgument(
        MethodParameter parameter,
        ModelAndViewContainer mavContainer,
        NativeWebRequest webRequest,
        WebDataBinderFactory binderFactory
    ) throws Exception {
        HttpServletRequest req = webRequest.getNativeRequest(HttpServletRequest.class);
        if (req == null) {
            return SearchRequest.empty();
        }

        String method = req.getMethod();
        if ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method)) {
            // JSON body 우선 — frontend rcm-listgrid SearchForm 형식 정합.
            try (InputStream in = req.getInputStream()) {
                if (in == null || in.available() == 0) {
                    return SearchRequest.empty();
                }
                byte[] bytes = in.readAllBytes();
                if (bytes.length == 0) {
                    return SearchRequest.empty();
                }
                return objectMapper.readValue(bytes, SearchRequest.class);
            }
        }

        // GET / DELETE 등 — query string 영역 (단순 검색).
        return SearchRequestParser.parse(req);
    }
}
