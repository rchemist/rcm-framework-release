/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Duration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 — Cookie 발급 / 조회 / 삭제 단일 단위. Spring {@link ResponseCookie} 기반
 * Set-Cookie 헤더 발급 (SameSite 표준 지원).
 *
 * <p>발급 default — {@link SameSite#LAX} / Secure(request.isSecure()) / HttpOnly(true). Consumer
 * 가 명시 인입 시 override.
 **/
public final class CookieHelper {

  private CookieHelper() {
    throw new UnsupportedOperationException("static utility");
  }

  /** SameSite=Lax default. */
  public static void setCookie(
      HttpServletRequest request,
      HttpServletResponse response,
      String name,
      String value,
      Duration maxAge,
      String path) {
    setCookie(request, response, name, value, maxAge, path, SameSite.LAX);
  }

  /** SameSite 명시 override. */
  public static void setCookie(
      HttpServletRequest request,
      HttpServletResponse response,
      String name,
      String value,
      Duration maxAge,
      String path,
      SameSite sameSite) {
    ResponseCookie cookie =
        ResponseCookie.from(name, value)
            .maxAge(maxAge)
            .path(path)
            .secure(request.isSecure())
            .httpOnly(true)
            .sameSite(sameSite.value())
            .build();
    response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());
  }

  /** Cookie 조회 — 첫 매칭 wins. */
  public static String getCookie(HttpServletRequest request, String name) {
    Cookie[] cookies = request.getCookies();
    if (cookies == null) {
      return null;
    }
    for (Cookie c : cookies) {
      if (c.getName().equals(name)) {
        return c.getValue();
      }
    }
    return null;
  }

  /** Cookie 삭제 — Max-Age=0 + 빈 value. Path 필수 (발급 시 path 와 동일해야 브라우저가 삭제). */
  public static void deleteCookie(HttpServletResponse response, String name, String path) {
    ResponseCookie cookie = ResponseCookie.from(name, "").maxAge(0).path(path).build();
    response.addHeader(HttpHeaders.SET_COOKIE, cookie.toString());
  }

  /** SameSite policy enum (브라우저 표준 3 종). */
  public enum SameSite {
    LAX("Lax"),
    STRICT("Strict"),
    NONE("None");

    private final String value;

    SameSite(String value) {
      this.value = value;
    }

    public String value() {
      return value;
    }
  }
}
