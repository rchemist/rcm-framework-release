/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import io.rchemist.core.error.ErrorCollector;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (5) — cross-field validation SPI. 단일 필드 영역 (Bean Validation 표준) 으로 표현 불가능한
 * 다중 필드 규칙 (예: {@code password == confirmPassword}, {@code startDate < endDate}) 을 적용.
 *
 * <p>구현체는 {@link ErrorCollector} 에 누적 — Consumer 가 명시적으로 호출하거나, framework 가 advisor 등으로 자동 호출하는
 * 두 가지 사용 패턴 모두 지원. 누적된 결과는 {@code ErrorCollector#throwIfPresent()} 로 throw → ProblemDetailAdvice 가
 * RFC 7807 응답으로 변환.
 *
 * @param <T> 대상 타입 (DTO / form / entity 등)
 */
@FunctionalInterface
public interface ValidationRule<T> {

    /**
     * 대상 객체에 규칙 적용. 위반 시 {@code collector.add(...)} 로 누적.
     *
     * @param target 검증 대상 (non-null 가정)
     * @param collector 위반 누적 collector
     */
    void validate(T target, ErrorCollector collector);
}
