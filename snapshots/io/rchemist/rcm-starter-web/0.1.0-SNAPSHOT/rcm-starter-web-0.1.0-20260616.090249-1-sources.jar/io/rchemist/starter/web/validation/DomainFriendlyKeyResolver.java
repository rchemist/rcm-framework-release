/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.metadata.ConstraintDescriptor;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.FieldError;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (2) — 도메인 friendly key 자동 lookup.
 *
 * <p>3 단계 lookup + fqn fallback 후보 list 를 우선순위 순으로 생성:
 * <ol>
 *   <li>{@code field.<Entity>.<property>.<Constraint>} — 가장 구체 (예:
 *       {@code field.User.email.NotBlank}).</li>
 *   <li>{@code field.<Entity>.<property>} — entity-property 단위 default.</li>
 *   <li>{@code field.<property>.<Constraint>} — entity 모르고 property 만 알 때.</li>
 *   <li>{@code field.<property>} — property 단위 default.</li>
 *   <li>{@code jakarta.validation.constraints.<Constraint>.message} — fqn fallback.</li>
 * </ol>
 *
 * <p>{@code ProblemDetailAdvice} 는 본 list 를 {@link TenantMessageSource} 에 순차 전달 — 첫 hit 메시지를
 * problem detail 의 errors[].message 로 적용.
 */
public final class DomainFriendlyKeyResolver {

    private static final String FIELD_PREFIX = "field.";
    private static final String JAKARTA_CONSTRAINTS_PACKAGE = "jakarta.validation.constraints.";
    private static final String MESSAGE_SUFFIX = ".message";

    private DomainFriendlyKeyResolver() {
        // utility
    }

    /**
     * Spring {@link FieldError} 기반 후보 list 생성. fieldError 의
     * {@link FieldError#getObjectName()} 을 entity 로 사용 (Spring binding result 의 target object name —
     * 통상 controller method param 변수명 또는 form class simple name).
     *
     * @param fieldError Spring binding result fieldError
     * @return 우선순위 순서의 message key 후보 list
     */
    public static List<String> resolve(FieldError fieldError) {
        if (fieldError == null) {
            return List.of();
        }
        String entity = simpleEntityName(fieldError.getObjectName());
        String property = fieldError.getField();
        String constraint = fieldError.getCode();
        return resolve(entity, property, constraint);
    }

    /**
     * jakarta {@link ConstraintViolation} 기반 후보 list 생성. entity 는 root bean class 의 simple name,
     * property 는 path 의 마지막 node, constraint 는 annotation simple name.
     */
    public static List<String> resolve(ConstraintViolation<?> violation) {
        if (violation == null) {
            return List.of();
        }
        String entity = violation.getRootBean() == null ? null
            : violation.getRootBean().getClass().getSimpleName();
        String property = lastPathNode(violation);
        String constraint = constraintSimpleName(violation);
        return resolve(entity, property, constraint);
    }

    /**
     * entity / property / constraint 명시 호출. 각 인자는 null/blank 가능 — 부재 시 해당 단계 스킵.
     */
    public static List<String> resolve(String entity, String property, String constraint) {
        List<String> keys = new ArrayList<>(5);

        boolean hasEntity = entity != null && !entity.isBlank();
        boolean hasProperty = property != null && !property.isBlank();
        boolean hasConstraint = constraint != null && !constraint.isBlank();

        if (hasEntity && hasProperty && hasConstraint) {
            keys.add(FIELD_PREFIX + entity + "." + property + "." + constraint);
        }
        if (hasEntity && hasProperty) {
            keys.add(FIELD_PREFIX + entity + "." + property);
        }
        if (hasProperty && hasConstraint) {
            keys.add(FIELD_PREFIX + property + "." + constraint);
        }
        if (hasProperty) {
            keys.add(FIELD_PREFIX + property);
        }
        if (hasConstraint) {
            // jakarta 표준 + 사용자 정의 둘 다 fqn 후보로 적용. Bean Validation 표준 어노테이션은 jakarta 패키지 이므로
            // baseline 메시지가 본 키로 정의됨.
            keys.add(JAKARTA_CONSTRAINTS_PACKAGE + constraint + MESSAGE_SUFFIX);
        }
        return keys;
    }

    /**
     * Spring binding result 의 objectName 정규화 — 통상 first-letter-lower-camelCase (예: "samplePayload").
     * convention 대로 첫 글자 대문자화 → simple name 으로 변환 (예: "SamplePayload").
     */
    private static String simpleEntityName(String objectName) {
        if (objectName == null || objectName.isBlank()) {
            return null;
        }
        // path 의 dot 만 제거 (nested 인 경우 마지막 segment).
        String s = objectName;
        int dot = s.lastIndexOf('.');
        if (dot >= 0 && dot < s.length() - 1) {
            s = s.substring(dot + 1);
        }
        char first = s.charAt(0);
        if (Character.isLowerCase(first)) {
            s = Character.toUpperCase(first) + s.substring(1);
        }
        return s;
    }

    private static String lastPathNode(ConstraintViolation<?> violation) {
        if (violation.getPropertyPath() == null) {
            return null;
        }
        String last = null;
        for (jakarta.validation.Path.Node node : violation.getPropertyPath()) {
            if (node.getName() != null) {
                last = node.getName();
            }
        }
        return last;
    }

    private static String constraintSimpleName(ConstraintViolation<?> violation) {
        ConstraintDescriptor<?> descriptor = violation.getConstraintDescriptor();
        if (descriptor == null) {
            return null;
        }
        Annotation annotation = descriptor.getAnnotation();
        if (annotation == null) {
            return null;
        }
        return annotation.annotationType().getSimpleName();
    }
}
