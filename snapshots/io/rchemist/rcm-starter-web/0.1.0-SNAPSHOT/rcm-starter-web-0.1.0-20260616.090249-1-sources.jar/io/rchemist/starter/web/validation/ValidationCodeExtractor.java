/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.metadata.ConstraintDescriptor;
import java.lang.annotation.Annotation;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.validation.FieldError;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (3) — 에러 코드 자동 추출 utility.
 *
 * <p>변환 규칙:
 * <ul>
 *   <li>{@link ValidationCode @ValidationCode("X.Y")} 명시 시 → {@code "X.Y"} 우선.</li>
 *   <li>아니면 annotation simple name → SCREAMING_SNAKE_CASE 변환 → {@code VALIDATION.<NAME>}.
 *       예: {@code @NotBlank} → {@code VALIDATION.NOT_BLANK}, {@code @AssertTrue} →
 *       {@code VALIDATION.ASSERT_TRUE}.</li>
 *   <li>annotation 미상 시 → {@code VALIDATION.INVALID} fallback.</li>
 * </ul>
 *
 * <p>{@code ProblemDetailAdvice} 가 본 utility 를 호출하여 errors[] 의 code 를 일관 적용.
 */
public final class ValidationCodeExtractor {

    public static final String DEFAULT_CODE = "VALIDATION.INVALID";

    /** simple name → VALIDATION.SCREAMING_SNAKE 변환 cache (반복 호출 회피). */
    private static final Map<String, String> SIMPLE_NAME_CACHE = new ConcurrentHashMap<>();

    private ValidationCodeExtractor() {
        // utility
    }

    /**
     * Bean Validation {@link FieldError} 한 건의 에러 코드 추출.
     *
     * <p>Spring 의 {@link FieldError#getCode()} 는 constraint annotation simple name (예:
     * {@code "NotBlank"}). 본 메서드는 그 값을 기반으로 {@code VALIDATION.NOT_BLANK} 변환.
     *
     * @param fieldError Spring binding result fieldError
     * @return {@code VALIDATION.<NAME>} 또는 {@link #DEFAULT_CODE}
     */
    public static String extract(FieldError fieldError) {
        if (fieldError == null) {
            return DEFAULT_CODE;
        }
        // @ValidationCode 명시 — Spring FieldError 의 arguments 에 ConstraintDescriptor 노출 X.
        // FieldError 만 가지고 명시 옵션을 추출하는 표준 hook 부재 → annotation type 자동 변환에 의존.
        return fromSimpleName(fieldError.getCode());
    }

    /**
     * Spring binding result global error 한 건의 에러 코드 추출. global error 는 cross-field 영역 — 추출 규칙 동일.
     */
    public static String extractGlobal(String springErrorCode) {
        return fromSimpleName(springErrorCode);
    }

    /**
     * jakarta {@link ConstraintViolation} 한 건의 에러 코드 추출 — {@code @ValidationCode} 명시 우선.
     *
     * @param violation Bean Validation 위반
     * @return 명시 코드 또는 자동 변환 코드
     */
    public static String extract(ConstraintViolation<?> violation) {
        if (violation == null) {
            return DEFAULT_CODE;
        }
        ConstraintDescriptor<?> descriptor = violation.getConstraintDescriptor();
        if (descriptor == null) {
            return DEFAULT_CODE;
        }
        Annotation annotation = descriptor.getAnnotation();
        if (annotation == null) {
            return DEFAULT_CODE;
        }
        // 1) @ValidationCode 명시 (annotation 자체 또는 meta-annotation)
        Class<? extends Annotation> annoType = annotation.annotationType();
        ValidationCode meta = annoType.getAnnotation(ValidationCode.class);
        if (meta != null && meta.value() != null && !meta.value().isBlank()) {
            return meta.value();
        }
        // 2) annotation type → VALIDATION.<NAME>
        return fromAnnotationType(annoType);
    }

    /**
     * annotation 타입을 직접 변환 — {@code @NotBlank.class} → {@code "VALIDATION.NOT_BLANK"}.
     */
    public static String fromAnnotationType(Class<? extends Annotation> annotationType) {
        if (annotationType == null) {
            return DEFAULT_CODE;
        }
        return fromSimpleName(annotationType.getSimpleName());
    }

    /**
     * simple name 변환 — {@code "NotBlank"} → {@code "VALIDATION.NOT_BLANK"}, {@code "AssertTrue"} →
     * {@code "VALIDATION.ASSERT_TRUE"}, {@code "URL"} → {@code "VALIDATION.URL"}.
     */
    public static String fromSimpleName(String simpleName) {
        if (simpleName == null || simpleName.isBlank()) {
            return DEFAULT_CODE;
        }
        return SIMPLE_NAME_CACHE.computeIfAbsent(simpleName, ValidationCodeExtractor::convert);
    }

    private static String convert(String simpleName) {
        StringBuilder sb = new StringBuilder("VALIDATION.");
        int len = simpleName.length();
        for (int i = 0; i < len; i++) {
            char c = simpleName.charAt(i);
            if (Character.isUpperCase(c)) {
                if (i > 0) {
                    char prev = simpleName.charAt(i - 1);
                    boolean nextLower = i + 1 < len && Character.isLowerCase(simpleName.charAt(i + 1));
                    // upper → lower 경계 (예: "AssertTrue" 의 'T') 또는 lower → upper 경계 시 underscore 적용.
                    if (Character.isLowerCase(prev) || (Character.isUpperCase(prev) && nextLower)) {
                        sb.append('_');
                    }
                }
                sb.append(c);
            } else {
                sb.append(Character.toUpperCase(c));
            }
        }
        return sb.toString();
    }
}
