/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import java.util.Collections;
import org.springframework.boot.EnvironmentPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * VirtualThread default 적용 — Spring Boot 4 의 {@code spring.threads.virtual.enabled} opt-in
 * default 를 *framework default = true* 로 변경. Phase 1 의 {@code ScopedValue} 3 키
 * (RequestContext / TenantContext / UserContext) 와 짝 — VirtualThread context propagation
 * 의 official API. Consumer 가 application.yml 에서 명시 false 로 override 가능
 * (priority: command-line / OS env / application.* > 본 PostProcessor).
 * <p>
 * 적용 메커니즘: 가장 낮은 priority 의 PropertySource 로 추가하여 사용자 application.* 가
 * 무조건 우선. {@code META-INF/spring/org.springframework.boot.EnvironmentPostProcessor.imports}
 * 등록으로 SB 4 가 자동 탐색 (옛 {@code org.springframework.boot.env.EnvironmentPostProcessor}
 * 는 SB 4.0.0 부터 deprecated + removal 예정 → 새 package {@code org.springframework.boot} 로 이동).
 **/
public class VirtualThreadDefaultPropertiesPostProcessor
    implements EnvironmentPostProcessor, Ordered {

    public static final String PROPERTY_NAME = "spring.threads.virtual.enabled";
    public static final String SOURCE_NAME = "rcmFrameworkVirtualThreadDefaults";

    @Override
    public void postProcessEnvironment(
        ConfigurableEnvironment environment, SpringApplication application) {
        if (environment.getPropertySources().contains(SOURCE_NAME)) {
            return;
        }
        environment.getPropertySources().addLast(
            new MapPropertySource(
                SOURCE_NAME,
                Collections.singletonMap(PROPERTY_NAME, "true")));
    }

    /**
     * 가장 낮은 우선순위로 등록 — application.yml / 환경변수 / CLI args 등 모든 사용자 명시 값이 우선.
     */
    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
