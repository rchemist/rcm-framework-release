/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (5) — 조건부 validation. SpEL expression 또는 group 식별자로 활성 조건 표현. {@link DependsOn}
 * 보다 더 표현력 있는 조건 (다중 필드 / 메소드 호출 / context 의존 등) 을 적용.
 *
 * <p>예:
 * <ul>
 *   <li>{@code @When("status == 'PUBLISHED'") @NotBlank private String slug;} — published 일 때만 slug 필수.</li>
 *   <li>{@code @When(group = "PaymentRequired") @NotBlank private String cardNumber;} — 명시적 group 활성.</li>
 * </ul>
 *
 * <p>본 어노테이션은 Phase 2 baseline 적용 (marker + reflection inspection). 실제 expression 평가 엔진 (SpEL parser)
 * 결합은 Phase 3 의 advisor 에서.
 */
@Target({FIELD, METHOD})
@Retention(RUNTIME)
public @interface When {

    /** SpEL expression — 평가 결과 true 일 때만 검증 활성. {@code group()} 와 동시 사용 시 AND. */
    String value() default "";

    /** Validation group 명시 — 명시 부재 시 default group 사용. */
    String group() default "";

    /** 에러 코드 — 명시 부재 시 {@code "VALIDATION.WHEN"} default. */
    String code() default "VALIDATION.WHEN";

    /** 메시지 또는 message key — 명시 부재 시 {@code code} 그대로. */
    String message() default "";
}
