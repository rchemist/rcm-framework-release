/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import io.rchemist.core.context.RequestContext;
import io.rchemist.core.logging.ScopedValueMdcBinder;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.UUID;
import java.util.regex.Pattern;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 2 task #2 — HTTP request 진입 시 W3C Trace Context (traceparent / tracestate) +
 * X-Request-Id 헤더 추출/발급 + {@link RequestContext} ScopedValue binding + SLF4J MDC 인입.
 * 부재 시 traceparent 는 W3C 형식 (00-{32hex}-{16hex}-01) 신규 발급, X-Request-Id 는 UUID 발급.
 * response 에 X-Request-Id echo 적용. {@link Ordered#HIGHEST_PRECEDENCE} + 10 으로 가장 먼저 진입.
 **/
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class RequestContextFilter extends OncePerRequestFilter {

    public static final String HEADER_TRACEPARENT = "traceparent";
    public static final String HEADER_TRACESTATE = "tracestate";
    public static final String HEADER_X_REQUEST_ID = "X-Request-Id";

    private static final Pattern TRACEPARENT_PATTERN =
        Pattern.compile("^[0-9a-f]{2}-[0-9a-f]{32}-[0-9a-f]{16}-[0-9a-f]{2}$");

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
        FilterChain chain) throws ServletException, IOException {

        String requestId = headerOrNull(request, HEADER_X_REQUEST_ID);
        if (requestId == null || requestId.isBlank()) {
            requestId = UUID.randomUUID().toString();
        }

        String traceparent = headerOrNull(request, HEADER_TRACEPARENT);
        if (traceparent == null || !TRACEPARENT_PATTERN.matcher(traceparent).matches()) {
            traceparent = generateTraceparent();
        }

        String tracestate = headerOrNull(request, HEADER_TRACESTATE);

        // response 에 X-Request-Id echo 적용 (downstream 이 status 결정 전에 set)
        response.setHeader(HEADER_X_REQUEST_ID, requestId);

        RequestContext ctx = new RequestContext(requestId, traceparent, tracestate);
        ServletException[] servletErr = new ServletException[1];
        IOException[] ioErr = new IOException[1];
        RuntimeException[] runtimeErr = new RuntimeException[1];

        RequestContext.runWith(ctx, () -> ScopedValueMdcBinder.runWithMdc(() -> {
            try {
                chain.doFilter(request, response);
            } catch (ServletException e) {
                servletErr[0] = e;
            } catch (IOException e) {
                ioErr[0] = e;
            } catch (RuntimeException e) {
                runtimeErr[0] = e;
            }
        }));

        if (servletErr[0] != null) {
            throw servletErr[0];
        }
        if (ioErr[0] != null) {
            throw ioErr[0];
        }
        if (runtimeErr[0] != null) {
            throw runtimeErr[0];
        }
    }

    /**
     * W3C Trace Context traceparent 신규 발급 — version=00, trace-id 16 byte (32 hex),
     * parent-id 8 byte (16 hex), flags=01 (sampled).
     */
    static String generateTraceparent() {
        byte[] traceId = new byte[16];
        byte[] parentId = new byte[8];
        RANDOM.nextBytes(traceId);
        RANDOM.nextBytes(parentId);
        return "00-" + toHex(traceId) + "-" + toHex(parentId) + "-01";
    }

    private static String toHex(byte[] bytes) {
        char[] out = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xff;
            out[i * 2] = HEX[v >>> 4];
            out[i * 2 + 1] = HEX[v & 0x0f];
        }
        return new String(out);
    }

    private static String headerOrNull(HttpServletRequest request, String name) {
        return request.getHeader(name);
    }
}
