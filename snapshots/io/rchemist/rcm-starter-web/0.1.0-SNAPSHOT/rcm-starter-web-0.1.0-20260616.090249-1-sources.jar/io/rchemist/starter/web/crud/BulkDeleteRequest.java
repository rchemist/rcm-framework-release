/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * controller-layer bulk delete request — Phase 0.1.0 GA Gate T0-5 (G-A-7) 신규.
 *
 * <p>Decision #31 정합 — {@code DELETE /} + RequestBody. RFC 9110 *서버 명시 지원* 영역. 0.1.0
 * baseline 환경 (JDK 25 + Spring Boot 4 + RestClient + axios 최신) 모두 자연 지원. 옛 silent strip
 * 환경 = 메모리 {@code project_v010_redesign} (하위 호환 무시) 정합 영구 거부.
 *
 * <p>0.0.5 {@code DeleteForm} 자산 흡수 (메모리 {@code feedback_no_feature_regression} 정합):
 * <ul>
 *   <li>{@code ids: List<ID>} — 삭제 대상 ID list (non-empty 강제, fail-loud)</li>
 *   <li>{@code revisionEntityName: String} — optional, audit history 영역 (Hibernate Envers 등)</li>
 * </ul>
 *
 * <p>service-layer 의 SearchRequest where 형태 (CriteriaDelete 영역) 와는 별개 — controller 는 ID
 * list 명시가 자연 (REST endpoint), service 는 SearchRequest where 가 자연 (criteria-based bulk).
 *
 * @param <ID> entity ID 타입 (Long / String / TSID 등)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record BulkDeleteRequest<ID>(
    @NotEmpty(message = "ids 는 비어 있을 수 없습니다 (전체 삭제 위험 회피).")
    List<ID> ids,
    String revisionEntityName
) {

  public BulkDeleteRequest {
    Objects.requireNonNull(ids, "ids (전체 삭제 위험 회피용 — 명시 ID list 박아라)");
    if (ids.isEmpty()) {
      throw new IllegalArgumentException("ids 는 비어 있을 수 없습니다 (전체 삭제 위험 회피).");
    }
    ids = List.copyOf(ids);
  }

  /** revisionEntityName 없이 ID list 만 — 가장 흔한 케이스. */
  public BulkDeleteRequest(List<ID> ids) {
    this(ids, null);
  }
}
