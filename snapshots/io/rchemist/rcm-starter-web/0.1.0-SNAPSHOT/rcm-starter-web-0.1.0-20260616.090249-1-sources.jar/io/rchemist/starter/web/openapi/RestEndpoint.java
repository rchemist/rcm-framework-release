/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.openapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — 0.0.5 의 {@code @RestEndpoint} 시그니처 흡수. 메소드 단위 OpenAPI Operation
 * 메타데이터 명시 어노테이션. 컴파일 시점에 {@code RestEndpointProcessor} 가 metadata 추출, 런타임
 * 시점에 {@code RestEndpointOperationCustomizer} 가 springdoc 의 {@code Operation} 객체로 변환.
 *
 * <p>Consumer 의 0.0.5 호출 패턴 100% 보존 (메모리 {@code feedback_no_feature_regression} 정합).
 * 별도 {@code @Operation} 명시 불필요 — APT + OperationCustomizer 가 자동 합산.
 *
 * <ul>
 *   <li>{@link #summary()} — Operation summary (Swagger UI 의 메소드 요약)</li>
 *   <li>{@link #description()} — Operation description (긴 설명, markdown 가능)</li>
 *   <li>{@link #tag()} — Operation 분류 tag (group 단위 묶음, 빈 값이면 controller 의 class name 자동)</li>
 *   <li>{@link #deprecated()} — deprecated marker (true 면 Swagger UI 에서 strikethrough)</li>
 *   <li>{@link #operationId()} — Operation 고유 ID (빈 값이면 메소드명 자동)</li>
 * </ul>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RestEndpoint {

  /** Operation summary (Swagger UI 의 메소드 요약). */
  String summary() default "";

  /** Operation 긴 설명. */
  String description() default "";

  /** Operation 분류 tag — 빈 값이면 controller class name 자동. */
  String tag() default "";

  /** Deprecated marker — true 면 Swagger UI 에서 strikethrough 표시. */
  boolean deprecated() default false;

  /** Operation 고유 ID — 빈 값이면 메소드명 자동. */
  String operationId() default "";
}
