/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.context;

import io.rchemist.starter.web.util.CookieHelper;
import jakarta.servlet.http.HttpServletRequest;
import java.time.DateTimeException;
import java.time.ZoneId;
import java.util.Currency;
import java.util.Locale;
import java.util.TimeZone;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 — request 단위 locale / timezone / currency / zoneId / device 5 종 chain
 * resolver. {@link io.rchemist.core.context.RequestContext} 와 짝.
 *
 * <p>chain 순서: header (Accept-Language / X-Currency / X-Time-Zone / User-Agent) → cookie (LANG)
 * → tenant default (parameter) → JVM default. invalid 값은 silent fall-through.
 **/
public final class RequestContextResolver {

  private static final String LANG_COOKIE = "LANG";

  private RequestContextResolver() {
    throw new UnsupportedOperationException("static utility");
  }

  /** Locale chain: Accept-Language > LANG cookie > tenant default > JVM default. */
  public static Locale resolveLocale(HttpServletRequest request, Locale tenantDefault) {
    Locale fromHeader = parseLocaleTag(request.getHeader("Accept-Language"));
    if (fromHeader != null) {
      return fromHeader;
    }
    Locale fromCookie = parseLocaleTag(CookieHelper.getCookie(request, LANG_COOKIE));
    if (fromCookie != null) {
      return fromCookie;
    }
    return tenantDefault != null ? tenantDefault : Locale.getDefault();
  }

  /** TimeZone chain: X-Time-Zone > tenant default > JVM default. */
  public static TimeZone resolveTimeZone(HttpServletRequest request, TimeZone tenantDefault) {
    String header = request.getHeader("X-Time-Zone");
    if (header != null && !header.isBlank() && isValidTimeZone(header)) {
      return TimeZone.getTimeZone(header);
    }
    return tenantDefault != null ? tenantDefault : TimeZone.getDefault();
  }

  /** ZoneId chain: X-Time-Zone > tenant default > JVM default. */
  public static ZoneId resolveZoneId(HttpServletRequest request, ZoneId tenantDefault) {
    String header = request.getHeader("X-Time-Zone");
    if (header != null && !header.isBlank()) {
      try {
        return ZoneId.of(header);
      } catch (DateTimeException ignored) {
        // fall through
      }
    }
    return tenantDefault != null ? tenantDefault : ZoneId.systemDefault();
  }

  /** Currency chain: X-Currency (ISO 4217) > tenant default > Locale 기반 currency > USD. */
  public static Currency resolveCurrency(HttpServletRequest request, Currency tenantDefault) {
    String header = request.getHeader("X-Currency");
    if (header != null && !header.isBlank()) {
      try {
        return Currency.getInstance(header);
      } catch (IllegalArgumentException ignored) {
        // fall through
      }
    }
    if (tenantDefault != null) {
      return tenantDefault;
    }
    try {
      return Currency.getInstance(Locale.getDefault());
    } catch (IllegalArgumentException e) {
      return Currency.getInstance("USD");
    }
  }

  /** User-Agent 기반 device 분류 — JDK pure (UA parser 외부 dep 0). */
  public static DeviceType resolveDeviceType(HttpServletRequest request) {
    String ua = request.getHeader("User-Agent");
    if (ua == null || ua.isBlank()) {
      return DeviceType.UNKNOWN;
    }
    String lc = ua.toLowerCase();
    if (lc.contains("bot") || lc.contains("crawler") || lc.contains("spider")) {
      return DeviceType.BOT;
    }
    if (lc.contains("ipad") || lc.contains("tablet")) {
      return DeviceType.TABLET;
    }
    if (lc.contains("iphone") || lc.contains("android") || lc.contains("mobile")) {
      return DeviceType.MOBILE;
    }
    return DeviceType.DESKTOP;
  }

  private static Locale parseLocaleTag(String tag) {
    if (tag == null || tag.isBlank()) {
      return null;
    }
    int comma = tag.indexOf(',');
    String first = (comma < 0 ? tag : tag.substring(0, comma)).trim();
    int semi = first.indexOf(';');
    if (semi >= 0) {
      first = first.substring(0, semi).trim();
    }
    if (first.isEmpty()) {
      return null;
    }
    Locale locale = Locale.forLanguageTag(first);
    return locale.getLanguage().isEmpty() ? null : locale;
  }

  private static boolean isValidTimeZone(String id) {
    for (String available : TimeZone.getAvailableIDs()) {
      if (available.equals(id)) {
        return true;
      }
    }
    return false;
  }

  /** Device 분류 — DESKTOP / MOBILE / TABLET / BOT / UNKNOWN. */
  public enum DeviceType {
    DESKTOP,
    MOBILE,
    TABLET,
    BOT,
    UNKNOWN
  }
}
