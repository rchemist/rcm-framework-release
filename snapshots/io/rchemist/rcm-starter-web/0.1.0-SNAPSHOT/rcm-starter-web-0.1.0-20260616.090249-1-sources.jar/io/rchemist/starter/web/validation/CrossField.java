/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.validation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #23 적용 영역 (5) — multi-field validation declarative. {@code fields()} 의 모든 필드가 규칙을 만족할 때만
 * 통과 — 본 어노테이션 한 개로 declarative 하게 표현. 실제 평가 엔진은 {@link ValidationRule} SPI 또는 별도 advisor 가
 * Phase 3 진입 시 결합.
 *
 * <p>예: {@code @CrossField(fields = {"password", "confirmPassword"}, rule = "EQUAL", message =
 * "비밀번호 확인이 일치하지 않습니다")}.
 *
 * <p>본 어노테이션은 marker — Phase 2 baseline 에서는 적용만, Phase 3 의 advisor 가 {@code beforeMethodCall} hook
 * 에서 평가. {@link Repeatable} 로 한 클래스에 다수 적용 가능.
 */
@Target(TYPE)
@Retention(RUNTIME)
@Repeatable(CrossField.List.class)
public @interface CrossField {

    /** 검증 대상 필드명 list (2 개 이상). */
    String[] fields();

    /**
     * 규칙 식별자 — 통상 enum-style key (예: {@code "EQUAL"}, {@code "BEFORE"}, {@code "AFTER"}).
     * Consumer 또는 framework 가 {@link ValidationRule} 로 매핑하여 평가.
     */
    String rule();

    /** 에러 코드 — 명시 부재 시 {@code "VALIDATION.CROSS_FIELD"} default. */
    String code() default "VALIDATION.CROSS_FIELD";

    /** 메시지 또는 message key (i18n) — 명시 부재 시 {@code code} 그대로. */
    String message() default "";

    /** 위반 시 어떤 필드에 적용할지 — 명시 부재 시 {@code fields()} 첫 번째 사용. */
    String reportOn() default "";

    @Target(TYPE)
    @Retention(RUNTIME)
    @interface List {
        CrossField[] value();
    }
}
