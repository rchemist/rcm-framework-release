/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.search;

import io.rchemist.core.search.Direction;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.QueryConditionType;
import io.rchemist.core.search.SearchRequest;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * GET query string → {@link SearchRequest} 변환 helper — 청사진 §5.5.1 적용 (단순 검색만).
 *
 * <p>지원 패턴 (단순 검색):
 * <ul>
 *   <li>{@code field=value} → EQUAL</li>
 *   <li>{@code field=v1,v2,v3} (값에 콤마 포함) → IN</li>
 *   <li>{@code field[gte]=v} → GREATER_THAN_EQUAL</li>
 *   <li>{@code field[lte]=v} → LESS_THAN_EQUAL</li>
 *   <li>{@code field[gt]=v} → GREATER_THAN</li>
 *   <li>{@code field[lt]=v} → LESS_THAN</li>
 *   <li>{@code field[like]=v} → LIKE</li>
 *   <li>{@code page} / {@code pageSize} / {@code searchTerm}</li>
 *   <li>{@code sort=-createdAt,viewCount} → DESC createdAt + ASC viewCount</li>
 * </ul>
 *
 * <p>복잡한 케이스 (AND/OR 트리, subFilter, NOT 등) → {@link ComplexQueryException} throw → advice 가
 * 400 ProblemDetail 변환 + "use POST {path}/search for complex queries" 안내.
 */
public final class SearchRequestParser {

    private SearchRequestParser() {
    }

    /** Reserved query params (filter 영역에서 제외). */
    private static final Set<String> RESERVED = Set.of(
        "page", "pageSize", "size", "sort", "searchTerm",
        "viewDetail", "exactMatch", "ignoreCache", "shouldReturnEmpty", "forceFetchFromDB",
        "cacheTTL");

    /** 명시 Op suffix ([gte], [lte] 등) — 단순 검색만. */
    private static final Map<String, QueryConditionType> OP_MAP = Map.of(
        "gte", QueryConditionType.GREATER_THAN_EQUAL,
        "gt", QueryConditionType.GREATER_THAN,
        "lte", QueryConditionType.LESS_THAN_EQUAL,
        "lt", QueryConditionType.LESS_THAN,
        "like", QueryConditionType.LIKE,
        "ne", QueryConditionType.NOT_EQUAL,
        "in", QueryConditionType.IN);

    /**
     * GET query string → SearchRequest. 복잡 케이스는 {@link ComplexQueryException} throw.
     */
    public static SearchRequest parse(HttpServletRequest req) {
        SearchRequest.Builder b = SearchRequest.builder();

        // page / pageSize
        b.page(asInt(req.getParameter("page"), 0));
        b.pageSize(asInt(req.getParameter("pageSize"), asInt(req.getParameter("size"), 20)));

        // searchTerm
        String searchTerm = req.getParameter("searchTerm");
        if (searchTerm != null && !searchTerm.isBlank()) {
            b.searchTerm(searchTerm);
        }

        // boolean flags
        b.viewDetail(asBool(req.getParameter("viewDetail")));
        b.exactMatch(asBool(req.getParameter("exactMatch")));
        b.ignoreCache(asBool(req.getParameter("ignoreCache")));
        b.shouldReturnEmpty(asBool(req.getParameter("shouldReturnEmpty")));
        b.forceFetchFromDB(asBool(req.getParameter("forceFetchFromDB")));

        // cacheTTL
        String cacheTTLstr = req.getParameter("cacheTTL");
        if (cacheTTLstr != null && !cacheTTLstr.isBlank()) {
            try {
                b.cacheTTL(Long.parseLong(cacheTTLstr));
            } catch (NumberFormatException ignored) {
                // 무시 — 단순 검색에서 잘못된 cacheTTL 은 굳이 400 으로 가지 않음.
            }
        }

        // sort=-createdAt,viewCount
        String sortStr = req.getParameter("sort");
        if (sortStr != null && !sortStr.isBlank()) {
            for (String token : sortStr.split(",")) {
                String t = token.trim();
                if (t.isEmpty()) {
                    continue;
                }
                if (t.startsWith("-")) {
                    b.addSort(t.substring(1), Direction.DESC);
                } else if (t.startsWith("+")) {
                    b.addSort(t.substring(1), Direction.ASC);
                } else {
                    b.addSort(t, Direction.ASC);
                }
            }
        }

        // body 필드들을 query string 으로 표현하면 *복잡* — POST 권장
        rejectIfComplexParam(req, "filters");
        rejectIfComplexParam(req, "operator");
        rejectIfComplexParam(req, "subFilters");

        // remaining params — filter 영역
        Map<String, String[]> map = new LinkedHashMap<>(req.getParameterMap());
        for (Map.Entry<String, String[]> e : map.entrySet()) {
            String key = e.getKey();
            if (RESERVED.contains(key)) {
                continue;
            }
            String[] vals = e.getValue();
            if (vals == null || vals.length == 0) {
                continue;
            }

            // [op] suffix — field[gte]=v
            int br = key.indexOf('[');
            if (br > 0 && key.endsWith("]")) {
                String field = key.substring(0, br);
                String op = key.substring(br + 1, key.length() - 1);
                QueryConditionType type = OP_MAP.get(op);
                if (type == null) {
                    throw new ComplexQueryException(
                        "Unsupported operator suffix [" + op + "] in query string. "
                            + "Use POST {path}/search for complex queries.");
                }
                if (type == QueryConditionType.IN) {
                    b.addFilter(LogicalOperator.AND,
                        io.rchemist.core.search.FilterItem.of(field, type,
                            Arrays.asList(vals[0].split(","))));
                } else {
                    b.addFilter(LogicalOperator.AND,
                        io.rchemist.core.search.FilterItem.of(field, type, vals[0]));
                }
                continue;
            }

            // 단순 EQUAL or IN (value 에 ',' 포함)
            String value = vals[0];
            if (value != null && value.contains(",")) {
                b.addFilter(LogicalOperator.AND,
                    io.rchemist.core.search.FilterItem.of(key, QueryConditionType.IN,
                        Arrays.asList(value.split(","))));
            } else {
                b.addFilter(LogicalOperator.AND,
                    io.rchemist.core.search.FilterItem.of(key, QueryConditionType.EQUAL, value));
            }
        }

        return b.build();
    }

    private static void rejectIfComplexParam(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        if (v != null && !v.isBlank()) {
            throw new ComplexQueryException(
                "Query parameter [" + name + "] is too complex for GET. "
                    + "Use POST {path}/search with JSON body for AND/OR trees, subFilters, or NOT.");
        }
    }

    private static int asInt(String s, int def) {
        if (s == null || s.isBlank()) {
            return def;
        }
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static boolean asBool(String s) {
        return "true".equalsIgnoreCase(s) || "1".equals(s);
    }

    /** Query 가 단순 케이스 범위를 넘었음을 나타내는 예외 (advice 가 400 ProblemDetail 로 변환). */
    public static final class ComplexQueryException extends RuntimeException {
        public ComplexQueryException(String message) {
            super(message);
        }
    }

    /** Reserved param 목록 (test 노출용). */
    public static List<String> reservedParams() {
        return Collections.unmodifiableList(List.copyOf(RESERVED));
    }
}
