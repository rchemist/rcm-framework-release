/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.crud;

import io.rchemist.core.search.EntityViewType;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SearchResponse;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #7 적용 — CRUD 보일러플레이트 얇은 base. Phase 0.1.0 GA Gate T0-6 갱신 (Decision #31 정합)
 * — 8 endpoint 매트릭스 + {@code search/schema} discovery 자동 적용. Consumer 가 단순 extends +
 * {@code @RestController} + {@code @RequestMapping("/articles")} 적용 → 모든 endpoint 동작.
 *
 * <p>얇은 base 5 규칙 (Decision #7 적용):
 * <ol>
 *   <li>상속 깊이 1 — Consumer controller extends AbstractCrudController 만 (3-계층 적용 거부)</li>
 *   <li>protected hook 0 — controller 차원 hook 메서드 없음. 비즈니스 override 는 Java 표준
 *       {@code @Override}</li>
 *   <li>추상 메서드는 비즈니스만 — {@link #toReadDTO(Object)} 단 1 개 (entity → DTO 변환은 비즈니스
 *       결정)</li>
 *   <li>generic 5 type — entity / id / createForm / updateForm / readDTO</li>
 *   <li>{@code @ConditionalOnMissingBean} 없음 — base 자체는 {@code @RestController} 아니라 abstract.
 *       Consumer 가 extends + {@code @RestController} + {@code @RequestMapping} 적용</li>
 * </ol>
 *
 * <p>Decision #31 정합 endpoint 매트릭스 (Phase 0.1.0 GA Gate T0-6):
 * <table border="1">
 *   <caption>8 endpoint + 1 discovery</caption>
 *   <tr><th>HTTP</th><th>path</th><th>영역</th><th>RequestBody</th></tr>
 *   <tr><td>GET</td><td>/</td><td>단순 목록 (query string SearchRequest binding)</td><td>—</td></tr>
 *   <tr><td>POST</td><td>/search</td><td>고급 검색 (24 종 condition + AND/OR 트리)</td><td>SearchRequest</td></tr>
 *   <tr><td>POST</td><td>/count</td><td>검색 조건 만족 count</td><td>SearchRequest</td></tr>
 *   <tr><td>POST</td><td>/</td><td>Create</td><td>CreateForm</td></tr>
 *   <tr><td>GET</td><td>/{id}?viewType=...</td><td>findById + view mode 분기</td><td>—</td></tr>
 *   <tr><td>PUT</td><td>/{id}</td><td>update</td><td>UpdateForm</td></tr>
 *   <tr><td>DELETE</td><td>/{id}</td><td>single delete</td><td>—</td></tr>
 *   <tr><td>DELETE</td><td>/</td><td>bulk delete (RFC 9110 정합)</td><td>BulkDeleteRequest&lt;ID&gt;</td></tr>
 *   <tr><td>GET</td><td>/search/schema</td><td>schema discovery</td><td>—</td></tr>
 * </table>
 *
 * <p>URL convention 결정 (Decision #31 정합):
 * <ul>
 *   <li><b>underscore prefix 영구 거부</b> — {@code /_search} / {@code /_count} 거부 (ES 자체 convention,
 *       일반 REST API 표준 아님). 종전 {@code /_search/schema} 는 {@code /search/schema} 갱신.</li>
 *   <li><b>{@code DELETE /} + body baseline</b> — JSON:API spec 정합, RFC 9110 *서버 명시 지원* 영역.
 *       0.1.0 baseline 환경 (JDK 25 + Spring Boot 4 + RestClient + axios 최신) 모두 자연 지원.</li>
 *   <li><b>POST /search vs POST /</b> — 0.0.5 의 *POST / 검색 + POST /add Create* 패턴 → 0.1.0
 *       *POST / Create + POST /search 검색* 갱신 (REST 표준 정합).</li>
 *   <li><b>Spring path matcher 자연 분리</b> — {@code /{id}} placeholder vs literal {@code /search} /
 *       {@code /count} Spring 의 *literal-first* 매칭 자연 분리.</li>
 * </ul>
 *
 * <p>NotFound 처리 — service 가 직접 {@code ServiceException} throw 하는 패턴 우선 (Consumer 의
 * 도메인별 ErrorType 적용 친화). service 가 단순 null 반환 시 base 가
 * {@link CrudErrorType#NOT_FOUND} 으로 자동 throw → {@link
 * io.rchemist.starter.web.autoconfig.ProblemDetailAdvice} 가 404 ProblemDetail 변환.
 *
 * @param <E>          entity 타입
 * @param <ID>         식별자 타입
 * @param <CreateForm> create body Records
 * @param <UpdateForm> update body Records
 * @param <ReadDTO>    응답 DTO Records
 **/
public abstract class AbstractCrudController<E, ID, CreateForm, UpdateForm, ReadDTO> {

  protected final CrudService<E, ID, CreateForm, UpdateForm> service;

  protected AbstractCrudController(CrudService<E, ID, CreateForm, UpdateForm> service) {
    this.service = service;
  }

  // ---------------------------------------------------------------------
  // 8 endpoint 매트릭스 (Decision #31 정합)
  // ---------------------------------------------------------------------

  /**
   * {@code POST /} — create. 201 Created + Location header + {@link ReadDTO} body.
   *
   * @param form valid create body
   * @return 201 응답 + 생성된 ReadDTO
   */
  @PostMapping
  public ResponseEntity<ReadDTO> create(@Valid @RequestBody CreateForm form) {
    E created = service.create(form);
    ReadDTO body = toReadDTO(created);
    URI location = ServletUriComponentsBuilder.fromCurrentRequest()
        .path("/{id}")
        .buildAndExpand(extractId(created))
        .toUri();
    return ResponseEntity.created(location).body(body);
  }

  /**
   * {@code GET /} — 단순 목록 (query string {@link SearchRequest} 자동 binding, Phase 2 task #4 의
   * argument resolver). 응답은 {@link SearchResponse} 풍부 형태 (Phase 0.1.0 GA Gate T0-5 baseline).
   *
   * <p>page / pageSize 는 SearchRequest 자체 적용 (별도 Pageable 분리 거부, 중복 적용 회피).
   *
   * <p>고급 영역 (24 종 condition / AND-OR 트리 / viewDetail / cacheTTL 등) 은 {@code POST /search}
   * 위임 — query string 한계 (예: {@code filters[0].subFilters[]}) 는 charter §1 원칙 5 (Fail loud)
   * 정합으로 *400 + "Use POST /search for advanced filters"* (cookbook 명시).
   *
   * @param request resolved SearchRequest (단순 영역 — page/pageSize/sorts/quickSearch)
   * @return SearchResponse&lt;ReadDTO&gt; — content + 페이징 + sorts/searchRequest echo + attributes + errors
   */
  @GetMapping
  public SearchResponse<ReadDTO> list(SearchRequest request) {
    return service.searchResponse(request).map(this::toReadDTO);
  }

  /**
   * {@code POST /search} — 고급 검색 (Decision #31 정합 신규). RequestBody {@link SearchRequest} 가
   * 24 종 condition + AND/OR 트리 + viewDetail / cacheTTL / ignoreCache 등 full body 표현.
   *
   * @param request body SearchRequest (full 영역)
   * @return SearchResponse&lt;ReadDTO&gt;
   */
  @PostMapping("/search")
  public SearchResponse<ReadDTO> search(@RequestBody SearchRequest request) {
    return service.searchResponse(request).map(this::toReadDTO);
  }

  /**
   * {@code POST /count} — 검색 조건 만족 count (Decision #31 정합 신규). Phase 3 의
   * AbstractCrudService 가 본격 override — Specification + COUNT(*) 직접 query.
   *
   * @param request body SearchRequest (filters / quickSearch — page/pageSize 무시)
   * @return 매칭 count
   */
  @PostMapping("/count")
  public long count(@RequestBody SearchRequest request) {
    return service.count(request);
  }

  /**
   * {@code GET /{id}} + 옵션 {@code ?viewType=VIEW|EDIT|DETAIL|MOBILE} — find by id + view mode 분기.
   * service 가 NotFound 의 경우 직접 throw 하거나 null 반환 — null 시 base 가 자동
   * {@link CrudErrorType#NOT_FOUND} throw → 404 ProblemDetail.
   *
   * <p>{@code viewType} param 미지정 = {@link EntityViewType#VIEW} default 동등 (service 의
   * {@code find(id, null)} → {@code find(id)} 위임).
   *
   * @param id       식별자 (Spring 의 Converter 가 path variable → ID 자동 변환)
   * @param viewType 옵션 view mode (VIEW / EDIT / DETAIL / MOBILE 4 baseline)
   * @return ReadDTO
   */
  @GetMapping("/{id}")
  public ReadDTO findById(
      @PathVariable("id") ID id,
      @RequestParam(name = "viewType", required = false) @Nullable EntityViewType viewType) {
    E entity = service.find(id, viewType);
    if (entity == null) {
      throw new io.rchemist.core.error.ServiceException(
          CrudErrorType.NOT_FOUND, String.valueOf(id));
    }
    return toReadDTO(entity);
  }

  /**
   * {@code PUT /{id}} — full or partial update.
   *
   * @param id   대상 식별자
   * @param form valid update body
   * @return 갱신된 ReadDTO
   */
  @PutMapping("/{id}")
  public ReadDTO update(@PathVariable("id") ID id, @Valid @RequestBody UpdateForm form) {
    E updated = service.update(id, form);
    return toReadDTO(updated);
  }

  /**
   * {@code DELETE /{id}} — 204 No Content. service 의 hard / soft 결정에 위임.
   *
   * @param id 대상 식별자
   */
  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void delete(@PathVariable("id") ID id) {
    service.delete(id);
  }

  /**
   * {@code DELETE /} + body — bulk delete (Decision #31 정합 신규, RFC 9110 *서버 명시 지원* 영역).
   * 0.1.0 baseline 환경 모두 자연 지원, 옛 silent strip 환경 = 메모리 {@code project_v010_redesign}
   * 정합 영구 거부.
   *
   * @param request body {ids: List&lt;ID&gt;, revisionEntityName: String?} (ids non-empty 강제)
   */
  @DeleteMapping
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void bulkDelete(@Valid @RequestBody BulkDeleteRequest<ID> request) {
    service.bulkDelete(request);
  }

  // ---------------------------------------------------------------------
  // discovery endpoint
  // ---------------------------------------------------------------------

  /**
   * {@code GET /search/schema} — entity 의 Searchable marker 안 fields + types 노출. Phase 1 APT
   * 의 {@code Entity_Search} 활용 가능 (service 책임). Phase 2 baseline = service 가 그대로 위임.
   *
   * <p>Decision #31 정합 — 종전 {@code /_search/schema} 의 underscore prefix 영구 거부 → 본 path 갱신.
   *
   * @return schema metadata Map
   */
  @GetMapping("/search/schema")
  public Map<String, Object> searchSchema() {
    return service.searchSchema();
  }

  // ---------------------------------------------------------------------
  // 추상 1 — 비즈니스 (Decision #7 적용, hook 거부)
  // ---------------------------------------------------------------------

  /**
   * entity → ReadDTO 변환 — 변환은 비즈니스 결정 영역 (도메인별 필드 노출 정책). Phase 3 의
   * code-generator v2 가 Records DTO + 변환 함께 generate.
   *
   * @param entity 원본 entity
   * @return 응답 DTO
   */
  protected abstract ReadDTO toReadDTO(E entity);

  // ---------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------

  /**
   * Location 헤더 적용용 — entity 의 ID 추출. 기본 구현은 reflection-free
   * {@link Object#toString()} fallback (Records / String ID / Long ID 모두 자연 적용). Consumer
   * 가 override 가능 — 단 base hook 거부 원칙 정합 = Java 표준 {@code @Override} 활용.
   *
   * @param entity 영속화된 entity
   * @return ID 문자열 표현 (URI path expand 용)
   */
  @SuppressWarnings("unchecked")
  protected ID extractId(E entity) {
    // Phase 2 baseline — service 가 ID injected entity 반환 시 toString() 충분.
    // Phase 3 의 AbstractCrudService 결합 시 typed 추출 적용 (entity_metadata APT 활용).
    return (ID) entity;
  }

  // ---------------------------------------------------------------------
  // Page<E> → Page<ReadDTO> 변환 helper (test fixture 친화)
  // ---------------------------------------------------------------------

  /**
   * test fixture 또는 Consumer 가 직접 Page 변환할 때 사용 — {@link Page#map} 정합.
   *
   * @param source entity Page
   * @return ReadDTO Page (page metadata 보존)
   */
  protected Page<ReadDTO> mapPage(Page<E> source) {
    return new PageImpl<>(
        source.getContent().stream().map(this::toReadDTO).toList(),
        source.getPageable(),
        source.getTotalElements());
  }
}
