/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import io.rchemist.core.context.RequestContext;
import io.rchemist.core.context.TenantContext;
import io.rchemist.core.error.ErrorType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 2 task #3 — multipart 안전 default 적용 filter (청사진 §9 task 2.4). multipart request 에 대해
 * 다음 4 영역 baseline 검증:
 *
 * <ol>
 *   <li>Path traversal 차단 — filename canonicalize ({@code ../}, null byte, 절대경로 reject)</li>
 *   <li>매직바이트 검증 — Content-Type 과 파일 시그니처 매칭</li>
 *   <li>ZIP Slip 차단 — application/zip / .zip 확장자에 한해 entry path 검증</li>
 *   <li>max-file-size — 단일 파일 size 제한 (위반 시 413 PAYLOAD_TOO_LARGE)</li>
 * </ol>
 *
 * <p>위반 시 직접 RFC 7807 ProblemDetail JSON 을 응답으로 적용 — filter 는 {@code @RestControllerAdvice}
 * 보다 외곽이라 advice 를 거치지 못함. ProblemDetail extension fields {@code code} / {@code traceId} /
 * {@code tenantId} 는 {@code ProblemDetailAdvice} 와 동일하게 적용 (정합).
 *
 * <p>{@link Order} = {@link Ordered#HIGHEST_PRECEDENCE} + 30 — {@code SecurityHeadersFilter} (+20) 보다 뒤.
 *
 * <p>Phase 6.8 {@code rcm-starter-storage} 진입 시 deeper hook (TempStore / virus scan SPI 등) 추가 적용 — 본
 * task 는 baseline 만.
 **/
@Order(Ordered.HIGHEST_PRECEDENCE + 30)
public class MultipartSafetyFilter extends OncePerRequestFilter {

  private final MultipartSafetyProperties properties;

  public MultipartSafetyFilter(MultipartSafetyProperties properties) {
    this.properties = properties == null ? MultipartSafetyProperties.defaults() : properties;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws ServletException, IOException {

    if (!properties.enabled() || !isMultipart(request)) {
      chain.doFilter(request, response);
      return;
    }

    Collection<Part> parts;
    try {
      parts = request.getParts();
    } catch (IllegalStateException ex) {
      // Servlet 의 max-file-size / max-request-size 위반 시
      writeProblem(response, MultipartSafetyError.MAX_SIZE_EXCEEDED, null, ex.getMessage());
      return;
    }

    for (Part part : parts) {
      MultipartSafetyError err = validatePart(part);
      if (err != null) {
        writeProblem(response, err, part.getSubmittedFileName(), null);
        return;
      }
    }

    chain.doFilter(request, response);
  }

  // ---------------------------------------------------------------------
  // 검증 helpers
  // ---------------------------------------------------------------------

  /**
   * 단일 part 검증 — 위반 발견 시 첫 위반 {@link MultipartSafetyError} 반환, 정상이면 null.
   */
  MultipartSafetyError validatePart(Part part) throws IOException {
    String filename = part.getSubmittedFileName();
    if (filename != null && !filename.isBlank()) {
      // 1. Path traversal
      if (isPathTraversal(filename)) {
        return MultipartSafetyError.PATH_TRAVERSAL;
      }
    }

    // max-file-size
    if (properties.maxFileSize() > 0 && part.getSize() > properties.maxFileSize()) {
      return MultipartSafetyError.MAX_SIZE_EXCEEDED;
    }

    String contentType = part.getContentType();

    // 2. magic bytes
    if (properties.checkMagicBytes() && contentType != null && filename != null
        && !filename.isBlank() && properties.magicBytes().containsKey(contentType.toLowerCase())) {
      byte[] head = readHead(part, 16);
      String expected = properties.magicBytes().get(contentType.toLowerCase());
      if (!matchesMagicBytes(head, expected)) {
        return MultipartSafetyError.MAGIC_BYTE_MISMATCH;
      }
    }

    // 3. ZIP slip
    if (properties.checkZipSlip() && isZip(contentType, filename)) {
      try (ZipInputStream zis = new ZipInputStream(part.getInputStream())) {
        ZipEntry entry;
        while ((entry = zis.getNextEntry()) != null) {
          if (isPathTraversal(entry.getName())) {
            return MultipartSafetyError.ZIP_SLIP;
          }
        }
      }
    }

    return null;
  }

  /** Path traversal 패턴 검사 — {@code ../}, {@code ..\}, null byte, 절대경로. */
  static boolean isPathTraversal(String path) {
    if (path == null) {
      return false;
    }
    if (path.indexOf('\0') >= 0) {
      return true;
    }
    String normalized = path.replace('\\', '/');
    if (normalized.contains("../") || normalized.contains("..\\")) {
      return true;
    }
    if (normalized.equals("..")) {
      return true;
    }
    if (normalized.startsWith("/")) {
      return true;
    }
    // Windows drive letter 절대경로 e.g. "C:\..."
    if (path.length() >= 2 && Character.isLetter(path.charAt(0)) && path.charAt(1) == ':') {
      return true;
    }
    return false;
  }

  static boolean isZip(String contentType, String filename) {
    if (contentType != null && contentType.toLowerCase().startsWith("application/zip")) {
      return true;
    }
    if (filename != null && filename.toLowerCase().endsWith(".zip")) {
      return true;
    }
    return false;
  }

  /**
   * part 의 head N byte 만 읽어 byte[] 반환 — Servlet Part 의 InputStream 은 매번 재생성되므로 안전.
   */
  static byte[] readHead(Part part, int n) throws IOException {
    try (InputStream in = part.getInputStream()) {
      byte[] buf = new byte[n];
      int total = 0;
      int read;
      while (total < n && (read = in.read(buf, total, n - total)) != -1) {
        total += read;
      }
      if (total < n) {
        byte[] truncated = new byte[total];
        System.arraycopy(buf, 0, truncated, 0, total);
        return truncated;
      }
      return buf;
    }
  }

  /** byte[] 가 hex 문자열 prefix 와 매칭되는지 검사. */
  static boolean matchesMagicBytes(byte[] head, String expectedHex) {
    if (head == null || expectedHex == null || expectedHex.isBlank()) {
      return false;
    }
    String hex = expectedHex.replace(" ", "").toUpperCase();
    int requiredBytes = hex.length() / 2;
    if (head.length < requiredBytes) {
      return false;
    }
    StringBuilder actual = new StringBuilder(requiredBytes * 2);
    for (int i = 0; i < requiredBytes; i++) {
      actual.append(String.format("%02X", head[i] & 0xff));
    }
    return actual.toString().equals(hex);
  }

  static boolean isMultipart(HttpServletRequest request) {
    String ct = request.getContentType();
    return ct != null && ct.toLowerCase().startsWith("multipart/");
  }

  // ---------------------------------------------------------------------
  // ProblemDetail JSON 직접 적용 — filter 단은 RestControllerAdvice 미도달
  // ---------------------------------------------------------------------

  void writeProblem(HttpServletResponse response, MultipartSafetyError err, String filename,
      String extra) throws IOException {
    HttpStatus status = err.httpStatus();
    response.setStatus(status.value());
    response.setContentType(MediaType.APPLICATION_PROBLEM_JSON_VALUE);
    response.setCharacterEncoding(StandardCharsets.UTF_8.name());

    Map<String, Object> body = new LinkedHashMap<>();
    body.put("type", "about:blank");
    body.put("title", err.code());
    body.put("status", status.value());
    body.put("detail", extra == null ? err.code() : err.code() + ": " + extra);
    body.put("code", err.code());
    if (filename != null) {
      body.put("field", filename);
    }
    String requestId = RequestContext.currentRequestIdOrNull();
    if (requestId != null) {
      body.put("traceId", requestId);
    }
    String tenantId = TenantContext.currentTenantIdOrNull();
    if (tenantId != null) {
      body.put("tenantId", tenantId);
    }

    response.getWriter().write(toJson(body));
    response.getWriter().flush();
  }

  /** 단순 JSON serializer — Jackson 의존 없이 ProblemDetail 형태만 적용 (filter 단 외부 의존 0). */
  static String toJson(Map<String, Object> map) {
    StringBuilder sb = new StringBuilder("{");
    boolean first = true;
    for (Map.Entry<String, Object> e : map.entrySet()) {
      if (!first) {
        sb.append(',');
      }
      first = false;
      sb.append('"').append(escape(e.getKey())).append('"').append(':');
      Object v = e.getValue();
      if (v == null) {
        sb.append("null");
      } else if (v instanceof Number || v instanceof Boolean) {
        sb.append(v);
      } else {
        sb.append('"').append(escape(v.toString())).append('"');
      }
    }
    sb.append('}');
    return sb.toString();
  }

  static String escape(String s) {
    StringBuilder sb = new StringBuilder(s.length());
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '"' -> sb.append("\\\"");
        case '\\' -> sb.append("\\\\");
        case '\n' -> sb.append("\\n");
        case '\r' -> sb.append("\\r");
        case '\t' -> sb.append("\\t");
        default -> {
          if (c < 0x20) {
            sb.append(String.format("\\u%04x", (int) c));
          } else {
            sb.append(c);
          }
        }
      }
    }
    return sb.toString();
  }

  // ---------------------------------------------------------------------
  // ErrorType enum — SECURITY.* 적용 (filter 안에서만 사용)
  // ---------------------------------------------------------------------

  /** Phase 2 task #3 적용 SECURITY.* error code. */
  enum MultipartSafetyError implements ErrorType {
    PATH_TRAVERSAL("SECURITY.MULTIPART_PATH_TRAVERSAL", HttpStatus.BAD_REQUEST),
    MAGIC_BYTE_MISMATCH("SECURITY.MULTIPART_MAGIC_BYTE_MISMATCH", HttpStatus.BAD_REQUEST),
    ZIP_SLIP("SECURITY.MULTIPART_ZIP_SLIP", HttpStatus.BAD_REQUEST),
    MAX_SIZE_EXCEEDED("SECURITY.MULTIPART_MAX_SIZE_EXCEEDED", HttpStatus.CONTENT_TOO_LARGE);

    private final String code;
    private final HttpStatus status;

    MultipartSafetyError(String code, HttpStatus status) {
      this.code = code;
      this.status = status;
    }

    @Override
    public String code() {
      return code;
    }

    @Override
    public HttpStatus httpStatus() {
      return status;
    }
  }

  // ---------------------------------------------------------------------
  // testing seam — magic bytes byte[] 검사 helper for unit test
  // ---------------------------------------------------------------------

  /** Test seam — byte[] body 가 contentType 매직바이트와 매칭되는지 직접 검사. */
  boolean validateMagicBytesForTest(String contentType, byte[] body) throws IOException {
    if (contentType == null || !properties.magicBytes().containsKey(contentType.toLowerCase())) {
      return true;
    }
    try (InputStream in = new ByteArrayInputStream(body)) {
      byte[] buf = new byte[16];
      int total = 0;
      int read;
      while (total < buf.length && (read = in.read(buf, total, buf.length - total)) != -1) {
        total += read;
      }
      String expected = properties.magicBytes().get(contentType.toLowerCase());
      byte[] head = new byte[total];
      System.arraycopy(buf, 0, head, 0, total);
      return matchesMagicBytes(head, expected);
    }
  }
}
