/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.autoconfig;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 2 task #3 — 보안 응답 헤더 default 적용 filter (청사진 §9 task 2.3). 모든 응답에 5 종 보안 헤더를
 * 자동으로 적용하며, 각 헤더는 {@link SecurityHeadersProperties} 를 통해 yml override 가능. null 또는 빈
 * 문자열로 설정 시 해당 헤더는 응답에 박지 않음 (개별 opt-out).
 *
 * <p>{@link Order} = {@link Ordered#HIGHEST_PRECEDENCE} + 20 — {@code RequestContextFilter} (+10)
 * 보다 뒤. 보안 헤더는 controller 진입 전 응답 적용 + downstream 이 덮어쓸 수 있음 (필요 시).
 **/
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class SecurityHeadersFilter extends OncePerRequestFilter {

  public static final String HEADER_CSP = "Content-Security-Policy";
  public static final String HEADER_HSTS = "Strict-Transport-Security";
  public static final String HEADER_X_FRAME_OPTIONS = "X-Frame-Options";
  public static final String HEADER_X_CONTENT_TYPE_OPTIONS = "X-Content-Type-Options";
  public static final String HEADER_REFERRER_POLICY = "Referrer-Policy";

  private final SecurityHeadersProperties properties;

  public SecurityHeadersFilter(SecurityHeadersProperties properties) {
    this.properties = properties == null ? SecurityHeadersProperties.defaults() : properties;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws ServletException, IOException {

    if (properties.enabled()) {
      applyHeader(response, HEADER_CSP, properties.contentSecurityPolicy());
      applyHeader(response, HEADER_HSTS, properties.strictTransportSecurity());
      applyHeader(response, HEADER_X_FRAME_OPTIONS, properties.xFrameOptions());
      applyHeader(response, HEADER_X_CONTENT_TYPE_OPTIONS, properties.xContentTypeOptions());
      applyHeader(response, HEADER_REFERRER_POLICY, properties.referrerPolicy());
    }

    chain.doFilter(request, response);
  }

  private static void applyHeader(HttpServletResponse response, String name, String value) {
    if (value != null && !value.isBlank()) {
      response.setHeader(name, value);
    }
  }
}
