/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.web.util;

import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 (Decision #29 Q2) — {@link HtmlSanitizer} 가 인입하는 정책 baseline 3 종.
 *
 * <p>OWASP Java HTML Sanitizer 의 {@link PolicyFactory} 를 wrap. Consumer 가 추가 정책이 필요하면
 * {@link HtmlPolicyBuilder} 로 직접 구성 후 {@link HtmlSanitizer#sanitize(String, PolicyFactory)} 인입.
 *
 * <p>3 baseline:
 * <ul>
 *   <li>{@link #RICH_TEXT} — Block + Format + Link + Image + List + Style. 게시글 본문에 적합.</li>
 *   <li>{@link #PLAIN_TEXT} — 모든 tag 제거 (text node 만 유지). 입력 검증·검색 인덱싱 용.</li>
 *   <li>{@link #MARKDOWN_SAFE} — Format + Link + Block 만 (Image / Style / Table 제외). Markdown
 *       렌더링 결과 sanitize 용 — 인라인 강조 + 링크 + 단락 + 인용 / 코드 블록.</li>
 * </ul>
 **/
public final class HtmlPolicies {

  /** 게시글 본문 baseline — Block + Format + Link + Image + List + Style + Table. */
  public static final PolicyFactory RICH_TEXT =
      Sanitizers.BLOCKS
          .and(Sanitizers.FORMATTING)
          .and(Sanitizers.LINKS)
          .and(Sanitizers.IMAGES)
          .and(Sanitizers.STYLES)
          .and(Sanitizers.TABLES);

  /** 모든 tag 제거 — text node 만. */
  public static final PolicyFactory PLAIN_TEXT = new HtmlPolicyBuilder().toFactory();

  /** Markdown 렌더링 결과 sanitize — Format + Link + Block. Image / Style / Table 제외. */
  public static final PolicyFactory MARKDOWN_SAFE =
      Sanitizers.BLOCKS.and(Sanitizers.FORMATTING).and(Sanitizers.LINKS);

  private HtmlPolicies() {
    throw new UnsupportedOperationException("static utility");
  }
}
