/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.thread.ThreadLocalManager;
import io.rchemist.common.web.request.resolver.RequestAttributeResolver;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.MessageSource;
import org.springframework.core.Ordered;
import org.springframework.http.HttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmWebRequestContextProcessor")
@Slf4j

public class WebRequestContextProcessor implements WebRequestProcessor{

  protected final MessageSource messageSource;

  protected final List<RequestAttributeResolver> requestAttributeResolvers;

  // BUG-013 fix (0.0.10.D): resolverSorted 는 JVM-global static 이었다. 동일 JVM 내에서
  // 두 번째 이후의 WebRequestContextProcessor 인스턴스가 다른 resolver 리스트를 가질 때
  // (테스트 / Spring Boot DevTools restart 등) 재정렬이 skip 되어 정렬 순서가 깨졌다.
  // 인스턴스 필드로 전환해 인스턴스 단위로 한 번만 정렬을 보장한다.
  private boolean resolverSorted = false;

  public WebRequestContextProcessor(MessageSource messageSource,
      List<RequestAttributeResolver> requestAttributeResolvers) {
    this.messageSource = messageSource;
    this.requestAttributeResolvers = requestAttributeResolvers;
  }

  private synchronized List<RequestAttributeResolver> getRequestAttributeResolvers(){
    if (!resolverSorted) {
      Collections.sort(requestAttributeResolvers, Comparator.comparing(Ordered::getOrder));
      resolverSorted = true;
    }
    return requestAttributeResolvers;
  }

  @Override
  public void process(ServletWebRequest request) {

    WebRequestContext context = new WebRequestContext();
    HttpRequest httpRequest = new ServletServerHttpRequest(request.getRequest());

    context.setRequest(httpRequest);

    WebRequestContext.setWebRequestContext(context);

    for(RequestAttributeResolver resolver : CollectionUtils.emptyIfNull(getRequestAttributeResolvers())){
      resolver.resolve(context);
    }

    context.setMessageSource(messageSource);

  }

  @Override
  public void postProcess(ServletWebRequest request) {
    // BUG-012 fix (0.0.10.D): ThreadLocalManager.remove() 이후 REQUEST_CONTEXT 의 후속
    // .get() 이 initialValue() 를 재실행해 fresh 기본 WebRequestContext 를 생성한다
    // (createInitialValue=true). 이로 인해 "비어있음" 시맨틱이 깨지고 null 체크가 우회된다.
    // 순서는 [ThreadLocalManager.remove → setWebRequestContext(null)] — remove 가 저장
    // 값을 지운 뒤 명시적으로 null 을 저장해 다음 요청의 set 전까지 get 이 저장된 null 을
    // 반환하도록 한다.
    ThreadLocalManager.remove();
    WebRequestContext.setWebRequestContext(null);
  }

  protected void clearSessionAttributes(ServletServerHttpRequest request){
    // WebRequestContextProcessor.process 로 인해 생성되는 세션 정보를 해제한다.
    // WebRequestContextProcessor 의 코드가 변경될 때 마다 해당하는 추가 코드를 작성한다.

    for(RequestAttributeResolver resolver : CollectionUtils.emptyIfNull(requestAttributeResolvers)){
      resolver.clearSessionAttribute(request);
    }
  }

}
