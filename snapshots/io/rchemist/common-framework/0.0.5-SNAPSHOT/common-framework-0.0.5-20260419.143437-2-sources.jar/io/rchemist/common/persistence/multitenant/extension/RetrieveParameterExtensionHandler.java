/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.multitenant.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = "rcmTenantInformationExtensionManager", priority = 300)
public class RetrieveParameterExtensionHandler extends AbstractTenantInformationExtensionHandler {

  @Override
  public ExtensionResultStatusType findTenantInformation(HttpServletRequest request,
      ExtensionResultHolder<TenantInformation> erh) {
    String tenantAlias = null;
    String siteAlias = null;
    if(request.getParameter("tenantAlias") != null){
      tenantAlias = request.getParameter("tenantAlias");
    }
    if(request.getParameter("siteAlias") != null){
      siteAlias = request.getParameter("siteAlias");
    }

    if(StringUtils.isNotEmpty(tenantAlias)){
      erh.setResult(new TenantInformation(tenantAlias, siteAlias));
      return ExtensionResultStatusType.HANDLED;
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
