/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.time.ZoneId;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Service("rcmZoneIdResolver")
@Slf4j
public class ZoneIdResolver implements RequestAttributeResolver<ZoneId> {

  public static String ZONE_ID_ATTR_NAME = "zoneId";
  public static String REQUESTED_ZONE_ID = "zoneId";

  @Override
  public boolean canHandle(Class<ZoneId> clazz) {
    return clazz.equals(ZoneId.class);
  }

  @Override
  public void resolve(WebRequestContext context) {

    ZoneId zoneId = null;

    try {
      ServletServerHttpRequest request = (ServletServerHttpRequest) context.getRequest();

      if(RequestUtil.getAttribute(ZONE_ID_ATTR_NAME) != null){
        zoneId = (ZoneId) RequestUtil.getAttribute(ZONE_ID_ATTR_NAME);
      }


      if(zoneId == null){
        if(RequestUtil.getURLorHeaderParameter(request, REQUESTED_ZONE_ID) != null){
          zoneId = ZoneId.of(RequestUtil.getURLorHeaderParameter(request, REQUESTED_ZONE_ID));
        }
      }

      if(zoneId == null){
        if(RequestUtil.getSessionAttribute(ZONE_ID_ATTR_NAME) != null){
          zoneId = (ZoneId) RequestUtil.getSessionAttribute(ZONE_ID_ATTR_NAME);
        }
      }

      if(zoneId != null){
        RequestUtil.setSessionAttribute(ZONE_ID_ATTR_NAME, zoneId);
      }
    }catch (Exception e) {
      log.debug("Error resolving zoneId", e);
    }

    context.setZoneId((zoneId == null) ? ZoneId.systemDefault() : zoneId);

  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, ZONE_ID_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.ZONE_ID_RESOLVER;
  }
}
