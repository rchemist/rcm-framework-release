/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.RequestUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class RereadableRequestFilter extends AbstractWebPageOncePerRequestFilter{

  private final ThreadLocal<HttpServletRequest> requestContext = new ThreadLocal<>();
  private final ThreadLocal<HttpServletResponse> responseContext = new ThreadLocal<>();

  @Override
  protected void doWebPageFilter(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, FilterChain filterChain)
      throws ServletException, IOException {

    if(!RequestUtil.isMultipartFormData(httpServletRequest.getContentType())){
      RereadableRequestWrapper rereadableRequestWrapper = new RereadableRequestWrapper(
          httpServletRequest);

      requestContext.set(httpServletRequest);
      responseContext.set(httpServletResponse);

      filterChain.doFilter(rereadableRequestWrapper, httpServletResponse);
    }else{
      filterChain.doFilter(httpServletRequest, httpServletResponse);
    }
  }

  @Override
  public int getOrder() {
    return Integer.MIN_VALUE;
  }

  private void remove(){
    requestContext.remove();
    responseContext.remove();
  }

  public static HttpServletRequest getHttpServletRequest(){
    RereadableRequestFilter filter = ApplicationContextHolder.getBean(RereadableRequestFilter.class);
    return filter.getRequest();
  }

  public static HttpServletResponse getHttpServletResponse(){
    RereadableRequestFilter filter = ApplicationContextHolder.getBean(RereadableRequestFilter.class);
    return filter.getResponse();
  }

  public HttpServletRequest getRequest(){
    return requestContext.get();
  }
  public HttpServletResponse getResponse(){
    return responseContext.get();
  }

  public static void removeContexts(){
    RereadableRequestFilter filter = ApplicationContextHolder.getBean(RereadableRequestFilter.class);
    filter.remove();
  }
}
