/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.web.request.data.HttpRequestData;
import jakarta.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
public class HttpRequestHelper {

  public static HttpRequestData getHttpRequestData(HttpServletRequest request) {

    // Headers
    Map<String, String> headers = new HashMap<>();
    Enumeration<String> headerNames = request.getHeaderNames();
    while (headerNames.hasMoreElements()) {
      String headerName = headerNames.nextElement();
      headers.put(headerName, request.getHeader(headerName));
    }

    // Body
    StringBuilder body = new StringBuilder();
    try {
      BufferedReader reader = request.getReader();
      String line;
      while ((line = reader.readLine()) != null) {
        body.append(line);
      }
    }catch (Exception e) {
      log.error("error occurred during parse body : {}", e.getMessage(), e);
      body.append(e.getMessage());
    }

    return new HttpRequestData()
        .withQueryString(request.getQueryString())
        .withRequestURL(request.getRequestURL().toString())
        .withSecure(request.isSecure())
        .withMethod(request.getMethod())
        .withBody(body.toString())
        .withHeaders(headers)
        .withParameters(request.getParameterMap());
  }

}
