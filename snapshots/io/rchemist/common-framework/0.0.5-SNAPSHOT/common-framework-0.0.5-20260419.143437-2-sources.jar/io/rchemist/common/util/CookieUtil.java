/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Base64;
import java.util.Optional;
import org.springframework.util.SerializationUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CookieUtil {

  public static final int DEFAULT_EXPIRY = 7 * 24 * 60 * 60;    // 7일
  public static final int SHORT_EXPIRY = 30 * 60;   // 30분
  public static final String DEFAULT_PATH = "/";

  public static Optional<Cookie> getCookie(HttpServletRequest request, String name) {
    Cookie[] cookies = request.getCookies();

    if (cookies != null && cookies.length > 0) {
      for (Cookie cookie : cookies) {
        if (cookie.getName().equals(name)) {
          return Optional.of(cookie);
        }
      }
    }

    return Optional.empty();
  }

  public static String getCookieValue(HttpServletRequest request, String name, boolean decode){
    Optional<Cookie> cookie = getCookie(request, name);
    if(cookie.isPresent()){
      return getValue(cookie.get(), decode);
    }
    return null;
  }

  private static String getValue(Cookie cookie, boolean decode){
    return (decode) ? decode(cookie, String.class) : cookie.getValue();
  }


  public static void addCookie(HttpServletResponse response, String name, String value){
    addCookie(response, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, false, false, false);
  }

  public static void addSecureCookie(HttpServletResponse response, String name, String value){
    addCookie(response, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, true, false, false);
  }

  public static void addHttpOnlyCookie(HttpServletResponse response, String name, String value){
    addCookie(response, DEFAULT_PATH, name, value, DEFAULT_EXPIRY, false, true, false);
  }

  public static void addCookie(HttpServletResponse response, String path, String name, String value, int maxAge, boolean secure, boolean httpOnly, boolean encode) {
    if(encode){
      value = encode(value);
    }
    Cookie cookie = new Cookie(name, value);
    cookie.setPath(path);
    cookie.setSecure(secure);
    cookie.setHttpOnly(httpOnly);
    cookie.setMaxAge(maxAge);
    response.addCookie(cookie);
  }

  public static void deleteCookie(HttpServletRequest request, HttpServletResponse response, String name) {
    Cookie[] cookies = request.getCookies();
    if (cookies != null && cookies.length > 0) {
      for (Cookie cookie: cookies) {
        if (cookie.getName().equals(name)) {
          cookie.setValue("");
          cookie.setPath(cookie.getPath());
          cookie.setMaxAge(0);
          response.addCookie(cookie);
        }
      }
    }
  }

  public static String encode(Object object) {
    return Base64.getUrlEncoder()
        .encodeToString(SerializationUtils.serialize(object));
  }

  public static <T> T decode(Cookie cookie, Class<T> cls) {
    return cls.cast(SerializationUtils.deserialize(
        Base64.getUrlDecoder().decode(cookie.getValue())));
  }
}

