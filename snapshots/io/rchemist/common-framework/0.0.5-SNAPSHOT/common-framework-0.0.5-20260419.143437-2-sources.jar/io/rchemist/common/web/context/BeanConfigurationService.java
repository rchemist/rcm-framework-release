/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.context;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.transformer.ConditionalExcludeScan;
import io.rchemist.common.util.StringUtil;
import java.util.Map;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.GenericWebApplicationContext;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmBeanConfigurationService")
@Slf4j
public class BeanConfigurationService implements ApplicationContextAware {

  @Value("${platform.config.endpoint.conditional-exclude:false}")
  @Getter
  @Setter
  private boolean conditionalExclude = false;

  @Getter
  @Autowired
  protected GenericWebApplicationContext webApplicationContext;

  @Getter
  protected ApplicationContext applicationContext;

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

  /**
   * register bean definition programmatically
   * @param beanName
   * @param factoryBeanClass
   * @param attributes
   * @param scope
   * @param override
   */
  public void registerBean(String beanName, Class factoryBeanClass, @Nullable Map<String, Object> attributes, @Nullable String scope, boolean override){
    if(webApplicationContext.containsBeanDefinition(beanName)){
      if(!override){
        return;
      }else{
        webApplicationContext.removeBeanDefinition(beanName);
      }
    }

    scope = StringUtil.toString(scope, BeanDefinition.SCOPE_SINGLETON);

    GenericBeanDefinition bd = new GenericBeanDefinition();
    bd.setBeanClass(factoryBeanClass);
    bd.setScope(scope);

    if(MapUtils.isNotEmpty(attributes)){
      attributes.entrySet().forEach(entry ->{
        bd.setAttribute(entry.getKey(), entry.getValue());
      });
    }

    webApplicationContext.registerBeanDefinition(beanName, bd);

  }

  public static void conditionalExcludeBeans(){

    try{
      BeanConfigurationService service = ApplicationContextHolder.getBean(BeanConfigurationService.class);

      if(service != null && service.isConditionalExclude()){

        GenericWebApplicationContext applicationContext = service.getWebApplicationContext();

        BeanDefinitionRegistry registry = (BeanDefinitionRegistry) applicationContext.getAutowireCapableBeanFactory();
        for(String name : registry.getBeanDefinitionNames()){
          BeanDefinition definition = registry.getBeanDefinition(name);
          try {
            Class beanClass = Class.forName(definition.getBeanClassName());

            ConditionalExcludeScan excludeScan = (ConditionalExcludeScan) beanClass.getDeclaredAnnotation(ConditionalExcludeScan.class);
            if(excludeScan != null){
              registry.removeBeanDefinition(name);
            }

          } catch (Exception e) {
            //e.printStackTrace();
          }
        }

        log.info("All beans of annotated with @ConditionalExcludeScan has removed.");

      }


    }catch (Exception e){
      // nothing
      e.printStackTrace();
      log.warn(e.getMessage());
    }

  }


}
