/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class FileServiceErrorType extends EnumType<FileServiceErrorType> implements ErrorType {

  public static final FileServiceErrorType RESOURCE_NOT_FOUND = new FileServiceErrorType("RESOURCE_NOT_FOUND", "Resource name not found.", "ResourceName 정보가 필요합니다.", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final FileServiceErrorType FILE_NOT_FOUND = new FileServiceErrorType("FILE_NOT_FOUND", "File not found.", "File 이 없습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final FileServiceErrorType FAILED_TO_CREATE_TEMP_DIRECTORY = new FileServiceErrorType("FAILED_TO_CREATE_TEMP_DIRECTORY", "Failed to create temp directory.", "TEMP 디렉토리를 생성하는 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final FileServiceErrorType EXCEED_MAX_UPLOAD_SIZE = new FileServiceErrorType("EXCEED_MAX_UPLOAD_SIZE", "Exceed to max upload file size.", "업로드할 수 있는 파일의 크기 제한을 초과했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);;
  public static final FileServiceErrorType NOT_FOUND_ASSET_INFO = new FileServiceErrorType("NOT_FOUND_ASSET_INFO", "AssetUpload info not found.", "AssetUpload 정보가 필요합니다.", HttpStatus.INTERNAL_SERVER_ERROR);;
  public static final FileServiceErrorType FAILED_TO_UPLOAD_FILE = new FileServiceErrorType("FAILED_TO_UPLOAD_FILE", "Failed to upload file.", "파일 업로드 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);;
  public static final FileServiceErrorType WEB_REQUEST_CONTEXT_NOT_FOUND = new FileServiceErrorType("WEB_REQUEST_CONTEXT_NOT_FOUND", "WebRequestContext not found.", "WebRequestContext 정보가 필요합니다.", HttpStatus.INTERNAL_SERVER_ERROR);;
  public static final FileServiceErrorType INVALID_FILE_TYPE = new FileServiceErrorType("INVALID_FILE_TYPE", "Invalid file.", "해당 파일을 업로드할 수 없습니다.", HttpStatus.INTERNAL_SERVER_ERROR);;

  @Getter
  private final int status;

  public FileServiceErrorType(String type, String friendlyType, String description, HttpStatus httpStatus) {
    super(type, friendlyType, description);
    this.status = httpStatus.value();
  }
}
