/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.file.service;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@ConditionalOnExpression("!${platform.config.microservice.admin:false}")
@Configuration
public class FileUploadConfig implements WebApplicationInitializer {

  @Value("${platform.config.common.file.max_upload_size:1000000000}")
  protected long maxUploadSize;

  @Bean
  public StandardServletMultipartResolver multipartResolver(){
    StandardServletMultipartResolver resolver = new StandardServletMultipartResolver();
    /*
    resolver.setMaxUploadSizePerFile(maxUploadSize);
    resolver.setMaxInMemorySize(1024 * 1024);
    resolver.setDefaultEncoding("UTF-8");*/
    return resolver;
  }

  @Override
  public void onStartup(ServletContext servletContext) throws ServletException {
    AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
  }
}
