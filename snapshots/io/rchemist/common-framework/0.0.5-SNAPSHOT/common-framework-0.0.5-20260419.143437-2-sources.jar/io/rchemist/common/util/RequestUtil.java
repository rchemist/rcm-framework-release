/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.util.data.ParameterDTO;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.RereadableRequestFilter;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class RequestUtil {

  private static final String HAS_DETECT_DEVICE_TYPE = "checkedDeviceType";
  private static final String DETECT_APP_KEYWORD = "APP_";
  private static final String REDIRECT_URL = "redirect:";
  private static final String REFERER_URL = "Referer";
  private static final String MULTIPART_FORMDATA = "multipart/form-data";
  private static final String USER_AGENT = "User-Agent";
  private static final String[] MOBILE_KEYWORDS = {"Mobile", "Android", "iPhone", "iPod", "BlackBerry", "Windows Phone", "webOS"};
  private static final String[] TABLET_KEYWORDS = {"iPad", "Tablet", "Android.*Tab", "Kindle", "Silk"};
  private static final String[] PC_EXCLUDE_KEYWORDS = {"Mobile", "Android", "iPhone", "iPad"};

  private static HttpServletRequest getRequestInternal(){
    RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
    if (requestAttributes instanceof ServletRequestAttributes) {
      return ((ServletRequestAttributes)requestAttributes).getRequest();
    }
    return RereadableRequestFilter.getHttpServletRequest();
  }

  private static HttpServletResponse getResponseInternal(){
    RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
    if (requestAttributes instanceof ServletRequestAttributes) {
      return ((ServletRequestAttributes)requestAttributes).getResponse();
    }
    return RereadableRequestFilter.getHttpServletResponse();
  }

  public static HttpServletRequest getHttpServletRequest(){
    return getRequestInternal();
  }

  public static HttpServletResponse getHttpServletResponse(){
    return getResponseInternal();
  }

  public static ServletServerHttpRequest getRequest(){
    return getServletServerHttpRequestFromContext();
  }

  public static Map<String, String[]> getRequestParamArray(String uri, String additionalSplitCode) {
    Map<String, List<String>> paramList = getRequestParamList(uri, additionalSplitCode);
    Map<String, String[]> paramArray = new HashMap<>();
    if( MapUtils.isNotEmpty(paramList)) {
      for(Entry<String, List<String>> entry : paramList.entrySet()) {
        paramArray.put(entry.getKey(), entry.getValue().toArray(new String[entry.getValue().size()]));
      }
    }
    return paramArray;
  }

  /**
   * ?a=100&b=200&c=300&c=400
   */
  public static Map<String, List<String>> getRequestParamList(String uri, String additionalSplitCode){

    if(StringUtils.contains(uri, "?")){
      /**
       * a =100&b=200&c=300&c=400
       **/
      String queryString = StringUtils.substringAfter(uri, "?");

      if(StringUtils.isNotBlank(queryString)){

        boolean additionalSplit = StringUtils.isNotBlank(additionalSplitCode);

        Map<String, List<String>> returnMap = new HashMap<>();


        /**
         * a=100
         * b=200
         * c=300
         * c=400
         */
        String[] params = StringUtils.split(queryString, "&");

        for(String param : params){
          String key;
          List<String> values = new ArrayList<>();

          String defaultSplitCode;

          if(StringUtils.contains(param, "=")){
            defaultSplitCode = "=";
          }else{
            defaultSplitCode = additionalSplitCode;
            additionalSplitCode = null;
          }

          returnMap = getParameterValues(defaultSplitCode, additionalSplitCode, additionalSplit, returnMap, param);
        }

        return returnMap;

      }
    }

    return null;


  }

  private static Map<String, List<String>> getParameterValues(String defaultSplitCode, String additionalSplitCode, boolean additionalSplit, Map<String, List<String>> returnMap, String param) {
    if(StringUtils.isEmpty(defaultSplitCode)){
      return MapUtil.mergeListHashMap(returnMap, param, param, false);
    }else{
      String[] paramValue = StringUtils.split(param, defaultSplitCode);
      // BUG-019 fix (0.0.10.F): "key=" 처럼 value 가 비어있으면 StringUtils.split 가
      // ["key"] 길이 1 을 반환해 paramValue[1] 에서 AIOOBE. 빈 문자열로 보정.
      String key = paramValue[0];
      String rawValue = paramValue.length > 1 ? paramValue[1] : "";
      if(additionalSplit && StringUtils.contains(rawValue, additionalSplitCode)){
        String[] additionalValues = StringUtils.split(rawValue, additionalSplitCode);
        for(String value : additionalValues){
          returnMap = MapUtil.mergeListHashMap(returnMap, key, value, false);
        }
      }else{
        returnMap = MapUtil.mergeListHashMap(returnMap, key, rawValue, false);
      }
      return returnMap;
    }
  }


  public static HttpServletRequest getHttpServletRequest(Object requestObj) throws ServletException {
    HttpServletRequest request;
    if(requestObj instanceof ServletWebRequest){
      request = ((ServletWebRequest) requestObj).getRequest();
    }else if (requestObj instanceof ServletServerHttpRequest ssr) {
      request = ssr.getServletRequest();
    }else if(requestObj instanceof HttpServletRequest){
      // HttpServletRequest 로 넘어 왔다면 request 에서 URL 정보를 불러온다
      request = (HttpServletRequest) requestObj;
    }else if(requestObj instanceof WebRequest){
      // WebRequest 로 넘어 왔다면 blRequestDTO를 가지고 있다는 뜻
      WebRequest req = (WebRequest) requestObj;
      request = ((NativeWebRequest)req).getNativeRequest(HttpServletRequest.class);
    }else{
      throw new ServletException("There is no properly request");
    }
    return request;
  }

  public static String getBasePath(HttpServletRequest request) {
    StringBuilder basePath = new StringBuilder();
    String scheme = request.getScheme();
    String domain = request.getServerName();
    int port = request.getServerPort();
    basePath.append(scheme);
    basePath.append("://");
    basePath.append(domain);
    if("http".equalsIgnoreCase(scheme) && 80 != port) {
      basePath.append(":").append(port);
    } else if("https".equalsIgnoreCase(scheme) && port != 443) {
      basePath.append(":").append(port);
    }
    return basePath.toString();
  }

  public static String getRefererUrl(HttpServletRequest request) {
    return request.getHeader(REFERER_URL);
  }

  public static String getRedirectRefererUrl(HttpServletRequest request) {
    return getRedirectRefererUrl(request, "/");
  }

  public static String getRedirectRefererUrl(HttpServletRequest request, String defaultPath) {
    String targetUrl = getRefererUrl(request);
    defaultPath = StringUtil.toString(defaultPath, "/");
    return REDIRECT_URL + (StringUtils.isBlank(targetUrl) ? defaultPath : targetUrl);
  }

  public static boolean isSecureRequest(HttpServletRequest request) {
    return (request.isSecure() || "HTTPS".equalsIgnoreCase(request.getScheme()));
  }

  public static String getURLorHeaderParameter(ServletServerHttpRequest request, String varName) {
    String returnValue = request.getServletRequest().getHeader(varName);
    if (returnValue == null) {
      returnValue = request.getServletRequest().getParameter(varName);
    }
    return returnValue;
  }

  public static String getURLorHeaderParameter(HttpServletRequest request, String varName) {
    String returnValue = request.getHeader(varName);
    if (returnValue == null) {
      returnValue = request.getParameter(varName);
    }
    return returnValue;
  }

  public static Object getSessionAttribute(String attribute) {
    return getAttribute(null, attribute, RequestAttributes.SCOPE_SESSION);
  }

  public static Object getSessionAttribute(ServletServerHttpRequest request, String attribute) {
    return getAttribute(request, attribute, RequestAttributes.SCOPE_SESSION);
  }

  public static Object getAttribute(String attribute) {
    return getAttribute(null, attribute, RequestAttributes.SCOPE_REQUEST);
  }


  public static Object getAttribute(ServletServerHttpRequest request, String attribute, int scope) {
    if(request == null){
      request = getServletServerHttpRequestFromContext();
    }

    if (scope == RequestAttributes.SCOPE_REQUEST) {
      return request.getServletRequest().getAttribute(attribute);
    } else {
      if (request != null && request.getServletRequest().getSession() != null) {
        return request.getServletRequest().getSession().getAttribute(attribute);
      }
    }

    return null;
  }


  private static ServletServerHttpRequest getServletServerHttpRequestFromContext() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if(context == null || context.getRequest() == null){
      HttpServletRequest request = getRequestInternal();
      return new ServletServerHttpRequest(request);
    }

    return (ServletServerHttpRequest) context.getRequest();
  }


  public static boolean setSessionAttribute(String attribute, Object value) {
    return setAttribute(attribute, value, RequestAttributes.SCOPE_SESSION);
  }

  public static boolean setAttribute(String attribute, Object value, int scope) {
    return setAttribute(null, attribute, value, scope);
  }

  public static boolean setAttribute(ServletServerHttpRequest request, String attribute, Object value, int scope) {
    if (request == null) {
      request = getServletServerHttpRequestFromContext();
    }

    if (request != null) {

      if (scope == RequestAttributes.SCOPE_REQUEST) {
        request.getServletRequest().setAttribute(attribute, value);
      } else {
        if (request.getServletRequest().getSession() == null) {
          return false;
        } else {
          request.getServletRequest().getSession().setAttribute(attribute, value);
        }
      }
      return true;
    }

    return false;
  }



  public static void removeSessionAttribute(String attribute) {
    ServletServerHttpRequest request = getServletServerHttpRequestFromContext();

    if (request != null) {
      removeSessionAttribute(request, attribute);
    }
  }

  public static void removeSessionAttribute(ServletServerHttpRequest request, String attribute) {
    if (request != null && request.getServletRequest().getSession() != null) {
      request.getServletRequest().getSession().removeAttribute(attribute);
    }
  }

  public static DeviceType getCurrentDeviceType(Object request){
    try {
      if(request == null)
        return DeviceType.UNIDENTIFIED;

      HttpServletRequest servletRequest = getHttpServletRequest(request);

      if(servletRequest == null)
        return DeviceType.UNIDENTIFIED;

      String userAgent = servletRequest.getHeader(USER_AGENT);
      
      // null 체크 추가
      if(StringUtils.isBlank(userAgent)){
        return DeviceType.UNIDENTIFIED;
      }

      // 앱 감지 (APP_ 키워드가 있으면 앱으로 처리)
      if(StringUtils.containsIgnoreCase(userAgent, DETECT_APP_KEYWORD)){
        return DeviceType.MOBILE_APP;
      }
      
      // 태블릿 감지 (태블릿을 먼저 체크)
      for(String keyword : TABLET_KEYWORDS){
        if(userAgent.matches(".*" + keyword + ".*")){
          return DeviceType.MOBILE;
        }
      }
      
      // 모바일 감지
      for(String keyword : MOBILE_KEYWORDS){
        if(StringUtils.containsIgnoreCase(userAgent, keyword)){
          return DeviceType.MOBILE;
        }
      }
      
      // PC 제외 키워드 체크 (모바일 키워드가 있으면 PC가 아님)
      for(String keyword : PC_EXCLUDE_KEYWORDS){
        if(StringUtils.containsIgnoreCase(userAgent, keyword)){
          return DeviceType.MOBILE;
        }
      }
      
      // 위 조건에 해당하지 않으면 PC
      return DeviceType.PC;

    } catch (ServletException e) {
      ExceptionUtil.printStackTrace(e);
      return DeviceType.PC;
    }
  }

  public static DeviceType getCurrentDeviceTypeFromSession(){
    ServletServerHttpRequest request = getRequest();
    return getCurrentDeviceTypeFromSession(request);
  }

  public static DeviceType getCurrentDeviceTypeFromSession(ServletServerHttpRequest request){
    if(request != null){
      if(getSessionAttribute(request, HAS_DETECT_DEVICE_TYPE) != null){
        String deviceType = (String) getSessionAttribute(request, HAS_DETECT_DEVICE_TYPE);
        return EnumTypeUtil.getEnumType(DeviceType.class, deviceType, DeviceType.UNIDENTIFIED);
      }else{
        DeviceType deviceType = getCurrentDeviceType(request);
        setSessionAttribute(HAS_DETECT_DEVICE_TYPE, deviceType.getType());
        return deviceType;
      }
    }
    return DeviceType.UNIDENTIFIED;
  }

  /**
   * multipart upload 인 경우에는 이 핸들러를 실행하지 않는다.
   * @param contentType
   * @return
   */
  public static boolean isMultipartFormData(String contentType){
    return StringUtils.startsWith(contentType, MULTIPART_FORMDATA);
  }

  public static String getUri(String url, Map<String, String[]> parameters) {
    if(MapUtils.isEmpty(parameters)){
      return url;
    }
    
    StringBuilder urlBuilder = new StringBuilder(url);
    
    // Query string 시작 처리
    if(!StringUtils.contains(url, "?")){
      urlBuilder.append("?useNavigate");
    }else if(url.endsWith("?")){
      urlBuilder.append("useNavigate");
    }

    // 파라미터 추가
    for(Entry<String, String[]> entry : parameters.entrySet()){
      String name = entry.getKey();
      String[] values = entry.getValue();

      urlBuilder.append("&").append(name).append("=");
      
      if(ArrayUtils.isNotEmpty(values)){
        for(int i = 0; i < values.length; i++){
          if(i > 0){
            urlBuilder.append(",");
          }
          urlBuilder.append(values[i]);
        }
      }
    }
    
    return urlBuilder.toString();
  }

  public static ParameterDTO parseParameters(String uri){
    return RequestParameterUtil.parseParameters(uri);
  }

}
