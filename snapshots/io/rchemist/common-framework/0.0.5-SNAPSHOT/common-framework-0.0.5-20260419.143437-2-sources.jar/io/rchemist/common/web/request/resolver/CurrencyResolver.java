/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Currency;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmCurrencyResolver")
@Slf4j
public class CurrencyResolver implements RequestAttributeResolver<Currency> {

  public static final String CURRENCY_ATTR_NAME = "currency";
  public static final String REQUESTED_CURRENCY_CODE = "currency";

  @Value("${platform.config.common.default.currency:KRW}")
  protected String currencyCode;

  @Override
  public boolean canHandle(Class<Currency> clazz) {
    return clazz.equals(Currency.class);
  }

  @Override
  public void resolve(WebRequestContext context) {

    HttpServletRequest request = RequestUtil.getHttpServletRequest();

    Currency currency;
    try {
      currency = (Currency) request.getAttribute(CURRENCY_ATTR_NAME);

      if(currency == null){
        currency = getCurrencyFromRequest(request);
      }

      if(currency == null){
        currency = getCurrencyFromSession(request);
      }

      if(currency == null){
        currency = Currency.getInstance(currencyCode);
      }

    }catch (Exception e) {
      log.debug("Error resolving currency", e);
      // 기본 로케일로 커런시 셋팅

      currency = Currency.getInstance(context.getLocale());
    }
    context.setCurrency(currency);

  }

  protected Currency getCurrencyFromSession(HttpServletRequest request) {
    if (request.getSession() != null && request.getSession().getAttribute(CURRENCY_ATTR_NAME) != null) {
      return (Currency) request.getSession().getAttribute(CURRENCY_ATTR_NAME);
    }
    return null;
  }

  protected Currency getCurrencyFromRequest(HttpServletRequest request) {
    String code = RequestUtil.getURLorHeaderParameter(request, REQUESTED_CURRENCY_CODE);
    if(StringUtils.isNotEmpty(code)){
      return Currency.getInstance(code);
    }
    return null;
  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, CURRENCY_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.CURRENCY_RESOLVER;
  }
}
