/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.multitenant.extension;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import jakarta.servlet.http.HttpServletRequest;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = "rcmTenantInformationExtensionManager", priority = 400)
public class RetrieveRequestBodyExtensionHandler extends AbstractTenantInformationExtensionHandler{

  private static final String MULTIPART_FORMDATA = "multipart/form-data";

  @Override
  public ExtensionResultStatusType findTenantInformation(HttpServletRequest request,
      ExtensionResultHolder<TenantInformation> erh) {

    // multipart formdata 일 때는 request body 를 읽으면 안 된다.
    if(!StringUtils.startsWith(request.getContentType(), MULTIPART_FORMDATA)){

      try {
        String requestBody = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
        JsonObject parameters = new Gson().fromJson(requestBody, JsonObject.class);

        if(parameters != null){
          String tenantAlias = null;
          String siteAlias = null;

          if(parameters.has("tenantAlias")){
            tenantAlias = parameters.get("tenantAlias").getAsString();
          }
          if(parameters.has("siteAlias")){
            siteAlias = parameters.get("siteAlias").getAsString();
          }

          if(StringUtils.isNotEmpty(tenantAlias)){
            erh.setResult(new TenantInformation(tenantAlias, siteAlias));
            return ExtensionResultStatusType.HANDLED;
          }
        }

      } catch (Exception e) {
        // e.printStackTrace();
      }

    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
