/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.RequestDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmRequestDTOResolver")
public class RequestDTOResolver implements RequestAttributeResolver<RequestDTO> {

  @Override
  public boolean canHandle(Class<RequestDTO> clazz) {
    return clazz.equals(RequestDTO.class);
  }

  @Override
  public void resolve(WebRequestContext context) {

    ServletServerHttpRequest request = (ServletServerHttpRequest) context.getRequest();

    RequestDTO dto;
    if(RequestUtil.getAttribute(request, RequestDTO.REQUEST_DTO_NAME, RequestAttributes.SCOPE_REQUEST) != null){
      dto = (RequestDTO) RequestUtil.getAttribute(request, RequestDTO.REQUEST_DTO_NAME, RequestAttributes.SCOPE_REQUEST);
    }else{
      dto = new RequestDTO();

      String requestUri = request.getURI().toString();
      String requestUrl = request.getURI().toString();
      if(requestUrl.contains("?")){
        requestUrl = StringUtils.substringBefore(requestUrl, "?");
      }

      dto.setRequestURI(requestUrl);
      dto.setSecure(request.getURI().getScheme().equals("https"));
      dto.setDeviceType(RequestUtil.getCurrentDeviceTypeFromSession(request));
      dto.setFullUrlWithQuery(requestUri);

      RequestUtil.setSessionAttribute(RequestDTO.REQUEST_DTO_NAME, dto);

    }
    context.setRequestDTO(dto);
  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, RequestDTO.REQUEST_DTO_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.REQUEST_DTO_RESOLVER;
  }
}
