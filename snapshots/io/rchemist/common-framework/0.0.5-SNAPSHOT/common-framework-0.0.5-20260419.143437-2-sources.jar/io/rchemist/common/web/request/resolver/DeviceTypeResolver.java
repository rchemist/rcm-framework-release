/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmDeviceTypeResolver")
public class DeviceTypeResolver implements RequestAttributeResolver<DeviceType> {

  public static final String DEVICE_TYPE_ATTR_NAME = "deviceType";

  @Override
  public boolean canHandle(Class<DeviceType> clazz) {
    return clazz.equals(DeviceType.class);
  }

  @Override
  public void resolve(WebRequestContext context) {

    HttpServletRequest request = RequestUtil.getHttpServletRequest();

    DeviceType deviceType;

    try {
      deviceType = (DeviceType) request.getAttribute(DEVICE_TYPE_ATTR_NAME);

      if(deviceType == null){
        String deviceTypeStr = RequestUtil.getURLorHeaderParameter(request, DEVICE_TYPE_ATTR_NAME);
        deviceType = EnumTypeUtil.getEnumType(DeviceType.class, deviceTypeStr, DeviceType.UNIDENTIFIED);
      }

      if (deviceType == null) {
        deviceType = RequestUtil.getCurrentDeviceType(request);
      }

      if (deviceType == null) {
        deviceType = DeviceType.UNIDENTIFIED;
      }

    } catch (Exception e) {
      deviceType = DeviceType.UNIDENTIFIED;
    }

    context.setDeviceType(deviceType);
  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, DEVICE_TYPE_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.DEVICE_TYPE_RESOLVER;
  }
}
