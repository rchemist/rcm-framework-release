/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmWebRequestContextFilter")
@Slf4j
public class WebRequestContextFilter extends AbstractWebPageOncePerRequestFilter {

  protected final WebRequestContextProcessor webRequestContextProcessor;

  private Set<String> ignoreSuffixes;

  public WebRequestContextFilter(WebRequestContextProcessor webRequestContextProcessor) {
    this.webRequestContextProcessor = webRequestContextProcessor;
  }

  @Override
  protected void doWebPageFilter(HttpServletRequest request,
      HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    if (!shouldProcessURL(request, request.getRequestURI())) {
      filterChain.doFilter(request, response);
      return;
    }

    try {
      webRequestContextProcessor.process(new ServletWebRequest(request, response));
      filterChain.doFilter(request, response);
    } finally {
      webRequestContextProcessor.postProcess(new ServletWebRequest(request, response));
    }

  }

  protected boolean shouldProcessURL(HttpServletRequest request, String requestURI) {
    int pos = requestURI.lastIndexOf(".");
    if (pos > 0) {
      String suffix = requestURI.substring(pos);
      if (getIgnoreSuffixes().contains(suffix.toLowerCase())) {
        return false;
      }
    }
    return true;
  }

  protected Set getIgnoreSuffixes() {
    if (ignoreSuffixes == null || ignoreSuffixes.isEmpty()) {
      String[] ignoreSuffixList = {".aif", ".aiff", ".asf", ".avi", ".bin", ".bmp", ".css", ".doc",
          ".eps", ".gif", ".hqx", ".js", ".jpg", ".jpeg", ".mid", ".midi", ".mov", ".mp3", ".mpg",
          ".mpeg", ".p65", ".pdf", ".pic", ".pict", ".png", ".ppt", ".psd", ".qxd", ".ram", ".ra",
          ".rm", ".sea", ".sit", ".stk", ".swf", ".tif", ".tiff", ".txt", ".rtf", ".vob", ".wav",
          ".wmf", ".xls", ".xlsx", ".zip"};
      ignoreSuffixes = new HashSet<String>(Arrays.asList(ignoreSuffixList));
    }
    return ignoreSuffixes;
  }

  @Override
  protected boolean shouldNotFilterErrorDispatch() {
    return false;
  }

  @Override
  public int getOrder() {
    return WebPageFilter.POST_SECURITY_HIGH;
  }
}
