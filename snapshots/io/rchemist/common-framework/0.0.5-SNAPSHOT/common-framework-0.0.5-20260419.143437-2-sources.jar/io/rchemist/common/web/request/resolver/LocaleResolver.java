/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.WebRequestContext;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.LocaleUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmLocaleResolver")
@Slf4j
public class LocaleResolver implements RequestAttributeResolver<Locale> {

  public static final String LOCALE_ATTR_NAME = "locale";
  public static final String REQUESTED_LOCALE_NAME = "locale";

  @Override
  public boolean canHandle(Class<Locale> clazz) {
    return clazz.equals(Locale.class);
  }

  @Override
  public void resolve(WebRequestContext context) {

    ServletServerHttpRequest request = (ServletServerHttpRequest) context.getRequest();

    Locale locale;

    try {
      locale = (Locale) RequestUtil.getAttribute(request, LOCALE_ATTR_NAME, RequestAttributes.SCOPE_REQUEST);

      if(locale == null){
        locale = getLocaleFromRequest(request);
      }

      if(locale == null){
        locale = (Locale) RequestUtil.getSessionAttribute(LOCALE_ATTR_NAME);
      }

      if(locale == null){
        locale = Locale.getDefault();
      }

    } catch (Exception e) {
      log.debug("Error resolving locale", e);
      locale = Locale.getDefault();
    }
    context.setLocale(locale);
  }

  protected Locale getLocaleFromRequest(ServletServerHttpRequest request) {
    String localeCode = RequestUtil.getURLorHeaderParameter(request, REQUESTED_LOCALE_NAME);
    if(StringUtils.isNotEmpty(localeCode)){
      try {
        return LocaleUtils.toLocale(localeCode);
      }catch (Exception e){
        log.debug("Error parsing locale code: {}", localeCode, e);
      }
    }
    return null;
  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, LOCALE_ATTR_NAME);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.LOCALE_RESOLVER;
  }
}
