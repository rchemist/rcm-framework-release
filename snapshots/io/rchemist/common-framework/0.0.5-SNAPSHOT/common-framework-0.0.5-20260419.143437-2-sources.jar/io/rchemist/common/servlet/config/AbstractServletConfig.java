/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.servlet.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.webresources.ExtractingRoot;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class AbstractServletConfig {

  protected TomcatServletWebServerFactory buildTomcatEmbeddedServletContainerFactory(int httpServerPort, boolean httpsProxyMode, final GracefulShutdown gracefulShutdown) {
    TomcatServletWebServerFactory tomcat = tomcatEmbeddedServletContainerFactory();
    tomcat.addAdditionalTomcatConnectors(createStandardConnector(httpServerPort, httpsProxyMode));
    tomcat.addConnectorCustomizers(gracefulShutdown);
    return tomcat;
  }

  protected TomcatServletWebServerFactory tomcatEmbeddedServletContainerFactory() {
    return new TomcatServletWebServerFactory() {

      @Override
      protected void postProcessContext(Context context) {
        context.setResources(new ExtractingRoot());
      }
    };
  }

  private Connector createStandardConnector(int port, boolean httpsProxyMode) {
    Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
    connector.setPort(port);
    if(httpsProxyMode) {
      connector.setProxyPort(443);
      connector.setScheme("https");
      connector.setSecure(true);
    }
    return connector;
  }

  /**
   * Tomcat Shutdown (kill -15)
   */
  public static class GracefulShutdown implements TomcatConnectorCustomizer, ApplicationListener<ContextClosedEvent> {
    private final int TIMEOUT = 30;
    private volatile Connector connector;

    @Override
    public void customize(Connector connector) {
      this.connector = connector;
    }

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
      this.connector.pause();
      Executor executor = this.connector.getProtocolHandler().getExecutor();
      if (executor instanceof ThreadPoolExecutor) {
        try {
          ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executor;
          threadPoolExecutor.shutdown();
          if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
            log.info("Tomcat thread pool did not shut down gracefully within "
                + TIMEOUT + " seconds. Proceeding with forceful shutdown");

            threadPoolExecutor.shutdownNow();

            if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
              log.info("Tomcat thread pool did not terminate");
            }
          }
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
      }
    }
  }

}
