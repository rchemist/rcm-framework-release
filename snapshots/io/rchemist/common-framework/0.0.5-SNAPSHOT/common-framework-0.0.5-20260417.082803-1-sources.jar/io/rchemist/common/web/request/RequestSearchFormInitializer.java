/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.web.request.data.SearchForm;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort.Direction;

@Slf4j
public class RequestSearchFormInitializer {

  public static SearchForm initialize(HttpServletRequest request) {
    return new RequestSearchFormInitializer(request).getSearchForm();
  }

  private final HttpServletRequest request;

  private static final String CONDITION_SPLITTER = "_";
  private static final String ARRAY_VALUE_SPLITTER = "||";

  private static final String PAGE = "page";
  private static final String PAGE_SIZE = "pageSize";   // 문자열 비교를 위해 모두 소문자로 처리한다.
  private static final String SEARCH_TERM = "searchTerm";   // 통합 검색 문자열
  private static final String SORT = "sort";   // 통합 검색 문자열
  private static final List<String> RESERVED_PARAMETERS = List.of(PAGE, PAGE_SIZE, SEARCH_TERM,
      SORT);

  @Getter
  private final SearchForm searchForm;

  private RequestSearchFormInitializer(HttpServletRequest request) {
    this.request = request;
    this.searchForm = new SearchForm();
    initializeSearchForm();

  }

  private void initializeSearchForm() {

    if (!request.getParameterNames().hasMoreElements()) {
      return;
    }

    request.getParameterNames().asIterator().forEachRemaining(name -> {

      /*
      name 이 title_like 와 같은 경우 _ 뒤의 문자열은 조건에 해당한다.
      _ 가 없는 경우는 EQUALS 이 된다.
       */

      if (RESERVED_PARAMETERS.contains(name.toLowerCase())) {
        setReservedParameters(name);
      } else {
        setFilters(name);
      }


    });
  }

  private void setFilters(String name) {
    QueryConditionType condition = QueryConditionType.EQUAL;
    String field = name;

    if (name.contains(CONDITION_SPLITTER)) {
      field = name.substring(0, name.indexOf(CONDITION_SPLITTER));
      condition = getCondition(name.substring(name.indexOf(CONDITION_SPLITTER) + 1));
    }

    String value = request.getParameter(name);

    if (StringUtils.isEmpty(value) && !condition.isNoValue()) {
      return;
    }

    if (condition.isNoValue()) {
      setNullCondition(condition, field);
    } else {
      /*
      만약 복수값이 들어와야 하는 조건이라면 value 에 || 가 포함된다.
      dateCreated_btw=2024-01-01||2024-01-02 와 같은 식이 된다.
     */
      if (condition.isListCondition()) {

        setListCondition(value, condition, field);

      } else {

        setSingleCondition(condition, field, value);

      }
    }
  }

  private void setNullCondition(QueryConditionType condition, String field) {
    switch (condition) {
      case NULL -> searchForm.filterIsNull(field);
      case NOT_NULL -> searchForm.filterIsNotNull(field);
    }
  }

  private void setListCondition(String value, QueryConditionType condition, String field) {
    if (!value.contains(ARRAY_VALUE_SPLITTER)) {
      // list condition 인데 value 에 splitter 가 없으면 오류
      return;
    }

    List<String> values = List.of(value.split(ARRAY_VALUE_SPLITTER));

    switch (condition) {
      case BETWEEN -> searchForm.filterBetween(field, values);
      case NOT_BETWEEN -> searchForm.filterNotBetween(field, values);
      case IN -> searchForm.filterIn(field, values);
      case NOT_IN -> searchForm.filterNotIn(field, values);
    }
  }

  private void setSingleCondition(QueryConditionType condition, String field, String value) {
    switch (condition) {
      case EQUAL -> searchForm.filterEquals(field, value);
      case NOT_EQUAL -> searchForm.filterNotEquals(field, value);
      case EQUAL_IGNORECASE -> searchForm.filterEqualsIgnoreCase(field, value);
      case NOT_EQUAL_IGNORECASE -> searchForm.filterNotEqualsIgnoreCase(field, value);
      case START_WITH -> searchForm.filterStartWith(field, value);
      case NOT_START_WITH -> searchForm.filterNotStartWith(field, value);
      case END_WITH -> searchForm.filterEndWith(field, value);
      case NOT_END_WITH -> searchForm.filterNotEndWith(field, value);
      case LESS_THAN -> searchForm.filterLessThan(field, value);
      case LESS_THAN_EQUAL -> searchForm.filterLessThanOrEqual(field, value);
      case GREATER -> searchForm.filterGreaterThan(field, value);
      case GREATER_THAN_EQUAL -> searchForm.filterGreaterThanOrEqual(field, value);
      case NOT_LESS_THAN -> searchForm.filterNotLessThan(field, value);
      case NOT_LESS_THAN_EQUAL -> searchForm.filterNotLessThanOrEqual(field, value);
      case NOT_GREATER -> searchForm.filterNotGreaterThan(field, value);
      case NOT_GREATER_THAN_EQUAL -> searchForm.filterNotGreaterThanOrEqual(field, value);
      case LIKE -> searchForm.filterLike(field, value);
      case NOT_LIKE -> searchForm.filterNotLike(field, value);
    }
  }

  private void setReservedParameters(String name) {
    try {
      String value = request.getParameter(name);

      if (StringUtils.equalsIgnoreCase(name, PAGE)) {
        int page = NumberUtil.getInteger(value);
        searchForm.setPage(page);
      } else if (StringUtils.equalsIgnoreCase(name, PAGE_SIZE)) {
        int pageSize = NumberUtil.getInteger(value);
        searchForm.setPageSize(pageSize);
      } else if (StringUtils.equalsIgnoreCase(name, SORT)) {
        setSort(value);
      } else if (StringUtils.equalsIgnoreCase(name, SEARCH_TERM)) {
        setSearchTerm(value);
      }
    } catch (Exception e) {
      // pageSize에 숫자값이 들어오지 않은 경우는 무시한다.
      log.debug("Failed to parse reserved parameter :: " + name + " - " + request.getParameter(name));
    }
  }

  private void setSearchTerm(String value) {
    if (StringUtils.isEmpty(value)) {
      return;
    }

    searchForm.setSearchTerm(value);
  }

  private void setSort(String value) {
    if (StringUtils.isEmpty(value)) {
      return;
    }
    if (value.contains(ARRAY_VALUE_SPLITTER)) {
      // 두개 이상의 정렬인 경우
      String[] split = value.split(ARRAY_VALUE_SPLITTER);
      for (String sort : split) {
        setSortCondition(sort);
      }
    } else {
      setSortCondition(value);
    }
  }

  private void setSortCondition(String value) {
    String field = value;
    String direction = "asc";

    if (value.contains(CONDITION_SPLITTER)) {
      // asc 또는 desc 가 name 과 결합된 형태
      // title_desc 와 같은 식이다.
      String[] split = value.split(CONDITION_SPLITTER);
      field = split[0];
      direction = split[1];
    }
    searchForm.addSort(field, Direction.fromString(direction));
  }

  private QueryConditionType getCondition(String condition) {
    if (StringUtils.isEmpty(condition)) {
      return QueryConditionType.EQUAL;
    }
    condition = condition.toUpperCase();

    return switch (condition) {
      case "NEQ" -> QueryConditionType.NOT_EQUAL;
      case "EQI" -> QueryConditionType.EQUAL_IGNORECASE;
      case "NEQI" -> QueryConditionType.NOT_EQUAL_IGNORECASE;
      case "IN" -> QueryConditionType.IN;
      case "NIN" -> QueryConditionType.NOT_IN;
      case "NULL" -> QueryConditionType.NULL;
      case "NOTNULL" -> QueryConditionType.NOT_NULL;
      case "SW" -> QueryConditionType.START_WITH;
      case "NSW" -> QueryConditionType.NOT_START_WITH;
      case "EW" -> QueryConditionType.END_WITH;
      case "NEW" -> QueryConditionType.NOT_END_WITH;
      case "LT" -> QueryConditionType.LESS_THAN;
      case "LTE" -> QueryConditionType.LESS_THAN_EQUAL;
      case "GT" -> QueryConditionType.GREATER;
      case "GTE" -> QueryConditionType.GREATER_THAN_EQUAL;
      case "NLT" -> QueryConditionType.NOT_LESS_THAN;
      case "NLTE" -> QueryConditionType.NOT_LESS_THAN_EQUAL;
      case "NGT" -> QueryConditionType.NOT_GREATER;
      case "NGTE" -> QueryConditionType.NOT_GREATER_THAN_EQUAL;
      case "BTW" -> QueryConditionType.BETWEEN;
      case "NBTW" -> QueryConditionType.NOT_BETWEEN;
      case "LIKE" -> QueryConditionType.LIKE;
      case "NLIKE" -> QueryConditionType.NOT_LIKE;
      default -> QueryConditionType.EQUAL;
    };

  }


}
