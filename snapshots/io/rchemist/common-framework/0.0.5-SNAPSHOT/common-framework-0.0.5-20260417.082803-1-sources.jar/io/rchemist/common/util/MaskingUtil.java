/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.web.request.WebRequestContext;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.context.request.RequestAttributes;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 **/
public class MaskingUtil {

  /** The Constant EMAIL_PATTERN. */
  public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

  /**
   * Mask email address.
   *
   * @param email the email
   * @return the string
   */
  public static String maskEmailAddress(String email){
    String result = email;

    if(StringUtils.isNotBlank(email)){
      WebRequestContext context = WebRequestContext.getWebRequestContext();

      if(context.isAdmin()){
        if(!isCsr()){
          result = setMaskEmailAddress(email);
        }
      }else{
        result = setMaskEmailAddress(email);
      }
    }

    return result;
  }

  public static String setMaskEmailAddress(String email){
    String result = email;

    Pattern pattern = Pattern.compile(EMAIL_PATTERN);
    if(pattern.matcher(email).matches()){
      int i=email.indexOf("@");
      if(email.substring(0,i).length()>2){
        result=email.substring(0,i-2)+"**"+email.substring(i);
      }else{
        result=email.substring(0,i-1)+"**"+email.substring(i);
      }
    }

    return result;
  }

  /**
   * Mask phone number.
   *
   * @param phoneNumber the phone number
   * @return the string
   */
  public static String maskPhoneNumber(String phoneNumber){
    String result = phoneNumber;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskPhoneNumber(phoneNumber);
      }
    }else{
      result = setMaskPhoneNumber(phoneNumber);
    }

    return result;
  }

  public static String setMaskPhoneNumber(String phoneNumber){
    String result = phoneNumber;
    String maskValue="****";

    if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.contains("-")){
      if(phoneNumber.split("-").length>0 && phoneNumber.split("-")[1].length()==3){
        maskValue="***";
      }
      StringBuilder sb=new StringBuilder(phoneNumber);
      sb.replace(phoneNumber.indexOf("-")+1, phoneNumber.lastIndexOf("-"), maskValue);
      result=sb.toString();
    }else if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.length()==10){
      result=phoneNumber.replaceFirst(phoneNumber.substring(3, 6),"-***-");
    }else if(StringUtils.isNotBlank(phoneNumber) && phoneNumber.length()>=11){
      result=phoneNumber.replaceFirst(phoneNumber.substring(3, 7),"-****-");
    }

    return result;
  }

  private static Boolean isCsr(){
    Boolean result = false;
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    Long csrRoleId = (Long)RequestUtil.getAttribute((ServletServerHttpRequest) context.getRequest(), "csrRoleId",
      RequestAttributes.SCOPE_REQUEST);
    /*AdminUser user = (AdminUser) context.getAdditionalProperties().get("adminUser");

    for(AdminRole role : user.getAllRoles()){
      if(role.getId() == csrRoleId){
        result = true;
        break;
      }
    }*/

    return result;
  }

  /**
   * Mask user name.
   *
   * @param userName the user name
   * @return the string
   */
  public static String maskUserName(String userName){
    String result = userName;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskUserName(userName);
      }
    }else{
      result = setMaskUserName(userName);
    }

    return result;
  }

  public static String setMaskUserName(String userName){
    String result = userName;

    if(StringUtils.isNotBlank(userName) && userName.length()>2){
      result=userName.substring(0,userName.length()-2)+"**";
    }

    return result;
  }

  /**
   * Mask customer name.
   *
   * @param customerName the customer name
   * @return the string
   */
  public static String maskCustomerName(String customerName){
    String result = customerName;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskCustomerName(customerName);
      }
    }else{
      result = setMaskCustomerName(customerName);
    }

    return result;
  }

  public static String setMaskCustomerName(String customerName){
    String result = customerName;

    if(StringUtils.isNotBlank(customerName) && customerName.length()>1){
      result=customerName.substring(0, 1) + '*' + customerName.substring(1 + 1);
    }

    return result;
  }

  /**
   * Mask address.
   *
   * @param address the address
   * @return the string
   */
  public static String maskAddress(String address){
    String result = address;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskAddress(address);
      }
    }else{
      result = setMaskAddress(address);
    }

    return result;
  }

  public static String setMaskAddress(String address){
    String result = address;

    if(StringUtils.isNotBlank(address)){
      StringBuilder sb=new StringBuilder();
      for(int i=0;i<address.length();i++){
        sb=sb.append("*");
      }
      result=sb.toString();
    }

    return result;
  }

  /**
   * Mask credit info.
   *
   * @param creditcard the creditcard
   * @return the string
   */
  public static String maskCreditInfo(String creditcard){
    String result =creditcard;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskCreditInfo(creditcard);
      }
    }else{
      result = setMaskCreditInfo(creditcard);
    }

    return result;
  }

  public static String setMaskCreditInfo(String creditcard){
    String result = creditcard;

    if(StringUtils.isNotBlank(creditcard) && creditcard.length()>12){
      result= creditcard.substring(0,4)+ "-****-****-"+creditcard.substring(12);
    }

    return result;
  }

  /**
   * Mask credit card info.
   *
   * @param creditcard the creditcard
   * @return the string
   */
  public static String maskCreditCardInfo(String creditcard){
    String result =creditcard;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskCreditCardInfo(creditcard);
      }
    }else{
      result = setMaskCreditCardInfo(creditcard);
    }

    return result;
  }

  /**
   * 16 자리 or 12 자리 일 경우 분기 로직 처리
   * <pre>
   * </pre>
   *
   * @Method setMaskCreditCardInfo
   * @param creditcard
   * @return
   */
  public static String setMaskCreditCardInfo(String creditcard){
    StringBuilder sb = new StringBuilder();

    if (StringUtils.isNotBlank(creditcard)) {
      if (creditcard.length() > 12) {
        sb.append(creditcard, 0, 4)
            .append("-")
            .append(creditcard, 4, 7).append("*")
            .append("-")
            .append("****")
            .append("-")
            .append(creditcard.substring(12));
      } else if (creditcard.length() > 10) {
        sb.append(creditcard, 0, 4)
            .append("-")
            .append(creditcard, 4, 7).append("*")
            .append("-")
            .append(creditcard.substring(8))
            .append("-")
            .append("****");
      }
    }

    return sb.toString();
  }

  public static String maskCustomerId(String loginName) {
    String result = loginName;
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if(context.isAdmin()){
      if(!isCsr()){
        result = setMaskCustomerId(loginName);
      }
    }else{
      result = setMaskCustomerId(loginName);
    }

    return result;
  }

  public static String setMaskCustomerId(String loginName){
    String result = loginName;

    result = loginName.substring(0, loginName.length()-2) + "**";

    return result;
  }

  public static String setMaskBankAccountNumber(String bankAccountNumber){
    if (StringUtils.isEmpty(bankAccountNumber)) {
      return bankAccountNumber;
    }

    StringBuilder sb = new StringBuilder()
        .append(bankAccountNumber, 0, 4)
        .append("***")
        .append(bankAccountNumber, 7, bankAccountNumber.length()-1)
        .append("*");

    return sb.toString();
  }
}
