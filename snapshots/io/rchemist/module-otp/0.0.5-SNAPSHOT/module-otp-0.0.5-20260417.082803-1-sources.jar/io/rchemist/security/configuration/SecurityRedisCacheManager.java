/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.configuration;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.rchemist.security.otp.configuration.SecurityCacheRegion.Otp;
import java.time.Duration;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Configuration
public class SecurityRedisCacheManager {

  public static final String CACHE_MANAGER = "rcmNotificationRedisCacheManager";

  protected final RedisConnectionFactory redisConnectionFactory;

  protected final ObjectMapper objectMapper;

  public SecurityRedisCacheManager(RedisConnectionFactory redisConnectionFactory,
      ObjectMapper objectMapper) {
    this.redisConnectionFactory = redisConnectionFactory;
    this.objectMapper = objectMapper;
  }

  @Bean(CACHE_MANAGER)
  public CacheManager redisCacheManager(){
    RedisCacheConfiguration redisCacheConfiguration = getDefaultRedisCacheConfiguration();

    RedisCacheManager redisCacheManager = RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(redisConnectionFactory)
        .transactionAware()
        .cacheDefaults(redisCacheConfiguration)

        .withCacheConfiguration(Otp.DATA, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Otp.ENTITY, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Otp.QUERY, getDefaultRedisCacheConfiguration())


        .build();

    return redisCacheManager;
  }

  private RedisCacheConfiguration getDefaultRedisCacheConfiguration() {

    ObjectMapper objectMapper = this.objectMapper.copy();
    objectMapper = objectMapper.activateDefaultTyping(objectMapper.getPolymorphicTypeValidator(), ObjectMapper.DefaultTyping.NON_FINAL, JsonTypeInfo.As.PROPERTY);

    RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
        .serializeKeysWith(
            RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
        .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer(objectMapper)))
        .entryTtl(Duration.ofSeconds(Otp.TTL));
    return redisCacheConfiguration;
  }

}
