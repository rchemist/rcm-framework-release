/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service;

import io.rchemist.security.otp.dao.OnetimePasswordDao;
import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.domain.OnetimePassword;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmOnetimePasswordService")
public class OnetimePasswordServiceImpl implements OnetimePasswordService {

  protected final OnetimePasswordDao dao;

  public OnetimePasswordServiceImpl(OnetimePasswordDao dao) {
    this.dao = dao;
  }

  /**
   * Active 한 OTP 만 조회한다.
   * @param otpCode
   * @return
   */
  @Override
  public OnetimePassword findActiveOtpByCode(String userId, String otpCode) {
    return dao.getRepository().findActiveOtpByCode(userId, otpCode);
  }

  @Override
  public List<OnetimePassword> getRequestInfo(OtpRequest request) {
    return dao.getRepository().getRequestInfo(request.getUserId(), request.getOnetimePasswordType());
  }

  @Override
  public Optional<OnetimePassword> findById(String id) {
    return dao.getRepository().findById(id);
  }

  @Override
  public OnetimePassword findActiveOtpByRequestInfo(OtpRequest request) {
    return dao.getRepository().findActiveOtpByRequestInfo(request.getUserId(), request.getOnetimePasswordType());
  }

  @Override
  @Transactional
  public OnetimePassword save(OnetimePassword otp) {
    return dao.getRepository().save(otp);
  }
}
