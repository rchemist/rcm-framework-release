/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.security.configuration.SecurityRedisCacheManager;
import io.rchemist.security.otp.configuration.SecurityCacheRegion.Otp;
import io.rchemist.security.otp.data.OnetimePasswordDTO;
import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.domain.OnetimePassword;
import io.rchemist.security.otp.service.exception.OnetimePasswordErrorType;
import io.rchemist.security.otp.service.exception.OnetimePasswordException;
import io.rchemist.security.otp.service.extension.OnetimePasswordServiceExtensionManager;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmOnetimePasswordManageService")
public class OnetimePasswordManageServiceImpl implements OnetimePasswordManageService {

  protected final OnetimePasswordService onetimePasswordService;

  protected final OnetimePasswordServiceExtensionManager extensionManager;

  private Cache cache;

  public OnetimePasswordManageServiceImpl(OnetimePasswordService onetimePasswordService,
      OnetimePasswordServiceExtensionManager extensionManager) {
    this.onetimePasswordService = onetimePasswordService;
    this.extensionManager = extensionManager;
  }

  private Cache getCache(){
    if(cache == null){
      CacheManager cacheManager = ApplicationContextHolder.getBean(SecurityRedisCacheManager.CACHE_MANAGER, CacheManager.class);
      cache = cacheManager.getCache(Otp.DATA);
    }
    return cache;
  }

  @Getter
  private static class CacheItem implements Serializable {

    public CacheItem(OtpRequest request) {
      this.request = request;
      this.requests.add(LocalDateTime.now());
    }

    private OtpRequest request;
    private Queue<LocalDateTime> requests = new LinkedList<>();

    public void addCount(int maxRetryCount) throws OnetimePasswordException {
      // 최초 요청 시각이 10분 이내인 경우
      if(this.requests.peek().isAfter(LocalDateTime.now())){
        // 최초 요청 시각이 10분 이내
        if(this.requests.size() >= maxRetryCount){
          throw new OnetimePasswordException(OnetimePasswordErrorType.EXCEED_MAX_RETRY_COUNT);
        }
      }

      if(this.requests.size() >= maxRetryCount){
        this.requests.poll();
      }

      this.requests.offer(LocalDateTime.now());
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) {
        return true;
      }
      if (!(o instanceof CacheItem)) {
        return false;
      }
      CacheItem cacheItem = (CacheItem) o;
      return Objects.equals(getRequest(), cacheItem.getRequest());
    }

    @Override
    public int hashCode() {
      return Objects.hash(getRequest());
    }
  }

  private void validateRequestCache(OtpRequest request) throws OnetimePasswordException {
    Cache cache = getCache();

    String cacheKey = request.toString();

    CacheItem cacheItem = cache.get(cacheKey, CacheItem.class);
    if(cacheItem != null){
      cacheItem.addCount(maxRetryCount);
    }else{
      cacheItem = new CacheItem(request);
    }

    cache.put(cacheKey, cacheItem);
  }

  /**
   * 비밀번호 찾기 시의 OTP 유효시간 : 기본 5분
   * AuthType 이 FIND_USER 일 때만 유효시간을 체크한다.
   */
  @Value("${platform.config.event.otp.restrict.minutes.auth:5}")
  protected Integer authMinutes;

  /**
   * 비밀번호 찾기를 제외한 OTP 기본 24시간
   */
  @Value("${platform.config.event.otp.restrict.minutes.default:1440}")
  protected Integer minutes;

  /**
   * 최근 10분 이내에 5회(기본) 이상 동일 OTP 획득 시도가 있으면 차단
   */
  @Value("${platform.config.event.otp.restrict.max-retry-count:5}")
  protected Integer maxRetryCount;

  @Override
  @Transactional
  public ResponseData<OnetimePasswordDTO> requestOnetimePassword(OtpRequest request) {

    try {

      request.validate();

      ExtensionResultHolder<OtpRequest> resultHolder = new ExtensionResultHolder<OtpRequest>().withResult(request);
      ExtensionResultStatusType statusType = extensionManager.getProxy().extractMessageTarget(resultHolder);

      if (!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)) {
        request = resultHolder.getResult();
      }

      // 동일한 조건의 요청이 반복적으로 수행되는 경우 이를 차단한다.
      validateRequestCache(request);

      // 동일한 조건의 기존 생성된 데이터가 있는지 확인하고, 있으면 해당 정보를 사용 불가로 변경, 새 데이터를 생성한다.
      OnetimePassword otp = onetimePasswordService.findActiveOtpByRequestInfo(request);
      if(otp != null){
        otp.setActive(false);
        onetimePasswordService.save(otp);
      }

      otp = OnetimePassword.create(request);
      otp = onetimePasswordService.save(otp);

      OnetimePasswordDTO dto = build(otp);

      if(request.shouldSendMessage()){
        // message 처리
        ExtensionResultHolder<OnetimePasswordDTO> sendResultHolder = new ExtensionResultHolder<OnetimePasswordDTO>().withResult(dto);
        statusType = extensionManager.getProxy().sendMessage(request, sendResultHolder);

        if (!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)) {
          dto = sendResultHolder.getResult();
        }

      }

      return ResponseHelper.result(dto);



    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }

  @Override
  public ResponseData<OnetimePasswordDTO> findOnetimePasswordById(String id){
    try{

      OnetimePassword otp = getOnetimePassword(id);

      return ResponseHelper.result(build(otp));

    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }

  protected OnetimePassword getOnetimePassword(String id) throws OnetimePasswordException {
    if(StringUtils.isBlank(id))
      throw new OnetimePasswordException(OnetimePasswordErrorType.USER_ID_REQUIRED);

    Optional<OnetimePassword> optional = onetimePasswordService.findById(id);

    if(optional.isEmpty())
      throw new OnetimePasswordException(OnetimePasswordErrorType.OTP_NOT_FOUND);

    if(!optional.get().isAvailableNow())
      throw new OnetimePasswordException(OnetimePasswordErrorType.EXPIRED);

    OnetimePassword otp = optional.get();
    return otp;
  }

  @Override
  public ResponseData<Boolean> validateOnetimePassword(String id, String otpCode) {

    try{
      OnetimePassword otp = getOnetimePassword(id);

      return ResponseHelper.result(otp.getOtpCode().equals(otpCode));

    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }

  protected OnetimePasswordDTO build(OnetimePassword otp){
    return new OnetimePasswordDTO()
        .withId(otp.getId())
        .withUserId(otp.getUserId())
        .withType(otp.getType())
        .withOtpCode(otp.getOtpCode())
        .withAvailableAt(otp.getAvailableAt())
        .withAvailableUntil(otp.getAvailableUntil());
  }

  /**
   * OTP 인증 유효 시간 생성
   * @param type
   * @param at
   * @return
   */
  protected LocalDateTime getAvailableUntil(OnetimePasswordType type, LocalDateTime at){
    if(type.isRequestCredentials()){
      return at.plusMinutes(getAuthMinutes());
    }else{
      return at.plusMinutes(getMinutes());
    }
  }

  protected Integer getAuthMinutes() {
    return authMinutes;
  }

  protected Integer getMinutes() {
    return minutes;
  }
}
