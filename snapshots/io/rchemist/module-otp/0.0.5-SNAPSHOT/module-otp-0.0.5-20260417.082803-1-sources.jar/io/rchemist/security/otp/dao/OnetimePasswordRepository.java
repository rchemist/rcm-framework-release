/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.security.otp.domain.OnetimePassword;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.util.List;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface OnetimePasswordRepository extends CommonSearchRepository<OnetimePassword, String> {

  @Query("select otp from OnetimePassword otp where otp.userId = :userId and otp.otpCode = :otpCode and (otp.active is null or otp.active = true)")
  OnetimePassword findActiveOtpByCode(String userId, String otpCode);

  @Query("select otp from OnetimePassword otp where otp.userId = :userId and otp.type = :onetimePasswordType ")
  List<OnetimePassword> getRequestInfo(String userId, OnetimePasswordType onetimePasswordType);

  @Query("select otp from OnetimePassword otp where otp.userId = :userId and otp.type = :onetimePasswordType and (otp.active is null or otp.active = true)")
  OnetimePassword findActiveOtpByRequestInfo(String userId, OnetimePasswordType onetimePasswordType);
}
