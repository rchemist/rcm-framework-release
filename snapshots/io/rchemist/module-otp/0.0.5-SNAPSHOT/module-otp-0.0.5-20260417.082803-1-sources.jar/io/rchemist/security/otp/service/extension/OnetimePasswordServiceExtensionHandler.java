/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.security.otp.data.OnetimePasswordDTO;
import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.service.exception.OnetimePasswordException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface OnetimePasswordServiceExtensionHandler extends ExtensionHandler {

  /**
   * 메시지 발송 대상을 특정해 request.targetAddress 나 request.userId 에 값을 입력한다.
   * @param resultHolder
   * @return
   */
  ExtensionResultStatusType extractMessageTarget(ExtensionResultHolder<OtpRequest> resultHolder) throws OnetimePasswordException;

  /**
   * OTP 생성이 끝나고 실제 메시지를 발송한다.
   * @param request
   * @param sendResultHolder
   * @return
   */
  ExtensionResultStatusType sendMessage(OtpRequest request, ExtensionResultHolder<OnetimePasswordDTO> sendResultHolder) throws OnetimePasswordException;
}
