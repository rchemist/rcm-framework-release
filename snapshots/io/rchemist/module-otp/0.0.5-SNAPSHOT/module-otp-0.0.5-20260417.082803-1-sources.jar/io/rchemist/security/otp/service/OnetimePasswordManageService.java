/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service;

import io.rchemist.common.web.response.ResponseData;
import io.rchemist.security.otp.data.OnetimePasswordDTO;
import io.rchemist.security.otp.data.OtpRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface OnetimePasswordManageService {

  /**
   * OtpRequest 를 이용해 OTP 생성하기
   *
   * OtpRequest 에 NotificationType 을 지정하면 해당 메시지 타입으로 자동으로 메시지가 발송된다.
   * 단, 이 경우 OneTimePasswordType.notificationTemplateType 으로 지정된 NotificationTemplate 이 미리 등록되어 있어야 한다.
   *
   * @param request
   * @return
   */
  ResponseData<OnetimePasswordDTO> requestOnetimePassword(OtpRequest request);

  ResponseData<OnetimePasswordDTO> findOnetimePasswordById(String id);

  /**
   * OTP 검증
   * @param id
   * @param otpCode
   * @return
   */
  ResponseData<Boolean> validateOnetimePassword(String id, String otpCode);
}
