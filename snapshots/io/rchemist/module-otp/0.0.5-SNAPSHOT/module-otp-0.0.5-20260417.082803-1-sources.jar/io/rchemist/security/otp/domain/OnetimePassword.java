/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.AvailableDatetime;
import io.rchemist.common.persistence.jpa.domain.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.util.RandomUtil;
import io.rchemist.security.otp.configuration.SecurityCacheRegion.Otp;
import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.service.OnetimePasswordTypeValueBridge;
import io.rchemist.security.otp.service.exception.OnetimePasswordException;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.bridge.mapping.annotation.ValueBridgeRef;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_REQUEST_AUTH")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = Otp.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "Onetime Password", comment = "Onetime Password")
public class OnetimePassword implements EssentialUUIDEntity<OnetimePassword>, AvailableDatetime<OnetimePassword>, SoftDelete<OnetimePassword> {

  protected OnetimePassword(){

  }

  @Id
  @IdGenerator
  @Description(name = "ID")
  protected String id;

  @Column(name = "USER_ID")
  @GenericField
  @IndexField
  @Description(name = "USER ID", comment = "관리자 또는 일반 회원의 ID. 로그인 아이디와 달리 시스템 내부에서 사용하는 ID 를 의미함. customerId / adminUserId = User.userId")
  protected String userId;

  @Column(name = "OTP_CODE")
  @IndexField
  @KeywordField
  @Description(name = "OTP Code", comment = "URL 링크를 사용하지 않고 OTP 코드를 입력하도록 하는 경우 ID 대신 6 자리의 숫자를 OTP 로 사용한다.")
  protected String otpCode;

  @Column(name = "OTP_TYPE")
  @IndexField
  @KeywordField(valueBridge = @ValueBridgeRef(type = OnetimePasswordTypeValueBridge.class))
  @Description(name = "OTP 발송 시점", comment = "OTP 발송 시점. 관리자 로그인 정보 찾기(FIND_ADMIN), 고객 로그인 정보 찾기(FIND_CUSTOMER), 임시 확인용(ONETIME_PASSWORD) 으로 구분된다.")
  protected OnetimePasswordType type;

  public static OnetimePassword create(OtpRequest request) throws OnetimePasswordException {

    request.validate();

    String otpCode = RandomUtil.getRandomNumber(6);

    OnetimePassword otp = new OnetimePassword();
    otp.setUserId(request.getUserId());
    otp.setOtpCode(otpCode);
    otp.setType(request.getOnetimePasswordType());

    return otp;

  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof OnetimePassword)) {
      return false;
    }
    OnetimePassword that = (OnetimePassword) o;
    return Objects.equals(getId(), that.getId()) && Objects.equals(getUserId(),
        that.getUserId())
        && Objects.equals(getOtpCode(), that.getOtpCode());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getId(), getUserId(), getOtpCode());
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("id", id)
        .append("userId", userId)
        .append("otpCode", otpCode)
        .append("availableAt", getAvailableAt())
        .append("availableUntil", getAvailableUntil())
        .append("audit", getAudit())
        .toString();
  }
}
