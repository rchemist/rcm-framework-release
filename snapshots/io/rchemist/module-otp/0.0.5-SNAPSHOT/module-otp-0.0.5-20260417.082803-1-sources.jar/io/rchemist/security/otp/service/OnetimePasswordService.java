/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service;

import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.domain.OnetimePassword;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface OnetimePasswordService {

  OnetimePassword findActiveOtpByCode(String userId, String otpCode);

  List<OnetimePassword> getRequestInfo(OtpRequest request);

  Optional<OnetimePassword> findById(String id);

  OnetimePassword findActiveOtpByRequestInfo(OtpRequest request);

  OnetimePassword save(OnetimePassword otp);
}
