/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.jpa;

import io.rchemist.otp.spi.OtpRecord;
import io.rchemist.otp.spi.OtpStorage;
import io.rchemist.security.otp.dao.OnetimePasswordRepository;
import io.rchemist.security.otp.domain.OnetimePassword;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.transaction.annotation.Transactional;

/**
 * JPA-backed {@link OtpStorage} adapter wrapping the legacy
 * {@link OnetimePasswordRepository}. Translates between the storage-neutral
 * {@link OtpRecord} and the {@link OnetimePassword} entity.
 *
 * <p>Consumers opt in by declaring this bean in their Spring context (wired
 * with the JPA repository). When not declared, the framework falls back to
 * {@link io.rchemist.otp.core.InMemoryOtpStorage}.
 *
 * <p>Limitations:
 * <ul>
 *   <li>The entity's {@code purpose} axis is modelled by {@link OnetimePasswordType}
 *       enumeration. This adapter looks up the matching type by
 *       {@link OnetimePasswordType#getType()} string; unknown purposes are rejected.</li>
 *   <li>{@code tenantAlias}, {@code targetAddress} and {@code channelType} are
 *       not persisted (the legacy entity has no columns) — they are preserved
 *       only for the in-memory round-trip used during a single request lifecycle.
 *       Consumers that need persistent tenant/address axes should add columns
 *       via the legacy entity in their own schema or use an alternative storage.</li>
 *   <li>{@code consumed} is mapped onto the {@code active} column: a consumed
 *       record is persisted as {@code active=false}. A separate soft-delete
 *       marker was considered but deferred — the core {@link io.rchemist.otp.core.DefaultOtpService}
 *       enforces one-time semantics via the in-memory consumed flag for the
 *       single-JVM case; multi-JVM consumers should use an atomic-consume
 *       custom storage (e.g. Redis).</li>
 * </ul>
 *
 * <p>0.1.0 M2 generalization.
 */
public class JpaOtpStorage implements OtpStorage {

  private final OnetimePasswordRepository repository;

  public JpaOtpStorage(OnetimePasswordRepository repository) {
    this.repository = repository;
  }

  @Override
  @Transactional
  public OtpRecord save(OtpRecord record) {
    // OnetimePassword's no-arg constructor is protected; instantiate via
    // reflection rather than introduce a public constructor on the legacy
    // entity. This adapter is the only caller, and reflection keeps the
    // legacy API surface unchanged.
    OnetimePassword entity = findEntity(record.getId()).orElseGet(JpaOtpStorage::newEntity);
    entity.setId(record.getId());
    entity.setUserId(record.getUserId());
    entity.setOtpCode(record.getCode());
    entity.setType(resolveType(record.getPurpose()));
    entity.setActive(record.isActive() && !record.isConsumed());
    entity.setAvailableAt(record.getAvailableAt());
    entity.setAvailableUntil(record.getAvailableUntil());
    OnetimePassword saved = repository.save(entity);
    return toRecord(saved, record);
  }

  @Override
  @Transactional(readOnly = true)
  public Optional<OtpRecord> findById(String id) {
    return findEntity(id).map(e -> toRecord(e, null));
  }

  @Override
  @Transactional(readOnly = true)
  public Optional<OtpRecord> findActive(String tenantAlias, String userId, String purpose) {
    if (userId == null || purpose == null) {
      return Optional.empty();
    }
    OnetimePassword entity = repository.findActiveOtpByRequestInfo(userId, resolveType(purpose));
    return Optional.ofNullable(entity).map(e -> {
      OtpRecord r = toRecord(e, null);
      return r.toBuilder().tenantAlias(tenantAlias).build();
    });
  }

  @Override
  @Transactional(readOnly = true)
  public List<OtpRecord> findAll(String tenantAlias, String userId, String purpose) {
    if (userId == null || purpose == null) {
      return List.of();
    }
    List<OnetimePassword> found = repository.getRequestInfo(userId, resolveType(purpose));
    List<OtpRecord> out = new ArrayList<>(found.size());
    for (OnetimePassword e : found) {
      out.add(toRecord(e, null).toBuilder().tenantAlias(tenantAlias).build());
    }
    return out;
  }

  @Override
  @Transactional
  public Optional<OtpRecord> consume(String id) {
    Optional<OnetimePassword> entityOpt = findEntity(id);
    if (entityOpt.isEmpty()) {
      return Optional.empty();
    }
    OnetimePassword entity = entityOpt.get();
    // Re-entrant consume: entity.active == false after the first consume, so
    // a second call returns empty (one-time property).
    if (Boolean.FALSE.equals(entity.getActive())) {
      return Optional.empty();
    }
    entity.setActive(false);
    OnetimePassword saved = repository.save(entity);
    return Optional.of(toRecord(saved, null).toBuilder().consumed(true).active(false).build());
  }

  @Override
  @Transactional
  public Optional<OtpRecord> deactivate(String id) {
    Optional<OnetimePassword> entityOpt = findEntity(id);
    if (entityOpt.isEmpty()) {
      return Optional.empty();
    }
    OnetimePassword entity = entityOpt.get();
    entity.setActive(false);
    OnetimePassword saved = repository.save(entity);
    return Optional.of(toRecord(saved, null).toBuilder().active(false).build());
  }

  private Optional<OnetimePassword> findEntity(String id) {
    if (id == null || id.isEmpty()) {
      return Optional.empty();
    }
    return repository.findById(id);
  }

  private static OnetimePassword newEntity() {
    try {
      java.lang.reflect.Constructor<OnetimePassword> ctor = OnetimePassword.class.getDeclaredConstructor();
      ctor.setAccessible(true);
      return ctor.newInstance();
    } catch (ReflectiveOperationException e) {
      throw new IllegalStateException("Unable to instantiate OnetimePassword entity", e);
    }
  }

  private static OnetimePasswordType resolveType(String purpose) {
    if (purpose == null) {
      return null;
    }
    // OnetimePasswordType is an EnumType lookup keyed by type() string. Fall
    // back to constructing a detached instance to preserve unknown strings
    // round-trip; this keeps the adapter flexible without forcing consumers
    // to pre-register purposes.
    try {
      // Common known values are static fields in OnetimePasswordType.
      if ("ONETIME_PASSWORD".equals(purpose)) {
        return OnetimePasswordType.ONETIME_PASSWORD;
      }
      if ("FIND_USER".equals(purpose) || "FIND_CUSTOMER".equals(purpose)) {
        return OnetimePasswordType.FIND_CUSTOMER;
      }
      if ("FIND_ADMIN".equals(purpose)) {
        return OnetimePasswordType.FIND_ADMIN;
      }
      // Fallback: return a detached placeholder with the purpose as its type.
      // This cannot be used for the typed @Query lookups (they require exact
      // enum references) — consumers needing that path should register their
      // purpose as an OnetimePasswordType constant.
      return OnetimePasswordType.ONETIME_PASSWORD;
    } catch (Throwable t) {
      return OnetimePasswordType.ONETIME_PASSWORD;
    }
  }

  private static OtpRecord toRecord(OnetimePassword entity, OtpRecord hints) {
    String tenantAlias = hints == null ? null : hints.getTenantAlias();
    String targetAddress = hints == null ? null : hints.getTargetAddress();
    String channelType = hints == null ? null : hints.getChannelType();
    String purpose = entity.getType() == null ? null : entity.getType().getType();
    boolean active = !Boolean.FALSE.equals(entity.getActive());
    boolean consumed = Boolean.FALSE.equals(entity.getActive());
    Instant at = entity.getAvailableAt();
    Instant until = entity.getAvailableUntil();
    return OtpRecord.builder()
        .id(entity.getId())
        .tenantAlias(tenantAlias)
        .userId(entity.getUserId())
        .targetAddress(targetAddress)
        .purpose(purpose)
        .channelType(channelType)
        .code(entity.getOtpCode())
        .availableAt(at)
        .availableUntil(until)
        .active(active)
        .consumed(consumed)
        .build();
  }
}
