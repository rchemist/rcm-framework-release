/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.security.otp.service;

import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpIssueResult;
import io.rchemist.otp.spi.OtpRecord;
import io.rchemist.otp.spi.OtpService;
import io.rchemist.otp.spi.OtpVerifyResult;
import io.rchemist.security.otp.data.OnetimePasswordDTO;
import io.rchemist.security.otp.data.OtpRequest;
import io.rchemist.security.otp.service.exception.OnetimePasswordErrorType;
import io.rchemist.security.otp.service.exception.OnetimePasswordException;
import io.rchemist.security.otp.service.type.OnetimePasswordType;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Back-compat adapter around the 0.1.0 M2 {@link OtpService} SPI.
 *
 * <p>Consumers that depended on the legacy 0.0.x API keep working: the method
 * shapes are unchanged and {@link OtpRequest} / {@link OnetimePasswordDTO}
 * are still accepted. Internally everything is routed through the neutral
 * {@link OtpService}, so storage / channel / policy are pluggable.
 *
 * <p>New consumers SHOULD depend directly on {@link OtpService} and
 * {@link OtpIssueRequest} rather than this adapter.
 *
 * <p>0.1.0 M2 generalization.
 */
@Service("rcmOnetimePasswordManageService")
public class OnetimePasswordManageServiceImpl implements OnetimePasswordManageService {

  protected final OtpService otpService;

  public OnetimePasswordManageServiceImpl(OtpService otpService) {
    this.otpService = otpService;
  }

  @Override
  @Transactional
  public ResponseData<OnetimePasswordDTO> requestOnetimePassword(OtpRequest request) {
    try {
      request.validate();
      OtpIssueRequest spiRequest = toSpiRequest(request);
      OtpIssueResult result = otpService.issue(spiRequest);
      return ResponseHelper.result(toDto(result.getRecord(), request.getOnetimePasswordType()));
    } catch (Exception e) {
      return ResponseHelper.result(e);
    }
  }

  @Override
  public ResponseData<OnetimePasswordDTO> findOnetimePasswordById(String id) {
    try {
      OtpRecord record = loadActive(id);
      return ResponseHelper.result(toDto(record, null));
    } catch (Exception e) {
      return ResponseHelper.result(e);
    }
  }

  @Override
  public ResponseData<Boolean> validateOnetimePassword(String id, String otpCode) {
    try {
      if (StringUtils.isBlank(id)) {
        throw new OnetimePasswordException(OnetimePasswordErrorType.USER_ID_REQUIRED);
      }
      if (StringUtils.isBlank(otpCode)) {
        throw new OnetimePasswordException(OnetimePasswordErrorType.OTP_REQUIRED);
      }
      OtpVerifyResult result = otpService.verify(id, otpCode);
      if (result.isVerified()) {
        return ResponseHelper.result(Boolean.TRUE);
      }
      switch (result.getReason()) {
        case NOT_FOUND:
          throw new OnetimePasswordException(OnetimePasswordErrorType.OTP_NOT_FOUND);
        case EXPIRED:
        case INACTIVE:
        case ALREADY_CONSUMED:
          throw new OnetimePasswordException(OnetimePasswordErrorType.EXPIRED);
        case MISMATCH:
        default:
          return ResponseHelper.result(Boolean.FALSE);
      }
    } catch (Exception e) {
      return ResponseHelper.result(e);
    }
  }

  private OtpRecord loadActive(String id) throws OnetimePasswordException {
    if (StringUtils.isBlank(id)) {
      throw new OnetimePasswordException(OnetimePasswordErrorType.USER_ID_REQUIRED);
    }
    Optional<OtpRecord> found = otpService.findById(id);
    if (found.isEmpty()) {
      throw new OnetimePasswordException(OnetimePasswordErrorType.OTP_NOT_FOUND);
    }
    OtpRecord record = found.get();
    if (record.isConsumed() || !record.isActive()) {
      throw new OnetimePasswordException(OnetimePasswordErrorType.EXPIRED);
    }
    if (record.getAvailableUntil() != null && record.getAvailableUntil().isBefore(java.time.Instant.now())) {
      throw new OnetimePasswordException(OnetimePasswordErrorType.EXPIRED);
    }
    return record;
  }

  private static OtpIssueRequest toSpiRequest(OtpRequest legacy) {
    OtpIssueRequest.Builder b = OtpIssueRequest.builder()
        .tenantAlias(legacy.getTenantAlias())
        .userId(legacy.getUserId())
        .targetAddress(legacy.getTargetAddress());
    if (legacy.getOnetimePasswordType() != null) {
      b.purpose(legacy.getOnetimePasswordType().getType());
    }
    // Legacy notificationType is retained as an attribute so channel
    // implementations can opt into it via request.getAttributes().
    if (legacy.getNotificationType() != null) {
      b.attribute("notificationType", legacy.getNotificationType());
    }
    return b.build();
  }

  private static OnetimePasswordDTO toDto(OtpRecord record, OnetimePasswordType hintType) {
    OnetimePasswordType type = hintType;
    // Legacy DTO expects a typed enum. Adapter falls back to ONETIME_PASSWORD
    // when the upstream purpose string does not correspond to a known type.
    if (type == null) {
      type = OnetimePasswordType.ONETIME_PASSWORD;
    }
    return new OnetimePasswordDTO()
        .withId(record.getId())
        .withUserId(record.getUserId())
        .withType(type)
        .withOtpCode(record.getCode())
        .withAvailableAt(record.getAvailableAt())
        .withAvailableUntil(record.getAvailableUntil());
  }
}
