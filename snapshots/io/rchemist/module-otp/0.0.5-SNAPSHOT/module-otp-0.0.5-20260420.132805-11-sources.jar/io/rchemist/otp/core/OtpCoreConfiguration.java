/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpChannel;
import io.rchemist.otp.spi.OtpCodeGenerator;
import io.rchemist.otp.spi.OtpPolicyProvider;
import io.rchemist.otp.spi.OtpService;
import io.rchemist.otp.spi.OtpStorage;
import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Wires the 0.1.0 M2 OTP SPI beans. Consumers can override any individual
 * bean by declaring a bean of the same type in their own configuration;
 * {@code @ConditionalOnMissingBean} guards the defaults.
 *
 * <p>Beans registered:
 * <ul>
 *   <li>{@link OtpProperties} — bound from {@code platform.otp.*}</li>
 *   <li>{@link OtpStorage} — {@link InMemoryOtpStorage} when no other bean present</li>
 *   <li>{@link OtpPolicyProvider} — {@link DefaultOtpPolicyProvider}</li>
 *   <li>{@link OtpCodeGenerator} — {@link NumericOtpCodeGenerator}</li>
 *   <li>{@link NoopOtpChannel} — default no-op delivery</li>
 *   <li>{@link OtpChannelRegistry} — aggregates every {@link OtpChannel} bean</li>
 *   <li>{@link RetryGuard} — in-process retry rate limiter</li>
 *   <li>{@link OtpService} — {@link DefaultOtpService}</li>
 * </ul>
 *
 * <p>0.1.0 M2 generalization.
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(OtpProperties.class)
public class OtpCoreConfiguration {

  @Bean
  @ConditionalOnMissingBean(OtpStorage.class)
  public OtpStorage otpStorage() {
    return new InMemoryOtpStorage();
  }

  @Bean
  @ConditionalOnMissingBean(OtpPolicyProvider.class)
  public OtpPolicyProvider otpPolicyProvider(OtpProperties properties) {
    return new DefaultOtpPolicyProvider(properties);
  }

  @Bean
  @ConditionalOnMissingBean(OtpCodeGenerator.class)
  public OtpCodeGenerator otpCodeGenerator() {
    return new NumericOtpCodeGenerator();
  }

  @Bean
  public NoopOtpChannel noopOtpChannel() {
    return new NoopOtpChannel();
  }

  @Bean
  @ConditionalOnMissingBean(OtpChannelRegistry.class)
  public OtpChannelRegistry otpChannelRegistry(List<OtpChannel> channels) {
    return new OtpChannelRegistry(channels);
  }

  @Bean
  @ConditionalOnMissingBean(RetryGuard.class)
  public RetryGuard otpRetryGuard() {
    return new RetryGuard();
  }

  @Bean
  @ConditionalOnMissingBean(OtpService.class)
  public OtpService otpService(OtpStorage storage,
      OtpChannelRegistry channelRegistry,
      OtpPolicyProvider policyProvider,
      OtpCodeGenerator codeGenerator,
      RetryGuard retryGuard,
      OtpProperties properties) {
    return new DefaultOtpService(storage, channelRegistry, policyProvider, codeGenerator,
        retryGuard, properties);
  }
}
