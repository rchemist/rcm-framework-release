/**
 * JPA-backed adapters for the OTP SPI (0.1.0 M2). Opt-in: consumers must
 * declare {@link io.rchemist.otp.jpa.JpaOtpStorage} as a bean wired with the
 * {@link io.rchemist.security.otp.dao.OnetimePasswordRepository}. When no
 * such bean is declared, the default in-memory storage is used and the JPA
 * entity is not loaded.
 */
package io.rchemist.otp.jpa;
