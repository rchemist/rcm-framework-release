/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpPolicy;
import io.rchemist.otp.spi.OtpPolicyProvider;
import java.time.Duration;
import java.util.Set;

/**
 * Default {@link OtpPolicyProvider} driven by {@link OtpProperties}.
 *
 * <p>Purposes listed in {@link #getCredentialPurposes()} use the shorter
 * {@code credentials-expiration} window. All other purposes use the longer
 * {@code default-expiration}. Consumers can override either value via
 * {@code platform.otp.*}, or replace this bean to get per-request policies.
 *
 * <p>0.1.0 M2 generalization.
 */
public class DefaultOtpPolicyProvider implements OtpPolicyProvider {

  /**
   * Purpose values treated as credential lookups. Matches the legacy {@code
   * OnetimePasswordType#isRequestCredentials()} enumeration by convention
   * ({@code FIND_USER}, {@code FIND_ADMIN}).
   */
  private static final Set<String> DEFAULT_CREDENTIAL_PURPOSES =
      Set.of("FIND_USER", "FIND_ADMIN", "FIND_CUSTOMER");

  private final OtpProperties properties;
  private final Set<String> credentialPurposes;

  public DefaultOtpPolicyProvider(OtpProperties properties) {
    this(properties, DEFAULT_CREDENTIAL_PURPOSES);
  }

  public DefaultOtpPolicyProvider(OtpProperties properties, Set<String> credentialPurposes) {
    this.properties = properties;
    this.credentialPurposes = credentialPurposes;
  }

  public Set<String> getCredentialPurposes() {
    return credentialPurposes;
  }

  @Override
  public OtpPolicy resolve(OtpIssueRequest request) {
    boolean isCredentials = request.getPurpose() != null
        && credentialPurposes.contains(request.getPurpose());
    Duration expiration = isCredentials
        ? properties.getCredentialsExpiration()
        : properties.getDefaultExpiration();
    return new OtpPolicy(
        properties.getCodeLength(),
        properties.isCodeDigitsOnly(),
        expiration,
        properties.getMaxRetryCount(),
        properties.getRetryWindow());
  }
}
