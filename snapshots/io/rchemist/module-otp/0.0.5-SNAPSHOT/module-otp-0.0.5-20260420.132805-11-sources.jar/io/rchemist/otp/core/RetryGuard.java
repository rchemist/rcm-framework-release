/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpException;
import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpPolicy;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe per-request-key retry rate limiter.
 *
 * <p>Tracks the timestamps of recent issuance attempts for each request key
 * (tenant/user/target/purpose/channel tuple). When the number of attempts
 * within the policy's retry window exceeds {@code maxRetryCount}, subsequent
 * calls to {@link #check(OtpIssueRequest, OtpPolicy, Instant)} throw
 * {@link OtpException.Reason#EXCEED_MAX_RETRY_COUNT}.
 *
 * <p>0.1.0 M2 generalization. Replaces the prior Spring-cache-based counter in
 * {@code OnetimePasswordManageServiceImpl.CacheItem} so the core no longer
 * requires a cache manager. Consumers needing a distributed counter can
 * replace this bean with a Redis-backed implementation.
 */
public class RetryGuard {

  private final ConcurrentHashMap<String, Deque<Instant>> attempts = new ConcurrentHashMap<>();

  /**
   * Record a new attempt at {@code at} and throw when the attempt is beyond
   * the policy's limit. This is the canonical entry point.
   */
  public void check(OtpIssueRequest request, OtpPolicy policy, Instant at) {
    String key = keyOf(request);
    Deque<Instant> deque = attempts.computeIfAbsent(key, k -> new ArrayDeque<>());
    synchronized (deque) {
      Instant windowStart = at.minus(policy.getRetryWindow());
      // Drop attempts older than the window.
      while (!deque.isEmpty() && deque.peekFirst().isBefore(windowStart)) {
        deque.pollFirst();
      }
      if (deque.size() >= policy.getMaxRetryCount()) {
        throw new OtpException(OtpException.Reason.EXCEED_MAX_RETRY_COUNT);
      }
      deque.offerLast(at);
    }
  }

  /** Clear the internal counters. Test-only. */
  public void reset() {
    attempts.clear();
  }

  public int keyCount() {
    return attempts.size();
  }

  static String keyOf(OtpIssueRequest request) {
    return String.join("|",
        nullSafe(request.getTenantAlias()),
        nullSafe(request.getUserId()),
        nullSafe(request.getTargetAddress()),
        nullSafe(request.getPurpose()),
        nullSafe(request.getChannelType()));
  }

  private static String nullSafe(String s) {
    return s == null ? "" : s;
  }
}
