/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpChannel;
import io.rchemist.otp.spi.OtpCodeGenerator;
import io.rchemist.otp.spi.OtpException;
import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpIssueResult;
import io.rchemist.otp.spi.OtpPolicy;
import io.rchemist.otp.spi.OtpPolicyProvider;
import io.rchemist.otp.spi.OtpRecord;
import io.rchemist.otp.spi.OtpService;
import io.rchemist.otp.spi.OtpStorage;
import io.rchemist.otp.spi.OtpVerifyResult;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * Default {@link OtpService} implementation. Generic over storage, channel,
 * policy and code generation.
 *
 * <p>Issue flow: validate request → apply retry guard → resolve policy →
 * deactivate any prior active record → generate code → persist → dispatch via
 * channel. Verify flow: load by id → check active/expiry/code → atomic
 * consume via storage. A second verify on the same id returns
 * {@link OtpVerifyResult.Reason#ALREADY_CONSUMED}.
 *
 * <p>0.1.0 M2 generalization.
 */
public class DefaultOtpService implements OtpService {

  private final OtpStorage storage;
  private final OtpChannelRegistry channelRegistry;
  private final OtpPolicyProvider policyProvider;
  private final OtpCodeGenerator codeGenerator;
  private final RetryGuard retryGuard;
  private final OtpProperties properties;
  private final Clock clock;

  public DefaultOtpService(OtpStorage storage,
      OtpChannelRegistry channelRegistry,
      OtpPolicyProvider policyProvider,
      OtpCodeGenerator codeGenerator,
      RetryGuard retryGuard,
      OtpProperties properties) {
    this(storage, channelRegistry, policyProvider, codeGenerator, retryGuard, properties,
        Clock.systemUTC());
  }

  public DefaultOtpService(OtpStorage storage,
      OtpChannelRegistry channelRegistry,
      OtpPolicyProvider policyProvider,
      OtpCodeGenerator codeGenerator,
      RetryGuard retryGuard,
      OtpProperties properties,
      Clock clock) {
    this.storage = Objects.requireNonNull(storage, "storage");
    this.channelRegistry = Objects.requireNonNull(channelRegistry, "channelRegistry");
    this.policyProvider = Objects.requireNonNull(policyProvider, "policyProvider");
    this.codeGenerator = Objects.requireNonNull(codeGenerator, "codeGenerator");
    this.retryGuard = Objects.requireNonNull(retryGuard, "retryGuard");
    this.properties = Objects.requireNonNull(properties, "properties");
    this.clock = Objects.requireNonNull(clock, "clock");
  }

  @Override
  public OtpIssueResult issue(OtpIssueRequest request) {
    Objects.requireNonNull(request, "request");
    validate(request);

    OtpPolicy policy = policyProvider.resolve(request);
    Instant now = clock.instant();

    // Retry rate limiting must run BEFORE deactivation so repeated calls
    // cannot silently churn storage state.
    retryGuard.check(request, policy, now);

    // Deactivate any prior active record for the tuple.
    storage.findActive(request.getTenantAlias(), request.getUserId(), request.getPurpose())
        .ifPresent(prior -> storage.deactivate(prior.getId()));

    String code = codeGenerator.generate(request, policy);
    OtpRecord toStore = OtpRecord.builder()
        .tenantAlias(request.getTenantAlias())
        .userId(request.getUserId())
        .targetAddress(request.getTargetAddress())
        .purpose(request.getPurpose())
        .channelType(effectiveChannelType(request))
        .code(code)
        .availableAt(now)
        .availableUntil(now.plus(policy.getExpiration()))
        .active(true)
        .consumed(false)
        .build();

    OtpRecord stored = storage.save(toStore);

    String deliveryRef = null;
    boolean delivered = false;
    String channelType = stored.getChannelType();
    if (channelType != null) {
      Optional<OtpChannel> channel = channelRegistry.find(channelType);
      if (channel.isPresent()) {
        deliveryRef = channel.get().send(request, stored);
        delivered = true;
      }
    }

    return new OtpIssueResult(stored, delivered, deliveryRef);
  }

  @Override
  public OtpVerifyResult verify(String id, String code) {
    if (id == null || id.isEmpty()) {
      throw new OtpException(OtpException.Reason.ID_REQUIRED);
    }
    if (code == null || code.isEmpty()) {
      throw new OtpException(OtpException.Reason.CODE_REQUIRED);
    }

    Optional<OtpRecord> found = storage.findById(id);
    if (found.isEmpty()) {
      return OtpVerifyResult.notFound();
    }
    OtpRecord record = found.get();

    if (record.isConsumed()) {
      return OtpVerifyResult.alreadyConsumed(record);
    }
    if (!record.isActive()) {
      return OtpVerifyResult.inactive(record);
    }

    Instant now = clock.instant();
    if (record.getAvailableUntil() != null && now.isAfter(record.getAvailableUntil())) {
      return OtpVerifyResult.expired(record);
    }
    if (record.getAvailableAt() != null && now.isBefore(record.getAvailableAt())) {
      return OtpVerifyResult.inactive(record);
    }

    if (!Objects.equals(record.getCode(), code)) {
      return OtpVerifyResult.mismatch(record);
    }

    Optional<OtpRecord> consumed = storage.consume(id);
    if (consumed.isEmpty()) {
      // Lost the race — someone else consumed.
      return OtpVerifyResult.alreadyConsumed(record);
    }
    return OtpVerifyResult.verified(consumed.get());
  }

  @Override
  public Optional<OtpRecord> findById(String id) {
    if (id == null || id.isEmpty()) {
      return Optional.empty();
    }
    return storage.findById(id);
  }

  private void validate(OtpIssueRequest request) {
    if (!request.hasTarget()) {
      throw new OtpException(OtpException.Reason.TARGET_REQUIRED);
    }
    if (request.getPurpose() == null || request.getPurpose().isEmpty()) {
      throw new OtpException(OtpException.Reason.PURPOSE_REQUIRED);
    }
  }

  private String effectiveChannelType(OtpIssueRequest request) {
    if (request.getChannelType() != null && !request.getChannelType().isEmpty()) {
      return request.getChannelType();
    }
    return properties.getDefaultChannel();
  }
}
