/**
 * Legacy OTP API (pre-0.1.0). Retained as a back-compat adapter around the
 * channel/storage-neutral SPI in {@link io.rchemist.otp.spi} introduced by
 * 0.1.0 M2. New consumers SHOULD depend on {@link io.rchemist.otp.spi.OtpService}
 * directly.
 *
 * <p>See {@code documents/refactor/15b-0.1.0-m2-otp-generalization.md} for the
 * generalization rationale and migration guidance.
 */
package io.rchemist.security.otp;
