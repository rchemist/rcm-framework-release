/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpChannelType;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Global OTP configuration bound from the {@code platform.otp.*} namespace.
 *
 * <p>0.1.0 M2 generalization.
 */
@ConfigurationProperties(prefix = "platform.otp")
public class OtpProperties {

  /** Default channel used when a request does not specify one. */
  private String defaultChannel = OtpChannelType.NOOP;

  /** Preferred storage backend identifier. Informational — selection is done by bean wiring. */
  private Storage storage = Storage.IN_MEMORY;

  /** Length of the generated code. */
  private int codeLength = 6;

  /** When true, generated codes contain digits only. */
  private boolean codeDigitsOnly = true;

  /** Expiration applied for issuance requests whose purpose is NOT a credential lookup. */
  private Duration defaultExpiration = Duration.ofMinutes(1440);

  /** Expiration applied for issuance requests whose purpose IS a credential lookup. */
  private Duration credentialsExpiration = Duration.ofMinutes(5);

  /** Max issuance attempts per retry window before {@code EXCEED_MAX_RETRY_COUNT} is raised. */
  private int maxRetryCount = 5;

  /** Window used for retry rate limiting. */
  private Duration retryWindow = Duration.ofMinutes(10);

  public enum Storage {
    IN_MEMORY,
    JPA
  }

  public String getDefaultChannel() { return defaultChannel; }
  public void setDefaultChannel(String defaultChannel) { this.defaultChannel = defaultChannel; }

  public Storage getStorage() { return storage; }
  public void setStorage(Storage storage) { this.storage = storage; }

  public int getCodeLength() { return codeLength; }
  public void setCodeLength(int codeLength) { this.codeLength = codeLength; }

  public boolean isCodeDigitsOnly() { return codeDigitsOnly; }
  public void setCodeDigitsOnly(boolean codeDigitsOnly) { this.codeDigitsOnly = codeDigitsOnly; }

  public Duration getDefaultExpiration() { return defaultExpiration; }
  public void setDefaultExpiration(Duration defaultExpiration) { this.defaultExpiration = defaultExpiration; }

  public Duration getCredentialsExpiration() { return credentialsExpiration; }
  public void setCredentialsExpiration(Duration credentialsExpiration) { this.credentialsExpiration = credentialsExpiration; }

  public int getMaxRetryCount() { return maxRetryCount; }
  public void setMaxRetryCount(int maxRetryCount) { this.maxRetryCount = maxRetryCount; }

  public Duration getRetryWindow() { return retryWindow; }
  public void setRetryWindow(Duration retryWindow) { this.retryWindow = retryWindow; }
}
