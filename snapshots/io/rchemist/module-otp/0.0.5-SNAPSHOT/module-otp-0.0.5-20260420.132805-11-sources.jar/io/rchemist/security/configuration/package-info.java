/**
 * Legacy security configuration for module-otp. The Redis-backed cache manager
 * defined here remains for back-compat and is consumed by {@code @Cache}
 * annotations on the JPA entity. Core OTP retry / storage state no longer
 * depends on it — that path now lives behind the
 * {@link io.rchemist.otp.spi.OtpStorage} SPI.
 *
 * <p>See {@code documents/refactor/15b-0.1.0-m2-otp-generalization.md}.
 */
package io.rchemist.security.configuration;
