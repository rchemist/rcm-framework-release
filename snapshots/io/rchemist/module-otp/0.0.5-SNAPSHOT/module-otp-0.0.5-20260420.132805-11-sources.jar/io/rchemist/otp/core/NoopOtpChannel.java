/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpChannel;
import io.rchemist.otp.spi.OtpChannelType;
import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * No-op {@link OtpChannel} used as the default when no channel is configured.
 * Logs the issuance at INFO and returns {@code null} as the delivery reference.
 *
 * <p>This lets consumers compile and exercise the issue/verify contract
 * without wiring any delivery gateway.
 *
 * <p>0.1.0 M2 generalization.
 */
public class NoopOtpChannel implements OtpChannel {

  private static final Logger log = LoggerFactory.getLogger(NoopOtpChannel.class);

  @Override
  public String getType() {
    return OtpChannelType.NOOP;
  }

  @Override
  public String send(OtpIssueRequest request, OtpRecord record) {
    log.info("OTP NOOP channel — id={} tenantAlias={} userId={} purpose={}",
        record.getId(), record.getTenantAlias(), record.getUserId(), record.getPurpose());
    return null;
  }
}
