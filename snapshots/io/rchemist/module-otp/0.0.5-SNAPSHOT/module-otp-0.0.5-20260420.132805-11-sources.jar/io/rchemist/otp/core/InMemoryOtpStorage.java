/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpRecord;
import io.rchemist.otp.spi.OtpStorage;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe in-memory {@link OtpStorage}. Default when no JPA-backed bean is
 * on the classpath. Issues records with UUID ids.
 *
 * <p>Records are never auto-evicted. For a process that runs beyond the
 * expected OTP retention, consumers should either periodically invoke
 * {@link #purgeExpired(Instant)} or wire a persistent storage.
 *
 * <p>0.1.0 M2 generalization.
 */
public class InMemoryOtpStorage implements OtpStorage {

  private final ConcurrentHashMap<String, OtpRecord> store = new ConcurrentHashMap<>();

  @Override
  public OtpRecord save(OtpRecord record) {
    OtpRecord toStore = record;
    if (toStore.getId() == null || toStore.getId().isEmpty()) {
      toStore = record.toBuilder().id(UUID.randomUUID().toString()).build();
    }
    store.put(toStore.getId(), toStore);
    return toStore;
  }

  @Override
  public Optional<OtpRecord> findById(String id) {
    if (id == null) {
      return Optional.empty();
    }
    return Optional.ofNullable(store.get(id));
  }

  @Override
  public Optional<OtpRecord> findActive(String tenantAlias, String userId, String purpose) {
    // "Active" for storage purposes = not deactivated and not consumed. Time-
    // window filtering is left to the caller (DefaultOtpService performs the
    // expiration check at verify time). This keeps the storage SPI clock-free
    // so implementations do not need to share a Clock with the service.
    return store.values().stream()
        .filter(r -> equalsNullable(r.getTenantAlias(), tenantAlias))
        .filter(r -> equalsNullable(r.getUserId(), userId))
        .filter(r -> equalsNullable(r.getPurpose(), purpose))
        .filter(OtpRecord::isActive)
        .filter(r -> !r.isConsumed())
        .max(Comparator.comparing(r -> r.getAvailableAt() == null ? Instant.EPOCH : r.getAvailableAt()));
  }

  @Override
  public List<OtpRecord> findAll(String tenantAlias, String userId, String purpose) {
    List<OtpRecord> out = new ArrayList<>();
    for (OtpRecord r : store.values()) {
      if (equalsNullable(r.getTenantAlias(), tenantAlias)
          && equalsNullable(r.getUserId(), userId)
          && equalsNullable(r.getPurpose(), purpose)) {
        out.add(r);
      }
    }
    return out;
  }

  @Override
  public Optional<OtpRecord> consume(String id) {
    if (id == null) {
      return Optional.empty();
    }
    final OtpRecord[] updated = new OtpRecord[1];
    store.computeIfPresent(id, (k, existing) -> {
      if (existing.isConsumed()) {
        updated[0] = null;
        return existing;
      }
      OtpRecord next = existing.toBuilder().consumed(true).active(false).build();
      updated[0] = next;
      return next;
    });
    return Optional.ofNullable(updated[0]);
  }

  @Override
  public Optional<OtpRecord> deactivate(String id) {
    if (id == null) {
      return Optional.empty();
    }
    final OtpRecord[] updated = new OtpRecord[1];
    store.computeIfPresent(id, (k, existing) -> {
      OtpRecord next = existing.toBuilder().active(false).build();
      updated[0] = next;
      return next;
    });
    return Optional.ofNullable(updated[0]);
  }

  /** Remove records whose {@code availableUntil} is strictly before the given instant. */
  public int purgeExpired(Instant cutoff) {
    int removed = 0;
    for (OtpRecord r : new ArrayList<>(store.values())) {
      Instant until = r.getAvailableUntil();
      if (until != null && until.isBefore(cutoff)) {
        if (store.remove(r.getId(), r)) {
          removed++;
        }
      }
    }
    return removed;
  }

  /** Remove every record. Primarily useful for tests. */
  public void clear() {
    store.clear();
  }

  /** Snapshot size — test/diagnostic use only. */
  public int size() {
    return store.size();
  }

  private static boolean equalsNullable(Object a, Object b) {
    if (a == null && b == null) {
      return true;
    }
    if (a == null || b == null) {
      return false;
    }
    return a.equals(b);
  }
}
