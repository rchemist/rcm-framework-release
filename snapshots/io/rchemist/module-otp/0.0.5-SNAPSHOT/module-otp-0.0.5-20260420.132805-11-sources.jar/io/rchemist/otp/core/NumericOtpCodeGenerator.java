/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpCodeGenerator;
import io.rchemist.otp.spi.OtpIssueRequest;
import io.rchemist.otp.spi.OtpPolicy;
import java.security.SecureRandom;

/**
 * Default {@link OtpCodeGenerator}. Produces a numeric (digits-only) code of
 * the configured length using {@link SecureRandom}. When
 * {@link OtpPolicy#isDigitsOnly()} is false, produces an alphanumeric code of
 * the same length.
 *
 * <p>0.1.0 M2 generalization.
 */
public class NumericOtpCodeGenerator implements OtpCodeGenerator {

  private static final char[] DIGITS = "0123456789".toCharArray();
  private static final char[] ALPHANUMERIC =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".toCharArray();

  private final SecureRandom random;

  public NumericOtpCodeGenerator() {
    this(new SecureRandom());
  }

  public NumericOtpCodeGenerator(SecureRandom random) {
    this.random = random;
  }

  @Override
  public String generate(OtpIssueRequest request, OtpPolicy policy) {
    char[] alphabet = policy.isDigitsOnly() ? DIGITS : ALPHANUMERIC;
    int length = policy.getCodeLength();
    StringBuilder sb = new StringBuilder(length);
    for (int i = 0; i < length; i++) {
      sb.append(alphabet[random.nextInt(alphabet.length)]);
    }
    return sb.toString();
  }
}
