/**
 * Default implementations of the OTP SPI introduced in 0.1.0 M2.
 *
 * <p>See {@link io.rchemist.otp.spi} for the interfaces. The classes in this
 * package are storage/channel-neutral; the JPA adapter lives in
 * {@link io.rchemist.otp.jpa}.
 */
package io.rchemist.otp.core;
