/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 */

package io.rchemist.otp.core;

import io.rchemist.otp.spi.OtpChannel;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Registry of {@link OtpChannel} beans keyed by {@link OtpChannel#getType()}.
 *
 * <p>When multiple beans declare the same type the first one encountered wins
 * and subsequent ones are logged and ignored. This lets the framework-provided
 * {@link NoopOtpChannel} coexist with consumer-registered channels without
 * requiring explicit bean exclusion.
 *
 * <p>0.1.0 M2 generalization.
 */
public class OtpChannelRegistry {

  private static final Logger log = LoggerFactory.getLogger(OtpChannelRegistry.class);

  private final Map<String, OtpChannel> channels = new LinkedHashMap<>();

  public OtpChannelRegistry(Collection<? extends OtpChannel> channels) {
    if (channels != null) {
      for (OtpChannel ch : channels) {
        register(ch);
      }
    }
  }

  public OtpChannelRegistry() {
    this(List.of());
  }

  public final void register(OtpChannel channel) {
    Objects.requireNonNull(channel, "channel must not be null");
    String type = channel.getType();
    Objects.requireNonNull(type, "channel.type must not be null");
    OtpChannel existing = channels.putIfAbsent(type, channel);
    if (existing != null && existing != channel) {
      log.warn("OTP channel with type={} already registered ({}). Ignoring {}.",
          type, existing.getClass().getName(), channel.getClass().getName());
    }
  }

  public Optional<OtpChannel> find(String type) {
    if (type == null) {
      return Optional.empty();
    }
    return Optional.ofNullable(channels.get(type));
  }

  public int size() {
    return channels.size();
  }
}
