/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.service.type;

import io.rchemist.activemq.artemis.service.MessageConverter;
import io.rchemist.activemq.artemis.service.MessageUtil;
import io.rchemist.activemq.artemis.service.exception.ConvertMessageException;
import io.rchemist.common.enumeration.EnumType;
import jakarta.jms.Message;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Getter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractMessageType<T> extends EnumType<T> {

  private static final ConcurrentHashMap<String, AbstractMessageType> DESTINATION_MAP = new ConcurrentHashMap<>(1000);

  /**
   * message 가 단순 Serializable 객체일 경우 사용
   *
   * @param destination
   * @param type
   * @param friendlyType
   * @param typeClass
   */
  public AbstractMessageType(String destination, String type, String friendlyType,
      Class<?> typeClass) {
    this(destination, type, friendlyType, typeClass, null);
  }

  /**
   * converter 를 override 해야 하는 경우에 사용
   *
   * @param destination
   * @param type
   * @param friendlyType
   * @param typeClass
   * @param converter
   */
  public AbstractMessageType(String destination, String type, String friendlyType,
      Class<?> typeClass, MessageConverter<?> converter) {
    super(type, friendlyType);
    this.destination = destination;
    this.typeClass = typeClass;
    if (converter == null) {
      this.converter = message -> {
        try {
          return MessageUtil.convert(message, typeClass);
        } catch (ConvertMessageException e) {
          throw new RuntimeException(e.getTextMessage());
        }
      };
    } else {
      this.converter = converter;
    }
    DESTINATION_MAP.put(destination, this);
  }

  @Getter
  private final String destination;

  @Getter
  private final Class<?> typeClass;

  private final MessageConverter<?> converter;

  public <T> T convert(Message message) {
    return (T) converter.convert(message);
  }

  public static <T> T fromDestination(String destination) {
    return (T) DESTINATION_MAP.get(destination);
  }

}
