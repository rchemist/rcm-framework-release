/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.log.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_QUEUE_MESSAGE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "queueMessage")
@Getter
@Setter
@Description(name = "Tenant", comment = "Tenant 정보")
public class QueueMessage implements EssentialEntity<QueueMessage> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "MESSAGE_TYPE")
  @IndexField
  @Description(name = "메시지 유형")
  protected String messageType;

  @Column(name = "MESSAGE_CONTEXT_ID")
  @IndexField
  @Description(name = "메시지 컨텍스트 아이디")
  protected String messageContextId;

  @Column(name = "MESSAGE")
  @Text
  @Description(name = "메시지")
  protected String message;

  @Column(name = "IS_SUCCEED")
  @Description(name = "성공여부")
  protected Boolean succeed;

  @Column(name = "ERROR_MESSAGE", length = 1000)
  @Description(name = "에러메시지")
  protected String errorMessage;

  public void setMessageBody(Serializable body) {
    if (body != null) {
      if (body instanceof Object) {
        this.message = StringUtil.toJson(body);
      } else {
        this.message = String.valueOf(body);
      }
    }
  }
}
