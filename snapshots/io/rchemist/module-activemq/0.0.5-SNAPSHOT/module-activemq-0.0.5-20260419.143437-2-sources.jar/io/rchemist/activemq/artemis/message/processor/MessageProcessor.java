/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.message.processor;

import io.rchemist.activemq.artemis.message.MessageContext;
import io.rchemist.activemq.artemis.message.MessageContextCache;
import io.rchemist.activemq.artemis.message.MessageProvider;
import io.rchemist.activemq.artemis.service.type.AbstractMessageType;
import jakarta.jms.Message;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface MessageProcessor extends MessageProcess {

  Message getMessage();

  AbstractMessageType<?> getMessageType();

  default void process() {
    try {
      Message message = getMessage();

      MessageContext context = MessageContextCache.get(message);

      processInternal(context);

      // 정상 동작한 경우
      MessageContextCache.complete(message);

    }catch (Exception e) {
      processException(e);
    }
  }

  default void processException(Exception e) {
    // e.printStackTrace();
    MessageProvider.retry(getMessageType(), getMessage());
  }

}
