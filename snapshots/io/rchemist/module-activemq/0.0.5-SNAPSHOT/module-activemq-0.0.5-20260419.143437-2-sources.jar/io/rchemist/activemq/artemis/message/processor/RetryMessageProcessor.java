/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.message.processor;

import io.rchemist.activemq.artemis.message.MessageContext;
import io.rchemist.activemq.artemis.service.type.AbstractMessageType;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import lombok.Getter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class RetryMessageProcessor implements MessageProcessor {

  @Getter
  private final AbstractMessageType<?> messageType;

  @Getter
  private final Message message;

  private final MessageProcess process;

  public static void process(AbstractMessageType<?> messageType, Message message, MessageProcess process) {
    new RetryMessageProcessor(messageType, message, process);
  }

  private RetryMessageProcessor(AbstractMessageType<?> messageType, Message message, MessageProcess process) {
    this.messageType = messageType;
    this.message = message;
    this.process = process;
    process();
  }

  @Override
  public void processInternal(MessageContext messageContext) throws JMSException {
    process.processInternal(messageContext);
  }

  @Override
  public void processException(Exception e) {
    MessageProcessor.super.processException(e);
  }
}
