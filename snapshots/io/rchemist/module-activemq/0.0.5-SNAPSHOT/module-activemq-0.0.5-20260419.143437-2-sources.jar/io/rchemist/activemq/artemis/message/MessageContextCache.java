/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.message;

import io.rchemist.activemq.artemis.log.service.LogMessageService;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class MessageContextCache {

  private static final Integer DEFAULT_RETRY_COUNT = 3;

  private static final Integer MAX_ENTRIES = 1000;

  private static final ConcurrentHashMap<String, MessageContext> messageContextMap = new ConcurrentHashMap<>(
      MAX_ENTRIES);

  private static void removeOldMessageContext() {
    messageContextMap.entrySet().stream()
        .filter(entry -> entry.getValue().isExpired())
        .forEach(entry -> messageContextMap.remove(entry.getKey()));
  }

  public static void put(MessageContext messageContext) {
    messageContextMap.put(messageContext.getMessageContextId(), messageContext);
    CompletableFuture.runAsync(MessageContextCache::removeOldMessageContext);
  }

  public static MessageContext get(Message message) {
    try {
      MessageContext context = messageContextMap.get(
          message.getStringProperty(MessageContext.MESSAGE_CONTEXT_ID));
      CompletableFuture.runAsync(MessageContextCache::removeOldMessageContext);
      return context;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public static void complete(Message message) {
    CompletableFuture.runAsync(() -> {
      try {
        messageContextMap.remove(message.getStringProperty(MessageContext.MESSAGE_CONTEXT_ID));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }).thenRunAsync(MessageContextCache::removeOldMessageContext).thenRunAsync(
        () -> {
          try {
            String messageContextId = message.getStringProperty(MessageContext.MESSAGE_CONTEXT_ID);
            LogMessageService.update(messageContextId, true, null);
          } catch (JMSException e) {
            // nothing to do
          }
        });
  }
}
