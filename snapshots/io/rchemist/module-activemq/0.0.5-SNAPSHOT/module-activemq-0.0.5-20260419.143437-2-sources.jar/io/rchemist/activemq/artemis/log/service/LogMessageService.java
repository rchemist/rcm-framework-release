/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.log.service;

import io.rchemist.activemq.artemis.log.dao.LogDao;
import io.rchemist.activemq.artemis.log.domain.QueueMessage;
import io.rchemist.activemq.artemis.message.MessageContext;
import io.rchemist.activemq.artemis.message.MessageProvider;
import io.rchemist.common.configuration.ApplicationContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
public class LogMessageService {

  private final LogDao dao;

  private static LogMessageService service;

  public static LogMessageService getService() {
    if (service == null) {
      service = ApplicationContextHolder.getBean(LogMessageService.class);
    }
    return service;
  }

  public LogMessageService(LogDao dao) {
    this.dao = dao;
  }

  @Transactional
  public void createLog(MessageContext context) {

    QueueMessage message = new QueueMessage();

    message.setMessageContextId(context.getMessageContextId());
    message.setMessageType(context.getMessageType().getType());
    message.setMessageBody(context.getBody());

    dao.getQueueMessageRepository().save(message);

  }

  @Transactional
  public void updateLog(String messageContextId, Boolean succeed, String errorMessage) {
    QueueMessage message = dao.getQueueMessageRepository().findByMessageContextId(messageContextId);
    if (message != null) {
      message.setSucceed(succeed);
      message.setErrorMessage(errorMessage);
      dao.getQueueMessageRepository().save(message);
    }
  }

  // save silently
  public static void create(MessageContext context) {
    if (!MessageProvider.isSaveLogEntity()) {
      return;
    }
    try {
      getService().createLog(context);
    }catch (Exception e) {
      e.printStackTrace();
    }
  }

  // update silently
  public static void update(String messageContextId, Boolean succeed, String errorMessage) {
    if (!MessageProvider.isSaveLogEntity()) {
      return;
    }
    try {
      getService().updateLog(messageContextId, succeed, errorMessage);
    }catch (Exception e) {
      e.printStackTrace();
    }
  }

}
