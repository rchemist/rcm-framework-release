/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.configuration;

import org.apache.activemq.artemis.api.core.QueueConfiguration;
import org.apache.activemq.artemis.core.config.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jms.artemis.ArtemisConfigurationCustomizer;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
@ConditionalOnProperty(prefix = "spring.artemis.embedded", name = "enabled", havingValue = "true",
  matchIfMissing = true)
public class EmbeddedArtemisConfiguration implements
  ArtemisConfigurationCustomizer {

  @Value("${spring.artemis.embedded.max-disk-usage:100}")
  protected int maxDiskUsage;

  @Value("${spring.artemis.embedded.queue-prefix:rcm}")
  protected String queuePrefix;

  @Value("${spring.artemis.embedded.journal-directory:}")
  protected String journalDirectory;

  @Value("${spring.artemis.embedded.persistent:true}")
  protected boolean persistent;

  @Value("${spring.artemis.embedded.graceful-shutdown.enabled:true}")
  protected boolean gracefulShutdown;

  @Value("${spring.artemis.embedded.graceful-shutdown.timeout:60000}")
  protected long gracefulShutdownTimeout;

  @Value("${spring.artemis.embedded.message-expiry-scan-period:3600000}")
  protected long messageExpiryScanPeriod;



  @Override
  public void customize(Configuration configuration) {
    configuration.addQueueConfiguration(QueueConfiguration.of(queuePrefix));
    if (StringUtils.isNotEmpty(journalDirectory)) {
      configuration.setJournalDirectory(journalDirectory);
    }
    configuration.setMaxDiskUsage(maxDiskUsage);
    configuration.setPersistenceEnabled(persistent);
    configuration.setGracefulShutdownEnabled(gracefulShutdown);
    configuration.setGracefulShutdownTimeout(gracefulShutdownTimeout);   // GracefulShutdown timeout 1분
    configuration.setMessageExpiryScanPeriod(messageExpiryScanPeriod);   // 1시간 이상 지난 메시지는 삭제
  }
}
