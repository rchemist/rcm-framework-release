/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.message;

import io.rchemist.activemq.artemis.log.service.LogMessageService;
import io.rchemist.activemq.artemis.service.type.AbstractMessageType;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.NumberUtil;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import java.io.Serializable;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component
public class MessageProvider {

  private static final String RETRY_COUNT = "RETRY_COUNT";
  private static final String RESTRICT_RETRY_COUNT = "RESTRICT_RETRY_COUNT";

  @Value("${spring.artemis.provider.log-entity:false}")
  private Boolean logEntity;

  @Value("${spring.artemis.provider.retry-count:3}")
  private Integer retryCount;

  @Value("${spring.artemis.provider.retry-interval:5000}")
  private Long retryInterval;

  private static Integer defaultRetryCount;

  private static Long defaultRetryInterval;

  private static Boolean saveLogEntity;

  private static MessageProvider instance;

  private static MessageProvider getInstance() {
    if (instance == null) {
      instance = ApplicationContextHolder.getBean(MessageProvider.class);
    }
    return instance;
  }

  private final JmsTemplate jmsTemplate;

  public MessageProvider(JmsTemplate jmsTemplate) {
    this.jmsTemplate = jmsTemplate;
  }

  private static Message appendPropertiesAndReturn(Message message, Boolean redelivered, Integer retryCount, Integer restrictRetryCount) throws JMSException {
    message.setBooleanProperty("JMSRedelivered", redelivered);
    message.setIntProperty(RETRY_COUNT, retryCount);
    message.setIntProperty(RESTRICT_RETRY_COUNT, restrictRetryCount);
    return message;
  }

  private void retryInternal(AbstractMessageType<?> messageType, Message originMessage) throws JMSException {

    if (getDefaultRetryInterval() > 0L) {
      try {
        Thread.sleep(getDefaultRetryInterval());
      } catch (InterruptedException e) {
        throw new RuntimeException(e);
      }
    }

    // get MessageContext from MessageContextCache
    MessageContext messageContext = MessageContextCache.get(originMessage);

    if (messageContext == null)
      throw new RuntimeException("MessageContext is null");

    // copy from original message
    int currentDeliveryCount = 0;
    int restrictRetryCount = 0;
    try {
      currentDeliveryCount = originMessage.getIntProperty("RETRY_COUNT");
      restrictRetryCount = NumberUtil.getInteger(originMessage.getIntProperty("RESTRICT_RETRY_COUNT"), 3);
    } catch (JMSException e) {
      // throw new RuntimeException(e);
    }
    currentDeliveryCount++;

    int finalCurrentDeliveryCount = currentDeliveryCount;
    int finalRestrictRetryCount = restrictRetryCount;

    jmsTemplate.convertAndSend(messageType.getDestination(), messageContext.getBody(), message ->
    {
      message.setStringProperty(MessageContext.MESSAGE_CONTEXT_ID, messageContext.getMessageContextId());
      return appendPropertiesAndReturn(message, true, finalCurrentDeliveryCount, finalRestrictRetryCount);
    });
  }

  public static void send(AbstractMessageType<?> messageType, Serializable data) {
    MessageContext messageContext = new MessageContext(messageType, data)
        .withRetryCount(getDefaultRetryCount());   // default retry count
    send(messageContext);
  }

  public static void send(MessageContext messageContext) {
    getInstance().jmsTemplate.convertAndSend(messageContext.getDestination(), messageContext.getBody(), message -> {

      // put messageContext to MessageContextCache
      MessageContextCache.put(messageContext);
      message.setStringProperty(MessageContext.MESSAGE_CONTEXT_ID, messageContext.getMessageContextId());

      return appendPropertiesAndReturn(message, false, 1, messageContext.getRetryCount());
    });
    CompletableFuture.runAsync(() -> LogMessageService.create(messageContext));
  }

  public static void retry(AbstractMessageType<?> messageType, Message message) {
    try {

      if (isExceedRestrictRetryCount(message)) {
        log.warn("Failed to retry message due to retry count - " + message.getJMSMessageID() + " :: " + message.getIntProperty("JMSXDeliveryCount"));
        String messageContextId = message.getStringProperty(MessageContext.MESSAGE_CONTEXT_ID);
        CompletableFuture.runAsync(() -> LogMessageService.update(messageContextId, false, "재시도 횟수 초과"));
        return;
      }

      log.info("Retry message - " + message.getJMSMessageID());

      // clone message
      getInstance().retryInternal(messageType, message);
    }catch (Exception e) {
      // nothing to do
      try {
        String messageContextId = message.getStringProperty(MessageContext.MESSAGE_CONTEXT_ID);
        CompletableFuture.runAsync(() -> LogMessageService.update(messageContextId, false,
            ExceptionUtil.printException(e)));
      } catch (JMSException ex) {
        throw new RuntimeException(ex);
      }
    }
  }

  public static boolean isExceedRestrictRetryCount(Message message) {
    try {
      return message.getIntProperty(RETRY_COUNT) >= getDefaultRetryCount();
    } catch (JMSException e) {
      // nothing to do
      e.printStackTrace();
      return true;
    }
  }

  public static Integer getDefaultRetryCount() {
    if (defaultRetryCount == null) {
      defaultRetryCount = NumberUtil.getInteger(getInstance().retryCount, 3);
    }
    return defaultRetryCount;
  }

  public static boolean isSaveLogEntity() {
    if (saveLogEntity == null) {
      saveLogEntity = getInstance().logEntity;
    }
    return saveLogEntity;
  }

  public static Long getDefaultRetryInterval() {
    if (defaultRetryInterval == null) {
      defaultRetryInterval = NumberUtil.getLong(getInstance().retryInterval, 5000L);
    }
    return defaultRetryInterval;
  }


}
