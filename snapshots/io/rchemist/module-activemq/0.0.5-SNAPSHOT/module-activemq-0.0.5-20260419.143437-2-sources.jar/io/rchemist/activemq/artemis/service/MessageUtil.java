/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.rchemist.activemq.artemis.service.exception.ConvertMessageException;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.GsonUtil;
import jakarta.jms.Message;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class MessageUtil {

  private static ObjectMapper objectMapper;

  public static ObjectMapper getObjectMapper() {
    if (objectMapper == null) {
      objectMapper = ApplicationContextHolder.getBean(ObjectMapper.class);
    }
    return objectMapper;
  }

  public static String convertString(Message message) {
    String value;
    try {
      if (message instanceof jakarta.jms.TextMessage textMessage) {
        value = textMessage.getText();
      } else if (message instanceof jakarta.jms.ObjectMessage objectMessage) {
        value = GsonUtil.toJson(objectMessage.getObject());
      } else if (message instanceof jakarta.jms.BytesMessage bytesMessage) {
        List<Byte> bytes = new ArrayList<>();
        while (true) {
          try {
            bytes.add(bytesMessage.readByte());
          } catch (Exception e) {
            break;
          }
        }
        // bytes to String
        value = new String(bytes.stream().mapToInt(Byte::intValue).toArray(), 0, bytes.size());
      } else {
        value = String.valueOf(message);
      }

    } catch (Exception e) {
      value = String.valueOf(message);
    }
    return value;
  }

  public static <T> T convert(Message message, Class<T> clazz) throws ConvertMessageException {
    try {
      // message 를 한번 읽으면 다음에는 다시 메시지에 접근할 수 없다. 주의해야 한다.
      String value = convertString(message);

      try {
        return getObjectMapper().readValue(value, clazz);
      } catch (Exception e) {
        throw new ConvertMessageException(e, value);
      }
    }catch (Exception e) {
      if (e instanceof ConvertMessageException) {
        throw e;
      } else {
        throw new ConvertMessageException(e, null);
      }
    }
  }

}
