/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.activemq.artemis.message;

import io.rchemist.activemq.artemis.service.type.AbstractMessageType;
import io.rchemist.common.util.TSIDUtil;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class MessageContext {

  public static final String MESSAGE_CONTEXT_ID = "MESSAGE_CONTEXT_ID";

  public static final Integer DEFAULT_RETRY_COUNT = 3;

  private final String messageContextId = TSIDUtil.tsId();

  private final Serializable body;

  private final AbstractMessageType<?> messageType;

  private Integer retryCount;

  private final LocalDateTime availableAt;

  public boolean isAvailable() {
    return LocalDateTime.now().isBefore(availableAt);
  }

  public boolean isExpired() {
    return LocalDateTime.now().isAfter(availableAt);
  }

  public MessageContext(AbstractMessageType<?> messageType, Serializable body) {
    this.body = body;
    this.messageType = messageType;
    this.availableAt = LocalDateTime.now().plusMinutes(10);    // 캐시는 10분간만 유효하다
  }

  public MessageContext withRetryCount(Integer retryCount) {
    this.retryCount = retryCount;
    return this;
  }

  public String getDestination() {
    return messageType.getDestination();
  }


}
