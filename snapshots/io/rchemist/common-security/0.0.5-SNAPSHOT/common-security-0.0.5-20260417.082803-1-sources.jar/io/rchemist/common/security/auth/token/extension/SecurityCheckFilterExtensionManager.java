/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.token.extension;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.util.type.SiteType;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Service(SecurityCheckFilterExtensionManager.BEAN_NAME)
public class SecurityCheckFilterExtensionManager extends ExtensionManager<SecurityCheckFilterExtensionHandler> {

  public static final String BEAN_NAME = "rcmSecurityCheckFilterExtensionManager";

  public SecurityCheckFilterExtensionManager() {
    super(SecurityCheckFilterExtensionHandler.class);
  }

  private static SecurityCheckFilterExtensionManager instance;

  public static SecurityCheckFilterExtensionManager getInstance() {
    if (instance == null) {
      instance = ApplicationContextHolder.getBean(SecurityCheckFilterExtensionManager.class);
    }
    return instance;
  }

  public static ExtensionResultStatusType authorizeByToken(SiteType siteType, String accessToken, String refreshToken, ExtensionResultHolder<PlatformAuthentication> resultHolder) {
    SecurityCheckFilterExtensionManager instance = getInstance();
    if (instance == null) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    return instance.getProxy().authorizeByToken(siteType, accessToken, refreshToken, resultHolder);
  }
}
