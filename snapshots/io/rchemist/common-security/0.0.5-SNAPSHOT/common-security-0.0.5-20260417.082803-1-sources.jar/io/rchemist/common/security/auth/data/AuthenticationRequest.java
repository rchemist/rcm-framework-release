/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.service.type.AuthRequestType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.security.core.Authentication;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public abstract class AuthenticationRequest implements Serializable {

  protected String siteType;

  protected String tenantAlias;

  protected String siteAlias;

  @RestDataField(name = "자동로그인 여부")
  protected Boolean rememberMe;

  public boolean isRememberMe() {
    return BooleanUtils.toBoolean(getRememberMe());
  }

  public abstract void validate() throws PlatformSecurityException;

  public abstract Object getPrincipal();

  public abstract Object getCredentials();

  public abstract AuthRequestType getAuthRequestType();

  public Authentication createAuthentication() throws PlatformSecurityException {
    validate();
    return new PlatformAuthenticationToken(getAuthRequestType(), getPrincipal(), getCredentials(),
      EnumTypeUtil.getEnumType(SiteType.class, getSiteType(), SiteType.FRONT)
      , null, getTenantAlias(), getSiteAlias(), null)
        .withRememberMe(isRememberMe());
  }

}
