/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.exception;

import io.rchemist.common.exception.error.ErrorDTO;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class PlatformSecurityExceptionFilter extends OncePerRequestFilter {

  private static final String CONTENT_TYPE = "application/json";
  private static final String CHARACTER_ENCODING = "UTF-8";

  @Value("${platform.config.microservice.monolithic:false}")
  protected boolean monolithicMode;

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain filterChain) {

    try{
      filterChain.doFilter(request, response);
    }catch (Exception e){
      if(!monolithicMode){
        // micro service mode 에서만 error response 처리한다.
        ErrorDTO errorDTO = new ErrorDTO(e);
        setErrorResponse(HttpStatus.valueOf(errorDTO.getStatus()), response, errorDTO);
      }

    }

  }

  public void setErrorResponse(HttpStatus status, HttpServletResponse response, ErrorDTO errorDTO){
    response.reset();
    response.setStatus(status.value());
    response.setContentType(CONTENT_TYPE);
    response.setCharacterEncoding(CHARACTER_ENCODING);
    try{
      String json = errorDTO.toJson();
      response.getWriter().write(json);
    }catch (IOException ex){
      ex.printStackTrace();
    }
  }


}
