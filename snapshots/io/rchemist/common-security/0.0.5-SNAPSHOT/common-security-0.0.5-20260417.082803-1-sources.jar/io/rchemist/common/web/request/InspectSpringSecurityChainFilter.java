/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import static io.rchemist.common.web.request.WebPageFilter.SKIP_WEB_PAGE_FILTER;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import org.springframework.beans.BeansException;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class InspectSpringSecurityChainFilter extends GenericFilterBean implements Ordered {

  FilterChainProxy springSecurityChain = null;

  @Override
  public void doFilter(
    ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

    if (springSecurityChain != null) {
      for (SecurityFilterChain chain : springSecurityChain.getFilterChains()) {
        if (chain.matches((HttpServletRequest) servletRequest) && chain.getFilters().isEmpty()) {
          servletRequest.setAttribute(SKIP_WEB_PAGE_FILTER, true);
          break;
        }
      }
    }
    filterChain.doFilter(servletRequest, servletResponse);

  }

  @Override
  public int getOrder() {
    return Integer.MIN_VALUE;   // 가장 먼저 수행한다.
  }

  @EventListener(ContextRefreshedEvent.class)
  public void init(ContextRefreshedEvent event) {
    try {
      springSecurityChain = (FilterChainProxy) event.getApplicationContext().getBean("springSecurityFilterChain");
    } catch (BeansException e) {
      // do nothing
    }
  }

}
