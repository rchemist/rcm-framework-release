/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.extension;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.LoginResult;
import io.rchemist.common.security.auth.data.PasswordCheckRequest;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.SecedeResult;
import io.rchemist.common.security.auth.data.SignOutRequest;
import io.rchemist.common.security.auth.data.Token;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface TokenAuthenticationExtensionHandler extends ExtensionHandler {

  /**
   * 이 핸들러가 처리할 SiteType 을 지정한다.
   * 이 값을 null 로 하면 SiteType 과 관계 없이 동작하게 할 수 있다.
   * @return
   */
  default SiteType getSiteType() {
    return null;
  }

  /**
   * LoginResult 객체가 생성된 후 실행된다.
   * 각 사이트에서 LoginResult 를 LocalCache 외에 다른 저장 장치에 저장할 거라면 이 정보를 사용한다.
   * @param erh
   * @return
   */
  default ExtensionResultStatusType postCreateLoginResult(boolean initialized, ExtensionResultHolder<LoginResult> erh) {

    if (getSiteType() == null || erh.getResult().isEqualSiteType(getSiteType())) {
      return postCreateLoginResultInternal(initialized, erh);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 구현해야 할 실제 로직
   * @param erh
   * @return
   */
  default ExtensionResultStatusType postCreateLoginResultInternal(boolean initialized, ExtensionResultHolder<LoginResult> erh) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * postCreateLoginResult 를 통해 저장된 LoginResult 데이터가 있다면 resultHolder 에 담아 리턴한다.
   *
   * @param siteType
   * @param accessToken
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType findLoginResultByAccessToken(SiteType siteType, String accessToken, ExtensionResultHolder<LoginResult> resultHolder) {
    if (getSiteType() == null || EnumTypeUtil.equals(getSiteType(), siteType)) {
      return findLoginResultByAccessTokenInternal(accessToken, resultHolder);
    }
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 구현해야 할 실제 로직 - accessToken 으로 DB에 저장되었거나 캐싱된 LoginResult 를 반환한다.
   * @param accessToken
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType findLoginResultByAccessTokenInternal(String accessToken, ExtensionResultHolder<LoginResult> resultHolder){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * refreshToken 에 대응되는 accessToken 이 있는지 확인하고 있다면 해당 정보를 리턴한다.
   * postCreateLoginResult 를 통해 저장된 accessToken 정보를 확인한다.
   * @param refreshToken
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType findAccessTokenByRefreshToken(SiteType siteType, String refreshToken, ExtensionResultHolder<String> resultHolder) {

    if (getSiteType() == null || EnumTypeUtil.equals(getSiteType(), siteType)) {
      return findAccessTokenByRefreshTokenInternal(refreshToken, resultHolder);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 로직 - refreshToken 에 대응되는 accessToken 이 있는지 확인하고 있다면 해당 정보를 리턴한다.
   * @param refreshToken
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType findAccessTokenByRefreshTokenInternal(String refreshToken, ExtensionResultHolder<String> resultHolder){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 로그아웃 후 실행된다.
   * postCreateLoginResult 에서 생성한 모든 캐시 데이터를 삭제한다.
   * @param signOutRequest
   * @return
   */
  default ExtensionResultStatusType postSignOut(SignOutRequest signOutRequest) {

    if (getSiteType() == null || EnumTypeUtil.equals(getSiteType(), signOutRequest.getSiteType())) {
      return postSignOutInternal(signOutRequest);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 로직 - 로그아웃 후 실행될 로직을 구현한다. 캐싱된 데이터를 삭제하거나 하는 등의 처리를 한다.
   * @param signOutRequest
   * @return
   */
  default ExtensionResultStatusType postSignOutInternal(SignOutRequest signOutRequest){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 회원 탈퇴 처리 확장 로직
   * 각 서비스에서 이 메소드를 구현해 회원 탈퇴 로직을 처리한다.
   * 토큰의 제거는 signout 을 실행해 자동으로 처리되므로 탈퇴 로직에서 신경쓸 필요는 없다.
   * @param resultHolder
   * @return
   * @throws ErrorTypeException
   */
  default ExtensionResultStatusType processSecedeUser(ExtensionResultHolder<SecedeResult> resultHolder) throws ErrorTypeException {

    if (getSiteType() == null || EnumTypeUtil.equals(resultHolder.getResult().getSiteType(), getSiteType())) {
      return processSecedeUserInternal(resultHolder);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 회원 탈퇴 후 처리해야 하는 로직
   * 토큰의 제거는 signout 을 실행해 자동으로 처리되므로 탈퇴 로직에서 신경쓸 필요는 없다.
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType processSecedeUserInternal(ExtensionResultHolder<SecedeResult> resultHolder){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 회원아이디와 입력받은 비밀번호를 가지고 해당 회원의 비밀번호가 맞는지 체크하는 로직
   * @param request
   * @param resultHolder
   * @return
   * @throws ErrorTypeException
   */
  default ExtensionResultStatusType checkPassword(PasswordCheckRequest request, ExtensionResultHolder<Boolean> resultHolder) throws ErrorTypeException {

    if (getSiteType() == null || EnumTypeUtil.equals(request.getSiteType(), getSiteType())) {
      return checkPasswordInternal(request, resultHolder);
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 회원 비밀번호 체크 로직
   * @param request
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType checkPasswordInternal(PasswordCheckRequest request, ExtensionResultHolder<Boolean> resultHolder) throws ErrorTypeException{
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * authentication 정보를 이용해 token 을 만든다.
   * @param authentication
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType createToken(PlatformAuthentication authentication, ExtensionResultHolder<Token> resultHolder) {
    if (getSiteType() == null || EnumTypeUtil.equals(authentication.getSiteType(), getSiteType())) {
      return createTokenInternal(authentication, resultHolder);
    }
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 로직 - authentication 정보를 이용해 token 을 만든다.
   * @param authentication
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType createTokenInternal(PlatformAuthentication authentication, ExtensionResultHolder<Token> resultHolder){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 생성된 token에 추가 처리를 해야 하는 경우 이 핸들러를 구현한다.
   * @param authentication
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType modifyCreatedToken(PlatformAuthentication authentication, ExtensionResultHolder<Token> resultHolder) {
    if (getSiteType() == null || EnumTypeUtil.equals(authentication.getSiteType(), getSiteType())) {
      return modifyCreatedTokenInternal(authentication, resultHolder);
    }
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 핸들러에서 실제 구현해야 하는 로직 - 생성된 token 에 추가 처리를 해야 하는 경우 이 핸들러를 구현한다.
   * @param authentication
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType modifyCreatedTokenInternal(PlatformAuthentication authentication, ExtensionResultHolder<Token> resultHolder){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
