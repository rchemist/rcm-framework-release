/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.configuration;

import io.rchemist.common.security.auth.service.GatewayTokenAuthenticationService;
import io.rchemist.common.security.auth.service.GlobalAuthenticationProvider;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityExceptionFilter;
import io.rchemist.common.security.auth.token.JwtAccessDeniedHandler;
import io.rchemist.common.security.auth.token.JwtAuthenticationEntryPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.CorsFilter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@EnableWebSecurity
@Slf4j
public class GlobalSecurityConfig {

  protected final GatewayTokenAuthenticationService gatewayTokenAuthenticationService;
  protected final CorsFilter corsFilter;
  protected final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
  protected final JwtAccessDeniedHandler jwtAccessDeniedHandler;
  protected final GlobalAuthenticationProvider globalAuthenticationProvider;
  protected final PasswordEncoder passwordEncoder;
  protected final PlatformSecurityExceptionFilter platformSecurityExceptionFilter;

  public GlobalSecurityConfig(
      GatewayTokenAuthenticationService gatewayTokenAuthenticationService,
      CorsFilter corsFilter,
      JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint,
      JwtAccessDeniedHandler jwtAccessDeniedHandler,
      GlobalAuthenticationProvider globalAuthenticationProvider, PasswordEncoder passwordEncoder, PlatformSecurityExceptionFilter platformSecurityExceptionFilter) {
    this.gatewayTokenAuthenticationService = gatewayTokenAuthenticationService;
    this.corsFilter = corsFilter;
    this.jwtAuthenticationEntryPoint = jwtAuthenticationEntryPoint;
    this.jwtAccessDeniedHandler = jwtAccessDeniedHandler;
    this.globalAuthenticationProvider = globalAuthenticationProvider;
    this.passwordEncoder = passwordEncoder;
    this.platformSecurityExceptionFilter = platformSecurityExceptionFilter;
  }

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
      .csrf(AbstractHttpConfigurer::disable)

      .addFilterBefore(corsFilter, UsernamePasswordAuthenticationFilter.class)

      .exceptionHandling(httpSecurityExceptionHandlingConfigurer -> httpSecurityExceptionHandlingConfigurer
        .authenticationEntryPoint(jwtAuthenticationEntryPoint)
        .accessDeniedHandler(jwtAccessDeniedHandler))

      .sessionManagement(httpSecuritySessionManagementConfigurer -> httpSecuritySessionManagementConfigurer
        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))

      .authorizeHttpRequests(authorizationManagerRequestMatcherRegistry -> {
        authorizationManagerRequestMatcherRegistry.anyRequest().permitAll();
      })
      .apply(new GlobalTokenFilterConfig(gatewayTokenAuthenticationService, passwordEncoder, platformSecurityExceptionFilter))
    ;

    log.info("Successfully configured GlobalSecurityConfig.");

    return http.build();
  }

}
