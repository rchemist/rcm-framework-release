/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.util.type.SiteType;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Data
public class RefreshTokenRequest implements Serializable {

  @NotNull
  private String refreshToken;

  protected SiteType siteType;

  public RefreshTokenRequest withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }


  public RefreshTokenRequest withRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

  public void validate() throws PlatformSecurityException {
    if (StringUtils.isEmpty(refreshToken))
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_REQUIRED);
  }

}
