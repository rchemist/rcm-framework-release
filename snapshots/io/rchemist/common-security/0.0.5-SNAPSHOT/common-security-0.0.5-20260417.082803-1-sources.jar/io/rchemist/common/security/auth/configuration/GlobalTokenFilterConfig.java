/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.configuration;

import io.rchemist.common.security.auth.service.GatewayTokenAuthenticationService;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityExceptionFilter;
import io.rchemist.common.security.auth.token.ServiceSecurityCheckFilter;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
public class GlobalTokenFilterConfig extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity> {

  protected final GatewayTokenAuthenticationService gatewayTokenAuthenticationService;

  protected final PasswordEncoder passwordEncoder;

  protected final PlatformSecurityExceptionFilter platformSecurityExceptionFilter;

  public GlobalTokenFilterConfig(
      GatewayTokenAuthenticationService gatewayTokenAuthenticationService, PasswordEncoder passwordEncoder
      , PlatformSecurityExceptionFilter platformSecurityExceptionFilter) {
    this.gatewayTokenAuthenticationService = gatewayTokenAuthenticationService;
    this.passwordEncoder = passwordEncoder;
    this.platformSecurityExceptionFilter = platformSecurityExceptionFilter;
  }

  @Override
  public void configure(HttpSecurity builder) throws Exception {
    ServiceSecurityCheckFilter customFilter = new ServiceSecurityCheckFilter(gatewayTokenAuthenticationService,
        passwordEncoder);
    builder.addFilterBefore(customFilter, UsernamePasswordAuthenticationFilter.class);
    builder.addFilterBefore(platformSecurityExceptionFilter, ServiceSecurityCheckFilter.class);
  }
}