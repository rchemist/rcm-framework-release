/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.service.type.AuthRequestType;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class SocialLoginRequest extends AuthenticationRequest{

  private static final String SPLITTER = "::";

  @NotNull
  protected String provider;

  @NotNull
  protected String providerUserId;

  @Nullable
  protected String emailAddress;

  @Override
  public void validate() throws PlatformSecurityException {
    if (StringUtils.isEmpty(provider) || StringUtils.isEmpty(providerUserId))
      throw new PlatformSecurityException(PlatformSecurityErrorType.INVALID_SOCIAL_REQUEST);
  }

  @Override
  public Object getPrincipal() {
    return provider + SPLITTER +  providerUserId;
  }

  @Override
  public Object getCredentials() {
    return providerUserId;
  }

  @Override
  public AuthRequestType getAuthRequestType() {
    return AuthRequestType.SOCIAL_PROVIDER;
  }

  @Getter
  public static class SocialLoginProperties implements Serializable {
    private final String provider;
    private final String providerUserId;

    public SocialLoginProperties(String principal) {
      if (StringUtils.isEmpty(principal) || !StringUtils.contains(principal, SPLITTER)) {
        throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_MISMATCH);
      }
      String[] split = StringUtils.split(principal, SPLITTER);
      this.provider = split[0];
      this.providerUserId = split[1];
    }
  }

  public SocialLoginRequest withProvider(String provider) {
    this.provider = provider;
    return this;
  }

  public SocialLoginRequest withProviderUserId(String providerUserId) {
    this.providerUserId = providerUserId;
    return this;
  }

  public SocialLoginRequest withSiteType(String siteType) {
    this.siteType = siteType;
    return this;
  }

  public SocialLoginRequest withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public SocialLoginRequest withSiteAlias(String siteAlias) {
    this.siteAlias = siteAlias;
    return this;
  }

  public SocialLoginRequest withRememberMe(Boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }
}
