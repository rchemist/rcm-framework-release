/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import io.rchemist.common.util.type.SiteType;
import java.io.Serializable;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Data
public class TokenData implements Serializable {

  private String accessToken;

  private String refreshToken;

  private SiteType siteType;

  public SiteType getSiteType() {
    return siteType == null ? SiteType.FRONT : siteType;
  }

  public TokenData() {
    
  }

  public TokenData(String accessToken, String refreshToken) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
  }

  public TokenData withAccessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

  public TokenData withRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

  public TokenData withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }

  public boolean isEmpty() {
    return StringUtils.isEmpty(accessToken) && StringUtils.isEmpty(refreshToken);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    TokenData tokenData = (TokenData) object;

    return new EqualsBuilder().append(accessToken,
        tokenData.accessToken).append(refreshToken, tokenData.refreshToken).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(accessToken).append(refreshToken).toHashCode();
  }
}
