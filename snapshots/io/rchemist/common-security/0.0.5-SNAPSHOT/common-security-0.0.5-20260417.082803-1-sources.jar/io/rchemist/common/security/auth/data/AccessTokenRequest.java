/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import java.io.Serializable;
import lombok.Data;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Data
public class AccessTokenRequest implements Serializable {

  private String accessToken;

  public AccessTokenRequest withAccessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }
}
