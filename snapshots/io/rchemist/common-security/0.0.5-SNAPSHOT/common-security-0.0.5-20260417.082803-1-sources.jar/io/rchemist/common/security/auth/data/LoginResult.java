/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.type.SiteType;
import java.io.Serial;
import java.io.Serializable;
import java.util.Optional;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@NoArgsConstructor
public class LoginResult implements Serializable {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Token token;

  protected PlatformAuthenticationData authentication;

  protected Boolean tokenChanged = false;

  public LoginResult(Token token, PlatformAuthentication authentication) {
    this.token = token;
    this.authentication = new PlatformAuthenticationData(authentication);
  }

  public LoginResult(Token token, PlatformAuthenticationData authentication) {
    this.token = token;
    this.authentication = authentication;
  }

  public LoginResult withToken(Token token) {
    this.token = token;
    return this;
  }

  public LoginResult withAuthentication(
      PlatformAuthentication authentication) {
    this.authentication = new PlatformAuthenticationData(authentication);
    return this;
  }

  public LoginResult withTokenChanged(Boolean tokenChanged) {
    this.tokenChanged = tokenChanged;
    return this;
  }

  public String getAccessToken() {
    return Optional.ofNullable(token)
        .map(Token::getAccessToken)
        .orElse(null);
  }

  public String getRefreshToken() {
    return Optional.ofNullable(token)
        .map(Token::getRefreshToken)
        .orElse(null);
  }

  public String getUserId() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::getUserId)
        .orElse(null);
  }

  public boolean isRememberMe() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::isRememberMe)
        .orElse(false);
  }

  public String getLoginName() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::getLoginName)
        .orElse(null);
  }

  public String getTenantAlias() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::getTenantAlias)
        .orElse(null);
  }

  public String getSiteAlias() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::getSiteAlias)
        .orElse(null);
  }

  public SiteType getSiteType() {
    return Optional.ofNullable(authentication)
        .map(PlatformAuthenticationData::getSiteType)
        .orElse(null);
  }

  public boolean isEqualSiteType(SiteType siteType) {
    return Optional.ofNullable(authentication)
        .map(auth -> EnumTypeUtil.equals(auth.getSiteType(), siteType))
        .orElse(false);
  }


  public long getAccessTokenExpirationTime() {
    return Optional.ofNullable(token)
        .map(Token::getAccessTokenExpirationTime)
        .orElse(60 * 60 * 1000L);
  }

  public long getRefreshTokenExpirationTime() {
    return Optional.ofNullable(token)
        .map(Token::getRefreshTokenExpirationTime)
        .orElse(60 * 60 * 24 * 7 * 1000L); // 7 days. Default.
  }

  public boolean isLoggedIn() {
    String accessToken = getAccessToken();
    String refreshToken = getRefreshToken();
    String userId = getUserId();
    return StringUtil.isNotEmpty(accessToken, refreshToken, userId);
  }

  public PlatformAuthentication getPlatformAuthentication() {
    return authentication != null ? new PlatformAuthentication(authentication) : null;
  }


}
