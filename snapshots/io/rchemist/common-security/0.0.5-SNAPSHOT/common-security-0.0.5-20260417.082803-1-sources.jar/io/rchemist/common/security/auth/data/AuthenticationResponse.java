/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.util.StringUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class AuthenticationResponse implements UserDetails {

  protected String siteType;

  protected String loginName;

  protected String emailAddress;

  protected String phoneNumber;

  protected String name;    // 식별 이름

  protected String password;

  protected String userId;    // Admin, Customer 의 각 ID

  protected String tenantAlias;    // 어떤 Tenant 에 속해 있는지

  protected String siteAlias;    // 어떤 Site 에 속해 있는지 - SiteType 이 FRONT 일 때만 값이 존재한다.

  protected List<String> roles = new ArrayList<>();

  protected boolean enabled = true;

  protected boolean accountNonLocked = true;

  protected boolean hidden = false;

  protected boolean accountNonExpired = true;

  protected boolean credentialsNonExpired = true;

  protected String profile;

  protected String userType;

  protected Map<String, Object> attributes;

  public AuthenticationResponse withUserType(String userType) {
    this.userType = userType;
    return this;
  }

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    if(CollectionUtils.isNotEmpty(roles)){
      return roles.stream().map(SimpleGrantedAuthority::new)
          .collect(Collectors.toList());
    }
    return Collections.emptyList();
  }

  @Override
  public String getUsername() {
    return StringUtil.toString(getName(), getLoginName());
  }

  public AuthenticationResponse withSiteType(String siteType) {
    this.siteType = siteType;
    return this;
  }

  public AuthenticationResponse withEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  public AuthenticationResponse withPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

  public AuthenticationResponse withLoginName(String loginName) {
    this.loginName = loginName;
    return this;
  }

  public AuthenticationResponse withName(String name) {
    this.name = name;
    return this;
  }

  public AuthenticationResponse withPassword(String password) {
    this.password = password;
    return this;
  }

  public AuthenticationResponse withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public AuthenticationResponse withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public AuthenticationResponse withSiteAlias(String siteAlias) {
    this.siteAlias = siteAlias;
    return this;
  }

  public AuthenticationResponse withRoles(List<String> roles) {
    this.roles = roles;
    return this;
  }

  public AuthenticationResponse addRole(String... roles) {
    if (roles != null && roles.length > 0) {
      // 중복 방지를 위함
      Set<String> roleSet = new HashSet<>(this.roles);
      roleSet.addAll(List.of(roles));
      this.roles = new ArrayList<>(roleSet);
    }
    return this;
  }

  public AuthenticationResponse removeRole(String... roles) {
    if (CollectionUtils.isNotEmpty(this.roles) && (roles != null && roles.length > 0)) {
      Arrays.stream(roles).forEach(role -> this.roles.remove(role));
    }
    return this;
  }

  /**
   * 열거한 role 중 하나라도 있으면 true
   * @param roles
   * @return
   */
  public boolean hasAnyRole(String... roles) {
    if (roles != null && roles.length > 0 && CollectionUtils.isNotEmpty(this.roles)) {
      for (String role : roles) {
        if (this.roles.contains(role)) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * 특정 role 보유 여부
   * @param role
   * @return
   */
  public boolean hasRole(String role) {
    return this.roles.contains(role);
  }

  /**
   * 열거한 모든 role 을 가지고 있는 경우에만 true
   * @param roles
   * @return
   */
  public boolean hasRole(String... roles) {

    if (roles != null && roles.length > 0) {

      if (CollectionUtils.isEmpty(this.roles)) {
        // 현재 보유한 role 이 없으면 false
        return false;
      }

      for (String role : roles) {
        if (!this.roles.contains(role)) {
          return false;
        }
      }
    }
    return true;
  }

  public AuthenticationResponse withEnabled(boolean enabled) {
    this.enabled = enabled;
    return this;
  }

  public AuthenticationResponse withAccountNonLocked(boolean accountNonLocked) {
    this.accountNonLocked = accountNonLocked;
    return this;
  }

  public AuthenticationResponse withHidden(boolean hidden) {
    this.hidden = hidden;
    return this;
  }

  public AuthenticationResponse withAccountNonExpired(boolean accountNonExpired) {
    this.accountNonExpired = accountNonExpired;
    return this;
  }

  public AuthenticationResponse withCredentialsNonExpired(boolean credentialsNonExpired) {
    this.credentialsNonExpired = credentialsNonExpired;
    return this;
  }

  public AuthenticationResponse withProfile(String profile) {
    this.profile = profile;
    return this;
  }

  public AuthenticationResponse withAttributes(Map<String, Object> attributes) {
    this.attributes = attributes;
    return this;
  }

  public AuthenticationResponse putAttribute(String key, Object value) {
    if (getAttributes() == null) {
      setAttributes(new HashMap<>());
    }
    getAttributes().put(key, value);
    return this;
  }

  public <S> S getAttribute(String key) {
    if (getAttributes() == null || !getAttributes().containsKey(key)) {
      return null;
    }
    return (S) getAttributes().get(key);
  }

  public AuthenticationResponse removeAttribute(String key) {
    if (getAttributes() != null) {
      getAttributes().remove(key);
    }
    return this;
  }



}
