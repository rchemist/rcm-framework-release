/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.AuthenticationResponse;
import io.rchemist.common.security.auth.data.DuplicateCheckRequest;
import io.rchemist.common.security.auth.data.PlatformAuthenticationToken;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.auth.service.type.SocialAccountActionType;
import org.springframework.security.core.AuthenticationException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface UserDetailsServiceProvider extends ExtensionHandler {

  /**
   * 사용자 정보 조회
   * 로그인 요청 정보를 가지고 실제로 DB 를 확인해 사용자 정보를 조회 한다.
   * PlatformAuthenticationToken 은 UsernamePassword 또는 SocialLogin 을 통해 생성 된다.
   *
   * @param authentication 로그인 요청 정보
   * @param result 조회한 사용자 정보
   * @return
   * @throws PlatformSecurityException
   */
  default ExtensionResultStatusType retrieveUser(PlatformAuthenticationToken authentication, ExtensionResultHolder<AuthenticationResponse> result) throws PlatformSecurityException {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 로그인 성공 또는 실패 기록을 저장한다.
   * 총 X 회 이상 연속 실패 시 계정 잠금 등의 처리를 하기 위해 사용한다.
   * 이 핸들러 내에 로그인이 성공했으면 연속 실패 횟수를 초기화 하는 등의 로직이 필요하다.
   *
   * @param authentication 로그인 요청 정보
   * @param user 실제 리턴된 사용자 정보
   * @param failed 로그인 실패 여부
   * @return
   */
  default ExtensionResultStatusType traceLoginResult(PlatformAuthenticationToken authentication, AuthenticationResponse user, boolean failed) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default ExtensionResultStatusType validate(
    PlatformAuthenticationToken authentication, AuthenticationResponse response) throws AuthenticationException {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 이메일 주소로 회원 가입 여부를 확인한다.
   * @param request
   * @param resultHolder
   * @return
   */
  default ExtensionResultStatusType checkRegisteredUserByEmailAddress(DuplicateCheckRequest request, ExtensionResultHolder<SocialAccountActionType> resultHolder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
