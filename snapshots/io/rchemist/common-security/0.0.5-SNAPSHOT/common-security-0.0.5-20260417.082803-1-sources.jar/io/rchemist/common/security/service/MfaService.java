/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service;

import dev.samstevens.totp.code.CodeGenerator;
import dev.samstevens.totp.code.DefaultCodeGenerator;
import dev.samstevens.totp.code.DefaultCodeVerifier;
import dev.samstevens.totp.code.HashingAlgorithm;
import dev.samstevens.totp.qr.QrData;
import dev.samstevens.totp.qr.QrGenerator;
import dev.samstevens.totp.qr.ZxingPngQrGenerator;
import dev.samstevens.totp.secret.DefaultSecretGenerator;
import dev.samstevens.totp.secret.SecretGenerator;
import dev.samstevens.totp.time.NtpTimeProvider;
import dev.samstevens.totp.time.TimeProvider;
import lombok.SneakyThrows;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class MfaService {

  private static final QrGenerator qrGenerator = new ZxingPngQrGenerator();

  public static String getSecret(){
    SecretGenerator secretGenerator = new DefaultSecretGenerator(64);
    return secretGenerator.generate();
  }

  public static String generateQrCodeImage(String userIdentifier, String issuer, String secret){
    return generateQrCodeImage(secret, userIdentifier, issuer, HashingAlgorithm.SHA512, 6, 15);
  }

  @SneakyThrows
  public static String generateQrCodeImage(String secret, String userIdentifier, String issuer, HashingAlgorithm algorithm, int digitsLength, int period){
    QrData data = new QrData.Builder()
        .label(userIdentifier)
        .secret(secret)
        .issuer(issuer)
        .algorithm(algorithm)
        .digits(digitsLength)
        .period(period)
        .build();

    byte[] imageData = qrGenerator.generate(data);

    String encodedString = Base64.encodeBase64String(imageData);

    return encodedString;
  }

  public static boolean validateCode(String secret, String code){
    return validateCode(secret, code, HashingAlgorithm.SHA512, 6, 15, 2);
  }

  @SneakyThrows
  public static boolean validateCode(String secret, String code, HashingAlgorithm algorithm, int digitsLength, int timePeriod, int allowedTimePeriodDiscrepancy){

    if(StringUtils.isEmpty(secret))
      return false;

    if(StringUtils.isEmpty(code))
      return false;

    TimeProvider timeProvider = new NtpTimeProvider("pool.ntp.org", 5000);
    CodeGenerator codeGenerator = new DefaultCodeGenerator(algorithm, digitsLength);
    DefaultCodeVerifier codeVerifier = new DefaultCodeVerifier(codeGenerator, timeProvider);

    codeVerifier.setTimePeriod(timePeriod);
    //codeVerifier.setAllowedTimePeriodDiscrepancy(allowedTimePeriodDiscrepancy);

    return codeVerifier.isValidCode(secret, code);
  }

}
