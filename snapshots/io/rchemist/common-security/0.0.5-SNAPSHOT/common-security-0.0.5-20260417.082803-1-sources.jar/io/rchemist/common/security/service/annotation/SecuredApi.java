/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Api endpoint 를 자동으로 탐지할 때 이 어노테이션 정보를 이용한다.
 * 이 어노테이션이 없는 경우 핸들러 메소드에 있는 메타데이터를 이용해 만든다.
 * 따라서, APi endpoint 를 자동으로 탐지하기를 원하지 않는 경우 해당 메소드 또는 타입에 NonSecuredApi 를 붙여야 한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface SecuredApi {

  String service();

  String module() default "";

  String name() default "";

  boolean secure() default true;

}
