/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import io.rchemist.common.security.service.exception.SecurityServiceErrorType;
import io.rchemist.common.security.service.exception.SecurityServiceException;
import io.rchemist.common.util.type.RegexType.Regex;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateApiRole implements Serializable {

  @NotNull
  @Size(min = 2, max = 50)
  @Pattern(regexp = Regex.NUMBER_ENGLISH_EXT)
  private String apiRole;

  private List<String> permissions = new ArrayList<>();

  private List<String> childRoles = new ArrayList<>();

  public void validate() throws SecurityServiceException {
    if(StringUtils.isEmpty(getApiRole()))
      throw new SecurityServiceException(SecurityServiceErrorType.REQUIRED_ROLE_NAME);

    this.permissions = CollectionUtils.emptyIfNull(permissions).stream()
        .filter(StringUtils::isNotEmpty).distinct().collect(Collectors.toList());

    this.childRoles = CollectionUtils.emptyIfNull(childRoles).stream()
        .filter(StringUtils::isNotEmpty).distinct().collect(Collectors.toList());
  }


}
