/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiRoleDTO implements Serializable {

  private String role;

  @Builder.Default
  private Map<String, SecuredModuleContext> modulePermissions = new TreeMap<>();   // module name, permission data

  public ApiRoleDTO putModulePermission(SecuredModuleContext dto){
    if(this.modulePermissions == null)
      this.modulePermissions = new TreeMap<>();
    if(modulePermissions.containsKey(dto.getModule())){
      modulePermissions.get(dto.getModule()).addPermissions(dto.getSecuredApis());
    }else{
      modulePermissions.put(dto.getModule(), dto);
    }
    return this;
  }

  public ApiRoleDTO addPermission(SecuredApiDTO data){
    if(this.modulePermissions == null)
      this.modulePermissions = new TreeMap<>();

    SecuredModuleContext modulePermission;
    if(modulePermissions.containsKey(data.getModule())){
      modulePermission = modulePermissions.get(data.getModule());
    }else{
      modulePermission = new SecuredModuleContext();
    }
    modulePermission.addPermissions(data);
    modulePermissions.put(data.getModule(), modulePermission);
    return this;
  }

  public List<String> getPermissions() {
    List<String> permissions = new ArrayList<>();
    if(MapUtils.isNotEmpty(modulePermissions)){
      for(String module : modulePermissions.keySet()){
        SecuredModuleContext modulePermission = modulePermissions.get(module);
        for(SecuredApiDTO data : modulePermission.getSecuredApis()){
          permissions.add(data.getPermissionCode());
        }
      }
    }
    return permissions;
  }
}
