/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.token;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.ExpiredJwtException;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.LoginResult;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.service.GatewayTokenAuthenticationService;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.auth.token.extension.SecurityCheckFilterExtensionManager;
import io.rchemist.common.security.data.TokenData;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * 모든 요청에 대해 토큰을 검증한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class ServiceSecurityCheckFilter extends UsernamePasswordAuthenticationFilter {

  protected final GatewayTokenAuthenticationService gatewayTokenAuthenticationService;

  protected final PasswordEncoder passwordEncoder;

  protected final List<SimpleGrantedAuthority> ANONYMOUS_AUTHORITIES = List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));

  private static final String ANONYMOUS = "anonymous";

  private static final String ANONYMOUS_PASSWORD = "userNotFoundPassword";

  private static ObjectMapper objectMapper;

  private static ObjectMapper getObjectMapper() {
    if (objectMapper == null) {
      objectMapper = ApplicationContextHolder.getBean(ObjectMapper.class);
    }
    return objectMapper;
  }

  public ServiceSecurityCheckFilter(
      GatewayTokenAuthenticationService gatewayTokenAuthenticationService, PasswordEncoder passwordEncoder) {
    this.gatewayTokenAuthenticationService = gatewayTokenAuthenticationService;
    this.passwordEncoder = passwordEncoder;

    this.setAuthenticationFailureHandler(getCustomAuthenticationFailureHandler());
  }


  protected AuthenticationFailureHandler getCustomAuthenticationFailureHandler() {
    return (request, response, exception) -> {
      ResponseData<Object> result = ResponseHelper.result(exception);
      response.reset();
      response.setStatus(result.getStatusCode().value());
      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");

      Map<String, Object> resultMap = new HashMap<>();
      resultMap.put("error", result.getError());

      try {
        getObjectMapper().writeValue(response.getWriter(), resultMap);
      } catch (Exception e) {
        log.error("Failed to write response", e);
      }

    };
  }

  protected String anonymousPassword;

  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
      FilterChain filterChain) throws IOException, ServletException {

    try {
      validateAccessToken((HttpServletRequest) servletRequest);

      filterChain.doFilter(servletRequest, servletResponse);
    }catch (Exception e) {

      AuthenticationException exception = new AuthenticationServiceException(e.getMessage(), e);

      this.getFailureHandler().onAuthenticationFailure(
          (HttpServletRequest) servletRequest, (HttpServletResponse) servletResponse, exception
      );
    }

  }

  protected void validateAccessToken(HttpServletRequest servletRequest) {
    String accessToken = JwtTokenHelper.resolveAccessToken(servletRequest);
    String refreshToken = JwtTokenHelper.resolveRefreshToken(servletRequest);
    SiteType siteType = JwtTokenHelper.resolveSiteType(servletRequest);

    try{
      if (StringUtils.isNotEmpty(accessToken) || StringUtils.isNotEmpty(refreshToken)) {
        try {
          LoginResult loginResult = gatewayTokenAuthenticationService.getLoginResultByToken(new TokenData(accessToken, refreshToken).withSiteType(siteType));
          if (loginResult != null) {
            PlatformAuthentication authentication = new PlatformAuthentication(loginResult.getAuthentication());
            SecurityContextHolder.getContext().setAuthentication(authentication);
          } else {
            throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_MISMATCH);
          }
        }catch (Exception e) {
          // 기본 서비스로 인증에 실패하는 경우 사용자 정의 프로세스를 통해 PlatformAuthentication 을 획득하게 할 수 있다.
          ExtensionResultHolder<PlatformAuthentication> resultHolder = new ExtensionResultHolder<>();
          ExtensionResultStatusType status = SecurityCheckFilterExtensionManager.authorizeByToken(siteType, accessToken, refreshToken, resultHolder);

          if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
            PlatformAuthentication authentication = resultHolder.getResult();
            SecurityContextHolder.getContext().setAuthentication(authentication);
          } else {
            // 여기서 throw 를 했을때 어떻게 authenticationFailureHandler 를 타게 하지?
            throw e;
          }
        }
      }
    }catch (ExpiredJwtException e){
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_MISMATCH);
    }
  }

  protected void useAnonymousAuthentication(){
    SecurityContextHolder.getContext().setAuthentication(getAnonymousAuthentication());
  }

  private AnonymousAuthenticationToken getAnonymousAuthentication(){
    User anonymous = new User(ANONYMOUS, getAnonymousPassword(), ANONYMOUS_AUTHORITIES);
    return new AnonymousAuthenticationToken(anonymous.getPassword(), anonymous, anonymous.getAuthorities());
  }

  private String getAnonymousPassword(){
    if(StringUtils.isEmpty(this.anonymousPassword)){
      this.anonymousPassword = passwordEncoder.encode(ANONYMOUS_PASSWORD + LocalDateTime.now().getChronology().toString());
    }
    return this.anonymousPassword;
  }


}
