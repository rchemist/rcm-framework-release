/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.configuration;

import io.rchemist.common.configuration.ApplicationContextHolder;
import java.io.Serializable;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
@ConfigurationProperties(prefix = "platform.config.common.security")
public class SecurityConfigProperty implements Serializable {

  private static SecurityConfigProperty properties;

  // platform.config.common.security.xss-protection: true
  @Getter
  private boolean xssProtection = false;

  public static SecurityConfigProperty getProperties() {
    if(properties == null){
      properties = ApplicationContextHolder.getBean(SecurityConfigProperty.class);
    }
    return properties;
  }

}
