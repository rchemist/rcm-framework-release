/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import io.rchemist.common.util.StringUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class XssFilterRequest extends HttpServletRequestWrapper {

  public XssFilterRequest(final HttpServletRequest request) {
    super(request);
  }

  @Override
  public String[] getParameterValues(final String name) {
    final String[] originalValues = super.getParameterValues(name);

    if (ArrayUtils.isEmpty(originalValues))
      return originalValues;

    return Arrays.stream(originalValues).map(StringUtil::cleanXss)
        .toArray(String[]::new);
  }

  @Override
  public Map<String, String[]> getParameterMap() {
    final Map<String, String[]> requestParameters = super.getParameterMap();
    final Map<String, String[]> filteredParameters = requestParameters.keySet().stream().collect(
        Collectors.toMap(name -> name, this::getParameterValues, (a, b) -> b,
            () -> new ConcurrentHashMap<>(requestParameters.size())));
    return Collections.unmodifiableMap(filteredParameters);
  }

  @Override
  public String getParameter(final String name) {
    final String potentiallyDirtyParameter = super.getParameter(name);
    return StringUtil.cleanXss(potentiallyDirtyParameter);
  }

}
