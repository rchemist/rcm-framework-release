/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.AuthenticationResponse;
import io.rchemist.common.security.auth.data.DuplicateCheckRequest;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.PlatformAuthenticationToken;
import io.rchemist.common.security.auth.data.UserDetailsCacheItem;
import io.rchemist.common.security.auth.service.extension.UserDetailsServiceManager;
import io.rchemist.common.security.auth.service.type.SocialAccountActionType;
import io.rchemist.common.security.service.type.AuthRequestType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import javax.cache.Cache;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmGlobalAuthenticationProvider")
@Slf4j
public class GlobalAuthenticationProviderImpl implements GlobalAuthenticationProvider {

  protected final PreAuthenticationValidator preValidator;
  protected final PostAuthenticationValidator postValidator;
  protected final PasswordEncoder passwordEncoder;
  protected final UserDetailsServiceManager userDetailsServiceManager;

  private static final String SPLITTER = "::";


  @Value("${platform.config.apigateway.auth.hide_notfound_user:true}")
  private boolean hideUserNotFoundExceptions;

  @Value("${platform.config.user.auth.use-cache:false}")
  private boolean useCache;

  @Getter
  @Setter
  protected boolean forcePrincipalAsString = false;

  @Getter
  @Setter
  private GrantedAuthoritiesMapper authoritiesMapper = new NullAuthoritiesMapper();

  private volatile String userNotFoundEncodedPassword;

  // cacheKey, UserDetailsCacheItem
  protected final Cache<String, UserDetailsCacheItem> cache;

  // cacheKey, refreshToken
  protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();

  public static final String CACHE_REGION_NAME = "GLOBAL_AUTHENTICATE";

  public GlobalAuthenticationProviderImpl(@Autowired(required = false) CommonCacheManager commonCacheManager,
      PreAuthenticationValidator preValidator,
      PostAuthenticationValidator postValidator,
      PasswordEncoder passwordEncoder,
      UserDetailsServiceManager userDetailsServiceManager) {
    this.preValidator = preValidator;
    this.postValidator = postValidator;
    this.passwordEncoder = passwordEncoder;
    this.userDetailsServiceManager = userDetailsServiceManager;
    if (commonCacheManager == null) {
      this.cache = null;
    } else {
      if (this.useCache) {
        this.cache = commonCacheManager.getOrCreateCache(CACHE_REGION_NAME, 60 * 30, 10000, UserDetailsCacheItem.class);
      } else {
        this.cache = null;
      }
    }
  }

  /**
   * 기존 캐시키를 만드는 로직이 너무 복잡해서 외부에 User 엔티티가 변화할 때 UserDetailsCache 를 evict 할 수가 없다.
   * globalAuthentication.getCacheKey() 로 만드는데, 실제 들어가 보면 AuthType 부터 알아야 할 것이 한 두 가지가 아니다.
   * 그리고 저게 외부에 클래스에 캐시키를 만드는 로직이 있다 보니 GlobalAuthenticationProvider 입장에서 캐시키를 어떻게 만들어야 하는지를 모르고 있다.
   * 따라서 캐시키 만드는 로직을 여기에 두고, 각 서비스에서 user 엔티티에 변화가 있을 때 clear 할 수 있게 하자.
   * 단, social login 과 같은 경우에는 - loginName 뿐 아니라 해당 user 의 socialProviderId 를 같이 가져와서 evict 해야 한다.
   * 이 처리가 그다지 매끄럽지 않기 때문에 일단은 private boolean useCache; 의 기본값을 false 로 해서 캐시를 끄고 추후 캐시키를 어떻게 만들 것인지 다시 생각해 봐야겠다.
   * 2024-07-31, kunner
   * @param authenticationToken
   * @return
   */
  private String createCacheKey(PlatformAuthenticationToken authenticationToken) {
    return createCacheKey(authenticationToken.getAuthRequestType(), authenticationToken.getSiteType(), String.valueOf(authenticationToken.getPrincipal()));
  }

  private String createCacheKey(AuthRequestType authRequestType, SiteType siteType, String principal) {
    return authRequestType.getType()
        + SPLITTER + siteType.getType()
        + SPLITTER + principal    // loginName
        + SPLITTER;
  }

  @Override
  public Authentication authenticate(Authentication authentication) throws AuthenticationException {

    boolean loginFailed = false;
    AuthenticationResponse user = null;

    try{
      if (!(authentication instanceof PlatformAuthenticationToken globalAuthentication)) {
        throw new InternalAuthenticationServiceException("Only PlatformAuthenticationToken is supported");
      }

      String cacheKey = createCacheKey(globalAuthentication);

      user = getUserDetailsFromCache(cacheKey);

      if (user == null) {
        // 각 서비스에서 extension manager 를 이용해 UserDetails 를 생성한다.
        user = retrieveUser(globalAuthentication);

        if (user == null) {
          throw new AuthenticationCredentialsNotFoundException("UserDetailsService returned null, which is an interface contract violation");
        }

      }

      // userDetails 에 대한 체크. lock 되었는지 등
      this.preValidator.check(user);
      this.additionalAuthenticationChecks(user, globalAuthentication);
      this.postValidator.check(user);

      putUserInCache(cacheKey, user);

      Object principalToReturn = user;
      if (this.forcePrincipalAsString) {
        principalToReturn = user.getUsername();
      }

      PlatformAuthentication result = new PlatformAuthentication(user).withPrincipal(principalToReturn).withRememberMe(globalAuthentication.isRememberMe());
      SecurityContextHolder.getContext().setAuthentication(result);

      return result;

    }catch (Exception e){
      loginFailed = true;
      throw e;
    }finally {
      traceLoginResult(authentication, user, loginFailed);
    }

  }

  private void traceLoginResult(Authentication authentication, AuthenticationResponse user, boolean failed) {
    if ((authentication instanceof PlatformAuthenticationToken globalAuthentication)) {
      try {
        ExtensionResultStatusType status = userDetailsServiceManager.getProxy().traceLoginResult(globalAuthentication, user, failed);
        if(status.equals(ExtensionResultStatusType.NOT_HANDLED)){
          log.debug("UserDetailsServiceManager#traceLoginResult returned null");
        }
      }catch (Exception e) {
        // nothing to do
      }
    }
  }

  private void putUserInCache(String cacheKey, AuthenticationResponse user){
    if (!isCacheEnabled())
      return;

    String loginName = user.getUsername();
    UserDetailsCacheItem item = new UserDetailsCacheItem(loginName, user);
    cache.put(cacheKey, item);

  }

  private static String createRegisteredEmailCacheKey(String siteType, String loginName) {
    return EnumTypeUtil.getEnumType(SiteType.class, siteType, SiteType.FRONT).getType()
        + "_" + loginName;
  }

  private AuthenticationResponse getUserDetailsFromCache(String cacheKey) {
    if (!isCacheEnabled())
      return null;

    try{
      if(cache.containsKey(cacheKey)){

        log.debug("UserDetails 정보를 캐시에서 조회");
        UserDetailsCacheItem item = cache.get(cacheKey);
        // 캐시에 다시 넣어 만료 시간을 늘린다.
        cache.put(cacheKey, item);

        return item.getUserDetails();
      }

      log.debug("캐시에 없음");

      return null;
    }catch (Exception e){
      // REDIS 에서 정보를 가져오다 오류가 발생해도 DB 조회를 통해 회원 정보를 조회할 수 있도록 exception 을 제거한다.
      log.warn("Failed to load userDetails from cache.");
      e.printStackTrace();
      return null;
    }

  }

  private String determineLoginName(Authentication authentication) {

    if (authentication instanceof PlatformAuthenticationToken globalAuthentication) {
      return globalAuthentication.getName();
    }

    return authentication.getPrincipal() == null ? "NONE_PROVIDED" : authentication.getName();
  }

  @Override
  public boolean supports(Class<?> authentication) {
    return authentication.equals(PlatformAuthenticationToken.class);
  }

  protected void additionalAuthenticationChecks(AuthenticationResponse user, PlatformAuthenticationToken authentication) throws AuthenticationException {
    if (authentication.isUsernamePasswordRequest() && authentication.getCredentials() == null) {
      log.debug("Failed to authenticate since no credentials provided");
      throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
    }
    userDetailsServiceManager.getProxy().validate(authentication, user);
  }

  protected final AuthenticationResponse retrieveUser(PlatformAuthenticationToken authentication) throws AuthenticationException {
    this.prepareTimingAttackProtection();

    try {
      var resultHolder = new ExtensionResultHolder<AuthenticationResponse>();
      ExtensionResultStatusType status = userDetailsServiceManager.getProxy().retrieveUser(authentication, resultHolder);

      if(status.equals(ExtensionResultStatusType.NOT_HANDLED) || resultHolder.getResult() == null){
        throw new InternalAuthenticationServiceException("UserDetailsServiceManager returned null, which is an interface contract violation");
      }

      return resultHolder.getResult();

    } catch (UsernameNotFoundException e) {
      this.mitigateAgainstTimingAttack(authentication);

      if (!this.hideUserNotFoundExceptions) {
        throw e;
      }

      throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
    } catch (InternalAuthenticationServiceException e) {
      throw e;
    } catch (Exception e) {
      throw new InternalAuthenticationServiceException(e.getMessage(), e);
    }
  }

  private void prepareTimingAttackProtection() {
    if (this.userNotFoundEncodedPassword == null) {
      this.userNotFoundEncodedPassword = this.passwordEncoder.encode("userNotFoundPassword");
    }
  }

  private void mitigateAgainstTimingAttack(PlatformAuthenticationToken authentication) {
    if (authentication.getCredentials() != null) {
      String presentedPassword = authentication.getCredentials().toString();
      this.passwordEncoder.matches(presentedPassword, this.userNotFoundEncodedPassword);
    }
  }

  @Override
  public void clearUserDetailCache(SiteType siteType, String... loginNames){
    if (!isCacheEnabled())
      return;
    if(ArrayUtils.isNotEmpty(loginNames)){
      for(String loginName : loginNames){
        String cacheKey = createCacheKey(AuthRequestType.USERNAME_PASSWORD, siteType, loginName);
        if(cache.containsKey(cacheKey)){
          cache.remove(cacheKey);
        }
        // TODO AuthRequestType.SOCIAL_PROVIDER 에 대한 evict 로직을 추가해야 한다.
      }
    }
  }

  public static void clearCache(SiteType siteType, String... loginNames){
    try {
      GlobalAuthenticationProvider provider = ApplicationContextHolder.getBean(GlobalAuthenticationProvider.class);
      provider.clearUserDetailCache(siteType, loginNames);
    }catch (Exception e){
      log.warn("Error occurred during clear cache", e);
    }
  }

  protected boolean isCacheEnabled(){
    return this.useCache && this.cache != null;
  }


  @Override
  public SocialAccountActionType checkRegisteredUserByEmailAddress(DuplicateCheckRequest request) {

    ExtensionResultHolder<SocialAccountActionType> resultHolder = new ExtensionResultHolder<SocialAccountActionType>().withResult(SocialAccountActionType.NOT_FOUND);
    ExtensionResultStatusType statusType = userDetailsServiceManager.getProxy().checkRegisteredUserByEmailAddress(request, resultHolder);

    if (!statusType.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
      return resultHolder.getResult();
    }

    return SocialAccountActionType.NOT_FOUND;

  }
}
