/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SecuredModuleContext implements Serializable {

  private String module;

  @Builder.Default
  private List<SecuredApiDTO> securedApis = new ArrayList<>();

  public SecuredModuleContext addPermissions(SecuredApiDTO... data){
    if(ArrayUtils.isNotEmpty(data)){
      Set<SecuredApiDTO> permissions = new HashSet<>(this.securedApis);
      Collections.addAll(permissions, data);
      this.securedApis = new ArrayList<>(permissions);
      this.securedApis.sort(Comparator.comparing(SecuredApiDTO::getName));
    }
    return this;
  }

  public SecuredModuleContext addPermissions(List<SecuredApiDTO> data){
    if(CollectionUtils.isNotEmpty(data)){
      Set<SecuredApiDTO> permissions = new HashSet<>(this.securedApis);
      permissions.addAll(data);
      this.securedApis = new ArrayList<>(permissions);
      this.securedApis.sort(Comparator.comparing(SecuredApiDTO::getName));
    }
    return this;
  }

}
