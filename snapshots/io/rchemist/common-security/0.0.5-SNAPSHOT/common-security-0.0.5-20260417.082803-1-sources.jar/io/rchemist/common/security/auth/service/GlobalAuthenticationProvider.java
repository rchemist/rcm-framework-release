/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import io.rchemist.common.security.auth.data.DuplicateCheckRequest;
import io.rchemist.common.security.auth.service.type.SocialAccountActionType;
import io.rchemist.common.util.type.SiteType;
import org.springframework.security.authentication.AuthenticationProvider;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface GlobalAuthenticationProvider extends AuthenticationProvider {

  /**
   * REDIS 내장 캐시 clear
   * @param siteType
   * @param loginNames
   */
  void clearUserDetailCache(SiteType siteType, String... loginNames);

  /**
   * 해당 site 에 동일한 emailAddress 가 존재하는지 확인
   * @param request
   * @return
   */
  SocialAccountActionType checkRegisteredUserByEmailAddress(DuplicateCheckRequest request);
}
