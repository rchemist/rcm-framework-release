/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.persistence.domain.template.presentation.HasEmailAddress;
import io.rchemist.common.persistence.domain.template.presentation.HasLoginName;
import io.rchemist.common.persistence.domain.template.presentation.HasPhoneNumber;
import io.rchemist.common.persistence.domain.template.presentation.HasSiteAlias;
import io.rchemist.common.util.type.SiteType;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * 기존 등록된 회원인지 확인할 때 사용하는 파라미터 객체
 * login name
 * emailAddress
 * phoneNumber
 * provider
 * tenant alias
 * site alias
 * 등에 대해 다양한 조합으로 중복확인을 할 수 있다.
 *
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class DuplicateCheckRequest implements HasEmailAddress<DuplicateCheckRequest>,
    HasLoginName<DuplicateCheckRequest>,
    HasPhoneNumber<DuplicateCheckRequest>,
    HasSiteAlias<DuplicateCheckRequest> {

  protected String provider;    // social provider

  protected String providerUserId;    // social provider 측의 userId

  protected SiteType siteType;

  public DuplicateCheckRequest withProviderUserId(String providerUserId) {
    this.providerUserId = providerUserId;
    return this;
  }

  public DuplicateCheckRequest withProvider(String provider) {
    this.provider = provider;
    return this;
  }

  public DuplicateCheckRequest withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }

  public boolean isLoginNameCheck() {
    return StringUtils.isNotEmpty(getLoginName());
  }

  public boolean isSocialUserCheck() {
    return StringUtils.isNotEmpty(getProvider()) && StringUtils.isNotEmpty(getEmailAddress());
  }

  public boolean isPhoneNumberCheck() {
    return StringUtils.isNotEmpty(getPhoneNumber());
  }

  public boolean isEmailAddressCheck() {
    return StringUtils.isNotEmpty(getEmailAddress());
  }


}
