/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.AuthenticationRequest;
import io.rchemist.common.security.auth.data.DuplicateCheckRequest;
import io.rchemist.common.security.auth.data.LoginResult;
import io.rchemist.common.security.auth.data.PasswordCheckRequest;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.SecedeResult;
import io.rchemist.common.security.auth.data.SignOutRequest;
import io.rchemist.common.security.auth.data.SocialLoginRequest;
import io.rchemist.common.security.auth.data.SocialLoginResult;
import io.rchemist.common.security.auth.data.Token;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.auth.service.extension.TokenAuthenticationExtensionManager;
import io.rchemist.common.security.auth.service.type.SocialAccountActionType;
import io.rchemist.common.security.auth.token.JwtTokenProvider;
import io.rchemist.common.security.data.TenantSwitchRequest;
import io.rchemist.common.security.data.TokenData;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.request.WebRequestContext;
import javax.cache.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmGatewayTokenAuthenticationService")
@Slf4j
public class GatewayTokenAuthenticationServiceImpl implements GatewayTokenAuthenticationService{

  protected final JwtTokenProvider jwtTokenProvider;
  protected final GlobalAuthenticationProvider authenticationProvider;

  protected final TokenAuthenticationExtensionManager extensionManager;

  public static final String ACCESS_TOKEN_CACHE_STORE = "ACCESS_TOKEN_CACHE_STORE";

  public static final String REFRESH_TOKEN_CACHE_STORE = "REFRESH_TOKEN_CACHE_STORE";


  @Getter
  private final long tokenValidityInMilliseconds;
  @Getter
  private final long refreshTokenValidityInMilliseconds;


  protected final Cache<String, LoginResult> accessTokenCache;

  // key: refreshToken, value: accessToken
  protected final Cache<String, String> refreshTokenCache;

  protected final boolean useCache;

  public GatewayTokenAuthenticationServiceImpl(
      @Value("${platform.config.security.access-token.validity:86400000}") long tokenValidityInMilliseconds,
      @Value("${platform.config.security.refresh-token.validity:604800000}") long refreshTokenValidityInMilliseconds,
      @Value("${platform.config.security.token.cache:true}") boolean useCache,
      JwtTokenProvider jwtTokenProvider,
      GlobalAuthenticationProvider authenticationProvider,
      TokenAuthenticationExtensionManager extensionManager,
      @Autowired(required = false) CommonCacheManager cacheManager) {
    this.jwtTokenProvider = jwtTokenProvider;
    this.authenticationProvider = authenticationProvider;
    this.extensionManager = extensionManager;
    this.useCache = useCache;
    this.tokenValidityInMilliseconds = tokenValidityInMilliseconds;
    this.refreshTokenValidityInMilliseconds = refreshTokenValidityInMilliseconds;
    if (cacheManager != null && useCache) {
      this.accessTokenCache = cacheManager.getOrCreateCache(ACCESS_TOKEN_CACHE_STORE,
          NumberUtil.getInteger(tokenValidityInMilliseconds) / 1000
          , 1000000
          , LoginResult.class);
      this.refreshTokenCache = cacheManager.getOrCreateCache(REFRESH_TOKEN_CACHE_STORE,
          NumberUtil.getInteger(refreshTokenValidityInMilliseconds) / 1000
          , 1000000
          , String.class);
    }else {
      this.accessTokenCache = null;
      this.refreshTokenCache = null;
    }

  }

  /**
   * login 후 토큰을 발행하고 추가 사용자 정보를 반환
   * - loginName / password login
   * - social login 모두 지원
   * @param request
   * @return
   */
  @Override
  public LoginResult login(final AuthenticationRequest request) {
    PlatformAuthentication authentication = (PlatformAuthentication) authenticationProvider.authenticate(request.createAuthentication());
    return createLoginResult(authentication);
  }

  /**
   * authentication 을 LoginResult 로 변경
   * @param authentication
   * @return
   */
  @Override
  public LoginResult createLoginResult(final PlatformAuthentication authentication) {
    Token token = jwtTokenProvider.createToken(authentication);
    LoginResult loginResult = new LoginResult(token, authentication);

    if (accessTokenCache != null) {
      accessTokenCache.put(loginResult.getToken().getAccessToken(), loginResult);
    }
    return postCreateLoginResult(true, loginResult);
  }

  /**
   * 일반적인 소셜 로그인은 login 을 사용해도 무방하다.
   * 소셜로그인 할 때 로그인을 시도하는 소셜 계정의 이메일 주소를 함께 전송하는 경우에만 이 메소드를 사용한다.
   * 아직 소셜 등록은 하지 않았지만 해당 이메일 주소로 회원가입한 적이 있다면 계정을 연결하라는 시도를 할 때 사용한다.
   * @param request
   * @return
   */
  @Override
  public SocialLoginResult socialLogin(final SocialLoginRequest request) {
    try {
      LoginResult result = this.login(request);
      return new SocialLoginResult(result);
    } catch (Exception e) {

      if (isNotFoundUserSocialException(e)) {

        // social 계정으로 등록된 적이 없다.
        // social login 을 할 때 이메일 주소도 함께 보내 줬다면
        // 혹시 기존 회원가입한 이메일 계정이 있는지 확인한다.
        // 있다면 Front 쪽에 해당 회원으로 가입하라는 안내를 보내줘야 한다.
        if (StringUtils.isNotEmpty(request.getEmailAddress())) {
          SiteType siteType = EnumTypeUtil.getEnumType(SiteType.class, request.getSiteType(), SiteType.FRONT);

          DuplicateCheckRequest duplicateCheckRequest = new DuplicateCheckRequest()
              .withProvider(request.getProvider())
              .withProviderUserId(request.getProviderUserId())
              .withSiteType(siteType)
              .withEmailAddress(request.getEmailAddress());

          SocialAccountActionType actionType = authenticationProvider.checkRegisteredUserByEmailAddress(duplicateCheckRequest);

          if (actionType.equals(SocialAccountActionType.NOT_FOUND)) {
            // just throw error
          } else if (actionType.equals(SocialAccountActionType.REGISTERED)) {
            // 해당 정보로 가입 시켰다는 뜻이다.
            // 이 정보로 로그인을 다시 시도한다.
            return this.socialLogin(request);
          } else if (actionType.equals(SocialAccountActionType.DUPLICATED)) {
            // Exception을 내지 않고 정상적인 SocialLoginResult 를 리턴한다.
            // 단, Token 과 authentication 정보가 전혀 없기 때문에 Front 에서 반드시 적절한 처리를 해야 한다.
            return new SocialLoginResult().withRegisteredEmailAddress(request.getEmailAddress());
          }

        }

      }

      throw e;
    }
  }

  private static boolean isNotFoundUserSocialException(Exception e) {
    if (e instanceof PlatformSecurityException pse) {
      return pse.getErrorType() != null && pse.getErrorType()
          .equals(PlatformSecurityErrorType.NOT_FOUND_USER_SOCIAL);
    }

    if (e.getCause() != null && e.getCause() instanceof PlatformSecurityException pse) {
      return isNotFoundUserSocialException(pse);
    }

    return false;
  }


  /**
   * Token 갱신
   * @param refreshToken
   * @return
   * @throws PlatformSecurityException
   */
  @Override
  public LoginResult refreshToken(SiteType siteType, String refreshToken) {

    if (StringUtils.isEmpty(refreshToken))
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_REQUIRED);

    String accessToken = useCache && this.refreshTokenCache.containsKey(refreshToken) ? this.refreshTokenCache.get(refreshToken) : null;

    if (accessToken == null) {
      ExtensionResultHolder<String> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = extensionManager.getProxy().findAccessTokenByRefreshToken(siteType, refreshToken, resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
        accessToken = resultHolder.getResult();
      }
    }

    if (StringUtils.isEmpty(accessToken))
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_EXPIRED);


    LoginResult loginResult = getLoginResultByToken(new TokenData().withAccessToken(accessToken).withSiteType(siteType));

    if (loginResult == null) {
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_EXPIRED);
    }

    return postCreateLoginResult(true, loginResult);
  }

  protected LoginResult postCreateLoginResult(boolean initialized, LoginResult loginResult) {
    ExtensionResultHolder<LoginResult> resultHolder = new ExtensionResultHolder<>();
    resultHolder.withResult(loginResult);
    extensionManager.getProxy().postCreateLoginResult(initialized, resultHolder);
    return resultHolder.getResult();
  }


  /**
   * AccessToken 에 대한 유효성 검사
   * @param request
   * @return
   */
  @Override
  public LoginResult getLoginResultByToken(TokenData request) {

    if (request == null || request.isEmpty())
      throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_REQUIRED);

    String accessToken = request.getAccessToken();

    if (StringUtils.isNotEmpty(accessToken)) {
      LoginResult loginResult = getCachedLoginResultByAccessToken(request.getSiteType(), accessToken);

      if (loginResult != null) {
        return postCreateLoginResult(false, loginResult);
      }
    }

    String refreshToken = request.getRefreshToken();

    if (StringUtils.isNotEmpty(refreshToken)) {
      return refreshToken(request.getSiteType(), refreshToken);
    }

    throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_MISMATCH);
  }

  protected LoginResult refreshTokenIfNeeded(LoginResult loginResult) {
    if (loginResult != null) {
      if (loginResult.getToken().isRefreshNeeded()) {
        // refresh 필요
        Token token = jwtTokenProvider.createToken(loginResult.getPlatformAuthentication());
        loginResult.setToken(token);
        this.accessTokenCache.put(token.getAccessToken(), loginResult);
      }
    }
    return loginResult;
  }

  protected LoginResult getCachedLoginResultByAccessToken(SiteType siteType, String accessToken) {
    LoginResult loginResult = null;

    if (useCache && this.accessTokenCache.containsKey(accessToken)) {
      loginResult = this.accessTokenCache.get(accessToken);
    }

    if (loginResult == null) {

      ExtensionResultHolder<LoginResult> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = extensionManager.getProxy().findLoginResultByAccessToken(siteType,
          accessToken, resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
        loginResult = resultHolder.getResult();
      }
    }

    return refreshTokenIfNeeded(loginResult);
  }

  /**
   * Sign out
   * @param tokenData
   * @throws PlatformSecurityException
   */
  @Override
  public void signOut(final TokenData tokenData) {
    String userId = WebRequestContext.getCurrentUserId();

    if (!StringUtils.isEmpty(userId)) {
      if (useCache) {
        this.accessTokenCache.remove(tokenData.getAccessToken());
        this.refreshTokenCache.remove(tokenData.getRefreshToken());
      }

      SignOutRequest request = new SignOutRequest(tokenData).withUserId(userId);

      extensionManager.getProxy().postSignOut(request);
    }

    // throw new PlatformSecurityException(PlatformSecurityErrorType.ACCESS_DENIED);
    // do nothing
    // silent exception


  }

  /**
   * Tenant 를 변경한다.
   * 기존 세션은 삭제되고 새로운 세션이 생성된다.
   * 이 메소드를 사용하는 경우
   * 변경된 Tenant 에 대한 검증 로직은 반드시 jwtTokenProvider#createToken 의 extensionManager.getProxy().postCreateToken 에 구현해야 한다.
   * @param request
   * @return
   */
  @Override
  public LoginResult switchTenant(TenantSwitchRequest request) {

    request.validate();

    if (SecurityContextHolder.getContext().getAuthentication() != null && SecurityContextHolder.getContext().getAuthentication() instanceof PlatformAuthentication pa) {
      // tenant alias 에 대한 검증은 jwtTokenProvider#createToken 의 extensionManager.getProxy().postCreateToken 에서 처리한다.
      pa.setTenantAlias(request.getTenantAlias());
      return createLoginResult(pa);
    }

    throw new PlatformSecurityException(PlatformSecurityErrorType.ACCESS_DENIED);

  }

  @Override
  public SecedeResult secedeUser() throws ErrorTypeException {
    if (SecurityContextHolder.getContext().getAuthentication() != null && SecurityContextHolder.getContext().getAuthentication() instanceof PlatformAuthentication pa) {
      SecedeResult result = new SecedeResult()
          .withSiteType(pa.getSiteType())
          .withName(pa.getName())
          .withUserId(pa.getUserId())
          .withLoginName(pa.getLoginName());

      ExtensionResultHolder<SecedeResult> resultHolder = new ExtensionResultHolder<SecedeResult>().withResult(result);
      ExtensionResultStatusType status = extensionManager.getProxy().processSecedeUser(resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
        result = resultHolder.getResult();
      }

      // 토큰 제거
      try {
        signOut(new TokenData().withAccessToken(pa.getAccessToken()).withRefreshToken(pa.getRefreshToken()));
      }catch (Exception e) {
        // nothing to do
        log.warn("Failed to remove tokens after secede user. {}", result);
      }

      return result;

    }
    throw new PlatformSecurityException(PlatformSecurityErrorType.ACCESS_DENIED);
  }

  @Override
  public Boolean checkPassword(PasswordCheckRequest request) throws ErrorTypeException {
    // 로그인한 사용자만 대상으로 체크해야 한다. 아무나 userId 만 가지고 api 를 호출해서는 안 된다.
    if (SecurityContextHolder.getContext().getAuthentication() != null && SecurityContextHolder.getContext().getAuthentication() instanceof PlatformAuthentication pa) {

      // request 에 대한 기본 검증
      request.validate(pa.getUserId());

      ExtensionResultHolder<Boolean> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = extensionManager.getProxy().checkPassword(request, resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
        return resultHolder.getResult();
      }
    }

    return false;
  }

}