/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AuthorityHelper {

  public static List<String> getRoles(Collection<? extends GrantedAuthority> authorities){
    if(CollectionUtils.isEmpty(authorities)){
      return new ArrayList<>();
    }else{
      return authorities.stream().map(GrantedAuthority::getAuthority).collect(
        Collectors.toList());
    }
  }

  public static Collection<GrantedAuthority> getAuthorities(List<String> roles){
    if(CollectionUtils.isNotEmpty(roles)){
      return roles.stream().map(SimpleGrantedAuthority::new)
          .collect(Collectors.toList());
    }
    return Collections.emptyList();
  }

}
