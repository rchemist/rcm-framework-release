/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.token;

import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class JwtTokenHelper {

  public static final String AUTHORIZATION_HEADER = "Authorization";

  public static final String REFRESH_TOKEN = "refreshToken";

  public static final String SITE_TYPE_HEADER = "siteType";

  public static String resolveAccessToken(HttpServletRequest request) {
    String bearerToken = request.getHeader(AUTHORIZATION_HEADER);
    if (StringUtils.isNotEmpty(bearerToken) && bearerToken.startsWith("Bearer ")) {
      return bearerToken.substring(7);
    }
    return null;
  }

  public static String resolveRefreshToken(HttpServletRequest request) {
    return request.getHeader(REFRESH_TOKEN);
  }

  public static SiteType resolveSiteType(HttpServletRequest request) {
    return EnumTypeUtil.getEnumType(SiteType.class, request.getHeader(SITE_TYPE_HEADER), SiteType.FRONT);
  }

}
