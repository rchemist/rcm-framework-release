/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.security.auth.data.AuthenticationRequest;
import io.rchemist.common.security.auth.data.LoginResult;
import io.rchemist.common.security.auth.data.PasswordCheckRequest;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.SecedeResult;
import io.rchemist.common.security.auth.data.SocialLoginRequest;
import io.rchemist.common.security.auth.data.SocialLoginResult;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.data.TenantSwitchRequest;
import io.rchemist.common.security.data.TokenData;
import io.rchemist.common.util.type.SiteType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface GatewayTokenAuthenticationService {

  /**
   * login 후 토큰을 발행하고 추가 사용자 정보를 반환
   * - loginName / password login
   * - social login 모두 지원
   * @param request
   * @return
   */
  LoginResult login(AuthenticationRequest request);

  /**
   * authentication 을 LoginResult 로 변경
   * @param authentication
   * @return
   */
  LoginResult createLoginResult(PlatformAuthentication authentication);

  /**
   * 일반적인 소셜 로그인은 login 을 사용해도 무방하다.
   * 소셜로그인 할 때 로그인을 시도하는 소셜 계정의 이메일 주소를 함께 전송하는 경우에만 이 메소드를 사용한다.
   * 아직 소셜 등록은 하지 않았지만 해당 이메일 주소로 회원가입한 적이 있다면 계정을 연결하라는 시도를 할 때 사용한다.
   * @param request
   * @return
   */
  SocialLoginResult socialLogin(SocialLoginRequest request);

  /**
   * Token 갱신
   * @param siteType
   * @param refreshToken
   * @return
   * @throws PlatformSecurityException
   */
  LoginResult refreshToken(SiteType siteType, String refreshToken);

  /**
   * AccessToken 에 대한 유효성 검사
   * @param request
   * @return
   */
  LoginResult getLoginResultByToken(TokenData request);

  /**
   * Sign out
   * @param tokenData
   * @throws PlatformSecurityException
   */
  void signOut(TokenData tokenData);

  /**
   * Tenant 를 변경한다.
   * 기존 세션은 삭제되고 새로운 세션이 생성된다.
   * 이 메소드를 사용하는 경우
   * 변경된 Tenant 에 대한 검증 로직은 반드시 jwtTokenProvider#createToken 의 extensionManager.getProxy().postCreateToken 에 구현해야 한다.
   * @param request
   * @return
   */
  LoginResult switchTenant(TenantSwitchRequest request);

  SecedeResult secedeUser() throws ErrorTypeException;

  /**
   * 화면 잠금해제와 같이 이미 로그인된 회원의 비밀번호가 맞는지만 확인하면 되는 경우 이 메소드를 호출한다.
   * @param request
   * @return
   * @throws ErrorTypeException
   */
  Boolean checkPassword(PasswordCheckRequest request) throws ErrorTypeException;
}
