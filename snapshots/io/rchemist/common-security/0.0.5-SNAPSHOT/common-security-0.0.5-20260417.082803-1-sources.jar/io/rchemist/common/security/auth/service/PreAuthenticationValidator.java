/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service;

import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.security.auth.data.AuthenticationResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsChecker;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class PreAuthenticationValidator implements UserDetailsChecker{

  protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();

  @Override
  public void check(UserDetails user) {
    if (!user.isAccountNonLocked()) {
      throw new LockedException(translate("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"));
    } else if (!user.isEnabled()) {
      throw new DisabledException(translate("AbstractUserDetailsAuthenticationProvider.disabled", "User is disabled"));
    } else if (!user.isAccountNonExpired()) {
      throw new AccountExpiredException(translate("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"));
    } else {
      if( user instanceof AuthenticationResponse){

        AuthenticationResponse response = (AuthenticationResponse) user;

        if(response.isHidden()){
          throw new AccountExpiredException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.hidden", "User account has expired"));
        }

      }
    }
  }

  /**
   * messages.getMessage 에서 PlatformResourceBundleMessageSource 의 resolveCodeWithoutArguments 를 타지 않아 MessageSourceHelper 를 사용
   * @param message
   * @param defaultMessage
   * @return
   */
  private String translate(String message, String defaultMessage){
    message = StringUtils.defaultIfBlank(message, defaultMessage);
    return (message == null) ? "" : MessageSourceHelper.getMessage(message);
  }

}