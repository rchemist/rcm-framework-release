/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.util.LocalDateTimeUtil;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
public class Token implements Serializable {

  @Serial
  private static final long serialVersionUID = 1L;

  private String grantType;
  private String accessToken;
  private String refreshToken;
  private long accessTokenExpirationTime;
  private long refreshTokenExpirationTime;

  public boolean isRefreshNeeded(){
    Date date = new Date(accessTokenExpirationTime);
    LocalDateTime dateTime = LocalDateTimeUtil.asLocalDateTime(date);
    // 최대 만료 10분전부터 갱신한다.
    return dateTime.isBefore(LocalDateTime.now().plusMinutes(10l));
  }

  public Token withGrantType(String grantType) {
    this.grantType = grantType;
    return this;
  }

  public Token withAccessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

  public Token withRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

  public Token withAccessTokenExpirationTime(long accessTokenExpirationTime) {
    this.accessTokenExpirationTime = accessTokenExpirationTime;
    return this;
  }

  public Token withRefreshTokenExpirationTime(long refreshTokenExpirationTime) {
    this.refreshTokenExpirationTime = refreshTokenExpirationTime;
    return this;
  }

}
