/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.service.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class SocialAccountActionType extends EnumType<SocialAccountActionType> {

  public static final SocialAccountActionType REGISTERED = new SocialAccountActionType("REGISTERED", "등록 처리 완료");
  public static final SocialAccountActionType DUPLICATED = new SocialAccountActionType("DUPLICATED", "중복된 데이터가 존재함");
  public static final SocialAccountActionType NOT_FOUND = new SocialAccountActionType("NOT_FOUND", "중복된 데이터가 없음");
  public static final SocialAccountActionType ERRORED = new SocialAccountActionType("ERRORED", "추가 등록 처리를 할 수 없음");

  public SocialAccountActionType(String type, String friendlyType) {
    super(type, friendlyType);
  }
}
