/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SecuredApiDTO implements Serializable {

  private String module;      // 모듈명
  private String name;      // 퍼미션 이름
  private String permissionCode;    // 퍼미션 코드 - 시스템에서 식별하기 위함 ControllerFullName#methodName(파라미터)
  private String[] apiUrls;     // 샘플 API 목록
  private boolean securePermission;   // Permission Check Interceptor 에서 퍼미션 체크를 해야 하는지 여부

  public boolean validate(){
    return (StringUtils.isNotEmpty(module)
      && StringUtils.isNotEmpty(name)
      && StringUtils.isNotEmpty(permissionCode)
        && ArrayUtils.isNotEmpty(apiUrls)
    );
  }

}
