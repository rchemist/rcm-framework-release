/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.presentation.HasPassword;
import io.rchemist.common.persistence.domain.template.presentation.HasUserUUId;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.util.type.SiteType;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class PasswordCheckRequest implements HasUserUUId<PasswordCheckRequest>, HasPassword<PasswordCheckRequest> {

  protected SiteType siteType;

  public PasswordCheckRequest withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }

  public void validate(String sessionUserId) throws ErrorTypeException {
    if (StringUtils.isEmpty(getPassword())) {
      throw new PlatformSecurityException(PlatformSecurityErrorType.PASSWORD_REQUIRED);
    }
    if (StringUtils.isEmpty(getUserId()) || !StringUtils.equals(sessionUserId, getUserId())) {
      throw new PlatformSecurityException(PlatformSecurityErrorType.NOW_OWNED_DATA);
    }
  }

}
