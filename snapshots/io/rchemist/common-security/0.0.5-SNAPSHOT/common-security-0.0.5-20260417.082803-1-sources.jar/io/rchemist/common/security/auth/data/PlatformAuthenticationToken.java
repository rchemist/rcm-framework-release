/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.security.auth.service.AuthorityHelper;
import io.rchemist.common.security.service.type.AuthRequestType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * <p>
 *   SpringSecurity 로 로그인 요청을 할 때 사용한다.
 *   이 요청에 의한 결과는 PlatformAuthentication 을 만들어 SecurityContextHolder 에 저장된다.
 * </p>
 * Created by kunner
 **/
public class PlatformAuthenticationToken extends AbstractAuthenticationToken {

  /**
   * UserNamePassword 일 때는 Username 이 들어가고, SocialLoginProvider 일 때는 provider 값이 들어간다.
   */
  @Getter
  protected final Object principal;

  @Getter
  protected final Object credentials;

  @Getter
  protected final SiteType siteType;

  @Getter
  protected final String userId;

  @Getter
  protected final String tenantAlias;

  @Getter
  protected final String siteAlias;

  @Getter
  protected final AuthRequestType authRequestType;

  @Getter
  protected Boolean rememberMe;

  @JsonIgnore
  protected List<String> roles;

  // 로그인 처리 중 확장 데이터를 전달할 필요가 있을 때 이 값을 사용한다.
  @JsonIgnore
  @Getter
  @Setter
  protected Map<String, Object> attributes = new HashMap<>();

  public PlatformAuthenticationToken(
    AuthRequestType authRequestType, Object principal, Object credentials, SiteType siteType, String userId, String tenantAlias,
    String siteAlias,
    Collection<? extends GrantedAuthority> authorities) {
    super(authorities);
    this.principal = principal;
    this.credentials = credentials;
    this.siteType = siteType;
    this.userId = userId;
    this.tenantAlias = tenantAlias;
    this.siteAlias = siteAlias;
    this.authRequestType = authRequestType;
  }

  public boolean isUsernamePasswordRequest(){
    return EnumTypeUtil.equals(authRequestType, AuthRequestType.USERNAME_PASSWORD);
  }

  public boolean isAdminRequest(){
    return EnumTypeUtil.equals(siteType, SiteType.ADMIN);
  }

  public List<String> getRoles(){
    if (this.roles == null) {
      this.roles = AuthorityHelper.getRoles(this.getAuthorities());
    }
    return this.roles;
  }

  public PlatformAuthenticationToken withAttributes(
      Map<String, Object> attributes) {
    this.attributes = attributes;
    return this;
  }

  public boolean hasAttribute(String key) {
    return attributes.containsKey(key);
  }

  public Object getAttribute(String key) {
    return attributes.get(key);
  }

  public PlatformAuthenticationToken putAttribute(String key, Object value) {
    attributes.put(key, value);
    return this;
  }

  public PlatformAuthenticationToken removeAttribute(String key) {
    attributes.remove(key);
    return this;
  }

  public PlatformAuthenticationToken withRememberMe(Boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

  public Boolean isRememberMe() {
    return BooleanUtils.toBoolean(getRememberMe());
  }
}
