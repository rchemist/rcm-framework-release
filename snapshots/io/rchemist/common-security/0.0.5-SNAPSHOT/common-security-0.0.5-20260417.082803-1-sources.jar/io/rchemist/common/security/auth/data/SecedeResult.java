/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.persistence.domain.template.presentation.HasLoginName;
import io.rchemist.common.persistence.domain.template.presentation.HasName;
import io.rchemist.common.persistence.domain.template.presentation.HasPhoneNumber;
import io.rchemist.common.persistence.domain.template.presentation.HasSucceed;
import io.rchemist.common.persistence.domain.template.presentation.HasUserUUId;
import io.rchemist.common.util.type.SiteType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@NoArgsConstructor
public class SecedeResult implements HasName<SecedeResult>
    , HasLoginName<SecedeResult>
    , HasUserUUId<SecedeResult>
    , HasPhoneNumber<SecedeResult>
    , HasSucceed<SecedeResult>
    , HasAttributes<SecedeResult>
{

  protected SiteType siteType;

  public SecedeResult withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }
}
