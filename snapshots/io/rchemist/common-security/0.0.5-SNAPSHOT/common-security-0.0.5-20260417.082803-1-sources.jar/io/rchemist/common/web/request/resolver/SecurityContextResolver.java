/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.resolver;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import io.rchemist.common.persistence.multitenant.TenantInformationProvider;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.PlatformAuthenticationToken;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.util.CookieUtil;
import io.rchemist.common.util.RandomUtil;
import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.resolver.extension.SecurityContextExtensionManager;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * 비회원의 경우에도 항상 동일한 sessionId 를 가질 수 있도록 한다
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmSecurityContextResolver")
public class SecurityContextResolver implements RequestAttributeResolver<SimpleAuthentication> {

  protected static TenantInformationProvider tenantInformationProvider;

  private static final String SECURITY_ATTR_NAME = "rcmSecurityContext";
  private static final String ANONYMOUS_COOKIE_NAME = "ANONYMOUS_COOKIE";

  protected final SecurityContextExtensionManager extensionManager;

  public SecurityContextResolver(SecurityContextExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Override
  public boolean canHandle(Class<SimpleAuthentication> clazz) {
    return clazz.equals(SimpleAuthentication.class);
  }

  @Override
  public void resolve(WebRequestContext context) {
    SimpleAuthentication authentication = parseSimpleAuthentication();

    if (authentication == null || authentication.isAnonymous())
      return;

    /*// validate authentication
    String tenantAlias = context.getTenantAlias();
    String siteAlias = context.getSiteAlias();

    if(!authentication.validateTenant(tenantAlias, siteAlias))
      throw new TenantServiceRuntimeException(TenantServiceErrorType.TENANT_NOT_MATCH);*/

    context.setAuthentication(authentication);
  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, SECURITY_ATTR_NAME);
  }

  protected SimpleAuthentication parseSimpleAuthentication() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication == null)
      return null;

    ExtensionResultHolder<SimpleAuthentication> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().translateAuthentication(authentication, resultHolder);

    if (status.equals(ExtensionResultStatusType.NOT_HANDLED)) {
      if(authentication instanceof PlatformAuthenticationToken pat){
        return new SimpleAuthentication(false, pat.getName(), pat.getSiteType(), pat.getUserId(), pat.getName(), pat.getTenantAlias(),
            pat.getSiteAlias(), pat.getRoles());
      } else if (authentication instanceof PlatformAuthentication pa) {
        return new SimpleAuthentication(false, pa.getName(), pa.getSiteType(), pa.getUserId(), pa.getName(), pa.getTenantAlias(),
            pa.getSiteAlias(), pa.getRoles());
      }else{
        if(authentication instanceof AnonymousAuthenticationToken){
          return getAnonymousSimpleAuthentication(authentication);
        }
        return new SimpleAuthentication(true, authentication.getName(), null, null, authentication.getName(), null, null, new ArrayList<>());
      }
    }

    return resultHolder.getResult();

  }

  private static SimpleAuthentication getAnonymousSimpleAuthentication(Authentication authentication) {
    // 로그인하지 않은 비회원의 경우 쿠키 정보를 확인한다.
    String sessionId = null;
    HttpServletRequest request = RequestUtil.getHttpServletRequest();
    if(request != null){
      String anonymousCookie = CookieUtil.getCookieValue(request, ANONYMOUS_COOKIE_NAME, false);

      if(StringUtils.isNotEmpty(anonymousCookie)){
        // 이미 비회원 쿠키를 가지고 있다.
        sessionId = anonymousCookie;
      }else{
        // 처음 들어온 경우
        HttpServletResponse response = RequestUtil.getHttpServletResponse();

        if(response != null){
          if(RequestContextHolder.getRequestAttributes() == null){
            try {
              sessionId = RandomUtil.generateRandomId(30);
            } catch (NoSuchAlgorithmException e) {
              e.printStackTrace();
            }
          }else{
            sessionId = RequestContextHolder.getRequestAttributes().getSessionId();
          }

          if(sessionId != null){
            CookieUtil.addCookie(response, CookieUtil.DEFAULT_PATH, ANONYMOUS_COOKIE_NAME, sessionId, CookieUtil.SHORT_EXPIRY, false, true, false);
          }

        }
      }
    }

    if(sessionId == null){
      try {
        sessionId = RandomUtil.generateRandomId(30);
      } catch (NoSuchAlgorithmException e) {
        sessionId = authentication.getName() + LocalDateTime.now().getChronology().hashCode();
      }
    }

    TenantInformation information = getTenantInformationProvider().getTenantInformation();

    return new SimpleAuthentication(true, sessionId, SiteType.FRONT, null, "anonymous", information.getTenantAlias(), information.getSiteAlias(), new ArrayList<>());
  }


  private static TenantInformationProvider getTenantInformationProvider(){
    if(tenantInformationProvider == null){
      tenantInformationProvider = ApplicationContextHolder.getBean("rcmTenantInformationProvider", TenantInformationProvider.class);
    }
    return tenantInformationProvider;
  }


  @Override
  public int getOrder() {
    return ResolverOrder.SECURITY_CONTEXT_RESOLVER;
  }
}
