/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.filter;

import io.rchemist.common.security.configuration.SecurityConfigProperty;
import io.rchemist.common.security.data.XssFilterRequest;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 *
 * Front 의 SpringSecurity 에서 필요할 때 filter 로 등록해 사용한다.
 *
 * @Bean
 * public FilterRegistrationBean antiSamyFilterRegistration(){
 *    XssFilter xssFilter = new XssFilter();
 *    FilterRegistrationBean bean = new FilteRegistrationBean();
 *    bean.setFilter(xssFilter);
 *    bean.setName("antisamyFilter");
 *    return bean;
 * }
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class XssFilter implements Filter {

  protected List<String> excludedRequestPatterns;

  protected Boolean xssProtectionEnabled;

  @Override
  public void doFilter(ServletRequest request, ServletResponse response,
      FilterChain filterChain) throws IOException, ServletException {
    if (request instanceof HttpServletRequest) {
      if(shouldFilter((HttpServletRequest) request)){
        filterChain.doFilter(new XssFilterRequest((HttpServletRequest) request), response);
      }else{
        filterChain.doFilter(request, response);
      }
    } else {
      filterChain.doFilter(request, response);
    }
  }

  @Override
  public void init(final FilterConfig filterConfig) throws ServletException {
    // do nothing
  }

  @Override
  public void destroy() {
    // do nothing
  }

  public XssFilter setExcludedRequestPatterns(List<String> excludedRequestPatterns) {
    this.excludedRequestPatterns = excludedRequestPatterns;
    return this;
  }

  protected boolean shouldFilter(HttpServletRequest request){
    if(!getXssProtectionEnabled())
      return false;

    if (excludedRequestPatterns != null && excludedRequestPatterns.size() > 0) {
      for (String pattern : excludedRequestPatterns) {
        RequestMatcher matcher = new AntPathRequestMatcher(pattern);
        if (matcher.matches(request)) {
          return false;
        }
      }
    }
    return true;
  }

  public Boolean getXssProtectionEnabled() {
    if(xssProtectionEnabled == null){
      xssProtectionEnabled = SecurityConfigProperty.getProperties().isXssProtection();
    }

    return xssProtectionEnabled;
  }
}
