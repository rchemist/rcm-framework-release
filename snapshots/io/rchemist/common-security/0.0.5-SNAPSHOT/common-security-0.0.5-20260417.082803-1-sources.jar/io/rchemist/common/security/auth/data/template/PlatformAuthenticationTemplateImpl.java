/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.type.SiteType;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(PlatformAuthenticationTemplate.class)
@Getter
@Setter
public class PlatformAuthenticationTemplateImpl implements EnhancedTemplate {

  protected String loginName;   // 로그인 아이디, 만약 아이디 로그인 없이 Social 로그인만 허용하는 경우에는 Social 로그인한 이메일 주소가 들어간다.

  protected String emailAddress;

  protected String phoneNumber;

  protected String name;    // 이름

  protected SiteType siteType;    // FRONT or ADMIN

  protected String tenantAlias;

  protected String siteAlias;

  protected String userId;

  protected String userType;

  protected List<String> roles;

  protected Boolean rememberMe;

  protected Object principal;

  @JsonIgnore
  // 내부 로직에서만 사용하는 accessToken, GlobalSecurityCheckFilter 에서 감지한 accessToken 을 넣어 준다.
  protected String accessToken;

  @JsonIgnore
  // 내부 로직에서만 사용하는 refreshToken, GlobalSecurityCheckFilter 에서 감지한 refreshToken 을 넣어 준다.
  protected String refreshToken;

  protected Boolean tokenRefreshed;

  // 서비스 프로세스 상 추가로 넣어야 하는 값이 있다면 이 값을 사용한다.
  @JsonIgnore
  // 내부 로직에서만 사용하는 attributes
  protected Map<String, Object> attributes;


}
