/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.util.type.SiteType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface PlatformAuthenticationTemplate<T> extends ClassTransformTarget {

  default String getLoginName() {
    return null;
  }

  default void setLoginName(String loginName) {
  }

  default String getName() {
    return null;
  }

  default void setName(String name) {
  }

  default String getEmailAddress() {
    return null;
  }

  default void setEmailAddress(String emailAddress) {

  }

  default String getPhoneNumber() {
    return null;
  }

  default void setPhoneNumber(String phoneNumber) {

  }

  default SiteType getSiteType() {
    return null;
  }

  default void setSiteType(SiteType siteType) {
  }

  default String getTenantAlias() {
    return null;
  }

  default void setTenantAlias(String tenantAlias) {
  }

  default String getSiteAlias() {
    return null;
  }

  default void setSiteAlias(String siteAlias) {
  }

  default String getUserId() {
    return null;
  }

  default void setUserId(String userId) {
  }

  default List<String> getRoles() {
    return null;
  }

  default void setRoles(List<String> roles) {
  }

  default Boolean getRememberMe() {
    return null;
  }

  default void setRememberMe(Boolean rememberMe) {
  }

  default Object getPrincipal() {
    return null;
  }

  default void setPrincipal(Object principal) {
  }

  default String getAccessToken() {
    return null;
  }

  default void setAccessToken(String accessToken) {
  }

  default String getRefreshToken() {
    return null;
  }

  default void setRefreshToken(String refreshToken) {
  }

  default Boolean getTokenRefreshed() {
    return null;
  }

  default void setTokenRefreshed(Boolean tokenRefreshed) {
  }


  default T withLoginName(String loginName) {
    setLoginName(loginName);
    return (T) this;
  }

  default T withName(String name) {
    setName(name);
    return (T) this;
  }

  default T withSiteType(
      SiteType siteType) {
    setSiteType(siteType);
    return (T) this;
  }

  default T withTenantAlias(String tenantAlias) {
    setTenantAlias(tenantAlias);
    return (T) this;
  }

  default T withSiteAlias(String siteAlias) {
    setSiteAlias(siteAlias);
    return (T) this;
  }

  default T withUserId(String userId) {
    setUserId(userId);
    return (T) this;
  }

  default T withEmailAddress(String emailAddress) {
    setEmailAddress(emailAddress);
    return (T) this;
  }

  default T withPhoneNumber(String phoneNumber) {
    setPhoneNumber(phoneNumber);
    return (T) this;
  }

  default boolean hasRole(String role) {
    if (CollectionUtils.isNotEmpty(getRoles())) {
      return getRoles().contains(role);
    }
    return false;
  }

  default T withRoles(List<String> roles) {
    setRoles(roles);
    return (T) this;
  }

  default T withRememberMe(Boolean rememberMe) {
    setRememberMe(rememberMe);
    return (T) this;
  }

  default T withPrincipal(Object principal) {
    setPrincipal(principal);
    return (T) this;
  }

  default T withAccessToken(String accessToken) {
    setAccessToken(accessToken);
    return (T) this;
  }

  default T withRefreshToken(String refreshToken) {
    setRefreshToken(refreshToken);
    return (T) this;
  }

  default boolean isRememberMe(){
    return BooleanUtils.toBoolean(getRememberMe());
  }

  default boolean isTokenRefreshed(){
    return BooleanUtils.toBoolean(getTokenRefreshed());
  }

  @JsonIgnore
  default SimpleAuthentication getSimpleAuthentication(){
    return new SimpleAuthentication(false, getLoginName(), getSiteType(), getUserId(), getName(), getTenantAlias(), getSiteAlias(), getRoles());
  }

  default Map<String, Object> getAttributes() {
    throw new ClassTransformException();
  }

  default void setAttributes(Map<String, Object> attributes) {
    throw new ClassTransformException();
  }

  default T withAttributes(Map<String, Object> attributes) {
    setAttributes(attributes);
    return (T) this;
  }

  default T putAttribute(String key, Object value) {
    if (getAttributes() == null) {
      setAttributes(new HashMap<>());
    }
    getAttributes().put(key, value);
    return (T) this;
  }

  default <S> S getAttribute(String key) {
    if (getAttributes() == null || !getAttributes().containsKey(key)) {
      return null;
    }
    return (S) getAttributes().get(key);
  }

  default T removeAttribute(String key) {
    if (getAttributes() != null) {
      getAttributes().remove(key);
    }
    return (T) this;
  }

  default boolean hasAttribute(String key) {
    return getAttributes() != null && getAttributes().containsKey(key);
  }

  default String getUserType() {
    throw new ClassTransformException();
  }

  default void setUserType(String userType) {
    throw new ClassTransformException();
  }

  default T withUserType(String userType) {
    setUserType(userType);
    return (T) this;
  }
}
