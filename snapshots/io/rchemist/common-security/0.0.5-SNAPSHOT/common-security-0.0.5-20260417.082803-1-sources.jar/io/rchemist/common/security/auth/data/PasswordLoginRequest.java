/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.service.type.AuthRequestType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class PasswordLoginRequest extends AuthenticationRequest {

  @NotNull
  @Size(min = 3, max = 50)
  private String loginName;

  @NotNull
  @Size(min = 8, max = 100)
  private String password;

  public String getLoginName() {
    return StringUtils.lowerCase(loginName);
  }

  public void setLoginName(String loginName) {
    this.loginName = StringUtils.lowerCase(loginName);
  }

  @Override
  public void validate() throws PlatformSecurityException {
    if (StringUtils.isEmpty(loginName)) {
      throw new PlatformSecurityException("loginName", PlatformSecurityErrorType.INVALID_USERNAME_REQUEST);
    }
    if (StringUtils.isEmpty(password)) {
      throw new PlatformSecurityException("password", PlatformSecurityErrorType.INVALID_USERNAME_REQUEST);
    }
  }

  @Override
  public Object getPrincipal() {
    return loginName;
  }

  @Override
  public Object getCredentials() {
    return password;
  }

  @Override
  public AuthRequestType getAuthRequestType() {
    return AuthRequestType.USERNAME_PASSWORD;
  }

  public PasswordLoginRequest withLoginName(String loginName) {
    this.setLoginName(loginName);
    return this;
  }

  public PasswordLoginRequest withPassword(String password) {
    this.password = password;
    return this;
  }

  public PasswordLoginRequest withSiteAlias(String siteAlias) {
    this.siteAlias = siteAlias;
    return this;
  }

  public PasswordLoginRequest withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public PasswordLoginRequest withSiteType(String siteType) {
    this.siteType = siteType;
    return this;
  }

  public PasswordLoginRequest withRememberMe(Boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

}

