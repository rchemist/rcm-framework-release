/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class UserAuthenticationErrorType extends EnumType<UserAuthenticationErrorType> implements ErrorType {

  public static final UserAuthenticationErrorType INVALID_NAME = new UserAuthenticationErrorType("INVALID_NAME", "Invalid name.", "이름을 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType INVALID_SITE_ALIAS = new UserAuthenticationErrorType("INVALID_SITE_ALIAS", "Invalid site alias.", "사이트 이름을 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType INVALID_LOGIN_NAME = new UserAuthenticationErrorType("INVALID_LOGIN_NAME", "Invalid loginName.", "아이디를 3자 이상 영문/숫자로 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType INVALID_EMAILADDRESS = new UserAuthenticationErrorType("INVALID_EMAILADDRESS", "Invalid emailaddress.", "이메일 주소를 확인해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType DUPLICATED_LOGIN_NAME = new UserAuthenticationErrorType("DUPLICATED_LOGIN_NAME", "LoginName is duplicated.", "이미 존재하는 아이디 입니다. 다른 아이디를 사용해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType DUPLICATED_PERSONAL_CODE = new UserAuthenticationErrorType("DUPLICATED_PERSONAL_CODE", "Personal code is duplicated.", "인증 키 값이 이미 존재합니다. 회원 찾기를 통해 로그인해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType INVALID_PASSWORD = new UserAuthenticationErrorType("INVALID_PASSWORD", "Password pattern is invalid",
      "올바른 비밀번호가 아니거나 형식에 맞지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType DUPLICATED_EMAILADDRESS = new UserAuthenticationErrorType("DUPLICATED_EMAILADDRESS", "Emailaddress is duplicated",
      "이미 등록된 이메일 주소 입니다.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType INVALID_PHONENUMBER = new UserAuthenticationErrorType("INVALID_PHONENUMBER", "Phone number is not valid",
      "전화번호를 다시 확인하고 숫자만 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType DUPLICATED_SECEDED_LOGIN_NAME = new UserAuthenticationErrorType("DUPLICATED_SECEDED_LOGIN_NAME", "LoginName is duplicated(seceded).", "탈퇴한 아이디로 재가입할 수 없습니다. 다른 아이디를 사용해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserAuthenticationErrorType DUPLICATED_SECEDED_PERSONAL_CODE = new UserAuthenticationErrorType("DUPLICATED_SECEDED_PERSONAL_CODE", "PersonalCode is duplicated(seceded).", "탈퇴 후 재가입 제한 기간이 만료되지 않아 가입할 수 없습니다.", HttpStatus.BAD_REQUEST);

  public UserAuthenticationErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  @Getter
  protected final int status;

}
