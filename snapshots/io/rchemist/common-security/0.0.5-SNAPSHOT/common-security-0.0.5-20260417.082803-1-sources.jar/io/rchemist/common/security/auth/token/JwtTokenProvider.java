/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.token;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.security.auth.data.Token;
import io.rchemist.common.security.auth.service.extension.TokenAuthenticationExtensionManager;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.TSIDUtil;
import java.security.Key;
import java.util.Date;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmJwtTokenProvider")
@Slf4j
public class JwtTokenProvider implements InitializingBean {

  public static final String GRANT_TYPE = "Bearer";

  @Getter
  private final String secret;

  private static final long REMEMBER_ME_EXPIRE_TIME = 365 * 24 * 60 * 60 * 1000L;    // 365일

  @Getter
  private final long tokenValidityInMilliseconds;
  @Getter
  private final long refreshTokenValidityInMilliseconds;

  @Getter
  private Key key;

  private final TokenAuthenticationExtensionManager extensionManager;

  public JwtTokenProvider(
      @Value("${platform.config.security.token.secret:QU0tbzBqYGIraiM=Qy5WW303ajZyJmlPZ2lzSUM2NDppS31pSFwqXGBEcCpkU3o=aU04dkIxW1slKV5cb0hmUms=UlV7QHpY}") String tokenSecret,
      @Value("${platform.config.security.access-token.validity:86400000}") long tokenValidityInMilliseconds,
      @Value("${platform.config.security.refresh-token.validity:604800000}") long refreshTokenValidityInMilliseconds,
      TokenAuthenticationExtensionManager extensionManager) {
    this.secret = tokenSecret;
    this.tokenValidityInMilliseconds = tokenValidityInMilliseconds;
    this.refreshTokenValidityInMilliseconds = refreshTokenValidityInMilliseconds;
    this.extensionManager = extensionManager;
  }

  @Override
  public void afterPropertiesSet() throws Exception {
    byte[] bytes = Decoders.BASE64.decode(secret);
    this.key = Keys.hmacShaKeyFor(bytes);
  }

  public Token createToken(PlatformAuthentication authentication) {
    Token token = null;

    // 토큰 정보 확장
    ExtensionResultHolder<Token> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy()
        .createToken(authentication, resultHolder);

    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.getResult() != null) {
      token = resultHolder.getResult();
    }

    if (token == null) {
      token = createDefaultToken(authentication);
    }

    // 토큰 정보 확장
    resultHolder = new ExtensionResultHolder<Token>().withResult(token);
    status = extensionManager.getProxy().modifyCreatedToken(authentication, resultHolder);

    if (!status.equals(ExtensionResultStatusType.HANDLED)) {
      token = resultHolder.getResult();
    }

    return token;
  }

  private Token createDefaultToken(PlatformAuthentication authentication) {
    Token token;

    // accessToken 과 refreshToken 을 동일하게 최소한의 User 정보만 가지도록 설정한다.
    long now = (new Date()).getTime();
    Date accessTokenExpiresIn =
        authentication.isRememberMe() ? new Date(now + REMEMBER_ME_EXPIRE_TIME)
            : new Date(now + this.tokenValidityInMilliseconds);
    Date refreshTokenExpiredIn =
        authentication.isRememberMe() ? new Date(now + REMEMBER_ME_EXPIRE_TIME)
            : new Date(now + this.refreshTokenValidityInMilliseconds);

    String accessToken = Jwts.builder()
        .setSubject(
            StringUtil.toString(authentication.getLoginName(), authentication.getName()))
        .signWith(key, SignatureAlgorithm.HS512)
        .setExpiration(accessTokenExpiresIn)
        .compact();

    // refresh Token 은 그냥 유니크한 key 를 하나 가져가는 것으로 하자.
    String refreshToken = TSIDUtil.tsId();

    token = Token.builder()
        .grantType(GRANT_TYPE)
        .accessToken(accessToken)
        .refreshToken(refreshToken)
        .accessTokenExpirationTime(accessTokenExpiresIn.getTime())
        .refreshTokenExpirationTime(refreshTokenExpiredIn.getTime())
        .build();

    return token;
  }

}
