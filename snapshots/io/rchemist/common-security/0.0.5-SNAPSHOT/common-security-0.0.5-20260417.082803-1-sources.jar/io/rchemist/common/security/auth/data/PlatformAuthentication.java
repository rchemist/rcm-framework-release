/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.data.template.PlatformAuthenticationTemplate;
import io.rchemist.common.security.auth.service.AuthorityHelper;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import java.util.Collection;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 *   <p>
 *     SpringSecurity 로 로그인 처리 후 결과를 저장할 때 사용한다.
 *   </p>
 * Created by kunner
 **/
@Getter
@Setter
public class PlatformAuthentication extends AbstractAuthenticationToken implements
    PlatformAuthenticationTemplate<PlatformAuthentication> {

  protected Boolean tokenRefreshed;

  protected Object principal;

  public PlatformAuthentication(
      String loginName, String userName, SiteType siteType, String userId, String tenantAlias, String siteAlias, Collection<? extends GrantedAuthority> authorities) {
    super(authorities);
    this.withLoginName(loginName)
        .withPrincipal(loginName)
        .withName(userName)
        .withSiteType(siteType)
        .withUserId(userId)
        .withTenantAlias(tenantAlias)
        .withSiteAlias(siteAlias);
    if (authorities != null && !authorities.isEmpty()) {
      setRoles(AuthorityHelper.getRoles(authorities));
    }
    setAuthenticated(true);
    setDetails(null);
  }

  public PlatformAuthentication(AuthenticationResponse user) {
    super(AuthorityHelper.getAuthorities(user.getRoles()));
    this.setDetails(user);
    setAuthenticated(user.getLoginName() != null);
    this.withPrincipal(user)
        .withLoginName(user.getLoginName())
        .withEmailAddress(user.getEmailAddress())
        .withPhoneNumber(user.getPhoneNumber())
        .withName(user.getName())
        .withSiteType(EnumTypeUtil.getEnumType(SiteType.class, user.getSiteType(), SiteType.FRONT))
        .withUserId(user.getUserId())
        .withTenantAlias(user.getTenantAlias())
        .withSiteAlias(user.getSiteAlias())
        .withRoles(user.getRoles())
        .withAttributes(user.getAttributes())
        .withUserType(user.getUserType());
  }

  public PlatformAuthentication(PlatformAuthenticationTemplate<?> template) {
    super(AuthorityHelper.getAuthorities(template.getRoles()));
    setAuthenticated(template.getPrincipal() != null);
    this.withPrincipal(template.getPrincipal())
        .withLoginName(template.getLoginName())
        .withEmailAddress(template.getEmailAddress())
        .withPhoneNumber(template.getPhoneNumber())
        .withName(template.getName())
        .withSiteType(template.getSiteType())
        .withUserId(template.getUserId())
        .withTenantAlias(template.getTenantAlias())
        .withSiteAlias(template.getSiteAlias())
        .withRoles(template.getRoles())
        .withAccessToken(template.getAccessToken())
        .withRefreshToken(template.getRefreshToken())
        .withRememberMe(template.isRememberMe())
        .withAttributes(template.getAttributes())
        .withUserType(template.getUserType())
    ;
  }

  @Override
  public Object getCredentials() {
    // 사용자의 비밀번호는 저장하지 않는다.
    return null;
  }

  @Override
  public Object getPrincipal() {
    return principal == null ? getLoginName() : principal;
  }

  public List<String> getRoles(){
    if (getRoles() == null) {
      setRoles(AuthorityHelper.getRoles(this.getAuthorities()));
    }
    return getRoles();
  }

}
