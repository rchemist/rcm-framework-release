/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class UserServiceErrorType extends EnumType<UserServiceErrorType> implements ErrorType {

  public static final UserServiceErrorType INVALID_IP_ADDRESS = new UserServiceErrorType("INVALID_IP_ADDRESS", "Ipaddress is invalid", "IP주소가 아닙니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType INVALID_PASSWORD_PATTERN = new UserServiceErrorType("INVALID_PASSWORD_PATTERN", "Password pattern is invalid",
      "올바른 비밀번호가 아니거나 형식에 맞지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType DUPLICATE_PASSWORD_IS_NOT_PERMITTED = new UserServiceErrorType("DUPLICATE_PASSWORD_IS_NOT_PERMITTED", "Duplicated password is not permitted",
      "최근 6개월 이내에 사용했던 비밀번호를 다시 사용할 수 없습니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType ROLE_IS_NOT_EXIST = new UserServiceErrorType("ROLE_IS_NOT_EXIST", "Role is not exist",
      "User 에 매핑할 Role 이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType NO_SESSION = new UserServiceErrorType("NO_SESSION", "No Session",
      "로그인 한 경우에만 사용할 수 있습니다.", HttpStatus.UNAUTHORIZED);
  public static final UserServiceErrorType USER_NOT_FOUND = new UserServiceErrorType("USER_NOT_FOUND", "User is not exist",
      "User 가 없습니다.", HttpStatus.NOT_FOUND);
  public static final UserServiceErrorType NOT_OWNED_DATA = new UserServiceErrorType("NOT_OWNED_DATA", "Not owned data.",
      "해당 데이터에 접근할 수 없습니다", HttpStatus.FORBIDDEN);
  public static final UserServiceErrorType WRONG_ACCESS = new UserServiceErrorType("WRONG_ACCESS", "Wrong access",
      "요청한 정보가 존재하지 않습니다", HttpStatus.NOT_FOUND);
  public static final UserServiceErrorType DUPLICATE_ATTRIBUTE_KEY = new UserServiceErrorType("DUPLICATE_ATTRIBUTE_KEY", "Attribute key is duplicated.",
      "입력한 Key는 이미 사용중입니다. 다른 Key를 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType FRONT_USER_ONLY = new UserServiceErrorType("FRONT_USER_ONLY", "Front user only.",
      "Front 사용자만 사용할 수 있습니다.", HttpStatus.FORBIDDEN);
  public static final UserServiceErrorType ADMIN_USER_ONLY = new UserServiceErrorType("ADMIN_USER_ONLY", "Admin user only.",
      "Admin 사용자만 사용할 수 있습니다.", HttpStatus.FORBIDDEN);
  public static final UserServiceErrorType USER_BLOCK_SHOULD_HAVE_PERIOD = new UserServiceErrorType("USER_BLOCK_SHOULD_HAVE_PERIOD", "Block user should have period",
      "시작일 또는 종료일 중 적어도 하나를 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType USER_BLOCK_PERIOD_HAS_PAST = new UserServiceErrorType("USER_BLOCK_PERIOD_HAS_PAST", "Block period has past",
      "이미 종료일이 경과 했습니다.", HttpStatus.BAD_REQUEST);
  public static final UserServiceErrorType BLOCK_CAUSE_REQUIRED = new UserServiceErrorType("BLOCK_CAUSE_REQUIRED", "Block cause is required",
      "사유를 입력해야 합니다.", HttpStatus.BAD_REQUEST);

  @Getter
  private final int status;

  public UserServiceErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

}
