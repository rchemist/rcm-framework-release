/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.token.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.security.auth.data.PlatformAuthentication;
import io.rchemist.common.util.type.SiteType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface SecurityCheckFilterExtensionHandler extends ExtensionHandler {

  /**
   * accessToken 정보를 가지고 PlatformAuthentication 객체를 생성한다.
   * ServiceSecurityCheckFilter 의 확장 로직
   *
   * @param accessToken
   * @param resultHolder
   * @return
   */
  ExtensionResultStatusType authorizeByToken(SiteType siteType, String accessToken, String refreshToken, ExtensionResultHolder<PlatformAuthentication> resultHolder);

}
