/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class SecurityServiceErrorType extends EnumType<SecurityServiceErrorType> implements ErrorType {

  public static final SecurityServiceErrorType DUPLICATED_ROLE = new SecurityServiceErrorType("DUPLICATED_ROLE", "Role is duplicated.", "같은 이름의 Role 이 이미 존재합니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType ROLE_NOT_FOUND = new SecurityServiceErrorType("ROLE_NOT_FOUND", "Role is not found.", "Role 이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType PERMISSION_NOT_FOUND = new SecurityServiceErrorType("PERMISSION_NOT_FOUND", "Permission is not found.", "Permission이 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType REQUIRED_ROLE_NAME = new SecurityServiceErrorType("REQUIRED_ROLE_NAME", "Role name is required.", "ROLE 이름을 지정해 주세요.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType REQUIRED_PERMISSIONS = new SecurityServiceErrorType("REQUIRED_PERMISSIONS", "Permission is required.", "ROLE 에 지정될 퍼미션을 입력해 주세요.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType REQUIRED_ROLE_HIERARCHY = new SecurityServiceErrorType("REQUIRED_ROLE_HIERARCHY", "Role hierarchy is required.", "ROLE HIERARCHY 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType USER_NOT_FOUND = new SecurityServiceErrorType("USER_NOT_FOUND", "User not found.", "User 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType REQUIRED_API_KEY = new SecurityServiceErrorType("REQUIRED_API_KEY", "ApiKey required.", "API KEY 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final SecurityServiceErrorType REQUIRED_UPDATE_VALUES = new SecurityServiceErrorType("REQUIRED_UPDATE_VALUES", "Update values are required.", "변경할 권한 정보를 찾을 수 없습니다.", HttpStatus.BAD_REQUEST);

  @Getter
  private final int status;

  public SecurityServiceErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  public SecurityServiceErrorType() {
    this.status = 500;
  }
}
