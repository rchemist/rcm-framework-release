/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.util.type.SiteType;
import java.io.Serializable;
import lombok.Data;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Data
public class SocialLinkRequest implements Serializable {

  protected String userId;

  protected String provider;

  protected String providerUserId;

  protected SiteType siteType;

  protected String loginName;   // 로그인과 동시에 provider 를 셋팅하는 케이스

  protected String password;   // 로그인과 동시에 provider 를 셋팅하는 케이스

  protected Boolean additional = false;   // 추가 연동인 경우 - accessToken, refreshToken 을 갱신하지 않는다.

  public SiteType getSiteType() {
    return siteType == null ? SiteType.FRONT : siteType;
  }

  public SocialLinkRequest withSiteType(SiteType siteType) {
    this.siteType = siteType;
    return this;
  }

  public SocialLinkRequest withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public SocialLinkRequest withProvider(String provider) {
    this.provider = provider;
    return this;
  }

  public SocialLinkRequest withProviderUserId(String providerUserId) {
    this.providerUserId = providerUserId;
    return this;
  }

  public void validate() throws PlatformSecurityException {
    if (StringUtils.isEmpty(provider) || StringUtils.isEmpty(providerUserId))
      throw new PlatformSecurityException(PlatformSecurityErrorType.INVALID_SOCIAL_REQUEST);

    // userId 값이 있거나, loginName / password 값이 있거나 둘 중 하나여야 한다.
    if (StringUtils.isEmpty(userId)) {
      if (StringUtils.isEmpty(loginName) || StringUtils.isEmpty(password))
        throw new PlatformSecurityException(PlatformSecurityErrorType.INVALID_SOCIAL_REQUEST);
    }

  }

  public boolean isSimpleLink() {
    return StringUtils.isNotEmpty(userId);
  }

  public boolean isLoginLink() {
    return StringUtils.isNotEmpty(loginName) && StringUtils.isNotEmpty(password);
  }

  public boolean isAdditional() {
    return BooleanUtils.toBoolean(additional);
  }

}
