/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class SocialLoginResult extends LoginResult{

  // 이미 회원가입된 이메일 주소가 있다면 Exception 대신 이 정보를 제공한다.
  protected String registeredEmailAddress;

  public SocialLoginResult() {
  }

  public SocialLoginResult(LoginResult loginResult) {
    super(loginResult.getToken(), loginResult.getAuthentication());
  }

  public SocialLoginResult(Token token, PlatformAuthentication authentication,
      String registeredEmailAddress) {
    super(token, authentication);
    this.registeredEmailAddress = registeredEmailAddress;
  }

  public SocialLoginResult withRegisteredEmailAddress(String registeredEmailAddress) {
    this.registeredEmailAddress = registeredEmailAddress;
    return this;
  }
}

