/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AuthenticationErrorType extends EnumType<AuthenticationErrorType> implements ErrorType {

  public static final AuthenticationErrorType USER_NOT_FOUND = new AuthenticationErrorType("USER_NOT_FOUND", "User not found", "User 정보를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
  public static final AuthenticationErrorType TENANT_NOT_FOUND = new AuthenticationErrorType("TENANT_NOT_FOUND", "Tenant not found", "Tenant 정보를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
  public static final AuthenticationErrorType SITE_NOT_FOUND = new AuthenticationErrorType("SITE_NOT_FOUND", "Site not found", "Site 정보를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);;

  public AuthenticationErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  @Getter
  protected final int status;

}
