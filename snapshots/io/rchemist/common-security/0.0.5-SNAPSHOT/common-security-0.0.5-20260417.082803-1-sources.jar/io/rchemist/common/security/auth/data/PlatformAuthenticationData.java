/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.auth.data;

import io.rchemist.common.security.auth.data.template.PlatformAuthenticationTemplate;
import lombok.NoArgsConstructor;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@NoArgsConstructor
public class PlatformAuthenticationData implements PlatformAuthenticationTemplate<PlatformAuthenticationData> {

  public PlatformAuthenticationData(PlatformAuthentication authentication) {
    this.withPrincipal(authentication.getPrincipal())
        .withLoginName(authentication.getLoginName())
        .withName(authentication.getName())
        .withSiteType(authentication.getSiteType())
        .withUserId(authentication.getUserId())
        .withTenantAlias(authentication.getTenantAlias())
        .withSiteAlias(authentication.getSiteAlias())
        .withRememberMe(authentication.isRememberMe())
        .withEmailAddress(authentication.getEmailAddress())
        .withRoles(authentication.getRoles())
        .withAccessToken(authentication.getAccessToken())
        .withRefreshToken(authentication.getRefreshToken())
        .withAttributes(authentication.getAttributes())
        .withUserType(authentication.getUserType());
  }
}
