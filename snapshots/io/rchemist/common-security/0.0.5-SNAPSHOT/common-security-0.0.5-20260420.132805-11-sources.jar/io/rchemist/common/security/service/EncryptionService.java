/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.EncryptionUtil;
import io.rchemist.common.util.ExceptionUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Service("rcmEncryptionService")
public class EncryptionService {

  private static EncryptionService encryptionService;

  @Value("${platform.config.common.encrypt.key:}")
  protected String key;

  public String encrypt(String origin){
    if(StringUtils.isEmpty(origin))
      return origin;
    try {
      return EncryptionUtil.encryptAES256(origin, key);
    } catch (Exception e) {
      log.warn("encryption skipped: {}", e.toString());
      log.debug("encryption stack trace", e);
      return origin;
    }
  }

  public String decrypt(String encrypted){
    if(StringUtils.isEmpty(encrypted))
      return encrypted;
    try {
      return EncryptionUtil.decryptAES256(encrypted, key);
    } catch (Exception e) {
      log.warn("encryption skipped: {}", e.toString());
      log.debug("encryption stack trace", e);
      return encrypted;
    }
  }

  public static EncryptionService getEncryptionService() {
    if(encryptionService == null){
      encryptionService = ApplicationContextHolder.getBean(EncryptionService.class);
    }
    return encryptionService;
  }

  public static String getEncrypt(String origin){
    return getEncryptionService().encrypt(origin);
  }

  public static String getDecrypt(String encrypted){
    return getEncryptionService().decrypt(encrypted);
  }
}
