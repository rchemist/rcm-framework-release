/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.slice;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.junit.jupiter.api.Tag;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.annotation.AliasFor;
import org.springframework.test.context.ActiveProfiles;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #4 — 통합 IT 진입점 메타 annotation. {@link SpringBootTest} +
 * {@code @Tag("it")} + {@link ActiveProfiles}{@code ("test")} 합성.
 *
 * <p>한 줄 부착으로 통합 IT 표준화 — {@code @Tag("it")} 정합 ({@code ./gradlew integrationTest}
 * 만 실행 / default {@code test} 영역에서 제외) + {@code test} profile activate +
 * {@link SpringBootTest} 기본 진입.
 *
 * <pre>
 * &#64;IntegrationTest
 * class ArticleIT {
 *   &#64;Autowired ArticleService service;
 *
 *   &#64;Test
 *   void createsArticle() { ... }
 * }
 * </pre>
 *
 * <p>{@link SpringBootTest} 의 {@code classes} / {@code properties} / {@code webEnvironment} 와
 * {@link ActiveProfiles} 의 {@code profiles} 는 {@link AliasFor} 로 위임 — 사용자가 본 메타에서
 * 직접 명시 가능.
 *
 * <p>Testcontainers 4 종 자동 binding 영역은 미포함 — 사용자가 {@code @DynamicPropertySource}
 * + {@code SharedXxxContainer.bindXxx(...)} 패턴으로 명시 합류 (Phase 8 task #2 baseline).
 * Container enum 자동 binding 추상화는 Spring Boot 4 의 {@code @ServiceConnection} 패턴 정합
 * 위해 Phase 8+ 후보.
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@SpringBootTest
@Tag("it")
@ActiveProfiles
public @interface IntegrationTest {

  /** {@link SpringBootTest#classes()} alias. */
  @AliasFor(annotation = SpringBootTest.class, attribute = "classes")
  Class<?>[] classes() default {};

  /** {@link SpringBootTest#properties()} alias. */
  @AliasFor(annotation = SpringBootTest.class, attribute = "properties")
  String[] properties() default {};

  /** {@link SpringBootTest#webEnvironment()} alias. default {@link WebEnvironment#NONE}. */
  @AliasFor(annotation = SpringBootTest.class, attribute = "webEnvironment")
  WebEnvironment webEnvironment() default WebEnvironment.NONE;

  /** {@link ActiveProfiles#profiles()} alias. default {@code "test"}. */
  @AliasFor(annotation = ActiveProfiles.class, attribute = "profiles")
  String[] profiles() default {"test"};
}
