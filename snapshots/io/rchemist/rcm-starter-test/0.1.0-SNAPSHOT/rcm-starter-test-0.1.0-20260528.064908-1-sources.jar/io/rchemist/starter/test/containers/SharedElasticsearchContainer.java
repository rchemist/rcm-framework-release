/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.elasticsearch.ElasticsearchContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #2 — Elasticsearch Testcontainers Singleton holder.
 *
 * <p>{@link ElasticsearchContainer} = ES 노드 단일 + 9200 HTTP / 9300 transport 노출.
 * Decision #8 (검색엔진 통합 = 0.1.0 영역 아님) 정합 — gjcu 분석 기반 *프로덕션 사용 0* 이라 본
 * Singleton 은 *0.2.0 search-elasticsearch RFC 진입 시점* 또는 *Consumer 자체 IT* 활용 baseline.
 *
 * <p>이미지 override = {@code rcm.test.containers.elasticsearch.image} system property /
 * {@code RCM_TEST_CONTAINERS_ELASTICSEARCH_IMAGE} env. default {@value #DEFAULT_IMAGE}.
 *
 * <pre>
 * &#64;DynamicPropertySource
 * static void registerProperties(DynamicPropertyRegistry registry) {
 *   SharedElasticsearchContainer.bindElasticsearch(registry);
 * }
 * </pre>
 *
 * <p>등록 키 = {@code spring.elasticsearch.uris} (HTTP URL list).
 **/
public final class SharedElasticsearchContainer {

  /**
   * Default Docker image — ES 9.x (Spring Boot 4 / Spring Data ES 6 의 ES Java Client 9 정합).
   * 8.x 서버 + 9 클라이언트 = REST5Client protocol mismatch (`status: 400 Expecting a response body`).
   */
  public static final String DEFAULT_IMAGE =
      "docker.elastic.co/elasticsearch/elasticsearch:9.0.4";

  /** System property key. */
  public static final String IMAGE_PROPERTY = "rcm.test.containers.elasticsearch.image";

  private static volatile ElasticsearchContainer instance;

  private SharedElasticsearchContainer() {
    // utility class
  }

  /** Singleton instance. 첫 호출 시 lazy startup. */
  public static ElasticsearchContainer instance() {
    ElasticsearchContainer local = instance;
    if (local == null) {
      synchronized (SharedElasticsearchContainer.class) {
        local = instance;
        if (local == null) {
          local =
              new ElasticsearchContainer(DockerImageName.parse(resolveImage()))
                  // ES 8+ default = xpack.security on (HTTPS + auth). Test 단순화 = 끔.
                  // 운영 환경은 Consumer 가 본인 ES 클러스터의 security 정책 적용.
                  .withEnv("xpack.security.enabled", "false")
                  .withEnv("discovery.type", "single-node")
                  .withReuse(true);
          local.start();
          instance = local;
        }
      }
    }
    return local;
  }

  /**
   * Spring Data Elasticsearch property 자동 등록.
   *
   * @param registry Spring Test {@link DynamicPropertyRegistry}
   */
  public static void bindElasticsearch(DynamicPropertyRegistry registry) {
    registry.add("spring.elasticsearch.uris", () -> "http://" + instance().getHttpHostAddress());
  }

  static String resolveImage() {
    String fromSystem = System.getProperty(IMAGE_PROPERTY);
    if (fromSystem != null && !fromSystem.isBlank()) {
      return fromSystem;
    }
    String fromEnv = System.getenv("RCM_TEST_CONTAINERS_ELASTICSEARCH_IMAGE");
    if (fromEnv != null && !fromEnv.isBlank()) {
      return fromEnv;
    }
    return DEFAULT_IMAGE;
  }
}
