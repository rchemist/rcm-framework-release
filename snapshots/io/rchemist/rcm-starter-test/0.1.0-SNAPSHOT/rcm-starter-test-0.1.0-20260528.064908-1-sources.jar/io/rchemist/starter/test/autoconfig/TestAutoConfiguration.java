/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.autoconfig;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #1 — {@code rcm-starter-test} 진입점.
 *
 * <p>baseline 적용 (Decision #20 + 청사진 §2.2):
 * <ul>
 *   <li>Decision #20 — {@code Rcm} prefix 영구 거부. Phase 0 의 stub
 *       {@code RcmStarterTestAutoConfiguration} ({@code io.rchemist.test} 패키지) 를 본
 *       클래스로 rename + sub-package 분할 ({@code io.rchemist.starter.test.autoconfig}).
 *   <li>Phase 5 / 6 의 {@code SecurityAutoConfiguration} / {@code ExternalAutoConfiguration}
 *       동일 톤 — 단일 진입점 + 후속 task 가 inner static config 또는 별도 sub-package 채움.
 *   <li>{@code platform.test.enabled} = {@code false} 로 opt-out 가능 (default = true).
 * </ul>
 *
 * <p>sub-package 4 영역 (Phase 8 후속 task 가 본문 채움):
 * <ul>
 *   <li>{@code containers/} — Testcontainers default 4 종 (PostgreSQL / Redis / RabbitMQ /
 *       Elasticsearch Singleton). Phase 8 task #2.
 *   <li>{@code slice/} — {@code @WithTenant} / {@code @WithUser} / {@code @IntegrationTest}
 *       메타 어노테이션. Phase 8 task #3 ~ #4.
 *   <li>{@code fixture/} — {@code EntityFixture<T>} base + Faker helper (Decision #3 옵션 A —
 *       APT 자동 생성 X). Phase 8 task #5.
 *   <li>{@code autoconfig/} — 본 진입점.
 * </ul>
 **/
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.test", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(TestProperties.class)
public class TestAutoConfiguration {
}
