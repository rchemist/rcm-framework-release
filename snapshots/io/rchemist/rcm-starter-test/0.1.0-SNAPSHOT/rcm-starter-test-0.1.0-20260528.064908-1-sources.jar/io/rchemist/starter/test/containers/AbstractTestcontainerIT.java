/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #54 — DB-agnostic 추상 명명. singleton Testcontainer + Spring DataSource 4 property
 * 자동 등록 = DB 종류 무관 추상 패턴 = 명명에서 "Postgres" 제거. 본 class 를 extend 만 하면
 * {@link SharedPostgresContainer} 싱글톤 컨테이너 + Spring DataSource 4 property
 * (url / username / password / driver-class-name) 자동 등록.
 *
 * <p>이전 패턴 ({@code @Container static PostgreSQLContainer postgres = new ...} per IT class)
 * 은 IT 마다 컨테이너 재시작 → 23 IT × ~3-5s = 70-115s 단순 startup 비용. 본 base 채택 후 JVM
 * 단일 컨테이너 + Hibernate {@code create-drop} 으로 schema 만 reset.
 *
 * <p>적용 범위: singleton 컨테이너 + DataSource 자동 등록으로 충분한 IT. 다음 영역은 본 base
 * 미적용:
 * <ul>
 *   <li>{@code postgis/postgis} 등 비표준 image — {@code SharedPostgisContainer} 별도 (#A6)</li>
 *   <li>multi-DBMS 매트릭스 (MySQL / MSSQL) — {@code SharedMultiDbContainerIT} 별도 (#A5)</li>
 *   <li>2+ 컨테이너 동시 ({@code MultiDataSourceIntegrationTest}) — 자기 컨테이너 유지</li>
 *   <li>custom DB 이름 / 초기화 ({@code DatabaseTenantIntegrationTest}) — 자기 컨테이너 유지</li>
 * </ul>
 *
 * <p>사용 예 (subclass):
 * <pre>
 * &#64;Tag("it")
 * &#64;DataJpaTest
 * &#64;AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
 * class ArticleIT extends AbstractTestcontainerIT {
 *   // 자기 @Container 필드 / @Testcontainers 어노테이션 모두 제거
 *   // SharedPostgresContainer 싱글톤이 JVM 단일 인스턴스 자동 제공
 * }
 * </pre>
 *
 * <p>{@code @ServiceConnection} 미사용 = Spring Boot Testcontainers 통합 우회. 대신
 * {@link DynamicPropertySource} 가 {@code spring.datasource.*} 4 key 직접 등록 → 표준
 * {@code DataSourceAutoConfiguration} 자동 동작. effect 동일 + 컨테이너 lifecycle 자유.
 *
 * <p>backward-compat — {@link AbstractPostgresIT} 영역이 본 class 를 extends 하는 deprecated alias
 * 형태 유지 ({@code 0.1.1} 도입 / forRemoval = true). 신규 IT 는 본 class 직접 extends 권장.
 **/
public abstract class AbstractTestcontainerIT {

  @DynamicPropertySource
  static void registerTestcontainer(DynamicPropertyRegistry registry) {
    SharedPostgresContainer.bindDataSource(registry);
    // 단일 컨테이너 공유 시 다수 IT context 가 각자 Hikari pool 보유 → 컨테이너의 max_connections=100
    // 한계 도달 시 "Unable to determine Dialect without JDBC metadata" 발생. context 별 pool 작게 = 안전.
    registry.add("spring.datasource.hikari.maximum-pool-size", () -> "2");
    registry.add("spring.datasource.hikari.minimum-idle", () -> "1");
  }
}
