/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #1 — {@code platform.test.*} 영역 baseline.
 *
 * <p>본 Records = {@code rcm-starter-test} 의 진입 게이트만 정의. Phase 8 후속 task 가
 * containers / slice / fixture sub-record 추가 (Phase 5 의 {@code SecurityProperties} 패턴).
 *
 * @param enabled 전체 활성 (default {@code true}). Consumer 가 {@code platform.test.enabled =
 *     false} 로 opt-out 가능
 **/
@ConfigurationProperties(prefix = "platform.test")
public record TestProperties(boolean enabled) {

  public TestProperties {
    // Records compact constructor — no normalization needed yet (Phase 8 task #2+ 갱신).
  }

  /** Spring Boot bind 용 default constructor. {@code platform.test.*} 미정의 시 본값 사용. */
  public TestProperties() {
    this(true);
  }
}
