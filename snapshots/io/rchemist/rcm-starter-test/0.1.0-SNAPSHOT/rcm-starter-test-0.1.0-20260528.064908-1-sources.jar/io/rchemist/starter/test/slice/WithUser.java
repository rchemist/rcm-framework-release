/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.slice;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.junit.jupiter.api.extension.ExtendWith;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #3 — testMethod 또는 testClass 부착 시 {@link
 * io.rchemist.core.context.UserContext} ScopedValue 자동 binding.
 *
 * <p>{@link ScopedValueTestExtension} 가 본 annotation 을 {@link WithTenant} 와 동시에 처리 —
 * 둘 다 부착 시 tenant outer scope + user inner scope 으로 nested binding.
 *
 * <pre>
 * &#64;Test
 * &#64;WithTenant("acme")
 * &#64;WithUser(userId = "alice", roles = {"ADMIN", "USER"})
 * void readsUserContext() {
 *   assertThat(UserContext.current().userId()).isEqualTo("alice");
 *   assertThat(TenantContext.required().tenantId()).isEqualTo("acme");
 * }
 * </pre>
 **/
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@ExtendWith(ScopedValueTestExtension.class)
public @interface WithUser {

  /** UserContext.userId 영역. default {@code "test-user"}. */
  String userId() default "test-user";

  /** UserContext.username 영역. default {@code "test"}. */
  String username() default "test";

  /** UserContext.roles 영역. default {@code {"USER"}}. */
  String[] roles() default {"USER"};
}
