/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.utility.DockerImageName;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #2 — Redis Testcontainers Singleton holder.
 *
 * <p>Testcontainers v2 = Redis 전용 module 없음 → {@link GenericContainer} + 6379 노출.
 * Phase 5 task #4 (Redis token store) + Phase 4 task #4 (cache metric) 의 IT 영역에서 활용 가능.
 *
 * <p>이미지 override = {@code rcm.test.containers.redis.image} system property /
 * {@code RCM_TEST_CONTAINERS_REDIS_IMAGE} env. default {@value #DEFAULT_IMAGE}.
 *
 * <pre>
 * &#64;DynamicPropertySource
 * static void registerProperties(DynamicPropertyRegistry registry) {
 *   SharedRedisContainer.bindRedis(registry);
 * }
 * </pre>
 *
 * <p>등록 키 = {@code spring.data.redis.host} + {@code spring.data.redis.port}.
 **/
public final class SharedRedisContainer {

  /** Default Docker image. Redis 7 = production baseline (RESP3 / ACL / cluster API). */
  public static final String DEFAULT_IMAGE = "redis:7-alpine";

  /** System property key. */
  public static final String IMAGE_PROPERTY = "rcm.test.containers.redis.image";

  /** Default Redis port (TCP 6379). */
  public static final int REDIS_PORT = 6379;

  private static volatile GenericContainer<?> instance;

  private SharedRedisContainer() {
    // utility class
  }

  /** Singleton instance. 첫 호출 시 lazy startup. */
  public static GenericContainer<?> instance() {
    GenericContainer<?> local = instance;
    if (local == null) {
      synchronized (SharedRedisContainer.class) {
        local = instance;
        if (local == null) {
          local =
              new GenericContainer<>(DockerImageName.parse(resolveImage()))
                  .withExposedPorts(REDIS_PORT)
                  .withReuse(true)
                  .waitingFor(Wait.forListeningPort());
          local.start();
          instance = local;
        }
      }
    }
    return local;
  }

  /**
   * Spring Data Redis property 2 종 자동 등록 ({@code spring.data.redis.host} +
   * {@code spring.data.redis.port}). supplier lazy.
   *
   * @param registry Spring Test {@link DynamicPropertyRegistry}
   */
  public static void bindRedis(DynamicPropertyRegistry registry) {
    registry.add("spring.data.redis.host", () -> instance().getHost());
    registry.add("spring.data.redis.port", () -> instance().getMappedPort(REDIS_PORT));
  }

  static String resolveImage() {
    String fromSystem = System.getProperty(IMAGE_PROPERTY);
    if (fromSystem != null && !fromSystem.isBlank()) {
      return fromSystem;
    }
    String fromEnv = System.getenv("RCM_TEST_CONTAINERS_REDIS_IMAGE");
    if (fromEnv != null && !fromEnv.isBlank()) {
      return fromEnv;
    }
    return DEFAULT_IMAGE;
  }
}
