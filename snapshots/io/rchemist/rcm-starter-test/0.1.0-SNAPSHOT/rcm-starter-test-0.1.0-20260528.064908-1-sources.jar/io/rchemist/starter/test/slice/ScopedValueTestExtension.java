/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.slice;

import io.rchemist.core.context.TenantContext;
import io.rchemist.core.context.UserContext;
import java.lang.reflect.Method;
import java.util.Set;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.InvocationInterceptor;
import org.junit.jupiter.api.extension.ReflectiveInvocationContext;
import org.junit.platform.commons.support.AnnotationSupport;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #3 — {@link WithTenant} / {@link WithUser} 통합 JUnit 5 extension.
 *
 * <p>JUnit 5 {@link InvocationInterceptor#interceptTestMethod} 가 testMethod invoke 자체를
 * wrap → ScopedValue.where(SCOPE, ctx).run(invocation) 패턴 적용. ScopedValue 의 *binding scope
 * 외부에서는 unbound* 정합 — testMethod 종료와 동시에 ScopedValue 도 자동 해제.
 *
 * <p>{@link WithTenant} = outer scope, {@link WithUser} = inner scope (둘 다 부착 시 nested).
 * 메서드 부착 우선, 없으면 클래스 부착 fallback (JUnit 5 {@link AnnotationSupport#findAnnotation}).
 *
 * <p>{@code @BeforeEach} / {@code @AfterEach} 는 *intercept 안 함* — ScopedValue 는 testMethod
 * scope 내부에서만 binding 유지가 표준 패턴 (Phase 1 baseline 정합). lifecycle method 도 binding
 * 필요 시 별도 nested annotation 또는 BeforeEachCallback 영역 추가 (Phase 8+ 보강 후보).
 **/
public class ScopedValueTestExtension implements InvocationInterceptor {

  @Override
  public void interceptTestMethod(
      Invocation<Void> invocation,
      ReflectiveInvocationContext<Method> invocationContext,
      ExtensionContext extensionContext)
      throws Throwable {
    Method method = extensionContext.getRequiredTestMethod();
    Class<?> testClass = extensionContext.getRequiredTestClass();

    WithTenant tenant =
        AnnotationSupport.findAnnotation(method, WithTenant.class)
            .orElseGet(() -> AnnotationSupport.findAnnotation(testClass, WithTenant.class).orElse(null));
    WithUser user =
        AnnotationSupport.findAnnotation(method, WithUser.class)
            .orElseGet(() -> AnnotationSupport.findAnnotation(testClass, WithUser.class).orElse(null));

    Throwable[] thrown = new Throwable[1];
    Runnable proceed =
        () -> {
          try {
            invocation.proceed();
          } catch (Throwable t) {
            thrown[0] = t;
          }
        };

    Runnable wrapped = proceed;
    if (user != null) {
      Runnable inner = wrapped;
      UserContext userCtx =
          new UserContext(user.userId(), user.username(), Set.of(user.roles()));
      wrapped = () -> UserContext.runWith(userCtx, inner);
    }
    if (tenant != null) {
      Runnable inner = wrapped;
      String name = tenant.name().isBlank() ? null : tenant.name();
      TenantContext tenantCtx = new TenantContext(tenant.value(), name);
      wrapped = () -> TenantContext.runWith(tenantCtx, inner);
    }

    wrapped.run();
    if (thrown[0] != null) {
      throw thrown[0];
    }
  }
}
