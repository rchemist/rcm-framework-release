/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.fixture;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.datafaker.Faker;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #5 — Entity fixture base. Decision #3 옵션 A 정합 — APT 자동 생성 X.
 *
 * <p>사용자가 본 base 를 extend 해서 entity 별 fixture 작성. {@link #newInstance()} 추상
 * 메서드만 구현, 나머지 builder 패턴 ({@link #one()} / {@link #one(Consumer)} /
 * {@link #list(int)} / {@link #list(int, Consumer)}) 자동 제공.
 *
 * <p>{@link #faker()} = {@link FakerHolder#defaultFaker()} 에 위임. 사용자가 별도 locale
 * 필요 시 {@link FakerHolder#korean()} / {@link FakerHolder#english()} 직접 호출.
 *
 * <pre>
 * public class ArticleFixture extends EntityFixture&lt;Article&gt; {
 *
 *   &#64;Override
 *   public Article newInstance() {
 *     Article a = new Article();
 *     a.setTitle(faker().book().title());
 *     a.setContent(faker().lorem().paragraph());
 *     a.setAuthor(faker().name().fullName());
 *     return a;
 *   }
 * }
 *
 * // 사용
 * Article one = new ArticleFixture().one();
 * Article custom = new ArticleFixture().one(a -&gt; a.setTitle("override"));
 * List&lt;Article&gt; ten = new ArticleFixture().list(10);
 * </pre>
 *
 * @param <T> fixture entity 타입
 **/
public abstract class EntityFixture<T> {

  /**
   * 신규 entity instance 1 개 — default 값 설정. 사용자가 entity 별로 구현.
   *
   * @return 신규 entity (id 미할당 영역, persistent 시 JPA 가 부여)
   */
  public abstract T newInstance();

  /** 단일 instance — {@link #newInstance()} 호출. */
  public T one() {
    return newInstance();
  }

  /**
   * 단일 instance + customizer 적용. customizer 는 {@link #newInstance()} 결과에 in-place 변경.
   *
   * @param customizer entity 변경 로직 (null 허용 X)
   * @return 변경 적용된 entity
   */
  public T one(Consumer<T> customizer) {
    Objects.requireNonNull(customizer, "customizer");
    T t = newInstance();
    customizer.accept(t);
    return t;
  }

  /**
   * N 개 instance.
   *
   * @param count 0 이상
   * @return immutable list (반환 list 자체는 수정 불가)
   */
  public List<T> list(int count) {
    if (count < 0) {
      throw new IllegalArgumentException("count < 0: " + count);
    }
    List<T> result = new ArrayList<>(count);
    for (int i = 0; i < count; i++) {
      result.add(newInstance());
    }
    return List.copyOf(result);
  }

  /**
   * N 개 instance + 각 entity 에 customizer 적용 (idx 0 ~ count-1).
   *
   * @param count 0 이상
   * @param customizer entity 별 변경 로직
   * @return immutable list
   */
  public List<T> list(int count, Consumer<T> customizer) {
    Objects.requireNonNull(customizer, "customizer");
    if (count < 0) {
      throw new IllegalArgumentException("count < 0: " + count);
    }
    List<T> result = new ArrayList<>(count);
    for (int i = 0; i < count; i++) {
      T t = newInstance();
      customizer.accept(t);
      result.add(t);
    }
    return List.copyOf(result);
  }

  /** Datafaker helper — {@link FakerHolder#defaultFaker()} 위임. locale 별 호출은 직접. */
  protected final Faker faker() {
    return FakerHolder.defaultFaker();
  }
}
