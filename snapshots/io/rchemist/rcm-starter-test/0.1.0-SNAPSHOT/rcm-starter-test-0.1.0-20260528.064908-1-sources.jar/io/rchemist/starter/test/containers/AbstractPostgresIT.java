/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Deprecated alias — issue #54 영역에서 {@link AbstractTestcontainerIT} 로 정정 명명. singleton
 * 컨테이너 + Spring DataSource 4 property 자동 등록 = DB 종류 무관 추상 패턴 → 명명에서
 * "Postgres" 제거. 본 class 는 backward-compat 만 유지 (메소드 영역 없음 — 모든 책임
 * {@link AbstractTestcontainerIT} 위임).
 *
 * <p>신규 IT 는 {@link AbstractTestcontainerIT} 직접 extends 권장. 본 alias 는 {@code 0.1.1}
 * 부터 deprecated, 다음 release 에서 제거 ({@code forRemoval = true}).
 *
 * <p>code-generator (rchemist/code-generator) 의 IT 산출 영역 (IntegrationTestRenderer /
 * RepositoryTestRenderer) 도 본 정정 명명 영역 진입 가능 — code-generator#44 (D32) 차단 해소.
 *
 * @deprecated since 0.1.1, for removal. {@link AbstractTestcontainerIT} 영역 직접 extends 권장.
 **/
@Deprecated(since = "0.1.1", forRemoval = true)
public abstract class AbstractPostgresIT extends AbstractTestcontainerIT {
  // 메소드 영역 없음 — 모든 책임 부모 위임 (AbstractTestcontainerIT.registerTestcontainer).
}
