/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.slice;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.junit.jupiter.api.extension.ExtendWith;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #3 — testMethod 또는 testClass 부착 시 {@link
 * io.rchemist.core.context.TenantContext} ScopedValue 자동 binding.
 *
 * <p>{@link ScopedValueTestExtension} 가 JUnit 5 {@link
 * org.junit.jupiter.api.extension.InvocationInterceptor} 로 testMethod invoke 자체를
 * {@code TenantContext.runWith(...).run(invocation)} wrap → ScopedValue 적용 영역 안에서 본
 * test method 실행. 메서드 부착 우선, 없으면 클래스 부착 fallback.
 *
 * <pre>
 * &#64;Test
 * &#64;WithTenant("acme")
 * void readsTenantContext() {
 *   assertThat(TenantContext.required().tenantId()).isEqualTo("acme");
 * }
 * </pre>
 *
 * <p>{@link #name()} = optional tenant display name. 미명시 시 {@code null} (TenantContext
 * Records 의 nullable 영역).
 **/
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@ExtendWith(ScopedValueTestExtension.class)
public @interface WithTenant {

  /** Tenant ID — TenantContext.tenantId 영역. */
  String value();

  /** Tenant display name. default 빈 문자열 (Records nullable 로 처리). */
  String name() default "";
}
