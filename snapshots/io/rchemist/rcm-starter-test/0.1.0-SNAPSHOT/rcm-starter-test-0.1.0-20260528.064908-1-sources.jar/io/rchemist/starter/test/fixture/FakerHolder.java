/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.fixture;

import java.util.Locale;
import net.datafaker.Faker;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #5 — {@link Faker} (datafaker) Singleton holder. Korean locale 지원
 * (사람 이름 / 주소 / 회사명 한국어 sample).
 *
 * <p>Decision #3 옵션 A 정합 — fixture APT 자동 생성 X. 사용자가 fixture 코드 손코딩 또는
 * {@code ~/dev/code-generator} 스캐폴딩, framework 는 본 helper + {@link EntityFixture} base
 * 만 제공.
 *
 * <p>locale 우선순위: system property {@code rcm.test.faker.locale} > env var
 * {@code RCM_TEST_FAKER_LOCALE} > {@value #DEFAULT_LOCALE} (한국어).
 *
 * <pre>
 * Faker faker = FakerHolder.defaultFaker();
 * String koreanName = faker.name().fullName(); // 한글 이름
 *
 * Faker english = FakerHolder.english();
 * String englishCompany = english.company().name();
 * </pre>
 **/
public final class FakerHolder {

  /** Default locale tag = ko (한국어). */
  public static final String DEFAULT_LOCALE = "ko";

  /** System property key — locale override 시. */
  public static final String LOCALE_PROPERTY = "rcm.test.faker.locale";

  private static volatile Faker korean;
  private static volatile Faker english;
  private static volatile Faker defaultFaker;

  private FakerHolder() {
    // utility class
  }

  /** Korean locale Faker. 한글 이름 / 주소 / 회사명 sample. */
  public static Faker korean() {
    Faker local = korean;
    if (local == null) {
      synchronized (FakerHolder.class) {
        local = korean;
        if (local == null) {
          local = new Faker(Locale.KOREAN);
          korean = local;
        }
      }
    }
    return local;
  }

  /** English locale Faker. Lorem ipsum / Western names sample. */
  public static Faker english() {
    Faker local = english;
    if (local == null) {
      synchronized (FakerHolder.class) {
        local = english;
        if (local == null) {
          local = new Faker(Locale.ENGLISH);
          english = local;
        }
      }
    }
    return local;
  }

  /**
   * Locale 우선순위 따라 default Faker 반환. system property > env > {@link #DEFAULT_LOCALE}.
   *
   * @return locale 결정된 Faker singleton
   */
  public static Faker defaultFaker() {
    Faker local = defaultFaker;
    if (local == null) {
      synchronized (FakerHolder.class) {
        local = defaultFaker;
        if (local == null) {
          local = new Faker(resolveLocale());
          defaultFaker = local;
        }
      }
    }
    return local;
  }

  static Locale resolveLocale() {
    String tag = System.getProperty(LOCALE_PROPERTY);
    if (tag == null || tag.isBlank()) {
      tag = System.getenv("RCM_TEST_FAKER_LOCALE");
    }
    if (tag == null || tag.isBlank()) {
      tag = DEFAULT_LOCALE;
    }
    return Locale.forLanguageTag(tag);
  }
}
