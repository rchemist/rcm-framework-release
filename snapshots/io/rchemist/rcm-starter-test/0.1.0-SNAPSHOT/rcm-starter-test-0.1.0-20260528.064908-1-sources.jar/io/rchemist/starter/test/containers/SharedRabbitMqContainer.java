/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.containers.RabbitMQContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #2 — RabbitMQ Testcontainers Singleton holder.
 *
 * <p>{@link RabbitMQContainer} = AMQP 5672 + management 15672 노출. Decision #11
 * ({@code rcm-starter-notification}) outbox / DLQ 영역 IT 시점에 활용.
 *
 * <p>이미지 override = {@code rcm.test.containers.rabbitmq.image} system property /
 * {@code RCM_TEST_CONTAINERS_RABBITMQ_IMAGE} env. default {@value #DEFAULT_IMAGE}.
 *
 * <pre>
 * &#64;DynamicPropertySource
 * static void registerProperties(DynamicPropertyRegistry registry) {
 *   SharedRabbitMqContainer.bindRabbit(registry);
 * }
 * </pre>
 *
 * <p>등록 키 = {@code spring.rabbitmq.host} + {@code spring.rabbitmq.port} +
 * {@code spring.rabbitmq.username} + {@code spring.rabbitmq.password}.
 **/
public final class SharedRabbitMqContainer {

  /** Default Docker image. 3-management-alpine = RabbitMQ 3 + management plugin. */
  public static final String DEFAULT_IMAGE = "rabbitmq:3-management-alpine";

  /** System property key. */
  public static final String IMAGE_PROPERTY = "rcm.test.containers.rabbitmq.image";

  private static volatile RabbitMQContainer instance;

  private SharedRabbitMqContainer() {
    // utility class
  }

  /** Singleton instance. 첫 호출 시 lazy startup. */
  public static RabbitMQContainer instance() {
    RabbitMQContainer local = instance;
    if (local == null) {
      synchronized (SharedRabbitMqContainer.class) {
        local = instance;
        if (local == null) {
          local = new RabbitMQContainer(DockerImageName.parse(resolveImage())).withReuse(true);
          local.start();
          instance = local;
        }
      }
    }
    return local;
  }

  /**
   * Spring AMQP property 4 종 자동 등록.
   *
   * @param registry Spring Test {@link DynamicPropertyRegistry}
   */
  public static void bindRabbit(DynamicPropertyRegistry registry) {
    registry.add("spring.rabbitmq.host", () -> instance().getHost());
    registry.add("spring.rabbitmq.port", () -> instance().getAmqpPort());
    registry.add("spring.rabbitmq.username", () -> instance().getAdminUsername());
    registry.add("spring.rabbitmq.password", () -> instance().getAdminPassword());
  }

  static String resolveImage() {
    String fromSystem = System.getProperty(IMAGE_PROPERTY);
    if (fromSystem != null && !fromSystem.isBlank()) {
      return fromSystem;
    }
    String fromEnv = System.getenv("RCM_TEST_CONTAINERS_RABBITMQ_IMAGE");
    if (fromEnv != null && !fromEnv.isBlank()) {
      return fromEnv;
    }
    return DEFAULT_IMAGE;
  }
}
