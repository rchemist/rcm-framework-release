/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.test.containers;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 8 task #2 — PostgreSQL Testcontainers Singleton holder.
 *
 * <p>JVM 단일 인스턴스. 첫 {@link #instance()} 호출 시 컨테이너 startup, JVM 종료 시
 * Testcontainers Ryuk reaper 가 자동 정리. {@code withReuse(true)} = {@code ~/.testcontainers.properties}
 * 의 {@code testcontainers.reuse.enable=true} 영역 합류 (다회 test 실행 간 컨테이너 재사용 →
 * 개발 cycle 단축).
 *
 * <p>이미지 override 는 시스템 property {@code rcm.test.containers.postgres.image} 또는 환경
 * 변수 {@code RCM_TEST_CONTAINERS_POSTGRES_IMAGE} 로. default {@value #DEFAULT_IMAGE}.
 *
 * <p>Spring Test {@link DynamicPropertyRegistry} 통합 — {@link #bindDataSource} 호출 시 4 가지
 * key 자동 등록. supplier lambda lazy invoke = registry 등록 시점에 컨테이너 startup 강제 X
 * (test method 진입 후 Spring 이 property resolve 시점에야 컨테이너 startup).
 *
 * <pre>
 * &#64;SpringBootTest
 * &#64;Tag("it")
 * class ArticleIT {
 *   &#64;DynamicPropertySource
 *   static void registerProperties(DynamicPropertyRegistry registry) {
 *     SharedPostgresContainer.bindDataSource(registry);
 *   }
 * }
 * </pre>
 *
 * <p>{@link #DEFAULT_IMAGE} = postgres 17-alpine = Spring Boot 4 + Hibernate 7 baseline.
 **/
public final class SharedPostgresContainer {

  /** Default Docker image. PG 17 = Hibernate 7 / Spring Boot 4 horizon. */
  public static final String DEFAULT_IMAGE = "postgres:17-alpine";

  /** System property key — 사용자가 환경별 PG 버전 강제 시. */
  public static final String IMAGE_PROPERTY = "rcm.test.containers.postgres.image";

  private static volatile PostgreSQLContainer<?> instance;

  private SharedPostgresContainer() {
    // utility class
  }

  /**
   * Singleton instance. 첫 호출 시 lazy startup. Docker daemon 필수.
   *
   * @return 시작된 PostgreSQL 컨테이너
   */
  public static PostgreSQLContainer<?> instance() {
    PostgreSQLContainer<?> local = instance;
    if (local == null) {
      synchronized (SharedPostgresContainer.class) {
        local = instance;
        if (local == null) {
          local = new PostgreSQLContainer<>(DockerImageName.parse(resolveImage())).withReuse(true);
          local.start();
          instance = local;
        }
      }
    }
    return local;
  }

  /**
   * Spring DataSource 4 property 자동 등록 ({@code spring.datasource.url} /
   * {@code .username} / {@code .password} / {@code .driver-class-name}). supplier lazy invoke 로
   * 본 메서드 호출 시점에 컨테이너 startup 강제 X.
   *
   * @param registry Spring Test {@link DynamicPropertyRegistry}
   */
  public static void bindDataSource(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", () -> instance().getJdbcUrl());
    registry.add("spring.datasource.username", () -> instance().getUsername());
    registry.add("spring.datasource.password", () -> instance().getPassword());
    registry.add("spring.datasource.driver-class-name", () -> instance().getDriverClassName());
  }

  static String resolveImage() {
    String fromSystem = System.getProperty(IMAGE_PROPERTY);
    if (fromSystem != null && !fromSystem.isBlank()) {
      return fromSystem;
    }
    String fromEnv = System.getenv("RCM_TEST_CONTAINERS_POSTGRES_IMAGE");
    if (fromEnv != null && !fromEnv.isBlank()) {
      return fromEnv;
    }
    return DEFAULT_IMAGE;
  }
}
