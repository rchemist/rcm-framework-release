/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0.
 */
package io.rchemist.test;

import org.springframework.boot.autoconfigure.AutoConfiguration;

/**
 * RCM Framework — Test starter 진입점.
 *
 * Phase 0 = 빈 골격. 후속 Phase 8 에서 Testcontainers default (PostgreSQL / Redis /
 * Elasticsearch / RabbitMQ) / slice test 친화 fixture / fixture builder APT 추가.
 */
@AutoConfiguration
public class RcmStarterTestAutoConfiguration {
}
