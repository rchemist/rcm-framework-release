/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/
public class NotificationProviderServiceErrorType extends EnumType<NotificationProviderServiceErrorType> implements ErrorType {

  public static final NotificationProviderServiceErrorType NOT_FOUND = new NotificationProviderServiceErrorType("NOT_FOUND", "Not Found", HttpStatus.NOT_FOUND);

  public static final NotificationProviderServiceErrorType INVALID_ALIAS = new NotificationProviderServiceErrorType("INVALID_ALIAS", "Alias 형식이 맞지 않습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationProviderServiceErrorType DUPLICATED_ALIAS = new NotificationProviderServiceErrorType("DUPLICATED_ALIAS", "이미 등록된 Alias 입니다", HttpStatus.BAD_REQUEST);

  public static final NotificationProviderServiceErrorType NOT_FOUND_ALIAS = new NotificationProviderServiceErrorType("NOT_FOUND_ALIAS", "해당 Alias로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationProviderServiceErrorType REQUIRED_ALIAS = new NotificationProviderServiceErrorType("REQUIRED_ALIAS", "Alias을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationProviderServiceErrorType REQUIRED_NAME = new NotificationProviderServiceErrorType("REQUIRED_NAME", "이름을 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final NotificationProviderServiceErrorType NOT_FOUND_ID = new NotificationProviderServiceErrorType("NOT_FOUND_ID", "해당 아이디로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationProviderServiceErrorType REQUIRED_ID = new NotificationProviderServiceErrorType("REQUIRED_ID", "아이디을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationProviderServiceErrorType REQUIRED_NOTIFICATION_TYPE = new NotificationProviderServiceErrorType("REQUIRED_NOTIFICATION_TYPE", "알림 유형을 선택해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationProviderServiceErrorType REQUIRED_PROVIDER_TYPE = new NotificationProviderServiceErrorType("REQUIRED_PROVIDER_TYPE", "메시지 프로바이더 유형을 선택해야 합니다", HttpStatus.BAD_REQUEST);

  // TODO: 필요한 에러 타입을 추가하세요.

  public NotificationProviderServiceErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }

  @Getter
  private final int status;

}