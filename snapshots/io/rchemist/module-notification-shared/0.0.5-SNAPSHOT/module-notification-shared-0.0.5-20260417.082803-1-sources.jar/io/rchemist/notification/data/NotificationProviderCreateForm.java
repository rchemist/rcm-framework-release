/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.presentation.HasAlias;
import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.notification.service.exception.NotificationProviderServiceErrorType;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationProviderCreateForm implements HasAlias<NotificationProviderCreateForm>, HasAttributes<NotificationProviderCreateForm>, CreateFormWrapper<NotificationProviderCreateForm> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected String apiKey;

  protected String apiSecret;

  protected String senderName;

  protected String senderAddress;

  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public void validate() throws ErrorTypeException {
    if (StringUtils.isEmpty(getAlias()))
      throw new NotificationProviderServiceException(NotificationProviderServiceErrorType.REQUIRED_ALIAS);

  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationProviderCreateForm that = (NotificationProviderCreateForm) o;
  
    return new EqualsBuilder()
      .append(getAlias(), that.getAlias())
      .append(getApiKey(), that.getApiKey())
      .append(getApiSecret(), that.getApiSecret())
      .append(getSenderName(), that.getSenderName())
      .append(getSenderAddress(), that.getSenderAddress())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getAlias())
      .append(getApiKey())
      .append(getApiSecret())
      .append(getSenderName())
      .append(getSenderAddress())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("alias", getAlias())
      .append("apiKey", getApiKey())
      .append("apiSecret", getApiSecret())
      .append("senderName", getSenderName())
      .append("senderAddress", getSenderAddress())
      .toString();
  }
}