/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.service.type.NotificationTemplateType;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class NotificationQueue implements Serializable {

  public NotificationQueue(NotificationType notificationType, String senderName, String senderAddress, String title, String content, TargetDTO... targets){
    this(WebRequestContext.getCurrentTenantAlias() == null ? TenantHelper.DEFAULT_TENANT_ALIAS : WebRequestContext.getCurrentTenantAlias(),
        notificationType, senderName, senderAddress, title, content, targets);
  }

  public NotificationQueue(NotificationType notificationType, String title, String content, TargetDTO... targets){
    this(WebRequestContext.getCurrentTenantAlias() == null ? TenantHelper.DEFAULT_TENANT_ALIAS : WebRequestContext.getCurrentTenantAlias(),
        notificationType, title, content, targets);
  }

  /**
   * 수신자 한명을 대상으로 하는 기본 send
   * @param tenantAlias
   * @param notificationType
   * @param senderName
   * @param senderAddress
   * @param toName
   * @param toAddress
   * @param title
   * @param content
   */
  public NotificationQueue(String tenantAlias, NotificationType notificationType, String senderName, String senderAddress
      , String toName, String toAddress
      , String title, String content){
    this(tenantAlias, notificationType, senderName, senderAddress, title, content, 
        new TargetDTO().withName(toName).withAddress(toAddress));
  }

  /**
   * toList 를 지정해야 한다.
   * @param tenantAlias
   * @param notificationType
   * @param senderName
   * @param senderAddress
   * @param title
   * @param content
   */
  public NotificationQueue(String tenantAlias, NotificationType notificationType, String senderName, String senderAddress
      , String title, String content, TargetDTO... toTarget){
    this(tenantAlias, notificationType, title, content, toTarget);
    this.senderName = senderName;
    this.senderAddress = senderAddress;
  }

  /**
   * 관리자가 발송하므로 따로 sender 정보가 필요없는 경우
   * @param tenantAlias
   * @param notificationType
   * @param title
   * @param content
   * @param targets
   */
  public NotificationQueue(String tenantAlias, NotificationType notificationType, String title, String content, TargetDTO... targets){
    this();
    initializeFields(tenantAlias, notificationType, null, null, title, content, targets);
  }

  private NotificationQueue(){

  }

  /**
   * Common initialization method to reduce constructor duplication
   */
  private void initializeFields(String tenantAlias, NotificationType notificationType, 
      String senderName, String senderAddress, String title, String content, TargetDTO... targets) {
    this.tenantAlias = tenantAlias;
    this.notificationType = notificationType;
    this.senderName = senderName;
    this.senderAddress = senderAddress;
    this.title = title;
    this.content = content;
    if (ArrayUtils.isNotEmpty(targets)) {
      this.toList = Arrays.asList(targets);
    }
  }

  public static NotificationQueue createSmsQueue(String tenantAlias, String senderAddress, String content, String... toAddress){
    return createMessageQueue(tenantAlias, senderAddress, null, StringUtil.trimBytes(content, 90), toAddress);
  }

  public static NotificationQueue createMmsQueue(String tenantAlias, String senderAddress, String title, String content, String... toAddress){
    return createMessageQueue(tenantAlias, senderAddress, title, content, toAddress);
  }

  /**
   * 관리자가 발송하여 따로 sender 정보가 필요 없는 경우
   * @param tenantAlias
   * @param content
   * @param toAddress
   * @return
   */
  public static NotificationQueue createSmsQueueByAdmin(String tenantAlias, String content, String... toAddress){
    return createMessageQueue(tenantAlias, null, null, StringUtil.trimBytes(content, 90), toAddress);
  }

  /**
   * 관리자가 발송하여 따로 sender 정보가 필요 없는 경우
   * @param tenantAlias
   * @param title
   * @param content
   * @param toAddress
   * @return
   */
  public static NotificationQueue createMmsQueueByAdmin(String tenantAlias, String title, String content, String... toAddress){
    return createMessageQueue(tenantAlias, null, title, content, toAddress);
  }

  /**
   * Common factory method for creating SMS/MMS queues
   */
  private static NotificationQueue createMessageQueue(String tenantAlias, String senderAddress, 
      String title, String content, String... toAddress) {
    NotificationQueue queue = new NotificationQueue();
    queue.setNotificationType(NotificationType.SMS);
    queue.tenantAlias = tenantAlias;
    queue.senderAddress = senderAddress;
    queue.title = title;
    queue.content = content;

    if (ArrayUtils.isNotEmpty(toAddress)) {
      for (String to : toAddress) {
        queue.addTo(null, to);
      }
    }

    return queue;
  }

  @NotNull
  protected String tenantAlias;

  @NotNull
  protected NotificationType notificationType;

  protected NotificationTemplateType notificationTemplateType;

  protected String notificationProviderType;    // NotificationProviderType 을 직접 지정해서 요청하는 경우

  protected String senderName;

  @NotNull
  protected String senderAddress;

  protected String title;

  @NotNull
  protected String content;

  protected String messageKey;

  // nullable
  // userId 가 지정되어 있다면 메시지 발송이 모두 끝난 후 해당 메시지를 user 에 저장한다.
  protected String userId;

  protected boolean skipHistory = false;

  protected Map<String, String> attributes = new HashMap<>();   // 문자열 치환 등의 목적으로 사용한다.

  protected Map<String, Object> modelMap = new HashMap<>();   // 템플릿 파싱에 사용된 모델맵을 전달한다, history 에는 저장되지 않는다.

  protected List<TargetDTO> toList = new ArrayList<>();
  protected List<TargetDTO> ccList = new ArrayList<>();
  protected List<TargetDTO> bccList = new ArrayList<>();

  public NotificationQueue withNotificationProviderType(String notificationProviderType) {
    this.notificationProviderType = notificationProviderType;
    return this;
  }

  public NotificationQueue withToList(
      List<TargetDTO> toList) {
    this.toList = toList;
    return this;
  }

  public NotificationQueue withCcList(
      List<TargetDTO> ccList) {
    this.ccList = ccList;
    return this;
  }

  public NotificationQueue withBccList(
      List<TargetDTO> bccList) {
    this.bccList = bccList;
    return this;
  }

  public NotificationQueue addTo(String name, String address){
    this.toList.add(new TargetDTO().withName(name).withAddress(address));
    return this;
  }

  public NotificationQueue addCc(String name, String address){
    this.ccList.add(new TargetDTO().withName(name).withAddress(address));
    return this;
  }

  public NotificationQueue addBcc(String name, String address){
    this.bccList.add(new TargetDTO().withName(name).withAddress(address));
    return this;
  }

  public String getSenderNameAddress(){
    if(StringUtils.isBlank(senderName))
      return senderAddress;
    return senderName + "<"+senderAddress+">";
  }

  public List<String> collectToList(){
    if(CollectionUtils.isNotEmpty(toList)){
      return toList.stream().map(TargetDTO::getNameAddress)
          .collect(Collectors.toList());
    }
    return null;
  }

  public List<String> collectCcList(){
    if(CollectionUtils.isNotEmpty(ccList)){
      return ccList.stream().map(TargetDTO::getNameAddress)
          .collect(Collectors.toList());
    }
    return null;
  }

  public List<String> collectBccList(){
    if(CollectionUtils.isNotEmpty(bccList)){
      return bccList.stream().map(TargetDTO::getNameAddress)
          .collect(Collectors.toList());
    }
    return null;
  }

  public String getToListToString(){
    List<String> list = collectToList();
    return (list == null) ? null : StringUtil.merge(list, ",");
  }

  public String getCcListToString(){
    List<String> list = collectCcList();
    return (list == null) ? null : StringUtil.merge(list, ",");
  }

  public String getBccListToString(){
    List<String> list = collectBccList();
    return (list == null) ? null : StringUtil.merge(list, ",");
  }

  public String getTitle() {
    return title == null ? "BLANK" : title.replaceAll("<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "");
  }

  public NotificationQueue withAttributes(
      Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public NotificationQueue addAttribute(String key, String value){
    this.attributes.put(key, value);
    return this;
  }

  public NotificationQueue withNotificationType(
      NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }

  public NotificationQueue withTitle(String title) {
    this.title = title;
    return this;
  }

  public NotificationQueue withContent(String content) {
    this.content = content;
    return this;
  }

  public NotificationQueue withNotificationTemplateType(
      NotificationTemplateType notificationTemplateType) {
    this.notificationTemplateType = notificationTemplateType;
    return this;
  }

  public NotificationQueue withSenderName(String senderName) {
    this.senderName = senderName;
    return this;
  }

  public NotificationQueue withSenderAddress(String senderAddress) {
    this.senderAddress = senderAddress;
    return this;
  }

  public NotificationQueue withMessageKey(String messageKey) {
    this.messageKey = messageKey;
    return this;
  }

  public NotificationQueue withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public NotificationQueue withModelMap(Map<String, Object> modelMap) {
    this.modelMap = modelMap;
    return this;
  }

  public NotificationQueue withSkipHistory(boolean skipHistory) {
    this.skipHistory = skipHistory;
    return this;
  }

  public Object getModel(String key){
    if(modelMap == null){
      return null;
    }
    return modelMap.get(key);
  }

  public String getAttribute(String key){
    if(attributes == null){
      return null;
    }
    return attributes.get(key);
  }

  @JsonIgnore
  public boolean isSkipHistory() {
    return BooleanUtils.toBoolean(skipHistory);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("tenantAlias", tenantAlias)
        .append("notificationType", notificationType)
        .append("notificationProviderType", notificationProviderType)
        .append("senderName", senderName)
        .append("senderAddress", senderAddress)
        .append("title", title)
        .append("messageKey", messageKey)
        .append("content", content)
        .append("toList", toList)
        .append("ccList", ccList)
        .append("bccList", bccList)
        .append("userId", userId)
        .toString();
  }

}
