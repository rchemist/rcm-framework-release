/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.exception;

import io.rchemist.common.exception.ErrorTypeException;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/
public class NotificationTemplateServiceException extends ErrorTypeException {

  public NotificationTemplateServiceException(NotificationTemplateServiceErrorType errorType){
    super(errorType);
  }

  public NotificationTemplateServiceException(String propertyName, NotificationTemplateServiceErrorType errorType){
    super(propertyName, errorType);
  }

  public NotificationTemplateServiceException(String propertyName, String message){
    super(propertyName, message);
  }

  public NotificationTemplateServiceException(String message, Throwable cause){
    super(message, cause);
  }

  public NotificationTemplateServiceException(String message){
    super(message);
  }

  public NotificationTemplateServiceException(Exception e){
    super(e);
    if (e instanceof ErrorTypeException errorTypeException) {
      errorTypeException.copyException(this);
    }
  }}