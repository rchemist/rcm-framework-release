/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationTemplateResult implements Serializable {

  protected String title;

  protected String content;

  protected Map<String, String> attributes = new HashMap<>();

  public NotificationTemplateResult withTitle(String title) {
    this.title = title;
    return this;
  }

  public NotificationTemplateResult withContent(String content) {
    this.content = content;
    return this;
  }

  public NotificationTemplateResult withAttributes(
      Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public NotificationTemplateResult addAttribute(String key, String value){
    this.attributes.put(key, value);
    return this;
  }
}
