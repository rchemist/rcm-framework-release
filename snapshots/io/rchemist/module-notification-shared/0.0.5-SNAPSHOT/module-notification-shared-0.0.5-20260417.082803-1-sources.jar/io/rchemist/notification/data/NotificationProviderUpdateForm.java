/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationProviderUpdateForm implements HasId<NotificationProviderUpdateForm>, HasActive<NotificationProviderUpdateForm>, HasAttributes<NotificationProviderUpdateForm>, UpdateFormWrapper<NotificationProviderUpdateForm, Long> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected String apiKey;

  protected String apiSecret;

  protected String senderName;

  protected String senderAddress;

  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public void validate() throws ErrorTypeException {

  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationProviderUpdateForm that = (NotificationProviderUpdateForm) o;
  
    return new EqualsBuilder()
      .append(getApiKey(), that.getApiKey())
      .append(getApiSecret(), that.getApiSecret())
      .append(getSenderName(), that.getSenderName())
      .append(getSenderAddress(), that.getSenderAddress())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getApiKey())
      .append(getApiSecret())
      .append(getSenderName())
      .append(getSenderAddress())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("apiKey", getApiKey())
      .append("apiSecret", getApiSecret())
      .append("senderName", getSenderName())
      .append("senderAddress", getSenderAddress())
      .toString();
  }
}