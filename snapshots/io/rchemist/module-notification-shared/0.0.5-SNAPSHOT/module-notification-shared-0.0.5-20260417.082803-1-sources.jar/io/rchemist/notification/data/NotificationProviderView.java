/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAlias;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditCreated;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditUpdated;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.service.type.NotificationProviderType;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationProviderView implements HasAlias<NotificationProviderView>, HasAuditCreated<NotificationProviderView>, HasAuditUpdated<NotificationProviderView>, HasActive<NotificationProviderView>, HasTenantAlias<NotificationProviderView>, HasId<NotificationProviderView> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Long id;



  protected String name;

  protected NotificationProviderType notificationProviderType;

  protected NotificationType notificationType;

  protected String apiKey;

  protected String apiSecret;

  protected String senderName;

  protected String senderAddress;


  public NotificationProviderView withName(String name) {
    this.name = name;
    return this;
  }

  public NotificationProviderView withNotificationProviderType(NotificationProviderType notificationProviderType) {
    this.notificationProviderType = notificationProviderType;
    return this;
  }

  public NotificationProviderView withNotificationType(NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }

  public NotificationProviderView withApiKey(String apiKey) {
    this.apiKey = apiKey;
    return this;
  }

  public NotificationProviderView withApiSecret(String apiSecret) {
    this.apiSecret = apiSecret;
    return this;
  }

  public NotificationProviderView withSenderName(String senderName) {
    this.senderName = senderName;
    return this;
  }

  public NotificationProviderView withSenderAddress(String senderAddress) {
    this.senderAddress = senderAddress;
    return this;
  }



  // TODO 필요한 필드가 있다면 추가하세요.


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationProviderView that = (NotificationProviderView) o;
  
    return new EqualsBuilder()
      .append(getAlias(), that.getAlias())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getUpdatedBy(), that.getUpdatedBy())
      .append(getUpdatedAt(), that.getUpdatedAt())
      .append(getActive(), that.getActive())
      .append(getTenantAlias(), that.getTenantAlias())
      .append(getName(), that.getName())
      .append(getNotificationProviderType(), that.getNotificationProviderType())
      .append(getNotificationType(), that.getNotificationType())
      .append(getApiKey(), that.getApiKey())
      .append(getApiSecret(), that.getApiSecret())
      .append(getSenderName(), that.getSenderName())
      .append(getSenderAddress(), that.getSenderAddress())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getAlias())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getUpdatedBy())
      .append(getUpdatedAt())
      .append(getActive())
      .append(getTenantAlias())
      .append(getName())
      .append(getNotificationProviderType())
      .append(getNotificationType())
      .append(getApiKey())
      .append(getApiSecret())
      .append(getSenderName())
      .append(getSenderAddress())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("alias", getAlias())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("updatedBy", getUpdatedBy())
      .append("updatedAt", getUpdatedAt())
      .append("active", getActive())
      .append("tenantAlias", getTenantAlias())
      .append("name", getName())
      .append("notificationProviderType", getNotificationProviderType())
      .append("notificationType", getNotificationType())
      .append("apiKey", getApiKey())
      .append("apiSecret", getApiSecret())
      .append("senderName", getSenderName())
      .append("senderAddress", getSenderAddress())
      .toString();
  }
}