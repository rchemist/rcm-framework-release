/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TargetDTO implements Serializable {

  protected String name;

  protected String address;

  public TargetDTO withName(String name) {
    this.name = name;
    return this;
  }

  public TargetDTO withAddress(String address) {
    this.address = address;
    return this;
  }

  public String getName() {
    return StringUtil.toString(name, address);
  }

  public String getNameAddress(){
    if(StringUtils.isEmpty(name))
      return address;
    return name + "<" +address+ ">";
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("name", name)
        .append("address", address)
        .toString();
  }
}
