/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.domain.type.NotificationType;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationProviderType extends EnumType<NotificationProviderType> {

  private static final String PREFIX = "notification.provider.type.";

  private NotificationProviderType(){

  }

  private NotificationProviderType(int order, String type, String description, NotificationType notificationType, String[] requiredAttributes) {
    super(order, type, description, description, PREFIX + StringUtils.replace(StringUtils.lowerCase(type), "_", "."));
    this.notificationType = notificationType;
    this.requiredAttributes = requiredAttributes;
  }

  /**
   * 이 공급자의 NotificationType
   */
  @Getter
  protected NotificationType notificationType;

  /**
   * 관리자도구에서 공급자를 설정할 때 반드시 필요한 추가 정보
   */
  @Getter
  protected String[] requiredAttributes;

  /**
   * Provider 를 등록하면 NotificationProviderType 이 자동으로 생성된다.
   * {@link NotifyProviderManager#onApplicationEvent(ApplicationReadyEvent)}
   * @param order
   * @param type
   * @param notificationType
   * @return
   */
  public static NotificationProviderType create(int order, String type, String name, NotificationType notificationType, String[] requiredAttributes){
    return new NotificationProviderType(order, type, name, notificationType, requiredAttributes);
  }

}
