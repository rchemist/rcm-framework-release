/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationHistoryUpdateForm implements HasId<NotificationHistoryUpdateForm>, UpdateFormWrapper<NotificationHistoryUpdateForm, Long> {

  @Serial
  private static final long serialVersionUID = 1L;

  // notification History 는 update 를 지원하지 않는다.

}