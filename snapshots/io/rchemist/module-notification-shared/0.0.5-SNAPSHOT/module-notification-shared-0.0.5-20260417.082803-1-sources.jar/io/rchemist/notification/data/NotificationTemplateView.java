/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditCreated;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditUpdated;
import io.rchemist.common.persistence.domain.template.presentation.HasExternalId;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.service.type.NotificationTemplateType;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationTemplateView implements HasAuditCreated<NotificationTemplateView>,
    HasAttributes<NotificationTemplateView>,
    HasAuditUpdated<NotificationTemplateView>, HasExternalId<NotificationTemplateView>, HasNameDescription<NotificationTemplateView>, HasTenantAlias<NotificationTemplateView>, HasId<NotificationTemplateView>,
    HasTags<NotificationTemplateView> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Long id;



  protected String title;

  protected String sourceCode;

  protected String customAlias;

  protected NotificationTemplateType notificationTemplateType;

  protected NotificationType notificationType;


  public NotificationTemplateView withTitle(String title) {
    this.title = title;
    return this;
  }

  public NotificationTemplateView withSourceCode(String sourceCode) {
    this.sourceCode = sourceCode;
    return this;
  }

  public NotificationTemplateView withCustomAlias(String customAlias) {
    this.customAlias = customAlias;
    return this;
  }

  public NotificationTemplateView withNotificationTemplateType(NotificationTemplateType notificationTemplateType) {
    this.notificationTemplateType = notificationTemplateType;
    return this;
  }

  public NotificationTemplateView withNotificationType(NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationTemplateView that = (NotificationTemplateView) o;
  
    return new EqualsBuilder()
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getUpdatedBy(), that.getUpdatedBy())
      .append(getUpdatedAt(), that.getUpdatedAt())
      .append(getExternalId(), that.getExternalId())
      .append(getName(), that.getName())
      .append(getDescription(), that.getDescription())
      .append(getTenantAlias(), that.getTenantAlias())
      .append(getTitle(), that.getTitle())
      .append(getSourceCode(), that.getSourceCode())
      .append(getCustomAlias(), that.getCustomAlias())
      .append(getNotificationTemplateType(), that.getNotificationTemplateType())
      .append(getNotificationType(), that.getNotificationType())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getUpdatedBy())
      .append(getUpdatedAt())
      .append(getExternalId())
      .append(getName())
      .append(getDescription())
      .append(getTenantAlias())
      .append(getTitle())
      .append(getSourceCode())
      .append(getCustomAlias())
      .append(getNotificationTemplateType())
      .append(getNotificationType())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("updatedBy", getUpdatedBy())
      .append("updatedAt", getUpdatedAt())
      .append("externalId", getExternalId())
      .append("name", getName())
      .append("description", getDescription())
      .append("tenantAlias", getTenantAlias())
      .append("title", getTitle())
      .append("sourceCode", getSourceCode())
      .append("customAlias", getCustomAlias())
      .append("notificationTemplateType", getNotificationTemplateType())
      .append("notificationType", getNotificationType())
      .toString();
  }
}