/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/
public class NotificationTemplateServiceErrorType extends EnumType<NotificationTemplateServiceErrorType> implements ErrorType {

  public static final NotificationTemplateServiceErrorType NOT_FOUND = new NotificationTemplateServiceErrorType("NOT_FOUND", "Not Found", HttpStatus.NOT_FOUND);

  public static final NotificationTemplateServiceErrorType NOT_FOUND_ID = new NotificationTemplateServiceErrorType("NOT_FOUND_ID", "해당 아이디로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType REQUIRED_ID = new NotificationTemplateServiceErrorType("REQUIRED_ID", "아이디을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType NOT_FOUND_EXTERNALID = new NotificationTemplateServiceErrorType("NOT_FOUND_EXTERNALID", "해당 External ID로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType REQUIRED_EXTERNALID = new NotificationTemplateServiceErrorType("REQUIRED_EXTERNALID", "External ID을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType INVALID_NAME = new NotificationTemplateServiceErrorType("INVALID_NAME", "이름 형식이 맞지 않습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType DUPLICATED_EXTERNALID = new NotificationTemplateServiceErrorType("DUPLICATED_EXTERNALID", "동일한 외부 연동 ID가 이미 등록되었습니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType DUPLICATED_NAME = new NotificationTemplateServiceErrorType("DUPLICATED_NAME", "이미 등록된 이름 입니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType NOT_FOUND_NAME = new NotificationTemplateServiceErrorType("NOT_FOUND_NAME", "해당 이름으로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationTemplateServiceErrorType REQUIRED_NAME = new NotificationTemplateServiceErrorType("REQUIRED_NAME", "이름을 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType REQUIRED_TITLE = new NotificationTemplateServiceErrorType("REQUIRED_TITLE", "제목을 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType REQUIRED_SOURCE = new NotificationTemplateServiceErrorType("REQUIRED_SOURCE", "템플릿 코드를 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType REQUIRED_TEMPLATE_TYPE = new NotificationTemplateServiceErrorType("REQUIRED_TEMPLATE_TYPE", "템플릿 유형을 선택해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType REQUIRED_TYPE = new NotificationTemplateServiceErrorType("REQUIRED_TYPE", "알림 유형을 선택해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType DUPLICATED_TYPE = new NotificationTemplateServiceErrorType("DUPLICATED_TYPE", "이미 동일한 유형의 템플릿이 등록되어 있습니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType REQUIRED_CUSTOM_ALIAS = new NotificationTemplateServiceErrorType("REQUIRED_CUSTOM_ALIAS", "사용자정의 템플릿 유형을 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final NotificationTemplateServiceErrorType TEMPLATE_NOT_FOUND = new NotificationTemplateServiceErrorType("TEMPLATE_NOT_FOUND", "지정된 메시지 템플릿이 등록되어 있지 않습니다", HttpStatus.BAD_REQUEST);

  // TODO: 필요한 에러 타입을 추가하세요.

  public NotificationTemplateServiceErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }

  @Getter
  private final int status;

}