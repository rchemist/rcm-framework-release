/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.cache.data.CacheData;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.service.type.NotificationProviderType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class NotificationProviderCache extends CacheData {

  public static final String CACHE_NAME = "notification-providers";

  private List<ProviderCacheItem> providers = new ArrayList<>();

  public NotificationProviderCache() {
    super(60 * 24 * 365);
  }

  public void addProvider(int priority, String name, String alias, NotificationProviderType type) {
    ProviderCacheItem dto = new ProviderCacheItem()
        .withPriority(priority)
        .withName(name)
        .withAlias(alias)
        .withNotificationType(type.getNotificationType())
        .withNotificationProviderType(type);
    this.providers.add(dto);
    Collections.sort(providers, Comparator.comparing(ProviderCacheItem::getPriority));
  }

  public ProviderCacheItem getProvider(String alias) {
    for(ProviderCacheItem item : CollectionUtils.emptyIfNull(getProviders())) {
      if(StringUtils.equals(item.getAlias(), alias)) {
        return item;
      }
    }
    return null;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public static class ProviderCacheItem implements Serializable {

    protected Integer priority;

    protected String name;

    protected String alias;

    protected NotificationProviderType notificationProviderType;

    protected NotificationType notificationType;

    public ProviderCacheItem withPriority(Integer priority) {
      this.priority = priority;
      return this;
    }

    public ProviderCacheItem withName(String name) {
      this.name = name;
      return this;
    }

    public ProviderCacheItem withAlias(String alias) {
      this.alias = alias;
      return this;
    }

    public ProviderCacheItem withNotificationProviderType(
        NotificationProviderType notificationProviderType) {
      this.notificationProviderType = notificationProviderType;
      return this;
    }

    public ProviderCacheItem withNotificationType(
        NotificationType notificationType) {
      this.notificationType = notificationType;
      return this;
    }

  }

}
