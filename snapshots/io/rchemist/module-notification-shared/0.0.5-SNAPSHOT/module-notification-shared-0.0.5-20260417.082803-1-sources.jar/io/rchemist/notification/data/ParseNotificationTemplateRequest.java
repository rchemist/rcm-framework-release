/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.service.type.NotificationTemplateType;
import java.util.HashMap;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@EqualsAndHashCode
@ToString
public class ParseNotificationTemplateRequest implements HasTenantAlias<ParseNotificationTemplateRequest> {

  protected NotificationTemplateType notificationTemplateType;

  protected NotificationType notificationType;

  protected String customAlias;   // Notification.customAlias   // NotificationTemplateType 이 custom 인 경우 customAlias 와 함께 값이 전송되어야 한다.

  protected String messageKey;

  protected Map<String, Object> modelMap = new HashMap<>();

  public ParseNotificationTemplateRequest(String tenantAlias, NotificationType notificationType, NotificationTemplateType notificationTemplateType) {
    setTenantAlias(tenantAlias);
    this.notificationTemplateType = notificationTemplateType;
    this.notificationType = notificationType;
  }

  public ParseNotificationTemplateRequest withModelMap(
      Map<String, Object> modelMap) {
    this.modelMap = modelMap;
    return this;
  }

  public ParseNotificationTemplateRequest addModelMap(String key, Object value){
    this.modelMap.put(key, value);
    return this;
  }

  public ParseNotificationTemplateRequest withCustomAlias(String customAlias) {
    this.customAlias = customAlias;
    return this;
  }

  public ParseNotificationTemplateRequest withMessageKey(String messageKey) {
    this.messageKey = messageKey;
    return this;
  }
}
