/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.presentation.HasExternalId;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.notification.service.type.NotificationTemplateType;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationTemplateUpdateForm implements HasExternalId<NotificationTemplateUpdateForm>, HasNameDescription<NotificationTemplateUpdateForm>, HasId<NotificationTemplateUpdateForm>, UpdateFormWrapper<NotificationTemplateUpdateForm, Long>,
    HasTags<NotificationTemplateUpdateForm> {

  @Serial
  private static final long serialVersionUID = 1L;



  protected String title;

  protected String sourceCode;

  protected String customAlias;

  protected NotificationTemplateType notificationTemplateType;

  protected NotificationType notificationType;


  public NotificationTemplateUpdateForm withTitle(String title) {
    this.title = title;
    return this;
  }

  public NotificationTemplateUpdateForm withSourceCode(String sourceCode) {
    this.sourceCode = sourceCode;
    return this;
  }

  public NotificationTemplateUpdateForm withCustomAlias(String customAlias) {
    this.customAlias = customAlias;
    return this;
  }

  public NotificationTemplateUpdateForm withNotificationTemplateType(NotificationTemplateType notificationTemplateType) {
    this.notificationTemplateType = notificationTemplateType;
    return this;
  }

  public NotificationTemplateUpdateForm withNotificationType(NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }



  // TODO 필요한 필드가 있다면 추가하세요.

  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public void validate() throws ErrorTypeException {
    // TODO: 필요한 validation을 추가하세요.
  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationTemplateUpdateForm that = (NotificationTemplateUpdateForm) o;
  
    return new EqualsBuilder()
      .append(getExternalId(), that.getExternalId())
      .append(getName(), that.getName())
      .append(getDescription(), that.getDescription())
      .append(getTitle(), that.getTitle())
      .append(getSourceCode(), that.getSourceCode())
      .append(getCustomAlias(), that.getCustomAlias())
      .append(getNotificationTemplateType(), that.getNotificationTemplateType())
      .append(getNotificationType(), that.getNotificationType())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getExternalId())
      .append(getName())
      .append(getDescription())
      .append(getTitle())
      .append(getSourceCode())
      .append(getCustomAlias())
      .append(getNotificationTemplateType())
      .append(getNotificationType())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("externalId", getExternalId())
      .append("name", getName())
      .append("description", getDescription())
      .append("title", getTitle())
      .append("sourceCode", getSourceCode())
      .append("customAlias", getCustomAlias())
      .append("notificationTemplateType", getNotificationTemplateType())
      .append("notificationType", getNotificationType())
      .toString();
  }
}