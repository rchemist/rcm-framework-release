/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import java.io.Serial;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationHistoryCreateForm implements HasContents<NotificationHistoryCreateForm>, HasTenantAlias<NotificationHistoryCreateForm>, CreateFormWrapper<NotificationHistoryCreateForm> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected NotificationType notificationType;

  protected String userId;

  protected List<String> toList = new ArrayList<>();

  protected List<String> ccList = new ArrayList<>();

  protected List<String> bccList = new ArrayList<>();

  protected String mergeTarget;

  protected List<String> getTargetListIds = new ArrayList<>();

  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public void validate() throws ErrorTypeException {

  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NotificationHistoryCreateForm that = (NotificationHistoryCreateForm) o;
    return Objects.equals(notificationType, that.notificationType) && Objects.equals(userId, that.userId) && Objects.equals(toList, that.toList)
        && Objects.equals(ccList, that.ccList) && Objects.equals(bccList, that.bccList) && Objects.equals(mergeTarget, that.mergeTarget) && Objects.equals(
        getTargetListIds, that.getTargetListIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(notificationType, userId, toList, ccList, bccList, mergeTarget, getTargetListIds);
  }

  @Override
  public String toString() {
    return new StringJoiner(", ", NotificationHistoryCreateForm.class.getSimpleName() + "[", "]")
        .add("notificationType=" + notificationType)
        .add("userId='" + userId + "'")
        .add("toList=" + toList)
        .add("ccList=" + ccList)
        .add("bccList=" + bccList)
        .add("mergeTarget='" + mergeTarget + "'")
        .add("getTargetListIds=" + getTargetListIds)
        .toString();
  }
}