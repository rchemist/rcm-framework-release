/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotifyServiceErrorType extends EnumType<NotifyServiceErrorType> implements ErrorType {

  public static final NotifyServiceErrorType WRONG_VALUES = new NotifyServiceErrorType("WRONG_VALUES", "wrong values are requested.", "잘못된 정보가 입력되었습니다.", "wrong.values", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType NO_CACHED_PROVIDERS = new NotifyServiceErrorType("NO_CACHED_PROVIDERS", "There is no cached message providers.", "등록된 메시지 프로바이더가 존재하지 않습니다.", "no.cached.providers", HttpStatus.NOT_FOUND);
  public static final NotifyServiceErrorType NOTIFICATION_TYPE_REQUIRED = new NotifyServiceErrorType("NOTIFICATION_TYPE_REQUIRED", "NotificationType is required.", "알림 유형이 설정되지 않았습니다.", "notification.type.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType NOTIFICATION_TEMPLATE_TYPE_REQUIRED = new NotifyServiceErrorType("NOTIFICATION_TEMPLATE_TYPE_REQUIRED", "NotificationTemplateType is required.", "알림 템플릿 유형이 설정되지 않았습니다.", "notification.template.type.required", HttpStatus.BAD_REQUEST);

  public static final NotifyServiceErrorType TENANT_ALIAS_REQUIRED = new NotifyServiceErrorType("TENANT_ALIAS_REQUIRED", "Tenant alias is required", "TENANT ALIAS 정보가 필요합니다.", "tenant.alias.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType TEMPLATE_PATH_REQUIRED = new NotifyServiceErrorType("TEMPLATE_PATH_REQUIRED", "TemplatePath is required", "TEMPLATE PATH 정보가 필요합니다.", "template.path.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType TEMPLATE_NOT_FOUND = new NotifyServiceErrorType("TEMPLATE_NOT_FOUND", "Template is not found", "TEMPLATE 이 존재하지 않습니다.", "template.not.found", HttpStatus.NOT_FOUND);
  public static final NotifyServiceErrorType NO_ID = new NotifyServiceErrorType("NO_ID", "ID is required.", "ID 정보가 필요합니다.", "id.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType NAME_REQUIRED = new NotifyServiceErrorType("NAME_REQUIRED", "Name is required.", "이름을 입력해야 합니다.", "name.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType SOURCE_CODE_REQUIRED = new NotifyServiceErrorType("SOURCE_CODE_REQUIRED", "SourceCode is required.", "소스코드를 입력해야 합니다.", "source.code.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType DUPLICATED = new NotifyServiceErrorType("DUPLICATED", "Template is duplicated.", "이미 같은 경로의 템플릿이 존재합니다.", "duplicated", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType AWS_SES_SETTING_ERROR = new NotifyServiceErrorType("AWS_SES_SETTING_ERROR", "AWS SES settings are not valid", "AWS SES 프로바이더 설정에 오류가 있습니다. Provider의 region, access-key, secret-key 값을 다시 확인해 주세요.", "", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final NotifyServiceErrorType MESSAGE_KEY_REQUIRED = new NotifyServiceErrorType("MESSAGE_KEY_REQUIRED", "MessageKey is required.", "메시지 코드를 입력해야 합니다.", "messagekey.required", HttpStatus.BAD_REQUEST);
  public static final NotifyServiceErrorType CUSTOM_ALIAS_REQUIRED = new NotifyServiceErrorType("CUSTOM_ALIAS_REQUIRED", "CustomAlias is required.", "Custom Alias를 입력해야 합니다.", "customalias.required", HttpStatus.BAD_REQUEST);


  public static final NotifyServiceErrorType NO_SESSION = new NotifyServiceErrorType("NO_SESSION", "No current session.", "이 서비스를 이용하려면 먼저 로그인해야 합니다.", "no.session", HttpStatus.UNAUTHORIZED);
  public static final NotifyServiceErrorType NO_HISTORY = new NotifyServiceErrorType("NO_HISTORY", "No history.", "정보가 존재하지 않습니다.", "no.history", HttpStatus.NOT_FOUND);
  public static final NotifyServiceErrorType NOT_OWNED_HISTORY = new NotifyServiceErrorType("NOT_OWNED_HISTORY", "Not owned history.", "자신이 소유한 데이터만 조회할 수 있습니다.", "no.session", HttpStatus.FORBIDDEN);


  @Getter
  private final int status;

  public NotifyServiceErrorType(String type, String friendlyType, String description, String messageKey, HttpStatus status) {
    super(1, type, friendlyType, description, messageKey);
    this.status = status.value();
  }

  private NotifyServiceErrorType() {
    this.status = 500;
  }
}
