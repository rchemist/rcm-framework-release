/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;


/**
 * <p>
 * Project : Rchemist Platform
 * </p>
 * Created by kunner
 **/
public class NotificationHistoryServiceErrorType extends EnumType<NotificationHistoryServiceErrorType> implements ErrorType {

  public static final NotificationHistoryServiceErrorType NOT_FOUND = new NotificationHistoryServiceErrorType("NOT_FOUND", "Not Found", HttpStatus.NOT_FOUND);

  public static final NotificationHistoryServiceErrorType REQUIRED_TITLE = new NotificationHistoryServiceErrorType("REQUIRED_TITLE", "제목을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final NotificationHistoryServiceErrorType REQUIRED_CONTENT = new NotificationHistoryServiceErrorType("REQUIRED_CONTENT", "내용을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final NotificationHistoryServiceErrorType NOT_FOUND_ID = new NotificationHistoryServiceErrorType("NOT_FOUND_ID", "해당 ID로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final NotificationHistoryServiceErrorType REQUIRED_ID = new NotificationHistoryServiceErrorType("REQUIRED_ID", "ID을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public NotificationHistoryServiceErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }

  @Getter
  private final int status;

}