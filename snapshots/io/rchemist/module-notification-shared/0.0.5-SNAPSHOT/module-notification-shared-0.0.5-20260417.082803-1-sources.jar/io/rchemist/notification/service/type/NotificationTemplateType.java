/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationTemplateType extends EnumType<NotificationTemplateType> {

  public static final NotificationTemplateType CUSTOM = new NotificationTemplateType(Integer.MIN_VALUE, "CUSTOM", "사용자 정의", "custom");

  public static final NotificationTemplateType USER_REGISTERED = new NotificationTemplateType(100, "USER_REGISTERED", "고객 - 회원가입 완료", "customer.registered");
  public static final NotificationTemplateType USER_UPDATED = new NotificationTemplateType(200, "USER_UPDATED", "고객 - 정보 수정 완료", "customer.updated");
  public static final NotificationTemplateType USER_LOGGED_IN = new NotificationTemplateType(300, "USER_LOGGED_IN", "고객 - 로그인", "customer.logged.in");
  public static final NotificationTemplateType USER_LOGGED_IN_NEW_DEVICE = new NotificationTemplateType(400, "USER_LOGGED_IN_NEW_DEVICE", "고객 - 새 장치에서 로그인", "customer.logged.in.new.device");
  public static final NotificationTemplateType USER_LOGIN_FAILED = new NotificationTemplateType(500, "USER_LOGIN_FAILED", "고객 - 제한 횟수 이상 로그인 실패", "customer.login.failed");
  public static final NotificationTemplateType USER_ACTIVATED = new NotificationTemplateType(600, "USER_ACTIVATED", "고객 - 활성화 전환", "customer.activated");
  public static final NotificationTemplateType USER_DEACTIVATED = new NotificationTemplateType(700, "USER_DEACTIVATED", "고객 - 비활성화 전환", "customer.deactivated");
  public static final NotificationTemplateType USER_SECEDED = new NotificationTemplateType(800, "USER_SECEDED", "고객 - 회원탈퇴 완료", "customer.seceded");
  public static final NotificationTemplateType USER_SECEDE_NOTIFICATION = new NotificationTemplateType(900, "USER_SECEDE_NOTIFICATION", "고객 - 장기 미사용 회원탈퇴 안내", "customer.secede.notification");
  public static final NotificationTemplateType USER_DORMANT = new NotificationTemplateType(1000, "USER_DORMANT", "고객 - 휴면 처리", "customer.dormant");
  public static final NotificationTemplateType USER_DORMANT_RELEASE = new NotificationTemplateType(1100, "USER_DORMANT_RELEASE", "고객 - 휴면 해제", "customer.dormant.release");
  public static final NotificationTemplateType USER_DORMANT_NOTIFICATION = new NotificationTemplateType(1200, "USER_DORMANT_NOTIFICATION", "고객 - 휴면 처리 안내", "customer.dormant.notification");

  public static final NotificationTemplateType USER_FIND_ID_OR_PASSWORD = new NotificationTemplateType(1300, "USER_FIND_ID_OR_PASSWORD", "고객 - 회원정보 찾기", "customer.find.id.or.password");
  public static final NotificationTemplateType USER_EMAIL_AUTH = new NotificationTemplateType(1400, "USER_EMAIL_AUTH", "고객 - 이메일 인증", "customer.email.auth");

  public static final NotificationTemplateType INQUIRY_REPLIED = new NotificationTemplateType(2000, "INQUIRY_REPLIED", "1:1 문의 - 문의 답변 완료", "inquiry.replied");

  public static final NotificationTemplateType PROFILE_SUBSCRIBED = new NotificationTemplateType(3000, "PROFILE_SUBSCRIBED", "구독 - 프로필 구독 신청", "profile.subscribed");

  public static final NotificationTemplateType ARTICLE_CREATED = new NotificationTemplateType(4000, "ARTICLE_CREATED", "게시물 - 게시물 등록", "article.created");
  public static final NotificationTemplateType ARTICLE_APPROVED = new NotificationTemplateType(4100, "ARTICLE_APPROVED", "게시물 - 게시물 승인", "article.approved");
  public static final NotificationTemplateType ARTICLE_COMMENT_REPLIED = new NotificationTemplateType(4200, "ARTICLE_COMMENT_REPLIED", "댓글 - 게시물 댓글 등록", "article.comment.replied");

  public static final NotificationTemplateType CONTRACT_MARKETING_NOTIFICATION = new NotificationTemplateType(5000, "CONTRACT_MARKETING_NOTIFICATION", "약관 - 마케팅 수신 동의 안내", "contract.marketing.notification");
  public static final NotificationTemplateType CONTRACT_PRIVACY_NOTIFICATION = new NotificationTemplateType(5100, "CONTRACT_PRIVACY_NOTIFICATION", "약관 - 개인정보 이용 내역 안내", "contract.marketing.notification");

  public static final NotificationTemplateType ONE_TIME_PASSWORD = new NotificationTemplateType(6000, "ONE_TIME_PASSWORD", "OneTimePassword", "one.time.password");
  public static final NotificationTemplateType REPORT = new NotificationTemplateType(10000, "REPORT", "리포트", "report");

  public static final NotificationTemplateType ADMIN_FIND_ID_OR_PASSWORD = new NotificationTemplateType(11000000, "ADMIN_FIND_ID_OR_PASSWORD", "관리자도구 - 아이디/비밀번호 찾기", "admin.find.id.or.password");

  public NotificationTemplateType(int order, String type,
      String description, String messageKey) {
    super(order, type, type, description, messageKey);
  }

  private NotificationTemplateType() {
  }
}
