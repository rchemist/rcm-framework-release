/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditCreated;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.TargetDTO;
import java.io.Serial;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : Rchemist Platform
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class NotificationHistoryView implements HasContents<NotificationHistoryView>, HasAttributes<NotificationHistoryView>, HasAuditCreated<NotificationHistoryView>, HasTenantAlias<NotificationHistoryView>, HasId<NotificationHistoryView> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Long id;

  protected NotificationType notificationType;

  protected String from;

  protected String providerAlias;

  protected Boolean success;

  protected List<TargetDTO> toList = new ArrayList<>();

  protected List<TargetDTO> ccList = new ArrayList<>();

  protected List<TargetDTO> bccList = new ArrayList<>();

  public NotificationHistoryView withNotificationType(NotificationType notificationType) {
    this.notificationType = notificationType;
    return this;
  }

  public NotificationHistoryView withFrom(String from) {
    this.from = from;
    return this;
  }

  public NotificationHistoryView withSuccess(Boolean success) {
    this.success = success;
    return this;
  }

  public NotificationHistoryView withToList(List<TargetDTO> toList) {
    this.toList = toList;
    return this;
  }

  public NotificationHistoryView withCcList(List<TargetDTO> ccList) {
    this.ccList = ccList;
    return this;
  }

  public NotificationHistoryView withBccList(List<TargetDTO> bccList) {
    this.bccList = bccList;
    return this;
  }

  public NotificationHistoryView addToList(TargetDTO... targetDTOs) {
    this.toList.addAll(Arrays.asList(targetDTOs));
    return this;
  }

  public NotificationHistoryView addCcList(TargetDTO... targetDTOs) {
    this.ccList.addAll(Arrays.asList(targetDTOs));
    return this;
  }

  public NotificationHistoryView addBccList(TargetDTO... targetDTOs) {
    this.bccList.addAll(Arrays.asList(targetDTOs));
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationHistoryView that = (NotificationHistoryView) o;
  
    return new EqualsBuilder()
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getTenantAlias(), that.getTenantAlias())
      .append(getNotificationType(), that.getNotificationType())
      .append(getFrom(), that.getFrom())
      .append(getSuccess(), that.getSuccess())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getTitle())
      .append(getContent())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getTenantAlias())
      .append(getNotificationType())
      .append(getFrom())
      .append(getSuccess())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("title", getTitle())
      .append("content", getContent())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("tenantAlias", getTenantAlias())
      .append("notificationType", getNotificationType())
      .append("from", getFrom())
      .append("success", getSuccess())
      .append("toList", toList)
      .append("ccList", ccList)
      .append("bccList", bccList)
      .toString();
  }
}