/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data;

import io.rchemist.common.persistence.mongo.config.MongoEntityBean;
import io.rchemist.common.persistence.mongo.config.MongoEntityBeanHelper;
import io.rchemist.common.persistence.mongo.search.data.provider.MongoQueryHelper;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.search.data.query.CombinedConditionItem;
import io.rchemist.common.search.data.query.QueryConditionItem;
import io.rchemist.common.search.data.query.SingleConditionItem;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class QueryParser<T> implements Serializable {

  private final List<QueryConditionItem> conditionItems;

  private final Class<?> entityClass;

  private final String entityClassName;

  private final MongoEntityBean mongoEntityBean;

  public QueryParser(Class<?> entityClass, List<QueryConditionItem> items) {
    this.entityClass = entityClass;
    this.entityClassName = entityClass.getName();
    this.conditionItems = items;
    this.mongoEntityBean = MongoEntityBeanHelper.getEntityBean(entityClassName);
  }

  public Criteria getCriteria(ConditionOperatorType operatorType){

    List<Criteria> criteriaList = new ArrayList<>();

    for(QueryConditionItem item : conditionItems){

      Criteria itemPredicate = getCriteria(item);

      if(itemPredicate != null){
        criteriaList.add(itemPredicate);
      }

    }

    if(operatorType.isMust()){
      return new Criteria().andOperator(criteriaList.toArray(new Criteria[0]));
    }else{
      return new Criteria().orOperator(criteriaList.toArray(new Criteria[0]));
    }
  }

  protected Criteria getCriteria(QueryConditionItem item){
    if(item instanceof CombinedConditionItem combinedItem){

      ConditionOperatorType operatorType = combinedItem.getOperatorType();

      List<Criteria> criteriaList = new ArrayList<>();

      for(QueryConditionItem subItem : combinedItem.getSubConditions()){
        Criteria subCriteria = getCriteria(subItem);

        if(subCriteria != null){
          criteriaList.add(subCriteria);
        }

      }

      if(criteriaList.size() > 0){
        if(operatorType.isMust()){
          return new Criteria().andOperator(criteriaList.toArray(new Criteria[0]));
        }else{
          return new Criteria().orOperator(criteriaList.toArray(new Criteria[0]));
        }
      }

      return null;

    }else{
      SingleConditionItem singleConditionItem = (SingleConditionItem) item;

      return parseCriteria(singleConditionItem);
    }
  }

  private Criteria parseCriteria(SingleConditionItem singleConditionItem) {

    QueryConditionType conditionType = singleConditionItem.getConditionType();

    String propertyName = singleConditionItem.getPropertyName();

    if (StringUtils.isEmpty(propertyName)) {
      return null;
    }

    Class propertyClass = mongoEntityBean == null ? null : mongoEntityBean.getPropertyClass(propertyName);
    if (propertyClass == null)
      propertyClass = String.class;

    if(conditionType.getParserType().equals(QueryParserType.COLLECTION)){
      // if values if not a collection but array, then we will convert it into a collection
      return MongoQueryHelper.getCriteria(propertyName, propertyClass, conditionType, null, singleConditionItem.getArrayValues());
    }else{
      if(conditionType.equals(QueryConditionType.BETWEEN) || conditionType.equals(QueryConditionType.NOT_BETWEEN)){
        return MongoQueryHelper.getCriteria(propertyName, propertyClass, conditionType, null, singleConditionItem.getArrayValues());
      }else{
        return MongoQueryHelper.getCriteria(propertyName, propertyClass, conditionType, singleConditionItem.getValue(), null);
      }
    }
  }


}
