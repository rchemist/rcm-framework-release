/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.money.Money;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.math.BigDecimal;
import java.util.Currency;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface Amount<T> extends ClassTransformTarget {

  default BigDecimal getAmount() {
    throw new ClassTransformException();
  }

  default void setAmount(BigDecimal amount) {
    throw new ClassTransformException();
  }

  default T withAmount(BigDecimal amount) {
    setAmount(amount);
    return (T) this;
  }

  default Currency getCurrency() {
    return StringUtils.isEmpty(getCurrencyCode()) ? Money.defaultCurrency() : Money.getCurrency(getCurrencyCode());
  }

  default String getCurrencyCode() {
    throw new ClassTransformException();
  }

  default void setCurrencyCode(String currencyCode) {
    throw new ClassTransformException();
  }

  default T withCurrencyCode(String currencyCode) {
    setCurrencyCode(currencyCode);
    return (T) this;
  }

  default Money getAmountAsMoney() {
    Currency currency = getCurrency();
    return getAmount() == null ? new Money(currency) : new Money(getAmount(), currency);
  }

  default void setAmountAsMoney(Money amount) {
    if (amount == null) {
      amount = new Money();
    }
    setAmount(amount.getAmount());
    setCurrencyCode(amount.getCurrency().getCurrencyCode());
  }

}