/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.BooleanUtil;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CompareQueryProvider implements QueryParseProvider {

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.COMPARE);
  }

  @Override
  public Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values) {

    Criteria criteria = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    if(value == null || shouldComputeEqual(value)){
      // COMPARE 대상 값이 없거나 ENUM_TYPE, Boolean 에 대해 Compare 타입의 질의를 한다면 equals 로 처리한다.
      criteria = MongoQueryHelper.getCriteria(propertyName,
        propertyClass, condition.isNegative() ?
          QueryConditionType.EQUAL : QueryConditionType.NOT_EQUAL, value, null);
    }else{

      if(isCondition(condition, QueryConditionType.LESS_THAN, QueryConditionType.NOT_LESS_THAN)){

        criteria = Criteria.where(propertyName).lt(MongoQueryHelper.getAppropriateValue(propertyClass, value));

      }else if(isCondition(condition, QueryConditionType.LESS_THAN_EQUAL, QueryConditionType.NOT_LESS_THAN_EQUAL)){

        criteria = Criteria.where(propertyName).lte(MongoQueryHelper.getAppropriateValue(propertyClass, value));

      }else if(isCondition(condition, QueryConditionType.GREATER, QueryConditionType.NOT_GREATER)){

        criteria = Criteria.where(propertyName).gt(MongoQueryHelper.getAppropriateValue(propertyClass, value));

      }else if(isCondition(condition, QueryConditionType.GREATER_THAN_EQUAL, QueryConditionType.NOT_GREATER_THAN_EQUAL)){

        criteria = Criteria.where(propertyName).gte(MongoQueryHelper.getAppropriateValue(propertyClass, value));

      }

    }

    return (criteria == null) ? null : (condition.isNegative()) ? criteria.not() : criteria;
  }

  private boolean isCondition(QueryConditionType condition, QueryConditionType... types) {
    return (ArrayUtils.contains(types, condition));
  }

  private boolean shouldComputeEqual(Object value) {
    return value instanceof EnumType
        || (BooleanUtil.isBoolean(value));
  }

  @Override
  public int getOrder() {
    return 300;
  }

  
}
