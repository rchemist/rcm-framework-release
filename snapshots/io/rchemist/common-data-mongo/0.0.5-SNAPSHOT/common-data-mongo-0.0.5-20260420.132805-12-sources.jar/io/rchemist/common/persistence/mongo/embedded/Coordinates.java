/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.embedded;

import io.rchemist.common.persistence.domain.embedded.ICoordinate;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
public class Coordinates implements Serializable, ICoordinate {

  @Getter(AccessLevel.PRIVATE)
  @Setter(AccessLevel.PRIVATE)
  private String type;

  @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
  private Double[] coordinates; // 배열로 위도(latitude)와 경도(longitude)를 저장

  public Coordinates(Double[] coordinates) {
    this.type = "Point";
    this.coordinates = coordinates;
  }

  public Coordinates() {
    this.type = "Point";
    this.coordinates = new Double[]{0.0, 0.0};
  }

  public Double getLongitude() {
    return ArrayUtils.isNotEmpty(coordinates) ? coordinates[0] : null;
  }

  public Double getLatitude() {
    return ArrayUtils.isNotEmpty(coordinates) ? coordinates[1] : null;
  }

  public void setCoordinates(Double longitude, Double latitude) {
    this.coordinates = new Double[]{longitude, latitude};
  }


}
