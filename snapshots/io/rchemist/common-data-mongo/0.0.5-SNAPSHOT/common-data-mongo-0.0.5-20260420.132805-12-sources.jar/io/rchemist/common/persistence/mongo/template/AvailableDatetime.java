/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.InstantUtil;
import java.time.Instant;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface AvailableDatetime<T> extends ClassTransformTarget {

  default Instant getAvailableAt(){throw new ClassTransformException();}
  default void setAvailableAt(Instant availableAt){
    throw new ClassTransformException();
  }

  default Instant getAvailableUntil(){throw new ClassTransformException();}
  default void setAvailableUntil(Instant availableUntil){
    throw new ClassTransformException();
  }

  default boolean isAvailableNow() {
    return InstantUtil.isBetween(getAvailableAt(), getAvailableUntil());
  }

  default boolean isStartedNow(){
    return InstantUtil.isBefore(getAvailableAt(), Instant.now());
  }

  default boolean isEndedNow(){
    return InstantUtil.isBefore(getAvailableUntil(), Instant.now());
  }

  default boolean isAvailable(Instant compareDate) {
    // compareDate 시각이 AvailableAt 과 AvailableUntil 사이에 있는지 확인
    return InstantUtil.isBetween(getAvailableAt(), getAvailableUntil(), compareDate, true);
  }

  default T withAvailableAt(Instant availableAt) {
    setAvailableAt(availableAt);
    return (T) this;
  }

  default T withAvailableUntil(Instant availableUntil) {
    setAvailableUntil(availableUntil);
    return (T) this;
  }

  default boolean validateAvailableDates() {
    if (getAvailableAt() != null && getAvailableUntil() != null) {
      return InstantUtil.isBefore(getAvailableAt(), getAvailableUntil());
    }
    return true;
  }
}
