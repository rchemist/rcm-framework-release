/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.config;

import io.rchemist.common.persistence.config.persistence.EntityBeanContext;
import java.util.concurrent.ConcurrentHashMap;
import javassist.NotFoundException;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class MongoEntityBeanHelper {

  private static final ConcurrentHashMap<String, MongoEntityBean> ENTITY_BEAN_MAP = new ConcurrentHashMap<>();

  public static MongoEntityBean getEntityBean(String entityClassName) {
    if (isMongoEntityBean(entityClassName)) {
      return ENTITY_BEAN_MAP.get(entityClassName);
    }

    try {
      MongoEntityBean entityBean = MongoEntityBean.registerEntityBean(entityClassName);
      put(entityClassName, entityBean);
      // SearchForm 에 대해 대응하기 위함
      // 나중에 EntityBeanContext 로 통합하는 것이 좋겠음
      EntityBeanContext.addRegisteredEntityBean(entityClassName, entityBean);
      return entityBean;
    } catch (NotFoundException e) {
      // silent
      return null;
    }
  }

  public static void put(String entityClassName, MongoEntityBean entityBean) {
    ENTITY_BEAN_MAP.put(entityClassName, entityBean);
  }

  public static boolean isMongoEntityBean(String entityClassName) {
    return ENTITY_BEAN_MAP.containsKey(entityClassName);
  }



}
