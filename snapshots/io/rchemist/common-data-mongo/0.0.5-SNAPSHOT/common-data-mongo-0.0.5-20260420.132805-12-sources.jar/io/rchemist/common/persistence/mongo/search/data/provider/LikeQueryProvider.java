/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.BooleanUtil;
import io.rchemist.common.util.StringUtil;
import java.util.List;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class LikeQueryProvider implements QueryParseProvider {

  private static final String WILD_CARD_CHARACTER = ".*";
  private static final String START_WITH_CHARACTER = "^";
  private static final String END_WITH_CHARACTER = "$";

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.LIKE);
  }

  @Override
  public Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values) {

    Criteria criteria = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    // like, startwith 와 같은 질의는 null value 를 처리할 수 없다.
    if(value == null){
      // null 로 like 검색을 시도할 때는 isNull 을 처리하게 한다.
      criteria = MongoQueryHelper.getCriteria(propertyName, propertyClass, QueryConditionType.NULL, null, null);
    }else{

      if(value instanceof EnumType){
        criteria = MongoQueryHelper.getCriteria(propertyName, propertyClass, QueryConditionType.EQUAL, value, null);
      }else if(Boolean.class.isAssignableFrom(value.getClass()) || boolean.class.isAssignableFrom(value.getClass())) {
        boolean booleanValue = BooleanUtil.getBooleanValue(value, true);
        criteria = MongoQueryHelper.getCriteria(propertyName, propertyClass, QueryConditionType.EQUAL, booleanValue, null);
      }

      if(criteria == null){
        String searchValue = getSearchValue(condition, value);
        criteria = Criteria.where(propertyName).regex(searchValue, "i");
      }

    }

    if (criteria == null)
      return null;

    return condition.isNegative() ? criteria.not() : criteria;

  }

  private String getSearchValue(QueryConditionType condition, Object value) {
    String val = StringUtil.getString(value);
    if(condition.equals(QueryConditionType.LIKE) || condition.equals(QueryConditionType.NOT_LIKE)){
      val = WILD_CARD_CHARACTER + val + WILD_CARD_CHARACTER;
    }else if(condition.equals(QueryConditionType.START_WITH) || condition.equals(QueryConditionType.NOT_START_WITH)){
      val = START_WITH_CHARACTER + val;
    }else if(condition.equals(QueryConditionType.END_WITH) || condition.equals(QueryConditionType.NOT_END_WITH)){
      val = val + END_WITH_CHARACTER;
    }
    return val;
  }

  @Override
  public int getOrder() {
    return 200;
  }
}
