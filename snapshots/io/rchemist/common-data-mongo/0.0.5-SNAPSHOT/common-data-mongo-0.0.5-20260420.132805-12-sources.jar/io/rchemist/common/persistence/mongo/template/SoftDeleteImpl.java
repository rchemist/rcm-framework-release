/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(SoftDelete.class)
public class SoftDeleteImpl implements EnhancedTemplate {

  @Indexed
  @Description(name = "삭제 여부", comment = "삭제 여부")
  @Getter
  protected Boolean archived = false;

  @Indexed
  @Description(name = "활성화 여부", comment = "활성화 여부, 기본적으로 isActive는 archived 되지 않은 것이다.")
  @AdminField(order = 100, fieldType = PresentationFieldType.BOOLEAN, name = "SoftDeleteImpl_Active"
      , defaultValue = "true"
      , headerField = @HeaderField(order = 1000000, sortable = false)
      , tab = @ViewTab(type = TabEnumType.STATUS)
      , modifiableType = ModifiableType.MODIFY_ONLY)
  @Getter
  protected Boolean active = true;

  @Indexed
  @Description(name = "일시 삭제 여부", comment = "최종 삭제 된 것은 아니며, 어플리케이션 로직 상에서 일시 삭제 상태. 언제든 다시 되돌릴 수 있어야 한다.")
  protected Boolean temporaryDeleted = false;

  public boolean isActive(){
    return (!isArchived() && !isTemporaryDeleted()
        && BooleanUtils.toBooleanDefaultIfNull(active, true)
    );
  }

  public boolean isArchived() { return (BooleanUtils.toBooleanDefaultIfNull(archived, false));}

  public boolean isTemporaryDeleted(){
    return BooleanUtils.toBooleanDefaultIfNull(temporaryDeleted, false);
  }

  public void setActive(Boolean active){
    this.active = BooleanUtils.toBooleanDefaultIfNull(active, true);
  }

  public void setArchived(Boolean archived){
    this.archived = BooleanUtils.toBooleanDefaultIfNull(archived, false);
  }

  public void setTemporaryDeleted(Boolean temporaryDeleted){
    this.temporaryDeleted = BooleanUtils.toBooleanDefaultIfNull(temporaryDeleted, false);
  }





}
