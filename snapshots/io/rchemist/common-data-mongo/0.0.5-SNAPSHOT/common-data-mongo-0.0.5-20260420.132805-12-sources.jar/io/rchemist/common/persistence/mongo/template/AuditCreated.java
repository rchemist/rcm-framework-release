/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.util.EnumTypeUtil;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * 반드시 weave 해야 한다
 **/

public interface AuditCreated<T> extends ClassTransformTarget {

  default Instant getCreatedAt() {
    throw new ClassTransformException();
  }

  default void setCreatedAt(Instant dateCreated) {
    throw new ClassTransformException();
  }

  @JsonIgnore
  default LocalDateTime getCreatedAtLocalDateTime() {
    return getCreatedAtLocalDateTime(ZoneId.systemDefault());
  }

  @JsonIgnore
  default LocalDateTime getCreatedAtLocalDateTime(ZoneId zoneId) {
    return getCreatedAt() == null ? null : LocalDateTime.ofInstant(getCreatedAt(), zoneId);
  }

  default String getCreatedBy() {
    throw new ClassTransformException();
  }

  default void setCreatedBy(String createdBy) {
    throw new ClassTransformException();
  }

  @JsonIgnore
  default int compareTo(AuditCreated<?> a) {
    if(a.getCreatedAt().isAfter(getCreatedAt())){
      return -1;
    }else if(a.getCreatedAt().equals(getCreatedAt())){
      return 0;
    }else{
      return 1;
    }
  }

  default AuditUserType getCreatedByUserType(){return AuditUserType.CUSTOMER;}

  default void setCreatedByUserType(AuditUserType createdByUserType){}

  @JsonIgnore
  default boolean isCreatedByCustomer(){
    return EnumTypeUtil.equals(getCreatedByUserType(), AuditUserType.CUSTOMER);
  }

  @JsonIgnore
  default boolean isCreatedByCustomer(String otherCreatedBy){
    if(getCreatedByUserType() != null && getCreatedBy() != null) {
      return getCreatedByUserType().equals(AuditUserType.CUSTOMER) && getCreatedBy().equals(otherCreatedBy);
    }
    return false;
  }

  default T withCreatedAt(Instant createdAt) {
    setCreatedAt(createdAt);
    return (T) this;
  }

  default T withCreatedBy(String createdBy) {
    setCreatedBy(createdBy);
    return (T) this;
  }

  default T withCreatedByUserType(AuditUserType createdByUserType) {
    setCreatedByUserType(createdByUserType);
    return (T) this;
  }

}
