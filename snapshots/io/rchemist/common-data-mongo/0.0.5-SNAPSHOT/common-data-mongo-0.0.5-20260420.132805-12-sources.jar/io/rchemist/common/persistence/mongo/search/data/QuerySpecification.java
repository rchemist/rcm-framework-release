/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.persistence.mongo.search.extension.SearchServiceExtensionManager;
import io.rchemist.common.persistence.mongo.template.EssentialEntity;
import io.rchemist.common.persistence.mongo.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.mongo.template.Historical;
import io.rchemist.common.persistence.mongo.template.HistoricalUUID;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.query.CombinedConditionItem;
import io.rchemist.common.search.data.query.QueryCondition;
import io.rchemist.common.search.data.query.SingleConditionItem;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Slf4j
public class QuerySpecification<T extends Serializable, S extends SearchFormWrapper<S>>  {

  private static SearchServiceExtensionManager extensionManager;

  private static SearchServiceExtensionManager getExtensionManager() {
    if(extensionManager == null){
      extensionManager = ApplicationContextHolder.getBean(SearchServiceExtensionManager.class);
    }
    return extensionManager;
  }

  private final S searchForm;

  private final Class<T> entityClass;

  private final Map<ConditionOperatorType, QueryCondition> conditions = new LinkedHashMap<>();

  private String[] explicitFilterNames;

  private final List<Criteria> mustPredicates = new ArrayList<>();
  private final List<Criteria> shouldPredicates = new ArrayList<>();

  /**
   * MongoTemplate.find(query, entityClass) 에서 사용할 query
   * ReactiveMongoTemplate.find(query, entityClass) 에서 사용할 query
   * @return
   */
  public Query getQuery() {
    Query query = new Query();

    if(MapUtils.isNotEmpty(conditions)){

      for(Entry<ConditionOperatorType, QueryCondition> entry : conditions.entrySet()){

        QueryCondition condition = entry.getValue();

        if(condition != null && !condition.isEmpty()){

          QueryParser<T> parser = new QueryParser<>(entityClass, condition.getAllQueryConditionItems());

          ConditionOperatorType operatorType = entry.getKey();

          Criteria criteria = parser.getCriteria(operatorType);

          if(operatorType.isMust()){
            this.mustPredicates.add(criteria);
          }else{
            this.shouldPredicates.add(criteria);
          }
        }
      }
    }

    if(CollectionUtils.isNotEmpty(mustPredicates)){
      query.addCriteria(new Criteria().andOperator(mustPredicates.toArray(new Criteria[0])));
    }
    if(CollectionUtils.isNotEmpty(shouldPredicates)){
      query.addCriteria(new Criteria().orOperator(shouldPredicates.toArray(new Criteria[0])));
    }

    // sort 처리는 Query 바깥에서 Pageable 로 별도 처리한다.
    // return withSortOrders(query);
    return query;
  }

  public QuerySpecification(Class<T> entityClass, S searchForm, String... propertyNames) {
    this.searchForm = searchForm;
    this.entityClass = entityClass;

    if (searchForm.isShouldReturnEmpty()) {
      conditions.put(ConditionOperatorType.AND, new QueryCondition().addQueryItems(SingleConditionItem.isNull("id")));
    } else {
      ExtensionResultHolder<QuerySpecificationResultHolder> erh = new ExtensionResultHolder<>();

      getExtensionManager().getProxy().addQueryPredicates(entityClass, searchForm, erh);

      if(erh.getResult() != null){

        Map<ConditionOperatorType, QueryCondition> result = erh.getResult().getResult();

        if(MapUtils.isNotEmpty(result)){
          result.entrySet().forEach(entry -> {

            if(conditions.containsKey(entry.getKey())){

              QueryCondition prevCondition = conditions.get(entry.getKey());

              prevCondition.merge(entry.getValue());

              conditions.put(entry.getKey(), prevCondition);

            }else{
              conditions.put(entry.getKey(), entry.getValue());
            }

          });
        }

        if (erh.getResult().isFiltered()) {
          this.explicitFilterNames = erh.getResult().getFiltered();
        }

      }


      // propertyNames 로 지정했지만 ExtensionHandler 에서 자동으로 처리한 필터는 제외한다.
      if(propertyNames != null && ArrayUtils.isNotEmpty(propertyNames)){

        Set<String> additionalFilterNames = new HashSet<>(Arrays.asList(propertyNames));
        if (ArrayUtils.isNotEmpty(this.explicitFilterNames)) {
          additionalFilterNames.removeAll(Arrays.asList(this.explicitFilterNames));
        }

        if(CollectionUtils.isNotEmpty(additionalFilterNames)){
          String[] additionalFilters = additionalFilterNames.toArray(new String[additionalFilterNames.size()]);
          addConditions(null, QueryConditionType.EQUAL, additionalFilters);
          this.explicitFilterNames = ArrayUtil.merge(this.explicitFilterNames, additionalFilters);
        }

      }

    }

  }

  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, QueryConditionType conditionType, String... propertyNames){

    if (conditionOperatorType == null) {
      addConditions(ConditionOperatorType.AND, conditionType, propertyNames);
      addConditions(ConditionOperatorType.OR, conditionType, propertyNames);
      return this;
    } else if (conditionOperatorType.equals(ConditionOperatorType.INHERITED)) {
      conditionOperatorType = searchForm.getOperator();
    }

    if(propertyNames != null && ArrayUtils.isNotEmpty(propertyNames)){
      QueryCondition queryCondition;
      if(conditions.containsKey(conditionOperatorType)){
        queryCondition = conditions.get(conditionOperatorType);

      }else{
        queryCondition = new QueryCondition();
      }

      if(conditionType.equals(QueryConditionType.NULL)) {
        for(String propertyName : propertyNames){
          queryCondition.addQueryItems(SingleConditionItem.isNull(propertyName));
        }
      }else if(conditionType.equals(QueryConditionType.NOT_NULL)){
        for(String propertyName : propertyNames){
          queryCondition.addQueryItems(SingleConditionItem.notNull(propertyName));
        }
      }else{
        for(String propertyName : propertyNames){

          if (ArrayUtils.contains(this.explicitFilterNames, propertyName)) {
            continue;
          }

          // join 으로 매핑된 property 는 propertyName:pathNames 형태로 셋팅된다.
          // ex) userId:user.id
          String pathName = StringUtil.subStringAfter(propertyName, ":");
          Object value = searchForm.getValue(pathName);

          if(value != null){
            // 자동으로 들어오는 값에 대해 searchForm.value 가 "" 인 경우 조건에서 제외한다.
            // 명시적으로 "" 값을 검색하고 싶다면 이 메소드를 사용해서는 안 된다.
            // if(conditionType.equals(QueryConditionType.EQUAL) && value instanceof String && StringUtils.isBlank((String) value))
              //continue;

            if (searchForm instanceof AbstractSearchForm<?> form) {

              FilterItem[] items = form.getFilterItems(conditionOperatorType, pathName);

              queryCondition.addConditions(items);

            } else {

              QueryConditionType queryConditionType = conditionType;

              if(value instanceof EnumType || value instanceof Boolean) {
                // value = ((EnumType) value).getType();
                queryConditionType = QueryConditionType.EQUAL;
              }

              queryCondition.addConditions(queryConditionType, propertyName, value);

            }



          } else {

            // searchForm 의 해당 이름의 필터가 subConditions 으로 매핑된 경우
            if (searchForm instanceof AbstractSearchForm<?> form) {
              LinkedHashMap<ConditionOperatorType, FilterItem[]> subConditions = form.getSubConditions(conditionOperatorType, propertyName);


              if (MapUtils.isNotEmpty(subConditions)) {

                for (Entry<ConditionOperatorType, FilterItem[]> entry : subConditions.entrySet()) {
                  ConditionOperatorType subConditionOperatorType = entry.getKey();
                  FilterItem[] filterItems = entry.getValue();

                  if (ArrayUtils.isNotEmpty(filterItems)) {
                    QueryCondition subQueryCondition = new QueryCondition();

                    for (FilterItem filterItem : filterItems) {
                      // single filter
                      subQueryCondition.addConditions(filterItem);
                    }

                    subQueryCondition.getAllQueryConditionItems();

                    CombinedConditionItem subConditionItem = new CombinedConditionItem(subConditionOperatorType,
                        subQueryCondition.getAllQueryConditionItems());

                    queryCondition = queryCondition.addCombinedConditionItem(subConditionItem);

                  }
                }
              }

            }



          }
        }
      }

      conditions.put(conditionOperatorType, queryCondition);

    }

    return this;
  }

  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, String propertyName, QueryConditionType conditionType, Object value){
    if(conditionOperatorType == null || conditionOperatorType.equals(ConditionOperatorType.INHERITED))
      conditionOperatorType = searchForm.getOperator();

    QueryCondition context;
    if(conditions.containsKey(conditionOperatorType)){
      context = conditions.get(conditionOperatorType);
    }else{
      context = new QueryCondition();
    }

    context.addConditions(conditionType, propertyName, value);

    conditions.put(conditionOperatorType, context);

    return this;
  }

  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, QueryCondition... queryConditions){
    if(queryConditions == null || ArrayUtils.isEmpty(queryConditions))
      return this;


    if(conditions.containsKey(conditionOperatorType)){
      QueryCondition condition = conditions.get(conditionOperatorType);

      for(QueryCondition c : queryConditions){
        condition = condition.merge(c);
      }

      conditions.put(conditionOperatorType, condition);
    }else{

      if(queryConditions.length > 1){
        QueryCondition condition = new QueryCondition();

        for(QueryCondition c : queryConditions){
          condition = condition.merge(c);
        }

        conditions.put(conditionOperatorType, condition);

      }else{
        conditions.put(conditionOperatorType, queryConditions[0]);
      }
    }
    return this;
  }


  public QuerySpecification<T, S> clearConditions(){
    this.conditions.clear();
    return this;
  }

  public QuerySpecification<T, S> clearCondition(String... propertyNames){
    if(propertyNames != null){
      for(String propertyName : propertyNames){
        this.conditions.remove(propertyName);
      }
    }
    return this;
  }

  /**
   * SimpleJpaRepository 에서 specification#toPredicate 는 select row 쿼리에서 한번, select count 쿼리에서 한번, 두번 호출된다.
   * 두번째 실행할 때 앞에서 만든 임시 정보를 모두 제거해야 한다.
   */
  private Query withSortOrders(Query query) {
    List<SortEntry> sortEntries = searchForm.getSorts();

    boolean sortedCreatedAt = false;
    boolean sortedId = false;

    if(CollectionUtils.isNotEmpty(sortEntries)){
      // List<SortEntry>를 Map<String, Direction>으로 변환 (동일 필드의 다중 정렬 지원)
      Map<String, Direction> sortMap = getEntitySortMap(sortEntries);

      if(MapUtils.isNotEmpty(sortMap)){

        for(Entry<String, Direction> entry : sortMap.entrySet()){

          String propertyName = entry.getKey();
          Direction direction = entry.getValue();

          if (propertyName.equals("createdAt")) {
            sortedCreatedAt = true;
          } else if (propertyName.equals("id")) {
            sortedId = true;
          }

          query.with(Sort.by(direction, propertyName));

        }

      }
    }

    if (!sortedCreatedAt) {
      if(EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)
          || EssentialUUIDEntity.class.isAssignableFrom(entityClass)
          || HistoricalUUID.class.isAssignableFrom(entityClass)
      ){
        query.with(Sort.by(Direction.DESC, "createdAt"));
      }
    }

    if (!sortedId) {
      if(EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)){
        query.with(Sort.by(Direction.DESC, "id"));
      }
    }

    return query;

  }


  private Map<String, Direction> getEntitySortMap(List<SortEntry> sortEntries) {
    if(CollectionUtils.isEmpty(sortEntries))
      return null;

    Map<String, String> alters = new HashMap<>();

    // 필드 별칭 처리
    for(SortEntry entry : sortEntries){
      String fieldName = entry.getFieldName();
      if(fieldName.contains(":")){
        alters.put(StringUtils.substringBefore(fieldName, ":"), StringUtils.substringAfter(fieldName, ":"));
      }
    }

    Map<String, Direction> sortMap = new LinkedHashMap<>();
    for(SortEntry entry : sortEntries){
      String fieldName = entry.getFieldName();
      SortInfo sortInfo = entry.getSortInfo();

      if (sortInfo == null) {
        continue;
      }

      // 별칭이 있으면 적용
      String propertyName = alters.getOrDefault(fieldName, fieldName);
      Direction direction = sortInfo.getDirection();

      // MongoDB는 동일 필드에 대해 하나의 정렬만 적용 가능하므로 마지막 값 사용
      sortMap.put(propertyName, direction);
    }

    return sortMap;
  }


  public boolean isEmpty(){
    boolean empty = MapUtils.isEmpty(conditions);

    if(empty)
      return true;

    // key 만 존재하고 실제 condition 은 적용되지 않은 경우에도 empty true 를 반환한다.
    for(QueryCondition condition : conditions.values()){
      if(!condition.isEmpty()){
        return false;
      }
    }

    return false;   // unmapped join items 때문에 무조건 false 가 된다.

  }

}
