/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template.listener;

import io.rchemist.common.persistence.mongo.template.IpAddress;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.IpAddressUtil;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.WebRequestContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertEvent;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmMongoIpAddressListener")
public class IpAddressListener extends AbstractMongoEventListener<IpAddress<?>> {

  @Override
  public void onBeforeConvert(BeforeConvertEvent<IpAddress<?>> event) {
    IpAddress<?> source = event.getSource();
    if(StringUtils.isEmpty(source.getIpAddress())){

      // How to i get UserAgent ?

      WebRequestContext context = WebRequestContext.getWebRequestContext();

      if (context != null && context.getRequest() != null) {
        HttpRequest request = context.getRequest();
        String ipAddress = getClientIp(request);
        String macAddress = IpAddressUtil.getMacAddress();
        DeviceType deviceType = context.getRequestDTO().getDeviceType();

        source.setDeviceType(deviceType);
        source.setIpAddress(ipAddress);
        source.setMacAddress(macAddress);

      }

    }
  }

  private static String getClientIp(HttpRequest request) {

    final String[] headers = {
      "X-Forwarded-For",
      "X-FORWARDED-FOR",
      "Proxy-Client-IP",
      "WL-Proxy-Client-IP",
      "HTTP_X_FORWARDED_FOR",
      "HTTP_X_FORWARDED",
      "HTTP_X_CLUSTER_CLIENT_IP",
      "HTTP_CLIENT_IP",
      "HTTP_FORWARDED_FOR",
      "HTTP_FORWARDED",
      "HTTP_VIA",
      "REMOTE_ADDR"
    };

    try {
      for (String headerName : headers) {
        String ip = request.getHeaders().getFirst(headerName);
        if (!StringUtils.isBlank(ip) && !"unknown".equalsIgnoreCase(ip)) {
          return ip;
        }
      }

      // TODO How to i get remote addr?
      return null;

    } catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
    }

    return null;
  }

}
