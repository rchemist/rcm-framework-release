/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Unmodifiable;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import java.io.Serializable;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * 계속 쌓이기만 하는 이력과 같은 엔티티는 이 인터페이스를 상속한다
 *
 **/
@Unmodifiable
public interface Historical<T> extends Serializable, AuditCreated<T>, ClassTransformTarget {

  Long getId();
  void setId(Long id);

  /**
   * 이력을 제거할 기간 설정
   *
   * 날짜를 숫자값으로 입력하되, 0 이면 지우지 않으며, 기본값은 30일.
   * 이 값을 변경하려면 반드시 이 인터페이스를 상속한 클래스에서 override 해야 한다
   *
   * @return
   */
  default Integer getRemovalPeriodDays(){return 30;}

  default Long getEntityId() {
    return getId();
  }

  default T withId(Long id){
    setId(id);
    return (T) this;
  }

}
