/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.DateUtil;
import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.LocalDateUtil;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MongoQueryHelper {

  private static final List<QueryParseProvider> providers;

  static {

    List<QueryParseProvider> list = CollectionUtil.list(
      new CompareQueryProvider(), new CollectionQueryProvider(), new EqualQueryProvider(), new LikeQueryProvider(), new NullQueryProvider()
    );

    list.sort(Comparator.comparing(QueryParseProvider::getOrder));
    providers = list;
  }

  public static Query buildQuery(FilterMapSearchForm<?> searchForm) {
    Query query = new Query();

    searchForm.getFilters().forEach((conditionOperatorType, filterItems) -> {
      Criteria criteria = new Criteria();

      Arrays.stream(filterItems).forEach(filterItem -> {
        String name = filterItem.getName();
        Object value = filterItem.getValue();
        Object[] values = filterItem.getValues();
        boolean not = BooleanUtils.toBoolean(filterItem.getNot());

        switch (filterItem.getQueryConditionType()) {
          case EQUAL -> criteria.and(name).is(value);
          case NOT_EQUAL -> criteria.and(name).ne(value);
          case IN -> criteria.and(name).in(values);
          case NOT_IN -> criteria.and(name).nin(values);
          case NULL -> criteria.and(name).is(null);
          case NOT_NULL -> criteria.and(name).ne(null);
          case LIKE -> criteria.and(name).regex(value.toString());
          case NOT_LIKE -> criteria.and(name).not().regex(value.toString());
          case START_WITH -> criteria.and(name).regex("^" + value.toString());
          case NOT_START_WITH -> criteria.and(name).not().regex("^" + value.toString());
          case END_WITH -> criteria.and(name).regex(value.toString() + "$");
          case NOT_END_WITH -> criteria.and(name).not().regex(value.toString() + "$");
          case LESS_THAN -> criteria.and(name).lt(value);
          case LESS_THAN_EQUAL -> criteria.and(name).lte(value);
          case GREATER -> criteria.and(name).gt(value);
          case GREATER_THAN_EQUAL -> criteria.and(name).gte(value);
          case NOT_LESS_THAN -> criteria.and(name).not().lt(value);
          case NOT_LESS_THAN_EQUAL -> criteria.and(name).not().lte(value);
          case NOT_GREATER -> criteria.and(name).not().gt(value);
          case NOT_GREATER_THAN_EQUAL -> criteria.and(name).not().gte(value);
          case BETWEEN -> {
            if (values.length != 2)
              throw new IllegalArgumentException("BETWEEN requires exactly 2 values");
            criteria.and(name).gte(values[0]).lte(values[1]);
          }
          case NOT_BETWEEN -> {
            if (values.length != 2)
              throw new IllegalArgumentException("NOT_BETWEEN requires exactly 2 values");
            criteria.orOperator(Criteria.where(name).lt(values[0]),
              Criteria.where(name).gt(values[1]));
          }
          case ID_EQUAL -> criteria.and("_id").is(value);
          default -> throw new IllegalArgumentException("Unsupported query condition type");
        }

        if (not) {
          criteria.not();
        }

      });

      switch (conditionOperatorType) {
        case AND -> query.addCriteria(criteria);
        case OR -> query.addCriteria(new Criteria().orOperator(criteria));
        default -> throw new IllegalArgumentException("Unsupported condition operator type");
      }
    });

    return query;
  }

  public static Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values){
    if(value == null && CollectionUtils.isNotEmpty(values)) value = values.get(0);

    for(QueryParseProvider provider : providers){
      if(provider.isMatched(condition)){
        return provider.getCriteria(propertyName, propertyClass, condition, value, values);
      }
    }
    return null;
  }

  public static <T> T getAppropriateValue(Class<T> clazz, Object value) {
    if (value == null)
      return null;

    if (clazz.isAssignableFrom(value.getClass()))
      return (T) value;

    try {
      switch (clazz.getSimpleName()) {
        case "String":
          return (T) String.valueOf(value);
        case "Integer":
          return (T) Integer.valueOf(String.valueOf(value));
        case "Long":
          return (T) Long.valueOf(String.valueOf(value));
        case "Double":
          return (T) Double.valueOf(String.valueOf(value));
        case "Float":
          return (T) Float.valueOf(String.valueOf(value));
        case "Boolean":
          return (T) Boolean.valueOf(String.valueOf(value));
        case "Character":
          return (T) Character.valueOf(String.valueOf(value).charAt(0));
        case "Short":
          return (T) Short.valueOf(String.valueOf(value));
        case "Byte":
          return (T) Byte.valueOf(String.valueOf(value));
        case "Date":
          return (T) DateUtil.getDate(value);
        case "LocalDate":
          return (T) LocalDateUtil.parse(String.valueOf(value));
        case "LocalDateTime":
          return (T) LocalDateTimeUtil.parse(String.valueOf(value));
        case "LocalTime":
          return (T) LocalDateTimeUtil.parse(String.valueOf(value));
        case "ZonedDateTime":
          return (T) LocalDateTimeUtil.parse(String.valueOf(value));
        case "Instant":
          return (T) InstantUtil.getInstant(value);
        default:
          return value == null ? null : (T) value;
      }
    }catch (Exception e) {
      return value == null ? null : (T) value;
    }

  }

}
