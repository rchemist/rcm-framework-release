/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.StringUtil;
import java.util.List;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class EqualQueryProvider implements QueryParseProvider {

  public static final String SPLIT_CODE = "|||";

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.EQUAL);
  }

  @Override
  public Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values) {

    Criteria criteria = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    if (value == null)
      return MongoQueryHelper.getCriteria(propertyName, propertyClass, QueryConditionType.NULL, null, null);

    // propertyClass 가 String.class 라면
    if (String.class.isAssignableFrom(propertyClass)) {
      String compareValue = StringUtil.getString(value);
      criteria = Criteria.where(propertyName).is(compareValue);
      if (condition.equals(QueryConditionType.NOT_EQUAL)) {
        criteria = criteria.not();
      }
    }

    if(criteria == null){
      try {
        criteria = Criteria.where(propertyName).is(MongoQueryHelper.getAppropriateValue(propertyClass, value));
      }catch (Exception e){
        criteria = Criteria.where(propertyName).is(value);
      }
    }

    return (condition.isNegative()) ? criteria.not() : criteria;
  }

  @Override
  public int getOrder() {
    return 100;
  }
}
