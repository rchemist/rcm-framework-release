/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface TagsMapping<T> extends ClassTransformTarget {

  default String[] getTags(){throw new ClassTransformException();}

  default void setTags(String[] tags){
    throw new ClassTransformException();
  }

  default T addTags(String... tags) {
    if (tags != null && tags.length > 0) {
      List<String> tagList = new ArrayList<>(List.of(getTags() != null ? getTags() : new String[0]));
      tagList.addAll(List.of(tags));
      setTags(tagList.toArray(new String[0]));
    }
    return (T) this;
  }

  @JsonIgnore
  default List<String> getSearchTags() {
    return (ArrayUtils.isNotEmpty(getTags())) ? Arrays.asList(getTags()) : new ArrayList<>();
  }

  default void setSearchTags(List<String> searchTags) {
    if (CollectionUtils.isNotEmpty(searchTags)) {
      setTags(searchTags.toArray(new String[0]));
    } else {
      setTags(null);
    }
  }

  default T withTags(String... tag){
    setTags(tag);
    return (T) this;
  }

}
