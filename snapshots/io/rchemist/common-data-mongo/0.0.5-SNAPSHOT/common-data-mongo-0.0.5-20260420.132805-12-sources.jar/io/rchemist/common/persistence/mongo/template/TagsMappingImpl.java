/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by kunner
 **/
@TemplateClass(value = TagsMapping.class)
@Getter
@Setter
public class TagsMappingImpl implements Serializable, EnhancedTemplate {

  @WildcardIndexed
  @Description(name = "태그", comment = "상품에 대한 태그 정보, 기본적으로 컴마로 구분해서 작성되며, 이 정보는 검색 엔진에서 상품에 태그 정보로서 인덱스 된다.")
  protected String[] tags;

  public void setTags(String[] tags) {
    if (tags == null || tags.length == 0) {
      this.tags = null;
    } else {
      List<String> tagList = new ArrayList<>();
      for (String tag : tags) {
        if (StringUtils.isNotEmpty(tag)) {
          tagList.add(tag);
        }
      }
      if (CollectionUtils.isNotEmpty(tagList)) {
        this.tags = tagList.toArray(new String[0]);
      } else {
        this.tags = null;
      }
    }
  }

}
