/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.config;

import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.util.BytecodeUtil;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.ClassFile;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class MongoEntityBean extends EntityBean<MongoEntityBean> {

  public MongoEntityBean() {
    super();
  }


  public static MongoEntityBean registerEntityBean(String entityClassName) throws NotFoundException {
    Class<?> clazz = BytecodeUtil.getClassByName(entityClassName);
    return registerEntityBean(clazz);
  }

  public static MongoEntityBean registerEntityBean(Class<?> clazz) throws NotFoundException {

    ClassPool classPool = ClassPool.getDefault();
    CtClass ctClass = classPool.getCtClass(clazz.getName());

    boolean isFrozen = ctClass.isFrozen();

    try {
      if (isFrozen) {
        ctClass.defrost();
      }

      ClassFile classFile = ctClass.getClassFile();

      /**
       * Abstract entity class 는 bean 으로 등록할 수 없다
       */
      if(!classFile.isAbstract()){
        Class<?> mappingClass = BytecodeUtil.getClassByName(classFile.getName());

        MongoEntityBean bean = new MongoEntityBean();

        /**
         * 어노테이션으로 설정된 정보가 없다면 기본값에 의해 처리한다.
         * 기본값은 엔티티 명명 규칙에 의해 Class의 Fully qualified class name 에서 맨 마지막 Impl 을 제외한 부분이다.
         * 그런데 만약 그런 이름의 인터페이스가 없다면 엔티티 클래스 이름 그 자체를 bean name 으로 등록한다
         */
        initialize(mappingClass, classFile, bean);

        return bean;
      }

    } finally {
      if (isFrozen) {
        ctClass.freeze();
      }
    }

    return null;

  }


  private static void initialize(Class<?> mappingClass, ClassFile classFile, MongoEntityBean bean) {

    Annotation register = BytecodeUtil.getDeclaredAnnotationOnType(classFile, Document.class.getName());

    // entity naming 규칙에 의거해, 뒤에 Impl 이 붙어 있다면
    String beanName = getDefaultEntityBeanName(classFile);

    if (register != null) {
      String tableName;
      try {
        tableName = BytecodeUtil.getStringValue(register, "collection");
        if (StringUtils.isEmpty(tableName)) {
          tableName = BytecodeUtil.getStringValue(register, "value");
        }
      }catch (Exception e) {
        tableName = beanName;
      }
      bean.setEntityClass(tableName, mappingClass);
    }

    bean.setOrder(10000);   // default
    bean.setName(beanName);

  }

  private static String getDefaultEntityBeanName(ClassFile classFile) {
    String beanName = classFile.getName();
    if(StringUtils.endsWith(beanName, "Impl")){
      String candidateBeanName = StringUtils.substringBeforeLast(beanName, "Impl");
      String[] interfaces = classFile.getInterfaces();
      if(ArrayUtils.contains(interfaces, candidateBeanName)){
        return candidateBeanName;
      }
    }
    return beanName;
  }

  @Override
  protected void arrangeProperties(){

    try {
      CtClass ctClazz = BytecodeUtil.getDefrostedCtClass(ClassPool.getDefault(), entityClass.getName());

      Set<CtClass> classHierarchy = new HashSet<>();
      BytecodeUtil.getInterfaces(ctClazz, classHierarchy);

      for(CtClass ctClass : classHierarchy){
        ClassFile classFile = BytecodeUtil.getClassFileSafety(ctClass);

        List<FieldInfo> fieldInfos = classFile.getFields();
        for(FieldInfo info : CollectionUtils.emptyIfNull(fieldInfos)){
          String propertyName = info.getName();

          String propertyType = BytecodeUtil.getAnnotationTypeName(info);
          Class propertyClass = BytecodeUtil.getProperClass(info.getDescriptor(), true);
          this.classMappingProperties.put(propertyName, new RegisterEntityBeanPropertyDTO(propertyName, propertyType, propertyClass, false));

        }

      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Class getPropertyClass(String propertyName) {
    RegisterEntityBeanPropertyDTO property = this.classMappingProperties.get(propertyName);
    return property == null ? null : property.getPropertyClass();
  }
}
