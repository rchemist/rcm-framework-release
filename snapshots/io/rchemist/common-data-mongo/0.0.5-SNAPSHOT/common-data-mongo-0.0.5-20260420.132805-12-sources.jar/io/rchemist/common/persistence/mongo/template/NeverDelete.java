/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 *
 * NeverDelete 를 상속한 경우에는 ResponseEntityService 에서 실제 삭제되지 않고 active 값만 변경한다.
 * 시스템에서 사용하는 중요한 참조 엔티티의 경우 SoftDelete 로 처리하면 안 된다.
 * 이때 NeverDelete 를 사용해 생성된 엔티티를 삭제할 수 없도록 보호할 수 있다.
 **/
public interface NeverDelete<T> extends ClassTransformTarget {

  default Boolean getActive() {
    throw new ClassTransformException();
  }

  default void setActive(Boolean active) {
    throw new ClassTransformException();
  }
  
  default boolean isActive() {
    return BooleanUtils.toBooleanDefaultIfNull(getActive(), true);
  }

  default T withActive(Boolean active){
    setActive(active);
    return (T) this;
  }

}
