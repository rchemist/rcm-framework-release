/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.embedded;

import com.google.common.base.MoreObjects;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.type.PhoneType;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.Enumeration;
import io.rchemist.common.presentation.annotation.ValidationConfig;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Phone implements Serializable {

  @Indexed
  @Description(name = "전화번호 유형", comment = "핸드폰, 일반 전화, 팩스 등 전화번호의 유형을 관리")
  @AdminField(name = "Phone_PhoneType", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.PHONE)
      , order=1000, fieldType = PresentationFieldType.ENUMERATION
      , enumeration = @Enumeration(enumType = "io.rchemist.common.jpa.domain.type.PhoneType")
      , defaultValue = "MOBILE")
  protected PhoneType phoneType;

  @Indexed
  @Description(name = "국가 코드", comment = "ISO 국가 코드")
  @AdminField(name = "Phone_CountryCode", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.PHONE)
      , order=2000, fieldType = PresentationFieldType.ENUMERATION, enumeration = @Enumeration(values = "+82"))
  protected String countryCode;

  @WildcardIndexed
  @Description(name = "전화번호", comment = "전화번호")
  @AdminField(name = "Phone_Number", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.PHONE)
      , order=3000, fieldType = PresentationFieldType.STRING, validation = @ValidationConfig(provider = "numberOnlyValidator"))
  protected String phoneNumber;

  @Indexed
  @Description(name = "내선 번호", comment = "내선 번호")
  @AdminField(name = "Phone_ExtensionCode", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.PHONE)
      , order=4000, fieldType = PresentationFieldType.STRING)
  protected String extensionCode;

  public String getCountryCode(){
    if(StringUtils.isBlank(countryCode))
      return "";

    String countryCode = this.countryCode;

    if(countryCode.startsWith("+") && countryCode.length() == 4)
      return countryCode;

    if(countryCode.startsWith("0") && countryCode.length() == 3){
      countryCode = countryCode.substring(1, 2);
    }

    if(!countryCode.startsWith("+"))
      countryCode = "+"+countryCode;

    return countryCode;
  }

  public String getPhoneNumber(){
    if(StringUtils.isBlank(phoneNumber))
      return "";

    return phoneNumber;
  }

  public String getFullPhoneNumber(){
    String countryCode = getCountryCode();
    if(StringUtils.isNotBlank(countryCode))
      countryCode = countryCode + " ";

    return  countryCode + getPhoneNumber();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Phone)) {
      return false;
    }
    Phone phone = (Phone) o;
    return Objects.equals(getPhoneType(), phone.getPhoneType()) && Objects.equals(
        getCountryCode(), phone.getCountryCode()) && Objects.equals(getPhoneNumber(),
        phone.getPhoneNumber()) && Objects.equals(getExtensionCode(),
        phone.getExtensionCode());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getPhoneType(), getCountryCode(), getPhoneNumber(), getExtensionCode());
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("phoneType", phoneType.getType())
        .add("countryCode", countryCode)
        .add("phoneNumber", phoneNumber)
        .add("extensionCode", extensionCode)
        .toString();
  }
}
