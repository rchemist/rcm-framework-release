/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.embedded;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.ModifierType;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AmountOverride implements Serializable {

  protected String modifierType;

  protected BigDecimal modifierValue;

  public ModifierType getModifierType(){
    return EnumTypeUtil.getEnumType(ModifierType.class, modifierType);
  }

  public void setModifierType(ModifierType modifierType){
    this.modifierType = EnumTypeUtil.getType(modifierType);
  }

  public Money getModifiedMoney(Money originAmount){
    ModifierType modifierType = getModifierType();
    return (modifierType == null) ? originAmount : modifierType.calculate(originAmount, modifierValue);
  }

}
