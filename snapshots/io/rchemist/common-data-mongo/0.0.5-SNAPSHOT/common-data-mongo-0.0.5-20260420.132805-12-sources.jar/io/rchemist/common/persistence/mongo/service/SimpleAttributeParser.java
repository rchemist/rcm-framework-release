/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.service;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.Data;

@Data
public class SimpleAttributeParser implements Serializable {

    private Set<String> removedKeys;

    private Map<String, String> addedAttributes;

    public SimpleAttributeParser addRemoveKeys(String... keys) {
        if (removedKeys == null) {
            removedKeys = new HashSet<>();
        }

        if (keys != null) {
            removedKeys.addAll(Set.of(keys));
        }
        return this;
    }

    public SimpleAttributeParser addAttributes(String key, String value) {
        if (addedAttributes == null) {
            addedAttributes = new java.util.HashMap<>();
        }
        addedAttributes.put(key, value);
        return this;
    }

    public SimpleAttributeParser withRemovedKeys(Set<String> removedKeys) {
        this.removedKeys = removedKeys;
        return this;
    }

    public SimpleAttributeParser withAddedAttributes(Map<String, String> addedAttributes) {
        this.addedAttributes = addedAttributes;
        return this;
    }

    public Map<String, String> parse(Map<String, String> previousAttributes) {

        if (previousAttributes == null) {
            return addedAttributes;
        }

        if (removedKeys != null) {
            removedKeys.forEach(previousAttributes::remove);
        }

        if (addedAttributes != null) {
            previousAttributes.putAll(addedAttributes);
        }

        return previousAttributes;
    }


}
