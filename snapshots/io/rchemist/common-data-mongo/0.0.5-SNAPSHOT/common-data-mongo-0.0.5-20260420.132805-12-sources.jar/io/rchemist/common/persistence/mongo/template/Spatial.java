/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;


import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.mongo.embedded.Coordinates;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface Spatial<T> extends ClassTransformTarget {

  default Double[] getCoordinates(){
    throw new ClassTransformException();
  }

  default void setCoordinates(Double[] coordinates){
    throw new ClassTransformException();
  }

  default void setCoordinates(Coordinates coordinate){
    throw new ClassTransformException();
  }

  default void setCoordinates(Double longitude, Double latitude){
    throw new ClassTransformException();
  }

  default double getLongitude(){
    throw new ClassTransformException();
  }

  default double getLatitude() {
    throw new ClassTransformException();
  }

  default T withCoordinates(Coordinates coordinate){
    setCoordinates(coordinate.getCoordinates());
    return (T) this;
  }

  default T withCoordinates(Double[] coordinates){
    setCoordinates(coordinates);
    return (T) this;
  }

  default T withCoordinates(Double longitude, Double latitude){
    setCoordinates(longitude, latitude);
    return (T) this;
  }


}
