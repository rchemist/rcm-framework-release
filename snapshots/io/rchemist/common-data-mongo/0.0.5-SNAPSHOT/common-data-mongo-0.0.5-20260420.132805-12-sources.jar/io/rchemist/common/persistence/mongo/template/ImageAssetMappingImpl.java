/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(ImageAssetMapping.class)
public class ImageAssetMappingImpl implements Serializable, EnhancedTemplate {

  @Indexed
  @Description(name = "Asset 키", comment = "시스템에서 사용하는 매핑 키 값")
  @AdminField(order = Integer.MAX_VALUE, fieldType = PresentationFieldType.STRING, hidden = true)
  protected String assetKey;

  @WildcardIndexed
  @AdminField(order = 1000, fieldType = PresentationFieldType.IMAGE, name = "ImageAssetMappingImpl_AssetUrl")
  @Description(name = "Asset Url", comment = "Asset Url")
  protected String assetUrl;

  @Indexed
  @AdminField(order = Integer.MAX_VALUE, fieldType = PresentationFieldType.STRING, hidden = true)
  @Description(name = "Asset File Size", comment = "Asset File Size")
  protected Long fileSize;

}
