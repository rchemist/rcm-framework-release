/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(value = Periodic.class)
@Getter
@Setter
public class PeriodicImpl implements Serializable, EnhancedTemplate {

  @Indexed
  @Description(name = "기간 정보 - 년도", comment = "레코드가 생성된 시각의 yyyy 값")
  protected String periodicYear;

  @Indexed
  @Description(name = "기간 정보 - 월", comment = "레코드가 생성된 시각의 mm 값")
  protected String periodicMonth;

  @Indexed
  @Description(name = "기간 정보 - 일", comment = "레코드가 생성된 시각의 dd 값")
  protected String periodicDay;

  @Indexed
  @Description(name = "기간 정보 - 시간대", comment = "레코드가 생성된 시각의 HH 값")
  protected String periodicHour;

}
