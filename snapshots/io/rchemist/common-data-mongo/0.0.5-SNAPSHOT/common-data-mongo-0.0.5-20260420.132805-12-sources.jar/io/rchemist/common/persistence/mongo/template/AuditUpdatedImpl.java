/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.persistence.Column;
import java.io.Serializable;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Updated by kunner
 **/
@TemplateClass(AuditUpdated.class)
@Getter
@Setter
public class AuditUpdatedImpl implements Serializable, EnhancedTemplate {

  @Indexed
  @Description(name = "수정일", comment = "수정일")
  @AdminField(name = "AuditableUpdated_UpdatedAt", propertyName = "updatedAt", order = 300, readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS), fieldType = PresentationFieldType.DATETIME, modifiableType = ModifiableType.MODIFY_ONLY)
  protected Instant updatedAt;

  @Column(name = "UPDATED_BY")
  @Description(name = "수정자", comment = "수정자의 User ID")
  @AdminField(name = "AuditableUpdated_UpdatedBy", propertyName = "updatedBy", order = 400, readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS), fieldType = PresentationFieldType.STRING, modifiableType = ModifiableType.MODIFY_ONLY)
  protected String updatedBy;

  @Column(name = "UPDATED_BY_USER", updatable = false)
  @Description(name = "수정자 유형", comment = "수정자가 관리자인지 Customer 인지")
  protected String updatedByUserType;

  public AuditUserType getUpdatedByUserType() {
    if(updatedByUserType == null) {
      return null;
    } else {
      return EnumTypeUtil.getEnumType(AuditUserType.class, updatedByUserType);
    }
  }

  public void setUpdatedByUserType(AuditUserType updatedByUserType) {
    if(updatedByUserType == null){
      this.updatedByUserType = null;
    }else{
      this.updatedByUserType = updatedByUserType.getType();
    }
  }
}
