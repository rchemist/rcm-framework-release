/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetUrls<T> extends ClassTransformTarget {

  default List<String> getAssetUrls() {
    throw new ClassTransformException();
  }

  default void setAssetUrls(List<String> assetUrls) {
    throw new ClassTransformException();
  }

  default T withAssetUrls(List<String> assetUrls) {
    setAssetUrls(assetUrls);
    return (T) this;
  }

  default boolean hasAssetUrls() {
    return CollectionUtils.isNotEmpty(getAssetUrls());
  }

  default T addAssetUrls(String... links) {
    initializeAssetUrls();
    for (String link : links) {
      getAssetUrls().add(link);
    }
    return (T) this;
  }

  default T removeAssetUrl(String... links) {
    initializeAssetUrls();
    for (String link : links) {
      getAssetUrls().remove(link);
    }
    return (T) this;
  }

  default void initializeAssetUrls() {
    if (getAssetUrls() == null)
      setAssetUrls(new ArrayList<>());
  }

}
