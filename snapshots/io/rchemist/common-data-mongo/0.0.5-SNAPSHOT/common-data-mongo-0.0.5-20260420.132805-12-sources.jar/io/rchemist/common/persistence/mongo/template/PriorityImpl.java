/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * <p>
 * 이 필드를 template 로 사용하지 말고 javaassist bytecode 를 활용해 엔티티에 필드로 끼워 넣자.
 * Priority 를 implements 한 클래스를 대상으로 한다.
 **/
@TemplateClass(value = Priority.class)
public class PriorityImpl implements Serializable, EnhancedTemplate, Comparable<Priority<?>> {

  @Indexed
  @Description(name = "우선순위", comment = "우선순위. 오름차순, 즉 작은 수가 높은 우선순위를 갖는다.")
  @AdminField(order = 200, name = "Display_Priority", headerField = @HeaderField(searchable = false, sortable = false, order = 200)
      , fieldType = PresentationFieldType.INTEGER, minLength ="-9999" ,maxLength = "9999")
  protected Integer priority = 100;

  public Integer getPriority() {
    return (priority == null) ? 100 : priority;     // 기본값은 항상 100 으로 리턴
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  @Override
  public int compareTo(Priority p){
    return Integer.compare(getPriority(), p.getPriority());
  }
}
