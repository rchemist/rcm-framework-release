/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import java.util.List;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NullQueryProvider implements QueryParseProvider {

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.NULL);
  }

  @Override
  public Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values) {
    return condition.isNegative() ? Criteria.where(propertyName).isNull().not() : Criteria.where(propertyName).isNull();
  }

  @Override
  public int getOrder() {
    return 10;
  }
}
