/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.RepeatPeriodType;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(RepeatPeriod.class)
@Getter
@Setter
public class RepeatPeriodImpl implements Serializable, EnhancedTemplate {

  @Description(name = "반복되는 기간의 형태", comment = "n년 동안, n월 동안, n일 동안과 같은 반복되는 기간의 형태")
  protected String repeatPeriodType;

  @Description(name = "반복 기간", comment = "반복 기간의 형태가 얼마 동안 지속할지에 대한 기간 정보")
  protected Integer repeatPeriod;

  @Description(name = "반복 시작 시간", comment = "repeatPeriodType 이 PER_MONTH, PER_DAYS 일 때 시작점이 되는 기준일")
  protected LocalDate periodBaseDate;

  @Description(name = "반복되는 기간의 형태", comment = "repeatPeriodType 이 YEARLY 일 때 몇월 몇일에 산정하는지")
  protected String periodMonthDay;

  @Description(name = "반복되는 기간의 형태", comment = "매월, PER 월 일 때 기준일. 1일 ~ 31 일 (29 이상의 날짜가 셋팅되는 경우 해당 월 마지막 날짜가 셋팅된 날짜보다 작으면 해당 월의 마지막 날짜로 자동 인식)")
  protected Integer dueDay;

  public RepeatPeriodType getRepeatPeriodType() {
    return EnumTypeUtil.getEnumType(RepeatPeriodType.class, repeatPeriodType);
  }

  public void setRepeatPeriodType(RepeatPeriodType repeatPeriodType) {
    this.repeatPeriodType = EnumTypeUtil.getType(repeatPeriodType);
  }

}
