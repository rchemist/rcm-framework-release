/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data;

import io.rchemist.common.persistence.mongo.config.MongoEntityBeanHelper;
import io.rchemist.common.persistence.mongo.search.SearchServiceHelper;
import io.rchemist.common.persistence.mongo.template.EssentialEntity;
import io.rchemist.common.persistence.mongo.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.mongo.template.Historical;
import io.rchemist.common.persistence.mongo.template.HistoricalUUID;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.search.data.query.QueryCondition;
import io.rchemist.common.search.data.query.QueryConditionItem;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import org.apache.commons.collections4.CollectionUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Query;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class MongoSearchContext<T extends Serializable, S extends SearchFormWrapper<S>> implements
        SearchContext<T, S> {

  private static final String CACHE_KEY_SPLITTER = "_";

  @Getter
  private final Class<T> entityClass;

  private final S searchForm;

  private final QuerySpecification<T, S> specification;

  private String[] explicitSearchFields;

  @Getter
  private boolean forceFetchFromDB = false;

  @Getter
  private boolean shouldReturnEmpty = false;

  public MongoSearchContext(Class<T> entityClass, S searchForm, String... explicitSearchFields) {
    this.entityClass = entityClass;
    MongoEntityBeanHelper.getEntityBean(entityClass.getName());

    // SearchForm 인 경우 filters, sorts 를 검증하고, preservedFilterAndSortCriteria 를 생성한다.
    if (searchForm instanceof FilterMapSearchForm<?> searchFormInstance) {
      searchFormInstance.preparePreservedFilterAndSortCriteria(entityClass, false);
    }

    this.searchForm = searchForm;

    if (ArrayUtils.isNotEmpty(explicitSearchFields)) {
      this.explicitSearchFields = explicitSearchFields;
    } else {
      if (searchForm instanceof AbstractSearchForm<?> searchFormInstance) {
        this.explicitSearchFields = searchFormInstance.getSearchFieldNames(entityClass);
      }
    }

    this.specification = new QuerySpecification<>(entityClass, searchForm, this.explicitSearchFields);

    addSearchPredicates(this.explicitSearchFields);

    if (searchForm instanceof AbstractSearchForm<?> searchFormInstance) {
      this.forceFetchFromDB = searchFormInstance.isForceFetchFromDB();
      this.shouldReturnEmpty = searchFormInstance.isShouldReturnEmpty();
    }

  }

  public MongoSearchContext<T, S> addSearchPredicates(String... propertyNames){

    QueryConditionType conditionType = searchForm.isExactMatch() ? QueryConditionType.EQUAL : QueryConditionType.LIKE;

    this.specification.addConditions(null, conditionType, propertyNames);
    return this;
  }

  public MongoSearchContext<T, S> addSearchPredicates(QueryConditionType conditionType, String... propertyNames){
    if(ArrayUtils.isEmpty(propertyNames))
      return this;

    this.specification.addConditions(null, conditionType, propertyNames);

    return this;
  }

  public MongoSearchContext<T, S> addSearchPredicate(String propertyName, QueryConditionType conditionType, Object value){
    return addSearchPredicate(null, propertyName, conditionType, value);
  }


  public MongoSearchContext<T, S> addSearchPredicate(ConditionOperatorType operator, String propertyName, QueryConditionType conditionType, Object value) {

    this.specification.addConditions(operator, propertyName, conditionType, value);

    return this;
  }

  public Pageable getPageable(boolean includeSort){
    if(includeSort){
      // Sort 관련 로직이 모두 QuerySpecification 으로 이동했다. specification 이 없을 때만 이 로직이 동작한다.

      Sort sort = getPagingSort(null, null);


      if(EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)
              || EssentialUUIDEntity.class.isAssignableFrom(entityClass)
              || HistoricalUUID.class.isAssignableFrom(entityClass)
      ){

        if (sort.stream().noneMatch((predicate) -> StringUtils.equals(predicate.getProperty(), "createdAt"))) {
          sort = sort.and(Sort.by(Direction.DESC, "createdAt"));
        }

        if (EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)) {
          if (sort.stream().noneMatch((predicate) -> StringUtils.equals(predicate.getProperty(), "id"))) {
            sort = sort.and(Sort.by(Direction.DESC, "id"));
          }
        }

        return PageRequest.of(searchForm.getPage(), searchForm.getPageSize(), sort);
      }
    }
    return PageRequest.of(searchForm.getPage(), searchForm.getPageSize());
  }

  public MongoSearchContext<T, S> addSearchConditions(ConditionOperatorType operatorType, QueryCondition... conditions) {
    specification.addConditions(operatorType, conditions);
    return this;
  }

  public MongoSearchContext<T, S> addSearchConditions(ConditionOperatorType operatorType, QueryConditionItem... conditionItems){
    if(conditionItems == null && ArrayUtils.isEmpty(conditionItems))
      return this;
    QueryCondition condition = new QueryCondition().addQueryItems(conditionItems);
    return addSearchConditions(operatorType, condition);
  }

  protected Sort getPagingSort(String defaultSortProperty, Direction direction) {
    // 기본 sort 항목
    String[] sorts = getDefaultSortProperties(defaultSortProperty, direction);

    // searchForm 에 있는 명시적 sort 처리
    sorts = getExplicitSearchSortProperties(sorts);

    return SearchServiceHelper.getPagingSortProperties(entityClass, sorts, defaultSortProperty, direction);
  }

  private String[] getExplicitSearchSortProperties(String[] sorts) {
    Map<String, String> alters = new HashMap<>();

    if(ArrayUtils.isNotEmpty(explicitSearchFields)) {
      for(String searchField : explicitSearchFields){
        if(searchField.contains(":")){
          alters.put(StringUtils.substringBefore(searchField, ":"), StringUtils.substringAfter(searchField, ":"));
        }
      }

      if(MapUtils.isNotEmpty(alters)){

        List<String> sortList = new ArrayList<>();
        if(ArrayUtils.isNotEmpty(sorts)){
          for(String sort : sorts){
            String propertyName = StringUtils.substringBefore(sort, " ");
            if(alters.containsKey(propertyName)){
              sortList.add(alters.get(propertyName) + " " + StringUtils.substringAfter(sort, " "));
            }else{
              sortList.add(sort);
            }
          }
        }

        sorts = sortList.toArray(new String[0]);

      }
    }

    return sorts;
  }

  private String[] getDefaultSortProperties(String defaultSortProperty, Direction direction) {
    List<SortEntry> sortEntries = searchForm.getSorts();

    if(CollectionUtils.isEmpty(sortEntries)){
      // 기본 정렬 속성이 있는 경우 해당 속성과 방향을 문자열 배열로 반환
      if(defaultSortProperty != null && !defaultSortProperty.isEmpty()){
        return new String[]{defaultSortProperty + " " + direction.name()};
      }
      return null;
    }

    // List<SortEntry>에서 필드 이름과 정렬 방향 추출
    String[] sorts = new String[sortEntries.size()];
    for (int i = 0; i < sortEntries.size(); i++) {
      SortEntry entry = sortEntries.get(i);
      String sortDirection = entry.getSortInfo() != null
          ? entry.getSortInfo().getDirection().name()
          : direction.name();
      sorts[i] = entry.getFieldName() + " " + sortDirection;
    }

    return sorts;
  }

  public String getCacheKey() {
    return getCacheKey(null);
  }

  public String getCacheKey(String prefix) {

    QuerySpecificationCache cache = new QuerySpecificationCache(specification);

    String cacheKey = cache.getCacheKey();

    if (StringUtils.isNotEmpty(prefix)) {
      return prefix + cacheKey;
    }

    return cacheKey;
  }

  @Override
  public void revertSearchForm() {
    if (searchForm != null && searchForm instanceof FilterMapSearchForm<?> filterMapSearchForm) {
      filterMapSearchForm.revertPreservedFilterAndSortCriteria();
    }
  }

  public Query getQuery(boolean includePaging) {

    Query query = specification.getQuery();

    if (includePaging) {
      query.with(getPageable(true));
    }

    return query;
  }

}
