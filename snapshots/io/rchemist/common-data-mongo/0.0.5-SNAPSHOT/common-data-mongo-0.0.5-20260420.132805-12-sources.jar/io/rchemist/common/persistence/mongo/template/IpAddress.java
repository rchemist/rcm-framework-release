/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.type.DeviceType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface IpAddress<T> extends ClassTransformTarget {

  default String getIpAddress(){throw new ClassTransformException();}
  default void setIpAddress(String ipAddress){
    throw new ClassTransformException();
  }

  default String getMacAddress(){throw new ClassTransformException();}
  default void setMacAddress(String macAddress){
    throw new ClassTransformException();
  }

  default DeviceType getDeviceType(){throw new ClassTransformException();}
  default void setDeviceType(DeviceType deviceType){
    throw new ClassTransformException();
  }

  default T withIpAddress(String ipAddress){
    setIpAddress(ipAddress);
    return (T) this;
  }

  default T withMacAddress(String macAddress){
    setMacAddress(macAddress);
    return (T) this;
  }

  default T withDeviceType(DeviceType deviceType){
    setDeviceType(deviceType);
    return (T) this;
  }
}
