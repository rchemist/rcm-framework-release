/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.rchemist.common.persistence.mongo;

import io.rchemist.common.configuration.ApplicationContextHolder;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
public class SequenceGenerator {

  private static SequenceGenerator sequenceGenerator;

  public SequenceGenerator(@Autowired(required = false) MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  private final MongoTemplate mongoTemplate;

  public long generateSequence(String sequenceCollection){
    if (Objects.isNull(mongoTemplate)) {
      throw new UnsupportedOperationException("ReactiveMongoTemplate is not initialized");
    }
    DatabaseSequence counter = mongoTemplate.findAndModify(Query.query(Criteria.where("_id").is(sequenceCollection)),
        new Update().inc("sequence",1), FindAndModifyOptions.options().returnNew(true).upsert(true),
        DatabaseSequence.class);
    return !Objects.isNull(counter) ? counter.getSequence() : 1;
  }

  public static SequenceGenerator get() {
    if (sequenceGenerator == null) {
      sequenceGenerator = ApplicationContextHolder.getBean(SequenceGenerator.class);
    }
    return sequenceGenerator;
  }

  public static long getNext(String sequenceCollection) {
    return get().generateSequence(sequenceCollection);
  }

}
