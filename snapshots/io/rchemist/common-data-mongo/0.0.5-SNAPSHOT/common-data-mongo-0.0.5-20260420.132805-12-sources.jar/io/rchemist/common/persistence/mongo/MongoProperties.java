/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo;

import lombok.Data;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class MongoProperties {

  protected String connectionString;

  private String username;

  private String password;

  private String host;

  private String port;

  private String database;

  private String authSource;

  private Boolean retryWrites = false;


  public MongoProperties setConnectionStringIfMissing(String connectionString) {
    if(this.connectionString == null) this.connectionString = connectionString;
    return this;
  }

  public MongoProperties setUsernameIfMissing(String username) {
    if(this.username == null) this.username = username;
    return this;
  }

  public MongoProperties setPasswordIfMissing(String password) {
    if(this.password == null) this.password = password;
    return this;
  }

  public MongoProperties setHostIfMissing(String host) {
    if(this.host == null) this.host = host;
    return this;
  }

  public MongoProperties setPortIfMissing(String port) {
    if(this.port == null) this.port = port;
    return this;
  }

  public MongoProperties setDatabaseIfMissing(String database) {
    if(this.database == null) this.database = database;
    return this;
  }

  public MongoProperties setAuthSourceIfMissing(String authSource){
    if(this.authSource == null) this.authSource = authSource;
    return this;
  }

}
