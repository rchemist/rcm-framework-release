/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo;

import io.rchemist.common.persistence.mongo.config.MongoEntityBean;
import io.rchemist.common.persistence.mongo.config.MongoEntityBeanHelper;
import javassist.NotFoundException;
import org.reflections.Reflections;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.mongodb.config.MongoConfigurationSupport;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractMongodbSetting extends MongoConfigurationSupport implements
  ApplicationContextAware {

  public static final String TRANSACTION_MANAGER = "nosqlTransactionManager";

  @Value("${spring.data.mongodb.username:rcm-client}")
  private String username;

  @Value("${spring.data.mongodb.password:rcm-pwd}")
  private String password;

  @Value("${spring.data.mongodb.database:admin}")
  private String database;

  @Value("${spring.data.mongodb.authSource:admin}")
  private String authSource;

  @Value("${spring.data.mongodb.connectionString:}")
  private String connectionString;

  protected MongoProperties setDefaultValues(MongoProperties props){
    props.setDatabaseIfMissing(database);
    props.setPasswordIfMissing(password);
    props.setUsernameIfMissing(username);
    props.setAuthSourceIfMissing(authSource);
    props.setConnectionStringIfMissing(connectionString);
    return props;
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    // MongoEntity 를 모두 조회해 해당 엔티티의 MongoEntityBean 을 캐싱한다.
    Reflections reflections = new Reflections();
    reflections.getTypesAnnotatedWith(Document.class).forEach(clazz -> {
      try {
        MongoEntityBean bean = MongoEntityBean.registerEntityBean(clazz);
        if (bean != null) {
          MongoEntityBeanHelper.put(clazz.getName(), bean);
        }
      } catch (NotFoundException e) {
        // skipping
      }
    });
  }
}
