/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(NameDetailDescription.class)
@Getter
@Setter
public class NameDetailDescriptionImpl implements Serializable, EnhancedTemplate {

  @AdminField(name = "NameDescriptionImpl_Name", fieldType = PresentationFieldType.STRING, order = 200
      , headerField = @HeaderField(order = 200), required = true
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 300)
  )
  @WildcardIndexed
  @Description(name = "이름", comment = "이름")
  protected String name;

  @AdminField(name = "NameDescriptionImpl_Description", fieldType = PresentationFieldType.TEXT, order = 210
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 210)
  )
  @Description(name = "설명", comment = "설명")
  protected String description;

  @AdminField(name = "NameDescriptionImpl_LongDescription", fieldType = PresentationFieldType.HTML, order = 220
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 220)
  )
  @Description(name = "상세 설명", comment = "상세 설명")
  protected String longDescription;

}
