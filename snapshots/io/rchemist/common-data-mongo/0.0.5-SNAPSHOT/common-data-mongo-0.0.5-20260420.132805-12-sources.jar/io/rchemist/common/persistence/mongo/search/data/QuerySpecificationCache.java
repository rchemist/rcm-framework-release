/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.search.data.query.QueryCondition;
import io.rchemist.common.util.GsonUtil;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class QuerySpecificationCache implements Serializable {

  private static final String DEFAULT_CACHE_KEY = "DEFAULT";

  private static final String CACHE_KEY_SPLITTER = "_";

  private final Integer page;
  private final Integer pageSize;
  private final SortInfo[] sort;

  private final Map<ConditionOperatorType, QueryCondition> conditions;

  public QuerySpecificationCache(QuerySpecification specification) {

    SearchFormWrapper<?> searchForm = specification.getSearchForm();

    this.page = searchForm != null ? searchForm.getPage() : null;
    this.pageSize = searchForm != null ? searchForm.getPageSize() : null;
    // List<SortEntry>에서 SortInfo 배열로 변환
    this.sort = extractSortInfo(searchForm);
    this.conditions = specification.getConditions();
  }

  /**
   * SearchForm에서 SortInfo 배열 추출
   */
  private SortInfo[] extractSortInfo(SearchFormWrapper<?> searchForm) {
    if (searchForm == null) {
      return null;
    }
    List<SortEntry> sortEntries = searchForm.getSorts();
    if (CollectionUtils.isEmpty(sortEntries)) {
      return null;
    }
    return sortEntries.stream()
        .map(SortEntry::getSortInfo)
        .filter(java.util.Objects::nonNull)
        .toArray(SortInfo[]::new);
  }

  protected boolean shouldCreateCacheKey() {
    if (page != null && page > 0) {
      return true;
    }
    if (pageSize != null && pageSize != 10) {
      return true;
    }
    if (ArrayUtils.isNotEmpty(sort)) {
      return true;
    }
    if (MapUtils.isNotEmpty(conditions)) {
      return true;
    }
    return false;
  }

  public String getCacheKey() {
    if (!shouldCreateCacheKey()) {
      return DEFAULT_CACHE_KEY;
    }

    StringBuilder sb = new StringBuilder();

    try {
      sb.append(GsonUtil.toJson(this));
    } catch (Exception e) {
      sb.append(getCacheKeySeparate(page))
          .append(CACHE_KEY_SPLITTER)
          .append(getCacheKeySeparate(pageSize))
          .append(CACHE_KEY_SPLITTER)
          .append(getCacheKeySeparate(sort))
          .append(CACHE_KEY_SPLITTER)
          .append(getCacheKeySeparate(conditions))
          .append(CACHE_KEY_SPLITTER);
    }

    String cacheKey = sb.toString();
    return String.valueOf(Objects.hash(cacheKey));
  }

  private String getCacheKeySeparate(Object value) {
    if (value == null) {
      return "";
    }
    String key;
    try {
      key = GsonUtil.toJson(value);
    }catch (Exception e) {
      key = String.valueOf(value);
    }
    return key;
  }

}
