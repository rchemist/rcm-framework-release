/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface AssetMapping<T> {

  default String getAssetKey(){throw new ClassTransformException();}

  default void setAssetKey(String assetKey){
    throw new ClassTransformException();
  }

  default String getAssetUrl(){throw new ClassTransformException();}

  default void setAssetUrl(String assetUrl){
    throw new ClassTransformException();
  }

  default Long getFileSize(){throw new ClassTransformException();}

  default void setFileSize(Long fileSize){
    throw new ClassTransformException();
  }

  default String[] getAssetTags(){
    throw new ClassTransformException();
  }

  default void setAssetTags(String[] assetTag){
    throw new ClassTransformException();
  }

  default String getAssetLink(){
    throw new ClassTransformException();
  }

  default void setAssetLink(String assetLink){
    throw new ClassTransformException();
  }

  default void setAsset(AttachAsset asset){
    if(asset == null) {
      setAssetKey(null);
      setAssetUrl(null);
      setFileSize(null);
      setAssetTags(null);
      setAssetLink(null);
    } else {
      setAssetUrl(asset.getAssetUrl());
      setAssetKey(asset.getAssetKey());
      setFileSize(asset.getFileSize());
      setAssetTags(asset.getAssetTags());
      setAssetLink(asset.getAssetLink());
    }
  }

  default AttachAsset getAsset(){return new AttachAsset(getAssetKey(), getFileSize(), getAssetUrl(), getAssetTags(), getAssetLink());}

  default T withAssetKey(String assetKey) {
    setAssetKey(assetKey);
    return (T) this;
  }

  default T withFileSize(Long fileSize) {
    setFileSize(fileSize);
    return (T) this;
  }

  default T withAssetUrl(String assetUrl) {
    setAssetUrl(assetUrl);
    return (T) this;
  }

  default T withAssetTags(String... assetTags) {
    setAssetTags(assetTags);
    return (T) this;
  }

  default T withAssetLink(String assetLink) {
    setAssetLink(assetLink);
    return (T) this;
  }

  default String getAssetUri(){
    return (getAsset() != null && getAsset().validateAsset()) ?
        getAsset().getUri() : null;
  }

}
