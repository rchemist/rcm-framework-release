/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.search.data.provider;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.StringUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.mongodb.core.query.Criteria;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * IN/NOT_IN, BETWEEN, NOT_BETWEEN
 **/
@Slf4j
public class CollectionQueryProvider implements QueryParseProvider {

  private static final String WILD_CARD_CHARACTER = ".%";
  private static final String IGNORE_CASE = "i";

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.COLLECTION);
  }

  @Override
  public Criteria getCriteria(String propertyName, Class propertyClass, QueryConditionType condition, Object value, List<?> values) {

    if(values == null || values.size() == 0){
      if(value != null){
        values = CollectionUtil.list(MongoQueryHelper.getAppropriateValue(propertyClass, value));
      }
    }

    if(CollectionUtils.isEmpty(values))
      return null;

    Criteria criteria = null;

    if(condition.equals(QueryConditionType.IN) || condition.equals(QueryConditionType.NOT_IN)){

      // 이 필드가 String[] 인지 확인해야 한다.

      if (String[].class.isAssignableFrom(propertyClass)) {
        List<Criteria> criteriaList = new ArrayList<>();

        for (Object itemValue : values) {
          String v = WILD_CARD_CHARACTER + StringUtil.getString(itemValue) + WILD_CARD_CHARACTER;
          criteriaList.add(Criteria.where(propertyName).regex(v, IGNORE_CASE));
        }

        criteria = Criteria.where(propertyName).orOperator(criteriaList.toArray(new Criteria[0]));
        if (condition.equals(QueryConditionType.NOT_IN)) {
          criteria = criteria.not();
        }

      } else {
        criteria = Criteria.where(propertyName).in(values);
        if (condition.equals(QueryConditionType.NOT_IN)) {
          criteria = criteria.not();
        }
      }

    }else{

      if (String[].class.isAssignableFrom(propertyClass)) {
        log.warn("String[] 타입에 대한 Collection 검색은 in / not in 만 가능합니다.");
        return null;
      }

      // between 에서 2 이상의 parameter 가 필요하다.
      if(values.size() < 2 || values.get(1) == null){
        criteria = MongoQueryHelper.getCriteria(propertyName, propertyClass, QueryConditionType.EQUAL, values.get(0), values);
      }else{

        Object value1 = values.get(0);
        Object value2 = values.get(1);

        criteria = Criteria.where(propertyName).gte(MongoQueryHelper.getAppropriateValue(propertyClass, value1)).lte(MongoQueryHelper.getAppropriateValue(propertyClass, value2));

      }
    }

    return (criteria == null) ? null : (condition.isNegative()) ? criteria.not() : criteria;
  }


  @Override
  public int getOrder() {
    return 400;
  }
}
