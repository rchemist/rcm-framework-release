/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.mongo.embedded.Name;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface FullName<T> extends ClassTransformTarget {

  default Name getName() {
    throw new ClassTransformException();
  }

  default void setName(Name name) {
    throw new ClassTransformException();
  }

  default T withName(Name name) {
    setName(name);
    return (T) this;
  }

  default String getFullName() {
    throw new ClassTransformException();
  }

  default String getFirstName() {
    throw new ClassTransformException();
  }

  default String getLastName() {
    throw new ClassTransformException();
  }

  default String getMiddleName() {
    throw new ClassTransformException();
  }

  default void setFirstName(String firstName) {
    throw new ClassTransformException();
  }

  default void setLastName(String lastName) {
    throw new ClassTransformException();
  }

  default void setMiddleName(String middleName) {
    throw new ClassTransformException();
  }

  default T withFirstName(String firstName) {
    setFirstName(firstName);
    return (T) this;
  }

  default T withLastName(String lastName) {
    setLastName(lastName);
    return (T) this;
  }

  default T withMiddleName(String middleName) {
    setMiddleName(middleName);
    return (T) this;
  }



}
