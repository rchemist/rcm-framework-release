/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.template.presentation.UserProfile;
import io.rchemist.common.util.type.SiteType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface UserMapping<T> extends ClassTransformTarget {

  default String getUserId() {
    throw new ClassTransformException();
  }

  default void setUserId(String userId) {
    throw new ClassTransformException();
  }

  default T withUserId(String userId) {
    setUserId(userId);
    return (T) this;
  }

  default boolean hasUserId() {
    return getUserId() != null;
  }

  default String getUserName() {
    return null;
  }

  default void setUserName(String userName) {
  }

  default T withUserName(String userName) {
    setUserName(userName);
    return (T) this;
  }

  default UserProfile getUserProfile() {
    return new UserProfile() {
      @Override
      public String getLoginName() {
        return null;
      }

      @Override
      public String getName() {
        return getUserName();
      }

      @Override
      public String getNickname() {
        return getUserName();
      }

      @Override
      public String getId() {
        return getUserId();
      }

      @Override
      public SiteType getSiteType() {
        return null;
      }
    };
  }

}
