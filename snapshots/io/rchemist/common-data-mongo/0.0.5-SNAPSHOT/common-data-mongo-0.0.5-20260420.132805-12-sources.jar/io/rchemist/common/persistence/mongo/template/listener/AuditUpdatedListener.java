/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template.listener;

import io.rchemist.common.persistence.domain.template.listener.AuditListener;
import io.rchemist.common.persistence.domain.template.listener.type.AuditType;
import io.rchemist.common.persistence.mongo.template.AuditUpdated;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.BeforeConvertEvent;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmAuditUpdatedListener")
public class AuditUpdatedListener extends AbstractMongoEventListener<AuditUpdated<?>> implements AuditListener {

  @Override
  public void onBeforeConvert(BeforeConvertEvent<AuditUpdated<?>> event) {
    AuditUpdated<?> source = event.getSource();
    try {
      audit(source, AuditType.UPDATE);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
