/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.mongo.service.SimpleAttributeParser;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SimpleAttributes<T> extends ClassTransformTarget {

  default String getSimpleAttributeValue(String key){
    throw new ClassTransformException();
  }
  default Map<String, String> getSimpleAttributes(){throw new ClassTransformException();}
  default void setSimpleAttributes(Map<String, String> simpleAttributes) {
    throw new ClassTransformException();
  }
  default void addSimpleAttribute(String key, String value){
    throw new ClassTransformException();
  }

  default T withSimpleAttributes(Map<String, String> simpleAttributes) {
    setSimpleAttributes(simpleAttributes);
    return (T) this;
  }

  /**
   * DTO 가 SimpleAttributes 를 구현하고 있을 경우, modifiedFields 에 attribute 필드가 있는 경우 최신 정보를 리턴한다.
   * 만약 modifiedFields 에는 값이 있는데 SimpleAttributes 에 값이 없을 때는 해당 key 를 삭제한다는 뜻이다.
   *
   * @param previousAttributes 기존 저장되어 있는 Map 정보
   * @param attributePrefix modifiedFields 에 attribute 필드가 있는 경우, attributePrefix 를 제외한 나머지 부분이 attribute key 가 된다.
   * @param modifiedFields Form DTO 에서 수정된 필드 목록
   * @return
   */
  default void updateAttributes(Map<String, String> previousAttributes, String attributePrefix, String... modifiedFields) {

    Map<String, String> attributes;

    if (modifiedFields == null || modifiedFields.length < 1){
      setSimpleAttributes(previousAttributes);
      return;
    } else {
      attributes = getSimpleAttributes();
    }

    SimpleAttributeParser parser = new SimpleAttributeParser();

    for (String fieldName : modifiedFields) {

      if (fieldName.startsWith(attributePrefix)) {
        String attributeName = fieldName.substring(attributePrefix.length());
        if (!attributes.containsKey(attributeName)) {
          parser.addRemoveKeys(attributeName);
        } else {
          parser.addAttributes(attributeName, attributes.get(attributeName));
        }
      }

    }

    attributes = parser.parse(previousAttributes);
    setSimpleAttributes(attributes);
  }

}
