/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.UrlUtil;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(Slug.class)
@Getter
@Setter
public class SlugImpl implements Serializable, EnhancedTemplate {

  private static final String SLASH = "/";

  @Indexed
  @Description(name = "URL", comment = "Front Site에서 이 정보에 접근할 수 있는 URL 정보")
  protected String slug;

  public void setSlug(String slug) {
    this.slug = UrlUtil.getValidatedSlug(slug);
  }

  public String getSlug() {
    return this.slug;
  }

}
