/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.embedded;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.util.KoreanUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.data.AppendStringSource;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Name implements Serializable {

  public Name(String lastName, String firstName, String middleName) {
    this.lastName = lastName;
    this.firstName = firstName;
    this.middleName = middleName;
  }

  @WildcardIndexed
  @Description(name = "성", comment = "성")
  protected String lastName;

  @WildcardIndexed
  @Description(name = "이름", comment = "이름")
  protected String firstName;

  @WildcardIndexed
  @Description(name = "중간 이름", comment = "중간 이름 (필요시)")
  protected String middleName;

  @WildcardIndexed
  @Description(name = "전체 이름", comment = "전체 이름")
  @Setter(AccessLevel.PRIVATE)  // 전체 이름은 반드시 firstName, middleName, lastName 의 조합으로 저장되어야 한다.
  protected String fullName;

  @Description(name = "전체 이름 초성", comment = "전체 이름 초성")
  @WildcardIndexed
  protected String fullNameConsonant;

  @Description(name = "전체 이름 발음", comment = "전체 이름 발음")
  @WildcardIndexed
  protected String fullNamePhoneme;

  public boolean validate() {
    if(StringUtils.isEmpty(getFirstName()) && StringUtils.isEmpty(getLastName())) {
      return false;
    }
    return true;
  }

  private String makeFullName(){
    // 영어식 이름이라면 makeFullName 을 사용해야 한다.
    return new AppendStringSource.TrimAndAppend(getFirstName(), false, getMiddleName(), getLastName())
        .splitCode(" ")
        .toString();
  }

  private void mergeFullName(){
    this.fullName = (StringUtil.toString(getLastName()) +
        StringUtil.toString(getFirstName()) +
        StringUtil.toString(getMiddleName()));

    this.fullNameConsonant = KoreanUtil.getConsonants(this.fullName);
    this.fullNamePhoneme = KoreanUtil.getPhonemes(this.fullName);
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
    mergeFullName();
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
    mergeFullName();
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
    mergeFullName();
  }

  public Name withLastName(String lastName) {
    setLastName(lastName);
    return this;
  }

  public Name withFirstName(String firstName) {
    setFirstName(firstName);
    return this;
  }

  public Name withMiddleName(String middleName) {
    setMiddleName(middleName);
    return this;
  }

  public String getLastName() {
    return StringUtils.defaultIfEmpty(lastName, "");
  }

  public String getFirstName() {
    return StringUtils.defaultIfEmpty(firstName, "");
  }

  public String getMiddleName() {
    return StringUtils.defaultIfEmpty(middleName, "");
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("lastName", lastName)
        .add("firstName", firstName)
        .add("middleName", middleName)
        .add("fullName", getFullName())
        .toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Name name = (Name) o;
    return Objects.equal(lastName, name.lastName)
        && Objects.equal(firstName, name.firstName)
        && Objects.equal(middleName, name.middleName)
        && Objects.equal(fullName, name.fullName);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(lastName, firstName, middleName, fullName);
  }
}
