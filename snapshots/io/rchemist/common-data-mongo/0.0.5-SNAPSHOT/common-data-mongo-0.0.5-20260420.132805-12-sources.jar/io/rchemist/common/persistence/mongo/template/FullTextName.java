/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * <p>
 *   이름을 정의할 때 firstName, lastName, middleName 등을 관리하지 않고 하나의 필드로만 관리할 때 사용한다.
 *   이름을 분리해 저장하려면 FullName 을 사용한다.
 * </p>
 *
 **/
public interface FullTextName<T> extends ClassTransformTarget, SearchableName {

  default String getName() {
    throw new ClassTransformException();
  }

  default void setName(String name) {
    throw new ClassTransformException();
  }

  default T withName(String name) {
    setName(name);
    return (T) this;
  }

}
