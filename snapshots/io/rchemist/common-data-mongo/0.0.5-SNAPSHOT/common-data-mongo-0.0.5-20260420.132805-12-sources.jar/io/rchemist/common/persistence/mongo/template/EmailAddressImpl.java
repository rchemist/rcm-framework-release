/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(EmailAddress.class)
public class EmailAddressImpl implements EnhancedTemplate {

  @WildcardIndexed
  @Description(name = "이메일주소")
  protected String emailAddress;

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = StringUtils.lowerCase(emailAddress);
  }

  public String getEmailAddress() {
    return StringUtils.lowerCase(this.emailAddress);
  }

}
