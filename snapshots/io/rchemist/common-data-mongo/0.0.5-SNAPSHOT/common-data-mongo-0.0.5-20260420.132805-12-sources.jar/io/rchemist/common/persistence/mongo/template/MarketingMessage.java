/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * MarketingMessage 는 다국어를 지원한다.
 * 따라서 이 템플릿 클래스를 구현한 엔티티 클래스는 반드시
 * TranslatedEntity 에 등록되어야 한다.
 *
 **/
public interface MarketingMessage<T> extends ClassTransformTarget {

  default String getMarketingMessage(){throw new ClassTransformException();}
  default void setMarketingMessage(String marketingMessage){
    throw new ClassTransformException();
  }

  default String getMarketingLink(){throw new ClassTransformException();}
  default void setMarketingLink(String marketingLink){
    throw new ClassTransformException();
  }

  default T withMarketingMessage(String marketingMessage){
    setMarketingMessage(marketingMessage);
    return (T) this;
  }
  default T withMarketingLink(String marketingLink){
    setMarketingLink(marketingLink);
    return (T) this;
  }
}
