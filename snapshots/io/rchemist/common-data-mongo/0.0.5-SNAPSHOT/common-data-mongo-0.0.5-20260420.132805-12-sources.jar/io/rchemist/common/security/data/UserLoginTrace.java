/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.security.data;

import io.rchemist.common.persistence.mongo.template.AuditCreated;
import jakarta.persistence.Id;
import java.io.Serializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Document("user_login_trace_data")
@Getter
@Setter
@NoArgsConstructor
public class UserLoginTrace implements Serializable, AuditCreated<UserLoginTrace> {

  @Id
  protected String id;

  @Indexed
  protected String userId;

  protected String ipAddress;

  protected Boolean success;

  protected Integer failedCount = 0;

  public UserLoginTrace withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public UserLoginTrace withIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
    return this;
  }

  public UserLoginTrace withSuccess(Boolean success) {
    this.success = success;
    return this;
  }

  public UserLoginTrace withFailedCount(Integer failedCount) {
    this.failedCount = failedCount;
    return this;
  }

  public boolean isSuccess(){
    return BooleanUtils.toBoolean(success);
  }

  public static UserLoginTrace create(String userId, boolean success, int failedCount) {
    return new UserLoginTrace()
        .withUserId(userId)
        .withSuccess(success)
        .withFailedCount(failedCount);
  }


  public static UserLoginTrace success(String userId) {
    return create(userId, true, 0);
  }

  public UserLoginTrace fail() {
    return create(getUserId(), false, BooleanUtils.toBoolean(success) ? 0 : getFailedCount() + 1);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    UserLoginTrace that = (UserLoginTrace) object;

    return new EqualsBuilder().append(id, that.id)
        .append(userId, that.userId).append(ipAddress, that.ipAddress).append(success, that.success)
        .append(failedCount, that.failedCount).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(id).append(userId).append(ipAddress).append(success)
        .append(failedCount).toHashCode();
  }

  @Override
  public String toString() {
    return "UserLoginTrace{" +
        "id='" + id + '\'' +
        ", userId='" + userId + '\'' +
        ", ipAddress='" + ipAddress + '\'' +
        ", success=" + success +
        ", failedCount=" + failedCount +
        ", createdAt=" + getCreatedAt() +
        '}';
  }
}

