/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.data.RuleFieldValue;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface RuleMapping<T> extends ClassTransformTarget {

  default String getRuleKey(){throw new ClassTransformException();}

  default void setRuleKey(String ruleKey){
    throw new ClassTransformException();
  }

  default String getRule() {
    throw new ClassTransformException();
  }

  default void setRule(String rule){
    throw new ClassTransformException();
  }

  default void addMatchRule(String rule){
    if(StringUtils.isNotBlank(getRule())){
      setRule(StringUtils.joinWith("&", getRule(), rule));
    }else{
      setRule(rule);
    }
  }

  default T withRuleKey(String ruleKey){
    setRuleKey(ruleKey);
    return (T) this;
  }

  default T withRule(String rule){
    setRule(rule);
    return (T) this;
  }

  default RuleFieldValue getRuleFieldValue() {
    return new RuleFieldValue().withRuleKey(getRuleKey()).withRule(getRule());
  }
}
