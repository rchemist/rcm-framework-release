/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.TenantUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface TenantAlias<T> extends ClassTransformTarget {

  default String getTenantAlias(){
    throw new ClassTransformException();
  }

  default void setTenantAlias(String tenantAlias){
    throw new ClassTransformException();
  }

  default boolean isEqualTenant(String tenantAlias){
    return StringUtils.equals(getTenantAlias(), tenantAlias);
  }

  /**
   * 요청한 TenantAlias 값이 없거나, 이 엔티티에 TenantAlias 값이 없거나, 두 TenantAlias 가 일치할 때 allowedTenant 가 된다.
   * @param tenantAlias
   * @return
   */
  default boolean isAllowedTenant(String tenantAlias) {
    return (StringUtils.isEmpty(tenantAlias)    // 요청한 tenantAlias 가 없거나
        || !hasTenantAlias()    // 이 엔티티에 tenantAlias 가 없거나
        || isEqualTenant(tenantAlias) // 두 tenantAlias 가 동일하거나
        || StringUtils.equals(tenantAlias, TenantUtil.DEFAULT_TENANT_ALIAS)  // 요청한 tenantAlias 가 defaultTenant 인 경우
    );
  }

  default T withTenantAlias(String tenantAlias){
    setTenantAlias(tenantAlias);
    return (T) this;
  }

  default boolean hasTenantAlias(){
    return StringUtils.isNotEmpty(getTenantAlias());
  }



}
