/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.DeviceType;
import java.io.Serializable;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.WildcardIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(value = IpAddress.class)
@Getter
@Setter
public class IpAddressImpl implements Serializable, EnhancedTemplate {

  @WildcardIndexed
  @Description(name = "IP 주소", comment = "IP 주소")
  protected String ipAddress;

  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @Indexed
  @Description(name = "디바이스 유형", comment = "디바이스 유형. (PC, MOBILE, MOBILE_APP, UNIDENTIFIED)")
  protected String deviceType;

  @Indexed
  @Description(name = "MAC 주소", comment = "MAC 주소")
  protected String macAddress;


  public DeviceType getDeviceType(){
    return EnumTypeUtil.getEnumType(DeviceType.class, deviceType);
  }

  public void setDeviceType(DeviceType deviceType){
    if(deviceType != null){
      this.deviceType = deviceType.getType();
    }else{
      this.deviceType = null;
    }
  }

}
