/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * Bytecode assist 로 SoftDelete 를 implements 하는 모든 class 에 다음과 같은 필드를 추가한다
 * <p>
 * // 엔티티 선언 부
 *
 * SoftDelete 를 implements 한 Class 를 extends 하는 경우 상속 받은 클래스에서도 반드시 SoftDelete 를 implements 해야 한다.
 * (Hibernate 이슈)
 *
 * @SQLDelete(sql="UPDATE T_TNT_USER SET ARCHIVED = true WHERE USER_ID = ?")
 * <p>
 * // 프로퍼티 추가
 * @Column(name = "ARCHIVED")
 * boolean archived;
 * <p>
 * // getter / setter
 **/

public interface SoftDelete<T> extends ClassTransformTarget {

  default Boolean getArchived() {
    throw new ClassTransformException();
  }

  default boolean isArchived() {
    return BooleanUtils.toBoolean(getArchived());
  }
  default void setArchived(Boolean archived) {
    throw new ClassTransformException();
  }

  default Boolean getActive(){
    throw new ClassTransformException();
  }

  // 기본적으로 isActive 는 archived 되지 않은 것이다
  default boolean isActive() {
    return !isArchived() && !isTemporaryDeleted();
  }

  default void setActive(Boolean active){
    throw new ClassTransformException();
  }

  default Boolean getTemporaryDeleted(){
    throw new ClassTransformException();
  }

  default void setTemporaryDeleted(Boolean temporaryDeleted){
    throw new ClassTransformException();
  }

  default boolean isTemporaryDeleted(){
    return BooleanUtils.toBoolean(getTemporaryDeleted());
  }

  default T withArchived(Boolean archived){
    setArchived(archived);
    return (T) this;
  }

  default T withActive(Boolean active){
    setActive(active);
    return (T) this;
  }

  default T withTemporaryDeleted(Boolean temporaryDeleted){
    setTemporaryDeleted(temporaryDeleted);
    return (T) this;
  }

}
