/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.embedded;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import java.io.Serializable;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class MongoAsset implements Serializable {

  private String assetName;

  private long fileSize;

  private String assetUrl;

  private String[] assetTags;

  public MongoAsset() {
  }

  public MongoAsset(String assetName, long fileSize, String assetUrl, String[] assetTags) {
    this.assetName = assetName;
    this.fileSize = fileSize;
    this.assetUrl = assetUrl;
    this.assetTags = assetTags;
  }

  public MongoAsset(AttachAsset asset){
    this(asset.getAssetKey(), asset.getFileSize(), asset.getAssetUrl(), asset.getAssetTags());
  }

  public MongoAsset withAssetName(String assetName) {
    this.assetName = assetName;
    return this;
  }

  public MongoAsset withFileSize(long fileSize) {
    this.fileSize = fileSize;
    return this;
  }

  public MongoAsset withAssetUrl(String assetUrl) {
    this.assetUrl = assetUrl;
    return this;
  }

  public MongoAsset withAssetTags(String[] assetTags) {
    this.assetTags = assetTags;
    return this;
  }

  public boolean validateAsset(){
    return StringUtils.isNotEmpty(assetName) && StringUtils.isNotEmpty(assetUrl);
  }

  public AttachAsset getAsset(){
    return new AttachAsset()
        .withAssetKey(getAssetName())
        .withAssetUrl(getAssetUrl())
        .withAssetTags(getAssetTags())
        .withFileSize(getFileSize());
  }

}
