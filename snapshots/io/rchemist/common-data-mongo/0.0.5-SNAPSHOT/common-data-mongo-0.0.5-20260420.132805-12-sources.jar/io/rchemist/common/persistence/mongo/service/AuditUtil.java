/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.mongo.service;

import io.rchemist.common.persistence.domain.data.AuditDTO;
import io.rchemist.common.persistence.mongo.template.AuditCreated;
import io.rchemist.common.persistence.mongo.template.EssentialEntity;
import io.rchemist.common.persistence.mongo.template.EssentialUUIDEntity;

public class AuditUtil {

  public static AuditDTO<?> create(EssentialEntity<?> entity){

    return AuditDTO.builder()
      .createdAt(entity.getCreatedAt())
      .updatedAt(entity.getUpdatedAt())
      .createdBy(entity.getCreatedBy())
      .updatedBy(entity.getUpdatedBy())
      .createUserType(entity.getCreatedByUserType())
      .updateUserType(entity.getUpdatedByUserType())
      .build();

  }

  public static AuditDTO<?> create(EssentialUUIDEntity<?> entity){

    return AuditDTO.builder()
      .createdAt(entity.getCreatedAt())
      .updatedAt(entity.getUpdatedAt())
      .createdBy(entity.getCreatedBy())
      .updatedBy(entity.getUpdatedBy())
      .createUserType(entity.getCreatedByUserType())
      .updateUserType(entity.getUpdatedByUserType())
      .build();

  }

  public static AuditDTO<?> createOnly(AuditCreated<?> entity){

    return AuditDTO.builder()
      .createdAt(entity.getCreatedAt())
      .createdBy(entity.getCreatedBy())
      .createUserType(entity.getCreatedByUserType())
      .build();

  }

}