/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import com.google.common.base.MoreObjects;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.Column;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.Indexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(NameValue.class)
@Getter
@Setter
public class NameValueImpl implements EnhancedTemplate {

  @AdminField(name = "NameValueImpl_Name", fieldType = PresentationFieldType.STRING, order = 100, headerField = @HeaderField(order = 100), required = true)
  @Indexed
  @Description(name = "NAME", comment = "추가 속성 Key")
  protected String name;

  @Indexed
  @Description(name = "VALUE", comment = "추가 속성 Value, 입력한 필드값(String)")
  @AdminField(name = "NameValueImpl_Value", fieldType = PresentationFieldType.TEXT, order = 200, headerField = @HeaderField(order = 200), required = true)
  @Getter(AccessLevel.NONE)
  protected String value;

  @Column(name = "ATTR_TXT_VALUE")
  @Text
  @Description(name = "VALUE(TEXT)", comment = "입력한 값이 255자 이내의 짧은 값이면 ATTR_VALUE를, 255자 이상의 큰 값이면 ATTR_TXT_VALUE를 사용해 값을 저장한다")
  @Getter(AccessLevel.NONE)
  @Indexed
  protected String txtValue;

  @Column(name = "IS_CUSTOM_FIELD")
  @Description(name = "커스텀 필드 여부", comment = "커스텀 필드로 사용됐는지 여부. 커스텀 필드로 사용된 속성 정보인 경우, 관리자도구의 속성값에 노출되지 않는다. 커스텀 필드에 대해서는 CustomField 참고")
  protected Boolean customField;

  public String getValue(){
    return StringUtil.toString(txtValue, value);
  }

  public void setValue(String value){
    if(StringUtils.length(value) > 255){
      this.value = StringUtils.left(value, 100);    // 단순 검색을 위해 앞글자 100 자까지.
      this.txtValue = value;
    }else{
      this.value = value;
      this.txtValue = null;
    }
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("name", getName())
        .add("value", getValue())
        .add("customField", getCustomField())
        .toString();
  }

}
