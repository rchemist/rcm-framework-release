/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EditorJsUtil;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.index.TextIndexed;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(ContentOnly.class)
@Getter
@Setter
public class ContentOnlyImpl implements Serializable, EnhancedTemplate {

  @AdminField(name = "ContentsImpl_Contents", order = 1000, fieldType = PresentationFieldType.HTML, required = true)
  @Description(name = "내용", comment = "본문 내용")
  protected String content;

  @TextIndexed
  @Description(name = "검색용 내용", comment = "검색 엔진에 적재되는 본문 내용")
  protected String searchableContent;

  public void setContent(String content) {
    this.content = content;
    setSearchableContent(content);
  }

  public void setSearchableContent(String content) {
    if(StringUtils.isNotEmpty(content)){
      this.searchableContent = EditorJsUtil.getSearchableContents(content);
    } else {
      this.searchableContent = content;
    }
  }

}
