/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.mongo.embedded;

import io.rchemist.common.money.Money;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.type.AdjustmentType;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Adjustment implements Serializable {

  @Description(name = "조정 유형", comment = "금액 또는 비율을 할인 또는 할증에 대한 정보")
  protected String adjustmentType;

  @Description(name = "조정 금액", comment = "조정 금액")
  protected BigDecimal adjustmentValue;

  @Description(name = "추가 할인 여부", comment = "이미 할인된 상품에 대해 추가 할인 할 것인지 여부. 이 값이 false 이면, 원 상품에 SalePrice가 설정된 경우 Adjustment를 적용하지 않는다.")
  protected Boolean applyToSalePrice;

  @Description(name = "원가에서 할인할지 여부", comment = "이 값이 true 이면 상품의 SalePrice가 아닌 RetailPrice 에서 가격을 할인하고, 상품의 SalePrice보다 더 낮은 가격일 때만 Adjustment 의 할인을 반영한다.")
  protected Boolean fromRetailPrice;

  public AdjustmentType getAdjustmentType(){
    return EnumTypeUtil.getEnumType(AdjustmentType.class, adjustmentType);
  }

  public void setAdjustmentType(AdjustmentType adjustmentType){
    this.adjustmentType = EnumTypeUtil.getType(adjustmentType);
  }

  /**
   * 가격 할인이 설정되었는지
   * @return
   */
  public boolean isAdjusted(){
    return adjustmentType != null || adjustmentValue != null;
  }

  public Money getAdjustedAmount(Money retailPrice, Money salePrice){

    if(salePrice == null || fromRetailPrice) salePrice = retailPrice;

    if(!isAdjusted()){
      return salePrice;
    }

    if(!applyToSalePrice){
      return salePrice;
    }else{

      int adjustedValue = adjustmentValue.intValue();
      AdjustmentType adjustmentType = getAdjustmentType();


      if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.ADD_PERCENT) || EnumTypeUtil.equals(adjustmentType, AdjustmentType.OFF_PERCENT)){
        adjustedValue = salePrice.getAmount().intValue() * adjustmentValue.intValue() / 100;
      }

      if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.ADD_AMOUNT)){

        salePrice = salePrice.add(new Money(adjustmentValue));

      }else if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.ADD_PERCENT)){

        salePrice = salePrice.add(new Money(adjustedValue));

      }else if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.OFF_AMOUNT)){
        salePrice = salePrice.subtract(new Money(adjustmentValue));

      }else if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.OFF_PERCENT)){

        salePrice = salePrice.subtract(new Money(adjustedValue));

      }else if(EnumTypeUtil.equals(adjustmentType, AdjustmentType.FIXED_PRICE)){
        return new Money(adjustmentValue, retailPrice.getCurrency());
      }

    }

    return salePrice;
  }

}
