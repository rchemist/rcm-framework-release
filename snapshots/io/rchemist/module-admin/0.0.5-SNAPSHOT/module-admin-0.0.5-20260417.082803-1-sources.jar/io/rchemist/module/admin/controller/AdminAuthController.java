/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.controller;

import io.rchemist.common.documentation.RestDocument;
import io.rchemist.common.documentation.RestEndpoint;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.module.admin.authentication.data.AdminLoginRequest;
import io.rchemist.module.admin.authentication.data.AuthenticationResult;
import io.rchemist.module.admin.authentication.service.AdminAuthService;
import io.rchemist.module.jwt.data.Token;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RestController("rcmAdminAuthController")
@RestDocument(project = "Rcm Admin Module", value="관리자 인증")
public class AdminAuthController {

  private final AdminAuthService adminAuthService;

  public AdminAuthController(AdminAuthService adminAuthService) {
    this.adminAuthService = adminAuthService;
  }

  @RequestMapping("/auth/admin-login")
  @RestEndpoint(stage = "로그인", value="로그인", description = "Social login")
  public ResponseData<AuthenticationResult> login(@RequestBody AdminLoginRequest request) {
    return ResponseHelper.result(() -> adminAuthService.login(request));
  }

  @RequestMapping("/auth/admin-refresh")
  @RestEndpoint(stage = "로그인", value="토큰 재발행", description = "AccessToken 이 만료되었을 때 RefreshToken 을 이용해 재발행한다.")
  public ResponseData<AuthenticationResult> refreshToken(@RequestBody Token token) {
    return ResponseHelper.result(() -> adminAuthService.refreshToken(token.getRefreshToken()));
  }

}
