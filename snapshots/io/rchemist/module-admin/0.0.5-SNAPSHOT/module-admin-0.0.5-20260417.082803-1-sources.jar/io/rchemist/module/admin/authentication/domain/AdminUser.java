/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.jpa.domain.annotation.Unique;
import io.rchemist.common.persistence.jpa.domain.comparator.HistoricalComparator;
import io.rchemist.common.persistence.jpa.domain.template.EmailAddress;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.Hidden;
import io.rchemist.common.persistence.jpa.domain.template.ImageAssetMapping;
import io.rchemist.common.persistence.jpa.domain.template.Name;
import io.rchemist.common.persistence.jpa.domain.template.PhoneNumber;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.security.service.PasswordHelper;
import io.rchemist.common.security.service.exception.UserServiceException;
import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.type.RegexType.Regex;
import io.rchemist.module.admin.authentication.configuration.AdminUserSetting;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AdminUserUpdateForm;
import io.rchemist.module.admin.authentication.data.AdminUserView;
import io.rchemist.module.admin.authentication.service.AdminUserServiceHelper;
import io.rchemist.module.admin.authentication.service.exception.AdminUserErrorType;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;
import io.rchemist.module.admin.config.AdminCacheRegion;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.SortComparator;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexingDependency;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.ObjectPath;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyValue;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_ADMIN_USER")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AdminCacheRegion.AdminUser.ENTITY)
@Getter
@Setter
@Description(name = "관리자", comment = "관리자 회원 정보")
public class AdminUser implements EssentialEntity<AdminUser>, Name<AdminUser>
    , ImageAssetMapping<AdminUser>, Hidden<AdminUser>
    , EmailAddress<AdminUser>, PhoneNumber<AdminUser>, SoftDelete<AdminUser> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "LOGIN_NAME")
  @Unique(columnList = "LOGIN_NAME")
  @GenericField
  @AdminField(name = "AdminUser_LoginName",
      headerField = @HeaderField(order = 100),
      placeHolder = "AdminUser_LoginName_Placeholder", fieldType = PresentationFieldType.STRING, modifiableType = ModifiableType.ADD_ONLY, order = 100, createForm = @CreateForm(type = CreateFormType.REQUIRED), required = true, regexValidation= Regex.ADMIN_LOGIN_NAME)
  @Description(name = "로그인 ID", comment = "로그인 ID")
  protected String loginName;

  @Column(name = "MFA_SECRET")
  @AdminField(name = "AdminUser_MfaSecret", order = 600
      , fieldType = PresentationFieldType.COMPONENT, helpText = "AdminUser_MfaSecret_HelpText"
      , modifiableType = ModifiableType.MODIFY_ONLY)
  @Description(name = "MFA 인증", comment = "관리자에 로그인 2차 인증 수단을 초기화 할 때 사용")
  protected String mfaSecret;

  /**
   * 비밀번호 변경 이력을 저장한다.
   */
  @OneToMany(targetEntity = AdminUserPassword.class, mappedBy = "adminUser", cascade = CascadeType.ALL, orphanRemoval = true)
  @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AdminCacheRegion.AdminUser.ENTITY)
  @BatchSize(size = 20)
  @SortComparator(HistoricalComparator.class)
  @Description(name = "비밀번호 이력", comment = "비밀번호 변경 이력")
  protected List<AdminUserPassword> passwords = new ArrayList<>();

  @Transient
  private AdminUserPassword adminUserPassword;

  protected AdminUserPassword getAdminUserPassword(){
    if(adminUserPassword == null){
      adminUserPassword = AdminUserServiceHelper.getRecentPassword(this);
    }
    return adminUserPassword;
  }

  /**
   * 저장된 비밀번호 중 가장 최근의 비밀번호 - 로그인 할 때 이 정보를 가지고 확인한다.
   * @return
   */
  @GenericField(name = "password")
  @IndexingDependency(derivedFrom = @ObjectPath(@PropertyValue(propertyName = "passwords")))
  public String getRecentPassword(){
    AdminUserPassword password = getAdminUserPassword();
    return (password == null) ? null : password.getPassword();
  }

  @GenericField(name = "lastPasswordModifiedAt")
  @IndexingDependency(derivedFrom = @ObjectPath(@PropertyValue(propertyName = "passwords")))
  public Instant getLastPasswordModifiedAt(){
    AdminUserPassword password = getAdminUserPassword();
    return password == null ? null : password.getCreatedAt();
  }

  /**
   * 비밀번호 변경
   * @param clearPassword
   * @throws UserServiceException
   */
  public void modifyUserPassword(String clearPassword) throws AdminUserException {

    if(!AdminUserSetting.validPassword(clearPassword))
      throw new AdminUserException(AdminUserErrorType.INVALID_PASSWORD);

    validateDuplicatedPassword(clearPassword);

    String encodedPassword = PasswordHelper.encode(clearPassword);

    AdminUserPassword password = new AdminUserPassword();
    password.setAdminUser(this);
    password.setPassword(encodedPassword);
    this.passwords.add(password);

  }

  private void validateDuplicatedPassword(String clearPassword) throws AdminUserException {
    if(CollectionUtils.isNotEmpty(passwords)){

      removePreviousUnsavedPasswords();

      int i = 0;
      for(AdminUserPassword password : passwords){
        // 가장 최근 저장된 비밀번호거나, 최근 6개월 이내의 비밀번호를 다시 사용할 수 없다.
        if((i++ == 0 || InstantUtil.hasElapsedDays(password.getCreatedAt(), 180))){
          // 6개월 이내라면 비밀번호가 같은지 확인한다.

          if(PasswordHelper.equalPassword(clearPassword, password.getPassword())){
            throw new AdminUserException("password", AdminUserErrorType.DUPLICATE_PASSWORD_IS_NOT_PERMITTED);
          }

        }else{
          break;
        }
      }
    }
  }

  public AdminUser withLoginName(String loginName) {
    this.loginName = loginName;
    return this;
  }

  public AdminUser withMfaSecret(String mfaSecret) {
    this.mfaSecret = mfaSecret;
    return this;
  }

  private void removePreviousUnsavedPasswords() {
    passwords.removeIf(adminUserPassword1 -> adminUserPassword1.getId() == null);
  }

  public void removeProfile() {
    this.setAsset(new AttachAsset());
  }

  public AdminUserView view() {

    return new AdminUserView()
        .withLoginName(getLoginName())
        .withActive(getActive())
        .withAsset(getAsset())
        .withId(getId())
        .withAudit(getAudit())
        .withName(getName())
        .withEmailAddress(getEmailAddress())
        .withHidden(isHidden())
        .withPhoneNumber(getPhoneNumber());
  }

  public static AdminUser create(AdminUserCreateForm form) throws AdminUserException {

    form.validate();

    validateCreate(form);

    AdminUser user = new AdminUser()
        .withActive(form.getActive())
        .withHidden(form.getHidden())
        .withLoginName(form.getLoginName())
        .withAsset(form.getProfile())
        .withName(form.getName())
        .withEmailAddress(form.getEmailAddress())
        .withPhoneNumber(form.getPhoneNumber())
        .withMfaSecret(form.getMfaSecret());

    if(AdminUserSetting.validPassword(form.getPassword())){
      AdminUserPassword password = new AdminUserPassword();
      password.setPassword(PasswordHelper.encode(form.getPassword()));
      password.setAdminUser(user);
      user.getPasswords().add(password);
    }

    return user;
  }

  protected static void validateCreate(AdminUserCreateForm form) throws AdminUserException {

    if(form.getLoginName() == null || !form.getLoginName().matches(AdminUserSetting.getLoginNameRegexPattern())){
      // throw new UserAuthenticationException(UserAuthenticationErrorType.INVALID_LOGIN_NAME);
      throw new AdminUserException("loginName", AdminUserErrorType.INVALID_LOGIN_NAME);
    }

    if (AdminUserServiceHelper.isDuplicatedLoginName(form.getLoginName())) {
      throw new AdminUserException("loginName", AdminUserErrorType.DUPLICATED_LOGIN_NAME);
    }

    if(AdminUserSetting.getRequiredEmailAddress()) {
      if ((form.getEmailAddress() == null || !form.getEmailAddress().matches(Regex.EMAIL))){
        throw new AdminUserException(AdminUserErrorType.INVALID_EMAILADDRESS);
      }
    }

    if (form.getEmailAddress() != null) {
      if (AdminUserServiceHelper.findUserByEmailAddress(form.getEmailAddress()) != null) {
        throw new AdminUserException(AdminUserErrorType.DUPLICATED_EMAILADDRESS);
      }
    } else {
      // 이메일 주소가 없으면 로그인 아이디를 이메일 주소로 사용한다.
      form.setEmailAddress(form.getLoginName());
    }

    // 비밀번호는 계정 생성 후 비밀번호 찾기를 통해 생성하게 해도 된다.
    if(StringUtils.isNotEmpty(form.getPassword()) && !form.getPassword().matches(AdminUserSetting.getPasswordRegexPattern())){
      throw new AdminUserException("password", AdminUserErrorType.INVALID_PASSWORD);
    }

  }

  public AdminUser update(AdminUserUpdateForm form) throws AdminUserException {
    form.validate();

    validateUpdate(form);

    if (ArrayUtils.isNotEmpty(form.getExplicitUpdatedFields())) {
      for (String field : form.getExplicitUpdatedFields()) {
        switch (field) {
          case "name" -> {
            setName(form.getName());
          }
          case "active" -> {
            setActive(form.getActive());
          }
          case "hidden" -> {
            setHidden(form.getHidden());
          }
          case "profile" -> {
            setAsset(form.getProfile());
          }
          case "emailAddress" -> {
            setEmailAddress(form.getEmailAddress());
          }
          case "phoneNumber" -> {
            setPhoneNumber(form.getPhoneNumber());
          }
          case "mfaSecret" -> {
            setMfaSecret(form.getMfaSecret());
          }
        }
      }
    } else {
      setHidden(form.getHidden());
      setAsset(form.getProfile());
      setName(form.getName());
      setEmailAddress(form.getEmailAddress());
      setPhoneNumber(form.getPhoneNumber());
      setMfaSecret(form.getMfaSecret());
    }

    if (StringUtils.isNotEmpty(form.getPassword())) {
      // 비밀번호 변경
      modifyUserPassword(form.getPassword());
    }
    return this;

  }

  protected void validateUpdate(AdminUserUpdateForm form) throws AdminUserException {

    if(StringUtils.isNotBlank(form.getEmailAddress())){
      if(!form.getEmailAddress().matches(Regex.EMAIL)){
        throw new AdminUserException("emailAddress", AdminUserErrorType.INVALID_EMAILADDRESS);
      }
      // check duplicated email address
      AdminUser other = AdminUserServiceHelper.findUserByEmailAddress(form.getEmailAddress());
      if (!other.getId().equals(form.getId())) {
        throw new AdminUserException("emailAddress", AdminUserErrorType.DUPLICATED_EMAILADDRESS);
      }
    }

    if(StringUtils.isNotBlank(form.getPassword())){
      if (!AdminUserSetting.validPassword(form.getPassword())) {
        throw new AdminUserException("password", AdminUserErrorType.INVALID_PASSWORD);
      }
    }

    if(StringUtils.isNotBlank(form.getPhoneNumber())){
      if(!form.getPhoneNumber().matches(Regex.NUMBER)){
        throw new AdminUserException("phoneNumber", AdminUserErrorType.INVALID_PHONENUMBER);
      }
    }

  }

  public boolean isPasswordMatches(String password) {
    return PasswordHelper.equalPassword(password, getRecentPassword());
  }


}
