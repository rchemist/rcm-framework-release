/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AdminUserUpdateForm;
import io.rchemist.module.admin.authentication.data.AdminUserView;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import io.rchemist.module.admin.authentication.domain.AdminUserPassword;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AdminUserService extends ResponseEntityListService<AdminUser, AdminUserView, AdminUserCreateForm, AdminUserUpdateForm, SearchForm, Long, AdminUserException> {
  AdminUser findAdminUserByNameAndPhoneNumber(String name, String phoneNumber);

  boolean removeAll(Iterable<? extends AdminUser> adminUsers);

  AdminUserPassword getRecentPassword(AdminUser adminUser);

  AdminUser findUserByLoginName(String loginName);

  AdminUser findUserByEmailAddress(String emailAddress);

}
