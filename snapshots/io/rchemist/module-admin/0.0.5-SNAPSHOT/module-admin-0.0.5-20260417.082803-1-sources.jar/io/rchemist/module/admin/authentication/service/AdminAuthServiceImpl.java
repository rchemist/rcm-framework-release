/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.jpa.transaction.TransactionHelper;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.module.admin.authentication.configuration.AdminUserSetting;
import io.rchemist.module.admin.authentication.data.AdminLoginRequest;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AuthenticationResult;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import io.rchemist.module.admin.authentication.service.exception.AuthServiceErrorType;
import io.rchemist.module.admin.authentication.service.exception.AuthServiceException;
import io.rchemist.module.admin.authentication.service.extension.AdminAuthServiceExtensionManager;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.data.Token;
import io.rchemist.module.jwt.data.TokenRequest;
import io.rchemist.module.jwt.service.CachedTokenProvider;
import io.rchemist.module.jwt.service.exception.TokenErrorType;
import io.rchemist.module.jwt.service.exception.TokenException;
import io.rchemist.module.jwt.service.type.TokenType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
public class AdminAuthServiceImpl implements AdminAuthService {

  private final AdminUserService adminUserService;

  private final CachedTokenProvider tokenProvider;

  private final AdminAuthServiceExtensionManager extensionManager;

  public AdminAuthServiceImpl(AdminUserService adminUserService, CachedTokenProvider tokenProvider,
      AdminAuthServiceExtensionManager extensionManager) {
    this.adminUserService = adminUserService;
    this.tokenProvider = tokenProvider;
    this.extensionManager = extensionManager;
  }


  @Override
  public AuthenticationResult login(AdminLoginRequest request) throws AuthServiceException {
    request.validate();
    AdminUser adminUser = adminUserService.findUserByLoginName(request.getLoginName());

    if (adminUser == null || !adminUser.isPasswordMatches(request.getPassword()))
      throw new AuthServiceException(AuthServiceErrorType.USER_NOT_FOUND);

    if (!adminUser.isActive() || adminUser.isHidden()) {
      // 일시적으로 사용 중지된 경우
      throw new AuthServiceException(AuthServiceErrorType.USER_NOT_FOUND);
    }


    return getAuthenticationResult(adminUser, request.getRememberMe());
  }

  private AuthenticationResult getAuthenticationResult(AdminUser adminUser, Boolean rememberMe) {

    TokenRequest request = new TokenRequest("admin", adminUser.getId()).withRememberMe(rememberMe);

    ExtensionResultHolder<TokenRequest> resultHolder = new ExtensionResultHolder<TokenRequest>().withResult(request);

    ExtensionResultStatusType status = extensionManager.getProxy().generateTokenRequest(resultHolder);

    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED)) {
      request = resultHolder.getResult();
    }

    Token token = tokenProvider.createToken(request);

    return new AuthenticationResult()
        .withName(adminUser.getName())
        .withId(adminUser.getId())
        .withActive(true)   // 향후 결제 정보와 연동해야 한다.
        .withRememberMe(rememberMe)
        .withToken(token);
  }

  @Override
  public AuthenticationResult refreshToken(String refreshToken) throws AuthServiceException {
    try {
      CachedToken token = tokenProvider.parse(TokenType.REFRESH_TOKEN, refreshToken);

      Long adminUserId = NumberUtil.getLong(token.getUserId());

      if (adminUserId == null)
        throw new AuthServiceException(AuthServiceErrorType.USER_NOT_FOUND);

      AdminUser adminUser = adminUserService.findEntityById(adminUserId);
      return getAuthenticationResult(adminUser, token.isRememberMe());

    } catch (Exception e) {

      if (e instanceof TokenException) {
        if (((TokenException) e).getErrorType().equals(TokenErrorType.EXPIRED_TOKEN)) {
          throw new AuthServiceException(AuthServiceErrorType.EXPIRED_TOKEN);
        }
      }

      throw new AuthServiceException(AuthServiceErrorType.USER_NOT_FOUND);
    }
  }

  @Override
  public AuthenticationResult register(AdminUserCreateForm form) throws AuthServiceException {

    // #1. loginName duplicate 확인
    AdminUser adminUser = adminUserService.findUserByLoginName(form.getLoginName());
    if(adminUser != null)
      throw new AuthServiceException(AuthServiceErrorType.DUPLICATED_LOGIN_NAME);

    // #2. email address duplicate 확인
    adminUser = adminUserService.findUserByEmailAddress(form.getEmailAddress());
    if(adminUser != null)
      throw new AuthServiceException(AuthServiceErrorType.DUPLICATED_EMAIL);

    // #3. password valid 확인
    // 신규 생성에서 비밀번호는 optional 한 정보이다. 먼저 계정을 생성하고 비밀번호 찾기로 새로 생성하는 프로세스에 대응하기 위함이다.
    if(StringUtils.isNotEmpty(form.getPassword()) && !AdminUserSetting.validPassword(form.getPassword()))
      throw new AuthServiceException(AuthServiceErrorType.INVALID_PASSWORD);

    TransactionStatus status = TransactionHelper.createTransaction("CREATE_ADMIN_USER",
        TransactionDefinition.PROPAGATION_REQUIRED);
    try{
      // #4. 기본 정보 셋팅, User 엔티티 생성 후 리턴
      adminUser = AdminUser.create(form);
      adminUser = adminUserService.save(adminUser);

      TransactionHelper.finalizeTransaction(status, false);
    }catch (Exception e){
      TransactionHelper.finalizeTransaction(status, true);
      throw new AuthServiceException(new ErrorDTO(e));
    }

    return getAuthenticationResult(adminUser, false);
  }
}
