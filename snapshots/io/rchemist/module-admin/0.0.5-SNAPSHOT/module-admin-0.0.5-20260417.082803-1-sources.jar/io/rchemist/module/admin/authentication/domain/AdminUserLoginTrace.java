/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.util.ClientIpUtil;
import io.rchemist.common.util.RequestUtil;
import io.rchemist.module.admin.config.AdminCacheRegion;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_ADMIN_USER_LOGIN_TRACE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AdminCacheRegion.AdminUser.ENTITY)
@Getter
@Setter
@Description(name = "관리자 로그인 이력", comment = "관리자도구에 로그인 시도에 따른 결과를 저장한다.")
public class AdminUserLoginTrace implements EssentialEntity<AdminUserLoginTrace> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "USER_ID")
  @IndexField
  @Description(name = "User ID", comment = "시스템에서 사용하는 유저의 유니크 키")
  protected String userId;

  @Column(name = "IP_ADDRESS")
  @Description(name = "IP 주소", comment = "로그인 시도한 IP 주소")
  protected String ipAddress;

  @Column(name = "IS_SUCCESS")
  @Description(name = "성공 여부", comment = "로그인 성공 여부")
  protected Boolean success;

  @Column(name = "FAILED_COUNT")
  @Description(name = "로그인 실패 횟수", comment = "로그인에 실패한 카운트 수. 해당 카운트는 로그인 성공시 다시 0 으로 초기화 된다.")
  protected Integer failedCount = 0;

  public boolean isSuccess(){
    return BooleanUtils.toBoolean(success);
  }

  public AdminUserLoginTrace withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public AdminUserLoginTrace withIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
    return this;
  }

  public AdminUserLoginTrace withSuccess(Boolean success) {
    this.success = success;
    return this;
  }

  public AdminUserLoginTrace withFailedCount(Integer failedCount) {
    this.failedCount = failedCount;
    return this;
  }

  public static AdminUserLoginTrace success(String customerId){
    return create(customerId, true, 0);
  }

  public static AdminUserLoginTrace create(String userId, boolean success, int failedCount){
    return new AdminUserLoginTrace()
        .withUserId(userId)
        .withSuccess(success)
        .withFailedCount(failedCount)
        .withIpAddress(ClientIpUtil.getClientIp(RequestUtil.getHttpServletRequest()));
  }

  public AdminUserLoginTrace fail(){
    return create(getUserId(), false, BooleanUtils.toBoolean(success) ? 0 : getFailedCount() + 1);
  }


}
