/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.AvailableDatetime;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.util.InstantUtil;
import io.rchemist.module.admin.config.AdminCacheRegion;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serial;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_ADMIN_USER_PASSWORD")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AdminCacheRegion.AdminUser.ENTITY)
@Getter
@Setter
@Description(name = "관리자 비밀번호", comment = "관리자 비밀번호. 비밀번호 이외에 사용가능한 기간 설정 등 추가적인 정보를 관리한다. 또한 관리자 비밀번호를 이력으로 관리하고 비밀번호에 재사용에 대한 허용 여부 등을 체크할 수 있다.")
public class AdminUserPassword implements EssentialEntity<AdminUserPassword>, AvailableDatetime<AdminUserPassword> {

  @Serial
  private static final long serialVersionUID = 1992178794635338326L;

  @Id
  @IdGenerator
  protected Long id;

  @ManyToOne(targetEntity = AdminUser.class, optional = false, cascade = CascadeType.REFRESH)
  @JoinColumn(name = "USER_ID")
  @IndexField
  @Description(name = "관리자 ID", comment = "비밀번호에 매핑된 관리자 정보")
  protected AdminUser adminUser;

  @Column(name = "PASSWORD")
  @Description(name = "비밀번호", comment = "비밀번호")
  protected String password;

  public boolean isChangeRequired(long days){
    Instant availableUntil = getAvailableUntil();
    if(availableUntil == null){
      availableUntil = InstantUtil.plusDays(getCreatedAt(), days);
    }
    return availableUntil.isAfter(Instant.now());

  }

}
