/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.configuration;

import io.rchemist.common.util.type.RegexType.Message;
import io.rchemist.common.util.type.RegexType.Regex;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "platform.config.admin.profile")
public class AdminUserSetting {

  public static final String ROLE_ADMIN = "ROLE_ADMIN";
  public static final String ROLE_USER = "ROLE_USER";

  private static String PASSWORD_REGEX_PATTERN;
  private static String PASSWORD_ERROR_MESSAGE;
  private static String LOGIN_NAME_REGEX_PATTERN;
  private static String LOGIN_NAME_ERROR_MESSAGE;
  private static Boolean REQUIRED_EMAIL_ADDRESS;

  private static String loginName;

  private static String loginEmail;

  private static String emailAddress;

  private static String phoneNumber;

  private static String countryCode;

  private static String password;

  private static boolean shouldInitialize;

  private static boolean useProfile;

  @Value("${platform.config.admin.user.initialize:true}")
  public void setShouldInitialize(boolean shouldInitialize) {
    AdminUserSetting.shouldInitialize = shouldInitialize;
  }

  @Value("${platform.config.admin.profile.email:official@rchemist.io}")
  public void setEmailAddress(String emailAddress) {
    AdminUserSetting.emailAddress = emailAddress;
  }

  @Value("${platform.config.admin.profile.phone:}")
  public void setPhoneNumber(String phoneNumber) {
    AdminUserSetting.phoneNumber = phoneNumber;
  }

  @Value("${platform.config.admin.profile.country:82}")
  public void setCountryCode(String countryCode) {
    AdminUserSetting.countryCode = countryCode;
  }

  @Value("${platform.config.admin.profile.password:}")
  public void setPassword(String password) {
    AdminUserSetting.password = password;
  }

  @Value("${platform.config.admin.profile.loginName:admin}")
  public void setLoginName(String loginName) {
    AdminUserSetting.loginName = loginName;
  }

  @Value("${platform.config.admin.profile.loginEmail:admin@rchemist.io}")
  public void setLoginEmail(String loginEmail) {
    AdminUserSetting.loginEmail = loginEmail;
  }

  @Value("${platform.config.admin.validate.regex.password:}")
  public void setDefaultPasswordRegexPattern(String pattern){
    AdminUserSetting.PASSWORD_REGEX_PATTERN = (StringUtils.isNotEmpty(pattern) ? pattern : Regex.PASSWORD);
  }

  @Value("${platform.config.admin.validate.message.password:}")
  public void setDefaultPasswordErrorMessage(String message){
    AdminUserSetting.PASSWORD_ERROR_MESSAGE = (StringUtils.isNotEmpty(message) ? message : Message.PASSWORD);
  }

  @Value("${platform.config.admin.validate.regex.loginName:}")
  public void setDefaultLoginNameRegexPattern(String pattern){
    AdminUserSetting.LOGIN_NAME_REGEX_PATTERN = (StringUtils.isNotEmpty(pattern) ? pattern : Regex.LOGIN_NAME);
  }

  @Value("${platform.config.admin.validate.message.loginName:}")
  public void setDefaultLoginNameErrorMessage(String message){
    AdminUserSetting.LOGIN_NAME_ERROR_MESSAGE = (StringUtils.isNotEmpty(message) ?message : Message.LOGIN_NAME);
  }

  @Value("${platform.config.admin.validate.required.emailAddress:}")
  public void setRequiredEmailAddress(Boolean requiredEmailAddress){
    AdminUserSetting.REQUIRED_EMAIL_ADDRESS = (BooleanUtils.toBooleanDefaultIfNull(requiredEmailAddress, true));
  }

  @Value("${platform.config.admin.profile.manage:true}")
  public void setUseProfile(Boolean useProfile){
    AdminUserSetting.useProfile = BooleanUtils.toBoolean(useProfile);
  }

  public static String getDefaultLoginName(){
    return isUsingDefaultLoginNameRegexPattern() ?
        loginName : loginEmail;
  }

  public static String getPasswordRegexPattern(){
    return (StringUtils.isNotEmpty(PASSWORD_REGEX_PATTERN) ? PASSWORD_REGEX_PATTERN : Regex.PASSWORD);
  }

  public static String getLoginNameRegexPattern(){
    return (StringUtils.isNotEmpty(LOGIN_NAME_REGEX_PATTERN) ? LOGIN_NAME_REGEX_PATTERN : Regex.LOGIN_NAME);
  }

  public static boolean isUsingDefaultPasswordRegexPattern(){
    return getPasswordRegexPattern().equals(Regex.PASSWORD);
  }

  public static boolean isUsingDefaultLoginNameRegexPattern(){
    return getLoginNameRegexPattern().equals(Regex.LOGIN_NAME);
  }

  public static String getLoginNameErrorMessage() {
    return StringUtils.isNotEmpty(LOGIN_NAME_ERROR_MESSAGE) ? LOGIN_NAME_ERROR_MESSAGE : Message.LOGIN_NAME;
  }

  public static String getPasswordErrorMessage() {
    return StringUtils.isNotEmpty(PASSWORD_ERROR_MESSAGE) ? PASSWORD_ERROR_MESSAGE : Message.PASSWORD;
  }

  public static Boolean getRequiredEmailAddress(){
    return BooleanUtils.toBooleanDefaultIfNull(REQUIRED_EMAIL_ADDRESS, true);
  }

  public static String getLoginName() {
    return loginName;
  }

  public static String getLoginEmail() {
    return loginEmail;
  }

  public static String getEmailAddress() {
    return emailAddress;
  }

  public static String getPhoneNumber() {
    return phoneNumber;
  }

  public static String getCountryCode() {
    return countryCode;
  }

  public static String getPassword() {
    return password;
  }

  public static boolean isShouldInitialize() {
    return shouldInitialize;
  }

  /**
   * password 가 적절한지 regex match
   * @param clearPassword
   * @return
   */
  public static boolean validPassword(String clearPassword) {
    return !StringUtils.isEmpty(clearPassword) && ((clearPassword.matches(getPasswordRegexPattern())) ? true : false);
  }


  /**
   * AdminUser 도 profile 을 사용할 것인지 여부
   * @return
   */
  public static boolean isUseProfile() {
    return useProfile;
  }

}
