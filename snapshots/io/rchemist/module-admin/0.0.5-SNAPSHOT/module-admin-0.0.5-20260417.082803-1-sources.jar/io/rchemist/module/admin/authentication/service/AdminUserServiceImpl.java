/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.module.admin.authentication.dao.AdminUserDao;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AdminUserUpdateForm;
import io.rchemist.module.admin.authentication.data.AdminUserView;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import io.rchemist.module.admin.authentication.domain.AdminUserPassword;
import io.rchemist.module.admin.authentication.service.exception.AdminUserErrorType;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
public class AdminUserServiceImpl implements AdminUserService {

  private final AdminUserDao dao;

  public AdminUserServiceImpl(AdminUserDao dao) {
    this.dao = dao;
  }

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  @Override
  public AdminUser findAdminUserByNameAndPhoneNumber(String name, String phoneNumber) {
    return dao.getAdminUserRepository().findAdminUserByNameAndPhoneNumber(name, phoneNumber);
  }

  @Override
  @Transactional
  public boolean removeAll(Iterable<? extends AdminUser> adminUsers) {
    try {
      dao.getAdminUserRepository().deleteAll(adminUsers);
      return true;
    }catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

  @Override
  public AdminUserPassword getRecentPassword(AdminUser adminUser) {
    return dao.getAdminUserPasswordRepository().findTopByAdminUserEqualsOrderByIdDesc(adminUser);
  }

  @Override
  public AdminUser findUserByLoginName(String loginName) {
    return dao.getAdminUserRepository().findAdminUserByLoginName(loginName);
  }

  @Override
  public AdminUser findUserByEmailAddress(String emailAddress) {
    return dao.getAdminUserRepository().findAdminUserByEmailAddress(emailAddress);
  }

  @Override
  public CommonSearchRepository<AdminUser, Long> getRepository() {
    return dao.getAdminUserRepository();
  }

  @Override
  public AdminUserException entityNotFoundException() {
    return new AdminUserException(AdminUserErrorType.NOT_FOUND);
  }

  @Override
  public AdminUser createEntity(AdminUserCreateForm adminUserCreateForm) throws AdminUserException {
    return AdminUser.create(adminUserCreateForm);
  }

  @Override
  public AdminUserView getView(AdminUser entity, EntityViewType entityViewType) {
    return entity.view();
  }

  @Override
  public SearchContext<AdminUser, SearchForm> getSearchContext(
      SearchForm searchForm) {
    return new CommonSearchContext<>(AdminUser.class, searchForm);
  }


  @Override
  public AdminUser updateEntity(AdminUser adminUser, AdminUserUpdateForm form) throws AdminUserException{
    return adminUser.update(form);
  }

  @Override
  public DeleteForm<Long> preDeleteAllBySearchForm(DeleteForm<Long> idList) throws AdminUserException {

    if (idList == null || idList.isEmpty()) {
      throw new AdminUserException(AdminUserErrorType.NOT_FOUND);
    }

    List<Long> remainIds = dao.getAdminUserRepository().getAdminUserIdExceptIds(idList.getIds());

    if (CollectionUtils.isEmpty(remainIds)) {
      throw new AdminUserException(AdminUserErrorType.DELETE_ALL_IS_NOT_ACCEPT);
    }

    return idList;

  }
}
