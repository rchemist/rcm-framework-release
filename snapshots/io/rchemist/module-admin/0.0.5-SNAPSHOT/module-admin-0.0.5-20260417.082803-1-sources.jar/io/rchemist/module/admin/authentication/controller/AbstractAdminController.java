/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.controller;

import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityController;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AdminUserUpdateForm;
import io.rchemist.module.admin.authentication.data.AdminUserView;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import io.rchemist.module.admin.authentication.service.AdminUserService;
import lombok.Getter;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractAdminController extends ResponseEntityController<AdminUser, AdminUserView, AdminUserCreateForm, AdminUserUpdateForm, SearchForm, Long> {

  @Getter
  protected final AdminUserService service;

  protected AbstractAdminController(AdminUserService service) {
    this.service = service;
  }

  @Override
  @PostMapping
  public ResponseListData<AdminUserView, SearchForm> search(@RequestBody SearchForm searchForm) {
    return super.search(searchForm);
  }

  @Override
  @PostMapping("/add")
  public ResponseData<AdminUserView> create(@RequestBody AdminUserCreateForm adminUserCreateForm) {
    return super.create(adminUserCreateForm);
  }

  @PutMapping("/{id}")
  public ResponseData<AdminUserView> update(@PathVariable Long id, @RequestBody AdminUserUpdateForm adminUserUpdateForm) {
    adminUserUpdateForm.setId(id);
    return super.update(adminUserUpdateForm);
  }

  @Override
  @DeleteMapping("/{id}")
  public ResponseData<Boolean> delete(@PathVariable Long id, @RequestParam(required = false) String revisionEntityName) {
    return super.delete(id, revisionEntityName);
  }

  @Override
  @GetMapping("/{id}")
  public ResponseData<AdminUserView> view(@PathVariable Long id) {
    return super.view(id);
  }

  @Override
  @DeleteMapping("/delete")
  public ResponseData<Integer> deleteMultiple(@RequestBody DeleteForm<Long> form) {
    return super.deleteMultiple(form);
  }
}
