/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import java.util.List;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AdminUserRepository extends CommonSearchRepository<AdminUser, Long> {

  @Query(value = "select adminUser from AdminUser adminUser where lower(adminUser.loginName) = lower(:loginName)")
  AdminUser findAdminUserByLoginName(String loginName);

  @Query(value = "select adminUser from AdminUser adminUser where lower(adminUser.emailAddress) = lower(:emailAddress)")
  AdminUser findAdminUserByEmailAddress(String emailAddress);

  @Query("select user from AdminUser user where user.name = :name "
      + " and user.phoneNumber = :phoneNumber")
  AdminUser findAdminUserByNameAndPhoneNumber(String name, String phoneNumber);

  @Query("select user.id from AdminUser user where user.id not in :ids")
  List<Long> getAdminUserIdExceptIds(List<Long> ids);
}
