/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.module.admin.authentication.data.AdminLoginRequest;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import io.rchemist.module.admin.authentication.data.AuthenticationResult;
import io.rchemist.module.admin.authentication.service.exception.AuthServiceException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AdminAuthService {

  /**
   * 관리자 로그인
   * @param request
   * @return
   * @throws AuthServiceException
   */
  AuthenticationResult login(AdminLoginRequest request) throws AuthServiceException;

  /**
   * 관리자 토큰 refresh
   * @param refreshToken
   * @return
   * @throws AuthServiceException
   */
  AuthenticationResult refreshToken(String refreshToken) throws AuthServiceException;

  /**
   * 관리자 신규 등록
   * @param form
   * @return
   * @throws AuthServiceException
   */
  AuthenticationResult register(AdminUserCreateForm form) throws AuthServiceException;


}
