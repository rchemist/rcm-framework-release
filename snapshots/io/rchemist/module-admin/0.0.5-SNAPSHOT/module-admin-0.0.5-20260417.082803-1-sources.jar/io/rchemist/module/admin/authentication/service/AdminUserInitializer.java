/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.common.util.RandomUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.type.RandomCharEnumType;
import io.rchemist.module.admin.authentication.configuration.AdminUserSetting;
import io.rchemist.module.admin.authentication.data.AdminUserCreateForm;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Order(Integer.MIN_VALUE + 200)
@Component
@Slf4j
public class AdminUserInitializer implements ApplicationRunner {

  private static final String DEFAULT_ADMIN_NAME = "Administrator";
  private static final String DEFAULT_ADMIN_EMAIL = "gowidfrsdev@gmail.com";
  private static final String DEFAULT_ADMIN_LOGINNAME = "admin";

  private final AdminUserSetting config;

  private final AdminAuthService adminAuthService;

  public AdminUserInitializer(AdminUserSetting config,
      AdminAuthService adminAuthService) {
    this.config = config;
    this.adminAuthService = adminAuthService;
  }

  @Override
  public void run(ApplicationArguments args) {

    // register super admin if absent
    AdminUserCreateForm form = new AdminUserCreateForm();
    form.setLoginName(getLoginName());
    form.setName(DEFAULT_ADMIN_NAME);
    form.setEmailAddress(getEmailAddress());

    // properties 에 지정된 비밀번호가 없다면 랜덤으로 생성한다.
    String password = (StringUtils.isEmpty(config.getPassword())) ? createTemporaryPassword() : config.getPassword();
    form.setPassword(password);

    try {

      adminAuthService.register(form);

      log.info("Try to Initialize admin user...");
      log.info("Create AdminUser :: " + form.getLoginName() + " password is " + form.getPassword());
    } catch (Exception e) {
      // nothing to do
      // e.printStackTrace();
    }
  }

  private String getEmailAddress() {
    return StringUtil.toString(AdminUserSetting.getEmailAddress(), DEFAULT_ADMIN_EMAIL);

  }

  private String getLoginName(){
    return getLoginName(null);
  }

  private String getLoginName(String prefix){
    String loginName = StringUtil.toString(AdminUserSetting.getDefaultLoginName(), DEFAULT_ADMIN_LOGINNAME);

    if(StringUtils.isNotEmpty(prefix)){
      loginName = prefix + loginName;
    }

    return loginName;
  }

  private String createTemporaryPassword(){

    String password;

    int loop = 0;
    while(loop++ < 10){
      password = RandomUtil.generateRandomString(RandomCharEnumType.CHARACTER_SPECIAL, 10, false);

      if(AdminUserSetting.validPassword(password)){
        return password;
      }

    }

    return config.getPassword();
  }



}
