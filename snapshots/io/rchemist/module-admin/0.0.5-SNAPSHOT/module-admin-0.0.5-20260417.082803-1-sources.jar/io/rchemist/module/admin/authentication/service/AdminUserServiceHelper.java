/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.admin.authentication.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.module.admin.authentication.data.AdminUserView;
import io.rchemist.module.admin.authentication.domain.AdminUser;
import io.rchemist.module.admin.authentication.domain.AdminUserPassword;
import io.rchemist.module.admin.authentication.service.exception.AdminUserErrorType;
import io.rchemist.module.admin.authentication.service.exception.AdminUserException;
import io.rchemist.module.jwt.service.CachedTokenHelper;
import java.time.LocalDateTime;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AdminUserServiceHelper {

  private static AdminUserService adminUserService;

  private static AdminUserLoginTraceService adminUserLoginTraceService;

  private static AdminUserService getAdminUserService(){
    if(adminUserService == null){
      adminUserService = ApplicationContextHolder.getBean(AdminUserService.class);
    }
    return adminUserService;
  }

  private static AdminUserLoginTraceService getAdminUserLoginTraceService(){
    if(adminUserLoginTraceService == null){
      adminUserLoginTraceService = ApplicationContextHolder.getBean(AdminUserLoginTraceService.class);
    }
    return adminUserLoginTraceService;
  }

  public static boolean isDuplicatedLoginName(String loginName){
    return getAdminUserService().findUserByLoginName(loginName) != null;
  }

  public static AdminUser findUserByEmailAddress(String emailAddress){
    return getAdminUserService().findUserByEmailAddress(emailAddress);
  }

  public static AdminUser findUserById(Long id) {
    try {
      return getAdminUserService().findEntityById(id);
    } catch (AdminUserException e) {
      return null;
    }
  }

  public static AdminUser findUserByLoginName(String loginName) {
    return getAdminUserService().findUserByLoginName(loginName);
  }
  
  public static AdminUser findAdminUserByNameAndPhoneNumber(String name, String phoneNumber){
    return getAdminUserService().findAdminUserByNameAndPhoneNumber(name, phoneNumber);
  }

  public static AdminUserPassword getRecentPassword(AdminUser adminUser) {
    return getAdminUserService().getRecentPassword(adminUser);
  }

  public static LocalDateTime getLastLoggedIn(Long adminUserId) {
    return getAdminUserLoginTraceService().getLastLoggedInDate(adminUserId);
  }

  public static void setMfaSecret(Long adminUserId, String mfaSecret)
      throws AdminUserException {
    AdminUser adminUser = getAdminUserService().findEntityById(adminUserId);
    setMfaSecret(adminUser, mfaSecret);
  }

  public static void setMfaSecret(AdminUser adminUser, String mfaSecret) {
    adminUser.setMfaSecret(mfaSecret);
    getAdminUserService().save(adminUser);
  }

  public static AdminUserView getCurrentLoginAdminUser() {
    Long userId = CachedTokenHelper.getUserIdAsLong();
    if (userId != null) {
      try {
        return getAdminUserService().findViewById(userId);
      } catch (AdminUserException e) {
        // nothing to do
      }
    }

    return null;
  }

  public static void checkAdminUserLoggedIn() throws AdminUserException {
    AdminUserView adminUserView = getCurrentLoginAdminUser();
    if (adminUserView == null) {
      throw new AdminUserException(AdminUserErrorType.NOT_FOUND);
    }
  }

}
