/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 음력 일자 immutable Records — {@link LunarCalendar} 변환 결과.
 *
 * @param year 음력 연도 (1900~2100 baseline)
 * @param month 음력 월 (1~12)
 * @param day 음력 일 (1~30)
 * @param leapMonth 윤달 여부 (true 면 본 month 가 윤달 — 예: 윤 4 월).
 */
public record LunarDate(int year, int month, int day, boolean leapMonth) {

  public LunarDate {
    if (month < 1 || month > 12) {
      throw new IllegalArgumentException("month must be 1~12: " + month);
    }
    if (day < 1 || day > 30) {
      throw new IllegalArgumentException("day must be 1~30: " + day);
    }
  }
}
