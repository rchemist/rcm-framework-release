/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 지번주소 Records — {@code 서울특별시 강남구 역삼동 826 아무빌딩 5 층}.
 *
 * @param sido 시 / 도 (예: {@code 서울특별시})
 * @param sigungu 시 / 군 / 구 (예: {@code 강남구})
 * @param dong 읍 / 면 / 동 / 리 (예: {@code 역삼동})
 * @param jibun 지번 (예: {@code 826} 또는 {@code 826-3}).
 * @param detail 상세주소 (예: {@code 아무빌딩 5 층}). 비어있을 수 있음.
 */
public record JibunAddress(
    String sido, String sigungu, String dong, String jibun, String detail) implements Address {

  public JibunAddress {
    Objects.requireNonNull(sido, "sido");
    Objects.requireNonNull(sigungu, "sigungu");
    Objects.requireNonNull(dong, "dong");
    Objects.requireNonNull(jibun, "jibun");
    detail = detail == null ? "" : detail;
  }

  @Override
  public String formatted() {
    String main = String.join(" ", sido, sigungu, dong, jibun);
    return detail.isEmpty() ? main : main + " " + detail;
  }
}
