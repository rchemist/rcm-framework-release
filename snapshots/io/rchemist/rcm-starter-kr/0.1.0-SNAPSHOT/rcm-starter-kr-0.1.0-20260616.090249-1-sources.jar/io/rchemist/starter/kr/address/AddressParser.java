/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 주소 텍스트 → {@link Address} 분류 / 분리 facade.
 *
 * <p>도로명 / 지번 자동 인식:
 * <ul>
 *   <li>도로명 — 4 번째 토큰이 {@code 로} 또는 {@code 길} 로 끝나면 도로명으로 분류.</li>
 *   <li>지번 — 4 번째 토큰이 {@code 동} / {@code 리} / {@code 읍} / {@code 면} 으로 끝나면 지번으로 분류.</li>
 * </ul>
 *
 * <p>분리 실패 = {@link Optional#empty()}. 5 번째 토큰부터는 detail 로 합산.
 */
public final class AddressParser {

  private static final Pattern ROAD_TOKEN = Pattern.compile(".+(로|길)$");
  private static final Pattern DONG_TOKEN = Pattern.compile(".+(동|리|읍|면)$");

  private AddressParser() {}

  public static Optional<Address> parse(String value) {
    if (value == null || value.isBlank()) {
      return Optional.empty();
    }
    String[] tokens = value.trim().split("\\s+", 6);
    if (tokens.length < 4) {
      return Optional.empty();
    }
    String sido = tokens[0];
    String sigungu = tokens[1];
    String midToken = tokens[2];
    String numberToken = tokens[3];
    String detail = tokens.length >= 5 ? joinTail(tokens, 4) : "";

    Matcher roadMatcher = ROAD_TOKEN.matcher(midToken);
    if (roadMatcher.matches()) {
      return Optional.of(new RoadNameAddress(sido, sigungu, midToken, numberToken, detail));
    }
    Matcher dongMatcher = DONG_TOKEN.matcher(midToken);
    if (dongMatcher.matches()) {
      return Optional.of(new JibunAddress(sido, sigungu, midToken, numberToken, detail));
    }
    return Optional.empty();
  }

  private static String joinTail(String[] tokens, int from) {
    StringBuilder sb = new StringBuilder();
    for (int i = from; i < tokens.length; i++) {
      if (sb.length() > 0) {
        sb.append(' ');
      }
      sb.append(tokens[i]);
    }
    return sb.toString();
  }
}
