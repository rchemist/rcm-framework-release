/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@code platform.kr.*} prefix 의 baseline yml binding — {@link KoreanRegionAutoConfiguration}
 * 의 단일 진입점.
 *
 * <p>{@code enabled} = autoconfig 자체 opt-out flag (default true).
 * 6 영역 (id / phone / address / calendar / text / tax) 의 세부 설정은 task #3~#8 진입 시
 * nested record 로 보강.
 **/
@ConfigurationProperties(prefix = "platform.kr")
public record KoreanRegionProperties(@DefaultValue("true") boolean enabled) {}
