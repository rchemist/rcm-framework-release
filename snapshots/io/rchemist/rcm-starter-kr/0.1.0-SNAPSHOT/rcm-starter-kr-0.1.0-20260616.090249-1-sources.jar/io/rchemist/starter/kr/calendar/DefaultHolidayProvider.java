/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

import java.time.LocalDate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link HolidayProvider} default 구현 — {@link KoreanHoliday} 위임.
 */
public final class DefaultHolidayProvider implements HolidayProvider {

  @Override
  public boolean isHoliday(LocalDate date) {
    return KoreanHoliday.isHoliday(date);
  }
}
