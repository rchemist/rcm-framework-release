/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.MonthDay;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 공휴일 검증 — 양력 고정 + 음력 변동 (hard-coded 2024~2030) + 단순 대체공휴일 룰.
 *
 * <p>본 utility 의 dataset 영역:
 * <ul>
 *   <li>양력 고정 8 종 (신정 / 삼일절 / 어린이날 / 현충일 / 광복절 / 개천절 / 한글날 / 크리스마스)</li>
 *   <li>음력 변동 (2024~2030 hard-coded 양력 일자 — 설날 3 일 / 추석 3 일 / 부처님오신날 1 일)</li>
 *   <li>단순 대체공휴일 — 어린이날 / 설날 / 추석 / 한글날 등이 일요일과 겹치면 다음 월요일</li>
 * </ul>
 *
 * <p>Consumer 가 더 긴 영역 또는 더 정확한 dataset 필요 시 — {@link HolidayProvider} SPI 로
 * override (KoreanRegionAutoConfiguration 의 CalendarBeans 본문에 ConditionalOnMissingBean
 * 골격). framework default 는 본 utility 위임.
 */
public final class KoreanHoliday {

  private static final Set<MonthDay> FIXED_HOLIDAYS =
      Set.of(
          MonthDay.of(1, 1), // 신정
          MonthDay.of(3, 1), // 삼일절
          MonthDay.of(5, 5), // 어린이날
          MonthDay.of(6, 6), // 현충일
          MonthDay.of(8, 15), // 광복절
          MonthDay.of(10, 3), // 개천절
          MonthDay.of(10, 9), // 한글날
          MonthDay.of(12, 25)); // 크리스마스

  private static final Map<Integer, Set<LocalDate>> LUNAR_HOLIDAYS = buildLunarHolidays();

  private KoreanHoliday() {}

  public static boolean isHoliday(LocalDate date) {
    if (date == null) {
      return false;
    }
    if (FIXED_HOLIDAYS.contains(MonthDay.from(date))) {
      return true;
    }
    Set<LocalDate> lunar = LUNAR_HOLIDAYS.get(date.getYear());
    if (lunar != null && lunar.contains(date)) {
      return true;
    }
    return isSubstituteHoliday(date);
  }

  /** 단순 대체공휴일 — 어린이날 / 설날 / 추석 / 한글날 등이 일요일에 겹치면 다음 월요일 휴무. */
  private static boolean isSubstituteHoliday(LocalDate date) {
    if (date.getDayOfWeek() != DayOfWeek.MONDAY) {
      return false;
    }
    LocalDate previousSunday = date.minusDays(1);
    if (FIXED_HOLIDAYS.contains(MonthDay.from(previousSunday))) {
      return isSubstituteEligible(MonthDay.from(previousSunday));
    }
    Set<LocalDate> lunar = LUNAR_HOLIDAYS.get(previousSunday.getYear());
    if (lunar != null && lunar.contains(previousSunday)) {
      return true;
    }
    return false;
  }

  private static boolean isSubstituteEligible(MonthDay md) {
    return md.equals(MonthDay.of(5, 5))
        || md.equals(MonthDay.of(3, 1))
        || md.equals(MonthDay.of(8, 15))
        || md.equals(MonthDay.of(10, 3))
        || md.equals(MonthDay.of(10, 9));
  }

  private static Map<Integer, Set<LocalDate>> buildLunarHolidays() {
    return Map.of(
        2024, lunar(2024, "02-09", "02-10", "02-11", "02-12", "05-15", "09-16", "09-17", "09-18"),
        2025, lunar(2025, "01-28", "01-29", "01-30", "05-05", "10-05", "10-06", "10-07"),
        2026, lunar(2026, "02-16", "02-17", "02-18", "05-24", "09-24", "09-25", "09-26"),
        2027, lunar(2027, "02-05", "02-06", "02-07", "05-13", "09-14", "09-15", "09-16"),
        2028, lunar(2028, "01-25", "01-26", "01-27", "05-02", "10-02", "10-03", "10-04"),
        2029, lunar(2029, "02-12", "02-13", "02-14", "05-20", "09-21", "09-22", "09-23"),
        2030, lunar(2030, "02-02", "02-03", "02-04", "05-09", "09-11", "09-12", "09-13"));
  }

  private static Set<LocalDate> lunar(int year, String... isoMonthDayPairs) {
    java.util.Set<LocalDate> set = new java.util.HashSet<>();
    for (String md : isoMonthDayPairs) {
      set.add(LocalDate.parse(year + "-" + md));
    }
    return java.util.Set.copyOf(set);
  }
}
