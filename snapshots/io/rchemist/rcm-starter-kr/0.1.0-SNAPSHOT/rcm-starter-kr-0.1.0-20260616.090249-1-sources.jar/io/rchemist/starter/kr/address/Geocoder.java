/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Geocoding SPI — Consumer 가 카카오 / 네이버 / 공공데이터 API 어댑터를 {@code @Component} 로 wire.
 *
 * <p>framework default = {@link NoopGeocoder} (모든 호출 = {@link UnsupportedOperationException}).
 * Geocoding 이 활성 영역인 Consumer 만 자체 어댑터 구현.
 */
public interface Geocoder {

  Geocoded geocode(Address address);

  Address reverseGeocode(double latitude, double longitude);
}
