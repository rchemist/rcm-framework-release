/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Geocoding 결과 — 위경도 좌표.
 *
 * @param latitude 위도 (남북, 한국 영역 ~33~38).
 * @param longitude 경도 (동서, 한국 영역 ~125~131).
 */
public record Geocoded(double latitude, double longitude) {}
