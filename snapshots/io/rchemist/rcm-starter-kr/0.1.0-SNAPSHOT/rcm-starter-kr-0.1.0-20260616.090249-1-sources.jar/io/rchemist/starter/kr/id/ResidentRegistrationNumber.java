/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.id;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 주민등록번호 검증 어노테이션 — 13 자리 + 표준 체크섬 알고리즘.
 *
 * <p>입력은 하이픈 / 공백 자동 제거. null / 빈 문자열 = pass-through (별도 {@code @NotBlank} 영역).
 * 알고리즘 본문은 {@link RegistrationNumbers#isValidResidentRegistrationNumber(String)} 참조.
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ResidentRegistrationNumber.Validator.class)
public @interface ResidentRegistrationNumber {

  String message() default "{rcm.kr.id.resident.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  class Validator implements ConstraintValidator<ResidentRegistrationNumber, CharSequence> {
    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
      if (value == null || value.length() == 0) {
        return true;
      }
      return RegistrationNumbers.isValidResidentRegistrationNumber(value.toString());
    }
  }
}
