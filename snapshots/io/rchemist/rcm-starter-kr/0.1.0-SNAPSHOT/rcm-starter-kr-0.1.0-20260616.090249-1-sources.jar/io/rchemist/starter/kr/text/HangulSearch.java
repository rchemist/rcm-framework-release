/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.text;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한글 초성 검색 helper — 검색 인덱싱용 normalize + match 매트릭스.
 *
 * <p>패턴:
 * <ul>
 *   <li>{@link #toChosungIndex(String)} — 인덱싱 시점에 모든 한글 음절을 초성으로 치환해 저장.</li>
 *   <li>{@link #matches(String, String)} — 검색 query 의 초성 / 음절 혼용 매칭.</li>
 * </ul>
 */
public final class HangulSearch {

  private HangulSearch() {}

  /** 음절 → 초성 치환. {@link Hangul#extractChosung(String)} alias (인덱싱 의도 명시). */
  public static String toChosungIndex(String text) {
    return Hangul.extractChosung(text);
  }

  /**
   * 검색 query 가 target 의 prefix / contains 로 매칭되면 true. query 가 초성만이면 target 의
   * 초성 치환 결과와 비교, 음절이면 target 그대로 비교.
   */
  public static boolean matches(String target, String query) {
    if (target == null || query == null || query.isEmpty()) {
      return false;
    }
    if (isAllChosung(query)) {
      return Hangul.extractChosung(target).contains(query);
    }
    return target.contains(query);
  }

  private static boolean isAllChosung(String query) {
    for (char c : query.toCharArray()) {
      if (!isChosung(c)) {
        return false;
      }
    }
    return true;
  }

  private static boolean isChosung(char c) {
    for (char initial : Hangul.INITIALS) {
      if (initial == c) {
        return true;
      }
    }
    return false;
  }
}
