/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.id;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 차량번호 검증 어노테이션 — 신/구 형식 정규식 매트릭스.
 *
 * <p>지원 형식 — {@code 12가1234} 신형 (2 자리 분류 + 한글 + 4 자리), {@code 123가1234}
 * 신형 (3 자리), {@code 서울12가1234} 구형 (지역명 prefix). 입력 공백 trim 자동.
 * null / 빈 문자열 = pass-through.
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = VehicleRegistrationNumber.Validator.class)
public @interface VehicleRegistrationNumber {

  String message() default "{rcm.kr.id.vehicle.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  class Validator implements ConstraintValidator<VehicleRegistrationNumber, CharSequence> {
    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
      if (value == null || value.length() == 0) {
        return true;
      }
      return RegistrationNumbers.isValidVehicleRegistrationNumber(value.toString());
    }
  }
}
