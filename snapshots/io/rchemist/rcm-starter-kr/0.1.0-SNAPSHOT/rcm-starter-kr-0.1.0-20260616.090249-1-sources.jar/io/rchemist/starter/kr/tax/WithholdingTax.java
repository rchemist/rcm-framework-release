/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.money.Money;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 원천징수 — 사업소득 (3.3%) + 기타소득 (8.8%, 필요경비 60% 적용 후) baseline.
 *
 * <p>근로소득은 *간이세액표* 기반이라 baseline 미흡수 — Phase 0.1.x 후속 task 영역. Consumer
 * 가 자체 간이세액표 dataset 합류 시 별도 utility 구현.
 *
 * <p>예시:
 * <pre>{@code
 * WithholdingBreakdown b = WithholdingTax.businessIncome(Money.of(1_000_000, "KRW"));
 * b.tax();   // 33,000 KRW (3.3%)
 * b.net();   // 967,000 KRW
 * }</pre>
 *
 * <p><strong>참고용</strong> — 실제 신고는 국세청 / 세무사 확인 필수.
 */
public final class WithholdingTax {

  private WithholdingTax() {}

  /** 사업소득 원천징수 — 지급액의 3.3% 공제. */
  public static WithholdingBreakdown businessIncome(Money gross) {
    Money tax = gross.multiply(TaxRates.WITHHOLDING_BUSINESS_INCOME);
    return new WithholdingBreakdown(gross, tax, gross.minus(tax));
  }

  /**
   * 기타소득 원천징수 — 필요경비 60% 차감 후 8.8% 공제. {@code gross} 는 전체 지급액.
   * 예: 100 만원 지급 → 필요경비 60 만원 → 과세대상 40 만원 → 세액 35,200 원.
   */
  public static WithholdingBreakdown otherIncome(Money gross) {
    Money taxable = gross.discount(TaxRates.WITHHOLDING_OTHER_NECESSARY_EXPENSE);
    Money tax = taxable.multiply(TaxRates.WITHHOLDING_OTHER_INCOME);
    return new WithholdingBreakdown(gross, tax, gross.minus(tax));
  }
}
