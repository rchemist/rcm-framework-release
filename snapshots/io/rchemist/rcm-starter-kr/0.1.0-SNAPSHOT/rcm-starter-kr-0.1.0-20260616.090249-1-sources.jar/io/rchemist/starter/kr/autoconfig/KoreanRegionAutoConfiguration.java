/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.autoconfig;

import io.rchemist.starter.kr.address.Geocoder;
import io.rchemist.starter.kr.address.NoopGeocoder;
import io.rchemist.starter.kr.calendar.BusinessDayCalculator;
import io.rchemist.starter.kr.calendar.DefaultHolidayProvider;
import io.rchemist.starter.kr.calendar.HolidayProvider;
import io.rchemist.starter.kr.tax.DefaultTaxRateProvider;
import io.rchemist.starter.kr.tax.TaxRateProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 6.5 task #2 — {@code rcm-starter-kr} 진입점 (Decision #10 옵션 starter).
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>Decision #20 — prefix 없음. starter / 패키지 가 region 영역 자체 명시 (ISO 3166
 *       alpha-2 {@code kr}). class 이름 = 도메인 의미 풀네임.</li>
 *   <li>{@code platform.kr.enabled=false} 로 opt-out (default true).</li>
 *   <li>6 inner static config marker — task #3~#8 진입 시 본문 채움
 *       (id / phone / address / calendar / text / tax).</li>
 * </ul>
 *
 * <p>Phase 5/6 의 {@code SecurityAutoConfiguration} / {@code ExternalAutoConfiguration} 패턴 정합.
 **/
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.kr", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(KoreanRegionProperties.class)
public class KoreanRegionAutoConfiguration {

  /** Phase 6.5 task #3 — 한국 ID 검증 (RRN/BRN/CRN/FRN/Vehicle). */
  @Configuration(proxyBeanMethods = false)
  static class IdBeans {}

  /** Phase 6.5 task #4 — PhoneNumber + @PhoneNumber. */
  @Configuration(proxyBeanMethods = false)
  static class PhoneBeans {}

  /** Phase 6.5 task #5 — Address + Geocoder SPI. */
  @Configuration(proxyBeanMethods = false)
  static class AddressBeans {

    /**
     * {@link Geocoder} default = {@link NoopGeocoder} fail-loud. Consumer 가 카카오 / 네이버 /
     * 공공데이터 어댑터를 {@code @Component} 로 wire 하면 자동 양보.
     */
    @Bean
    @ConditionalOnMissingBean(Geocoder.class)
    Geocoder defaultGeocoder() {
      return new NoopGeocoder();
    }
  }

  /** Phase 6.5 task #6 — LunarCalendar + KoreanHoliday + BusinessDayCalculator. */
  @Configuration(proxyBeanMethods = false)
  static class CalendarBeans {

    @Bean
    @ConditionalOnMissingBean(HolidayProvider.class)
    HolidayProvider defaultHolidayProvider() {
      return new DefaultHolidayProvider();
    }

    @Bean
    @ConditionalOnMissingBean(BusinessDayCalculator.class)
    BusinessDayCalculator businessDayCalculator(HolidayProvider holidayProvider) {
      return new BusinessDayCalculator(holidayProvider);
    }
  }

  /** Phase 6.5 task #7 — Hangul + Hanja + Transliterator. */
  @Configuration(proxyBeanMethods = false)
  static class TextBeans {}

  /** Phase 6.5 task #8 — Vat + WithholdingTax + SocialInsurance. */
  @Configuration(proxyBeanMethods = false)
  static class TaxBeans {

    @Bean
    @ConditionalOnMissingBean(TaxRateProvider.class)
    TaxRateProvider defaultTaxRateProvider() {
      return new DefaultTaxRateProvider();
    }
  }
}
