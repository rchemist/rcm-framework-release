/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.text;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한글 자모 분리 / 결합 / 초성 추출 — 유니코드 산술 ({@code 가-힣 = 0xAC00~0xD7A3 = 11172 음절}).
 *
 * <p>음절 = 초성 19 × 중성 21 × 종성 28 (종성 0 = 종성 없음). 외부 dataset 의존 0.
 *
 * <p>예시:
 * <pre>{@code
 * Hangul.decompose("한글");                  // [ㅎ, ㅏ, ㄴ, ㄱ, ㅡ, ㄹ]
 * Hangul.compose('ㅎ', 'ㅏ', 'ㄴ');           // '한'
 * Hangul.extractChosung("김홍도");           // "ㄱㅎㄷ"
 * Hangul.isHangul('가');                     // true
 * }</pre>
 */
public final class Hangul {

  private static final int BASE = 0xAC00;
  private static final int LAST = 0xD7A3;
  private static final int MEDIAL_COUNT = 21;
  private static final int FINAL_COUNT = 28;

  static final char[] INITIALS = {
      'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ',
      'ㅌ', 'ㅍ', 'ㅎ'
  };

  static final char[] MEDIALS = {
      'ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ',
      'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ'
  };

  static final char[] FINALS = {
      0, 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ',
      'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
  };

  private Hangul() {}

  public static boolean isHangul(char c) {
    return c >= BASE && c <= LAST;
  }

  /** 음절 1 자 → [초성, 중성, (종성)] 리스트. 종성이 없으면 2 개. 한글 음절 아니면 빈 리스트. */
  public static List<Character> decompose(char syllable) {
    if (!isHangul(syllable)) {
      return List.of();
    }
    int idx = syllable - BASE;
    int initial = idx / (MEDIAL_COUNT * FINAL_COUNT);
    int medial = (idx % (MEDIAL_COUNT * FINAL_COUNT)) / FINAL_COUNT;
    int finalConsonant = idx % FINAL_COUNT;
    List<Character> result = new ArrayList<>(3);
    result.add(INITIALS[initial]);
    result.add(MEDIALS[medial]);
    if (finalConsonant > 0) {
      result.add(FINALS[finalConsonant]);
    }
    return result;
  }

  /** 문자열 전체 자모 분리 — 한글 외 문자는 그대로 통과. */
  public static List<Character> decompose(String text) {
    if (text == null || text.isEmpty()) {
      return List.of();
    }
    List<Character> result = new ArrayList<>();
    for (char c : text.toCharArray()) {
      if (isHangul(c)) {
        result.addAll(decompose(c));
      } else {
        result.add(c);
      }
    }
    return result;
  }

  /** 자모 결합 — 종성 없을 때 {@code 0} 또는 {@code (char) 0} 전달. */
  public static char compose(char initial, char medial, char finalConsonant) {
    int initialIdx = indexOf(INITIALS, initial);
    int medialIdx = indexOf(MEDIALS, medial);
    int finalIdx = finalConsonant == 0 ? 0 : indexOf(FINALS, finalConsonant);
    if (initialIdx < 0 || medialIdx < 0 || finalIdx < 0) {
      throw new IllegalArgumentException(
          "Invalid jamo: " + initial + " " + medial + " " + finalConsonant);
    }
    return (char) (BASE + (initialIdx * MEDIAL_COUNT + medialIdx) * FINAL_COUNT + finalIdx);
  }

  /** 종성 없는 결합 — {@code compose('ㅎ', 'ㅏ')} = '하'. */
  public static char compose(char initial, char medial) {
    return compose(initial, medial, (char) 0);
  }

  /** 문자열 → 초성 추출 (한글 외는 그대로). 예: {@code "김홍도"} → {@code "ㄱㅎㄷ"}. */
  public static String extractChosung(String text) {
    if (text == null || text.isEmpty()) {
      return "";
    }
    StringBuilder sb = new StringBuilder(text.length());
    for (char c : text.toCharArray()) {
      if (isHangul(c)) {
        int initial = (c - BASE) / (MEDIAL_COUNT * FINAL_COUNT);
        sb.append(INITIALS[initial]);
      } else {
        sb.append(c);
      }
    }
    return sb.toString();
  }

  private static int indexOf(char[] array, char target) {
    for (int i = 0; i < array.length; i++) {
      if (array[i] == target) {
        return i;
      }
    }
    return -1;
  }
}
