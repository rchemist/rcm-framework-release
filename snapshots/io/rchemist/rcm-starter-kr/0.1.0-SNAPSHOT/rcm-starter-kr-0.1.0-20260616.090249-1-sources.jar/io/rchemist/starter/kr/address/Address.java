/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 주소 sealed interface — 도로명 / 지번 두 형식 공통.
 *
 * <p>구현체는 모두 immutable Records. {@link AddressParser#parse(String)} 가 입력 텍스트를
 * 자동 분류해 적절한 구현체를 반환.
 */
public sealed interface Address permits RoadNameAddress, JibunAddress {

  String sido();

  String sigungu();

  String detail();

  /** 표준 표기 — 시도 / 시군구 / 본문 / 상세를 공백으로 결합. */
  String formatted();
}
