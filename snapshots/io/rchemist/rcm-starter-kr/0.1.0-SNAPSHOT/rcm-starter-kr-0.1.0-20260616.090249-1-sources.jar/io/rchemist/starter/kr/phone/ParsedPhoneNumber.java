/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.phone;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 전화번호 파싱 결과 — type / areaCode / 분리된 subscriber 영역.
 *
 * <p>{@link PhoneNumberFormatter#parse(String)} 결과로 반환된다. immutable Records — format
 * 메소드는 area code + subscriber 결합 표시를 제공.
 *
 * @param type 전화번호 종류
 * @param areaCode 지역 / carrier code (예: {@code 010}, {@code 02}, {@code 070}, {@code 1588})
 * @param subscriberPrefix subscriber 앞 영역 (예: {@code 1234}). 대표번호는 {@code null}.
 * @param subscriberSuffix subscriber 뒤 영역 (예: {@code 5678}).
 */
public record ParsedPhoneNumber(
    PhoneNumberType type, String areaCode, String subscriberPrefix, String subscriberSuffix) {

  public ParsedPhoneNumber {
    Objects.requireNonNull(type, "type");
    Objects.requireNonNull(areaCode, "areaCode");
    Objects.requireNonNull(subscriberSuffix, "subscriberSuffix");
  }

  /** 표준 한국 표기 — 하이픈 구분 ({@code 010-1234-5678} / {@code 02-1234-5678} / {@code 1588-1234}). */
  public String formatted() {
    if (subscriberPrefix == null) {
      return areaCode + "-" + subscriberSuffix;
    }
    return areaCode + "-" + subscriberPrefix + "-" + subscriberSuffix;
  }

  /** 하이픈 / 공백 제거 raw 표시. */
  public String compact() {
    if (subscriberPrefix == null) {
      return areaCode + subscriberSuffix;
    }
    return areaCode + subscriberPrefix + subscriberSuffix;
  }

  /**
   * 국제 표기 — {@code +82} prefix + leading zero 제거. {@link PhoneNumberType#REPRESENTATIVE}
   * 는 국제 전화 의미 없음 → {@link UnsupportedOperationException} fail-loud.
   */
  public String e164() {
    if (type == PhoneNumberType.REPRESENTATIVE) {
      throw new UnsupportedOperationException(
          "Representative numbers (1588 등) cannot be expressed in E.164 — domestic-only.");
    }
    String stripped = areaCode.startsWith("0") ? areaCode.substring(1) : areaCode;
    if (subscriberPrefix == null) {
      return "+82" + stripped + subscriberSuffix;
    }
    return "+82" + stripped + subscriberPrefix + subscriberSuffix;
  }
}
