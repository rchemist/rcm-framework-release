/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.id;

import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 등록번호 검증 / 포맷 / 마스킹 통합 utility — 5 type (주민/외국인/법인/사업자/차량).
 *
 * <p>모든 메소드는 입력에서 하이픈 / 공백을 자동 제거 (normalize) 후 검증한다. null / 빈 문자열은
 * 모두 false / 빈 결과 반환 (별도 {@code @NotNull} / {@code @NotBlank} 영역).
 *
 * <p>알고리즘 출처 — 정부 표준:
 * <ul>
 *   <li>주민등록번호 / 외국인등록번호 (RRN/FRN, 13 자리) — 가중치 {@code [2,3,4,5,6,7,8,9,2,3,4,5]} mod 11</li>
 *   <li>사업자등록번호 (BRN, 10 자리) — 가중치 {@code [1,3,7,1,3,7,1,3,5]} + 9 번째 자리 보정 mod 10</li>
 *   <li>법인등록번호 (CRN, 13 자리) — 가중치 {@code [1,2,1,2,...,1,2]} mod 10</li>
 * </ul>
 */
public final class RegistrationNumbers {

  private static final int[] RRN_WEIGHTS = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};
  private static final int[] BRN_WEIGHTS = {1, 3, 7, 1, 3, 7, 1, 3, 5};
  private static final int[] CRN_WEIGHTS = {1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2};

  private static final Pattern VEHICLE_PATTERN =
      Pattern.compile("^(?:[가-힣]{2,3}\\s?)?\\d{2,3}[가-힣]\\s?\\d{4}$");

  private RegistrationNumbers() {}

  // ---------- RRN — 주민등록번호 ----------

  public static boolean isValidResidentRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13 || !digits.chars().allMatch(Character::isDigit)) {
      return false;
    }
    return checksum13(digits, RRN_WEIGHTS, 11);
  }

  public static String formatResidentRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13) {
      return value;
    }
    return digits.substring(0, 6) + "-" + digits.substring(6);
  }

  /** 성별/세기 자리 (7 번째) 만 노출, 나머지 6 자리 마스킹: {@code 930101-1******}. */
  public static String maskResidentRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13) {
      return value;
    }
    return digits.substring(0, 6) + "-" + digits.charAt(6) + "******";
  }

  // ---------- FRN — 외국인등록번호 ----------

  public static boolean isValidForeignerRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13 || !digits.chars().allMatch(Character::isDigit)) {
      return false;
    }
    int genderDigit = digits.charAt(6) - '0';
    if (genderDigit < 5 || genderDigit > 8) {
      return false;
    }
    return checksum13(digits, RRN_WEIGHTS, 11);
  }

  public static String formatForeignerRegistrationNumber(String value) {
    return formatResidentRegistrationNumber(value);
  }

  public static String maskForeignerRegistrationNumber(String value) {
    return maskResidentRegistrationNumber(value);
  }

  // ---------- BRN — 사업자등록번호 ----------

  public static boolean isValidBusinessRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 10 || !digits.chars().allMatch(Character::isDigit)) {
      return false;
    }
    int sum = 0;
    for (int i = 0; i < 9; i++) {
      sum += (digits.charAt(i) - '0') * BRN_WEIGHTS[i];
    }
    sum += ((digits.charAt(8) - '0') * 5) / 10;
    int checkDigit = (10 - (sum % 10)) % 10;
    return checkDigit == (digits.charAt(9) - '0');
  }

  public static String formatBusinessRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 10) {
      return value;
    }
    return digits.substring(0, 3) + "-" + digits.substring(3, 5) + "-" + digits.substring(5);
  }

  // ---------- CRN — 법인등록번호 ----------

  public static boolean isValidCorporateRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13 || !digits.chars().allMatch(Character::isDigit)) {
      return false;
    }
    return checksum13(digits, CRN_WEIGHTS, 10);
  }

  public static String formatCorporateRegistrationNumber(String value) {
    String digits = normalize(value);
    if (digits.length() != 13) {
      return value;
    }
    return digits.substring(0, 6) + "-" + digits.substring(6);
  }

  // ---------- Vehicle — 차량번호 ----------

  public static boolean isValidVehicleRegistrationNumber(String value) {
    if (value == null || value.isBlank()) {
      return false;
    }
    return VEHICLE_PATTERN.matcher(value.trim()).matches();
  }

  // ---------- internal ----------

  /** 13 자리 가중치 합산 → modulo 검증 — RRN/CRN 공통 골격. */
  private static boolean checksum13(String digits, int[] weights, int modulo) {
    int sum = 0;
    for (int i = 0; i < weights.length; i++) {
      sum += (digits.charAt(i) - '0') * weights[i];
    }
    int checkDigit = (modulo - (sum % modulo)) % 10;
    return checkDigit == (digits.charAt(12) - '0');
  }

  private static String normalize(String value) {
    if (value == null) {
      return "";
    }
    return value.replaceAll("[\\s-]", "");
  }
}
