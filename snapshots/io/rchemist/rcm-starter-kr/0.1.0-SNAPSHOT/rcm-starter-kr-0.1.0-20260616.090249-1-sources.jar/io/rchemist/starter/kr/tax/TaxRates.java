/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.percentage.Percentage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 표준 세금 / 보험 요율 baseline (2026 년 기준).
 *
 * <p><strong>법적 권위 보장 X</strong> — 참고용. 실제 신고 / 산출은 국세청 / 세무사 / 4 대보험
 * 공단 확인 필수. 요율 변경 시 {@link TaxRateProvider} SPI 로 Consumer override.
 */
public final class TaxRates {

  /** 표준 부가세 — 10%. */
  public static final Percentage VAT_STANDARD = Percentage.of(10);

  /** 영세율 부가세 — 0% (수출 등). */
  public static final Percentage VAT_ZERO = Percentage.zero();

  /** 사업소득 원천징수 — 3.3% (소득세 3% + 지방소득세 0.3%). */
  public static final Percentage WITHHOLDING_BUSINESS_INCOME = Percentage.of(3.3);

  /** 기타소득 원천징수 — 8.8% (소득세 8% + 지방소득세 0.8%, 필요경비 60% 적용 후 기준). */
  public static final Percentage WITHHOLDING_OTHER_INCOME = Percentage.of(8.8);

  /** 기타소득 필요경비 비율 — 60% (강의 / 원고료 / 자문료 등). */
  public static final Percentage WITHHOLDING_OTHER_NECESSARY_EXPENSE = Percentage.of(60);

  /** 국민연금 본인부담 — 4.5% (사업주 4.5% 별도). */
  public static final Percentage NATIONAL_PENSION = Percentage.of(4.5);

  /** 건강보험 본인부담 — 3.545% (2026 baseline). */
  public static final Percentage HEALTH_INSURANCE = Percentage.of(3.545);

  /** 장기요양보험 — 건강보험료의 12.81% 가산. */
  public static final Percentage LONG_TERM_CARE_RATE_OF_HEALTH = Percentage.of(12.81);

  /** 고용보험 본인부담 — 0.9% (2026 baseline). */
  public static final Percentage EMPLOYMENT_INSURANCE = Percentage.of(0.9);

  private TaxRates() {}
}
