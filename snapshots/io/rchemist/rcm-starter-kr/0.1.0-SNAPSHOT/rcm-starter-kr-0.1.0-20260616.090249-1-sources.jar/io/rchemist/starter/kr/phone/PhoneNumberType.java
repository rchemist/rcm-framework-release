/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.phone;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 전화번호 종류 — 정규식 매트릭스 + format 정합.
 *
 * <p>분류 기준:
 * <ul>
 *   <li>{@link #MOBILE} — 휴대폰 (010/011/016/017/018/019). 11 자리.</li>
 *   <li>{@link #SEOUL} — 서울 (02). 9~10 자리.</li>
 *   <li>{@link #LOCAL} — 지역 (031~064). 10~11 자리.</li>
 *   <li>{@link #VOIP} — VoIP (050x). 11~12 자리.</li>
 *   <li>{@link #INTERNET} — 인터넷 (070). 11 자리.</li>
 *   <li>{@link #TOLL_FREE} — 수신자 부담 (080). 9~10 자리.</li>
 *   <li>{@link #REPRESENTATIVE} — 대표번호 (1588/1577/1644/1666/1688/1899). 8 자리.</li>
 * </ul>
 */
public enum PhoneNumberType {
  MOBILE,
  SEOUL,
  LOCAL,
  VOIP,
  INTERNET,
  TOLL_FREE,
  REPRESENTATIVE
}
