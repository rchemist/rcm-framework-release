/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 우편번호 검증 어노테이션 — 5 자리 신 우편번호 default (2015 년 8 월 시행). 구 6 자리 reject.
 *
 * <p>입력 trim 자동, null / 빈 문자열 = pass-through.
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PostalCode.Validator.class)
public @interface PostalCode {

  String message() default "{rcm.kr.address.postal.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  class Validator implements ConstraintValidator<PostalCode, CharSequence> {
    private static final Pattern PATTERN = Pattern.compile("^\\d{5}$");

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
      if (value == null || value.length() == 0) {
        return true;
      }
      return PATTERN.matcher(value.toString().trim()).matches();
    }
  }
}
