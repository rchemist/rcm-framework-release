/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 영업일 계산 — 주말 + 공휴일 ({@link HolidayProvider}) 제외.
 *
 * <p>예시:
 * <pre>{@code
 * BusinessDayCalculator calc = new BusinessDayCalculator(new DefaultHolidayProvider());
 * calc.plusBusinessDays(LocalDate.of(2026, 5, 1), 5);   // 영업일 5 일 후
 * calc.between(LocalDate.of(2026, 5, 1), LocalDate.of(2026, 5, 31));  // 영업일 일수
 * calc.isBusinessDay(LocalDate.of(2026, 5, 5));         // 어린이날 → false
 * }</pre>
 */
public final class BusinessDayCalculator {

  private final HolidayProvider holidayProvider;

  public BusinessDayCalculator(HolidayProvider holidayProvider) {
    this.holidayProvider = Objects.requireNonNull(holidayProvider, "holidayProvider");
  }

  public boolean isBusinessDay(LocalDate date) {
    Objects.requireNonNull(date, "date");
    return !isWeekend(date) && !holidayProvider.isHoliday(date);
  }

  /** 영업일 +N — 0 면 시작일 자체 (영업일 아니면 다음 영업일까지 advance). */
  public LocalDate plusBusinessDays(LocalDate start, int businessDays) {
    Objects.requireNonNull(start, "start");
    if (businessDays < 0) {
      return minusBusinessDays(start, -businessDays);
    }
    LocalDate cursor = start;
    int remaining = businessDays;
    while (remaining > 0) {
      cursor = cursor.plusDays(1);
      if (isBusinessDay(cursor)) {
        remaining--;
      }
    }
    return cursor;
  }

  public LocalDate minusBusinessDays(LocalDate start, int businessDays) {
    Objects.requireNonNull(start, "start");
    if (businessDays < 0) {
      return plusBusinessDays(start, -businessDays);
    }
    LocalDate cursor = start;
    int remaining = businessDays;
    while (remaining > 0) {
      cursor = cursor.minusDays(1);
      if (isBusinessDay(cursor)) {
        remaining--;
      }
    }
    return cursor;
  }

  /** {@code from} ~ {@code to} 사이 영업일 수 (양 끝 포함). {@code from > to} 면 음수 반환. */
  public int between(LocalDate from, LocalDate to) {
    Objects.requireNonNull(from, "from");
    Objects.requireNonNull(to, "to");
    if (from.isAfter(to)) {
      return -between(to, from);
    }
    int count = 0;
    LocalDate cursor = from;
    while (!cursor.isAfter(to)) {
      if (isBusinessDay(cursor)) {
        count++;
      }
      cursor = cursor.plusDays(1);
    }
    return count;
  }

  private static boolean isWeekend(LocalDate date) {
    DayOfWeek dow = date.getDayOfWeek();
    return dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY;
  }
}
