/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

import java.time.LocalDate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 음력 ↔ 양력 변환 facade — 1900~2100 KASI dataset 기반.
 *
 * <p><strong>baseline 상태 (Phase 6.5)</strong>: API 골격만 존재. 실제 변환 dataset
 * (1900~2100 binary packed ~2.4 KB) 합류는 후속 task (Phase 0.1.x) 영역 — 본 task 본문에서
 * 제외. 호출 시 {@link UnsupportedOperationException} fail-loud (silent X). dataset 합류 후
 * 본 facade 본문만 보강 = Consumer 측 변경 0.
 *
 * <p>현 시점 음력 공휴일 사용 = {@link KoreanHoliday} 의 hard-coded list (2024~2030, 양력 일자
 * 직접 명시) — 음력 변환 의존성 없음.
 */
public final class LunarCalendar {

  private LunarCalendar() {}

  public static LunarDate toLunar(LocalDate solar) {
    throw new UnsupportedOperationException(
        "LunarCalendar dataset not yet bundled — Phase 0.1.x 후속 task 영역. KoreanHoliday 는"
            + " 양력 일자 hard-coded list 로 음력 의존 없음.");
  }

  public static LocalDate toSolar(LunarDate lunar) {
    throw new UnsupportedOperationException(
        "LunarCalendar dataset not yet bundled — Phase 0.1.x 후속 task 영역. KoreanHoliday 는"
            + " 양력 일자 hard-coded list 로 음력 의존 없음.");
  }
}
