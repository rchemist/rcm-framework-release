/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.percentage.Percentage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link TaxRateProvider} default 구현 — {@link TaxRates} 2026 baseline 위임.
 */
public final class DefaultTaxRateProvider implements TaxRateProvider {

  @Override
  public Percentage vatStandard() {
    return TaxRates.VAT_STANDARD;
  }

  @Override
  public Percentage withholdingBusinessIncome() {
    return TaxRates.WITHHOLDING_BUSINESS_INCOME;
  }

  @Override
  public Percentage withholdingOtherIncome() {
    return TaxRates.WITHHOLDING_OTHER_INCOME;
  }

  @Override
  public Percentage nationalPension() {
    return TaxRates.NATIONAL_PENSION;
  }

  @Override
  public Percentage healthInsurance() {
    return TaxRates.HEALTH_INSURANCE;
  }

  @Override
  public Percentage longTermCareRateOfHealth() {
    return TaxRates.LONG_TERM_CARE_RATE_OF_HEALTH;
  }

  @Override
  public Percentage employmentInsurance() {
    return TaxRates.EMPLOYMENT_INSURANCE;
  }
}
