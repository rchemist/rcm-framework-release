/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.money.Money;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 4 대보험 본인부담 baseline (2026 년 기준).
 *
 * <p>3 종 baseline (국민연금 / 건강보험 + 장기요양 / 고용보험). 산재보험은 업종별 요율 + 사업주
 * 전액 부담이라 본 utility 영역 X (Consumer 가 별도 dataset 합류).
 *
 * <p>예시:
 * <pre>{@code
 * Money salary = Money.of(3_000_000, "KRW");
 * InsuranceBreakdown b = SocialInsurance.calculate(salary);
 * b.nationalPension();    // 135,000 (4.5%)
 * b.healthInsurance();    // 106,350 (3.545%)
 * b.longTermCare();       // 13,623 (건강보험의 12.81%)
 * b.employmentInsurance();// 27,000 (0.9%)
 * b.total();              // 합산
 * }</pre>
 *
 * <p><strong>참고용</strong> — 실제 산출은 4 대보험 공단 / 회사 인사 부서 확인 필수.
 */
public final class SocialInsurance {

  private SocialInsurance() {}

  /** 월 보수액 입력 → 4 대보험 (3 종) 본인부담 분리. */
  public static InsuranceBreakdown calculate(Money monthlySalary) {
    Money nationalPension = monthlySalary.multiply(TaxRates.NATIONAL_PENSION);
    Money healthInsurance = monthlySalary.multiply(TaxRates.HEALTH_INSURANCE);
    Money longTermCare = healthInsurance.multiply(TaxRates.LONG_TERM_CARE_RATE_OF_HEALTH);
    Money employmentInsurance = monthlySalary.multiply(TaxRates.EMPLOYMENT_INSURANCE);
    Money total =
        nationalPension.plus(healthInsurance).plus(longTermCare).plus(employmentInsurance);
    return new InsuranceBreakdown(
        nationalPension, healthInsurance, longTermCare, employmentInsurance, total);
  }
}
