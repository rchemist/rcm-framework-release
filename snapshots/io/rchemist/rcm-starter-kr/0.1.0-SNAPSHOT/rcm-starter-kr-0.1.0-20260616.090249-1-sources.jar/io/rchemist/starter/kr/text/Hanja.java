/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.text;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한자 → 한글 변환 facade.
 *
 * <p><strong>baseline 상태 (Phase 6.5)</strong>: API 골격만 존재. KS X 1001 표준 4888 자
 * dataset 합류는 후속 task (Phase 0.1.x) 영역. 호출 시 {@link UnsupportedOperationException}
 * fail-loud (silent X). 0.0.5 도 한자 변환 영역 = 0 → 회귀 손실 X.
 */
public final class Hanja {

  private Hanja() {}

  public static String toHangul(String hanjaText) {
    throw new UnsupportedOperationException(
        "Hanja → Hangul dataset (KS X 1001, 4888 자) not yet bundled — Phase 0.1.x 후속 task 영역.");
  }
}
