/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link Geocoder} default 구현 — 모든 호출 fail-loud. Consumer 가 자체 어댑터 wire 하지 않으면
 * Geocoding 시도 즉시 의도 불명 silent fail 대신 명시 에러 발생.
 */
public final class NoopGeocoder implements Geocoder {

  @Override
  public Geocoded geocode(Address address) {
    throw new UnsupportedOperationException(
        "Geocoder is not configured — wire a Consumer-side @Component implementing Geocoder.");
  }

  @Override
  public Address reverseGeocode(double latitude, double longitude) {
    throw new UnsupportedOperationException(
        "Geocoder is not configured — wire a Consumer-side @Component implementing Geocoder.");
  }
}
