/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.money.Money;
import io.rchemist.core.numeric.percentage.Percentage;
import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 부가세 (VAT) 분리 / 합산 — Money + Percentage 활용.
 *
 * <p>2 진입점:
 * <ul>
 *   <li>{@link #fromSupply(Money)} — 공급가액 → 부가세 + 총액 (forward).</li>
 *   <li>{@link #fromIncluded(Money)} — 부가세 포함 가격 → 공급가액 + 부가세 (reverse).</li>
 * </ul>
 *
 * <p>요율은 {@link TaxRates#VAT_STANDARD} (10%) default. 영세율 / 면세 영역은
 * {@link #of(Percentage)} 로 0% 또는 다른 요율 instance 생성 후 사용.
 *
 * <p><strong>참고용</strong> — 실제 신고는 국세청 / 세무사 확인 필수.
 */
public final class Vat {

  private final Percentage rate;

  private Vat(Percentage rate) {
    this.rate = rate;
  }

  public static Vat standard() {
    return new Vat(TaxRates.VAT_STANDARD);
  }

  public static Vat zero() {
    return new Vat(TaxRates.VAT_ZERO);
  }

  public static Vat of(Percentage rate) {
    return new Vat(rate);
  }

  /** 공급가액 입력 → 부가세 / 총액 분리. */
  public VatBreakdown fromSupply(Money supply) {
    Money tax = supply.multiply(rate);
    Money total = supply.plus(tax);
    return new VatBreakdown(supply, tax, total);
  }

  /** 부가세 포함 가격 → 공급가액 / 부가세 분리 (역산). */
  public VatBreakdown fromIncluded(Money included) {
    BigDecimal divisor = BigDecimal.ONE.add(rate.asRatio());
    Money supply = included.dividedBy(divisor);
    Money tax = included.minus(supply);
    return new VatBreakdown(supply, tax, included);
  }

  public Percentage rate() {
    return rate;
  }
}
