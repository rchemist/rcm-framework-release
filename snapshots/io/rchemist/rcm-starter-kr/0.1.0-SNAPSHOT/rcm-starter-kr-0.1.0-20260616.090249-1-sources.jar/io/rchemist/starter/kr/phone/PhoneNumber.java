/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.phone;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 전화번호 검증 어노테이션 — 7 type 매트릭스 ({@link PhoneNumberType}).
 *
 * <p>속성:
 * <ul>
 *   <li>{@code types} — 허용할 종류. 비어있으면 모든 type 허용.</li>
 * </ul>
 *
 * <p>예시:
 * <pre>{@code
 * record SignupForm(
 *     @PhoneNumber String mobile,                                          // 모든 type 허용
 *     @PhoneNumber(types = PhoneNumberType.MOBILE) String mobileOnly,      // 휴대폰만
 *     @PhoneNumber(types = {PhoneNumberType.SEOUL, PhoneNumberType.LOCAL}) String office
 * ) {}
 * }</pre>
 */
@Documented
@Target({ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.RECORD_COMPONENT})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PhoneNumber.Validator.class)
public @interface PhoneNumber {

  String message() default "{rcm.kr.phone.invalid}";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  PhoneNumberType[] types() default {};

  class Validator implements ConstraintValidator<PhoneNumber, CharSequence> {
    private PhoneNumberType[] allowedTypes;

    @Override
    public void initialize(PhoneNumber constraintAnnotation) {
      this.allowedTypes = constraintAnnotation.types();
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
      if (value == null || value.length() == 0) {
        return true;
      }
      return PhoneNumberFormatter.isValid(value.toString(), allowedTypes);
    }
  }
}
