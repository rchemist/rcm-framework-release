/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.money.Money;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 원천징수 분리 결과 — gross / tax / net.
 *
 * @param gross 지급액 (총액).
 * @param tax 원천징수 세액.
 * @param net 실수령액 = gross - tax.
 */
public record WithholdingBreakdown(Money gross, Money tax, Money net) {}
