/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.tax;

import io.rchemist.core.numeric.percentage.Percentage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 세금 / 보험 요율 SPI — Consumer 가 연도별 요율 변경에 따라 override.
 *
 * <p>framework default = {@link TaxRates} 의 2026 년 baseline 위임. Consumer 가 자체
 * {@code @Component} 정의 시 ConditionalOnMissingBean 자동 양보.
 */
public interface TaxRateProvider {

  Percentage vatStandard();

  Percentage withholdingBusinessIncome();

  Percentage withholdingOtherIncome();

  Percentage nationalPension();

  Percentage healthInsurance();

  Percentage longTermCareRateOfHealth();

  Percentage employmentInsurance();
}
