/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.address;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 도로명주소 Records — {@code 서울특별시 강남구 테헤란로 152 아무빌딩 5 층}.
 *
 * @param sido 시 / 도 (예: {@code 서울특별시})
 * @param sigungu 시 / 군 / 구 (예: {@code 강남구})
 * @param roadName 도로명 (예: {@code 테헤란로}). 끝이 {@code 로} 또는 {@code 길} 로 끝나는 토큰.
 * @param buildingNumber 건물번호 (예: {@code 152} 또는 {@code 152-3}).
 * @param detail 상세주소 (예: {@code 아무빌딩 5 층}). 비어있을 수 있음.
 */
public record RoadNameAddress(
    String sido, String sigungu, String roadName, String buildingNumber, String detail)
    implements Address {

  public RoadNameAddress {
    Objects.requireNonNull(sido, "sido");
    Objects.requireNonNull(sigungu, "sigungu");
    Objects.requireNonNull(roadName, "roadName");
    Objects.requireNonNull(buildingNumber, "buildingNumber");
    detail = detail == null ? "" : detail;
  }

  @Override
  public String formatted() {
    String main = String.join(" ", sido, sigungu, roadName, buildingNumber);
    return detail.isEmpty() ? main : main + " " + detail;
  }
}
