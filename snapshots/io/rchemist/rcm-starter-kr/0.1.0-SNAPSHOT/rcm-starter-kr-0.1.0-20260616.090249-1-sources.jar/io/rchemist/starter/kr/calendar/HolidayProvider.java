/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.calendar;

import java.time.LocalDate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 공휴일 SPI — Consumer 가 자체 dataset (긴 영역 / 더 정확한 음력 / 임시 공휴일 / 회사 휴무일 등)
 * 으로 override 가능.
 *
 * <p>framework default = {@link DefaultHolidayProvider} ({@link KoreanHoliday} 위임).
 * Consumer 가 자체 {@code @Component} 정의 시 ConditionalOnMissingBean 자동 양보.
 */
public interface HolidayProvider {

  boolean isHoliday(LocalDate date);
}
