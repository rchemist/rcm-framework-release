/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.kr.phone;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 한국 전화번호 정규화 / 파싱 / 포맷 — JDK 표준 {@link Pattern} 만 사용 (libphonenumber 등 외부 의존 0).
 *
 * <p>지원 매트릭스 — 7 type ({@link PhoneNumberType}). 입력은 하이픈 / 공백 자동 제거 후 분류.
 * 분류 결과는 {@link ParsedPhoneNumber} Records 로 반환.
 *
 * <p>예시:
 * <pre>{@code
 * ParsedPhoneNumber p = PhoneNumberFormatter.parse("01012345678").orElseThrow();
 * p.type();        // MOBILE
 * p.formatted();   // "010-1234-5678"
 * p.e164();        // "+821012345678"
 * }</pre>
 */
public final class PhoneNumberFormatter {

  private static final Map<PhoneNumberType, Pattern> PATTERNS = buildPatterns();

  private PhoneNumberFormatter() {}

  private static Map<PhoneNumberType, Pattern> buildPatterns() {
    Map<PhoneNumberType, Pattern> map = new LinkedHashMap<>();
    map.put(PhoneNumberType.MOBILE, Pattern.compile("^(01[016789])(\\d{3,4})(\\d{4})$"));
    map.put(PhoneNumberType.SEOUL, Pattern.compile("^(02)(\\d{3,4})(\\d{4})$"));
    map.put(PhoneNumberType.LOCAL, Pattern.compile("^(0(?:3[1-3]|4[1-4]|5[1-5]|6[1-4]))(\\d{3,4})(\\d{4})$"));
    map.put(PhoneNumberType.VOIP, Pattern.compile("^(050\\d)(\\d{3,4})(\\d{4})$"));
    map.put(PhoneNumberType.INTERNET, Pattern.compile("^(070)(\\d{4})(\\d{4})$"));
    map.put(PhoneNumberType.TOLL_FREE, Pattern.compile("^(080)(\\d{3,4})(\\d{4})$"));
    map.put(PhoneNumberType.REPRESENTATIVE, Pattern.compile("^(1588|1577|1644|1666|1688|1899)(\\d{4})$"));
    return map;
  }

  /** 하이픈 / 공백 / E.164 prefix ({@code +82}) 자동 제거. */
  public static String normalize(String value) {
    if (value == null) {
      return "";
    }
    String stripped = value.replaceAll("[\\s-]", "");
    if (stripped.startsWith("+82")) {
      return "0" + stripped.substring(3);
    }
    return stripped;
  }

  /** 매칭되는 첫 type 으로 파싱. 모든 type 에 매칭 안 되면 {@link Optional#empty()}. */
  public static Optional<ParsedPhoneNumber> parse(String value) {
    String normalized = normalize(value);
    if (normalized.isEmpty()) {
      return Optional.empty();
    }
    for (Map.Entry<PhoneNumberType, Pattern> entry : PATTERNS.entrySet()) {
      Matcher m = entry.getValue().matcher(normalized);
      if (m.matches()) {
        if (entry.getKey() == PhoneNumberType.REPRESENTATIVE) {
          return Optional.of(
              new ParsedPhoneNumber(entry.getKey(), m.group(1), null, m.group(2)));
        }
        return Optional.of(
            new ParsedPhoneNumber(entry.getKey(), m.group(1), m.group(2), m.group(3)));
      }
    }
    return Optional.empty();
  }

  /** {@link #parse(String)} 후 {@link ParsedPhoneNumber#formatted()} — 한 줄 편의 메소드. */
  public static String format(String value) {
    return parse(value).map(ParsedPhoneNumber::formatted).orElse(value);
  }

  public static boolean isValid(String value) {
    return parse(value).isPresent();
  }

  public static boolean isValid(String value, PhoneNumberType... allowedTypes) {
    if (allowedTypes == null || allowedTypes.length == 0) {
      return isValid(value);
    }
    return parse(value)
        .map(parsed -> matchesAny(parsed.type(), allowedTypes))
        .orElse(false);
  }

  private static boolean matchesAny(PhoneNumberType type, PhoneNumberType[] candidates) {
    for (PhoneNumberType candidate : candidates) {
      if (candidate == type) {
        return true;
      }
    }
    return false;
  }
}
