/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * MessageDigest helper — SHA-256 / SHA-512 / MD5 (legacy 호환만, 보안 비추천) hex / base64.
 *
 * <p>JDK 25 의 {@link HexFormat} + {@code java.util.Base64} 사용. 외부 의존 0.
 **/
public final class MessageDigestUtil {

    private MessageDigestUtil() { }

    public static byte[] sha256(byte[] input) {
        return digest("SHA-256", input);
    }

    public static byte[] sha256(String input) {
        return sha256(input.getBytes(StandardCharsets.UTF_8));
    }

    public static String sha256Hex(String input) {
        return HexFormat.of().formatHex(sha256(input));
    }

    public static String sha256Base64(String input) {
        return java.util.Base64.getEncoder().encodeToString(sha256(input));
    }

    public static byte[] sha512(byte[] input) {
        return digest("SHA-512", input);
    }

    public static String sha512Hex(String input) {
        return HexFormat.of().formatHex(sha512(input.getBytes(StandardCharsets.UTF_8)));
    }

    /** legacy 호환 — checksum 외 보안 용도 비추천 (collision attack). */
    public static String md5Hex(String input) {
        return HexFormat.of().formatHex(digest("MD5", input.getBytes(StandardCharsets.UTF_8)));
    }

    /** custom 알고리즘 — sha256/512/md5 외 사용 시. */
    public static byte[] digest(String algorithm, byte[] input) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            return md.digest(input);
        }
        catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException("Unknown algorithm: " + algorithm, e);
        }
    }
}
