/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import io.hypersistence.tsid.TSID;
import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * TSID utility — {@code hypersistence-tsid} 보조 (parsing / 변환 / timestamp 추출). entity ID 생성은
 * {@code starter-jpa} 의 {@code @TsidGenerator} 가 책임 (Decision #21).
 *
 * <p>TSID = 64-bit Time-Sorted ID (Crockford base 32, 13 char). long 으로 저장 시 정렬 = 시간순 정렬.
 **/
public final class TsidUtil {

    private TsidUtil() { }

    /** 13 char Crockford base32 → TSID. */
    public static TSID fromString(String tsidString) {
        return TSID.from(tsidString);
    }

    /** long → TSID. */
    public static TSID fromLong(long tsidLong) {
        return TSID.from(tsidLong);
    }

    /** TSID instance → 13 char String (Crockford base32). */
    public static String toString(TSID tsid) {
        return tsid == null ? null : tsid.toString();
    }

    public static long toLong(TSID tsid) {
        return tsid == null ? 0L : tsid.toLong();
    }

    /** 13 char String → long (조회 인덱스 BIGINT 활용). */
    public static long stringToLong(String tsidString) {
        return TSID.from(tsidString).toLong();
    }

    public static String longToString(long tsidLong) {
        return TSID.from(tsidLong).toString();
    }

    /** TSID 생성 시각 추출 — 64-bit 의 상위 42-bit timestamp 영역. */
    public static Instant extractInstant(TSID tsid) {
        if (tsid == null) {
            return null;
        }
        return Instant.ofEpochMilli(tsid.getInstant().toEpochMilli());
    }

    public static Instant extractInstant(long tsidLong) {
        return extractInstant(TSID.from(tsidLong));
    }

    public static Instant extractInstant(String tsidString) {
        return extractInstant(TSID.from(tsidString));
    }

    /** valid TSID String 인지 형식 검증 (parsing 시도). */
    public static boolean isValid(String tsidString) {
        if (tsidString == null || tsidString.length() != 13) {
            return false;
        }
        try {
            TSID.from(tsidString);
            return true;
        }
        catch (IllegalArgumentException e) {
            return false;
        }
    }
}
