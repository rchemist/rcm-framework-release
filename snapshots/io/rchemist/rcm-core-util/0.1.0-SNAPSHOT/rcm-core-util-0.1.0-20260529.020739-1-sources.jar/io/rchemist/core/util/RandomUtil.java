/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.security.SecureRandom;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Random helper — *security-critical 영역만 SecureRandom*, 그 외 (ThreadLocalRandom) 으로 비용 회피.
 *
 * <p>cherry-pick (사용자 요청, 메모리 feedback_util_cherry_pick).
 **/
public final class RandomUtil {

    private static final SecureRandom SECURE = new SecureRandom();
    private static final char[] ALPHANUM =
            "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    private static final char[] DIGITS = "0123456789".toCharArray();
    private static final char[] LOWER = "abcdefghijklmnopqrstuvwxyz".toCharArray();
    private static final char[] UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    private RandomUtil() { }

    /** [0, max) 의 random int — fast (ThreadLocalRandom). */
    public static int nextInt(int max) {
        if (max <= 0) {
            throw new IllegalArgumentException("max > 0");
        }
        return ThreadLocalRandom.current().nextInt(max);
    }

    /** [origin, bound) 의 random int. */
    public static int nextInt(int origin, int bound) {
        return ThreadLocalRandom.current().nextInt(origin, bound);
    }

    public static long nextLong(long origin, long bound) {
        return ThreadLocalRandom.current().nextLong(origin, bound);
    }

    public static double nextDouble() {
        return ThreadLocalRandom.current().nextDouble();
    }

    public static boolean nextBoolean() {
        return ThreadLocalRandom.current().nextBoolean();
    }

    /** alphanumeric String — *non-secure* (ThreadLocalRandom). 단순 ID / nonce 용도. */
    public static String randomAlphanumeric(int length) {
        return random(length, ALPHANUM, false);
    }

    /** digits-only String. */
    public static String randomDigits(int length) {
        return random(length, DIGITS, false);
    }

    public static String randomLower(int length) {
        return random(length, LOWER, false);
    }

    public static String randomUpper(int length) {
        return random(length, UPPER, false);
    }

    /** alphanumeric secure String (SecureRandom) — token / secret 용도. */
    public static String secureAlphanumeric(int length) {
        return random(length, ALPHANUM, true);
    }

    /** secure digits-only — OTP / verification code 용도. */
    public static String secureDigits(int length) {
        return random(length, DIGITS, true);
    }

    /** UUID v4 random String (lowercase, hyphenated). */
    public static String uuid() {
        return UUID.randomUUID().toString();
    }

    /** UUID v4 hex (no hyphen, 32 char). */
    public static String uuidHex() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /** 임의 charset 으로 길이 length 의 랜덤 문자열. */
    public static String random(int length, char[] alphabet, boolean secure) {
        if (length <= 0) {
            return "";
        }
        if (alphabet == null || alphabet.length == 0) {
            throw new IllegalArgumentException("alphabet 필요");
        }
        char[] buf = new char[length];
        if (secure) {
            for (int i = 0; i < length; i++) {
                buf[i] = alphabet[SECURE.nextInt(alphabet.length)];
            }
        }
        else {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            for (int i = 0; i < length; i++) {
                buf[i] = alphabet[r.nextInt(alphabet.length)];
            }
        }
        return new String(buf);
    }

    /** byte[] 랜덤 (secure). e.g. salt / nonce. */
    public static byte[] secureBytes(int length) {
        byte[] b = new byte[length];
        SECURE.nextBytes(b);
        return b;
    }
}
