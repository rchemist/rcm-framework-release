/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * LocalDateTime 보조 — parsing 다중 포맷 / 변환 / start-end of period.
 **/
public final class LocalDateTimeUtil {

    public static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    public static final DateTimeFormatter COMPACT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    public static final DateTimeFormatter STANDARD = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final DateTimeFormatter SLASH = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    private LocalDateTimeUtil() { }

    public static LocalDateTime now() {
        return LocalDateTime.now();
    }

    public static LocalDateTime now(ZoneId zone) {
        return LocalDateTime.now(zone);
    }

    /** 다중 포맷 parsing (ISO / "yyyy-MM-dd HH:mm:ss" / "yyyy/MM/dd HH:mm:ss" / compact). null/blank → null. */
    public static LocalDateTime parse(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        String t = text.trim();
        for (DateTimeFormatter fmt : new DateTimeFormatter[] {ISO, STANDARD, SLASH, COMPACT}) {
            try {
                return LocalDateTime.parse(t, fmt);
            }
            catch (DateTimeParseException ignored) {
                // 다음 포맷
            }
        }
        return null;
    }

    public static LocalDateTime parse(String text, String pattern) {
        if (text == null || text.isBlank()) {
            return null;
        }
        return LocalDateTime.parse(text.trim(), DateTimeFormatter.ofPattern(pattern));
    }

    public static String format(LocalDateTime ldt) {
        return ldt == null ? null : ldt.format(STANDARD);
    }

    public static String format(LocalDateTime ldt, String pattern) {
        return ldt == null ? null : ldt.format(DateTimeFormatter.ofPattern(pattern));
    }

    public static String formatIso(LocalDateTime ldt) {
        return ldt == null ? null : ldt.format(ISO);
    }

    public static Instant toInstant(LocalDateTime ldt, ZoneId zone) {
        return ldt == null ? null : ldt.atZone(zone).toInstant();
    }

    public static Instant toInstantKst(LocalDateTime ldt) {
        return toInstant(ldt, InstantUtil.KST);
    }

    public static LocalDate toLocalDate(LocalDateTime ldt) {
        return ldt == null ? null : ldt.toLocalDate();
    }

    public static LocalTime toLocalTime(LocalDateTime ldt) {
        return ldt == null ? null : ldt.toLocalTime();
    }

    /** 같은 day 의 시작 (00:00:00). */
    public static LocalDateTime startOfDay(LocalDateTime ldt) {
        return ldt == null ? null : ldt.toLocalDate().atStartOfDay();
    }

    /** 같은 day 의 끝. */
    public static LocalDateTime endOfDay(LocalDateTime ldt) {
        return ldt == null ? null : ldt.toLocalDate().atTime(23, 59, 59, 999_999_999);
    }

    public static LocalDateTime plusDays(LocalDateTime ldt, long days) {
        return ldt == null ? null : ldt.plusDays(days);
    }

    public static LocalDateTime plusHours(LocalDateTime ldt, long hours) {
        return ldt == null ? null : ldt.plusHours(hours);
    }

    public static LocalDateTime plusMinutes(LocalDateTime ldt, long minutes) {
        return ldt == null ? null : ldt.plusMinutes(minutes);
    }

    public static long minutesBetween(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.MINUTES.between(start, end);
    }

    public static long hoursBetween(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.HOURS.between(start, end);
    }

    public static long daysBetween(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(start, end);
    }

    public static Duration durationBetween(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) {
            return Duration.ZERO;
        }
        return Duration.between(start, end);
    }

    public static boolean isBetween(LocalDateTime target, LocalDateTime start, LocalDateTime end) {
        if (target == null || start == null || end == null) {
            return false;
        }
        return !target.isBefore(start) && !target.isAfter(end);
    }
}
