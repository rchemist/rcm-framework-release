/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Boolean 안전 변환 — Y/N, 1/0, true/false, t/f, yes/no 모두 흡수.
 *
 * <p>흔한 0.0.5 → 0.1.0 마이그레이션: legacy 컬럼 (Y/N CHAR) ↔ Java boolean.
 **/
public final class BooleanUtil {

    private BooleanUtil() { }

    /** "Y"/"y"/"YES"/"yes"/"true"/"1" → true, 그 외 (null 포함) → false. */
    public static boolean toBoolean(Object value) {
        return toBoolean(value, false);
    }

    public static boolean toBoolean(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean b) {
            return b;
        }
        if (value instanceof Number n) {
            return n.intValue() != 0;
        }
        String s = value.toString().trim();
        if (s.isEmpty()) {
            return defaultValue;
        }
        return switch (s.toLowerCase(java.util.Locale.ROOT)) {
            case "y", "yes", "true", "t", "1", "on" -> true;
            case "n", "no", "false", "f", "0", "off" -> false;
            default -> defaultValue;
        };
    }

    /** boolean → "Y"/"N" (legacy DB 호환). */
    public static String toYn(boolean value) {
        return value ? "Y" : "N";
    }

    /** Boolean → "Y"/"N"/null. */
    public static String toYn(Boolean value) {
        return value == null ? null : toYn(value.booleanValue());
    }

    /** 모두 true. */
    public static boolean allTrue(Boolean... values) {
        if (values == null || values.length == 0) {
            return false;
        }
        for (Boolean b : values) {
            if (b == null || !b) {
                return false;
            }
        }
        return true;
    }

    /** 하나라도 true. */
    public static boolean anyTrue(Boolean... values) {
        if (values == null) {
            return false;
        }
        for (Boolean b : values) {
            if (b != null && b) {
                return true;
            }
        }
        return false;
    }

    /** null → defaultValue, 그 외 → 그대로. */
    public static boolean defaultIfNull(Boolean value, boolean defaultValue) {
        return value == null ? defaultValue : value;
    }
}
