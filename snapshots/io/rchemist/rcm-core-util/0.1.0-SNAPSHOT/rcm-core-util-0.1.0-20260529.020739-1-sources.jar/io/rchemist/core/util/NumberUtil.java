/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Number helper — null-safe parse / format / clamp / round.
 **/
public final class NumberUtil {

    private NumberUtil() { }

    public static Integer parseIntOrNull(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return Integer.parseInt(s.trim());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    public static int parseIntOrDefault(String s, int defaultValue) {
        Integer v = parseIntOrNull(s);
        return v == null ? defaultValue : v;
    }

    public static Long parseLongOrNull(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return Long.parseLong(s.trim());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    public static long parseLongOrDefault(String s, long defaultValue) {
        Long v = parseLongOrNull(s);
        return v == null ? defaultValue : v;
    }

    public static Double parseDoubleOrNull(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return Double.parseDouble(s.trim());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    public static double parseDoubleOrDefault(String s, double defaultValue) {
        Double v = parseDoubleOrNull(s);
        return v == null ? defaultValue : v;
    }

    public static BigDecimal parseDecimalOrNull(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(s.trim());
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    /** value 를 [min, max] 로 clamp. */
    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public static long clamp(long value, long min, long max) {
        return Math.max(min, Math.min(max, value));
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    /** scale 자리에서 HALF_UP 반올림. */
    public static BigDecimal round(BigDecimal value, int scale) {
        if (value == null) {
            return null;
        }
        return value.setScale(scale, RoundingMode.HALF_UP);
    }

    public static double round(double value, int scale) {
        return BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
    }

    /** comma thousands separator (예: 1234567 → "1,234,567"). */
    public static String formatThousands(long value) {
        return NumberFormat.getNumberInstance(Locale.ROOT).format(value);
    }

    public static String formatThousands(double value) {
        return NumberFormat.getNumberInstance(Locale.ROOT).format(value);
    }

    /** decimal places 명시 — 예: format(3.14159, "0.00") → "3.14". */
    public static String format(double value, String pattern) {
        return new DecimalFormat(pattern).format(value);
    }

    /** byte 크기 → human-readable (1024 base, 예: 1536 → "1.5 KB"). */
    public static String formatBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        String[] units = {"KB", "MB", "GB", "TB", "PB"};
        double v = bytes / 1024.0;
        int idx = 0;
        while (v >= 1024 && idx < units.length - 1) {
            v /= 1024;
            idx++;
        }
        return String.format(Locale.ROOT, "%.1f %s", v, units[idx]);
    }

    /** 0 보다 큰지 (null-safe). */
    public static boolean isPositive(Number n) {
        return n != null && n.doubleValue() > 0;
    }

    /** 0 또는 양수. */
    public static boolean isNonNegative(Number n) {
        return n != null && n.doubleValue() >= 0;
    }

    /** null → 0. */
    public static int defaultIfNull(Integer n) {
        return n == null ? 0 : n;
    }

    public static long defaultIfNull(Long n) {
        return n == null ? 0L : n;
    }

    public static double defaultIfNull(Double n) {
        return n == null ? 0.0 : n;
    }
}
