/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Jackson JSON helper — toJson / fromJson 흔한 용도. Spring Boot 의 wired ObjectMapper 와 별개 *static
 * baseline* (config 누락 / 단발성 사용 / unit test 영역).
 *
 * <p>설정 default: {@code UNKNOWN_PROPERTIES} ignore (forward-compat) + null 필드 omit + ISO timestamp
 * (단 Java time module 등록 안 함 — Consumer 가 명시 등록 시).
 *
 * <p>Spring 통합 영역에서는 *Spring 의 wired ObjectMapper 를 주입* — JsonUtil 은 *static baseline* 영역
 * (편의성 + 유닛 테스트 영역).
 **/
public final class JsonUtil {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    private static final ObjectMapper PRETTY = MAPPER.copy()
            .enable(SerializationFeature.INDENT_OUTPUT);

    private JsonUtil() { }

    /** 내장 ObjectMapper 직접 노출 (custom Module 등록 등 영역). */
    public static ObjectMapper mapper() {
        return MAPPER;
    }

    /** Object → JSON String. null → "null". */
    public static String toJson(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException("toJson failed: " + e.getOriginalMessage(), e);
        }
    }

    /** Object → 들여쓰기된 JSON String. */
    public static String toPrettyJson(Object value) {
        try {
            return PRETTY.writeValueAsString(value);
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException("toPrettyJson failed: " + e.getOriginalMessage(), e);
        }
    }

    /** JSON String → Class<T> instance. null/blank → null. */
    public static <T> T fromJson(String json, Class<T> type) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return MAPPER.readValue(json, type);
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException(
                    "fromJson failed (" + type.getSimpleName() + "): " + e.getOriginalMessage(), e);
        }
    }

    /** JSON String → TypeReference (Generic 보존, 예: {@code List<Article>} / {@code Map<String, Object>}). */
    public static <T> T fromJson(String json, TypeReference<T> typeReference) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return MAPPER.readValue(json, typeReference);
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException(
                    "fromJson<TypeReference> failed: " + e.getOriginalMessage(), e);
        }
    }

    /** JSON String → {@link Map}{@code <String, Object>} 단축. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> toMap(String json) {
        return fromJson(json, Map.class);
    }

    /** JSON String → {@link List} 단축 (요소 타입 명시). */
    public static <T> List<T> toList(String json, Class<T> elementType) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return MAPPER.readValue(json,
                    MAPPER.getTypeFactory().constructCollectionType(List.class, elementType));
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException(
                    "toList failed (" + elementType.getSimpleName() + "): " + e.getOriginalMessage(), e);
        }
    }

    /** Object 간 *변환* (Map → Records, A → B 등). */
    public static <T> T convert(Object source, Class<T> targetType) {
        return MAPPER.convertValue(source, targetType);
    }

    public static <T> T convert(Object source, TypeReference<T> typeReference) {
        return MAPPER.convertValue(source, typeReference);
    }

    /** JSON String → JsonNode (Jackson 트리 — *부분 navigation* 시). */
    public static JsonNode parseTree(String json) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            return MAPPER.readTree(json);
        }
        catch (JsonProcessingException e) {
            throw new IllegalStateException("parseTree failed: " + e.getOriginalMessage(), e);
        }
    }

    /** valid JSON 인지 형식 검증 (parsing 시도). */
    public static boolean isValidJson(String json) {
        if (json == null || json.isBlank()) {
            return false;
        }
        try {
            MAPPER.readTree(json);
            return true;
        }
        catch (JsonProcessingException e) {
            return false;
        }
    }
}
