/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.text.Normalizer;
import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 흔히 쓰이는 String util — Apache Commons Lang StringUtils 의 lite 영역 (외부 의존 0).
 *
 * <p>0.0.5 cherry-pick + 풍부한 baseline. null-safe default 우선 (예: isBlank 가 null 도 true).
 **/
public final class StringUtil {

    private StringUtil() { }

    public static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    public static boolean isNotEmpty(String s) {
        return !isEmpty(s);
    }

    public static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    public static boolean isNotBlank(String s) {
        return !isBlank(s);
    }

    /** null → "", 그 외 → trim. */
    public static String trimToEmpty(String s) {
        return s == null ? "" : s.trim();
    }

    /** null / blank → null, 그 외 → trim. */
    public static String trimToNull(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    /** null / blank → fallback, 그 외 → 그대로. */
    public static String defaultIfBlank(String s, String fallback) {
        return isBlank(s) ? fallback : s;
    }

    /** null → fallback, 그 외 → 그대로 (empty 도 그대로 통과). */
    public static String defaultIfNull(String s, String fallback) {
        return s == null ? fallback : s;
    }

    /** null-safe equals — 둘 다 null = true. */
    public static boolean equals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    /** null-safe equalsIgnoreCase. */
    public static boolean equalsIgnoreCase(String a, String b) {
        return a == null ? b == null : a.equalsIgnoreCase(b);
    }

    /** 좌측 zero-pad (예: pad("7", 4) → "0007"). */
    public static String leftPad(String s, int width) {
        return leftPad(s, width, '0');
    }

    public static String leftPad(String s, int width, char ch) {
        String src = s == null ? "" : s;
        if (src.length() >= width) {
            return src;
        }
        StringBuilder sb = new StringBuilder(width);
        for (int i = src.length(); i < width; i++) {
            sb.append(ch);
        }
        return sb.append(src).toString();
    }

    /** 우측 space-pad. */
    public static String rightPad(String s, int width) {
        return rightPad(s, width, ' ');
    }

    public static String rightPad(String s, int width, char ch) {
        String src = s == null ? "" : s;
        if (src.length() >= width) {
            return src;
        }
        StringBuilder sb = new StringBuilder(width).append(src);
        for (int i = src.length(); i < width; i++) {
            sb.append(ch);
        }
        return sb.toString();
    }

    /** 처음 N 글자만 (length 보다 짧으면 그대로). */
    public static String left(String s, int n) {
        if (s == null) {
            return null;
        }
        return n >= s.length() ? s : s.substring(0, Math.max(0, n));
    }

    public static String right(String s, int n) {
        if (s == null) {
            return null;
        }
        return n >= s.length() ? s : s.substring(s.length() - Math.max(0, n));
    }

    /** 길이 초과 시 ... 부착 (null-safe). */
    public static String abbreviate(String s, int max) {
        if (s == null || s.length() <= max) {
            return s;
        }
        if (max <= 3) {
            return s.substring(0, max);
        }
        return s.substring(0, max - 3) + "...";
    }

    /** snake_case → camelCase. */
    public static String snakeToCamel(String s) {
        if (isBlank(s)) {
            return s;
        }
        StringBuilder sb = new StringBuilder(s.length());
        boolean nextUpper = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '_') {
                nextUpper = true;
            }
            else if (nextUpper) {
                sb.append(Character.toUpperCase(c));
                nextUpper = false;
            }
            else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** camelCase → snake_case (소문자). */
    public static String camelToSnake(String s) {
        if (isBlank(s)) {
            return s;
        }
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isUpperCase(c) && i > 0) {
                sb.append('_');
            }
            sb.append(Character.toLowerCase(c));
        }
        return sb.toString();
    }

    /** 한글 자모 분리 + ASCII 정규화 (검색 용도) — NFKD + Mn (combining mark) 제거. */
    public static String normalize(String s) {
        if (s == null) {
            return null;
        }
        String n = Normalizer.normalize(s, Normalizer.Form.NFKD);
        return n.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    /** Lower-case using {@link Locale#ROOT} — locale-bug 회피 (i18n turkish I 등). */
    public static String lowerRoot(String s) {
        return s == null ? null : s.toLowerCase(Locale.ROOT);
    }

    public static String upperRoot(String s) {
        return s == null ? null : s.toUpperCase(Locale.ROOT);
    }

    /** repeat (JDK 11+ String.repeat 의 null-safe). */
    public static String repeat(String s, int n) {
        if (s == null || n <= 0) {
            return "";
        }
        return s.repeat(n);
    }

    /** 숫자만 남김 (예: phone "010-1234-5678" → "01012345678"). */
    public static String digitsOnly(String s) {
        if (s == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** s 가 prefix 로 시작하지 않으면 prefix 부착. */
    public static String prependIfMissing(String s, String prefix) {
        if (s == null || prefix == null || s.startsWith(prefix)) {
            return s;
        }
        return prefix + s;
    }

    /** s 가 suffix 로 끝나지 않으면 suffix 부착. */
    public static String appendIfMissing(String s, String suffix) {
        if (s == null || suffix == null || s.endsWith(suffix)) {
            return s;
        }
        return s + suffix;
    }

    /** s 가 candidates 중 하나와도 같으면 true (null-safe). */
    public static boolean equalsAny(String s, String... candidates) {
        if (candidates == null) {
            return false;
        }
        for (String c : candidates) {
            if (equals(s, c)) {
                return true;
            }
        }
        return false;
    }

    public static boolean equalsAnyIgnoreCase(String s, String... candidates) {
        if (candidates == null) {
            return false;
        }
        for (String c : candidates) {
            if (equalsIgnoreCase(s, c)) {
                return true;
            }
        }
        return false;
    }

    /** s 안에 substrings 중 하나라도 포함되면 true. */
    public static boolean containsAny(String s, String... substrings) {
        if (s == null || substrings == null) {
            return false;
        }
        for (String sub : substrings) {
            if (sub != null && s.contains(sub)) {
                return true;
            }
        }
        return false;
    }

    /** start 직후 ~ end 직전 substring (start/end 자체 미포함, 못 찾으면 null). */
    public static String between(String s, String start, String end) {
        if (s == null || start == null || end == null) {
            return null;
        }
        int i = s.indexOf(start);
        if (i < 0) {
            return null;
        }
        int from = i + start.length();
        int j = s.indexOf(end, from);
        if (j < 0) {
            return null;
        }
        return s.substring(from, j);
    }

    /** sep 첫 등장 *직후* substring (못 찾으면 ""). */
    public static String substringAfter(String s, String sep) {
        if (isEmpty(s) || sep == null) {
            return s;
        }
        int i = s.indexOf(sep);
        return i < 0 ? "" : s.substring(i + sep.length());
    }

    /** sep 마지막 등장 *직후* substring (못 찾으면 ""). */
    public static String substringAfterLast(String s, String sep) {
        if (isEmpty(s) || isEmpty(sep)) {
            return s;
        }
        int i = s.lastIndexOf(sep);
        return i < 0 ? "" : s.substring(i + sep.length());
    }

    /** sep 첫 등장 *직전* substring (못 찾으면 s 그대로). */
    public static String substringBefore(String s, String sep) {
        if (isEmpty(s) || sep == null) {
            return s;
        }
        int i = s.indexOf(sep);
        return i < 0 ? s : s.substring(0, i);
    }

    /** sep 마지막 등장 *직전* substring. */
    public static String substringBeforeLast(String s, String sep) {
        if (isEmpty(s) || isEmpty(sep)) {
            return s;
        }
        int i = s.lastIndexOf(sep);
        return i < 0 ? s : s.substring(0, i);
    }

    /** delimiter 로 split → trim → empty 제거. */
    public static java.util.List<String> splitTrim(String s, String delimiter) {
        if (isEmpty(s) || delimiter == null) {
            return java.util.List.of();
        }
        String[] parts = s.split(java.util.regex.Pattern.quote(delimiter));
        java.util.List<String> result = new java.util.ArrayList<>(parts.length);
        for (String p : parts) {
            String t = p.trim();
            if (!t.isEmpty()) {
                result.add(t);
            }
        }
        return result;
    }

    /** CJK / 한글 / 일본어 / 한자 같은 double-byte 문자 포함 여부 (검색 / 길이 산정). */
    public static boolean containsDoubleByte(String s) {
        if (s == null) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            if (isDoubleByteCharacter(s.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    public static boolean isDoubleByteCharacter(char c) {
        Character.UnicodeBlock b = Character.UnicodeBlock.of(c);
        return b == Character.UnicodeBlock.HANGUL_SYLLABLES
                || b == Character.UnicodeBlock.HANGUL_JAMO
                || b == Character.UnicodeBlock.HANGUL_COMPATIBILITY_JAMO
                || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                || b == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || b == Character.UnicodeBlock.HIRAGANA
                || b == Character.UnicodeBlock.KATAKANA;
    }

    /** non-null 만 join (null 은 skip). */
    public static String joinNonNull(String delimiter, Object... parts) {
        if (parts == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (Object p : parts) {
            if (p == null) {
                continue;
            }
            if (!first) {
                sb.append(delimiter);
            }
            sb.append(p);
            first = false;
        }
        return sb.toString();
    }

    /** non-blank String 만 join. */
    public static String joinNonBlank(String delimiter, String... parts) {
        if (parts == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (String p : parts) {
            if (isBlank(p)) {
                continue;
            }
            if (!first) {
                sb.append(delimiter);
            }
            sb.append(p);
            first = false;
        }
        return sb.toString();
    }

    /** 첫 글자 대문자. */
    public static String capitalize(String s) {
        if (isEmpty(s)) {
            return s;
        }
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** 첫 글자 소문자. */
    public static String uncapitalize(String s) {
        if (isEmpty(s)) {
            return s;
        }
        return Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }

    /** 문자열 byte length (default UTF-8). */
    public static int utf8ByteLength(String s) {
        return s == null ? 0 : s.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
    }

    /**
     * Object → JSON String. {@link JsonUtil#toJson} delegating shortcut — 0.0.5 의 {@code StringUtil.toJson}
     * 습관 정합. *static baseline ObjectMapper* 사용 (Spring 통합 영역에선 wired ObjectMapper 권장).
     */
    public static String toJson(Object value) {
        return JsonUtil.toJson(value);
    }

    /** JSON String → Class<T>. {@link JsonUtil#fromJson(String, Class)} delegating shortcut. */
    public static <T> T fromJson(String json, Class<T> type) {
        return JsonUtil.fromJson(json, type);
    }
}
