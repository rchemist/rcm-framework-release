/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * LocalDate 보조 — 다중 포맷 parse / 한국 스타일 format / week/month 영역 / age 계산.
 **/
public final class LocalDateUtil {

    public static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE;
    public static final DateTimeFormatter COMPACT = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final DateTimeFormatter SLASH = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    public static final DateTimeFormatter DOT = DateTimeFormatter.ofPattern("yyyy.MM.dd");
    public static final DateTimeFormatter KO = DateTimeFormatter.ofPattern("yyyy년 M월 d일");

    private LocalDateUtil() { }

    public static LocalDate today() {
        return LocalDate.now();
    }

    public static LocalDate parse(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        String t = text.trim();
        for (DateTimeFormatter fmt : new DateTimeFormatter[] {ISO, SLASH, DOT, COMPACT}) {
            try {
                return LocalDate.parse(t, fmt);
            }
            catch (DateTimeParseException ignored) {
                // 다음
            }
        }
        return null;
    }

    public static LocalDate parse(String text, String pattern) {
        if (text == null || text.isBlank()) {
            return null;
        }
        return LocalDate.parse(text.trim(), DateTimeFormatter.ofPattern(pattern));
    }

    public static String format(LocalDate date) {
        return date == null ? null : date.format(ISO);
    }

    public static String format(LocalDate date, String pattern) {
        return date == null ? null : date.format(DateTimeFormatter.ofPattern(pattern));
    }

    public static String formatKo(LocalDate date) {
        return date == null ? null : date.format(KO);
    }

    public static String formatCompact(LocalDate date) {
        return date == null ? null : date.format(COMPACT);
    }

    /** 이번 달 첫째 날. */
    public static LocalDate firstDayOfMonth(LocalDate date) {
        return date == null ? null : date.with(TemporalAdjusters.firstDayOfMonth());
    }

    public static LocalDate lastDayOfMonth(LocalDate date) {
        return date == null ? null : date.with(TemporalAdjusters.lastDayOfMonth());
    }

    /** 이번 주 월요일. */
    public static LocalDate firstDayOfWeek(LocalDate date) {
        return date == null ? null : date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    public static LocalDate lastDayOfWeek(LocalDate date) {
        return date == null ? null : date.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
    }

    public static long daysBetween(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(start, end);
    }

    public static long monthsBetween(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.MONTHS.between(start, end);
    }

    public static long yearsBetween(LocalDate start, LocalDate end) {
        if (start == null || end == null) {
            return 0;
        }
        return ChronoUnit.YEARS.between(start, end);
    }

    /** age (만 나이) — birth ~ today. */
    public static int age(LocalDate birth) {
        if (birth == null) {
            return 0;
        }
        return Period.between(birth, LocalDate.now()).getYears();
    }

    public static int age(LocalDate birth, LocalDate refer) {
        if (birth == null || refer == null) {
            return 0;
        }
        return Period.between(birth, refer).getYears();
    }

    public static boolean isWeekend(LocalDate date) {
        if (date == null) {
            return false;
        }
        DayOfWeek d = date.getDayOfWeek();
        return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY;
    }

    public static boolean isWeekday(LocalDate date) {
        return date != null && !isWeekend(date);
    }

    public static boolean isBetween(LocalDate target, LocalDate start, LocalDate end) {
        if (target == null || start == null || end == null) {
            return false;
        }
        return !target.isBefore(start) && !target.isAfter(end);
    }

    public static int dayCountInMonth(int year, int month) {
        return YearMonth.of(year, month).lengthOfMonth();
    }

    public static int dayCountInMonth(LocalDate date) {
        return date == null ? 0 : date.lengthOfMonth();
    }

    public static LocalDate plusDays(LocalDate date, long days) {
        return date == null ? null : date.plusDays(days);
    }

    public static LocalDate plusMonths(LocalDate date, long months) {
        return date == null ? null : date.plusMonths(months);
    }

    public static LocalDate plusYears(LocalDate date, long years) {
        return date == null ? null : date.plusYears(years);
    }
}
