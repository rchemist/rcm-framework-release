/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Instant 보조 — TZ 변환 / 기간 비교 / parsing / formatting / start/end of day, week, month.
 *
 * <p>baseline: instant = UTC, 표시는 zone 변환. {@code TimeZoneUtil} 와 짝.
 **/
public final class InstantUtil {

    public static final ZoneId KST = ZoneId.of("Asia/Seoul");
    public static final ZoneId UTC = ZoneOffset.UTC;
    public static final DateTimeFormatter ISO = DateTimeFormatter.ISO_INSTANT;

    private InstantUtil() { }

    public static Instant now() {
        return Instant.now();
    }

    public static Instant nowOrNull(boolean trueIfNow) {
        return trueIfNow ? Instant.now() : null;
    }

    /** ISO-8601 String → Instant (null/blank → null). */
    public static Instant parse(String iso) {
        if (iso == null || iso.isBlank()) {
            return null;
        }
        return Instant.parse(iso.trim());
    }

    /** Instant → ISO-8601 (UTC, 'Z' suffix). null-safe. */
    public static String format(Instant instant) {
        return instant == null ? null : ISO.format(instant);
    }

    /** zoneId 기준 LocalDateTime 변환. */
    public static LocalDateTime toLocalDateTime(Instant instant, ZoneId zone) {
        return instant == null ? null : LocalDateTime.ofInstant(instant, zone);
    }

    public static LocalDateTime toLocalDateTimeKst(Instant instant) {
        return toLocalDateTime(instant, KST);
    }

    public static LocalDate toLocalDate(Instant instant, ZoneId zone) {
        return instant == null ? null : instant.atZone(zone).toLocalDate();
    }

    public static LocalDate toLocalDateKst(Instant instant) {
        return toLocalDate(instant, KST);
    }

    public static ZonedDateTime toZonedDateTime(Instant instant, ZoneId zone) {
        return instant == null ? null : instant.atZone(zone);
    }

    public static OffsetDateTime toOffsetDateTime(Instant instant, ZoneId zone) {
        return instant == null ? null : instant.atZone(zone).toOffsetDateTime();
    }

    /** epoch seconds → Instant. */
    public static Instant fromEpochSecond(long epochSecond) {
        return Instant.ofEpochSecond(epochSecond);
    }

    public static Instant fromEpochMilli(long epochMilli) {
        return Instant.ofEpochMilli(epochMilli);
    }

    /** zoneId 기준 day 시작 (00:00:00). */
    public static Instant startOfDay(Instant instant, ZoneId zone) {
        if (instant == null) {
            return null;
        }
        return instant.atZone(zone).toLocalDate().atStartOfDay(zone).toInstant();
    }

    /** zoneId 기준 day 끝 (23:59:59.999_999_999). */
    public static Instant endOfDay(Instant instant, ZoneId zone) {
        if (instant == null) {
            return null;
        }
        return instant.atZone(zone).toLocalDate().atTime(23, 59, 59, 999_999_999).atZone(zone).toInstant();
    }

    public static Instant startOfDayKst(Instant instant) {
        return startOfDay(instant, KST);
    }

    public static Instant endOfDayKst(Instant instant) {
        return endOfDay(instant, KST);
    }

    public static Instant startOfMonth(Instant instant, ZoneId zone) {
        if (instant == null) {
            return null;
        }
        return instant.atZone(zone).withDayOfMonth(1).toLocalDate().atStartOfDay(zone).toInstant();
    }

    public static Instant endOfMonth(Instant instant, ZoneId zone) {
        if (instant == null) {
            return null;
        }
        ZonedDateTime z = instant.atZone(zone);
        int last = z.toLocalDate().lengthOfMonth();
        return z.withDayOfMonth(last).toLocalDate().atTime(23, 59, 59, 999_999_999).atZone(zone).toInstant();
    }

    /** plus seconds. */
    public static Instant plusSeconds(Instant instant, long seconds) {
        return instant == null ? null : instant.plusSeconds(seconds);
    }

    public static Instant plusMinutes(Instant instant, long minutes) {
        return instant == null ? null : instant.plus(minutes, ChronoUnit.MINUTES);
    }

    public static Instant plusHours(Instant instant, long hours) {
        return instant == null ? null : instant.plus(hours, ChronoUnit.HOURS);
    }

    public static Instant plusDays(Instant instant, long days) {
        return instant == null ? null : instant.plus(days, ChronoUnit.DAYS);
    }

    public static Instant minusDays(Instant instant, long days) {
        return plusDays(instant, -days);
    }

    /** 두 Instant 의 Duration (start ~ end). null 처리: start/end 중 null 있으면 Duration.ZERO. */
    public static Duration between(Instant start, Instant end) {
        if (start == null || end == null) {
            return Duration.ZERO;
        }
        return Duration.between(start, end);
    }

    public static long secondsBetween(Instant start, Instant end) {
        return between(start, end).getSeconds();
    }

    public static long minutesBetween(Instant start, Instant end) {
        return between(start, end).toMinutes();
    }

    public static long hoursBetween(Instant start, Instant end) {
        return between(start, end).toHours();
    }

    public static long daysBetween(Instant start, Instant end) {
        return between(start, end).toDays();
    }

    /** target 이 현 시점 이전인지. */
    public static boolean isPast(Instant target) {
        return target != null && target.isBefore(Instant.now());
    }

    public static boolean isFuture(Instant target) {
        return target != null && target.isAfter(Instant.now());
    }

    /** [start, end] 안에 target 이 포함되는지 (양 끝 포함). */
    public static boolean isBetween(Instant target, Instant start, Instant end) {
        if (target == null || start == null || end == null) {
            return false;
        }
        return !target.isBefore(start) && !target.isAfter(end);
    }

    /** age 계산 — birth ~ now (zone 기준 LocalDate Period). */
    public static int yearsBetween(Instant start, Instant end, ZoneId zone) {
        if (start == null || end == null) {
            return 0;
        }
        LocalDate s = start.atZone(zone).toLocalDate();
        LocalDate e = end.atZone(zone).toLocalDate();
        return Period.between(s, e).getYears();
    }
}
