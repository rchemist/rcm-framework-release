/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.util.regex.Pattern;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Password 강도 / 생성 helper — *encode 는 spring-security 의 PasswordEncoder 영역* (BCrypt / Argon2 등).
 * 본 util 은 *정책 검증* + *임시 비밀번호 생성* 만.
 *
 * <p>강도 정책 baseline (NIST SP 800-63B 정합):
 * <ul>
 *   <li>최소 길이 8</li>
 *   <li>최대 길이 64 (이상은 인증 시 hash 비용 폭증)</li>
 *   <li>대소문자 / 숫자 / 특수문자 4 카테고리 중 *기본 3 종* 이상</li>
 * </ul>
 **/
public final class PasswordUtil {

    public static final int MIN_LENGTH = 8;
    public static final int MAX_LENGTH = 64;

    private static final Pattern HAS_LOWER = Pattern.compile(".*[a-z].*");
    private static final Pattern HAS_UPPER = Pattern.compile(".*[A-Z].*");
    private static final Pattern HAS_DIGIT = Pattern.compile(".*\\d.*");
    private static final Pattern HAS_SPECIAL = Pattern.compile(".*[^a-zA-Z0-9].*");

    private static final char[] LOWER = "abcdefghijklmnopqrstuvwxyz".toCharArray();
    private static final char[] UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    private static final char[] DIGITS = "0123456789".toCharArray();
    private static final char[] SPECIAL = "!@#$%^&*-_=+?".toCharArray();

    private PasswordUtil() { }

    /** 강도 판정 — 0~4 (충족된 카테고리 수). */
    public static int categoryCount(String password) {
        if (password == null) {
            return 0;
        }
        int n = 0;
        if (HAS_LOWER.matcher(password).matches()) {
            n++;
        }
        if (HAS_UPPER.matcher(password).matches()) {
            n++;
        }
        if (HAS_DIGIT.matcher(password).matches()) {
            n++;
        }
        if (HAS_SPECIAL.matcher(password).matches()) {
            n++;
        }
        return n;
    }

    /** baseline 정책 검증 — length 8..64 + 카테고리 3 이상. */
    public static boolean isStrongEnough(String password) {
        return isStrongEnough(password, MIN_LENGTH, 3);
    }

    public static boolean isStrongEnough(String password, int minLength, int minCategories) {
        if (password == null || password.length() < minLength || password.length() > MAX_LENGTH) {
            return false;
        }
        return categoryCount(password) >= minCategories;
    }

    /** 임시 비밀번호 생성 — 4 카테고리 균등 + secure random. */
    public static String generate(int length) {
        if (length < 4) {
            throw new IllegalArgumentException("length >= 4 (4 카테고리 보장)");
        }
        StringBuilder sb = new StringBuilder(length);
        // 카테고리 1 종씩 강제
        sb.append(LOWER[RandomUtil.nextInt(LOWER.length)]);
        sb.append(UPPER[RandomUtil.nextInt(UPPER.length)]);
        sb.append(DIGITS[RandomUtil.nextInt(DIGITS.length)]);
        sb.append(SPECIAL[RandomUtil.nextInt(SPECIAL.length)]);
        // 나머지 채움 (alphanumeric secure)
        int remain = length - 4;
        if (remain > 0) {
            sb.append(RandomUtil.secureAlphanumeric(remain));
        }
        // shuffle
        return shuffle(sb.toString());
    }

    private static String shuffle(String s) {
        char[] a = s.toCharArray();
        for (int i = a.length - 1; i > 0; i--) {
            int j = RandomUtil.nextInt(i + 1);
            char t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
        return new String(a);
    }
}
