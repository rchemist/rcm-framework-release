/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.util;

import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Object null-safe 보조 — getter chain / Optional 의 verbose 회피.
 **/
public final class ObjectUtil {

    private ObjectUtil() { }

    /** value 가 null 이면 default. */
    public static <T> T defaultIfNull(T value, T defaultValue) {
        return value == null ? defaultValue : value;
    }

    /** value 가 null 이면 supplier. */
    public static <T> T defaultIfNull(T value, Supplier<T> defaultSupplier) {
        return value == null ? defaultSupplier.get() : value;
    }

    /** 첫 non-null 반환 (Coalesce — SQL NULLIF 비스무리). */
    @SafeVarargs
    public static <T> T firstNonNull(T... values) {
        if (values == null) {
            return null;
        }
        for (T v : values) {
            if (v != null) {
                return v;
            }
        }
        return null;
    }

    /** source 가 null 이면 null, 아니면 mapper 결과. */
    public static <S, T> T mapIfNotNull(S source, Function<S, T> mapper) {
        return source == null ? null : mapper.apply(source);
    }

    /** 2 단계 chained mapping — null 안전. */
    public static <S, M, T> T mapIfNotNull(S source, Function<S, M> mid, Function<M, T> mapper) {
        if (source == null) {
            return null;
        }
        M m = mid.apply(source);
        return m == null ? null : mapper.apply(m);
    }

    /** 모든 인자 non-null 인지. */
    public static boolean allNonNull(Object... values) {
        if (values == null) {
            return false;
        }
        for (Object v : values) {
            if (v == null) {
                return false;
            }
        }
        return true;
    }

    /** 하나라도 null 인지. */
    public static boolean anyNull(Object... values) {
        if (values == null) {
            return true;
        }
        for (Object v : values) {
            if (v == null) {
                return true;
            }
        }
        return false;
    }

    /** {@link Objects#equals} 의 null-safe deep equals (배열 / collection 까지 — 단 reference 영역만). */
    public static boolean equals(Object a, Object b) {
        return Objects.equals(a, b);
    }
}
