/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.DeepCopy;
import io.rchemist.common.persistence.domain.template.presentation.HasAvailableDateTime;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasUserName;
import io.rchemist.common.persistence.domain.template.presentation.HasUserUUId;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class TodoUpdateForm implements HasAvailableDateTime<TodoUpdateForm>, HasContents<TodoUpdateForm>, HasTags<TodoUpdateForm>, HasUserUUId<TodoUpdateForm>, HasUserName<TodoUpdateForm>, HasId<TodoUpdateForm>, UpdateFormWrapper<TodoUpdateForm, Long>, DeepCopy<TodoUpdateForm> {

  @Serial
  private static final long serialVersionUID = 1L;



  protected Boolean done;

  protected Boolean important;

  protected String priority;


  public TodoUpdateForm withDone(Boolean done) {
    this.done = done;
    return this;
  }

  public TodoUpdateForm withImportant(Boolean important) {
    this.important = important;
    return this;
  }

  public TodoUpdateForm withPriorityId(String priority) {
    this.priority = priority;
    return this;
  }



  // TODO 필요한 필드가 있다면 추가하세요.

  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }
  public void validate() throws ErrorTypeException {
    // TODO: 필요한 validation을 추가하세요.
  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    TodoUpdateForm that = (TodoUpdateForm) o;
  
    return new EqualsBuilder()
      .append(getId(), that.getId())
      .append(getAvailableAt(), that.getAvailableAt())
      .append(getAvailableUntil(), that.getAvailableUntil())
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getTags(), that.getTags())
      .append(getUserId(), that.getUserId())
      .append(getUserName(), that.getUserName())
      .append(getDone(), that.getDone())
      .append(getImportant(), that.getImportant())
      .append(getPriority(), that.getPriority())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getAvailableAt())
      .append(getAvailableUntil())
      .append(getTitle())
      .append(getContent())
      .append(getTags())
      .append(getUserId())
      .append(getUserName())
      .append(getDone())
      .append(getImportant())
      .append(getPriority())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("availableAt", getAvailableAt())
      .append("availableUntil", getAvailableUntil())
      .append("title", getTitle())
      .append("content", getContent())
      .append("tags", getTags())
      .append("userId", getUserId())
      .append("userName", getUserName())
      .append("done", getDone())
      .append("important", getImportant())
      .append("priority", getPriority())
      .toString();
  }

  @Override
  public TodoUpdateForm deepCopy(boolean includeId, boolean includeSubEntities) {
    TodoUpdateForm clone = new TodoUpdateForm();
    clone.setId(includeId ? this.getId() : null);
    clone.setAvailableAt(getAvailableAt());
    clone.setAvailableUntil(getAvailableUntil());
    clone.setTitle(getTitle());
    clone.setContent(getContent());
    clone.setTags(getTags());
    clone.setUserId(getUserId());
    clone.setUserName(getUserName());
    clone.setDone(getDone());
    clone.setImportant(getImportant());
    clone.setPriority(getPriority());
    return clone;
  }
}