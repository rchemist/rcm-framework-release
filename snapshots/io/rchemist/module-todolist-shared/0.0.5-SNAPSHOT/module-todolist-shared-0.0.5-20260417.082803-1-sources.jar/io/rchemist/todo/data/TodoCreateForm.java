/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.data;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.DeepCopy;
import io.rchemist.common.persistence.domain.template.presentation.HasAvailableDateTime;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasUserName;
import io.rchemist.common.persistence.domain.template.presentation.HasUserUUId;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.todo.service.exception.TodoServiceErrorType;
import io.rchemist.todo.service.exception.TodoServiceException;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class TodoCreateForm implements HasAvailableDateTime<TodoCreateForm>, HasContents<TodoCreateForm>, HasTags<TodoCreateForm>, HasUserUUId<TodoCreateForm>, HasUserName<TodoCreateForm>, DeepCopy<TodoCreateForm>, CreateFormWrapper<TodoCreateForm> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Boolean done;

  protected Boolean important;

  protected String priority;


  public TodoCreateForm withDone(Boolean done) {
    this.done = done;
    return this;
  }

  public TodoCreateForm withImportant(Boolean important) {
    this.important = important;
    return this;
  }

  public TodoCreateForm withPriorityId(String priorityId) {
    this.priority = priority;
    return this;
  }



  public boolean isValid() {
    try {
      validate();
      return true;
    } catch (Exception e) {
      return false;
    }
  }
  public void validate() throws ErrorTypeException {

    if (StringUtils.isEmpty(getTitle()))
      throw new TodoServiceException(TodoServiceErrorType.REQUIRED_TITLE);
    if (StringUtils.isEmpty(getContent()))
      throw new TodoServiceException(TodoServiceErrorType.REQUIRED_CONTENT);

  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    TodoCreateForm that = (TodoCreateForm) o;
  
    return new EqualsBuilder()
      .append(getAvailableAt(), that.getAvailableAt())
      .append(getAvailableUntil(), that.getAvailableUntil())
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getTags(), that.getTags())
      .append(getUserId(), that.getUserId())
      .append(getUserName(), that.getUserName())
      .append(getDone(), that.getDone())
      .append(getImportant(), that.getImportant())
      .append(getPriority(), that.getPriority())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getAvailableAt())
      .append(getAvailableUntil())
      .append(getTitle())
      .append(getContent())
      .append(getTags())
      .append(getUserId())
      .append(getUserName())
      .append(getDone())
      .append(getImportant())
      .append(getPriority())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("availableAt", getAvailableAt())
      .append("availableUntil", getAvailableUntil())
      .append("title", getTitle())
      .append("content", getContent())
      .append("tags", getTags())
      .append("userId", getUserId())
      .append("userName", getUserName())
      .append("done", getDone())
      .append("important", getImportant())
      .append("priority", getPriority())
      .toString();
  }

  @Override
  public TodoCreateForm deepCopy(boolean includeId, boolean includeSubEntities) {
    TodoCreateForm clone = new TodoCreateForm();
    clone.setAvailableAt(getAvailableAt());
    clone.setAvailableUntil(getAvailableUntil());
    clone.setTitle(getTitle());
    clone.setContent(getContent());
    clone.setTags(getTags());
    clone.setUserId(getUserId());
    clone.setUserName(getUserName());
    clone.setDone(getDone());
    clone.setImportant(getImportant());
    clone.setPriority(getPriority());
    return clone;
  }
}