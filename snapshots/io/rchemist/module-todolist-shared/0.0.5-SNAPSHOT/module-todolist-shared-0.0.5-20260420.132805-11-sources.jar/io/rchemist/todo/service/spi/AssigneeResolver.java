/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

/**
 * <p>Service Provider Interface allowing Consumers to decide who a todo entity is
 * assigned to at creation / update time, independent of what the request form says.
 *
 * <p>Typical Consumer strategies:
 * <ul>
 *   <li>Use the currently authenticated user as assignee if form is empty.</li>
 *   <li>Round-robin across a team when the form specifies a role instead of a user.</li>
 *   <li>Workload-aware routing.</li>
 *   <li>Pass-through — just honor whatever the form says (this is the framework default).</li>
 * </ul>
 *
 * <p>The default implementation {@code DefaultAssigneeResolver} is pass-through: it simply
 * returns the form's userId/userName unchanged. Consumers override by registering a Spring
 * bean of this type.
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
public interface AssigneeResolver {

  /**
   * Snapshot of a resolved assignee. Immutable data carrier.
   */
  final class Assignee {
    private final String userId;
    private final String userName;

    public Assignee(String userId, String userName) {
      this.userId = userId;
      this.userName = userName;
    }

    public String getUserId() {
      return userId;
    }

    public String getUserName() {
      return userName;
    }

    public static Assignee of(String userId, String userName) {
      return new Assignee(userId, userName);
    }
  }

  /**
   * @param requestedUserId   user id from the form (nullable)
   * @param requestedUserName user name from the form (nullable)
   * @return resolved assignee. Never null, but individual fields may be null.
   */
  Assignee resolve(String requestedUserId, String requestedUserName);
}
