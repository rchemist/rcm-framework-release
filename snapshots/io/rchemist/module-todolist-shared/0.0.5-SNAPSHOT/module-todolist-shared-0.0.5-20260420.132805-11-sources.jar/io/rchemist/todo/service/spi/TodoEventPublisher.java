/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

import io.rchemist.todo.service.event.TodoLifecycleEvent;

/**
 * <p>Service Provider Interface used by {@code TodoService} to announce lifecycle events.
 *
 * <p>The framework's default implementation {@code ApplicationEventTodoEventPublisher} simply
 * hands each event to Spring's {@code ApplicationEventPublisher}. Consumers that want to
 * bridge to a notification module, a message queue, or an audit log can register a custom
 * bean of this type and replace the default.
 *
 * <p>A no-op variant ({@code NoOpTodoEventPublisher}) is used when event publishing is
 * explicitly disabled via {@code platform.todolist.events.enabled=false}.
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
public interface TodoEventPublisher {

  /**
   * Publish a lifecycle event. Implementations must be non-throwing — todo CRUD must not fail
   * because a downstream subscriber broke.
   */
  void publish(TodoLifecycleEvent event);
}
