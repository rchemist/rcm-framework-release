/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>Generic todo state enum. Consumers extend this class and define their own constants
 * to model domain-specific workflows (e.g. {@code IN_REVIEW}, {@code BLOCKED}, {@code ARCHIVED}).
 *
 * <p>Two built-in constants — {@link #OPEN} and {@link #DONE} — are supplied as the minimal
 * default (the framework's {@code DefaultTodoStateMachine} only knows how to transition
 * {@code OPEN -> DONE}). Consumer-defined states work via the {@code TodoStateMachine} SPI.
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
public class TodoState extends EnumType<TodoState> {

  public static final TodoState OPEN = new TodoState(1, "OPEN", "Open");
  public static final TodoState DONE = new TodoState(2, "DONE", "Done");

  public TodoState(int order, String type, String friendlyType) {
    super(order, type, friendlyType);
  }
}
