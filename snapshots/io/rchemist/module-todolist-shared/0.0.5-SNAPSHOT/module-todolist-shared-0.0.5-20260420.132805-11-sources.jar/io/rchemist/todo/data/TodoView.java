/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.data;

import io.rchemist.common.persistence.domain.template.DeepCopy;
import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditCreated;
import io.rchemist.common.persistence.domain.template.presentation.HasAuditUpdated;
import io.rchemist.common.persistence.domain.template.presentation.HasAvailableDateTime;
import io.rchemist.common.persistence.domain.template.presentation.HasContents;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasUserName;
import io.rchemist.common.persistence.domain.template.presentation.HasUserUUId;
import io.rchemist.todo.service.type.TodoPriorityType;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * </p>
 * Created by kunner
 **/

@Getter
@Setter
public class TodoView implements HasAvailableDateTime<TodoView>, HasContents<TodoView>, HasAuditCreated<TodoView>, HasAuditUpdated<TodoView>, HasActive<TodoView>, HasTags<TodoView>, HasUserUUId<TodoView>, HasUserName<TodoView>, HasId<TodoView>, DeepCopy<TodoView> {

  @Serial
  private static final long serialVersionUID = 1L;

  protected Long id;

  protected Boolean done;

  protected Boolean important;

  protected TodoPriorityType priority;

  /**
   * Raw state string as stored on the entity. Resolved to a {@code TodoState} subclass via
   * the Consumer's own lookup if a custom state type is in use.
   */
  protected String state;


  public TodoView withDone(Boolean done) {
    this.done = done;
    return this;
  }

  public TodoView withImportant(Boolean important) {
    this.important = important;
    return this;
  }

  public TodoView withPriority(TodoPriorityType priority) {
    this.priority = priority;
    return this;
  }

  public TodoView withState(String state) {
    this.state = state;
    return this;
  }



  // TODO 필요한 필드가 있다면 추가하세요.


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    TodoView that = (TodoView) o;
  
    return new EqualsBuilder()
      .append(getId(), that.getId())
      .append(getAvailableAt(), that.getAvailableAt())
      .append(getAvailableUntil(), that.getAvailableUntil())
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getUpdatedAt(), that.getUpdatedAt())
      .append(getActive(), that.getActive())
      .append(getTags(), that.getTags())
      .append(getUserId(), that.getUserId())
      .append(getUserName(), that.getUserName())
      .append(getDone(), that.getDone())
      .append(getImportant(), that.getImportant())
      .append(getPriority(), that.getPriority())
      .append(getState(), that.getState())
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getAvailableAt())
      .append(getAvailableUntil())
      .append(getTitle())
      .append(getContent())
      .append(getCreatedAt())
      .append(getUpdatedAt())
      .append(getActive())
      .append(getTags())
      .append(getUserId())
      .append(getUserName())
      .append(getDone())
      .append(getImportant())
      .append(getPriority())
      .append(getState())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("availableAt", getAvailableAt())
      .append("availableUntil", getAvailableUntil())
      .append("title", getTitle())
      .append("content", getContent())
      .append("createdAt", getCreatedAt())
      .append("updatedAt", getUpdatedAt())
      .append("active", getActive())
      .append("tags", getTags())
      .append("userId", getUserId())
      .append("userName", getUserName())
      .append("done", getDone())
      .append("important", getImportant())
      .append("priority", getPriority())
      .append("state", getState())
      .toString();
  }

  @Override
  public TodoView deepCopy(boolean includeId, boolean includeSubEntities) {
    TodoView clone = new TodoView();
    clone.setId(includeId ? this.getId() : null);
    clone.setAvailableAt(getAvailableAt());
    clone.setAvailableUntil(getAvailableUntil());
    clone.setTitle(getTitle());
    clone.setContent(getContent());
    clone.setCreatedAt(getCreatedAt());
    clone.setUpdatedAt(getUpdatedAt());
    clone.setActive(getActive());
    clone.setTags(getTags());
    clone.setUserId(getUserId());
    clone.setUserName(getUserName());
    clone.setDone(getDone());
    clone.setImportant(getImportant());
    clone.setPriority(getPriority());
    clone.setState(getState());
    return clone;
  }
}