/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

import io.rchemist.todo.service.type.TodoState;
import java.util.Set;

/**
 * <p>Service Provider Interface that a Consumer implements (and registers as a Spring bean)
 * to define the legal state transitions of its domain-specific todo workflow.
 *
 * <p>Method semantics:
 * <ul>
 *   <li>{@link #initialState()} — state applied when an entity is created (create form didn't
 *       specify anything).</li>
 *   <li>{@link #isTerminal(TodoState)} — whether further transitions are allowed from the
 *       given state. Used by helpers such as {@code isDone(entity)} to treat non-{@code DONE}
 *       terminal states as "completed" in Consumer domains.</li>
 *   <li>{@link #canTransition(TodoState, TodoState)} — guards {@code TodoService#transitionTo}
 *       and {@code processDone}. Returning {@code false} raises
 *       {@code TodoServiceException(INVALID_STATE_TRANSITION)}.</li>
 *   <li>{@link #allStates()} — optional inventory of every state the SPI accepts. Default
 *       returns {@code null}, meaning "open domain — trust the caller's custom TodoState
 *       subclass registration".</li>
 * </ul>
 *
 * <p>The default implementation supplied by module-todolist is {@code DefaultTodoStateMachine},
 * which only permits {@code OPEN -> DONE}. Consumers override by registering a Spring bean of
 * this type (the framework picks it up via dependency injection, same pattern as other SPIs).
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
public interface TodoStateMachine {

  /**
   * @return state assigned to a freshly-created entity when the create form does not specify
   *         one explicitly. Must never be {@code null}.
   */
  TodoState initialState();

  /**
   * @return true if the given state is terminal — no further transitions allowed.
   */
  boolean isTerminal(TodoState state);

  /**
   * @param from current state (nullable only if transitioning from "uninitialized")
   * @param to   target state (never null)
   * @return true if the transition is permitted under this state machine's rules.
   */
  boolean canTransition(TodoState from, TodoState to);

  /**
   * @return all states the machine knows about, or {@code null} if the machine operates on
   *         an open domain. Default implementation returns {@code null}.
   */
  default Set<TodoState> allStates() {
    return null;
  }
}
