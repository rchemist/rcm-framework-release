/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;


/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * </p>
 * Created by kunner
 **/
public class TodoServiceErrorType extends EnumType<TodoServiceErrorType> implements ErrorType {

  public static final TodoServiceErrorType NOT_FOUND = new TodoServiceErrorType("NOT_FOUND", "Not Found", HttpStatus.NOT_FOUND);

  public static final TodoServiceErrorType REQUIRED_TITLE = new TodoServiceErrorType("REQUIRED_TITLE", "제목을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType REQUIRED_CONTENT = new TodoServiceErrorType("REQUIRED_CONTENT", "내용을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType NOT_FOUND_ID = new TodoServiceErrorType("NOT_FOUND_ID", "해당 아이디로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType REQUIRED_ID = new TodoServiceErrorType("REQUIRED_ID", "아이디을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType DUPLICATED_USERID = new TodoServiceErrorType("DUPLICATED_USERID", "이미 등록된 User ID 입니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType NOT_FOUND_USERID = new TodoServiceErrorType("NOT_FOUND_USERID", "해당 User ID로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType REQUIRED_USERID = new TodoServiceErrorType("REQUIRED_USERID", "User ID을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType DUPLICATED_USERNAME = new TodoServiceErrorType("DUPLICATED_USERNAME", "이미 등록된 User Name 입니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType NOT_FOUND_USERNAME = new TodoServiceErrorType("NOT_FOUND_USERNAME", "해당 User Name로 등록된 정보가 없습니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType REQUIRED_USERNAME = new TodoServiceErrorType("REQUIRED_USERNAME", "User Name을(를) 입력해야 합니다", HttpStatus.BAD_REQUEST);
  public static final TodoServiceErrorType REQUIRED_AUTHENTICATION = new TodoServiceErrorType("REQUIRED_AUTHENTICATION", "이 서비스를 이용하려면 먼저 로그인해야 합니다", HttpStatus.UNAUTHORIZED);

  public static final TodoServiceErrorType INVALID_STATE_TRANSITION = new TodoServiceErrorType("INVALID_STATE_TRANSITION", "허용되지 않은 상태 전이입니다", HttpStatus.BAD_REQUEST);

  public static final TodoServiceErrorType UNKNOWN_STATE = new TodoServiceErrorType("UNKNOWN_STATE", "알 수 없는 상태 값입니다", HttpStatus.BAD_REQUEST);

  // TODO: 필요한 에러 타입을 추가하세요.

  public TodoServiceErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }

  @Getter
  private final int status;

}