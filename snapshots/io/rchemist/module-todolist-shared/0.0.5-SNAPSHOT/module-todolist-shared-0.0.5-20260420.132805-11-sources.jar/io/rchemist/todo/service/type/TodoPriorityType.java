/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * project : showfl
 * <p>
 * Created by kunner
 **/
public class TodoPriorityType extends EnumType<TodoPriorityType> {

  public static final TodoPriorityType LOW = new TodoPriorityType(1, "LOW", "Low");
  public static final TodoPriorityType MEDIUM = new TodoPriorityType(2, "MEDIUM", "Medium");
  public static final TodoPriorityType HIGH = new TodoPriorityType(3, "HIGH", "High");


  public TodoPriorityType(int order, String type, String friendlyType) {
    super(order, type, friendlyType);
  }
}
