/**
 * <p>module-todolist-shared — DTO / SPI surface of the generic task-tracking infrastructure.
 *
 * <p>Since 0.1.0 M5 (DEC-017), the shared module exposes:
 * <ul>
 *   <li>DTOs: {@code TodoCreateForm}, {@code TodoUpdateForm}, {@code TodoView} — all carry
 *       an optional {@code state} field in addition to the legacy {@code done} boolean.</li>
 *   <li>{@code TodoState} — generic state enum (EnumType). Built-ins: {@code OPEN},
 *       {@code DONE}. Consumers extend by subclassing and declaring their own constants.</li>
 *   <li>SPI interfaces (in {@code service.spi}): {@code TodoStateMachine},
 *       {@code AssigneeResolver}, {@code TodoEventPublisher}.</li>
 *   <li>Event model (in {@code service.event}): {@code TodoLifecycleEvent},
 *       {@code TodoLifecycleEventType}.</li>
 * </ul>
 *
 * <p>The {@code module-notification-shared} dependency present in 0.0.x has been removed —
 * notification / workflow integration is now a Consumer-side {@code @EventListener}
 * concern and requires no compile-time coupling.
 *
 * <p>Detail: {@code documents/refactor/15e-0.1.0-m5-todolist-generalization.md}.
 */
package io.rchemist.todo;
