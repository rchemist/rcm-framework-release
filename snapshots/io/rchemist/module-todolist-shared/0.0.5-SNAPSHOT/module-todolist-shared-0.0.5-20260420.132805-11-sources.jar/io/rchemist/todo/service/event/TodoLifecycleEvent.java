/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.event;

import io.rchemist.todo.service.type.TodoState;
import java.time.Instant;

/**
 * <p>Immutable event describing a lifecycle change of a todo entity.
 *
 * <p>The event intentionally does not carry the entity itself so it stays decoupled from any
 * specific {@code Todo} subclass. Consumers that need more detail can fetch the entity by id.
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
public final class TodoLifecycleEvent {

  private final TodoLifecycleEventType type;
  private final Long todoId;
  private final String assigneeUserId;
  private final TodoState previousState;
  private final TodoState currentState;
  private final Instant occurredAt;

  public TodoLifecycleEvent(TodoLifecycleEventType type, Long todoId, String assigneeUserId,
                            TodoState previousState, TodoState currentState, Instant occurredAt) {
    this.type = type;
    this.todoId = todoId;
    this.assigneeUserId = assigneeUserId;
    this.previousState = previousState;
    this.currentState = currentState;
    this.occurredAt = occurredAt != null ? occurredAt : Instant.now();
  }

  public TodoLifecycleEventType getType() {
    return type;
  }

  public Long getTodoId() {
    return todoId;
  }

  public String getAssigneeUserId() {
    return assigneeUserId;
  }

  public TodoState getPreviousState() {
    return previousState;
  }

  public TodoState getCurrentState() {
    return currentState;
  }

  public Instant getOccurredAt() {
    return occurredAt;
  }
}
