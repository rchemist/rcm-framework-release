/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.async;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.asset.variant.AssetVariantPipeline;
import io.rchemist.starter.jpa.async.AsyncJob;
import io.rchemist.starter.jpa.async.AsyncJobTracker;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.quota.ScanResult;
import io.rchemist.starter.storage.quota.VirusScanProvider;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A9) — Async post-processing — virus scan + variant 결합 job.
 * AsyncJobTracker 가 진행률 / 실패 재처리 지원.
 *
 * <p>job 흐름 (총 100% progress):
 * <ol>
 *   <li>register + start (0%).</li>
 *   <li>storage.open(key) — virus scan (50%).</li>
 *   <li>virus scan 결과 ACTIVE / QUARANTINED 전이 + scanResult 기록.</li>
 *   <li>(QUARANTINED 가 아니면) variant pipeline 호출 (90%).</li>
 *   <li>complete (100%).</li>
 * </ol>
 *
 * <p>JDK 25 VirtualThread 친화 — default Executor 가 newVirtualThreadPerTaskExecutor.
 **/
public class AssetPostProcessor {

  private static final Logger LOG = LoggerFactory.getLogger(AssetPostProcessor.class);
  private static final String JOB_TYPE = "asset-post-process";

  private final AssetRepository repository;
  private final Storage storage;
  private final VirusScanProvider scanProvider;
  private final AssetVariantPipeline variantPipeline;
  private final AsyncJobTracker tracker;
  private final Executor executor;

  public AssetPostProcessor(
      AssetRepository repository,
      Storage storage,
      VirusScanProvider scanProvider,
      AssetVariantPipeline variantPipeline,
      AsyncJobTracker tracker) {
    this(repository, storage, scanProvider, variantPipeline, tracker,
        Executors.newVirtualThreadPerTaskExecutor());
  }

  public AssetPostProcessor(
      AssetRepository repository,
      Storage storage,
      VirusScanProvider scanProvider,
      AssetVariantPipeline variantPipeline,
      AsyncJobTracker tracker,
      Executor executor) {
    if (repository == null) {
      throw new IllegalArgumentException("repository must not be null");
    }
    if (storage == null) {
      throw new IllegalArgumentException("storage must not be null");
    }
    if (tracker == null) {
      throw new IllegalArgumentException("tracker must not be null");
    }
    if (executor == null) {
      throw new IllegalArgumentException("executor must not be null");
    }
    this.repository = repository;
    this.storage = storage;
    this.scanProvider = scanProvider;
    this.variantPipeline = variantPipeline;
    this.tracker = tracker;
    this.executor = executor;
  }

  /** Asset post-process job 등록 + dispatch. 즉시 AsyncJob (QUEUED) 반환. */
  public AsyncJob enqueue(Long assetId) {
    if (assetId == null) {
      throw new IllegalArgumentException("assetId must not be null");
    }
    String jobId = UUID.randomUUID().toString();
    AsyncJob job = tracker.register(jobId, JOB_TYPE);
    executor.execute(() -> run(jobId, assetId));
    return job;
  }

  /** Visible for tests — same-thread 실행. */
  void run(String jobId, Long assetId) {
    try {
      tracker.start(jobId);
      Asset asset = repository.findById(assetId).orElse(null);
      if (asset == null) {
        tracker.fail(jobId, "asset not found: " + assetId);
        return;
      }
      // Virus scan.
      if (scanProvider != null) {
        asset.setStatus(AssetStatus.SCANNING);
        repository.save(asset);
        try (InputStream in = storage.open(asset.getKey())) {
          ScanResult result = scanProvider.scan(in);
          if (!result.isClean()) {
            asset.setStatus(AssetStatus.QUARANTINED);
            asset.setScanResult("infected:" + String.join(",", result.threats()));
            repository.save(asset);
            tracker.complete(jobId);
            return;
          }
          asset.setScanResult("clean");
          asset.setStatus(AssetStatus.ACTIVE);
          repository.save(asset);
        } catch (IOException e) {
          LOG.warn("virus scan I/O failed (assetId={}): {}", assetId, e.getMessage());
          tracker.fail(jobId, "scan I/O: " + e.getMessage());
          return;
        }
        tracker.updateProgress(jobId, 50);
      }
      // Variant pipeline (image only).
      if (variantPipeline != null
          && asset.getContentType() != null
          && asset.getContentType().toLowerCase().startsWith("image/")) {
        try (InputStream in = storage.open(asset.getKey())) {
          byte[] bytes = in.readAllBytes();
          variantPipeline.process(storage, asset, bytes, asset.getContentType());
          repository.save(asset);
        } catch (Exception e) {
          LOG.warn("variant pipeline failed (assetId={}): {}", assetId, e.getMessage());
          // variant 실패 = job 자체 실패 X (Asset 은 ACTIVE 유지).
        }
        tracker.updateProgress(jobId, 90);
      }
      tracker.complete(jobId);
    } catch (RuntimeException e) {
      LOG.warn("post-process job failed (jobId={}, assetId={}): {}", jobId, assetId, e.getMessage());
      try {
        tracker.fail(jobId, e.getMessage());
      } catch (RuntimeException ignored) {
        // tracker mutate 충돌 무시.
      }
    }
  }
}
