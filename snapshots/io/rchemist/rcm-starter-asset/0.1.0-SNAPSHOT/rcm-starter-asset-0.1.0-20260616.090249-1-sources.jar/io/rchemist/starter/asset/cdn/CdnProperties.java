/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — CDN provider 공용 설정. baseUrl + signed URL 옵션.
 *
 * <p>provider 별 baseUrl 패턴:
 * <ul>
 *   <li>CloudFront — "https://d1xxxxxxxx.cloudfront.net"</li>
 *   <li>Cloudflare — "https://cdn.example.com" (Cloudflare CDN 또는 R2 public URL)</li>
 *   <li>Noop — null (Storage direct URL fallback).</li>
 * </ul>
 **/
public record CdnProperties(String baseUrl, boolean signedUrl, long signTtlSeconds) {

  public CdnProperties {
    if (signTtlSeconds < 0) {
      throw new IllegalArgumentException("signTtlSeconds must be non-negative");
    }
  }

  public static CdnProperties noop() {
    return new CdnProperties(null, false, 0L);
  }

  public static CdnProperties of(String baseUrl) {
    return new CdnProperties(baseUrl, false, 0L);
  }
}
