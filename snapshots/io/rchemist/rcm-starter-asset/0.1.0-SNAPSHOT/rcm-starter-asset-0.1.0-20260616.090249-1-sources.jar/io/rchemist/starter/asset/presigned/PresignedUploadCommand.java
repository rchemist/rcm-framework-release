/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.presigned;

import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A6) — Presigned URL 요청 입력. browser direct upload 시작 시점.
 **/
public record PresignedUploadCommand(
    String contentType,
    String originalName,
    long sizeHint,
    String ownerType,
    Object ownerId,
    Map<String, Object> extraMetadata) {

  public PresignedUploadCommand {
    if (sizeHint < 0) {
      throw new IllegalArgumentException("sizeHint must not be negative");
    }
  }

  public static PresignedUploadCommand pending(String contentType, String originalName, long sizeHint) {
    return new PresignedUploadCommand(contentType, originalName, sizeHint, null, null, null);
  }
}
