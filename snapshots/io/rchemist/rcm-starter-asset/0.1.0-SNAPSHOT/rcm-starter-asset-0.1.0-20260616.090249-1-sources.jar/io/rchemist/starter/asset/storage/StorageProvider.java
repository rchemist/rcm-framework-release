/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.storage;

import io.rchemist.starter.storage.core.Storage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — Storage provider SPI. ServiceLoader 등록 → AssetAutoConfig
 * 가 platform.asset.storage.provider yml key 로 선택.
 *
 * <p>설계 원칙 (사용자 명시 2026-05-04 준수):
 * <ul>
 *   <li>"S3 구현체는 provider 패턴으로 계속 추가하거나 선택적으로 적용. 작은 = R2, 큰 = AWS S3
 *       또는 MinIO" — baseline 3종 1st-party (AWS / R2 / MinIO) + 추가 provider = 같은 SPI 로
 *       신규 jar.</li>
 *   <li>단일 환경 hard-code = SI 다양 환경 대응 X. 영구 거부.</li>
 * </ul>
 **/
public interface StorageProvider {

  /** Provider 식별 이름 (yml key 와 매칭. 예: aws / r2 / minio). */
  String name();

  /** 본 provider 가 주어진 name 을 지원하는가 (case-insensitive). default impl = name() 비교. */
  default boolean supports(String providerName) {
    return providerName != null && providerName.equalsIgnoreCase(name());
  }

  /** 주어진 config 로 Storage 인스턴스 생성. SDK 미입주 시 ProviderUnavailableException. */
  Storage create(StorageProviderConfig config);
}
