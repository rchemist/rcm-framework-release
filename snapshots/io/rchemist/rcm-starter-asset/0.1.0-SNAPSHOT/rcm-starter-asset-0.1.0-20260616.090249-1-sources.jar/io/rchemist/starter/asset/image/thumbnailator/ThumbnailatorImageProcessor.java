/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.thumbnailator;

import io.rchemist.starter.asset.image.autoconfig.ImageProperties;
import io.rchemist.starter.asset.image.core.ImageFit;
import io.rchemist.starter.asset.image.core.ImageFormat;
import io.rchemist.starter.asset.image.core.ImageProcessor;
import io.rchemist.starter.asset.image.core.ImageVariant;
import io.rchemist.starter.asset.image.core.ProcessedImage;
import io.rchemist.starter.asset.image.core.exception.ImageProcessingException;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import net.coobird.thumbnailator.Thumbnails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — Default {@link ImageProcessor} impl. Thumbnailator 0.4.21 + JDK
 * ImageIO 기반. WebP / EXIF 의존이 classpath 에 없을 때 graceful fallback (명확 exception 또는 no-op).
 *
 * <ul>
 *   <li>resize — Thumbnailator 의 size() + crop / contain / fit 적용. format convert 결합 가능.</li>
 *   <li>crop — Thumbnailator 의 sourceRegion() 적용.</li>
 *   <li>watermark — Thumbnailator 의 watermark(Position, BufferedImage, opacity) 적용.</li>
 *   <li>convert — outputFormat() 만 적용 (resize 없음).</li>
 *   <li>exifNormalize — metadata-extractor 옵션 의존 reflection lookup. 부재 시 fallback log.</li>
 * </ul>
 */
public class ThumbnailatorImageProcessor implements ImageProcessor {

  private static final Logger LOG = LoggerFactory.getLogger(ThumbnailatorImageProcessor.class);
  private static final String EXIF_READER_CLASS = "com.drew.imaging.ImageMetadataReader";
  private static final String EXIF_DIRECTORY_CLASS = "com.drew.metadata.exif.ExifIFD0Directory";

  private final ImageProperties properties;
  private final boolean exifSupportAvailable;

  public ThumbnailatorImageProcessor(ImageProperties properties) {
    if (properties == null) {
      throw new IllegalArgumentException("properties must not be null");
    }
    this.properties = properties;
    this.exifSupportAvailable = detectExifSupport();
  }

  /** EXIF reader 의존 ({@code metadata-extractor}) 활성 여부. */
  public boolean isExifSupportAvailable() {
    return exifSupportAvailable;
  }

  @Override
  public ProcessedImage resize(InputStream source, ImageVariant variant) {
    if (source == null) {
      throw new IllegalArgumentException("source must not be null");
    }
    if (variant == null) {
      throw new IllegalArgumentException("variant must not be null");
    }
    try (InputStream in = source) {
      BufferedImage img = readImage(in);
      validateSourcePixels(img);
      ImageFormat targetFormat = variant.format() != null ? variant.format() : detectFormatOrDefault(img);
      BufferedImage resized = applyFit(img, variant);
      return encode(resized, targetFormat, variant.quality());
    } catch (IOException e) {
      throw new ImageProcessingException("resize failed: " + e.getMessage(), e);
    }
  }

  @Override
  public ProcessedImage crop(
      InputStream source, int x, int y, int width, int height, ImageFormat outputFormat) {
    if (source == null) {
      throw new IllegalArgumentException("source must not be null");
    }
    if (x < 0 || y < 0) {
      throw new IllegalArgumentException("x/y must be non-negative: x=" + x + ", y=" + y);
    }
    if (width <= 0 || height <= 0) {
      throw new IllegalArgumentException(
          "width/height must be positive: w=" + width + ", h=" + height);
    }
    try (InputStream in = source) {
      BufferedImage img = readImage(in);
      validateSourcePixels(img);
      if (x + width > img.getWidth() || y + height > img.getHeight()) {
        throw new ImageProcessingException(
            "crop region exceeds source: srcW="
                + img.getWidth()
                + ", srcH="
                + img.getHeight()
                + ", x="
                + x
                + ", y="
                + y
                + ", w="
                + width
                + ", h="
                + height);
      }
      BufferedImage cropped = img.getSubimage(x, y, width, height);
      // Defensive copy — getSubimage shares pixel data with parent.
      BufferedImage copy = new BufferedImage(width, height, cropped.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : cropped.getType());
      Graphics2D g = copy.createGraphics();
      try {
        g.drawImage(cropped, 0, 0, null);
      } finally {
        g.dispose();
      }
      ImageFormat target = outputFormat != null ? outputFormat : detectFormatOrDefault(img);
      return encode(copy, target, properties.defaultQuality());
    } catch (IOException e) {
      throw new ImageProcessingException("crop failed: " + e.getMessage(), e);
    }
  }

  @Override
  public ProcessedImage watermark(
      InputStream source,
      InputStream watermark,
      double relativeX,
      double relativeY,
      float opacity,
      ImageFormat outputFormat) {
    if (source == null || watermark == null) {
      throw new IllegalArgumentException("source/watermark must not be null");
    }
    if (relativeX < 0 || relativeX > 1 || relativeY < 0 || relativeY > 1) {
      throw new IllegalArgumentException(
          "relativeX/Y must be 0.0~1.0: x=" + relativeX + ", y=" + relativeY);
    }
    if (opacity < 0 || opacity > 1) {
      throw new IllegalArgumentException("opacity must be 0.0~1.0: " + opacity);
    }
    try (InputStream srcIn = source;
        InputStream wmIn = watermark) {
      BufferedImage base = readImage(srcIn);
      validateSourcePixels(base);
      BufferedImage wm = readImage(wmIn);
      int wmX = (int) ((base.getWidth() - wm.getWidth()) * relativeX);
      int wmY = (int) ((base.getHeight() - wm.getHeight()) * relativeY);
      if (wmX < 0) wmX = 0;
      if (wmY < 0) wmY = 0;
      BufferedImage out =
          new BufferedImage(base.getWidth(), base.getHeight(), BufferedImage.TYPE_INT_ARGB);
      Graphics2D g = out.createGraphics();
      try {
        g.drawImage(base, 0, 0, null);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
        g.drawImage(wm, wmX, wmY, null);
      } finally {
        g.dispose();
      }
      ImageFormat target = outputFormat != null ? outputFormat : detectFormatOrDefault(base);
      return encode(out, target, properties.defaultQuality());
    } catch (IOException e) {
      throw new ImageProcessingException("watermark failed: " + e.getMessage(), e);
    }
  }

  @Override
  public ProcessedImage convert(InputStream source, ImageFormat targetFormat, int quality) {
    if (source == null) {
      throw new IllegalArgumentException("source must not be null");
    }
    if (targetFormat == null) {
      throw new IllegalArgumentException("targetFormat must not be null");
    }
    if (quality < 1 || quality > 100) {
      throw new IllegalArgumentException("quality out of range [1,100]: " + quality);
    }
    try (InputStream in = source) {
      BufferedImage img = readImage(in);
      validateSourcePixels(img);
      return encode(img, targetFormat, quality);
    } catch (IOException e) {
      throw new ImageProcessingException("convert failed: " + e.getMessage(), e);
    }
  }

  @Override
  public ProcessedImage exifNormalize(InputStream source, ImageFormat outputFormat) {
    if (source == null) {
      throw new IllegalArgumentException("source must not be null");
    }
    try (InputStream in = source) {
      byte[] bytes = in.readAllBytes();
      int orientation = readExifOrientation(bytes);
      BufferedImage img = readImage(new ByteArrayInputStream(bytes));
      validateSourcePixels(img);
      BufferedImage rotated = applyOrientation(img, orientation);
      ImageFormat target = outputFormat != null ? outputFormat : detectFormatOrDefault(img);
      return encode(rotated, target, properties.defaultQuality());
    } catch (IOException e) {
      throw new ImageProcessingException("exifNormalize failed: " + e.getMessage(), e);
    }
  }

  private void validateSourcePixels(BufferedImage img) {
    long pixels = (long) img.getWidth() * img.getHeight();
    if (pixels > properties.maxSourcePixels()) {
      throw new ImageProcessingException(
          "source exceeds maxSourcePixels: srcPixels="
              + pixels
              + ", limit="
              + properties.maxSourcePixels());
    }
  }

  private BufferedImage readImage(InputStream in) throws IOException {
    BufferedImage img = ImageIO.read(in);
    if (img == null) {
      throw new ImageProcessingException("Unsupported image format (ImageIO returned null)");
    }
    return img;
  }

  private BufferedImage applyFit(BufferedImage img, ImageVariant variant) throws IOException {
    int targetW = variant.width();
    int targetH = variant.height();
    int srcW = img.getWidth();
    int srcH = img.getHeight();
    return switch (variant.fit()) {
      case FILL ->
          Thumbnails.of(img).forceSize(targetW, targetH).asBufferedImage();
      case COVER -> {
        // 종횡비 유지 + crop. Thumbnailator size() + crop(Positions.CENTER) 패턴.
        double scale = Math.max((double) targetW / srcW, (double) targetH / srcH);
        int sw = (int) Math.ceil(srcW * scale);
        int sh = (int) Math.ceil(srcH * scale);
        BufferedImage scaled = Thumbnails.of(img).size(sw, sh).asBufferedImage();
        int x = Math.max(0, (scaled.getWidth() - targetW) / 2);
        int y = Math.max(0, (scaled.getHeight() - targetH) / 2);
        int w = Math.min(targetW, scaled.getWidth() - x);
        int h = Math.min(targetH, scaled.getHeight() - y);
        BufferedImage sub = scaled.getSubimage(x, y, w, h);
        BufferedImage copy = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = copy.createGraphics();
        try {
          g.drawImage(sub, 0, 0, null);
        } finally {
          g.dispose();
        }
        yield copy;
      }
      case CONTAIN -> Thumbnails.of(img).size(targetW, targetH).asBufferedImage();
      case INSIDE -> {
        if (srcW <= targetW && srcH <= targetH) {
          yield img;
        }
        yield Thumbnails.of(img).size(targetW, targetH).asBufferedImage();
      }
      case OUTSIDE -> {
        if (srcW <= targetW && srcH <= targetH) {
          yield img;
        }
        // OUTSIDE = COVER + downscale only.
        yield applyFit(img, new ImageVariant(variant.name(), targetW, targetH, variant.format(), variant.quality(), ImageFit.COVER));
      }
    };
  }

  private ProcessedImage encode(BufferedImage img, ImageFormat format, int quality)
      throws IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    BufferedImage outputImage = img;
    // JPEG 은 alpha channel 미지원 — TYPE_INT_RGB 으로 redraw.
    if (format == ImageFormat.JPEG && img.getColorModel().hasAlpha()) {
      BufferedImage rgb = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
      Graphics2D g = rgb.createGraphics();
      try {
        g.drawImage(img, 0, 0, java.awt.Color.WHITE, null);
      } finally {
        g.dispose();
      }
      outputImage = rgb;
    }
    try {
      Thumbnails.of(outputImage)
          .scale(1.0)
          .outputFormat(format.outputFormatName())
          .outputQuality(quality / 100.0f)
          .toOutputStream(baos);
    } catch (UnsupportedOperationException | IOException e) {
      throw new ImageProcessingException(
          "encode failed for format " + format + ": " + e.getMessage(), e);
    } catch (LinkageError e) {
      // WebP / AVIF native SPI 의존이 platform mismatch (ARM64 / Windows native 미동봉) 시 fail-soft.
      throw new ImageProcessingException(
          "encode failed for format "
              + format
              + " — native SPI unavailable (consider providing platform-matching dependency): "
              + e.getMessage(),
          e);
    }
    byte[] bytes = baos.toByteArray();
    if (bytes.length == 0) {
      throw new ImageProcessingException("encode produced empty output for format " + format);
    }
    return ProcessedImage.of(bytes, format, outputImage.getWidth(), outputImage.getHeight());
  }

  private static ImageFormat detectFormatOrDefault(BufferedImage img) {
    return img.getColorModel().hasAlpha() ? ImageFormat.PNG : ImageFormat.JPEG;
  }

  /**
   * EXIF Orientation tag (1~8) read. metadata-extractor classpath 부재 시 default 1 (no rotation).
   */
  int readExifOrientation(byte[] bytes) {
    if (!exifSupportAvailable) {
      LOG.debug("EXIF support disabled (metadata-extractor not on classpath) — orientation=1");
      return 1;
    }
    try {
      Class<?> readerClass = Class.forName(EXIF_READER_CLASS);
      Object metadata =
          readerClass
              .getMethod("readMetadata", InputStream.class)
              .invoke(null, new ByteArrayInputStream(bytes));
      Class<?> directoryClass = Class.forName(EXIF_DIRECTORY_CLASS);
      Object directory = metadata.getClass().getMethod("getFirstDirectoryOfType", Class.class)
          .invoke(metadata, directoryClass);
      if (directory == null) {
        return 1;
      }
      Object orientationObj = directory.getClass()
          .getMethod("getInteger", int.class)
          .invoke(directory, 0x0112);
      if (orientationObj == null) {
        return 1;
      }
      int orientation = (Integer) orientationObj;
      return orientation >= 1 && orientation <= 8 ? orientation : 1;
    } catch (ReflectiveOperationException e) {
      LOG.warn("EXIF read failed (orientation defaulted to 1): {}", e.getMessage());
      return 1;
    } catch (RuntimeException e) {
      LOG.warn("EXIF read RuntimeException (orientation defaulted to 1): {}", e.getMessage());
      return 1;
    }
  }

  /**
   * EXIF orientation 1~8 → Graphics2D 적용 회전 / 미러. AffineTransformOp 의 일부 RGB 모델 raster
   * incompatibility 회피를 위해 Graphics2D 사용.
   */
  static BufferedImage applyOrientation(BufferedImage src, int orientation) {
    if (orientation == 1) {
      return src;
    }
    int w = src.getWidth();
    int h = src.getHeight();
    boolean swap = orientation >= 5 && orientation <= 8;
    int destW = swap ? h : w;
    int destH = swap ? w : h;
    int destType = src.getColorModel().hasAlpha() ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB;
    BufferedImage dest = new BufferedImage(destW, destH, destType);
    Graphics2D g = dest.createGraphics();
    try {
      AffineTransform t = new AffineTransform();
      switch (orientation) {
        case 2 -> {
          // Mirror horizontal.
          t.translate(w, 0);
          t.scale(-1.0, 1.0);
        }
        case 3 -> {
          // 180° rotation.
          t.translate(w, h);
          t.rotate(Math.PI);
        }
        case 4 -> {
          // Mirror vertical.
          t.translate(0, h);
          t.scale(1.0, -1.0);
        }
        case 5 -> {
          // Mirror horizontal + 90° CW.
          t.rotate(Math.PI / 2);
          t.scale(1.0, -1.0);
        }
        case 6 -> {
          // 90° CW.
          t.translate(h, 0);
          t.rotate(Math.PI / 2);
        }
        case 7 -> {
          // Mirror horizontal + 90° CCW.
          t.scale(-1.0, 1.0);
          t.translate(-h, 0);
          t.translate(0, w);
          t.rotate(-Math.PI / 2);
        }
        case 8 -> {
          // 90° CCW.
          t.translate(0, w);
          t.rotate(-Math.PI / 2);
        }
        default -> {
          // No-op — but we already returned for 1.
          g.dispose();
          return src;
        }
      }
      g.setTransform(t);
      g.drawImage(src, 0, 0, null);
    } finally {
      g.dispose();
    }
    return dest;
  }

  private static boolean detectExifSupport() {
    try {
      Class.forName(EXIF_READER_CLASS);
      return true;
    } catch (ClassNotFoundException e) {
      return false;
    }
  }
}
