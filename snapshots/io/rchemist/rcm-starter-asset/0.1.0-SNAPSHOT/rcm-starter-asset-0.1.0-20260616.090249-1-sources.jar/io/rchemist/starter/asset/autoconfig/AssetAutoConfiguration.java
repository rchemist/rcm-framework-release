/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.autoconfig;

import io.rchemist.starter.asset.cdn.CdnProperties;
import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.cdn.CdnUrlResolverProvider;
import io.rchemist.starter.asset.cdn.noop.NoopCdnResolver;
import io.rchemist.starter.asset.controller.AssetController;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.presigned.PresignedUploadService;
import io.rchemist.starter.asset.service.AssetService;
import io.rchemist.starter.asset.service.DefaultAssetService;
import io.rchemist.starter.asset.session.OrphanCleanupJob;
import io.rchemist.starter.asset.session.UploadSessionService;
import io.rchemist.starter.asset.storage.StorageProvider;
import io.rchemist.starter.asset.storage.StorageProviderConfig;
import io.rchemist.starter.asset.image.async.AsyncImageProcessor;
import io.rchemist.starter.asset.image.storage.ImageStorageAdapter;
import io.rchemist.starter.asset.variant.AssetVariantConfig;
import io.rchemist.starter.asset.variant.AssetVariantPipeline;
import io.rchemist.starter.asset.variant.DefaultAssetVariantPipeline;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.s3.PresignedUrlIssuer;
import io.rchemist.starter.storage.security.UploadValidator;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.time.Duration;
import java.util.ServiceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — {@code rcm-starter-asset} 진입점. Provider 패턴으로
 * Storage / CDN 양쪽 wire.
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>{@code platform.asset.enabled=false} 로 opt-out (default true).</li>
 *   <li>{@code platform.asset.storage.provider} = aws / r2 / minio → ServiceLoader 가 selected
 *       provider.create(config) → Storage bean. provider 미지정 = Consumer 의 별도 Storage bean
 *       (Phase 6.8 LocalFileSystemStorage 등) 위임.</li>
 *   <li>{@code platform.asset.cdn.provider} = cloudfront / cloudflare / noop (default noop).</li>
 *   <li>UploadSessionService / OrphanCleanupJob 자동 wire (AssetRepository bean 필수).</li>
 *   <li>DefaultAssetService 자동 wire — Consumer 가 자체 AssetService 정의 시 양보.</li>
 * </ul>
 **/
@AutoConfiguration(after = io.rchemist.starter.storage.autoconfig.StorageAutoConfiguration.class)
@ConditionalOnProperty(prefix = "platform.asset", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(AssetProperties.class)
@EnableScheduling
public class AssetAutoConfiguration {

  private static final Logger LOG = LoggerFactory.getLogger(AssetAutoConfiguration.class);

  /**
   * Storage bean — provider 명시 시 ServiceLoader 가 가져옴. 미명시 = Consumer 가 별도 Storage
   * bean 등록.
   */
  @Bean
  @ConditionalOnMissingBean(Storage.class)
  @ConditionalOnProperty(prefix = "platform.asset.storage", name = "provider")
  public Storage assetStorage(AssetProperties properties) {
    String name = properties.storage().provider();
    StorageProvider provider = findStorageProvider(name);
    StorageProviderConfig config =
        new StorageProviderConfig(
            properties.storage().endpoint(),
            properties.storage().region(),
            properties.storage().accessKey(),
            properties.storage().secretKey(),
            properties.storage().bucket(),
            properties.storage().pathStyle());
    LOG.info("asset storage provider={} bucket={}", name, properties.storage().bucket());
    return provider.create(config);
  }

  /** CDN URL resolver — default = noop (key 그대로 노출). */
  @Bean
  @ConditionalOnMissingBean(CdnUrlResolver.class)
  public CdnUrlResolver cdnUrlResolver(AssetProperties properties) {
    String name = properties.cdn().provider();
    CdnProperties cdnProps =
        new CdnProperties(
            properties.cdn().baseUrl(),
            properties.cdn().signedUrl(),
            properties.cdn().signTtlSeconds());
    if (name == null || "noop".equalsIgnoreCase(name)) {
      LOG.info("asset CDN provider=noop (no transformation)");
      return new NoopCdnResolver(cdnProps);
    }
    CdnUrlResolverProvider provider = findCdnProvider(name);
    LOG.info("asset CDN provider={} baseUrl={}", name, cdnProps.baseUrl());
    return provider.create(cdnProps);
  }

  /** Default AssetService — Storage + AssetRepository 필수, 나머지 optional. */
  @Bean
  @ConditionalOnMissingBean(AssetService.class)
  @ConditionalOnBean({Storage.class, AssetRepository.class})
  public AssetService assetService(
      Storage storage,
      AssetRepository repository,
      ObjectProvider<KeyGenerator> keyGeneratorProvider,
      ObjectProvider<UploadValidator> validatorProvider,
      ObjectProvider<AssetVariantPipeline> pipelineProvider,
      ObjectProvider<CdnUrlResolver> cdnProvider) {
    return new DefaultAssetService(
        storage,
        repository,
        keyGeneratorProvider.getIfAvailable(),
        validatorProvider.getIfAvailable(),
        pipelineProvider.getIfAvailable(),
        cdnProvider.getIfAvailable());
  }

  /** UploadSessionService — Asset PENDING / commit / cancel 흐름. */
  @Bean
  @ConditionalOnMissingBean(UploadSessionService.class)
  @ConditionalOnBean(AssetRepository.class)
  public UploadSessionService uploadSessionService(
      AssetRepository repository,
      ObjectProvider<KeyGenerator> keyGeneratorProvider,
      AssetProperties properties) {
    return new UploadSessionService(
        repository,
        keyGeneratorProvider.getIfAvailable(),
        Duration.ofSeconds(properties.session().ttlSeconds()));
  }

  /** OrphanCleanupJob — @Scheduled 활성. */
  @Bean
  @ConditionalOnMissingBean(OrphanCleanupJob.class)
  @ConditionalOnBean({AssetRepository.class, Storage.class})
  public OrphanCleanupJob orphanCleanupJob(AssetRepository repository, Storage storage) {
    return new OrphanCleanupJob(repository, storage);
  }

  /** PresignedUploadService — PresignedUrlIssuer wired 시에만 활성. */
  @Bean
  @ConditionalOnMissingBean(PresignedUploadService.class)
  @ConditionalOnBean({AssetRepository.class, PresignedUrlIssuer.class})
  public PresignedUploadService presignedUploadService(
      AssetRepository repository,
      PresignedUrlIssuer urlIssuer,
      ObjectProvider<KeyGenerator> keyGeneratorProvider,
      ObjectProvider<Storage> storageProvider,
      ObjectProvider<AssetVariantPipeline> pipelineProvider) {
    return new PresignedUploadService(
        repository,
        urlIssuer,
        keyGeneratorProvider.getIfAvailable(),
        storageProvider.getIfAvailable(),
        pipelineProvider.getIfAvailable(),
        Duration.ofMinutes(5));
  }

  /** AssetVariantPipeline — image starter (ImageStorageAdapter) wired 시 활성. */
  @Bean
  @ConditionalOnMissingBean(AssetVariantPipeline.class)
  @ConditionalOnBean(ImageStorageAdapter.class)
  public AssetVariantPipeline assetVariantPipeline(
      ImageStorageAdapter syncAdapter,
      ObjectProvider<AsyncImageProcessor> asyncProvider) {
    return new DefaultAssetVariantPipeline(
        syncAdapter, asyncProvider.getIfAvailable(), AssetVariantConfig.defaults());
  }

  /** AssetController — Spring Web classpath + AssetService bean wired 시 활성. */
  @Bean
  @ConditionalOnMissingBean(AssetController.class)
  @ConditionalOnClass(name = "org.springframework.web.bind.annotation.RestController")
  @ConditionalOnBean(AssetService.class)
  public AssetController assetController(
      AssetService assetService,
      ObjectProvider<PresignedUploadService> presignedProvider,
      ObjectProvider<CdnUrlResolver> cdnProvider) {
    return new AssetController(
        assetService, presignedProvider.getIfAvailable(), cdnProvider.getIfAvailable());
  }

  private static StorageProvider findStorageProvider(String name) {
    for (StorageProvider p : ServiceLoader.load(StorageProvider.class)) {
      if (p.supports(name)) {
        return p;
      }
    }
    throw new IllegalStateException(
        "no StorageProvider found for name=" + name + " (registered: aws / r2 / minio)");
  }

  private static CdnUrlResolverProvider findCdnProvider(String name) {
    for (CdnUrlResolverProvider p : ServiceLoader.load(CdnUrlResolverProvider.class)) {
      if (p.supports(name)) {
        return p;
      }
    }
    throw new IllegalStateException(
        "no CdnUrlResolverProvider found for name="
            + name
            + " (registered: cloudfront / cloudflare / noop)");
  }
}
