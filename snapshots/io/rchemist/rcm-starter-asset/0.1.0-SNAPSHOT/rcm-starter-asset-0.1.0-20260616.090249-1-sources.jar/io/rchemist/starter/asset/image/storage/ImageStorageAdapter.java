/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.storage;

import io.rchemist.starter.asset.image.autoconfig.ImageProperties;
import io.rchemist.starter.asset.image.core.ImageProcessor;
import io.rchemist.starter.asset.image.core.ImageVariant;
import io.rchemist.starter.asset.image.core.ProcessedImage;
import io.rchemist.starter.asset.image.core.exception.ImageProcessingException;
import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3-5 — Storage SPI 정합 어댑터. 원본 + variant 모두 자동 저장.
 *
 * <p>주요 동작:
 * <ul>
 *   <li>원본 저장 — caller 가 제공한 base key (또는 KeyGenerator 가 생성한 key) 그대로.</li>
 *   <li>variant 저장 — {@link ImageProperties#variantKeyPattern()} pattern 적용
 *       (default {@code "{key}.{variant}.{ext}"}).</li>
 *   <li>multi-tenant — {@link KeyGenerator} bean 활성 시 자동 prefix (TenantContext ScopedValue
 *       기반).</li>
 * </ul>
 *
 * <p>실패 시 부분 저장된 원본 / variant cleanup 시도 (best-effort). KeyGenerator 옵션 — null 이면
 * caller key 그대로 사용 (multi-tenant 미사용 영역 안전).
 */
public class ImageStorageAdapter {

  private static final Logger LOG = LoggerFactory.getLogger(ImageStorageAdapter.class);

  private final ImageProcessor processor;
  private final ImageProperties properties;
  private final KeyGenerator keyGenerator;

  public ImageStorageAdapter(
      ImageProcessor processor, ImageProperties properties, KeyGenerator keyGenerator) {
    if (processor == null) {
      throw new IllegalArgumentException("processor must not be null");
    }
    if (properties == null) {
      throw new IllegalArgumentException("properties must not be null");
    }
    this.processor = processor;
    this.properties = properties;
    this.keyGenerator = keyGenerator;
  }

  /**
   * 원본 + variants 모두 저장. caller 가 제공한 {@code baseKey} 가 원본 storage key 가 됨 ({@link
   * KeyGenerator} 가 wired 인 경우 그것이 우선 — multi-tenant prefix 자동 적용).
   *
   * @param storage    Storage SPI
   * @param baseKey    원본 저장 key (KeyGenerator wired 시 무시됨 — generator 가 결정)
   * @param contentType 원본 MIME (null 가능)
   * @param source     원본 InputStream — 메서드 종료 시 close
   * @param variants   생성할 variants
   * @return 원본 key → StorageObject + 각 variant name → StorageObject map (insertion order 보존)
   */
  public Map<String, StorageObject> processAndStore(
      Storage storage,
      String baseKey,
      String contentType,
      InputStream source,
      List<ImageVariant> variants) {
    if (storage == null) {
      throw new IllegalArgumentException("storage must not be null");
    }
    if (source == null) {
      throw new IllegalArgumentException("source must not be null");
    }
    if (variants == null) {
      throw new IllegalArgumentException("variants must not be null");
    }
    String resolvedBaseKey = resolveBaseKey(baseKey);
    Map<String, StorageObject> result = new LinkedHashMap<>();
    byte[] sourceBytes;
    try (InputStream in = source) {
      sourceBytes = in.readAllBytes();
    } catch (IOException e) {
      throw new ImageProcessingException("source read failed: " + e.getMessage(), e);
    }
    if (sourceBytes.length == 0) {
      throw new ImageProcessingException("source is empty");
    }

    StorageObject original;
    try {
      original =
          storage.put(
              resolvedBaseKey,
              new ByteArrayInputStream(sourceBytes),
              contentType,
              ObjectMetadata.of(Map.of("variant", "original")));
    } catch (RuntimeException e) {
      throw new ImageProcessingException(
          "original put failed for key " + resolvedBaseKey + ": " + e.getMessage(), e);
    }
    result.put("original", original);

    for (ImageVariant variant : variants) {
      String variantKey = formatVariantKey(resolvedBaseKey, variant);
      try {
        ProcessedImage processed = processor.resize(new ByteArrayInputStream(sourceBytes), variant);
        StorageObject obj =
            storage.put(
                variantKey,
                new ByteArrayInputStream(processed.bytes()),
                processed.format().mimeType(),
                ObjectMetadata.of(
                    Map.of(
                        "variant", variant.name(),
                        "width", String.valueOf(processed.width()),
                        "height", String.valueOf(processed.height()))));
        result.put(variant.name(), obj);
      } catch (RuntimeException e) {
        // 부분 저장 cleanup — best-effort.
        cleanup(storage, result, resolvedBaseKey);
        throw new ImageProcessingException(
            "variant put failed for "
                + variant.name()
                + " (key="
                + variantKey
                + "): "
                + e.getMessage(),
            e);
      }
    }
    return result;
  }

  /**
   * Variant key 포매팅 — {@code {key}.{variant}.{ext}} pattern 기본. ext 가 baseKey 안 이미 있으면
   * baseKey 의 ext 를 떼고 variant ext 적용.
   */
  String formatVariantKey(String baseKey, ImageVariant variant) {
    String stem = stripExtension(baseKey);
    String ext = variant.format() != null ? variant.format().extension() : extractExtensionOrJpg(baseKey);
    return properties
        .variantKeyPattern()
        .replace("{key}", stem)
        .replace("{variant}", variant.name())
        .replace("{ext}", ext);
  }

  private String resolveBaseKey(String callerKey) {
    if (keyGenerator != null) {
      // tenant prefix + uuid + ext — caller key 의 filename 만 sniff (extension 보존).
      String filename = callerKey != null ? callerKey : "image";
      return keyGenerator.generate(filename);
    }
    if (callerKey == null || callerKey.isBlank()) {
      throw new IllegalArgumentException("baseKey must not be blank when KeyGenerator is absent");
    }
    return callerKey;
  }

  private void cleanup(
      Storage storage, Map<String, StorageObject> stored, String baseKey) {
    for (Map.Entry<String, StorageObject> entry : stored.entrySet()) {
      try {
        storage.delete(entry.getValue().key());
      } catch (RuntimeException ex) {
        LOG.warn(
            "cleanup failed for key {} (originalBase={}): {}",
            entry.getValue().key(),
            baseKey,
            ex.getMessage());
      }
    }
  }

  private static String stripExtension(String key) {
    int dot = key.lastIndexOf('.');
    int slash = key.lastIndexOf('/');
    if (dot > slash && dot > 0) {
      return key.substring(0, dot);
    }
    return key;
  }

  private static String extractExtensionOrJpg(String key) {
    int dot = key.lastIndexOf('.');
    int slash = key.lastIndexOf('/');
    if (dot > slash && dot > 0 && dot < key.length() - 1) {
      return key.substring(dot + 1);
    }
    return "jpg";
  }
}
