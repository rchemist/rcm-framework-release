/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — {@code platform.asset.*} prefix 의 baseline yml binding.
 * Records first.
 *
 * <p>주요 properties:
 * <ul>
 *   <li>{@code basePath} — AssetController endpoint 의 base path (default {@code /assets}).</li>
 *   <li>{@code storage.provider} — aws / r2 / minio / null (none = 별도 Storage bean 위임).</li>
 *   <li>{@code storage.endpoint / region / accessKey / secretKey / bucket / pathStyle} — provider
 *       config.</li>
 *   <li>{@code cdn.provider} — cloudfront / cloudflare / noop.</li>
 *   <li>{@code cdn.baseUrl / signedUrl / signTtlSeconds}.</li>
 *   <li>{@code session.ttlSeconds} — UploadSession 의 TTL (default 3600 = 1시간).</li>
 *   <li>{@code session.cleanupIntervalMillis} — OrphanCleanupJob 주기 (default 3600000 = 1시간).</li>
 * </ul>
 **/
@ConfigurationProperties("platform.asset")
public record AssetProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("/assets") String basePath,
    @DefaultValue Storage storage,
    @DefaultValue Cdn cdn,
    @DefaultValue Session session) {

  public record Storage(
      String provider,
      String endpoint,
      String region,
      String accessKey,
      String secretKey,
      String bucket,
      @DefaultValue("false") boolean pathStyle) {
  }

  public record Cdn(
      @DefaultValue("noop") String provider,
      String baseUrl,
      @DefaultValue("false") boolean signedUrl,
      @DefaultValue("3600") long signTtlSeconds) {
  }

  public record Session(
      @DefaultValue("3600") long ttlSeconds,
      @DefaultValue("3600000") long cleanupIntervalMillis) {
  }
}
