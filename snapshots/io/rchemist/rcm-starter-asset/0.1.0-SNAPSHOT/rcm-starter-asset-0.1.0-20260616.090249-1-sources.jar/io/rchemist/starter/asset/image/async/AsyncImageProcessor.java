/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.async;

import io.rchemist.starter.asset.image.core.ImageVariant;
import io.rchemist.starter.asset.image.storage.ImageStorageAdapter;
import io.rchemist.starter.jpa.async.AsyncJob;
import io.rchemist.starter.jpa.async.AsyncJobTracker;
import io.rchemist.starter.storage.core.Storage;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3-6 — Async / bulk image processing. Phase 4 {@link AsyncJobTracker}
 * 정합 — 진행률 update + 실패 시 재처리 가능.
 *
 * <p>JDK 25 VirtualThread 친화 — default {@link Executor} 가 {@link
 * Executors#newVirtualThreadPerTaskExecutor()}. caller 가 자체 Executor 주입 가능.
 *
 * <p>대량 이미지 변환 시 {@link AsyncJobTracker} 에 register / start / updateProgress / complete /
 * fail 자동. 각 BatchItem 처리 후 progress 갱신 (n / total * 100).
 */
public class AsyncImageProcessor {

  private static final Logger LOG = LoggerFactory.getLogger(AsyncImageProcessor.class);
  private static final String JOB_TYPE = "image-batch";

  private final ImageStorageAdapter adapter;
  private final AsyncJobTracker tracker;
  private final Executor executor;

  public AsyncImageProcessor(ImageStorageAdapter adapter, AsyncJobTracker tracker) {
    this(adapter, tracker, Executors.newVirtualThreadPerTaskExecutor());
  }

  public AsyncImageProcessor(
      ImageStorageAdapter adapter, AsyncJobTracker tracker, Executor executor) {
    if (adapter == null) {
      throw new IllegalArgumentException("adapter must not be null");
    }
    if (tracker == null) {
      throw new IllegalArgumentException("tracker must not be null");
    }
    if (executor == null) {
      throw new IllegalArgumentException("executor must not be null");
    }
    this.adapter = adapter;
    this.tracker = tracker;
    this.executor = executor;
  }

  /**
   * Batch processing — 각 item 의 source 를 storage 에 저장 + variants 생성. AsyncJobTracker 에 진행률
   * 자동 update.
   *
   * @param storage  Storage SPI
   * @param items    처리할 item list
   * @param variants 모든 item 에 동일 적용할 variant list
   * @return 등록된 AsyncJob
   */
  public AsyncJob processBatch(Storage storage, List<BatchItem> items, List<ImageVariant> variants) {
    if (storage == null) {
      throw new IllegalArgumentException("storage must not be null");
    }
    if (items == null || items.isEmpty()) {
      throw new IllegalArgumentException("items must not be empty");
    }
    if (variants == null) {
      throw new IllegalArgumentException("variants must not be null");
    }
    String jobId = UUID.randomUUID().toString();
    AsyncJob job = tracker.register(jobId, JOB_TYPE);
    executor.execute(() -> runBatch(storage, jobId, items, variants));
    return job;
  }

  /** Visible for tests — same-thread synchronous execution. */
  void runBatch(
      Storage storage, String jobId, List<BatchItem> items, List<ImageVariant> variants) {
    tracker.start(jobId);
    int total = items.size();
    int processed = 0;
    try {
      for (BatchItem item : items) {
        try {
          adapter.processAndStore(
              storage, item.baseKey(), item.contentType(), item.source(), variants);
        } catch (RuntimeException e) {
          LOG.warn("batch item {} failed: {}", item.baseKey(), e.getMessage());
          tracker.fail(jobId, "item failed: " + item.baseKey() + " — " + e.getMessage());
          return;
        }
        processed++;
        // last entry 는 complete() 가 100 set — 그 직전 까지만 progress update.
        if (processed < total) {
          int progress = (int) Math.min(99L, ((long) processed * 100L) / total);
          if (progress > 0) {
            tracker.updateProgress(jobId, progress);
          }
        }
      }
      tracker.complete(jobId);
    } catch (RuntimeException e) {
      LOG.warn("batch failed (jobId={}): {}", jobId, e.getMessage());
      try {
        tracker.fail(jobId, e.getMessage());
      } catch (RuntimeException ignored) {
        // tracker mutate 충돌 무시 — 이미 fail / complete 직전 상태일 수 있음.
      }
    }
  }

  /**
   * Batch 단위 입력. source InputStream 은 처리 시점에 close.
   *
   * @param baseKey     원본 storage key (KeyGenerator wired 시 무시)
   * @param contentType 원본 MIME (null 가능)
   * @param source      원본 InputStream
   */
  public record BatchItem(String baseKey, String contentType, InputStream source) {

    public BatchItem {
      if (source == null) {
        throw new IllegalArgumentException("source must not be null");
      }
    }
  }
}
