/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.session;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.time.Duration;
import java.time.Instant;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A4) — Multi-step upload (createSession → 외부 업로드 → commit)
 * 흐름. presigned URL 미사용 영역 또는 owner 가 나중에 결정되는 시나리오 (WYSIWYG temp upload).
 *
 * <p>흐름:
 * <ol>
 *   <li>createSession(contentType, sizeHint) — Asset PENDING 생성 + UUID sessionId 발급.</li>
 *   <li>(Consumer 가 업로드 진행 — direct PUT to Storage 또는 별도 endpoint 통해)</li>
 *   <li>commit(sessionId, ownerType, ownerId, sha256, actualSize) — Asset ACTIVE 전이.</li>
 * </ol>
 *
 * <p>session map = in-memory ConcurrentHashMap (단일 프로세스 가정). multi-instance 환경에서는
 * Asset entity 만으로 충분 (sessionId 가 Asset 의 secondary key).
 **/
public class UploadSessionService {

  private final AssetRepository repository;
  private final KeyGenerator keyGenerator;
  private final Duration ttl;
  private final ConcurrentMap<String, Long> sessions = new ConcurrentHashMap<>();

  public UploadSessionService(AssetRepository repository, KeyGenerator keyGenerator, Duration ttl) {
    if (repository == null) {
      throw new IllegalArgumentException("repository must not be null");
    }
    if (ttl == null || ttl.isZero() || ttl.isNegative()) {
      throw new IllegalArgumentException("ttl must be positive");
    }
    this.repository = repository;
    this.keyGenerator = keyGenerator;
    this.ttl = ttl;
  }

  /** UploadSession 시작 — Asset PENDING + sessionId 토큰 발급. */
  public UploadSessionToken createSession(String contentType, String originalName, long sizeHint) {
    Instant expiresAt = Instant.now().plus(ttl);
    String key = resolveKey(originalName);
    Asset asset = Asset.pending(key, sizeHint, contentType, expiresAt);
    asset.setOriginalName(originalName);
    Asset saved = repository.save(asset);
    String sessionId = UUID.randomUUID().toString();
    sessions.put(sessionId, saved.getId());
    return new UploadSessionToken(sessionId, saved.getId(), key, expiresAt);
  }

  /**
   * Session commit — Asset ACTIVE 전이 + owner + sha256 채움. session 미존재 또는 만료 시
   * NoSuchElementException.
   */
  public Asset commit(
      String sessionId, String ownerType, Object ownerId, String sha256, long actualSize) {
    Long assetId = sessions.remove(sessionId);
    if (assetId == null) {
      throw new NoSuchElementException("session not found or already committed: " + sessionId);
    }
    Asset asset =
        repository.findById(assetId)
            .orElseThrow(() -> new NoSuchElementException("asset not found: " + assetId));
    if (asset.getStatus() != AssetStatus.PENDING) {
      throw new IllegalStateException(
          "asset is not PENDING (status=" + asset.getStatus() + ")");
    }
    if (asset.getExpiresAt() != null && asset.getExpiresAt().isBefore(Instant.now())) {
      throw new IllegalStateException("session expired at " + asset.getExpiresAt());
    }
    asset.setStatus(AssetStatus.ACTIVE);
    asset.setExpiresAt(null);
    asset.setOwnerType(ownerType);
    asset.setOwnerId(ownerId != null ? ownerId.toString() : null);
    asset.setSha256(sha256);
    if (actualSize > 0) {
      asset.setSize(actualSize);
    }
    return repository.save(asset);
  }

  /** session 강제 삭제 (Consumer 가 cancel 호출 시). */
  public boolean cancel(String sessionId) {
    Long assetId = sessions.remove(sessionId);
    if (assetId == null) {
      return false;
    }
    repository.findById(assetId).ifPresent(repository::delete);
    return true;
  }

  /** TTL 노출 (테스트 / 디버그). */
  public Duration ttl() {
    return ttl;
  }

  private String resolveKey(String originalName) {
    String name = originalName != null ? originalName : "session";
    if (keyGenerator != null) {
      return keyGenerator.generate(name);
    }
    return "sessions/" + UUID.randomUUID() + "-" + name;
  }
}
