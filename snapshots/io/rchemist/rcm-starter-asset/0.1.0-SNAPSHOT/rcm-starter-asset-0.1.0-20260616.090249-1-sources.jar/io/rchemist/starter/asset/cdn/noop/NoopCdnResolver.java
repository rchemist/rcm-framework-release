/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn.noop;

import io.rchemist.starter.asset.cdn.CdnProperties;
import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.cdn.CdnUrlResolverProvider;
import io.rchemist.starter.asset.entity.Asset;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — Noop CDN provider. CDN 미사용 환경의 fallback. asset key
 * 그대로 노출. baseUrl 이 properties 에 있으면 prefix 부착.
 **/
public class NoopCdnResolver implements CdnUrlResolver {

  private final String baseUrl;

  public NoopCdnResolver(CdnProperties properties) {
    this.baseUrl = properties != null ? properties.baseUrl() : null;
  }

  @Override
  public String name() {
    return "noop";
  }

  @Override
  public String resolve(Asset asset) {
    if (asset == null) {
      return null;
    }
    return prefix(asset.getKey());
  }

  private String prefix(String key) {
    if (baseUrl == null || baseUrl.isBlank()) {
      return key;
    }
    if (baseUrl.endsWith("/")) {
      return baseUrl + (key.startsWith("/") ? key.substring(1) : key);
    }
    return baseUrl + (key.startsWith("/") ? key : "/" + key);
  }

  /** ServiceLoader 등록용 provider. */
  public static class Provider implements CdnUrlResolverProvider {
    @Override
    public String name() {
      return "noop";
    }

    @Override
    public CdnUrlResolver create(CdnProperties properties) {
      return new NoopCdnResolver(properties);
    }
  }
}
