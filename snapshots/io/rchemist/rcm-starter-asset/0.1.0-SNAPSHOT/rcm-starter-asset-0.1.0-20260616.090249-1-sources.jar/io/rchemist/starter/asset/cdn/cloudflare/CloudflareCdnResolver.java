/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn.cloudflare;

import io.rchemist.starter.asset.cdn.CdnProperties;
import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.cdn.CdnUrlResolverProvider;
import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetVariant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — Cloudflare CDN provider (Cloudflare Workers / R2 public
 * URL / Cloudflare CDN). baseUrl prefix 단순.
 *
 * <p>Cloudflare 의 signed URL = Workers script 또는 Cloudflare Access 적용 외부 메커니즘 — 본
 * resolver 는 baseline path-based 만 제공.
 **/
public class CloudflareCdnResolver implements CdnUrlResolver {

  private final String baseUrl;

  public CloudflareCdnResolver(CdnProperties properties) {
    if (properties == null || properties.baseUrl() == null || properties.baseUrl().isBlank()) {
      throw new IllegalArgumentException(
          "Cloudflare baseUrl required (e.g. https://cdn.example.com)");
    }
    this.baseUrl = properties.baseUrl();
  }

  @Override
  public String name() {
    return "cloudflare";
  }

  @Override
  public String resolve(Asset asset) {
    if (asset == null) {
      return null;
    }
    return join(baseUrl, asset.getKey());
  }

  @Override
  public String resolveVariant(Asset asset, AssetVariant variant) {
    if (variant == null) {
      return null;
    }
    return join(baseUrl, variant.getKey());
  }

  private static String join(String base, String key) {
    String b = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
    String k = key.startsWith("/") ? key : "/" + key;
    return b + k;
  }

  /** ServiceLoader 등록용 provider. */
  public static class Provider implements CdnUrlResolverProvider {
    @Override
    public String name() {
      return "cloudflare";
    }

    @Override
    public CdnUrlResolver create(CdnProperties properties) {
      return new CloudflareCdnResolver(properties);
    }
  }
}
