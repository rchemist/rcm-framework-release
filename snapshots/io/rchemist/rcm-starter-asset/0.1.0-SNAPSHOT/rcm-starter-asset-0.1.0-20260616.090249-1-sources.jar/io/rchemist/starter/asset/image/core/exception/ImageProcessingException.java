/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core.exception;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — 이미지 처리 실패 RuntimeException (cause 보존). Thumbnailator 의 IOException
 * / ImageIO 의 SPI 미지원 / EXIF parser 실패 등을 wrap.
 */
public class ImageProcessingException extends RuntimeException {

  public ImageProcessingException(String message) {
    super(message);
  }

  public ImageProcessingException(String message, Throwable cause) {
    super(message, cause);
  }
}
