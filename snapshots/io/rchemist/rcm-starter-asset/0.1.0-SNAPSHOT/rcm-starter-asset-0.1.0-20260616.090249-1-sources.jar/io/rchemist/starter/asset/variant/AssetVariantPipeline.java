/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.variant;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetVariant;
import io.rchemist.starter.storage.core.Storage;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A8) — Image variant pipeline SPI. AssetService 가 contentType
 * = image/* 인 경우만 호출. 동기 / 비동기 분기는 impl 책임.
 **/
public interface AssetVariantPipeline {

  /**
   * Asset 에 대해 variant 생성 + Storage 저장 + AssetVariant entity 부착.
   *
   * @param storage     Storage SPI
   * @param asset       부모 Asset (이미 저장된 상태)
   * @param sourceBytes 원본 bytes (이미 메모리에 있음)
   * @param contentType 원본 MIME
   * @return 생성된 variant list (실패 시 빈 list).
   */
  List<AssetVariant> process(Storage storage, Asset asset, byte[] sourceBytes, String contentType);
}
