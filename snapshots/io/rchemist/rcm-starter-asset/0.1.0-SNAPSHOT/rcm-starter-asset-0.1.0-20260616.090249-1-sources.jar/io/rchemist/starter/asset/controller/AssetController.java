/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.controller;

import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.presigned.PresignedCompleteCommand;
import io.rchemist.starter.asset.presigned.PresignedUploadCommand;
import io.rchemist.starter.asset.presigned.PresignedUploadService;
import io.rchemist.starter.asset.presigned.PresignedUploadTicket;
import io.rchemist.starter.asset.service.AssetService;
import io.rchemist.starter.asset.service.AssetUploadCommand;
import io.rchemist.starter.asset.service.AssetUploadResult;
import io.rchemist.starter.storage.security.UploadValidationException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A7) — *단일 통합 endpoint*. WYSIWYG / 첨부파일 / direct upload /
 * presigned URL 모두 동일 5 endpoint 매트릭스.
 *
 * <p>endpoint:
 * <ul>
 *   <li>POST {basePath}/ — multipart upload (file + ownerType + ownerId + extra) → AssetView.</li>
 *   <li>POST {basePath}/presigned-url — Presigned URL 발급 → PresignedUploadTicket.</li>
 *   <li>POST {basePath}/{id}/complete — Presigned upload 완료 → AssetView.</li>
 *   <li>GET  {basePath}/{id} — Asset 조회 → AssetView.</li>
 *   <li>DELETE {basePath}/{id} — soft-delete → 204.</li>
 * </ul>
 *
 * <p>WYSIWYG-specific wire protocol (CKEditor / TinyMCE / Quill) 변환은 *Consumer controller
 * 책임* — framework 가 5종 wire protocol 다 안다고 가정 = over-engineering 영구 거부 (사용자 통찰
 * 2026-05-04).
 **/
@RestController
@RequestMapping("${platform.asset.base-path:/assets}")
public class AssetController {

  private final AssetService assetService;
  private final PresignedUploadService presignedService;
  private final CdnUrlResolver cdnResolver;

  public AssetController(
      AssetService assetService,
      PresignedUploadService presignedService,
      CdnUrlResolver cdnResolver) {
    this.assetService = assetService;
    this.presignedService = presignedService;
    this.cdnResolver = cdnResolver;
  }

  /** Multipart upload — file + ownerType + ownerId + extra. */
  @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<AssetView> upload(
      @RequestParam("file") MultipartFile file,
      @RequestParam(value = "ownerType", required = false) String ownerType,
      @RequestParam(value = "ownerId", required = false) String ownerId,
      @RequestParam Map<String, String> allParams)
      throws IOException {
    Map<String, Object> extra = new LinkedHashMap<>();
    allParams.forEach((k, v) -> {
      if (!k.equals("file") && !k.equals("ownerType") && !k.equals("ownerId")) {
        extra.put(k, v);
      }
    });
    AssetUploadCommand cmd = new AssetUploadCommand(
        file.getInputStream(),
        file.getContentType(),
        file.getOriginalFilename(),
        file.getSize(),
        ownerType,
        ownerId,
        extra);
    AssetUploadResult result = assetService.upload(cmd);
    return ResponseEntity.ok(AssetView.of(result.asset(), result.url(), result.variants()));
  }

  /** Presigned URL 발급 — direct upload 시작. */
  @PostMapping("/presigned-url")
  public ResponseEntity<PresignedUploadTicket> requestPresignedUrl(
      @RequestBody PresignedUploadCommand command) {
    if (presignedService == null) {
      return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
    }
    return ResponseEntity.ok(presignedService.request(command));
  }

  /** Presigned URL 완료 알림 — Asset PENDING → ACTIVE 전이. */
  @PostMapping("/{id}/complete")
  public ResponseEntity<AssetView> completePresigned(
      @PathVariable("id") Long id, @RequestBody PresignedCompleteCommand bodyCommand) {
    if (presignedService == null) {
      return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
    }
    PresignedCompleteCommand cmd =
        new PresignedCompleteCommand(
            id,
            bodyCommand.sha256(),
            bodyCommand.actualSize(),
            bodyCommand.ownerType(),
            bodyCommand.ownerId());
    Asset asset = presignedService.complete(cmd);
    return ResponseEntity.ok(AssetView.of(asset, resolveUrl(asset), List.of()));
  }

  /** Asset 단일 조회. */
  @GetMapping("/{id}")
  public ResponseEntity<AssetView> get(@PathVariable("id") Long id) {
    return assetService.findById(id)
        .map(a -> ResponseEntity.ok(AssetView.of(a, resolveUrl(a), List.of())))
        .orElse(ResponseEntity.notFound().build());
  }

  /** Asset soft-delete. */
  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
    assetService.delete(id);
    return ResponseEntity.noContent().build();
  }

  @ExceptionHandler(UploadValidationException.class)
  public ProblemDetail handleValidation(UploadValidationException e) {
    ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    pd.setTitle("Upload validation failed");
    return pd;
  }

  @ExceptionHandler(java.util.NoSuchElementException.class)
  public ProblemDetail handleNotFound(java.util.NoSuchElementException e) {
    ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, e.getMessage());
    pd.setTitle("Asset not found");
    return pd;
  }

  @ExceptionHandler(io.rchemist.starter.asset.storage.ProviderUnavailableException.class)
  public ProblemDetail handleProviderUnavailable(
      io.rchemist.starter.asset.storage.ProviderUnavailableException e) {
    ProblemDetail pd =
        ProblemDetail.forStatusAndDetail(HttpStatus.SERVICE_UNAVAILABLE, e.getMessage());
    pd.setTitle("Storage provider unavailable");
    return pd;
  }

  private String resolveUrl(Asset asset) {
    if (cdnResolver != null) {
      String url = cdnResolver.resolve(asset);
      if (url != null) {
        return url;
      }
    }
    return asset.getKey();
  }
}
