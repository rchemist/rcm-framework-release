/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.controller;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.asset.service.AssetVariantView;
import java.time.Instant;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A7) — Asset REST 응답 DTO. Records first.
 *
 * <p>{@link Asset} entity 의 외부 노출 view (sensitive field 제외 — internal column 등 hide).
 **/
public record AssetView(
    Long id,
    String key,
    String url,
    String contentType,
    Long size,
    String sha256,
    String originalName,
    AssetStatus status,
    List<AssetVariantView> variants,
    Instant createdAt) {

  /** entity → view 변환 (variants + url 은 caller 가 제공). */
  public static AssetView of(Asset asset, String url, List<AssetVariantView> variants) {
    if (asset == null) {
      throw new IllegalArgumentException("asset must not be null");
    }
    return new AssetView(
        asset.getId(),
        asset.getKey(),
        url,
        asset.getContentType(),
        asset.getSize(),
        asset.getSha256(),
        asset.getOriginalName(),
        asset.getStatus(),
        variants != null ? variants : List.of(),
        asset.getCreatedAt());
  }
}
