/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.service;

import io.rchemist.starter.asset.entity.Asset;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — AssetService.upload 응답. Records first.
 *
 * <p>WYSIWYG / Article 첨부 / API 직접 호출 모두 동일 응답 사용. WYSIWYG-specific wire protocol
 * (CKEditor {@code {url}} / TinyMCE {@code {location}}) 변환은 *Consumer controller 책임* —
 * framework 가 5종 wire protocol 다 안다고 가정 = over-engineering 영구 거부.
 **/
public record AssetUploadResult(
    Asset asset,
    String url,
    List<AssetVariantView> variants,
    Map<String, Object> attributes) {
}
