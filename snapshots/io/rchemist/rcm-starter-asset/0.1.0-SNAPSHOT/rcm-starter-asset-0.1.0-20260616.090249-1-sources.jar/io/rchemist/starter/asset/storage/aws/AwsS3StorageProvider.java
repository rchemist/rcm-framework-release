/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.storage.aws;

import io.rchemist.starter.asset.storage.ProviderUnavailableException;
import io.rchemist.starter.asset.storage.S3CompatStorage;
import io.rchemist.starter.asset.storage.StorageProvider;
import io.rchemist.starter.asset.storage.StorageProviderConfig;
import io.rchemist.starter.storage.core.Storage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — AWS S3 provider. AWS SDK v2 직접 사용. endpoint = null
 * (region 만 지정 — SDK 가 표준 endpoint 자동 resolve).
 *
 * <p>SDK = compileOnly. 미입주 시 ClassNotFoundException → ProviderUnavailableException wrap.
 **/
public class AwsS3StorageProvider implements StorageProvider {

  @Override
  public String name() {
    return "aws";
  }

  @Override
  public Storage create(StorageProviderConfig config) {
    try {
      return new S3CompatStorage(config, "aws");
    } catch (LinkageError e) {
      throw new ProviderUnavailableException(
          "AWS S3 SDK v2 not on classpath — add software.amazon.awssdk:s3 dependency", e);
    }
  }
}
