/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — CDN provider SPI. ServiceLoader 등록 → AssetAutoConfig
 * 가 platform.asset.cdn.provider yml key 로 선택.
 **/
public interface CdnUrlResolverProvider {

  /** Provider 식별 이름 (예: cloudfront / cloudflare / noop). */
  String name();

  /** 본 provider 가 주어진 name 을 지원하는가. default impl = name() 비교. */
  default boolean supports(String providerName) {
    return providerName != null && providerName.equalsIgnoreCase(name());
  }

  /** 주어진 properties 로 resolver 인스턴스 생성. */
  CdnUrlResolver create(CdnProperties properties);
}
