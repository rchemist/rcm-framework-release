/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core;

import java.io.InputStream;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (Decision #29 Q1) — 이미지 처리 SPI baseline. 백엔드 (Thumbnailator
 * default / ImageMagick / GraphicsMagick / native libvips 등) 와 무관한 사용자 시각.
 *
 * <p>method:
 * <ul>
 *   <li>{@link #resize(InputStream, ImageVariant)} — 종횡비 정책 + variant 인코딩 적용 resize.</li>
 *   <li>{@link #crop(InputStream, int, int, int, int, ImageFormat)} — pixel coord crop.</li>
 *   <li>{@link #watermark(InputStream, InputStream, double, double, float, ImageFormat)} —
 *       watermark image overlay (relative pos + opacity).</li>
 *   <li>{@link #convert(InputStream, ImageFormat, int)} — format / quality conversion.</li>
 *   <li>{@link #exifNormalize(InputStream, ImageFormat)} — EXIF orientation 으로 회전 보정 후
 *       metadata 제거.</li>
 * </ul>
 *
 * <p>실패 시 {@link io.rchemist.starter.asset.image.core.exception.ImageProcessingException} (RuntimeException)
 * 으로 wrap. caller stream 은 메서드가 자동 close.
 */
public interface ImageProcessor {

  /** Resize + (optional) format convert. */
  ProcessedImage resize(InputStream source, ImageVariant variant);

  /**
   * Pixel coordinate crop.
   *
   * @param source      input stream (close 책임 = 본 메서드)
   * @param x           crop region 시작 X (좌상단 기준, &gt;= 0)
   * @param y           crop region 시작 Y (좌상단 기준, &gt;= 0)
   * @param width       crop 영역 width (&gt; 0)
   * @param height      crop 영역 height (&gt; 0)
   * @param outputFormat 출력 포맷 (null = source format 유지)
   */
  ProcessedImage crop(
      InputStream source, int x, int y, int width, int height, ImageFormat outputFormat);

  /**
   * Watermark overlay. {@code relativeX/Y} 는 0.0~1.0 (좌상단 = 0/0, 우하단 = 1/1).
   *
   * @param source       대상 이미지 stream
   * @param watermark    overlay 이미지 stream
   * @param relativeX    가로 위치 비율 (0.0~1.0)
   * @param relativeY    세로 위치 비율 (0.0~1.0)
   * @param opacity      opacity (0.0~1.0, 1.0 = 불투명)
   * @param outputFormat 출력 포맷 (null = source format 유지)
   */
  ProcessedImage watermark(
      InputStream source,
      InputStream watermark,
      double relativeX,
      double relativeY,
      float opacity,
      ImageFormat outputFormat);

  /** Format / quality conversion (resize 없음). quality = 1~100. */
  ProcessedImage convert(InputStream source, ImageFormat targetFormat, int quality);

  /**
   * EXIF orientation tag 으로 회전 보정 + metadata 제거. EXIF 의존 ({@code metadata-extractor}) 미입주
   * 시 fallback (회전 0 으로 처리, no-op + log).
   *
   * @param source       JPEG / TIFF 등 EXIF 보유 가능 source
   * @param outputFormat 출력 포맷 (null = source format 유지)
   */
  ProcessedImage exifNormalize(InputStream source, ImageFormat outputFormat);
}
