/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.storage;

import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import io.rchemist.starter.storage.core.exception.ObjectNotFoundException;
import io.rchemist.starter.storage.core.exception.StorageException;
import java.io.InputStream;
import java.net.URI;
import java.util.Map;
import java.util.stream.Stream;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — AWS SDK v2 기반 S3-compat Storage. AWS / R2 / MinIO 모두
 * 동일 구현 사용 — endpoint / region / pathStyle 만 다름.
 *
 * <p>SDK 의존 = compileOnly. Consumer 가 활성화 시점에 SDK 가져와야 함. 미입주 = ClassNotFound
 * 가 ProviderUnavailableException 으로 wrap (provider 진입점에서).
 **/
public class S3CompatStorage implements Storage {

  private final S3Client client;
  private final String bucket;
  private final String providerName;

  public S3CompatStorage(StorageProviderConfig config, String providerName) {
    if (config == null) {
      throw new IllegalArgumentException("config must not be null");
    }
    this.bucket = config.bucket();
    this.providerName = providerName != null ? providerName : "s3";
    this.client = buildClient(config);
  }

  /** Visible for testing — caller 가 직접 client 주입. */
  public S3CompatStorage(S3Client client, String bucket, String providerName) {
    if (client == null) {
      throw new IllegalArgumentException("client must not be null");
    }
    if (bucket == null || bucket.isBlank()) {
      throw new IllegalArgumentException("bucket must not be blank");
    }
    this.client = client;
    this.bucket = bucket;
    this.providerName = providerName != null ? providerName : "s3";
  }

  @Override
  public String name() {
    return providerName;
  }

  @Override
  public StorageObject put(
      String key, InputStream content, String contentType, ObjectMetadata metadata) {
    try {
      byte[] bytes = content.readAllBytes();
      PutObjectRequest.Builder req =
          PutObjectRequest.builder().bucket(bucket).key(key).contentLength((long) bytes.length);
      if (contentType != null) {
        req.contentType(contentType);
      }
      if (metadata != null && !metadata.isEmpty()) {
        req.metadata(metadata.entries());
      }
      client.putObject(req.build(), RequestBody.fromBytes(bytes));
      return new StorageObject(key, contentType, bytes.length, null, metadata, null);
    } catch (Exception e) {
      throw new StorageException("put failed for key " + key + ": " + e.getMessage(), e);
    }
  }

  @Override
  public InputStream open(String key) {
    try {
      return client.getObject(
          GetObjectRequest.builder().bucket(bucket).key(key).build(),
          ResponseTransformer.toInputStream());
    } catch (NoSuchKeyException e) {
      throw new ObjectNotFoundException(key);
    } catch (Exception e) {
      throw new StorageException("open failed for key " + key + ": " + e.getMessage(), e);
    }
  }

  @Override
  public StorageObject head(String key) {
    try {
      HeadObjectResponse resp =
          client.headObject(HeadObjectRequest.builder().bucket(bucket).key(key).build());
      Map<String, String> meta = resp.metadata();
      return new StorageObject(
          key,
          resp.contentType(),
          resp.contentLength(),
          null,
          meta != null && !meta.isEmpty() ? ObjectMetadata.of(meta) : null,
          resp.lastModified());
    } catch (NoSuchKeyException e) {
      throw new ObjectNotFoundException(key);
    } catch (Exception e) {
      throw new StorageException("head failed for key " + key + ": " + e.getMessage(), e);
    }
  }

  @Override
  public boolean delete(String key) {
    try {
      client.deleteObject(DeleteObjectRequest.builder().bucket(bucket).key(key).build());
      return true;
    } catch (NoSuchKeyException e) {
      return false;
    } catch (Exception e) {
      throw new StorageException("delete failed for key " + key + ": " + e.getMessage(), e);
    }
  }

  @Override
  public boolean exists(String key) {
    try {
      client.headObject(HeadObjectRequest.builder().bucket(bucket).key(key).build());
      return true;
    } catch (NoSuchKeyException e) {
      return false;
    } catch (Exception e) {
      // 일반 S3 endpoint 미존재 시 404 가 NoSuchKey 가 아니라 다른 wrap 으로 올 수 있어 보수적
      // false 반환.
      return false;
    }
  }

  @Override
  public Stream<String> listKeys(String prefix) {
    try {
      return client
          .listObjectsV2(ListObjectsV2Request.builder().bucket(bucket).prefix(prefix).build())
          .contents()
          .stream()
          .map(o -> o.key());
    } catch (Exception e) {
      throw new StorageException("listKeys failed for prefix " + prefix + ": " + e.getMessage(), e);
    }
  }

  private static S3Client buildClient(StorageProviderConfig config) {
    var builder = S3Client.builder();
    if (config.region() != null && !config.region().isBlank()) {
      builder.region(Region.of(config.region()));
    } else {
      builder.region(Region.US_EAST_1);
    }
    if (config.endpoint() != null && !config.endpoint().isBlank()) {
      builder.endpointOverride(URI.create(config.endpoint()));
    }
    if (config.accessKey() != null && config.secretKey() != null) {
      builder.credentialsProvider(
          StaticCredentialsProvider.create(
              AwsBasicCredentials.create(config.accessKey(), config.secretKey())));
    }
    builder.serviceConfiguration(
        S3Configuration.builder().pathStyleAccessEnabled(config.pathStyle()).build());
    return builder.build();
  }
}
