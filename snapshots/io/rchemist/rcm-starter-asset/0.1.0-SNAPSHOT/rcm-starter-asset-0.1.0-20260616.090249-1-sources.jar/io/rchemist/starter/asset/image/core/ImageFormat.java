/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core;

import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — 이미지 포맷 enum. {@link ImageProcessor#convert} 의 target format 으로 사용.
 *
 * <p>각 entry 는 MIME type + 확장자 + Thumbnailator output format 명을 보유. WEBP / AVIF 는 ImageIO
 * SPI 의존 (옵션 — webp-imageio classpath 시 활성, AVIF 는 JDK pure 미지원이라 *advisory*).
 */
public enum ImageFormat {

  JPEG("image/jpeg", "jpg", "jpg"),
  PNG("image/png", "png", "png"),
  WEBP("image/webp", "webp", "webp"),
  AVIF("image/avif", "avif", "avif"),
  GIF("image/gif", "gif", "gif");

  private final String mimeType;
  private final String extension;
  private final String outputFormatName;

  ImageFormat(String mimeType, String extension, String outputFormatName) {
    this.mimeType = mimeType;
    this.extension = extension;
    this.outputFormatName = outputFormatName;
  }

  public String mimeType() {
    return mimeType;
  }

  public String extension() {
    return extension;
  }

  public String outputFormatName() {
    return outputFormatName;
  }

  /**
   * MIME 또는 확장자 string 으로부터 lookup. 미일치 = {@code null}.
   *
   * @param value MIME (e.g. {@code image/jpeg}) 또는 확장자 (e.g. {@code jpg})
   */
  public static ImageFormat fromString(String value) {
    if (value == null || value.isBlank()) {
      return null;
    }
    String lower = value.toLowerCase(Locale.ROOT).trim();
    for (ImageFormat fmt : values()) {
      if (fmt.mimeType.equalsIgnoreCase(lower) || fmt.extension.equalsIgnoreCase(lower)) {
        return fmt;
      }
    }
    // jpeg vs jpg 별칭.
    if ("jpeg".equals(lower)) {
      return JPEG;
    }
    return null;
  }
}
