/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.entity;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — AssetVariant CRUD. 직접 inject 보다 Asset.getVariants() 가 일반적
 * — 본 repository 는 cross-asset 관리 / 통계 / cleanup 용.
 **/
public interface AssetVariantRepository extends JpaRepository<AssetVariant, Long> {

  /** Asset 기반 모든 variant (없으면 빈 list). */
  List<AssetVariant> getByAssetId(Long assetId);

  /** Asset + variant name 단일 조회. */
  Optional<AssetVariant> findByAssetIdAndName(Long assetId, String name);
}
