/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.autoconfig;

import io.rchemist.starter.asset.image.async.AsyncImageProcessor;
import io.rchemist.starter.asset.image.core.ImageProcessor;
import io.rchemist.starter.asset.image.storage.ImageStorageAdapter;
import io.rchemist.starter.asset.image.thumbnailator.ThumbnailatorImageProcessor;
import io.rchemist.starter.jpa.async.AsyncJobTracker;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, Decision #29 Q1) — {@code rcm-starter-asset} 의 image
 * sub-package 진입점. asset 통합 starter 안에서 image 는 special case 로 흡수됨.
 *
 * <p>baseline 적용:
 * <ul>
 *   <li>Decision #20 — prefix 없음. starter / 패키지 가 도메인 영역 자체 명시
 *       ({@code io.rchemist.starter.asset.image}).</li>
 *   <li>{@code platform.image.enabled=false} 로 opt-out (default true).</li>
 *   <li>Thumbnailator classpath 발견 시 {@link ThumbnailatorImageProcessor} 자동 wire — Consumer
 *       가 자체 {@link ImageProcessor} bean 정의 시 양보.</li>
 *   <li>{@link KeyGenerator} bean 활성 시 {@link ImageStorageAdapter} 가 멀티테넌트 prefix 자동
 *       (옵션 — null 도 안전).</li>
 *   <li>{@link AsyncJobTracker} bean 활성 시 {@link AsyncImageProcessor} 자동 wire (대량 변환
 *       baseline).</li>
 * </ul>
 */
@AutoConfiguration
@ConditionalOnProperty(prefix = "platform.image", name = "enabled", matchIfMissing = true)
@ConditionalOnClass(net.coobird.thumbnailator.Thumbnails.class)
@EnableConfigurationProperties(ImageProperties.class)
public class ImageAutoConfiguration {

  /** Default {@link ImageProcessor} = {@link ThumbnailatorImageProcessor}. */
  @Bean
  @ConditionalOnMissingBean(ImageProcessor.class)
  public ImageProcessor thumbnailatorImageProcessor(ImageProperties properties) {
    return new ThumbnailatorImageProcessor(properties);
  }

  /**
   * Default {@link ImageStorageAdapter} — Storage SPI 와 결합 (Storage bean 미입주 영역에서도 직접
   * inject 가능). {@link KeyGenerator} 는 옵션 — wired 시 멀티테넌트 prefix 자동.
   */
  @Bean
  @ConditionalOnMissingBean(ImageStorageAdapter.class)
  public ImageStorageAdapter imageStorageAdapter(
      ImageProcessor processor,
      ImageProperties properties,
      ObjectProvider<KeyGenerator> keyGeneratorProvider) {
    return new ImageStorageAdapter(processor, properties, keyGeneratorProvider.getIfAvailable());
  }

  /** Default {@link AsyncImageProcessor} — {@link AsyncJobTracker} bean 활성 시 wire. */
  @Bean
  @ConditionalOnBean(AsyncJobTracker.class)
  @ConditionalOnMissingBean(AsyncImageProcessor.class)
  public AsyncImageProcessor asyncImageProcessor(
      ImageStorageAdapter adapter, AsyncJobTracker tracker) {
    return new AsyncImageProcessor(adapter, tracker);
  }
}
