/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.presigned;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A6) — Presigned URL 완료 알림 입력. browser 가 PUT 완료 후
 * 본 endpoint 호출 → Asset PENDING → ACTIVE 전이.
 **/
public record PresignedCompleteCommand(
    Long assetId,
    String sha256,
    long actualSize,
    String ownerType,
    Object ownerId) {

  public PresignedCompleteCommand {
    if (assetId == null) {
      throw new IllegalArgumentException("assetId must not be null");
    }
    if (actualSize < 0) {
      throw new IllegalArgumentException("actualSize must not be negative");
    }
  }
}
