/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.storage.r2;

import io.rchemist.starter.asset.storage.ProviderUnavailableException;
import io.rchemist.starter.asset.storage.S3CompatStorage;
import io.rchemist.starter.asset.storage.StorageProvider;
import io.rchemist.starter.asset.storage.StorageProviderConfig;
import io.rchemist.starter.storage.core.Storage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — Cloudflare R2 provider. R2 = S3-compat, AWS SDK v2 사용.
 * endpoint 형식 = "https://{accountId}.r2.cloudflarestorage.com" + region = "auto".
 *
 * <p>"작은 프로젝트 = R2" — 사용자 명시 baseline (egress 비용 무료, S3-compat 100%).
 **/
public class CloudflareR2StorageProvider implements StorageProvider {

  @Override
  public String name() {
    return "r2";
  }

  @Override
  public Storage create(StorageProviderConfig config) {
    if (config.endpoint() == null || config.endpoint().isBlank()) {
      throw new IllegalArgumentException(
          "R2 endpoint required (https://{accountId}.r2.cloudflarestorage.com)");
    }
    StorageProviderConfig effective =
        new StorageProviderConfig(
            config.endpoint(),
            config.region() != null ? config.region() : "auto",
            config.accessKey(),
            config.secretKey(),
            config.bucket(),
            config.pathStyle());
    try {
      return new S3CompatStorage(effective, "r2");
    } catch (LinkageError e) {
      throw new ProviderUnavailableException(
          "AWS S3 SDK v2 (R2 = S3-compat) not on classpath", e);
    }
  }
}
