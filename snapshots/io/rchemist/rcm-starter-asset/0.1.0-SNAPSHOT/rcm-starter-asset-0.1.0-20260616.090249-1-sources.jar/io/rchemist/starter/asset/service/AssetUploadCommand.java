/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.service;

import java.io.InputStream;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — AssetService.upload 단일 통합 entry point 의 입력. WYSIWYG /
 * Article 첨부 / profile image 등 모든 업로드 케이스가 동일 Records 사용.
 *
 * <p>field:
 * <ul>
 *   <li>{@code content} — InputStream (caller 가 close 책임 — service 가 자동 close).</li>
 *   <li>{@code contentType} — declared MIME (예: image/jpeg). null = service 가 detect 시도.</li>
 *   <li>{@code originalName} — 업로드 시점의 원본 파일명 (key 와 다름).</li>
 *   <li>{@code sizeHint} — 알려진 크기 (검증 + Asset entity 기록). 0 = 미상.</li>
 *   <li>{@code ownerType} — Asset 을 소유할 도메인 entity 타입 (예: "article"). null = PENDING 으로
 *       저장 (presigned / UploadSession 사용 시 commit 단계에서 채움).</li>
 *   <li>{@code ownerId} — Owner entity ID (Long / UUID 모두). null OK.</li>
 *   <li>{@code extraMetadata} — Storage object metadata 에 포함될 user-defined attribute. null OK.</li>
 * </ul>
 **/
public record AssetUploadCommand(
    InputStream content,
    String contentType,
    String originalName,
    long sizeHint,
    String ownerType,
    Object ownerId,
    Map<String, Object> extraMetadata) {

  public AssetUploadCommand {
    if (content == null) {
      throw new IllegalArgumentException("content must not be null");
    }
    if (sizeHint < 0) {
      throw new IllegalArgumentException("sizeHint must not be negative: " + sizeHint);
    }
  }

  /** Owner 결정 안 된 시점의 PENDING upload 헬퍼. */
  public static AssetUploadCommand pending(
      InputStream content, String contentType, String originalName, long sizeHint) {
    return new AssetUploadCommand(
        content, contentType, originalName, sizeHint, null, null, null);
  }

  /** Owner 가 결정된 시점의 직접 ACTIVE upload 헬퍼. */
  public static AssetUploadCommand owned(
      InputStream content,
      String contentType,
      String originalName,
      long sizeHint,
      String ownerType,
      Object ownerId) {
    return new AssetUploadCommand(
        content, contentType, originalName, sizeHint, ownerType, ownerId, null);
  }
}
