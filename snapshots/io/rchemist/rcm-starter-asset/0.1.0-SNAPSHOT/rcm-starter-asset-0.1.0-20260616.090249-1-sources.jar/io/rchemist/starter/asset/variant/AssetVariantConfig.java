/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.variant;

import io.rchemist.starter.asset.image.core.ImageFormat;
import io.rchemist.starter.asset.image.core.ImageVariant;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A8) — Asset variant 기본 설정. defaultVariants + asyncThreshold.
 * Records first.
 *
 * <p>default 3종 — thumbnail (100×100 JPEG), medium (400×400 JPEG), large (1000×1000 PNG).
 * Consumer 가 yml {@code platform.asset.variant.*} 으로 override 가능 (별도 properties 영역).
 **/
public record AssetVariantConfig(
    List<ImageVariant> defaultVariants, long asyncThresholdBytes) {

  public AssetVariantConfig {
    if (defaultVariants == null) {
      defaultVariants = defaultThree();
    }
    if (asyncThresholdBytes < 0) {
      throw new IllegalArgumentException("asyncThresholdBytes must be non-negative");
    }
  }

  /** 기본 3 variant. */
  public static List<ImageVariant> defaultThree() {
    return List.of(
        ImageVariant.of("thumbnail", 100, 100, ImageFormat.JPEG),
        ImageVariant.of("medium", 400, 400, ImageFormat.JPEG),
        ImageVariant.of("large", 1000, 1000, ImageFormat.PNG));
  }

  /** Default config — 3 variants + 2MB async threshold. */
  public static AssetVariantConfig defaults() {
    return new AssetVariantConfig(defaultThree(), 2L * 1024 * 1024);
  }
}
