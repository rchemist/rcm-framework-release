/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.session;

import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A4) — UploadSession 시작 토큰. presigned URL 사용 안 하는 영역
 * 에서 PENDING asset + 만료 시각을 함께 가지는 sessionId 반환.
 *
 * <p>field:
 * <ul>
 *   <li>{@code sessionId} — 외부에 노출되는 UUID 토큰 (Asset.id 노출 회피).</li>
 *   <li>{@code assetId} — 내부 Asset entity ID (commit 시 사용).</li>
 *   <li>{@code key} — Storage object key (이미 reserved 됨).</li>
 *   <li>{@code expiresAt} — 만료 시각 (이후 OrphanCleanupJob 대상).</li>
 * </ul>
 **/
public record UploadSessionToken(
    String sessionId, Long assetId, String key, Instant expiresAt) {
}
