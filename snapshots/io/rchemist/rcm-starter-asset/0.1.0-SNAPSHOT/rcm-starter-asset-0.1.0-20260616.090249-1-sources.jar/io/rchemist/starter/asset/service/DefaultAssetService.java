/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.service;

import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.asset.entity.AssetVariant;
import io.rchemist.starter.asset.variant.AssetVariantPipeline;
import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.security.UploadValidator;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — AssetService 기본 구현. 단일 통합 upload flow.
 *
 * <p>upload 흐름:
 * <ol>
 *   <li>InputStream → byte[] (sha256 + size 계산 + UploadValidator 호출).</li>
 *   <li>Storage object key 생성 (KeyGenerator wired 시 multi-tenant prefix).</li>
 *   <li>Storage.put + Asset entity 등록 (status = ACTIVE 또는 PENDING).</li>
 *   <li>contentType startsWith "image/" 이면 AssetVariantPipeline 위임 (A8 — sync / async 분기).</li>
 *   <li>CdnUrlResolver.resolve → AssetUploadResult.url.</li>
 * </ol>
 *
 * <p>모든 collaborator 가 optional — KeyGenerator / UploadValidator / AssetVariantPipeline /
 * CdnUrlResolver null 안전 (graceful degradation).
 **/
public class DefaultAssetService implements AssetService {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultAssetService.class);
  private static final int HEADER_BYTES = 512;

  private final Storage storage;
  private final AssetRepository repository;
  private final KeyGenerator keyGenerator;
  private final UploadValidator validator;
  private final AssetVariantPipeline variantPipeline;
  private final CdnUrlResolver cdnResolver;

  public DefaultAssetService(
      Storage storage,
      AssetRepository repository,
      KeyGenerator keyGenerator,
      UploadValidator validator,
      AssetVariantPipeline variantPipeline,
      CdnUrlResolver cdnResolver) {
    if (storage == null) {
      throw new IllegalArgumentException("storage must not be null");
    }
    if (repository == null) {
      throw new IllegalArgumentException("repository must not be null");
    }
    this.storage = storage;
    this.repository = repository;
    this.keyGenerator = keyGenerator;
    this.validator = validator;
    this.variantPipeline = variantPipeline;
    this.cdnResolver = cdnResolver;
  }

  @Override
  public AssetUploadResult upload(AssetUploadCommand command) {
    if (command == null) {
      throw new IllegalArgumentException("command must not be null");
    }
    byte[] bytes = readAll(command.content());
    String sha256 = sha256Hex(bytes);
    long actualSize = bytes.length;

    if (validator != null) {
      byte[] header = headerBytes(bytes);
      validator.validate(command.originalName(), command.contentType(), actualSize, header);
    }

    String key = resolveKey(command);
    Map<String, Object> attrs = new LinkedHashMap<>();
    attrs.put("sha256", sha256);
    if (command.extraMetadata() != null) {
      attrs.putAll(command.extraMetadata());
    }
    Map<String, String> stringAttrs = new LinkedHashMap<>();
    attrs.forEach((k, v) -> stringAttrs.put(k, String.valueOf(v)));

    storage.put(
        key, new ByteArrayInputStream(bytes), command.contentType(), ObjectMetadata.of(stringAttrs));

    Asset asset = newAsset(command, key, sha256, actualSize);
    Asset saved = repository.save(asset);

    List<AssetVariantView> variants = List.of();
    if (variantPipeline != null && isImage(command.contentType())) {
      try {
        List<AssetVariant> generated =
            variantPipeline.process(storage, saved, bytes, command.contentType());
        variants = generated.stream()
            .map(v -> new AssetVariantView(
                v.getName(),
                resolveVariantUrl(saved, v),
                v.getWidth() != null ? v.getWidth() : 0,
                v.getHeight() != null ? v.getHeight() : 0,
                v.getSizeBytes()))
            .toList();
      } catch (RuntimeException e) {
        LOG.warn("variant pipeline failed (key={}): {}", key, e.getMessage());
      }
    }

    String url = resolveAssetUrl(saved);
    return new AssetUploadResult(saved, url, variants, attrs);
  }

  @Override
  public Optional<Asset> findById(Long id) {
    return repository.findById(id);
  }

  @Override
  public Optional<Asset> findByKey(String key) {
    return repository.findByKey(key);
  }

  @Override
  public List<Asset> getByOwner(String ownerType, Object ownerId) {
    return repository.getByOwnerTypeAndOwnerId(ownerType, ownerId != null ? ownerId.toString() : null);
  }

  @Override
  public void delete(Long id) {
    repository.findById(id).ifPresent(a -> {
      a.setStatus(AssetStatus.DELETED);
      repository.save(a);
      // Hibernate 7 @SoftDelete 가 SELECT 자동 차단. hard delete 는 OrphanCleanupJob 또는
      // 별도 admin job 에서 수행.
      repository.delete(a);
    });
  }

  private Asset newAsset(AssetUploadCommand command, String key, String sha256, long size) {
    boolean ownerKnown = command.ownerType() != null && command.ownerId() != null;
    Asset asset =
        ownerKnown
            ? Asset.active(key, size, command.contentType())
            : Asset.pending(key, size, command.contentType(), null);
    asset.setSha256(sha256);
    asset.setOriginalName(command.originalName());
    if (ownerKnown) {
      asset.setOwnerType(command.ownerType());
      asset.setOwnerId(command.ownerId().toString());
    }
    return asset;
  }

  private String resolveKey(AssetUploadCommand command) {
    String filename = command.originalName() != null ? command.originalName() : "asset";
    if (keyGenerator != null) {
      return keyGenerator.generate(filename);
    }
    return "assets/" + java.util.UUID.randomUUID() + "-" + filename;
  }

  private String resolveAssetUrl(Asset asset) {
    if (cdnResolver != null) {
      String url = cdnResolver.resolve(asset);
      if (url != null) {
        return url;
      }
    }
    return asset.getKey();
  }

  private String resolveVariantUrl(Asset asset, AssetVariant variant) {
    if (cdnResolver != null) {
      String url = cdnResolver.resolveVariant(asset, variant);
      if (url != null) {
        return url;
      }
    }
    return variant.getKey();
  }

  private static boolean isImage(String contentType) {
    return contentType != null && contentType.toLowerCase().startsWith("image/");
  }

  private static byte[] readAll(InputStream in) {
    try (InputStream stream = in) {
      return stream.readAllBytes();
    } catch (IOException e) {
      throw new AssetUploadException("source read failed: " + e.getMessage(), e);
    }
  }

  private static byte[] headerBytes(byte[] bytes) {
    int len = Math.min(HEADER_BYTES, bytes.length);
    byte[] header = new byte[len];
    System.arraycopy(bytes, 0, header, 0, len);
    return header;
  }

  private static String sha256Hex(byte[] bytes) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      return HexFormat.of().formatHex(md.digest(bytes));
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("SHA-256 unavailable on JDK", e);
    }
  }
}
