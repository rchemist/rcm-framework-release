/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.service;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — AssetService 의 일반 실패 (storage I/O / hash 계산 / 기타).
 * UploadValidationException (security) 과는 별도.
 **/
public class AssetUploadException extends RuntimeException {

  public AssetUploadException(String message) {
    super(message);
  }

  public AssetUploadException(String message, Throwable cause) {
    super(message, cause);
  }
}
