/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — 이미지 variant spec (Records first). 하나의 source 이미지로부터 생성할
 * resize / format-convert 결과의 명세.
 *
 * @param name     variant 식별 이름 (e.g. {@code thumbnail}, {@code medium}, {@code large}). storage
 *                 key naming 에 사용 ({@code {key}.{name}.{ext}}).
 * @param width    target width (pixel, &gt; 0).
 * @param height   target height (pixel, &gt; 0).
 * @param format   target format (null 가능 — null 이면 source format 유지).
 * @param quality  output quality (1~100, JPEG / WebP 영역. PNG / GIF 무시).
 * @param fit      종횡비 처리 정책 (default {@link ImageFit#COVER}).
 */
public record ImageVariant(
    String name, int width, int height, ImageFormat format, int quality, ImageFit fit) {

  /** compact constructor — 입력 검증 + null 안전 default. */
  public ImageVariant {
    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("name must not be blank");
    }
    if (width <= 0) {
      throw new IllegalArgumentException("width must be positive: " + width);
    }
    if (height <= 0) {
      throw new IllegalArgumentException("height must be positive: " + height);
    }
    if (quality < 1 || quality > 100) {
      throw new IllegalArgumentException("quality out of range [1,100]: " + quality);
    }
    if (fit == null) {
      fit = ImageFit.COVER;
    }
  }

  /** 간편 factory — quality default 85 + fit default COVER. */
  public static ImageVariant of(String name, int width, int height, ImageFormat format) {
    return new ImageVariant(name, width, height, format, 85, ImageFit.COVER);
  }

  /** 간편 factory — source format 유지 + quality default 85 + fit default COVER. */
  public static ImageVariant of(String name, int width, int height) {
    return new ImageVariant(name, width, height, null, 85, ImageFit.COVER);
  }
}
