/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.entity;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Asset CRUD repository. Spring Data JPA 표준 — 추가 query 메서드는
 * 도메인 사용 패턴에 맞춰 생성 (key UNIQUE / owner 조회 / orphan cleanup).
 *
 * <p>naming 컨벤션 (Decision #20 + misc/readme.md 적용):
 * <ul>
 *   <li>{@code findByKey} — UNIQUE 단일 결과 → Optional (caller 가 NotFound 처리)</li>
 *   <li>{@code getByOwnerTypeAndOwnerId} — 복수 결과 → List (없으면 빈 list)</li>
 *   <li>{@code getByStatusAndExpiresAtBefore} — orphan cleanup 용 (PENDING + 만료 시각)</li>
 * </ul>
 **/
public interface AssetRepository extends JpaRepository<Asset, Long> {

  /** Storage key 로 단일 조회 — UNIQUE 제약 정합. */
  Optional<Asset> findByKey(String key);

  /** Owner 기반 모든 asset 조회 (없으면 빈 list). */
  List<Asset> getByOwnerTypeAndOwnerId(String ownerType, String ownerId);

  /** Tenant + status 기반 paged 조회 (관리 화면 용). multi-tenant 미사용 시에도 동작. */
  Page<Asset> findByStatus(AssetStatus status, Pageable pageable);

  /** Orphan cleanup — 지정 status (보통 PENDING) + 만료 시각 이전. */
  List<Asset> getByStatusAndExpiresAtBefore(AssetStatus status, Instant cutoff);
}
