/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.storage;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — Storage provider 의 endpoint / 자격증명 / bucket 입력.
 * S3-compat (AWS / R2 / MinIO) provider 가 동일하게 사용. Records first.
 *
 * <p>provider 별 endpoint 패턴:
 * <ul>
 *   <li>AWS — null 또는 "https://s3.{region}.amazonaws.com" (region = us-east-1 등).</li>
 *   <li>R2 — "https://{accountId}.r2.cloudflarestorage.com" (region = "auto").</li>
 *   <li>MinIO — self-hosted URL ("https://minio.example.com:9000"). pathStyle=true.</li>
 * </ul>
 **/
public record StorageProviderConfig(
    String endpoint,
    String region,
    String accessKey,
    String secretKey,
    String bucket,
    boolean pathStyle) {

  public StorageProviderConfig {
    if (bucket == null || bucket.isBlank()) {
      throw new IllegalArgumentException("bucket must not be blank");
    }
  }
}
