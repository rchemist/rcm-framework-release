/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetVariant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — CDN URL 해석 SPI. Provider 패턴 (CloudFront / Cloudflare /
 * Noop) baseline + Consumer 가 추가 provider 등록 가능 (ServiceLoader).
 *
 * <p>설계 원칙 (사용자 명시 2026-05-04 준수): "S3 구현체는 provider 패턴으로 계속 추가하거나
 * 선택적으로 적용. 작은 = R2, 큰 = AWS S3 또는 MinIO". CDN 도 동일 패턴.
 **/
public interface CdnUrlResolver {

  /** Provider 식별 이름 (예: cloudfront / cloudflare / noop). */
  String name();

  /** Asset 의 원본 (또는 variant 미지원) URL 해석. null = caller 가 fallback. */
  String resolve(Asset asset);

  /** Variant 의 URL 해석. default = variant.key 그대로 사용. */
  default String resolveVariant(Asset asset, AssetVariant variant) {
    return variant != null ? variant.getKey() : null;
  }
}
