/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.service;

import io.rchemist.starter.asset.entity.Asset;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Asset application API. *모든 업로드 프로세스의 단일 entry
 * point*. WYSIWYG / 첨부파일 / profile image / API 직접 호출 모두 동일 service 사용.
 *
 * <p>설계 원칙 (사용자 통찰 2026-05-04 준수):
 * <ul>
 *   <li>**WYSIWYG-specific adapter 영구 거부** — File + 대상 entity + 추가 정보 → 백엔드 처리 →
 *       실제 asset 접근 경로 리턴. WYSIWYG 별 wire protocol 은 Consumer controller 책임.</li>
 *   <li>**Provider 비중립** — Storage SPI 위, CDN SPI 위. AWS / R2 / MinIO 모두 동일 동작.</li>
 *   <li>**Asset 1st-class** — entity 자체로 역추적 가능 + lifecycle 관리.</li>
 * </ul>
 **/
public interface AssetService {

  /** 단일 통합 upload — content + owner + extra 만 받으면 모든 처리 자동. */
  AssetUploadResult upload(AssetUploadCommand command);

  /** ID 단일 조회 — 존재 안 하면 Optional.empty. */
  Optional<Asset> findById(Long id);

  /** Storage key 단일 조회. */
  Optional<Asset> findByKey(String key);

  /** Owner 기반 모든 asset 조회 (없으면 빈 list). */
  List<Asset> getByOwner(String ownerType, Object ownerId);

  /** Soft-delete (status = DELETED + Hibernate 7 @SoftDelete). */
  void delete(Long id);
}
