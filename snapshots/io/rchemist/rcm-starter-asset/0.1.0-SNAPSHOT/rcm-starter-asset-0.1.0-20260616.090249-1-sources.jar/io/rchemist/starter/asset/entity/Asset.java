/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.entity;

import io.rchemist.core.marker.Auditable;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.SoftDelete;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Asset 1st-class entity. 모든 업로드 프로세스의 핵심 도메인.
 * 이미지 / 첨부파일 / WYSIWYG / presigned URL 등 모든 경로에서 동일하게 등록됨.
 *
 * <p>핵심 필드:
 * <ul>
 *   <li>{@code key} — Storage object key (provider 비중립). UNIQUE.</li>
 *   <li>{@code sha256} — content fingerprint (중복 검출 / integrity).</li>
 *   <li>{@code ownerType / ownerId} — Asset 을 소유한 도메인 entity (예: "article" / 123L). PENDING
 *       단계에서는 null 가능 (UploadSession.commit 시 채워짐).</li>
 *   <li>{@code status} — {@link AssetStatus} (PENDING / ACTIVE / SCANNING / QUARANTINED /
 *       EXPIRED / DELETED).</li>
 *   <li>{@code variants} — 1:N {@link AssetVariant} (image 의 thumbnail / medium / large).
 *       sync = upload 시 즉시, async = AsyncJobTracker 위임.</li>
 *   <li>{@code expiresAt} — PENDING TTL (OrphanCleanupJob 대상).</li>
 *   <li>{@code width / height} — image 만 사용 (다른 contentType 은 null).</li>
 * </ul>
 *
 * <p>{@code @SoftDelete(columnName = "IS_DELETED")} (Hibernate 7 native) — DELETE 가 자동 update 로
 * 변환. 모든 SELECT 에 자동 predicate 적용. column 명은 컨벤션 (boolean = {@code IS_*} prefix +
 * UPPER_SNAKE, misc/readme.md §2.1.1.6) 정합. {@link #status} 를 추가로 DELETED 로 표시 = 명시적
 * lifecycle 전이.
 *
 * <p>tenant — 본 entity 는 *non-multi-tenant default*. multi-tenant Consumer 는 {@code @TenantId}
 * 자체 추가하거나 KeyGenerator 의 prefix 만 의존. (T3 baseline = simple, multi-tenant 는 Phase 3
 * 의 기존 marker 적용 옵션.)
 **/
@Entity
@Table(
    name = "T_ASSET",
    comment = "Asset — 업로드된 모든 파일의 1st-class entity (image / 첨부 / WYSIWYG / presigned 통합)",
    indexes = {
      @Index(name = "IDX_ASSET_KEY", columnList = "OBJECT_KEY", unique = true),
      @Index(name = "IDX_ASSET_OWNER", columnList = "OWNER_TYPE,OWNER_ID"),
      @Index(name = "IDX_ASSET_STATUS_EXPIRES", columnList = "STATUS,EXPIRES_AT")
    })
@EntityListeners(AuditingEntityListener.class)
@SoftDelete(columnName = "IS_DELETED")

@Getter
@Setter
@NoArgsConstructor
public class Asset implements Auditable {

  @Id
  @GeneratedValue
  @Column(name = "ASSET_ID", nullable = false, comment = "Asset 식별자 (PK)")
  private Long id;

  @Column(name = "OWNER_TYPE", length = 64,
      comment = "Asset 을 소유한 도메인 entity 타입 (예: article / user-profile). PENDING 시 null 가능")
  private String ownerType;

  @Column(name = "OWNER_ID", length = 64,
      comment = "Owner entity 의 ID (Long / UUID 모두 String 으로 보존). PENDING 시 null 가능")
  private String ownerId;

  @Column(name = "OBJECT_KEY", length = 1024, nullable = false,
      comment = "Storage object key (S3 path / local FS path / R2 key). UNIQUE")
  private String key;

  @Column(name = "SHA256", length = 64, comment = "Content SHA-256 hex (중복 검출 + integrity 검증)")
  private String sha256;

  @Column(name = "SIZE_BYTES", nullable = false, comment = "Bytes 단위 크기")
  private long size;

  @Column(name = "CONTENT_TYPE", length = 128, comment = "MIME (예: image/jpeg, application/pdf)")
  private String contentType;

  @Column(name = "ORIGINAL_NAME", length = 255, comment = "업로드 시점의 원본 파일명")
  private String originalName;

  @Enumerated(EnumType.STRING)
  @Column(name = "STATUS", length = 16, nullable = false,
      comment = "Asset lifecycle 상태 (PENDING / ACTIVE / SCANNING / QUARANTINED / EXPIRED / DELETED)")
  private AssetStatus status;

  @Column(name = "SCAN_RESULT", length = 255,
      comment = "Virus scan 결과 (예: clean / infected:Eicar-Test-Signature). null = 미scan")
  private String scanResult;

  @Column(name = "WIDTH", comment = "Image width (image 만 사용, 다른 type 은 null)")
  private Integer width;

  @Column(name = "HEIGHT", comment = "Image height (image 만 사용, 다른 type 은 null)")
  private Integer height;

  @Column(name = "EXPIRES_AT",
      comment = "PENDING / temp asset 의 만료 시각 (OrphanCleanupJob 대상). ACTIVE 는 null")
  private Instant expiresAt;

  @CreatedDate
  @Column(name = "CREATED_AT", updatable = false)
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY", length = 64, updatable = false)
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY", length = 64)
  private String updatedBy;

  @OneToMany(mappedBy = "asset", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<AssetVariant> variants = new ArrayList<>();

  /** 신규 ACTIVE asset 생성 헬퍼 (status default + expiresAt = null). */
  public static Asset active(String key, long size, String contentType) {
    Asset asset = new Asset();
    asset.setKey(key);
    asset.setSize(size);
    asset.setContentType(contentType);
    asset.setStatus(AssetStatus.ACTIVE);
    return asset;
  }

  /** 신규 PENDING asset 생성 헬퍼 (UploadSession / presigned 시작 시점). */
  public static Asset pending(String key, long sizeHint, String contentType, Instant expiresAt) {
    Asset asset = new Asset();
    asset.setKey(key);
    asset.setSize(sizeHint);
    asset.setContentType(contentType);
    asset.setStatus(AssetStatus.PENDING);
    asset.setExpiresAt(expiresAt);
    return asset;
  }

  /** Variant 추가 — 양방향 정합 자동. */
  public void addVariant(AssetVariant variant) {
    if (variant == null) {
      throw new IllegalArgumentException("variant must not be null");
    }
    variants.add(variant);
    variant.setAsset(this);
  }

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }
}
