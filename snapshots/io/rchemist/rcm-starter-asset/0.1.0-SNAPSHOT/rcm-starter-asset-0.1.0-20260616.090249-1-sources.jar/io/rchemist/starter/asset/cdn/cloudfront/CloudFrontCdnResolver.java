/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.cdn.cloudfront;

import io.rchemist.starter.asset.cdn.CdnProperties;
import io.rchemist.starter.asset.cdn.CdnUrlResolver;
import io.rchemist.starter.asset.cdn.CdnUrlResolverProvider;
import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetVariant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A5) — AWS CloudFront CDN provider. baseUrl 기반 URL prefix.
 *
 * <p>signed URL = 옵션 (private content). baseline = public path-based. signed URL 활성 시
 * AWS SDK CloudFront signing 사용 (compileOnly — 미입주 시 baseline path-based fallback).
 **/
public class CloudFrontCdnResolver implements CdnUrlResolver {

  private final String baseUrl;
  private final boolean signed;

  public CloudFrontCdnResolver(CdnProperties properties) {
    if (properties == null || properties.baseUrl() == null || properties.baseUrl().isBlank()) {
      throw new IllegalArgumentException(
          "CloudFront baseUrl required (e.g. https://d1xxxxx.cloudfront.net)");
    }
    this.baseUrl = properties.baseUrl();
    this.signed = properties.signedUrl();
  }

  @Override
  public String name() {
    return "cloudfront";
  }

  @Override
  public String resolve(Asset asset) {
    if (asset == null) {
      return null;
    }
    String url = join(baseUrl, asset.getKey());
    return signed ? appendSigningPlaceholder(url) : url;
  }

  @Override
  public String resolveVariant(Asset asset, AssetVariant variant) {
    if (variant == null) {
      return null;
    }
    String url = join(baseUrl, variant.getKey());
    return signed ? appendSigningPlaceholder(url) : url;
  }

  /** signed URL 옵션 — baseline 은 query placeholder, 실제 signing 은 Consumer 가 SDK 로 wrap. */
  private static String appendSigningPlaceholder(String url) {
    return url + (url.contains("?") ? "&" : "?") + "signed=placeholder";
  }

  private static String join(String base, String key) {
    String b = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
    String k = key.startsWith("/") ? key : "/" + key;
    return b + k;
  }

  /** ServiceLoader 등록용 provider. */
  public static class Provider implements CdnUrlResolverProvider {
    @Override
    public String name() {
      return "cloudfront";
    }

    @Override
    public CdnUrlResolver create(CdnProperties properties) {
      return new CloudFrontCdnResolver(properties);
    }
  }
}
