/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.presigned;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.asset.variant.AssetVariantPipeline;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.s3.PresignedMethod;
import io.rchemist.starter.storage.s3.PresignedUrl;
import io.rchemist.starter.storage.s3.PresignedUrlIssuer;
import io.rchemist.starter.storage.tenant.KeyGenerator;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A6) — Presigned URL 흐름. browser direct upload (front-end →
 * Storage 직접). request → ticket / complete → ACTIVE 전이 + variant 자동 생성.
 *
 * <p>흐름:
 * <ol>
 *   <li>request(PresignedUploadCommand) — Asset PENDING 등록 + PresignedUrlIssuer.issue PUT URL.</li>
 *   <li>browser 가 ticket.presignedUrl 으로 PUT (framework 외부).</li>
 *   <li>complete(PresignedCompleteCommand) — Asset ACTIVE 전이 + sha256 / size 업데이트.</li>
 * </ol>
 **/
public class PresignedUploadService {

  private final AssetRepository repository;
  private final PresignedUrlIssuer urlIssuer;
  private final KeyGenerator keyGenerator;
  private final Storage storage;
  private final AssetVariantPipeline variantPipeline;
  private final Duration ttl;

  public PresignedUploadService(
      AssetRepository repository,
      PresignedUrlIssuer urlIssuer,
      KeyGenerator keyGenerator,
      Storage storage,
      AssetVariantPipeline variantPipeline,
      Duration ttl) {
    if (repository == null) {
      throw new IllegalArgumentException("repository must not be null");
    }
    if (urlIssuer == null) {
      throw new IllegalArgumentException("urlIssuer must not be null");
    }
    if (ttl == null || ttl.isZero() || ttl.isNegative()) {
      throw new IllegalArgumentException("ttl must be positive");
    }
    this.repository = repository;
    this.urlIssuer = urlIssuer;
    this.keyGenerator = keyGenerator;
    this.storage = storage;
    this.variantPipeline = variantPipeline;
    this.ttl = ttl;
  }

  /** Presigned URL 발급 + Asset PENDING 등록. */
  public PresignedUploadTicket request(PresignedUploadCommand command) {
    if (command == null) {
      throw new IllegalArgumentException("command must not be null");
    }
    Instant expiresAt = Instant.now().plus(ttl);
    String key = resolveKey(command.originalName());
    Asset asset = Asset.pending(key, command.sizeHint(), command.contentType(), expiresAt);
    asset.setOriginalName(command.originalName());
    if (command.ownerType() != null && command.ownerId() != null) {
      asset.setOwnerType(command.ownerType());
      asset.setOwnerId(command.ownerId().toString());
    }
    Asset saved = repository.save(asset);

    PresignedUrl url = urlIssuer.issue(key, PresignedMethod.PUT, ttl);

    Map<String, String> requiredHeaders = new LinkedHashMap<>();
    if (command.contentType() != null) {
      requiredHeaders.put("Content-Type", command.contentType());
    }
    return new PresignedUploadTicket(
        url.url(), url.method().name(), key, saved.getId(), expiresAt, requiredHeaders);
  }

  /** browser 의 PUT 완료 후 호출 — Asset ACTIVE 전이 + (옵션) variant 자동 생성. */
  public Asset complete(PresignedCompleteCommand command) {
    if (command == null) {
      throw new IllegalArgumentException("command must not be null");
    }
    Asset asset =
        repository.findById(command.assetId())
            .orElseThrow(() -> new NoSuchElementException("asset not found: " + command.assetId()));
    if (asset.getStatus() != AssetStatus.PENDING) {
      throw new IllegalStateException(
          "asset is not PENDING (status=" + asset.getStatus() + ")");
    }
    if (asset.getExpiresAt() != null && asset.getExpiresAt().isBefore(Instant.now())) {
      throw new IllegalStateException("ticket expired at " + asset.getExpiresAt());
    }
    asset.setStatus(AssetStatus.ACTIVE);
    asset.setExpiresAt(null);
    asset.setSha256(command.sha256());
    if (command.actualSize() > 0) {
      asset.setSize(command.actualSize());
    }
    if (command.ownerType() != null && command.ownerId() != null) {
      asset.setOwnerType(command.ownerType());
      asset.setOwnerId(command.ownerId().toString());
    }
    Asset saved = repository.save(asset);

    // Variant 자동 생성 — image 인 경우만 + storage / pipeline 모두 wired 시.
    // PresignedUploadService 는 raw bytes 가 없어 storage.open(key) 으로 다운로드 후 pipeline 호출.
    if (variantPipeline != null
        && storage != null
        && saved.getContentType() != null
        && saved.getContentType().toLowerCase().startsWith("image/")) {
      try (var in = storage.open(saved.getKey())) {
        byte[] sourceBytes = in.readAllBytes();
        variantPipeline.process(storage, saved, sourceBytes, saved.getContentType());
      } catch (Exception ignored) {
        // variant 생성 실패 = 정상 ACTIVE 영향 X (fail-soft).
      }
    }
    return saved;
  }

  /** TTL 노출 (테스트 / 디버그). */
  public Duration ttl() {
    return ttl;
  }

  private String resolveKey(String originalName) {
    String name = originalName != null ? originalName : "presigned";
    if (keyGenerator != null) {
      return keyGenerator.generate(name);
    }
    return "presigned/" + UUID.randomUUID() + "-" + name;
  }
}
