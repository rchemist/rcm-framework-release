/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.variant;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetVariant;
import io.rchemist.starter.asset.image.async.AsyncImageProcessor;
import io.rchemist.starter.asset.image.core.ImageVariant;
import io.rchemist.starter.asset.image.storage.ImageStorageAdapter;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A8) — Default AssetVariantPipeline. ImageStorageAdapter (sync)
 * 또는 AsyncImageProcessor (async) 분기. 분기 기준 = config.asyncThresholdBytes (default 2MB).
 *
 * <p>흐름:
 * <ol>
 *   <li>contentType startsWith "image/" 가 아니면 빈 list (caller 가 호출 전 분기, 본 layer
 *       는 graceful fallback).</li>
 *   <li>sourceBytes.length &lt; threshold 또는 AsyncImageProcessor null = sync (즉시 ImageStorageAdapter
 *       호출 + AssetVariant entity 부착).</li>
 *   <li>이상 = async (AsyncImageProcessor.processBatch 위임 — JobTracker 가 진행률 update).</li>
 * </ol>
 **/
public class DefaultAssetVariantPipeline implements AssetVariantPipeline {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultAssetVariantPipeline.class);

  private final ImageStorageAdapter syncAdapter;
  private final AsyncImageProcessor asyncProcessor;
  private final AssetVariantConfig config;

  public DefaultAssetVariantPipeline(
      ImageStorageAdapter syncAdapter,
      AsyncImageProcessor asyncProcessor,
      AssetVariantConfig config) {
    if (syncAdapter == null) {
      throw new IllegalArgumentException("syncAdapter must not be null");
    }
    if (config == null) {
      throw new IllegalArgumentException("config must not be null");
    }
    this.syncAdapter = syncAdapter;
    this.asyncProcessor = asyncProcessor;
    this.config = config;
  }

  @Override
  public List<AssetVariant> process(
      Storage storage, Asset asset, byte[] sourceBytes, String contentType) {
    if (contentType == null || !contentType.toLowerCase().startsWith("image/")) {
      return List.of();
    }
    boolean async =
        asyncProcessor != null
            && config.asyncThresholdBytes() > 0
            && sourceBytes.length >= config.asyncThresholdBytes();
    if (async) {
      // Async dispatch — variant entity 는 즉시 부착 안 됨 (job 완료 후 별도 update 가 필요).
      // 본 baseline = job 등록 후 빈 list 반환 (Consumer 는 job 진행률 polling 후 별도 update).
      try {
        List<AsyncImageProcessor.BatchItem> items = List.of(
            new AsyncImageProcessor.BatchItem(
                asset.getKey(), contentType, new ByteArrayInputStream(sourceBytes)));
        asyncProcessor.processBatch(storage, items, config.defaultVariants());
        return List.of();
      } catch (RuntimeException e) {
        LOG.warn("async dispatch failed (key={}): {} — fallback sync", asset.getKey(), e.getMessage());
      }
    }
    return processSync(storage, asset, sourceBytes, contentType);
  }

  private List<AssetVariant> processSync(
      Storage storage, Asset asset, byte[] sourceBytes, String contentType) {
    Map<String, StorageObject> stored;
    try {
      stored =
          syncAdapter.processAndStore(
              storage,
              asset.getKey(),
              contentType,
              new ByteArrayInputStream(sourceBytes),
              config.defaultVariants());
    } catch (RuntimeException e) {
      LOG.warn("sync variant pipeline failed (key={}): {}", asset.getKey(), e.getMessage());
      return List.of();
    }
    List<AssetVariant> result = new ArrayList<>();
    for (ImageVariant spec : config.defaultVariants()) {
      StorageObject obj = stored.get(spec.name());
      if (obj == null) {
        continue;
      }
      AssetVariant v = AssetVariant.of(
          spec.name(),
          obj.key(),
          spec.width(),
          spec.height(),
          spec.format() != null ? spec.format().name() : null,
          obj.size());
      asset.addVariant(v);
      result.add(v);
    }
    return result;
  }
}
