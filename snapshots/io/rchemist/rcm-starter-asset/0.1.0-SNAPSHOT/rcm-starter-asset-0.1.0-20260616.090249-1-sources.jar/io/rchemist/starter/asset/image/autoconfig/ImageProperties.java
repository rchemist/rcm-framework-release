/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (Decision #29 Q1) — {@code platform.image.*} prefix 의 baseline yml
 * binding. {@link ImageAutoConfiguration} 의 단일 진입점 — Records first.
 *
 * <p>속성 영역:
 * <ul>
 *   <li>{@code enabled} — autoconfig 자체 opt-out flag (default true).</li>
 *   <li>{@code defaultQuality} — JPEG / WebP 변환 시 default quality (1~100, default 85).</li>
 *   <li>{@code maxSourcePixels} — 단일 이미지 source 의 최대 pixel 수 (memory 폭발 방지, default
 *       100M = 10000x10000).</li>
 *   <li>{@code preserveExif} — EXIF metadata 보존 여부 (default false — 회전 normalize 후 제거).</li>
 *   <li>{@code variantKeyPattern} — variant 저장 시 key naming 패턴 (default
 *       {@code "{key}.{variant}.{ext}"}).</li>
 * </ul>
 */
@ConfigurationProperties("platform.image")
public record ImageProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("85") int defaultQuality,
    @DefaultValue("100000000") long maxSourcePixels,
    @DefaultValue("false") boolean preserveExif,
    @DefaultValue("{key}.{variant}.{ext}") String variantKeyPattern) {

  /** compact constructor — 입력 검증 (out-of-range 차단). */
  public ImageProperties {
    if (defaultQuality < 1 || defaultQuality > 100) {
      throw new IllegalArgumentException(
          "defaultQuality out of range [1,100]: " + defaultQuality);
    }
    if (maxSourcePixels <= 0) {
      throw new IllegalArgumentException("maxSourcePixels must be positive: " + maxSourcePixels);
    }
    if (variantKeyPattern == null || variantKeyPattern.isBlank()) {
      throw new IllegalArgumentException("variantKeyPattern must not be blank");
    }
  }
}
