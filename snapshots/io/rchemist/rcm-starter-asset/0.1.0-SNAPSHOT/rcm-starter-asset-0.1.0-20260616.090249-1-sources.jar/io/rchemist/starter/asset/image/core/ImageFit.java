/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — resize 시 종횡비 처리 정책. CSS {@code object-fit} / Sharp.js 패턴 정합.
 *
 * <ul>
 *   <li>{@link #COVER} — 종횡비 유지, target 영역 전체 채움 (남는 영역은 crop).</li>
 *   <li>{@link #CONTAIN} — 종횡비 유지, target 영역 안 fit (letterbox 영역 발생 가능).</li>
 *   <li>{@link #FILL} — 종횡비 무시, target 정확 fit (왜곡 발생 가능).</li>
 *   <li>{@link #INSIDE} — CONTAIN 동일하되, source 가 더 작으면 확대 X (downscale only).</li>
 *   <li>{@link #OUTSIDE} — COVER 동일하되, source 가 더 작으면 확대 X (downscale only).</li>
 * </ul>
 */
public enum ImageFit {
  COVER,
  CONTAIN,
  FILL,
  INSIDE,
  OUTSIDE
}
