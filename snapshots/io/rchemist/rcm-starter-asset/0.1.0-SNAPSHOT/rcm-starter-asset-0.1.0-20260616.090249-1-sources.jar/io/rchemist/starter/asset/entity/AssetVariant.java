/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Asset 의 variant (image 의 thumbnail / medium / large 등).
 * 1:N child entity. variant 자체도 Storage 에 별도 저장 → key 보존.
 *
 * <p>도메인 가정 — image 만 variant 가짐 (기타 contentType 은 variant 0). 향후 video / audio 의
 * thumbnail 도 동일 패턴 확장 가능.
 **/
@Entity
@Table(
    name = "T_ASSET_VARIANT",
    comment = "Asset variant — image 의 thumbnail / medium / large 등",
    indexes = {@Index(name = "IDX_ASSET_VARIANT_ASSET", columnList = "ASSET_ID")})
@Getter
@Setter
@NoArgsConstructor
public class AssetVariant {

  @Id
  @GeneratedValue
  @Column(name = "VARIANT_ID", nullable = false, comment = "Variant 식별자 (PK)")
  private Long id;

  // EAGER fetch — Hibernate 7 제약: @SoftDelete entity 는 LAZY @ManyToOne 으로 참조 불가.
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ASSET_ID", nullable = false, comment = "부모 Asset (FK)")
  private Asset asset;

  @Column(name = "NAME", length = 64, nullable = false,
      comment = "Variant 이름 (예: thumbnail / medium / large)")
  private String name;

  @Column(name = "OBJECT_KEY", length = 1024, nullable = false,
      comment = "Variant 의 Storage object key")
  private String key;

  @Column(name = "WIDTH", comment = "Variant width (px)")
  private Integer width;

  @Column(name = "HEIGHT", comment = "Variant height (px)")
  private Integer height;

  @Column(name = "FORMAT", length = 16, comment = "Variant 포맷 (jpeg / png / webp 등)")
  private String format;

  @Column(name = "SIZE_BYTES", nullable = false, comment = "Variant 의 bytes 크기")
  private long sizeBytes;

  /** Builder helper — name + key + 차원 + 크기. */
  public static AssetVariant of(
      String name, String key, Integer width, Integer height, String format, long sizeBytes) {
    AssetVariant v = new AssetVariant();
    v.setName(name);
    v.setKey(key);
    v.setWidth(width);
    v.setHeight(height);
    v.setFormat(format);
    v.setSizeBytes(sizeBytes);
    return v;
  }
}
