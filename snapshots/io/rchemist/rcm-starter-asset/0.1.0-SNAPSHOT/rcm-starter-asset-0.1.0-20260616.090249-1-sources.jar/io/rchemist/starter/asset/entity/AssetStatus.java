/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.entity;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Asset lifecycle 상태. Asset entity 의 핵심 status field.
 *
 * <p>전이 매트릭스:
 * <ul>
 *   <li>{@link #PENDING} → {@link #ACTIVE} (UploadSession.commit 또는 직접 upload 성공)</li>
 *   <li>{@link #PENDING} → {@link #EXPIRED} (TTL 초과 후 OrphanCleanupJob)</li>
 *   <li>{@link #ACTIVE} → {@link #SCANNING} (AssetPostProcessor 가 virus scan 비동기 시작)</li>
 *   <li>{@link #SCANNING} → {@link #ACTIVE} 또는 {@link #QUARANTINED} (scan 결과 적용)</li>
 *   <li>{@link #ACTIVE} → {@link #DELETED} (soft-delete, AssetService.delete)</li>
 * </ul>
 **/
public enum AssetStatus {

  /** 임시 업로드 — Owner 미확정 (presigned URL 또는 UploadSession 으로 생성). TTL 후 cleanup 대상. */
  PENDING,

  /** 정상 (사용 가능). */
  ACTIVE,

  /** Virus scan 진행 중 (비동기). 완료 시 ACTIVE 또는 QUARANTINED 로 전이. */
  SCANNING,

  /** Virus scan 결과 격리 — 다운로드 / serving 차단. */
  QUARANTINED,

  /** Orphan TTL 초과 — OrphanCleanupJob 이 hard-delete 직전 표시. */
  EXPIRED,

  /** Soft-delete. */
  DELETED
}
