/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.image.core;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 — 처리 완료된 이미지 결과 (Records first). {@link
 * ImageProcessor#resize}/{@link ImageProcessor#crop}/{@link ImageProcessor#convert} 등이 반환.
 *
 * @param bytes      처리 결과 byte array (encoded). caller 가 Storage put / HTTP body 등에 사용.
 * @param format     실제 인코딩 포맷.
 * @param width      처리 후 width (pixel).
 * @param height     처리 후 height (pixel).
 * @param sizeBytes  byte array 길이 (편의 — {@code bytes.length}).
 */
public record ProcessedImage(byte[] bytes, ImageFormat format, int width, int height, long sizeBytes) {

  /** compact constructor — 입력 검증. */
  public ProcessedImage {
    if (bytes == null || bytes.length == 0) {
      throw new IllegalArgumentException("bytes must not be empty");
    }
    if (format == null) {
      throw new IllegalArgumentException("format must not be null");
    }
    if (width <= 0) {
      throw new IllegalArgumentException("width must be positive: " + width);
    }
    if (height <= 0) {
      throw new IllegalArgumentException("height must be positive: " + height);
    }
    if (sizeBytes < 0) {
      throw new IllegalArgumentException("sizeBytes negative: " + sizeBytes);
    }
  }

  /** Convenience factory — sizeBytes 자동 set ({@code bytes.length}). */
  public static ProcessedImage of(byte[] bytes, ImageFormat format, int width, int height) {
    return new ProcessedImage(bytes, format, width, height, bytes.length);
  }
}
