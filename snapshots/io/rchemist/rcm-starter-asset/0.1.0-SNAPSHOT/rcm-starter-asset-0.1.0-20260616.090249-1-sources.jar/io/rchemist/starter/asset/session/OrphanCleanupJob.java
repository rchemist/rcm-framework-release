/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.asset.session;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.entity.AssetRepository;
import io.rchemist.starter.asset.entity.AssetStatus;
import io.rchemist.starter.storage.core.Storage;
import java.time.Instant;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의, A4) — Orphan PENDING asset cleanup. session TTL 초과 후 Storage
 * + Asset entity 모두 삭제.
 *
 * <p>설계: PENDING + expiresAt before now → status=EXPIRED → Storage.delete + Asset hard-delete.
 * @Scheduled fixedDelay 로 주기 실행 (default 1 시간). yml {@code platform.asset.session.cleanup-
 * interval} 로 조정 가능.
 *
 * <p>본 job 은 Spring Scheduling 활성 (Consumer Application 에 {@code @EnableScheduling} 또는
 * Spring Boot autoconfig 가 자동 활성) 시에만 동작.
 **/
public class OrphanCleanupJob {

  private static final Logger LOG = LoggerFactory.getLogger(OrphanCleanupJob.class);

  private final AssetRepository repository;
  private final Storage storage;

  public OrphanCleanupJob(AssetRepository repository, Storage storage) {
    if (repository == null) {
      throw new IllegalArgumentException("repository must not be null");
    }
    if (storage == null) {
      throw new IllegalArgumentException("storage must not be null");
    }
    this.repository = repository;
    this.storage = storage;
  }

  /** Scheduled cleanup — fixedDelayString = configurable property. */
  @Scheduled(fixedDelayString = "${platform.asset.session.cleanup-interval-millis:3600000}")
  public void runCleanup() {
    int deleted = cleanup(Instant.now());
    if (deleted > 0) {
      LOG.info("orphan cleanup: removed {} expired PENDING assets", deleted);
    }
  }

  /** Public for manual trigger / test. cutoff 이전의 PENDING asset 모두 삭제. */
  public int cleanup(Instant cutoff) {
    List<Asset> orphans = repository.getByStatusAndExpiresAtBefore(AssetStatus.PENDING, cutoff);
    int count = 0;
    for (Asset asset : orphans) {
      try {
        storage.delete(asset.getKey());
      } catch (RuntimeException e) {
        LOG.warn("storage.delete failed for orphan {}: {}", asset.getKey(), e.getMessage());
      }
      asset.setStatus(AssetStatus.EXPIRED);
      repository.delete(asset);
      count++;
    }
    return count;
  }
}
