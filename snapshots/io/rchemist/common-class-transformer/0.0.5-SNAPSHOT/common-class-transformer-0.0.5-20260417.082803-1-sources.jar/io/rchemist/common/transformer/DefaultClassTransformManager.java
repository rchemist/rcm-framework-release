/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.BytecodeUtil;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * ClassTransform이 실행될 때 한번 Load 된 EntityClass 는 다시 load 되지 않도록 해야 한다.
 * 만약 특정 조건에서 필드를 추가하는 ClassTransformer가 있다고 할 때,
 * PersistenceUnitInfo 가 생성될 때 마다 ClassTransformer 가 실행된다면 오류가 발생할 수 있다.
 * 따라서 한번 변환된 클래스는 더 이상 변환하지 않도록 하기 위해 변환된 클래스 이름을 저장해 두어야 한다.
 **/
@Slf4j
public class DefaultClassTransformManager extends AbstractClassTransformManager{

  public static final Set<String> TRANSFORMED_CLASS_NAMES = new HashSet<>();

  private static final String[] TARGET_ANNOTATIONS = ArrayUtil.make(
      "jakarta.persistence.Entity"
      , "jakarta.persistence.Embedded"
      , "org.springframework.data.mongodb.core.mapping.Document"
      , "io.rchemist.common.presentation.annotation.AdminEntity"
      , "io.rchemist.common.persistence.mongo.annotation.DocumentTemplate"
      , "jakarta.persistence.MappedSuperclass"
  );


  @Override
  public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {

    if (className == null) {
      return null;
    }

    try {
      String convertedClassName = className.replace('/', '.');

      if (!containsTargetPackages(convertedClassName)) {
        return null;
      }

      ClassPool classPool = ClassPool.getDefault();
      CtClass clazz;
      ClassFile targetClassFile;
      if(classfileBuffer == null){
        clazz = BytecodeUtil.getDefrostedCtClass(classPool, className);
        targetClassFile = BytecodeUtil.getClassFileSafety(clazz);
      }else{
        clazz = classPool.makeClass(new ByteArrayInputStream(classfileBuffer), false);
        targetClassFile = new ClassFile(new DataInputStream(new ByteArrayInputStream(classfileBuffer)));
      }

      // 빌드 타임 플러그인이 이미 변환한 클래스는 런타임 이중 변환을 방지하기 위해 skip.
      // 0.0.x 병존 정책: @ClassEnhanced 마커 유무로 양쪽 경로를 구분한다.
      if (isAlreadyEnhanced(targetClassFile)) {
        log.debug("Skipping runtime enhance for {} (already enhanced at build time)", convertedClassName);
        TRANSFORMED_CLASS_NAMES.add(convertedClassName);
        return null;
      }

      List<?> attributes = targetClassFile.getAttributes();


      if(!getTransformedClassNames().contains(convertedClassName)){

        boolean templateTarget = false;

        SEARCH_ATTRIBUTE:
        for (Object object : attributes) {
          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {

            AnnotationsAttribute attribute = (AnnotationsAttribute) object;

            if(ArrayUtils.isNotEmpty(attribute.getAnnotations())){
              for(Annotation annotation : attribute.getAnnotations()){

                /**
                 * 엔티티 클래스 마킹
                 */
                templateTarget = markingEntityClass(convertedClassName, annotation);
                if(templateTarget){
                  break SEARCH_ATTRIBUTE;
                }

                if(!clazz.isInterface() && clazz.getInterfaces() != null){

                  for(CtClass interfaceClass : clazz.getInterfaces()){
                    if(getClassTransformConditions().containsKey(interfaceClass.getName())){
                      templateTarget = true;
                      break SEARCH_ATTRIBUTE;
                    }
                  }

                }

              }
            }
          }
        }

        if(!templateTarget){
          if(!clazz.isInterface()){
            Set<CtClass> interfaces = BytecodeUtil.getInterfaces(clazz, new HashSet<>());
            if(CollectionUtils.isNotEmpty(interfaces)){
              for(CtClass itf : interfaces){
                if(itf.isInterface() && itf.getName().equals(ClassTransformTarget.class.getName())){
                  // System.out.println("Added target :: " + className);
                  templateTarget = true;
                  break;
                }
              }
            }
          }
        }

        if(templateTarget){
          addTargetEntityClass(convertedClassName);
        }

      }

      return doTransform(loader, classBeingRedefined, classfileBuffer, classPool, convertedClassName, clazz);

    } catch (IOException | CannotCompileException | NotFoundException | ClassNotFoundException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }

  }

  /**
   * 실제 클래스 Transform 처리
   * @param loader
   * @param classBeingRedefined
   * @param classfileBuffer
   * @param classPool
   * @param convertedClassName
   * @param clazz
   * @return
   * @throws IllegalClassFormatException
   * @throws IOException
   * @throws CannotCompileException
   * @throws NotFoundException
   * @throws ClassNotFoundException
   */
  private byte[] doTransform(ClassLoader loader, Class<?> classBeingRedefined, byte[] classfileBuffer, ClassPool classPool, String convertedClassName, CtClass clazz) throws IllegalClassFormatException, IOException, CannotCompileException, NotFoundException, ClassNotFoundException {

    if(CollectionUtils.isNotEmpty(getClassTransformers())){

      Map<String, TransformCondition> conditions = getClassTransformConditions();
      for(Map.Entry<String, TransformCondition> entry : conditions.entrySet()){
        // pre template class load
        try{
          Class.forName(entry.getValue().getTemplateClassName());
        }catch (Exception e){
          // skip
        }
      }

      TransformResult result = TransformResult.builder()
          .targetClass(clazz)
          .classLoader(loader)
          .classBeingRedefined(classBeingRedefined)
          .classfileBuffer(classfileBuffer)
          .classPool(classPool)
          .className(convertedClassName)
          .transformed(false)
          .build();


      for(PlatformClassTransformer classTransformer : getClassTransformers()){
        try{
          result = classTransformer.transform(result, getTargetEntityClasses(), getClassTransformConditions());
        }catch(Exception e){
          log.warn(classTransformer.getClass().getSimpleName() + "::" + convertedClassName + "\n" + e.getMessage());
          e.printStackTrace();
        }
      }

      TRANSFORMED_CLASS_NAMES.add(clazz.getName());

      if(result.isTransformed()){
        return result.getTargetClass().toBytecode();
      }
    }

    return null;
  }

  private boolean markingEntityClass(String convertedClassName, Annotation annotation) {
    return BytecodeUtil.containsAnnotation(annotation
        , TARGET_ANNOTATIONS);
  }

  private static final String CLASS_ENHANCED_ANNOTATION = ClassEnhanced.class.getName();

  private static boolean isAlreadyEnhanced(ClassFile classFile) {
    for (Object attr : classFile.getAttributes()) {
      if (attr instanceof AnnotationsAttribute) {
        AnnotationsAttribute attribute = (AnnotationsAttribute) attr;
        if (attribute.getAnnotation(CLASS_ENHANCED_ANNOTATION) != null) {
          return true;
        }
      }
    }
    return false;
  }

  // 무조건 가장 먼저 실행된다.
  @Override
  public int getOrder() {
    return Integer.MIN_VALUE;
  }

}
