/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.transformer.dto.ClassTransformConfig;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.provider.AddFieldFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddIndexAnnotationProvider;
import io.rchemist.common.transformer.provider.AddInterfaceFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddMethodFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddTypeLevelAnnotationProvider;
import io.rchemist.common.transformer.provider.TemplateBasedClassTransformProvider;
import io.rchemist.common.transformer.provider.ValidateRequiredAnnotationProvider;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
import org.springframework.instrument.classloading.LoadTimeWeaver;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class PlatformClassTransformHelper {

  private static final String DEFAULT_PACKAGE = "io.rchemist";

  private static final String SEARCH_PROVIDER_CONFIG = "platform.config.provider.search";
  private static final String PLATFORM_CLASS_TRANSFORM_LOG = "platform.config.class-transformer.log";

  private static final String BOOTSTRAP_YML = "bootstrap.yml";

  private static SearchProvider searchProvider;

  public static String[] getDefaultApplicationPackages() {
    return getPackagesToScan(getApplicationPackages());
  }

  public static String getApplicationPackages() {
    return System.getProperty("platform.config.application.packages", DEFAULT_PACKAGE);
  }

  public static String[] getPackagesToScan(String packages) {
    return StringUtil.splitWithNonEmpty(packages, ",");
  }

  public static void initializeDefaultTransformedClasses() {
    initializeTransformedClasses(getDefaultApplicationPackages());
  }

  // use default class transformer
  public static void initializeTransformedClasses(String... packagesToScan) {
    ClassTransformConfig config = new ClassTransformConfig().withPackagesToScan(packagesToScan);
    initializeTransformedClasses(config);
  }

  /**
   * ClassTransformers 와 TemplateBasedClassTransformProvider 를 추가로 지정해 클래스를 변환한다.
   *
   * @param config
   */
  public static void initializeTransformedClasses(ClassTransformConfig config) {

    ClassTransformManager classTransformManager = getDefaultClassTransformer(config);

    try {
      // never create ajcore dump txt file
      // org.aspectj.weaver.Dump.setDumpOnException(false);

      // org.aspectj.weaver.Dump.setDumpOnExit(org.aspectj.bridge.IMessage.ABORT);
    } catch (Exception e) {
      if (log.isDebugEnabled()) {
        log.debug("Failed to set aspectj weaver dump settings: {}", e.getMessage());
      }
    }

    List<String> packagesToScan = classTransformManager.getClassTransformTargetPackages();

    // SpringInstrument 를 지정하는 VM 옵션 없이 Class Transform 을 할 수 있게 하는 경우 너무 느려지기 때문에 권장하지 않는다. 해당 기능은 제거한다.
    if (config.isUseDynamicInstrumentationLoader()) {
      
      throw new IllegalStateException("VM 옵션에 -javaagent:${path}/spring-instrument-${version}.jar 를 지정해 주세요");
      
    }

    LoadTimeWeaver weaver = new InstrumentationLoadTimeWeaver();
    weaver.addTransformer(classTransformManager);

    boolean printLog = getClassTransformerLogFromBootstrap();

    for (String packageStr : packagesToScan) {

      Reflections reflections = new Reflections(packageStr);
      Set<Class<? extends Serializable>> classes = reflections.getSubTypesOf(Serializable.class);
      @SuppressWarnings("rawtypes")
      Set<Class<? extends EnumType>> enumTypes = reflections.getSubTypesOf(EnumType.class);
      if (CollectionUtils.isNotEmpty(enumTypes)) {
        classes.addAll(enumTypes);
      }

      if (printLog) {
        log.info("Start ClassTransform in package " + packageStr + "("+classes.size()+" classes)...");
      }

      boolean transformed = false;

      for (@SuppressWarnings("rawtypes") Class clazz : classes) {
        try {
          if (printLog) {
            log.info("Target Class is " + clazz.getName());
          }

          // show progress bar for class transformation, using square box instead of dot
          weaver.getInstrumentableClassLoader().loadClass(clazz.getName());
          transformed = true;
          Class.forName(clazz.getName());
        } catch (ClassNotFoundException e) {
          System.out.println();
          ExceptionUtil.printStackTrace(e);
        }
      }

      if (transformed) {
        if (printLog) {
          log.info("Transformed classes in package " + packageStr + " successfully.");
        }
      }

    }
    log.info("PlatformClassTransformer has processed successfully.");

  }

  // you can use your own classTransformManager
  public static ClassTransformManager build(String[] packagesToScan,
      LinkedHashMap<String, TransformCondition> transformConditions,
      List<PlatformClassTransformer> platformClassTransformers) {
    DefaultClassTransformManager manager = new DefaultClassTransformManager();
    manager.setClassTransformers(platformClassTransformers);
    manager.setClassTransformConditions(transformConditions);
    manager.setClassTransformTargetPackages(Arrays.asList(packagesToScan));
    return manager;
  }

  private static ClassTransformManager getDefaultClassTransformer(ClassTransformConfig config) {
    DefaultClassTransformManager manager = new DefaultClassTransformManager();
    manager.setClassTransformers(platformClassTransformers(config));
    manager.setClassTransformConditions(classTransformConditions(config.getPackagesToScan()));
    manager.setClassTransformTargetPackages(config.getPackagesToScan(getDefaultApplicationPackages()));
    return manager;
  }

  private static List<PlatformClassTransformer> platformClassTransformers(
      ClassTransformConfig config) {

    List<PlatformClassTransformer> defaultTransformers = CollectionUtil.list(
        new IdGeneratorClassTransformer(),
        new EnumTypeClassTransformer(),
        new EnumTypeFieldConverterClassTransformer(),
        new ExceptArchivedEntityClassTransformer(),
        new DefaultValueFieldClassTransformer(),
        new IndexFieldClassTransformer(),
        new TemplateBasedClassTransformer(templateBasedClassTransformProviders(
            config.getCustomTemplateBasedClassTransformProviders())),
        new TextFieldClassTransformer(),
        new HibernateSearchClassTransformer(
            getSearchProviderConfiguration(SearchProvider.QUERY)),
        new IndexKeyValueMapClassTransformer(),
        new TableFieldCommentClassTransformer()
    );

    if (CollectionUtils.isNotEmpty(config.getCustomClassTransformers())) {
      for (PlatformClassTransformer addedClassTransformer : config.getCustomClassTransformers()) {
        if (!defaultTransformers.contains(addedClassTransformer)) {
          defaultTransformers.add(addedClassTransformer);
        }
      }
    }
    return defaultTransformers;

  }

  public static SearchProvider getSearchProviderConfiguration(SearchProvider defaultProvider) {
    if (searchProvider != null) {
      return searchProvider;
    }

    // -Dplatform.config.provider.search=querydsl
    String provider = System.getProperty(SEARCH_PROVIDER_CONFIG);

    // load config from bootstrap.yml
    try {
      provider = getProviderConfigFromBootstrap(provider);

      if (StringUtils.isEmpty(provider)) {
        return defaultProvider;
      }

    } catch (Exception e) {
      if (log.isDebugEnabled()) {
        log.debug("Failed to get search provider configuration from bootstrap.yml: {}", e.getMessage());
      }
    }

    try {
      searchProvider = SearchProvider.valueOf(provider.toUpperCase());
    } catch (Exception e) {
      if (log.isDebugEnabled()) {
        log.debug("Invalid search provider value '{}', using default provider: {}", provider, defaultProvider, e);
      }
      searchProvider = defaultProvider;
    }

    return searchProvider;

  }

  private static boolean getClassTransformerLogFromBootstrap() {
    // bootstrap 에 정의된 platform.config.provider.search 값
    Resource resource = new ClassPathResource(BOOTSTRAP_YML);

    YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
    try {
      List<PropertySource<?>> sources = loader.load("bootstrap_loader", resource);

      for (PropertySource<?> source : sources) {
        if (source.containsProperty(PLATFORM_CLASS_TRANSFORM_LOG)) {
          return (Boolean) source.getProperty(PLATFORM_CLASS_TRANSFORM_LOG);
        }
      }

    } catch (IOException e) {
      if (log.isDebugEnabled()) {
        log.debug("Failed to load class transformer log configuration from bootstrap.yml: {}", e.getMessage());
      }
    }

    return false;
  }

  private static String getProviderConfigFromBootstrap(String provider) {
    if (StringUtils.isEmpty(provider)) {
      // bootstrap 에 정의된 platform.config.provider.search 값
      Resource resource = new ClassPathResource(BOOTSTRAP_YML);

      YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
      try {
        List<PropertySource<?>> sources = loader.load("bootstrap_loader", resource);

        for (PropertySource<?> source : sources) {
          if (source.containsProperty(SEARCH_PROVIDER_CONFIG)) {
            provider = (String) source.getProperty(SEARCH_PROVIDER_CONFIG);
            break;
          }
        }

      } catch (IOException e) {
        if (log.isDebugEnabled()) {
          log.debug("Failed to load provider configuration from bootstrap.yml: {}", e.getMessage());
        }
      }
    }

    return provider;
  }

  private static List<TemplateBasedClassTransformProvider> templateBasedClassTransformProviders(
      List<TemplateBasedClassTransformProvider> customTemplateBasedClassTransformProviders) {
    List<TemplateBasedClassTransformProvider> providers = CollectionUtil.list(
        new AddFieldFromTemplateProvider()
        , new AddIndexAnnotationProvider()
        , new AddInterfaceFromTemplateProvider()
        , new AddMethodFromTemplateProvider()
        , new AddTypeLevelAnnotationProvider()
        , new ValidateRequiredAnnotationProvider()
    );

    if (CollectionUtils.isNotEmpty(customTemplateBasedClassTransformProviders)) {
      for (TemplateBasedClassTransformProvider addedClassTransformer : customTemplateBasedClassTransformProviders) {
        if (!providers.contains(addedClassTransformer)) {
          providers.add(addedClassTransformer);
        }
      }
    }

    return providers;

  }


  private static LinkedHashMap<String, TransformCondition> classTransformConditions(
      String... packagesToScan) {

    var conditions = new LinkedHashMap<String, TransformCondition>();

    if (ArrayUtils.isNotEmpty(packagesToScan)) {
      Set<Class<?>> templateClasses = new HashSet<>();
      for (String packageStr : packagesToScan) {
        Reflections reflections = new Reflections(packageStr);
        templateClasses.addAll(reflections.getTypesAnnotatedWith(TemplateClass.class, false));
      }

      if (CollectionUtils.isNotEmpty(templateClasses)) {
        for (Class<?> clazz : templateClasses) {
          String className = clazz.getName();
          if (StringUtils.endsWith(className, "Impl")) {
            String interfaceName = StringUtils.substringBeforeLast(className, "Impl");
            conditions.put(interfaceName, new TransformCondition(interfaceName, className));
          }

        }
      }

    }

    return conditions;
  }

}
