/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.util.BytecodeUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.MemberValue;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public abstract class AbstractClassTransformer implements PlatformClassTransformer {

  protected static final Set<String> alreadyLoadedClasses = new HashSet<>();
  protected List<String> preLoadClassNamePatterns = new ArrayList<>();

  protected List<String> classTransformTargetPackages;

  protected Integer order = Integer.MAX_VALUE;



  public void setOrder(Integer order){
    this.order = order;
  }

  @Override
  public abstract int getOrder();

  protected String getStringMemberValue(MemberValue value) {
    if (value != null) {
      return StringUtils.removeEnd(StringUtils.removeStart(value.toString(), "\""), "\"");
    } else {
      return null;
    }
  }

  /**
   * 어노테이션에 columnList의 값을 가져온다
   * @param annotation
   * @param info
   * @return
   */
  protected String getAnnotationFieldValue(Annotation annotation, FieldInfo info, String annotationFieldName) {
    String value = getStringMemberValue(annotation.getMemberValue(annotationFieldName));
    if (StringUtils.isBlank(value)) {
      value = getFieldColumnName(info);
    }
    return value;
  }

  /**
   * FieldInfo 에서 @Column.name 값을 추출한다
   * @param info
   * @return
   */
  protected String getFieldColumnName(FieldInfo info) {
    for (Object infoAttr : info.getAttributes()) {
      if (AnnotationsAttribute.class.isAssignableFrom(infoAttr.getClass())) {
        AnnotationsAttribute annoAttr = (AnnotationsAttribute) infoAttr;
        Annotation[] annos = annoAttr.getAnnotations();
        for (Annotation anno : annos) {
          if (anno.getTypeName().equals(Annotations.PERSISTENCE_COLUMN_CLASS)) {
            return getStringMemberValue(anno.getMemberValue("name"));
          }else if(anno.getTypeName().equals(Annotations.PERSISTENCE_JOIN_COLUMN_CLASS)){
            return getStringMemberValue(anno.getMemberValue("name"));
          }
        }
      }
    }
    return null;
  }

  /**
   * ClassFile 에 정의된 필드 뿐 아니라, SuperClass의 필드, Embedded 에 정의된 필드까지 모두 가져오는 메소드
   * @param classFile   대상 classFile
   * @param targetAnnotationClass   특정 어노테이션을 가진 필드만 가져올 수도 있다
   * @param fieldInfos  기본값은 null
   * @return
   */
  @SneakyThrows
  protected Set<FieldInfo> getAllFields(ClassFile classFile, Class<?> targetAnnotationClass, Set<FieldInfo> fieldInfos, boolean includeSuperClass, boolean includeEmbedded){

    try{

      if(fieldInfos == null){
        fieldInfos = new HashSet<>();
      }

      if(includeSuperClass && classFile.getSuperclass() != null && !classFile.getSuperclass().equals(Object.class.getName())){
        fieldInfos.addAll(getAllFields(classFile.getSuperclass(), targetAnnotationClass, fieldInfos, includeSuperClass, includeEmbedded));
      }

      List<FieldInfo> tempFieldInfos = classFile.getFields();
      for(FieldInfo info : tempFieldInfos){

        List<?> objects = info.getAttributes();
        Iterator<?> iters = objects.iterator();
        boolean toAddField = targetAnnotationClass == null;

        while (iters.hasNext()) {
          Object obj = iters.next();
          if (AnnotationsAttribute.class.isAssignableFrom(obj.getClass())) {
            AnnotationsAttribute attr = (AnnotationsAttribute) obj;
            Annotation[] items = attr.getAnnotations();

            for (Annotation annotation : items) {
              if(!toAddField){
                toAddField = annotation.getTypeName().equals(targetAnnotationClass.getName());
              }

              if (includeEmbedded && annotation.getTypeName().equals(Annotations.PERSISTENCE_EMBEDDED_CLASS)) {
                fieldInfos.addAll(getAllFields(
                    BytecodeUtil.getProperClassName(info.getDescriptor(), true), targetAnnotationClass, fieldInfos, includeSuperClass, false));
              }
            }
          }
        }

        if(toAddField){
          fieldInfos.add(info);
        }
      }
    }catch (Exception e){
      // do nothing
      System.out.println("오류 발생: " + classFile.getName());
      e.printStackTrace();
      throw e;
    }

    return fieldInfos;
  }

  /**
   * 클래스 이름만 가지고 getAllFields 를 할 수 있도록 하는 편의성 메소드
   * @param className
   * @param targetAnnotationClass
   * @param fieldInfos
   * @return
   * @throws ClassNotFoundException
   * @throws NotFoundException
   */
  protected Set<FieldInfo> getAllFields(String className, Class<?> targetAnnotationClass, Set<FieldInfo> fieldInfos, boolean includeSuperClass, boolean includeEmbedded) throws ClassNotFoundException, NotFoundException {
    if(!className.equals(Object.class.getName())){
      ClassPool classPool = ClassPool.getDefault();
      CtClass ctClass = classPool.get(className);
      boolean isFrozen = ctClass.isFrozen();
      if(isFrozen) {
        ctClass.defrost();
      }

      ClassFile classFile = ctClass.getClassFile();
      Set<FieldInfo> results =  getAllFields(classFile, targetAnnotationClass, fieldInfos, includeSuperClass, includeEmbedded);

      if(isFrozen){
        ctClass.freeze();
      }

      return results;

    }
    return fieldInfos;
  }

  @Override
  public int compareTo(PlatformClassTransformer o) {
    if(o.getOrder() > getOrder()){
      return -1;
    }else if(o.getOrder() == getOrder()){
      return 0;
    }else{
      return 1;
    }
  }

}