/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.ClassFile;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class HibernateSearchClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final int order = 400;

  private static final String TARGET_ANNOTATION = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed";

  private static Class ANNOTATION_CLASS;

  static {
    try {
      ANNOTATION_CLASS = Class.forName(TARGET_ANNOTATION);
    } catch (ClassNotFoundException e) {
      log.debug("IndexFieldClassTransformer를 사용할 수 없습니다.");
    }
  }

  protected final SearchProvider searchProvider;

  public HibernateSearchClassTransformer(
      SearchProvider searchProvider) {
    this.searchProvider = searchProvider;

    if(ANNOTATION_CLASS != null && (searchProvider == null || !(searchProvider.equals(SearchProvider.HIBERNATE)))){
      if (log.isDebugEnabled()) {
        System.out.println("==============================================================");
        System.out.println("SearchProvider 가 QUERY 로 설정되었습니다. 모든 서비스에서 ElasticSearch 대신 직접 DB 조회를 수행합니다.");
        System.out.println("SearchProvider 를 HIBERNATE 로 설정해 검색에서 ElasticSearch 를 사용하게 되면 더 나은 성능을 기대할 수 있습니다. 자세한 내용은 매뉴얼을 참고하시기 바랍니다.");
        System.out.println("SearchProvider set to QUERYDSL. All services perform direct DB lookups instead of ElasticSearch.");
        System.out.println("It might expected better performance when using ElasticSearch in searches by setting the SearchProvider to HIBERNATE. Please refer to the manual for details.");
        System.out.println("==============================================================");
      } else {
        System.out.println("==============================================================");
        System.out.println("Current SearchProvider is QUERY. Use HIBERNATE(Hibernate-Search) is recommended.");
        System.out.println("==============================================================");
      }
    }

  }

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {

    if(searchProvider.equals(SearchProvider.HIBERNATE) || ANNOTATION_CLASS == null)
      return result;

    if (!transformedEntityClassNames.contains(result.getClassName())) {
      String className = result.getClassName();
      ClassFile targetClassFile = result.getTargetClassFile();

      Annotation annotation = BytecodeUtil.getDeclaredAnnotationOnType(targetClassFile, TARGET_ANNOTATION);

      if(annotation != null){

        List<AttributeInfo> attributes = targetClassFile.getAttributes();

        AttributeInfo info = null;

        for(AttributeInfo attr : attributes){
          if(attr instanceof AnnotationsAttribute){
            ((AnnotationsAttribute) attr).removeAnnotation(TARGET_ANNOTATION);
            info = attr;
          }
        }

        if(info != null){
          targetClassFile.removeAttribute(info.getName());
          targetClassFile.addAttribute(info);
        }

        transformedEntityClassNames.add(className);

        result.arrangeTransformResultByClassFile(targetClassFile);

      }

    }
    return result;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
