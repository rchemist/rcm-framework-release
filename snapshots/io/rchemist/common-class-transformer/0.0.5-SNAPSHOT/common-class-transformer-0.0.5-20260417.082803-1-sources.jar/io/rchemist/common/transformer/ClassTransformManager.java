/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.RegisterEntityBean;
import io.rchemist.common.transformer.dto.TransformCondition;
import java.lang.instrument.ClassFileTransformer;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface ClassTransformManager extends ClassFileTransformer {

  Map<String, TransformCondition> getClassTransformConditions();

  void addClassTransformCondition(TransformCondition condition);

  void setClassTransformConditions(Map<String, TransformCondition> classTransformConditions);

  List<String> getClassTransformTargetPackages();

  void setClassTransformTargetPackages(List<String> classTransformTargetPackages);

  boolean containsTargetPackages(String convertedClassName);

  default void registerEntityBean(RegisterEntityBean registerEntityBean) {
    // nothing to do
  }

  int getOrder();

}
