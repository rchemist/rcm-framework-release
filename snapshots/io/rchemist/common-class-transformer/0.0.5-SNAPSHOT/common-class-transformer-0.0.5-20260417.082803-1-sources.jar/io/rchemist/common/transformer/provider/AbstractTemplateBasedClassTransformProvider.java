/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.BytecodeUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public abstract class AbstractTemplateBasedClassTransformProvider implements TemplateBasedClassTransformProvider {

  protected TransformResult arrangeTransformResult(TransformResult result){
    try {
      result.setTargetClass(BytecodeUtil.classFileToCtClass(result.getClassPool(), result.getTargetClassFile()));
    } catch (IOException e) {
      log.warn("TemplateBasedClassTransformer has failed");
      e.printStackTrace();
    }
    return result;
  }

  /**
   * Annotation[] 에 특정 어노테이션 클래스가 있는지
   * @param annotations
   * @param annotationClass
   * @return
   */
  protected Annotation getAnnotationMember(Annotation[] annotations, Class annotationClass){
    return getAnnotationMemberByClassName(annotations, annotationClass.getName());
  }

  protected Annotation getAnnotationMemberByClassName(Annotation[] annotations, String className){
    for(Annotation annotation : annotations){
      if(annotation.getTypeName().equals(className)){
        return annotation;
      }
    }
    return null;
  }

  protected Annotation[] getDeclaredAnnotation(TransformResult result, Class... annotationClass) {
    if (ArrayUtils.isNotEmpty(annotationClass)) {
      List<String> targetAnnotationClassName = new ArrayList<>();
      for (Class clazz : annotationClass) {
        targetAnnotationClassName.add(clazz.getName());
      }
      return getDeclaredAnnotationByClassName(result, targetAnnotationClassName.toArray(new String[0]));
    }
    return getDeclaredAnnotationByClassName(result, null);
  }

  protected Annotation[] getDeclaredAnnotationByClassName(TransformResult result, String... annotationClassNames) {
    List<?> templateAttributes = result.getTemplateClassFile().getAttributes();
    Iterator<?> templateItr = templateAttributes.iterator();
    List<String> targetAnnotationClassName = new ArrayList<>();
    List<Annotation> annotations = new ArrayList<>();

    if(ArrayUtils.isNotEmpty(annotationClassNames)){
      for(String className : annotationClassNames){
        targetAnnotationClassName.add(className);
      }
    }

    while (templateItr.hasNext()) {
      Object object = templateItr.next();
      if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
        AnnotationsAttribute attr = (AnnotationsAttribute) object;
        Annotation[] items = attr.getAnnotations();
        for (Annotation anno : items) {
          String typeName = anno.getTypeName();
          if (targetAnnotationClassName.contains(typeName)) {
            annotations.add(anno);
          }
        }
      }
    }

    return (CollectionUtils.isNotEmpty(annotations)) ? ArrayUtil.toArray(Annotation.class, annotations) : null ;
  }
}
