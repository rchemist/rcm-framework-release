/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.ExcludeTransform;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class AddFieldFromTemplateProvider extends AbstractTemplateBasedClassTransformProvider {

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 500;

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, NotFoundException {

    /**
     * 템플릿 클래스에 선언된 모든 필드를 복제한다.
     */
    CtField[] fieldsToCopy = result.getTemplateClass().getDeclaredFields();

    for (CtField field : fieldsToCopy) {
      if (field.hasAnnotation(ExcludeTransform.class)) {
        //
      } else {

        /**
         * 대상 클래스에 복제 대상 필드가 있으면 제거한다.
         * 단, 이름만 같고 타입이 다른 경우는 IllegalArgumentException 을 낸다.
         */
        try {
          CtField ctField = result.getTargetClass().getDeclaredField(field.getName());
          String originalSignature = ctField.getSignature();
          String mySignature = field.getSignature();

          // 타입이 같은 필드만 제거한다.
          if (originalSignature.equals(mySignature)) {
            result.getTargetClass().removeField(ctField);
          } else {
            log.warn("There is duplicated field on source class and destination class. The target class is "
                + result.getTargetClass().getName() + ", and duplicated field name is " + ctField.getName()
            );
          }
        } catch (NotFoundException e) {
          // 필드가 존재하지 않는게 정상이다. 무시한다.
          //e.printStackTrace();
        }

        /**
         * 대상 클래스에 필드를 추가한다.
         */
        try{
          result.setTargetClass(addFieldToClass(result.getTargetClass(), result.getClassPool(), field));
        }catch (Exception e){
          e.printStackTrace();
          // 오류가 난 필드만 skip
        }


      }
    }

    return result;
  }

  /**
   * 대상 클래스에 지정된 필드를 복사한다.
   * @param targetClass
   * @param classPool
   * @param field
   * @throws CannotCompileException
   * @throws NotFoundException
   */
  private CtClass addFieldToClass(CtClass targetClass, ClassPool classPool, CtField field) throws CannotCompileException, NotFoundException {

    CtField copiedField = new CtField(field, targetClass);

    boolean defaultConstructorFound = false;

    String implClass = BytecodeUtil.getImplementationType(field.getType().getName());

    /**
     * 필드에 초기화 생성자가 있다면 함께 복사한다.
     */
    try {
      CtConstructor[] implConstructors = classPool.get(implClass).getConstructors();
      if (implConstructors != null) {
        for (CtConstructor cons : implConstructors) {
          if (cons.getParameterTypes().length == 0) {
            defaultConstructorFound = true;
            break;
          }
        }
      }
    } catch (NotFoundException e) {
      // 필드의 생성자가 존재하지 않는다는 것은 배열 필드라는 뜻이다. 무시한다.
    }

    if (defaultConstructorFound) {
      targetClass.addField(copiedField, "new " + implClass + "()");
    } else {
      targetClass.addField(copiedField);
    }

    return targetClass;
  }

}
