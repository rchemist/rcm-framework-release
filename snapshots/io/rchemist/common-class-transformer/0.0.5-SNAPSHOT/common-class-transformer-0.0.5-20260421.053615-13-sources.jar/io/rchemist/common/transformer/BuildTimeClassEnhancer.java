/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.provider.AddFieldFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddIndexAnnotationProvider;
import io.rchemist.common.transformer.provider.AddInterfaceFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddMethodFromTemplateProvider;
import io.rchemist.common.transformer.provider.AddTypeLevelAnnotationProvider;
import io.rchemist.common.transformer.provider.TemplateBasedClassTransformProvider;
import io.rchemist.common.transformer.provider.ValidateRequiredAnnotationProvider;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.StringMemberValue;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.reflections.scanners.Scanners;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

/**
 * 빌드 타임 바이트코드 변환 진입점. Spring 컨텍스트 없이 호출 가능하며, Maven/Gradle
 * 플러그인에서 사용한다.
 *
 * <p>기존 {@link PlatformClassTransformHelper} 가 수행하던 런타임 LoadTimeWeaver 기반 변환을
 * 빌드 시점으로 이동한다. 변환 체인·조건 해석·TransformResult 파이프라인은 기존 구현을
 * 그대로 재사용하되, 진입점에서 Spring 의존(YamlPropertySourceLoader, Resource,
 * InstrumentationLoadTimeWeaver 등)을 제거한다.</p>
 *
 * <p>변환된 클래스에는 {@link ClassEnhanced} 마커 어노테이션을 부착해 런타임에서
 * 이중 변환을 방지한다. 0.0.x 시리즈에서는 런타임 경로와 병존하며, 0.1.0 에서 런타임
 * 경로가 완전히 제거된다.</p>
 *
 * @since 0.0.5
 */
public final class BuildTimeClassEnhancer {

  private BuildTimeClassEnhancer() {
  }

  /**
   * 단일 모듈의 컴파일된 클래스 디렉토리에 변환을 적용한다.
   *
   * @param classesDirectory       대상 {@code target/classes} 디렉토리
   * @param compileClasspathElements 프로젝트 의존성 classpath (jar 및 디렉토리 경로)
   * @param packagesToScan         변환 대상 패키지. 비어 있으면 기본 {@code io.rchemist}
   * @param searchProvider         {@link HibernateSearchClassTransformer} 에 주입할 provider.
   *                               null 이면 {@link SearchProvider#QUERY}
   * @param pluginVersion          {@link ClassEnhanced#version()} 에 기록할 값
   * @param listener               진행 이벤트 리스너. null 이면 no-op
   */
  public static Result enhance(File classesDirectory,
      Collection<String> compileClasspathElements,
      String[] packagesToScan,
      SearchProvider searchProvider,
      String pluginVersion,
      Listener listener) {

    Listener log = listener == null ? Listener.NOOP : listener;

    if (classesDirectory == null || !classesDirectory.isDirectory()) {
      log.info("Skip enhance: classes directory missing");
      return Result.empty();
    }

    String[] packages = (packagesToScan == null || packagesToScan.length == 0)
        ? new String[]{"io.rchemist"} : packagesToScan;
    SearchProvider provider = (searchProvider == null) ? SearchProvider.QUERY : searchProvider;

    List<URL> urls = buildUrls(classesDirectory, compileClasspathElements, log);

    // reactor 내 여러 모듈이 동일 JVM 에서 연속 enhance 를 실행할 때 ClassPool.getDefault()
    // 싱글턴에 이전 모듈의 frozen CtClass 가 캐시되어 template weaving 이 부분적으로만
    // 수행되는 현상을 방지하기 위해, 매 호출 시 cache 를 reset 한다. 트랜스포머들이
    // ClassPool.getDefault() 를 직접 참조하는 경로들이 남아있어 완전 분리 대신 선택한 절충안.
    resetDefaultClassPoolCache(log);

    ClassPool pool = ClassPool.getDefault();
    try {
      pool.appendClassPath(classesDirectory.getAbsolutePath());
    } catch (Exception e) {
      log.warn("Failed to append classesDirectory to ClassPool", e);
    }
    if (compileClasspathElements != null) {
      for (String element : compileClasspathElements) {
        if (element == null) continue;
        File f = new File(element);
        if (!f.exists()) continue;
        try {
          pool.appendClassPath(element);
        } catch (Exception e) {
          log.warn("Failed to append classpath element: " + element, e);
        }
      }
    }

    URLClassLoader loader = new URLClassLoader(urls.toArray(new URL[0]),
        BuildTimeClassEnhancer.class.getClassLoader());

    try {
      Map<String, TransformCondition> conditions = discoverConditions(loader, urls, packages, log);
      List<PlatformClassTransformer> transformers = buildTransformers(provider);

      DefaultClassTransformManager manager = new DefaultClassTransformManager();
      manager.setClassTransformers(transformers);
      manager.setClassTransformConditions(conditions);
      manager.setClassTransformTargetPackages(Arrays.asList(packages));

      List<Path> classFiles = listClassFiles(classesDirectory, log);
      int enhanced = 0;
      int skippedAlreadyMarked = 0;
      int skippedNoTransform = 0;
      int failed = 0;

      // conditions 에 source 로 등록된 (@TemplateClass 가 붙은 "...Impl") 클래스 집합.
      // 본 for-loop 이 알파벳 순으로 돌며 target entity 를 enhance 하다가 template source
      // 가 ClassPool 에 frozen 상태로 캐시되고, 이후 같은 for-loop 이 그 source 의
      // .class 파일을 target 으로 만나 건드리려 하면 "class is frozen" / ConstPool
      // corruption 에러가 발생한다. 이 Set 으로 "target 으로는 처리하지 않는다" 를
      // in-memory state 로만 판정 — 파일/바이트코드 수정 없이 사이드 이펙트 0.
      Set<String> templateSourceInternalNames = new HashSet<>();
      for (TransformCondition cond : conditions.values()) {
        String templateClass = cond.getTemplateClassName();
        if (templateClass != null) {
          templateSourceInternalNames.add(templateClass.replace('.', '/'));
        }
      }
      int skippedTemplateSource = 0;

      for (Path classFile : classFiles) {
        String internalName = toInternalName(classesDirectory.toPath(), classFile);
        if (internalName == null) continue;

        byte[] bytes;
        try {
          bytes = Files.readAllBytes(classFile);
        } catch (IOException e) {
          failed++;
          log.warn("Failed to read " + classFile, e);
          continue;
        }

        if (hasEnhancedMarker(bytes)) {
          skippedAlreadyMarked++;
          continue;
        }

        if (templateSourceInternalNames.contains(internalName)) {
          // Template source (@TemplateClass Impl) 는 설계상 target 이 아니라 다른 entity
          // 에 필드/메서드를 공급하는 쪽. for-loop 에서 target 으로 처리하지 않는다.
          skippedTemplateSource++;
          continue;
        }

        byte[] transformed;
        try {
          transformed = manager.transform(loader, internalName, null, null, bytes);
        } catch (Throwable t) {
          failed++;
          log.warn("Failed to enhance " + internalName, t);
          continue;
        }

        if (transformed == null) {
          skippedNoTransform++;
          continue;
        }

        try {
          byte[] marked = attachEnhancedMarker(transformed, pluginVersion);
          Files.write(classFile, marked);
          enhanced++;
        } catch (IOException e) {
          failed++;
          log.warn("Failed to write enhanced bytecode for " + internalName, e);
        }
      }

      log.info("enhance summary: enhanced=" + enhanced
          + ", skippedNoTransform=" + skippedNoTransform
          + ", skippedAlreadyMarked=" + skippedAlreadyMarked
          + ", skippedTemplateSource=" + skippedTemplateSource
          + ", failed=" + failed);

      return new Result(enhanced, skippedNoTransform, skippedAlreadyMarked, failed);

    } finally {
      try {
        loader.close();
      } catch (IOException ignored) {
      }
    }
  }

  @SuppressWarnings("unchecked")
  private static void resetDefaultClassPoolCache(Listener log) {
    try {
      ClassPool pool = ClassPool.getDefault();
      Field classesField = ClassPool.class.getDeclaredField("classes");
      classesField.setAccessible(true);
      Object value = classesField.get(pool);
      if (value instanceof Map<?, ?> map) {
        ((Map<String, CtClass>) map).clear();
      }
    } catch (NoSuchFieldException | IllegalAccessException e) {
      log.warn("Failed to reset ClassPool cache (reactor state may leak across modules)", e);
    }
  }

  private static List<URL> buildUrls(File classesDirectory,
      Collection<String> compileClasspathElements, Listener log) {
    List<URL> urls = new ArrayList<>();
    try {
      urls.add(classesDirectory.toURI().toURL());
    } catch (MalformedURLException e) {
      log.warn("bad classesDirectory URL", e);
    }
    if (compileClasspathElements != null) {
      for (String element : compileClasspathElements) {
        if (element == null) continue;
        File f = new File(element);
        if (!f.exists()) continue;
        try {
          urls.add(f.toURI().toURL());
        } catch (MalformedURLException e) {
          log.warn("bad classpath URL: " + element, e);
        }
      }
    }
    return urls;
  }

  private static Map<String, TransformCondition> discoverConditions(URLClassLoader loader,
      List<URL> urls, String[] packages, Listener log) {
    LinkedHashMap<String, TransformCondition> conditions = new LinkedHashMap<>();
    try {
      FilterBuilder filter = new FilterBuilder();
      for (String pkg : packages) {
        filter.includePackage(pkg);
      }
      ConfigurationBuilder cfg = new ConfigurationBuilder()
          .setUrls(urls)
          .addClassLoaders(loader)
          .filterInputsBy(filter)
          .setScanners(Scanners.TypesAnnotated);
      Reflections reflections = new Reflections(cfg);
      Set<Class<?>> templateClasses = reflections.getTypesAnnotatedWith(TemplateClass.class, false);
      if (templateClasses != null) {
        for (Class<?> clazz : templateClasses) {
          String className = clazz.getName();
          if (StringUtils.endsWith(className, "Impl")) {
            String interfaceName = StringUtils.substringBeforeLast(className, "Impl");
            conditions.putIfAbsent(interfaceName,
                new TransformCondition(interfaceName, className));
          }
        }
      }
    } catch (Throwable t) {
      log.warn("Failed to scan @TemplateClass in packages " + Arrays.toString(packages), t);
    }
    log.info("discovered " + conditions.size() + " transform conditions");
    return conditions;
  }

  private static List<PlatformClassTransformer> buildTransformers(SearchProvider provider) {
    List<TemplateBasedClassTransformProvider> providers = new ArrayList<>();
    providers.add(new AddFieldFromTemplateProvider());
    providers.add(new AddIndexAnnotationProvider());
    providers.add(new AddInterfaceFromTemplateProvider());
    providers.add(new AddMethodFromTemplateProvider());
    providers.add(new AddTypeLevelAnnotationProvider());
    providers.add(new ValidateRequiredAnnotationProvider());

    List<PlatformClassTransformer> list = new ArrayList<>();
    list.add(new IdGeneratorClassTransformer());
    list.add(new EnumTypeClassTransformer());
    list.add(new EnumTypeFieldConverterClassTransformer());
    list.add(new ExceptArchivedEntityClassTransformer());
    list.add(new DefaultValueFieldClassTransformer());
    list.add(new IndexFieldClassTransformer());
    list.add(new TemplateBasedClassTransformer(providers));
    list.add(new TextFieldClassTransformer());
    list.add(new HibernateSearchClassTransformer(provider));
    list.add(new IndexKeyValueMapClassTransformer());
    list.add(new TableFieldCommentClassTransformer());
    return list;
  }

  private static List<Path> listClassFiles(File classesDirectory, Listener log) {
    List<Path> result = new ArrayList<>();
    try (Stream<Path> stream = Files.walk(classesDirectory.toPath())) {
      stream.filter(Files::isRegularFile)
          .filter(p -> p.getFileName().toString().endsWith(".class"))
          .forEach(result::add);
    } catch (IOException e) {
      log.warn("Failed to walk " + classesDirectory, e);
    }
    Collections.sort(result);
    return result;
  }

  private static String toInternalName(Path rootDir, Path classFile) {
    Path rel = rootDir.relativize(classFile);
    String name = rel.toString().replace(File.separatorChar, '/');
    if (!name.endsWith(".class")) return null;
    return name.substring(0, name.length() - ".class".length());
  }

  private static boolean hasEnhancedMarker(byte[] bytes) {
    try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes))) {
      ClassFile cf = new ClassFile(in);
      AnnotationsAttribute attr = (AnnotationsAttribute) cf.getAttribute(
          AnnotationsAttribute.visibleTag);
      if (attr == null) return false;
      return attr.getAnnotation(ClassEnhanced.class.getName()) != null;
    } catch (IOException e) {
      return false;
    }
  }


  private static byte[] attachEnhancedMarker(byte[] bytes, String version) throws IOException {
    ClassFile cf;
    try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes))) {
      cf = new ClassFile(in);
    }
    ConstPool cp = cf.getConstPool();
    AnnotationsAttribute attr = (AnnotationsAttribute) cf.getAttribute(
        AnnotationsAttribute.visibleTag);
    if (attr == null) {
      attr = new AnnotationsAttribute(cp, AnnotationsAttribute.visibleTag);
      cf.addAttribute(attr);
    } else if (attr.getAnnotation(ClassEnhanced.class.getName()) != null) {
      ByteArrayOutputStream bos = new ByteArrayOutputStream(bytes.length);
      try (DataOutputStream out = new DataOutputStream(bos)) {
        cf.write(out);
      }
      return bos.toByteArray();
    }

    Annotation marker = new Annotation(ClassEnhanced.class.getName(), cp);
    StringMemberValue v = new StringMemberValue(version == null ? "" : version, cp);
    marker.addMemberValue("version", v);
    attr.addAnnotation(marker);

    ByteArrayOutputStream bos = new ByteArrayOutputStream(bytes.length + 64);
    try (DataOutputStream out = new DataOutputStream(bos)) {
      cf.write(out);
    }
    return bos.toByteArray();
  }

  public static final class Result {
    private final int enhanced;
    private final int skippedNoTransform;
    private final int skippedAlreadyMarked;
    private final int failed;

    public Result(int enhanced, int skippedNoTransform, int skippedAlreadyMarked, int failed) {
      this.enhanced = enhanced;
      this.skippedNoTransform = skippedNoTransform;
      this.skippedAlreadyMarked = skippedAlreadyMarked;
      this.failed = failed;
    }

    public static Result empty() {
      return new Result(0, 0, 0, 0);
    }

    public int getEnhanced() { return enhanced; }
    public int getSkippedNoTransform() { return skippedNoTransform; }
    public int getSkippedAlreadyMarked() { return skippedAlreadyMarked; }
    public int getFailed() { return failed; }
  }

  public interface Listener {
    Listener NOOP = new Listener() {
      @Override public void info(String msg) {}
      @Override public void warn(String msg, Throwable t) {}
    };

    void info(String msg);

    void warn(String msg, Throwable t);
  }
}
