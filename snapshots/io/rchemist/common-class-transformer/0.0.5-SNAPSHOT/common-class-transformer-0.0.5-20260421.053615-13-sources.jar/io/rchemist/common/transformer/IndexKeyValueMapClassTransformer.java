/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.EnumMemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Project : rchemist Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 * &#064;io.rchemist.common.jpa.domain.annotation.EntityAttributeValue 어노테이션이 매핑된 필드가 있다면 자동으로 다음 메소드를
 * 클래스에 추가한다.
 * &#064;Transient
 * &#064;PropertyBinding(binder  = @PropertyBinderRef(type = MapFieldPropertyBridge.class, params = {
 * &#064;Param(name = "indexName", value = "attributes") }))
 * &#064;IndexingDependency(derivedFrom = {
 * &#064;ObjectPath(@PropertyValue(propertyName = "userAttributes")), }, extraction =
 * &#064;ContainerExtraction(extract = ContainerExtract.NO)) public Map&lt;String, String>
 * getAttributeValues() { Map&lt;String, String> attributeValues = new HashMap<>(); for(UserAttribute
 * userAttribute : userAttributes.values()) { attributeValues.put(userAttribute.getName(),
 * userAttribute.getValue()); } return attributeValues; }
 **/
@Slf4j
public class IndexKeyValueMapClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final String INDEX_KEY_VALUE_CLASS = "io.rchemist.common.persistence.domain.annotation.IndexKeyValue";

  private static final String TRANSIENT_CLASS = "jakarta.persistence.Transient";

  private static final String PROPERTY_BINDING_CLASS = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyBinding";

  private static final String PROPERTY_BINDER_REF_CLASS = "org.hibernate.search.mapper.pojo.bridge.mapping.annotation.PropertyBinderRef";

  private static final String MAP_FIELD_PROPERTY_BRIDGE_CLASS = "io.rchemist.common.persistence.jpa.domain.data.MapFieldPropertyBridge";

  private static final String INDEXING_DEPENDENCY_CLASS = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexingDependency";
  private static final String OBJECT_PATH_CLASS = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.ObjectPath";
  private static final String PROPERTY_VALUE_CLASS = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyValue";
  private static final String CONTAINER_EXTRACTION_CLASS = "org.hibernate.search.mapper.pojo.extractor.mapping.annotation.ContainerExtraction";
  private static final String CONTAINER_EXTRACT_CLASS = "org.hibernate.search.mapper.pojo.extractor.mapping.annotation.ContainerExtract";
  private static final String PARAM_CLASS = "org.hibernate.search.mapper.pojo.common.annotation.Param";

  private static final String ONE_TO_MANY_CLASS = "jakarta.persistence.OneToMany";

  private static final int order = 100000;

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses,
      Map<String, TransformCondition> classTransformConditions)
      throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {


    if (!transformedEntityClassNames.contains(result.getClassName())) {

      // log.debug("Target class name is " + result.getClassName());

      boolean transformed = false;
      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<MethodInfo> methods = targetClassFile.getMethods();

      CHECK_INDEX_KEY_VALUE:
      for (MethodInfo info : methods) {
        CtMethod method;
        try {
          method = targetClass.getDeclaredMethod(info.getName());
        }catch (Exception e) {
          // skip
          continue;
        }

        List<?> objects = info.getAttributes();
        Iterator<?> iterator = objects.iterator();

        boolean hasIndexKeyValue = method.hasAnnotation(INDEX_KEY_VALUE_CLASS);

        if (!hasIndexKeyValue) {
          continue;
        }

        while (iterator.hasNext()) {
          Object object = iterator.next();
          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            AnnotationsAttribute attr = (AnnotationsAttribute) object;

            Annotation eav = attr.getAnnotation(INDEX_KEY_VALUE_CLASS);

            if (eav != null) {

              // 어노테이션 설정에 인덱싱 여부가 false 로 설정되어 있다면 수행하지 않는다.
              Boolean excluded = BytecodeUtil.getBooleanValue(eav, "excluded");

              if (BooleanUtils.toBoolean(excluded)) {
                continue CHECK_INDEX_KEY_VALUE;
              }

              // 이미 메소드에 인덱싱 관련 어노테이션이 있다면 더 이상 수행하지 않는다.
              boolean alreadyIndexed = checkHasIndexingAnnotations(method);

              if (alreadyIndexed) {
                continue CHECK_INDEX_KEY_VALUE;
              }

              // Indexing 관련 어노테이션을 추가할 대상 메소드
              String indexName = BytecodeUtil.getStringValue(eav, "indexName");
              if (StringUtils.isEmpty(indexName)) {
                indexName = StringUtil.toLowerCamelCase(StringUtils.removeStart(method.getName(), "get"));
              }

              String derivedFromValue = BytecodeUtil.getStringValue(eav, "derivedFrom");

              /*
              // 아래 어노테이션을 메소드에 추가한다.
              @Transient
              @PropertyBinding(binder = @PropertyBinderRef(type = MapFieldPropertyBridge.class, params = {
                @Param(name = "indexName", value = "attributes")
              }))
              @IndexingDependency(derivedFrom = {
                @ObjectPath(@PropertyValue(propertyName = "userAttributes")),
                }, extraction = @ContainerExtraction(extract = ContainerExtract.NO))
               */
              Annotation transientAnnotation = new Annotation(TRANSIENT_CLASS, constPool);
              attr.addAnnotation(transientAnnotation);

              Annotation propertyBindingAnnotation = new Annotation(PROPERTY_BINDING_CLASS,
                  constPool);
              Annotation propertyBinderRefAnnotation = new Annotation(PROPERTY_BINDER_REF_CLASS,
                  constPool);
              propertyBinderRefAnnotation.addMemberValue("type",
                  new ClassMemberValue(MAP_FIELD_PROPERTY_BRIDGE_CLASS, constPool));

              ArrayMemberValue params = new ArrayMemberValue(constPool);

              Annotation paramAnnotation = new Annotation(PARAM_CLASS, constPool);
              paramAnnotation.addMemberValue("name", new StringMemberValue("indexName", constPool));
              paramAnnotation.addMemberValue("value", new StringMemberValue(indexName, constPool));

              params.setValue(new AnnotationMemberValue[]{
                  new AnnotationMemberValue(paramAnnotation, constPool)});

              propertyBinderRefAnnotation.addMemberValue("params", params);

              propertyBindingAnnotation.addMemberValue("binder",
                  new AnnotationMemberValue(propertyBinderRefAnnotation, constPool));

              attr.addAnnotation(propertyBindingAnnotation);

              Annotation indexingDependencyAnnotation = new Annotation(INDEXING_DEPENDENCY_CLASS,
                  constPool);

              ArrayMemberValue derivedFrom = new ArrayMemberValue(constPool);
              Annotation objectPathAnnotation = new Annotation(OBJECT_PATH_CLASS, constPool);

              ArrayMemberValue propertyValue = new ArrayMemberValue(constPool);

              Annotation propertyValueAnnotation = new Annotation(PROPERTY_VALUE_CLASS, constPool);
              propertyValueAnnotation.addMemberValue("propertyName",
                  new StringMemberValue(derivedFromValue, constPool));

              propertyValue.setValue(new AnnotationMemberValue[]{new AnnotationMemberValue(propertyValueAnnotation, constPool)});


              objectPathAnnotation.addMemberValue("value",
                  propertyValue);

              AnnotationMemberValue objectPath = new AnnotationMemberValue(objectPathAnnotation, constPool);
              derivedFrom.setValue(new AnnotationMemberValue[]{objectPath});

              indexingDependencyAnnotation.addMemberValue("derivedFrom", derivedFrom);
              Annotation containerExtractionAnnotation = new Annotation(CONTAINER_EXTRACTION_CLASS,
                  constPool);
              EnumMemberValue containerExtract = new EnumMemberValue(constPool);
              containerExtract.setType(CONTAINER_EXTRACT_CLASS);
              containerExtract.setValue("NO");
              containerExtractionAnnotation.addMemberValue("extract", containerExtract);
              indexingDependencyAnnotation.addMemberValue("extraction",
                  new AnnotationMemberValue(containerExtractionAnnotation, constPool));

              attr.addAnnotation(indexingDependencyAnnotation);

              info.addAttribute(attr);

              transformed = true;


            }


          }
        }


      }

      transformedEntityClassNames.add(className);

      if (transformed) {
        result.arrangeTransformResultByClassFile(targetClassFile);
      }

    }
    return result;
  }

  private static String getTargetEntityClassName(AnnotationsAttribute attr) {
    Annotation oneToMany = attr.getAnnotation(ONE_TO_MANY_CLASS);

    if (oneToMany == null) {
      // fatal error
      throw new RuntimeException(
          "EntityAttributeValue annotation is not used with OneToMany annotation. Please check your code.");
    }

    ClassMemberValue targetEntityClassValue = (ClassMemberValue) oneToMany.getMemberValue(
            "targetEntity");
    String targetEntityClassName = targetEntityClassValue.getValue();

    if (StringUtils.isBlank(targetEntityClassName)) {
      // fatal error
      throw new RuntimeException(
          "EntityAttributeValue targetEntity class is not defined. @OneToMany(targetEntity=...) is required. Please check your code.");
    }
    return targetEntityClassName;
  }

  private static boolean checkHasIndexingAnnotations(CtMethod targetMethod) {
    boolean alreadyIndexed = false;

    Object[] methodAvailableAnnotations = targetMethod.getAvailableAnnotations();
    if (ArrayUtils.isNotEmpty(methodAvailableAnnotations)) {
      for (Object o : methodAvailableAnnotations) {
        if (o.toString().startsWith("@"+PROPERTY_BINDING_CLASS)
            || o.toString().startsWith("@"+PROPERTY_BINDER_REF_CLASS)
            || o.toString().startsWith("@"+INDEXING_DEPENDENCY_CLASS)) {
          return true;
        }
      }
    }
    return alreadyIndexed;
  }

  @Override
  public int getOrder() {
    return order;
  }

}
