/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.Serializable;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class RestrictOnDeleteDTO implements Serializable {

  public RestrictOnDeleteDTO(String entityClassName, String property) {
    this.entityClassName = entityClassName;
    this.property = property;
  }

  protected String entityClassName;
  protected String property;

  // 처음부터 Class 를 lookup 하면 ClassTransformation 에서 문제가 생길 수 있다.
  // 따라서 처음엔 이름만 받고, 필요할 때 lookup 한다.
  public Class getEntityClass(){
    try {
      return Class.forName(entityClassName);
    } catch (ClassNotFoundException e) {
      throw new RuntimeException("No Class for name" + entityClassName);
    }
  }

}
