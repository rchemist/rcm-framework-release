/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.ExcludeTransform;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.util.List;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class AddMethodFromTemplateProvider extends AbstractTemplateBasedClassTransformProvider {

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 600;

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, NotFoundException {
    CtMethod[] methodsToCopy = result.getTemplateClass().getDeclaredMethods();
    if(ArrayUtils.isNotEmpty(methodsToCopy)){
      for (CtMethod method : methodsToCopy) {
        if (method.hasAnnotation(ExcludeTransform.class)) {
        } else {

          try {
            CtClass[] paramTypes = method.getParameterTypes();
            CtMethod originalMethod = result.getTargetClass().getDeclaredMethod(method.getName(), paramTypes);

            try{
              // get annotations from original method
              result.getTargetClass().removeMethod(originalMethod);
            }catch (Exception e){
              // method not found 가 정상이다.
              // e.printStackTrace();
            }


          } catch (Exception e) {
            // Do nothing -- we don't need to remove a method because it doesn't exist
            // e.printStackTrace();
          }

          try{
            CtMethod copiedMethod = new CtMethod(method, result.getTargetClass(), null);

            // Copy annotations from original method to the copied method
            MethodInfo originalMethodInfo = method.getMethodInfo();
            MethodInfo copiedMethodInfo = copiedMethod.getMethodInfo();

            List<AttributeInfo> attributes = originalMethodInfo.getAttributes();
            for (AttributeInfo info : attributes) {
              if (info instanceof AnnotationsAttribute) {
                AnnotationsAttribute attribute = (AnnotationsAttribute) info;
                Annotation[] annotations = attribute.getAnnotations();
                if (ArrayUtils.isNotEmpty(annotations)) {
                  copiedMethodInfo.addAttribute(attribute.copy(copiedMethodInfo.getConstPool(), null));
                }
              }
            }
            result.getTargetClass().addMethod(copiedMethod);
          }catch (Exception e){
            // duplicated method
            e.printStackTrace();
          }


        }
      }
      return result.arrangeTransformResult();
    }
    return result;
  }


}
