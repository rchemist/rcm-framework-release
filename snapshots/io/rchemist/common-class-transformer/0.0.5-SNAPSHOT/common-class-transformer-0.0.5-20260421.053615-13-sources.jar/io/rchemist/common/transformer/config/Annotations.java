/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.config;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class Annotations {

  public static final String PERSISTENCE_ID_CLASS = "jakarta.persistence.Id";
  public static final String PERSISTENCE_TABLE_CLASS = "jakarta.persistence.Table";
  public static final String PERSISTENCE_COLUMN_CLASS = "jakarta.persistence.Column";
  public static final String PERSISTENCE_ENTITY_LISTENERS_CLASS = "jakarta.persistence.EntityListeners";

  public static final String PERSISTENCE_EMBEDDED_CLASS = "jakarta.persistence.Embedded";
  public static final String PERSISTENCE_JOIN_COLUMN_CLASS = "jakarta.persistence.JoinColumn";

  public static final String PERSISTENCE_ONE_TO_MANY_CLASS = "jakarta.persistence.OneToMany";
  public static final String PERSISTENCE_ONE_TO_ONE_CLASS = "jakarta.persistence.OneToOne";
  public static final String PERSISTENCE_MANY_TO_ONE_CLASS = "jakarta.persistence.ManyToOne";
  public static final String PERSISTENCE_MANY_TO_MANY_CLASS = "jakarta.persistence.ManyToMany";
  public static final String PERSISTENCE_ENTITY_CLASS = "jakarta.persistence.Entity";
  public static final String PERSISTENCE_INDEX_CLASS = "jakarta.persistence.Index";
  public static final String PERSISTENCE_GENERATED_VALUE_CLASS = "jakarta.persistence.GeneratedValue";
  public static final String PERSISTENCE_GENERATION_TYPE_CLASS = "jakarta.persistence.GenerationType";
  public static final String PERSISTENCE_GENERATION_TYPE_SEQUENCE = "SEQUENCE";

  public static final String HIBERNATE_COMMENT = "org.hibernate.annotations.Comment";
  public static final String HIBERNATE_WHERE_CLASS = "org.hibernate.annotations.Where";
  public static final String HIBERNATE_COLUMN_DEFAULT_CLASS = "org.hibernate.annotations.ColumnDefault";
  public static final String HIBERNATE_TYPE_CLASS = "org.hibernate.annotations.Type";
  public static final String HIBERNATE_PARAMETER_CLASS = "org.hibernate.annotations.Parameter";
  public static final String HIBERNATE_GENERIC_GENERATOR_CLASS = "org.hibernate.annotations.GenericGenerator";
  public static final String HIBERNATE_FILTER_CLASS = "org.hibernate.annotations.Filter";
  public static final String HIBERNATE_FILTER_DEF_CLASS = "org.hibernate.annotations.FilterDef";
  public static final String HIBERNATE_FILTER_DEFS_CLASS = "org.hibernate.annotations.FilterDefs";
  public static final String HIBERNATE_FILTERS_CLASS = "org.hibernate.annotations.Filters";
  public static final String HIBERNATE_PARAM_DEF_CLASS = "org.hibernate.annotations.ParamDef";
  public static final String HIBERNATE_SQL_DELETE_CLASS = "org.hibernate.annotations.SQLDelete";
  public static final String HIBERNATE_SQL_FRAGMENT_ALIAS_CLASS = "org.hibernate.annotations.SqlFragmentAlias";

  /*
   */






}
