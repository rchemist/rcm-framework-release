/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.TransformCondition;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public abstract class AbstractClassTransformManager implements ClassTransformManager {

  private Set<String> transformedClassNames = new HashSet<>();
  private Set<String> targetEntityClasses = new HashSet<>();

  /**
   * 전체 클래스패스를 탐색하면서 TransformCondition 을 생성한다.
   */
  private Map<String, TransformCondition> classTransformConditions;

  private List<PlatformClassTransformer> classTransformers;

  private List<String> classTransformTargetPackages;

  private boolean transformersSorted = false;


  public Set<String> getTransformedClassNames() {
    return transformedClassNames;
  }

  public Set<String> getTargetEntityClasses() {
    return targetEntityClasses;
  }

  public void addTargetEntityClass(String targetEntityClass){
    if(targetEntityClasses == null){
      targetEntityClasses = new HashSet<>();
    }
    targetEntityClasses.add(targetEntityClass);
  }

  public void addTransformedClassName(String className){
    if(transformedClassNames == null){
      transformedClassNames = new HashSet<>();
    }
    transformedClassNames.add(className);
  }

  @Override
  public Map<String, TransformCondition> getClassTransformConditions() {
    return classTransformConditions;
  }

  @Override
  public void addClassTransformCondition(TransformCondition condition){
    if(classTransformConditions == null){
      classTransformConditions = new HashMap<>();
    }
    log.debug("new condition has putted "+ condition.getInterfaceClassName() + " | " + condition.getTemplateClassName());
    classTransformConditions.put(condition.getInterfaceClassName(), condition);
  }

  @Override
  public void setClassTransformConditions(Map<String, TransformCondition> classTransformConditions) {
    this.classTransformConditions = classTransformConditions;
  }

  public List<PlatformClassTransformer> getClassTransformers() {
    if(!transformersSorted){
      Comparator<PlatformClassTransformer> comparator = Comparable::compareTo;
      classTransformers.sort(comparator);
      this.transformersSorted = true;
    }
    return classTransformers;
  }

  public void setClassTransformers(List<PlatformClassTransformer> classTransformers) {
    this.classTransformers = classTransformers;
  }

  public void addClassTransformer(
      PlatformClassTransformer classFileTransformer){
    if(!getClassTransformers().contains(classFileTransformer)){
      getClassTransformers().add(classFileTransformer);
    }
  }

  @Override
  public List<String> getClassTransformTargetPackages() {
    return CollectionUtils.isEmpty(classTransformTargetPackages) ? List.of("io.rchemist") : classTransformTargetPackages;
  }

  @Override
  public void setClassTransformTargetPackages(List<String> classTransformTargetPackages) {
    this.classTransformTargetPackages = classTransformTargetPackages;
  }

  public boolean isTransformersSorted() {
    return transformersSorted;
  }

  public void setTransformersSorted(boolean sorted){
    this.transformersSorted = sorted;
  }

  /**
   * 클래스 Transform 대상 클래스인지 - 지정된 패키지 하위의 클래스인지 확인한다.
   */
  @Override
  public boolean containsTargetPackages(String convertedClassName) {

    if(CollectionUtils.isEmpty(classTransformTargetPackages))
      return true;

    // Full Classpath 의 맨 뒤에 있는 . 앞의 글자가 패키지 이름이다.
    String packageName = StringUtils.substringBeforeLast(convertedClassName, ".");

    for(String targetPackage : CollectionUtils.emptyIfNull(classTransformTargetPackages)){
      if(packageName.startsWith(targetPackage)){
        return true;
      }
    }

    return false;

  }

}
