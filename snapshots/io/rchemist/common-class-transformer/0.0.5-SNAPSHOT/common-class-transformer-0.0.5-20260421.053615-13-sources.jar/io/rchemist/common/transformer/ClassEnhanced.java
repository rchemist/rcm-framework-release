/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 빌드 타임 Maven 플러그인이 클래스 바이트코드 변환을 완료했을 때 부착하는 마커.
 *
 * <p>런타임의 {@link ClassTransformManager} 가 이 annotation 이 붙은 클래스는
 * 이미 변환되었다고 판단하여 skip 하며, 빌드 타임 변환과 런타임 변환의 이중 적용을 방지한다.</p>
 *
 * <p>개발자가 직접 부착하지 않는다 — {@code common-class-transformer-maven-plugin} 의
 * {@code enhance} goal 이 자동으로 관리한다.</p>
 *
 * <p>0.0.5 에서 도입되어 0.0.x 시리즈 동안 런타임 경로와 병존하고, 0.1.0 에서 런타임
 * 경로가 완전히 제거되면 마커 존재는 사실상 "변환 완료" 의 유일한 증거가 된다.</p>
 *
 * @since 0.0.5
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ClassEnhanced {

  /**
   * 변환을 수행한 플러그인 버전. 디버깅과 점진 이주 추적 용도.
   */
  String version() default "";
}
