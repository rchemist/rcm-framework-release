/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.lang.instrument.IllegalClassFormatException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Project : rchemist
 * Created by kunner
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class TableFieldCommentClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedClassNames = new HashSet<>();

  private static final String COMMENT_SPLIT = ". ";

  private static final int order = 900;

  private static final String TARGET_ANNOTATION = "io.rchemist.common.persistence.domain.annotation.Description";


  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws IllegalClassFormatException, CannotCompileException, NotFoundException, ClassNotFoundException{

    Class<?> annotationClass = resolveClass(TARGET_ANNOTATION, result.getClassLoader());
    if (annotationClass != null && !transformedClassNames.contains(result.getClassName())) {
      String className = result.getClassName();
      try {

        ClassFile targetClassFile = result.getTargetClassFile();

        AnnotationsAttribute annotationsAttribute = null;
        List<?> attributes = targetClassFile.getAttributes();
        boolean doClassTransform = false;

        Annotation descriptionAnnotation = null;
        Iterator<?> itr = attributes.iterator();
        boolean hasCommentOnType = false;

        CHECK_DO_TRANSFORM:
        while (itr.hasNext()) {
          Object object = itr.next();

          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            Annotation[] annotations = ((AnnotationsAttribute) object).getAnnotations();
            if (!doClassTransform) {
              /**
               * 인덱스는 필드에 있는 정보를 읽어 Entity Class의 Type 어노테이션으로 바꾸는 것이다.
               * MappedSuperClass 나 Embeddable 에 있는 클래스의 값을 아무리 바꿔 봐야 실제 Entity 클래스가 바뀌지 않는다.
               * 따라서 이 TableFieldCommentClassTransformer 대상은 반드시 @Entity 클래스여야 한다.
               */
              doClassTransform = BytecodeUtil.containsAnnotation(annotations
                  , Annotations.PERSISTENCE_ENTITY_CLASS
              );

              // @TABLE 어노테이션과 함께 @Description 어노테이션이 존재해야만 classTransform 을 처리한다.
              /*if (doClassTransform) {
                doClassTransform = BytecodeUtil.containsAnnotation(annotations
                    , TARGET_ANNOTATION);
              }*/
            }

            for (Annotation annotation : annotations) {
              // Hibernate Comment 어노테이션이 있다면 이 클래스 트랜스포머를 더 이상 사용하지 않는다.
              if (annotation.getTypeName().equals(Annotations.HIBERNATE_COMMENT)) {
                // Comment 어노테이션이 이미 존재한다. 굳이 Class 에 붙어 있는 Description 어노테이션을 조사할 필요가 없다.
                doClassTransform = false;
                hasCommentOnType = true;
                break CHECK_DO_TRANSFORM;
              } else if (annotation.getTypeName().equals(TARGET_ANNOTATION)) {
                descriptionAnnotation = annotation;
                annotationsAttribute = ((AnnotationsAttribute) object);
                hasCommentOnType = false;
              }
            }
          }
        }

        if (doClassTransform) {

          boolean classTransformed = false;

          transformedClassNames.add(className);

          if (!hasCommentOnType) {
            if (descriptionAnnotation != null) {
              // Class 단위에 @Comment 가 없을 때 Type 에 @Description 이 있는지 확인하고 있으면 @Comment 를 추가한다.
              String comment = StringUtil.toString(getStringMemberValue(descriptionAnnotation.getMemberValue("name")));
              String descriptionComment = StringUtil.toString(getStringMemberValue(descriptionAnnotation.getMemberValue("comment")));

              comment = getProperComment(comment, descriptionComment);

              if (StringUtils.isNotEmpty(comment)) {
                // comment 가 not empty 일 때 Type 에 @Comment 어노테이션을 추가한다.
                Annotation annotation = createCommentAnnotation(result, comment);

                annotationsAttribute.addAnnotation(annotation);
                targetClassFile.addAttribute(annotationsAttribute);

                classTransformed = true;
              }


            }
          }

          // 이제 필드 단위에 @Description 이 있는지 확인하고 해당 필드에 @Comment 가 없으면 마찬가지로 @Comment 를 추가한다.
          // includeSuperClass=false: superclass 의 필드를 포함하면 그 필드의 AnnotationsAttribute 에
          // target 의 ConstPool 기반 annotation 을 추가하게 되어 superclass 의 ConstPool 인덱스가
          // 불일치(Methodref 자리에 Utf8 기대 등) → 다음 target 이 superclass 필드를 읽을 때
          // ClassCastException. 각 class 는 자기 자신이 target 일 때 자기 필드만 처리한다.
          Set<FieldInfo> fieldInfos = super.getAllFields(targetClassFile, annotationClass, null, false, false);
          // 해당 필드들에 @Comment 가 없는지 확인하고 있으면 대상에서 제거한다.
          for (FieldInfo info : CollectionUtils.emptyIfNull(fieldInfos)) {
            List<?> objects = info.getAttributes();
            Iterator<?> iters = objects.iterator();

            while (iters.hasNext()) {
              Object obj = iters.next();

              if (AnnotationsAttribute.class.isAssignableFrom(obj.getClass())) {
                AnnotationsAttribute attr = (AnnotationsAttribute) obj;
                Annotation[] items = attr.getAnnotations();

                String fieldComment = null;
                for (Annotation annotation : items) {
                  if (annotation.getTypeName().equals(TARGET_ANNOTATION)) {
                    fieldComment = StringUtil.toString(getStringMemberValue(annotation.getMemberValue("name")));
                    String fieldDescriptionComment = StringUtil.toString(getStringMemberValue(annotation.getMemberValue("comment")));

                    fieldComment = getProperComment(fieldComment, fieldDescriptionComment);
                  } else if (annotation.getTypeName().equals(Annotations.HIBERNATE_COMMENT)) {
                    // hibernate @Comment 가 있다면 해당 필드에 @Comment 를 추가할 수 없다.
                    fieldComment = null;
                    break;
                  }
                }

                if (StringUtils.isNotEmpty(fieldComment)) {
                  Annotation annotation = createCommentAnnotation(result, fieldComment);
                  attr.addAnnotation(annotation);

                  info.addAttribute(attr);
                  classTransformed = true;
                }
              }
            }
          }

          if (classTransformed) {
            result.arrangeTransformResultByClassFile(targetClassFile);
          }


        }


        return result;

      } catch (Exception e) {
        System.out.println("오류 발생: " + className);
        e.printStackTrace();
      }
    }
    return result;
  }

  private static Annotation createCommentAnnotation(TransformResult result, String comment) {
    Annotation annotation = new Annotation(Annotations.HIBERNATE_COMMENT, result.getConstPool());
    annotation.addMemberValue("value", new StringMemberValue(comment, result.getConstPool()));
    return annotation;
  }

  private static String getProperComment(String comment, String descriptionComment) {
    if (StringUtils.isNotEmpty(descriptionComment) && !StringUtils.equals(comment, descriptionComment)) {
      comment = comment + COMMENT_SPLIT + descriptionComment;
    }
    return comment;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
