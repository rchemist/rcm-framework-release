/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.IntegerMemberValue;
import javassist.bytecode.annotation.MemberValue;
import lombok.extern.slf4j.Slf4j;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class TextFieldClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final int order = 400;

  private static final String TARGET_ANNOTATION = "io.rchemist.common.persistence.domain.annotation.Text";

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    if (!transformedEntityClassNames.contains(result.getClassName())) {
      boolean transformed = false;
      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<FieldInfo> fieldInfos = targetClassFile.getFields();

      for (FieldInfo info : fieldInfos) {
        CtField field = targetClass.getDeclaredField(info.getName());
        AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);

        List<?> objects = info.getAttributes();
        Iterator<?> iters = objects.iterator();

        boolean doTransform = false;
        while (iters.hasNext()) {
          Object object = iters.next();
          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            AnnotationsAttribute attr = (AnnotationsAttribute) object;
            Annotation[] items = attr.getAnnotations();

            if (hasFieldAnnotationByName(info, TARGET_ANNOTATION)) {
              doTransform = true;
              for (Annotation annotation : items) {
                if (annotation.getTypeName().equals(Annotations.PERSISTENCE_COLUMN_CLASS)) {
                  if (annotation.getMemberValue("length") != null) {
                    doTransform = false;
                    annotationsAttribute.addAnnotation(annotation);
                    log.warn("@Text 가 붙은 필드에 @Column.length 속성이 설정되었습니다. @Text 자동 처리를 SKIP 합니다. \n at " + targetClass.getName() + "." + field.getName());
                  } else {
                    MemberValue length = new IntegerMemberValue(constPool, Integer.MAX_VALUE);
                    annotation.addMemberValue("length", length);
                    annotationsAttribute.addAnnotation(annotation);
                  }
                } else if (annotation.getTypeName().equals(Annotations.HIBERNATE_TYPE_CLASS)) {
                  doTransform = false;
                  log.warn("@Text 가 붙은 필드에 @Type 이 설정되었습니다. @Text 자동 처리를 SKIP 합니다. \n at " + targetClass.getName() + "." + field.getName());
                  annotationsAttribute.addAnnotation(annotation);
                } else {
                  annotationsAttribute.addAnnotation(annotation);
                }
              }
            } else {
              annotationsAttribute = attr;
            }
          }
        }

        if (doTransform) {
          transformed = true;
          info.addAttribute(annotationsAttribute);
        }
      }

      transformedEntityClassNames.add(className);

      if (transformed) {
        result.arrangeTransformResultByClassFile(targetClassFile);
      }

    }
    return result;
  }

  @Override
  public int getOrder() {
    return order;
  }

  private static boolean hasFieldAnnotationByName(FieldInfo info, String annotationTypeName) {
    for (Object obj : info.getAttributes()) {
      if (obj instanceof AnnotationsAttribute attr) {
        if (attr.getAnnotation(annotationTypeName) != null) {
          return true;
        }
      }
    }
    return false;
  }
}
