/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import io.rchemist.common.transformer.PlatformClassTransformer;
import io.rchemist.common.transformer.provider.TemplateBasedClassTransformProvider;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class ClassTransformConfig implements Serializable {

  private String[] packagesToScan;

  private boolean useDynamicInstrumentationLoader = false;

  List<TemplateBasedClassTransformProvider> customTemplateBasedClassTransformProviders = new ArrayList<>();

  List<PlatformClassTransformer> customClassTransformers = new ArrayList<>();

  public ClassTransformConfig withUseDynamicInstrumentationLoader(
      boolean useDynamicInstrumentationLoader) {
    this.useDynamicInstrumentationLoader = useDynamicInstrumentationLoader;
    return this;
  }

  public ClassTransformConfig withPackagesToScan(String... packagesToScan) {
    if (packagesToScan != null && ArrayUtils.isEmpty(packagesToScan)) {
      this.packagesToScan = new String[]{"io.rchemist"};
    } else {
      this.packagesToScan = packagesToScan;
    }

    return this;
  }

  public ClassTransformConfig addCustomTemplateBasedClassTransformProviders(TemplateBasedClassTransformProvider... customTemplateBasedClassTransformProviders) {
    this.customTemplateBasedClassTransformProviders.addAll(List.of(customTemplateBasedClassTransformProviders));
    return this;
  }

  public ClassTransformConfig addCustomClassTransformers(PlatformClassTransformer... customClassTransformers) {
    this.customClassTransformers.addAll(List.of(customClassTransformers));
    return this;
  }

  public ClassTransformConfig withCustomTemplateBasedClassTransformProviders(
      List<TemplateBasedClassTransformProvider> customTemplateBasedClassTransformProviders) {
    this.customTemplateBasedClassTransformProviders = customTemplateBasedClassTransformProviders;
    return this;
  }

  public ClassTransformConfig withCustomClassTransformers(
      List<PlatformClassTransformer> customClassTransformers) {
    this.customClassTransformers = customClassTransformers;
    return this;
  }

  public boolean isBlankPackagesToScan() {
    return packagesToScan == null || packagesToScan.length == 0;
  }

  public List<String> getPackagesToScan(String[] defaultPackagesToScan) {
    if (isBlankPackagesToScan()) {
      return List.of(defaultPackagesToScan);
    }
    return List.of(packagesToScan);
  }
}
