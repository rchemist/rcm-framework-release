/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.MapUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * Hibernate 5.6.1 이상에서 UserType Converter 를 사용할 때 컬럼에 @Type 을 사용하지 않으면 deserialize 할 때 오류가 발생한다.
 * @Column 어노테이션을 가진 필드가 EnumType
 **/
@Slf4j
@Component
public class EnumTypeFieldConverterClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final String ENUM_TYPE_CONVERTER = "io.rchemist.common.persistence.jpa.config.mapping.type.EnumTypeConverter";
  private static final String STRING_ARRAY_CONVERTER = "io.rchemist.common.persistence.jpa.config.mapping.type.StringArrayTypeConverter";
  private static final String MONEY_CONVERTER = "io.rchemist.common.persistence.jpa.config.mapping.type.MoneyConverter";
  private static final int order = 500;

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    if (!transformedEntityClassNames.contains(result.getClassName())) {

      boolean doColumnTransform = false;

      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<FieldInfo> fieldInfos = targetClassFile.getFields();

      for (FieldInfo info : fieldInfos) {

        CtField field = targetClass.getDeclaredField(info.getName());


        List<?> objects = info.getAttributes();
        Iterator<?> iters = objects.iterator();

        boolean converterSettled = false;

        AnnotationsAttribute annotationsAttribute = null;

        COLUMN_SEARCH:
        while (iters.hasNext()) {
          Object object = iters.next();
          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            AnnotationsAttribute attr = (AnnotationsAttribute) object;
            Annotation[] items = attr.getAnnotations();

            annotationsAttribute = attr;

            for (Annotation annotation : items) {
              if (annotation.getTypeName().equals(Annotations.PERSISTENCE_COLUMN_CLASS)) {

                if(StringUtils.equals(field.getType().getSimpleName(), "String[]")){
                  converterSettled = true;
                  setConverterAnnotation(constPool, STRING_ARRAY_CONVERTER, attr, null);
                  break COLUMN_SEARCH;
                }else if(BytecodeUtil.isAssignableFrom(field.getType(), EnumType.class.getName())){
                  converterSettled = true;
                  setConverterAnnotation(constPool, ENUM_TYPE_CONVERTER, attr, MapUtil.asMap(MapUtil.entry("PARAMETER_CLASS_NAME|" + info.getName(), field.getType().getName())));
                  break COLUMN_SEARCH;
                }else if(BytecodeUtil.isAssignableFrom(field.getType(), "io.rchemist.common.money.Money")){
                  converterSettled = true;
                  setConverterAnnotation(constPool, MONEY_CONVERTER, attr, null);
                  break COLUMN_SEARCH;
                }

              }

            }
          }
        }

        if (converterSettled) {
          info.addAttribute(annotationsAttribute);
          doColumnTransform = true;
        }

      }

      transformedEntityClassNames.add(className);

      if (doColumnTransform) {
        result.arrangeTransformResultByClassFile(targetClassFile);
      }

    }
    return result;
  }

  private void setConverterAnnotation(ConstPool constPool, String converterClass,
      AnnotationsAttribute attr, Map<String, String> parameters) {
    Annotation converterAnnotation = new Annotation(Annotations.HIBERNATE_TYPE_CLASS,
        constPool);
    ClassMemberValue converter = new ClassMemberValue(converterClass, constPool);
    //StringMemberValue converter = new StringMemberValue(constPool);
    converter.setValue(converterClass);
    converterAnnotation.addMemberValue("value", converter);

    if(MapUtils.isNotEmpty(parameters)){

      ArrayMemberValue parameterValues = new ArrayMemberValue(constPool);
      List<MemberValue> params = new ArrayList<>();
      for(Entry<String, String> entry : parameters.entrySet()){
        String key = entry.getKey();
        String value = entry.getValue();
        AnnotationMemberValue parameter = new AnnotationMemberValue(constPool);
        Annotation pValue = new Annotation(Annotations.HIBERNATE_PARAMETER_CLASS, constPool);
        pValue.addMemberValue("name", new StringMemberValue(key, constPool));
        pValue.addMemberValue("value", new StringMemberValue(value, constPool));
        parameter.setValue(pValue);
        params.add(parameter);
      }
      parameterValues.setValue(params.toArray(new MemberValue[0]));
      converterAnnotation.addMemberValue("parameters", parameterValues);

    }

    attr.addAnnotation(converterAnnotation);
  }

  @Override
  public int getOrder() {
    return order;
  }
}
