/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * 원본 클래스와 템플릿 클래스 간 @EntityListener 를 병합한다.
 *
 **/
@Slf4j
public class AddTypeLevelAnnotationProvider extends AbstractTemplateBasedClassTransformProvider {

  public static final String SQL_DELETE_TABLE_NAME = "__TABLE_NAME__";
  public static final String SQL_DELETE_ID_NAME = "__ID__";

  protected Set<String> REGISTERED_FILTER_DEF = new HashSet<>();

  private static final String ID_GENERATOR = "io.rchemist.common.jpa.domain.annotation.IdGenerator";

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 300;

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException{
    return processTransformTypeLevelAnnotationTransformResult(result);
  }

  @Override
  public TransformResult transformClassWithNonCondition(TransformResult result) throws CannotCompileException, NotFoundException, IOException {

    // 임시로 템플릿 클래스를 자기 자신으로 넣는다
    ClassFile oldTemplateClassFile = result.getTemplateClassFile();
    result.setTemplateClassFile(result.getTargetClassFile());

    result = processTransformTypeLevelAnnotationTransformResult(result);

    // 템플릿 클래스를 다시 복원한다.
    result.setTemplateClassFile(oldTemplateClassFile);

    return result;
  }

  private TransformResult processTransformTypeLevelAnnotationTransformResult(TransformResult result) throws IOException {
    Annotation[] annotations = getDeclaredAnnotationByClassName(result, Annotations.PERSISTENCE_ENTITY_LISTENERS_CLASS
        , Annotations.HIBERNATE_SQL_DELETE_CLASS
        , Annotations.HIBERNATE_WHERE_CLASS
        , Annotations.HIBERNATE_FILTER_CLASS
        , Annotations.HIBERNATE_FILTERS_CLASS
        , Annotations.HIBERNATE_FILTER_DEF_CLASS
        , Annotations.HIBERNATE_FILTER_DEFS_CLASS);

    if (ArrayUtils.isNotEmpty(annotations)) {

      AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(result.getConstPool(), AnnotationsAttribute.visibleTag);
      List<?> attributes = result.getTargetClassFile().getAttributes();
      Iterator<?> itr = attributes.iterator();
      Annotation existingEntityListeners = null;
      Annotation existingSqlDelete = null;
      Annotation existingFilters = null;
      Annotation existingFilter = null;
      Annotation existingFilterDef = null;
      Annotation existingFilterDefs = null;
      Annotation existingWhere = null;

      Annotation table = null;

      while (itr.hasNext()) {
        Object object = itr.next();
        if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
          AnnotationsAttribute attr = (AnnotationsAttribute) object;
          Annotation[] items = attr.getAnnotations();
          boolean shouldAddAnnotation = false;
          for (Annotation annotation : items) {
            String typeName = annotation.getTypeName();
            if(typeName.equals(Annotations.PERSISTENCE_TABLE_CLASS)){
              table = annotation;
              // table 어노테이션을 별도로 저장하고 loop의 남은 로직을 수행함
            }else{
              if (typeName.equals(Annotations.PERSISTENCE_ENTITY_LISTENERS_CLASS)) {
                existingEntityListeners = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_SQL_DELETE_CLASS)){
                existingSqlDelete = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_FILTERS_CLASS)){
                existingFilters = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_FILTER_CLASS)){
                existingFilter = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_FILTER_DEF_CLASS)){
                existingFilterDef = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_FILTER_DEFS_CLASS)){
                existingFilterDefs = annotation;
                shouldAddAnnotation = true;
                continue;
              }else if(typeName.equals(Annotations.HIBERNATE_WHERE_CLASS)){
                existingWhere = annotation;
                shouldAddAnnotation = true;
                continue;
              }
            }
            annotationsAttribute.addAnnotation(annotation);
          }
          if (shouldAddAnnotation) {
            itr.remove();
          }
        }
      }

      Annotation entityListener = getAnnotationMemberByClassName(annotations, Annotations.PERSISTENCE_ENTITY_LISTENERS_CLASS);    // 템플릿 클래스에 선언된 @EntityListeners
      mergeEntityListeners(result, annotations, annotationsAttribute, existingEntityListeners, entityListener);

      Annotation sqlDelete = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_SQL_DELETE_CLASS);   // 템플릿 클래스에 선언된 @SQLDelete
      mergeSqlDelete(result, annotationsAttribute, existingSqlDelete, table, sqlDelete);

      // @Where 는 단 하나만 선언할 수 있으므로 이미 정의된 경우에는 skip 한다
      if(existingWhere == null){
        Annotation where = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_WHERE_CLASS);

        if(where != null){
          Annotation newWhere = new Annotation(Annotations.HIBERNATE_WHERE_CLASS, result.getConstPool());
          String clause = ((StringMemberValue) where.getMemberValue("clause")).getValue();
          newWhere.addMemberValue("clause", new StringMemberValue(clause, result.getConstPool()));
          annotationsAttribute.addAnnotation(newWhere);
        }
      }else{
        annotationsAttribute.addAnnotation(existingWhere);
      }

      // Filters 와 @FilterDefs 는 이상하게 적용이 안 된다.. 나중에 다시 ㅠㅠ
      // setFreshedFilterAnnotation(result, annotations, annotationsAttribute, existingFilters, existingFilter, existingFilterDef, existingFilterDefs);

      result.getTargetClassFile().addAttribute(annotationsAttribute);
      return result.arrangeTransformResultByClassFile(result.getTargetClassFile());

    }
    return result;
  }

  private void setFreshedFilterAnnotation(TransformResult result, Annotation[] annotations, AnnotationsAttribute annotationsAttribute, Annotation existingFilters, Annotation existingFilter, Annotation existingFilterDef, Annotation existingFilterDefs) {
    Annotation filters = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_FILTERS_CLASS);   // 템플릿 클래스에 선언된 @Filters
    Annotation filter = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_FILTER_CLASS);     // 템플릿 클래스에 선언된 @Filter
    Annotation filterDefs = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_FILTER_DEFS_CLASS);   // 템플릿 클래스에 선언된 @FilterDefs
    Annotation filterDef = getAnnotationMemberByClassName(annotations, Annotations.HIBERNATE_FILTER_DEF_CLASS);   // 템플릿 클래스에 선언된 @FilterDef


    // @FilterDefs, @FilterDef 중 무엇 하나라도 존재한다면
    if(existingFilterDefs != null || filterDefs != null || filterDef != null || existingFilterDef != null){
      Annotation newFilterDefs = (existingFilterDefs != null) ? existingFilterDefs :
          (filterDefs != null) ? filterDefs :
              new Annotation(Annotations.HIBERNATE_FILTER_DEFS_CLASS, result.getConstPool());

      newFilterDefs = mergeFilterDefs(result.getConstPool(), newFilterDefs, existingFilterDefs, filterDefs);

      if(existingFilterDef != null){
        List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();
        annotationMemberValues = getMergedFilterDefAnnotations(result.getConstPool(), newFilterDefs, annotationMemberValues, existingFilterDef);
        setNewFilterValues(result.getConstPool(), newFilterDefs, annotationMemberValues);
      }

      if(filterDef != null){
        List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();
        annotationMemberValues = getMergedFilterDefAnnotations(result.getConstPool(), newFilterDefs, annotationMemberValues, filterDef);
        setNewFilterValues(result.getConstPool(), newFilterDefs, annotationMemberValues);
      }
      annotationsAttribute.addAnnotation(newFilterDefs);
    }

    // 필터 관련 어노테이션이 존재하는 경우
    if(existingFilters != null || filters != null || existingFilter != null || filter != null){
      Annotation newFilters = (existingFilters != null) ? existingFilters :
          (filters != null) ? filters :
              new Annotation(Annotations.HIBERNATE_FILTERS_CLASS, result.getConstPool());

      newFilters = mergeFilters(result.getConstPool(), newFilters, existingFilters, filters);


      if(existingFilter != null){
        List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();
        annotationMemberValues = getMergedFilterAnnotations(result.getConstPool(), newFilters, annotationMemberValues, existingFilter);
        setNewFilterValues(result.getConstPool(), newFilters, annotationMemberValues);
      }

      if(filter != null){
        List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();
        annotationMemberValues = getMergedFilterAnnotations(result.getConstPool(), newFilters, annotationMemberValues, filter);
        setNewFilterValues(result.getConstPool(), newFilters, annotationMemberValues);
      }

      annotationsAttribute.addAnnotation(newFilters);
    }
  }

  private Annotation mergeFilters(ConstPool constPool, Annotation newFilters, Annotation... mergeAnnotations) {

    if(ArrayUtils.isEmpty(mergeAnnotations))
      return newFilters;

    for(Annotation merge : mergeAnnotations){
      newFilters = mergeFiltersAnnotations(constPool, newFilters, merge);
    }

    return newFilters;
  }

  private Annotation mergeFilterDefs(ConstPool constPool, Annotation newFilters, Annotation... mergeAnnotations) {

    if(ArrayUtils.isEmpty(mergeAnnotations))
      return newFilters;

    for(Annotation merge : mergeAnnotations){
      newFilters = mergeFilterDefsAnnotations(constPool, newFilters, merge);
    }

    return newFilters;
  }

  private Annotation mergeFilterDefsAnnotations(ConstPool constPool, Annotation newFilters, Annotation mergeFilters) {

    if(mergeFilters == null)
      return newFilters;

    // newFilters 에 Value 가 하나도 없는 상황이다
    MemberValue mergeValues = mergeFilters.getMemberValue("value");

    if(mergeValues == null)
      return newFilters;

    List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();

    ArrayMemberValue mvs = (ArrayMemberValue) mergeValues;
    for(MemberValue mv : mvs.getValue()){
      // mv 는 새 Filters 에 정의된 @Filter 어노테이션이다
      AnnotationMemberValue oldFilterValue = (AnnotationMemberValue) mv;
      Annotation oldFilter = oldFilterValue.getValue();

      annotationMemberValues = getMergedFilterDefAnnotations(constPool, newFilters, annotationMemberValues, oldFilter);
    }

    setNewFilterValues(constPool, newFilters, annotationMemberValues);

    return newFilters;
  }

  private Annotation mergeFiltersAnnotations(ConstPool constPool, Annotation newFilters, Annotation mergeFilters) {

    if(mergeFilters == null)
      return newFilters;

    // newFilters 에 Value 가 하나도 없는 상황이다
    MemberValue mergeValues = mergeFilters.getMemberValue("value");

    if(mergeValues == null)
      return newFilters;

    List<AnnotationMemberValue> annotationMemberValues = new ArrayList<>();

    ArrayMemberValue mvs = (ArrayMemberValue) mergeValues;
    for(MemberValue mv : mvs.getValue()){
      // mv 는 새 Filters 에 정의된 @Filter 어노테이션이다
      AnnotationMemberValue oldFilterValue = (AnnotationMemberValue) mv;
      Annotation oldFilter = oldFilterValue.getValue();

      annotationMemberValues = getMergedFilterAnnotations(constPool, newFilters, annotationMemberValues, oldFilter);
    }

    setNewFilterValues(constPool, newFilters, annotationMemberValues);

    return newFilters;
  }

  private void setNewFilterValues(ConstPool constPool, Annotation annotation, List<AnnotationMemberValue> annotationMemberValues) {
    if(CollectionUtils.isNotEmpty(annotationMemberValues)){
      ArrayMemberValue newValues = new ArrayMemberValue(constPool);
      MemberValue[] arrayMemberVaues = ArrayUtil.toArray(AnnotationMemberValue.class, annotationMemberValues);

      if(annotation.getMemberValue("value") != null){
        ArrayMemberValue oldValueArrays = (ArrayMemberValue) annotation.getMemberValue("value");
        MemberValue[] oldValues = oldValueArrays.getValue();
        arrayMemberVaues = ArrayUtils.addAll(oldValues, arrayMemberVaues);
      }

      newValues.setValue(arrayMemberVaues);
      annotation.addMemberValue("value", newValues);
    }
  }

  private List<AnnotationMemberValue> getMergedFilterAnnotations(ConstPool constPool, Annotation newFilters, List<AnnotationMemberValue> annotationMemberValues, Annotation oldFilter) {
    StringMemberValue smv = (StringMemberValue) oldFilter.getMemberValue("name");
    if(isDuplicatedFilterNames(newFilters, smv.getValue())){
      return annotationMemberValues;
    }else{
      Annotation filter = new Annotation(Annotations.HIBERNATE_FILTER_CLASS, constPool);

      for(String name : oldFilter.getMemberNames()){
        MemberValue memberValue = oldFilter.getMemberValue(name);
        if(name.equals("aliases")){
          // aliases 는 Annotation Array 이다

          ArrayMemberValue aliasesMemberValues = (ArrayMemberValue) memberValue;
          List<AnnotationMemberValue> newAliases = new ArrayList<>();
          for(MemberValue alias : aliasesMemberValues.getValue()){
            AnnotationMemberValue aliasValue = (AnnotationMemberValue) alias;
            Annotation aliasAnnotation = aliasValue.getValue();
            Annotation newAlias = new Annotation(Annotations.HIBERNATE_SQL_FRAGMENT_ALIAS_CLASS, constPool);

            for(String _name : aliasAnnotation.getMemberNames()){
              MemberValue _value = aliasAnnotation.getMemberValue(_name);
              newAlias.addMemberValue(_name, _value);
            }

            AnnotationMemberValue amv = new AnnotationMemberValue(newAlias, constPool);
            newAliases.add(amv);
          }

          if(CollectionUtils.isNotEmpty(newAliases)){
            ArrayMemberValue newAliasValue = new ArrayMemberValue(constPool);
            AnnotationMemberValue[] arrayMemberVaues = ArrayUtil.toArray(AnnotationMemberValue.class, newAliases);
            newAliasValue.setValue(arrayMemberVaues);
            filter.addMemberValue("aliases", newAliasValue);
          }

        }else{
          filter.addMemberValue(name, memberValue);
        }
      }

      annotationMemberValues.add(new AnnotationMemberValue(filter, constPool));
    }

    return annotationMemberValues;
  }

  private List<AnnotationMemberValue> getMergedFilterDefAnnotations(ConstPool constPool, Annotation newFilterDefs, List<AnnotationMemberValue> annotationMemberValues, Annotation oldFilterDef) {
    StringMemberValue smv = (StringMemberValue) oldFilterDef.getMemberValue("name");
    if(isDuplicatedFilterNames(newFilterDefs, smv.getValue())){
      return annotationMemberValues;
    }else{
      Annotation filter = new Annotation(Annotations.HIBERNATE_FILTER_DEF_CLASS, constPool);

      for(String name : oldFilterDef.getMemberNames()){
        MemberValue memberValue = oldFilterDef.getMemberValue(name);
        if(name.equals("parameters")){
          // aliases 는 Annotation Array 이다

          ArrayMemberValue aliasesMemberValues = (ArrayMemberValue) memberValue;
          List<AnnotationMemberValue> newAliases = new ArrayList<>();
          for(MemberValue alias : aliasesMemberValues.getValue()){
            AnnotationMemberValue aliasValue = (AnnotationMemberValue) alias;
            Annotation aliasAnnotation = aliasValue.getValue();
            Annotation newAlias = new Annotation(Annotations.HIBERNATE_PARAM_DEF_CLASS, constPool);

            for(String _name : aliasAnnotation.getMemberNames()){
              MemberValue _value = aliasAnnotation.getMemberValue(_name);
              newAlias.addMemberValue(_name, _value);
            }

            AnnotationMemberValue amv = new AnnotationMemberValue(newAlias, constPool);
            newAliases.add(amv);
          }

          if(CollectionUtils.isNotEmpty(newAliases)){
            ArrayMemberValue newAliasValue = new ArrayMemberValue(constPool);
            AnnotationMemberValue[] arrayMemberVaues = ArrayUtil.toArray(AnnotationMemberValue.class, newAliases);
            newAliasValue.setValue(arrayMemberVaues);
            filter.addMemberValue("parameters", newAliasValue);
          }

        }else{
          filter.addMemberValue(name, memberValue);
        }
      }

      annotationMemberValues.add(new AnnotationMemberValue(filter, constPool));
    }

    return annotationMemberValues;
  }

  /**
   * 기존 필터에 중복된 이름이 있는지 확인하는 메소드
   * @param newFilters
   * @param value
   * @return
   */
  private boolean isDuplicatedFilterNames(Annotation newFilters, String value) {
    MemberValue memberValue = newFilters.getMemberValue("value");
    if(memberValue != null){
      ArrayMemberValue arrayMemberValue = (ArrayMemberValue) memberValue;
      for(MemberValue mv : arrayMemberValue.getValue()){
        AnnotationMemberValue amv = (AnnotationMemberValue) mv;
        Annotation filter = amv.getValue();

        StringMemberValue filterNameValue = (StringMemberValue) filter.getMemberValue("name");
        if(StringUtils.equalsIgnoreCase(filterNameValue.getValue(), value)){
          return true;
        }
      }
    }
    return false;
  }


  private void mergeSqlDelete(TransformResult result, AnnotationsAttribute annotationsAttribute, Annotation existingSqlDelete, Annotation table, Annotation sqlDelete) {
    boolean isTarget = false;
    if(existingSqlDelete != null){
      sqlDelete = getCopiedAnnotationByClassName(result, Annotations.HIBERNATE_SQL_DELETE_CLASS, existingSqlDelete);
      isTarget = true;
    }else{
      if(sqlDelete != null && table != null){
        // sqlDelete 는 반드시 @Table 어노테이션과 함께 사용된다. abstract 클래스에 SoftDelete 가 지정된 경우 이 구문에서 오류가 발생할 수 있다.
        // 따라서 table 이 있을 때만 isTarget 으로 지정한다.
        sqlDelete = getFreshSqlDeleteIfCould(result, result.getConstPool(), sqlDelete, table);
        isTarget = true;
      }
    }

    if (isTarget && sqlDelete != null) {
      annotationsAttribute.addAnnotation(sqlDelete);
    }
  }

  private void mergeEntityListeners(TransformResult result, Annotation[] annotations, AnnotationsAttribute annotationsAttribute, Annotation existingEntityListeners, Annotation entityListener) {
    if(entityListener != null || existingEntityListeners != null){
      Annotation entityListeners = mergeEntityListeners(result.getConstPool(), existingEntityListeners, annotations);
      annotationsAttribute.addAnnotation(entityListeners);
    }
  }

  private Annotation getCopiedAnnotation(TransformResult result, Class<?> annotationClass, Annotation originAnnotation) {
    return getCopiedAnnotationByClassName(result, annotationClass.getName(), originAnnotation);
  }

  private Annotation getCopiedAnnotationByClassName(TransformResult result, String annotationClassName, Annotation originAnnotation) {
    Annotation copied = new Annotation(annotationClassName, result.getConstPool());
    for(String name : originAnnotation.getMemberNames()){
      copied.addMemberValue(name, originAnnotation.getMemberValue(name));
    }
    return copied;
  }

  private Annotation getFreshSqlDeleteIfCould(TransformResult result, ConstPool constantPool, Annotation sqlDelete, Annotation table) {
    try{

      Annotation newSqlDelete = new Annotation(Annotations.HIBERNATE_SQL_DELETE_CLASS, constantPool);

      String sql = ((StringMemberValue) sqlDelete.getMemberValue("sql")).getValue();

      sql = replaceTableName(table, sql);

      sql = replaceIdFieldName(result, sql);

      newSqlDelete.addMemberValue("sql", new StringMemberValue(sql, constantPool));

      return newSqlDelete;
    }catch (Exception e){
      log.warn("SQLDelete 어노테이션을 적용 중 오류가 발생 했습니다." + e.getStackTrace());
    }
    return null;
  }

  private String replaceIdFieldName(TransformResult result, String sql) {
    String idName = getIdFieldName(result);
    sql = StringUtils.replace(sql, SQL_DELETE_ID_NAME, idName);
    return sql;
  }

  private String replaceTableName(Annotation table, String sql) {
    String tableName = ((StringMemberValue) table.getMemberValue("name")).getValue();
    sql = StringUtils.replace(sql, SQL_DELETE_TABLE_NAME, tableName);
    return sql;
  }

  private String getIdFieldName(TransformResult result) {
    SEARCH_ID_FIELD:
    for(CtField field : result.getTargetClass().getDeclaredFields()){
      List<Annotation> annotations = BytecodeUtil.getDeclaredAnnotationsOnFieldByClassName(field, Annotations.PERSISTENCE_ID_CLASS);
      if(CollectionUtils.isNotEmpty(annotations)){
        for(Annotation anno : annotations){
          if(anno.getTypeName().equals(Annotations.PERSISTENCE_COLUMN_CLASS)){
            // 컬럼명
            return StringUtil.toString(BytecodeUtil.getStringValue(anno, "name"), field.getName());
          }else if(anno.getTypeName().equals(ID_GENERATOR)){
            String idFieldName = BytecodeUtil.getStringValue(anno, "columnName");
            if(StringUtils.isNotBlank(idFieldName))
              return idFieldName;
          }
        }
      }
    }
    return "ID";
  }

  /**
   * 원본 클래스에 정의된 엔티티 리스너 정보를 조회한다
   *
   * @param constantPool
   * @param existingEntityListeners
   * @param annotations
   * @return
   */
  protected Annotation mergeEntityListeners(ConstPool constantPool, Annotation existingEntityListeners, Annotation[] annotations) {
    Annotation templateEntityListeners = getAnnotationMemberByClassName(annotations, Annotations.PERSISTENCE_ENTITY_LISTENERS_CLASS);
    Annotation listeners = new Annotation(Annotations.PERSISTENCE_ENTITY_LISTENERS_CLASS, constantPool);
    ArrayMemberValue listenerArray = new ArrayMemberValue(constantPool);
    Set<MemberValue> listenerMemberValues = new HashSet<>();
    if (templateEntityListeners != null){
      ArrayMemberValue templateListenerValues = (ArrayMemberValue) templateEntityListeners.getMemberValue("value");
      listenerMemberValues.addAll(Arrays.asList(templateListenerValues.getValue()));
    }
    if (existingEntityListeners != null) {
      ArrayMemberValue oldListenerValues = (ArrayMemberValue) existingEntityListeners.getMemberValue("value");
      listenerMemberValues.addAll(Arrays.asList(oldListenerValues.getValue()));
    }
    listenerArray.setValue(listenerMemberValues.toArray(new MemberValue[listenerMemberValues.size()]));
    listeners.addMemberValue("value", listenerArray);

    return listeners;

  }

}
