/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class CacheRegionHolder {

  /**
   * 전체 Entity Class 내에 기술된 @Cache 어노테이션을 분석해 대상 Class 와 Cache region name 을 저장한다.
   */
  private static final Map<String, CacheRegionDTO> CACHE_REGIONS = new ConcurrentHashMap<>(2000);

  public static void put(Class<?> entityClass, String regionName){
    if(!CACHE_REGIONS.containsKey(entityClass)){
      CACHE_REGIONS.put(entityClass.getName(), new CacheRegionDTO(entityClass, regionName));
    }
  }

  public static void addSubCollection(Class<?> entityClass, String propertyName, Class<?> subCollectionClass, String regionName){
    if(CACHE_REGIONS.containsKey(entityClass)){
      CacheRegionDTO dto = CACHE_REGIONS.get(entityClass);
      dto.putSubCollection(propertyName, subCollectionClass, regionName);
      CACHE_REGIONS.put(entityClass.getName(), dto);
    }else{
      CacheRegionDTO dto = new CacheRegionDTO(entityClass, regionName);
      dto.putSubCollection(propertyName, subCollectionClass, regionName);
    }
  }

}
