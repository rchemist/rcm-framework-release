/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@ToString
@EqualsAndHashCode
public class CacheRegionDTO implements Serializable {

  private final String qualifiedEntityClassName;
  private final String regionName;
  private Map<String, CacheRegionDTO> subCollections = new HashMap<>();     // String propertyName, CacheRegionDTO

  public CacheRegionDTO(Class<?> entityClass, String regionName){
    this.qualifiedEntityClassName = entityClass.getName();
    this.regionName = regionName;
  }

  public CacheRegionDTO putSubCollection(String subCollectionPropertyName, Class<?> subCollectionClass, String regionName){
    if(subCollections == null)
      subCollections = new HashMap<>();

    if(!subCollections.containsKey(subCollectionPropertyName)){
      CacheRegionDTO subCollection = new CacheRegionDTO(subCollectionClass, regionName);
      subCollections.put(subCollectionPropertyName, subCollection);
    }
    return this;
  }

}
