/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.security.ProtectionDomain;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Setter
public class TransformResult implements Serializable {

  private ClassLoader classLoader;
  private ClassPool classPool;
  private ConstPool constPool;
  @NonNull private CtClass targetClass;
  private ClassFile targetClassFile;
  private CtClass interfaceClass;
  private ClassFile interfaceClassFile;
  private CtClass templateClass;
  private ClassFile templateClassFile;
  private String className;
  private boolean transformed;
  Class<?> classBeingRedefined;
  ProtectionDomain protectionDomain;
  byte[] classfileBuffer;

  public void setTransformed(boolean transformed){
    this.transformed = transformed;
    if(transformed){
      arrangeTransformResult();
    }
  }

  public void setTransformed(boolean transformed, boolean reset){
    if(reset){
      setTransformed(transformed);
    }else{
      this.transformed = transformed;
    }
  }

  /**
   * CtClass targetClass 가 변경됐을 때 ClassFile targetClassFile, byte[] classfileBuffer 를 갱신한다
   */
  public TransformResult arrangeTransformResult(){
    this.targetClassFile = targetClass.getClassFile();
    resetClassfileBuffer();
    return this;
  }

  /**
   * CtClass targetClass 를  set 하면 자동으로 ClassFile targetClassFile, byte[] classfileBuffer 를 입력한다
   * @param targetClass
   */
  public void setTargetClass(CtClass targetClass) {
    this.targetClass = targetClass;
    arrangeTransformResult();
  }

  public void setTemplateClass(CtClass templateClass) {
    this.templateClass = templateClass;
    this.templateClassFile = templateClass.getClassFile();
  }

  public void setInterfaceClass(CtClass interfaceClass){
    this.interfaceClass = interfaceClass;
    this.interfaceClassFile = interfaceClass.getClassFile();
  }

  /**
   * targetClassFile 로부터 classfileBuffer 를 생성한다
   */
  public void resetClassfileBuffer(){
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    DataOutputStream os = new DataOutputStream(bos);
    try {
      targetClassFile.write(os);
      os.close();
      this.classfileBuffer = bos.toByteArray();
    } catch (IOException e) {
      e.printStackTrace();
      this.classfileBuffer = null;
    }
  }

  /**
   * 변경된 ClassFile로부터 CtClass 재생성
   * @param classFile
   * @throws IOException
   */
  public TransformResult arrangeTransformResultByClassFile(ClassFile classFile) throws IOException {
    this.targetClassFile = classFile;
    resetClassfileBuffer();

    CtClass ctClass = getClassPool().makeClass(new ByteArrayInputStream(getClassfileBuffer()), false);
    setTargetClass(ctClass);
    setTransformed(true, false);
    return this;
  }

  /**
   * 변경된 classFile의 bytecode로부터 ctClass 재생성
   * @param byteArrays
   * @throws IOException
   */
  public TransformResult arrangeTransformResultFromBytes(byte[] byteArrays) throws IOException {
    CtClass ctClass = getClassPool().makeClass(new ByteArrayInputStream(byteArrays), false);
    setTargetClass(ctClass);
    setTransformed(true, false);
    return this;
  }

  public ClassPool getClassPool(){
    return (this.classPool == null) ? ClassPool.getDefault() : classPool;
  }

  public ClassFile getTargetClassFile(){
    return (this.targetClassFile == null) ? getTargetClass().getClassFile() : targetClassFile;
  }

  public ConstPool getConstPool(){
    return (this.constPool == null) ? getTargetClassFile().getConstPool() : constPool;
  }

}
