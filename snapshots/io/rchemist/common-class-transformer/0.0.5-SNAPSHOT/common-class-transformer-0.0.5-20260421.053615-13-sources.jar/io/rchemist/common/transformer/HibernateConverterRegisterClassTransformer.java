/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import java.lang.instrument.IllegalClassFormatException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.NotFoundException;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class HibernateConverterRegisterClassTransformer extends AbstractClassTransformer{

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  @Override
  public TransformResult transform(TransformResult transformResult, Set<String> targetEntityClasses,
      Map<String, TransformCondition> classTransformConditions)
      throws IllegalClassFormatException, CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    return null;
  }

  @Override
  public int getOrder() {
    // 가장 늦게 실행한다.
    return Integer.MAX_VALUE;
  }
}
