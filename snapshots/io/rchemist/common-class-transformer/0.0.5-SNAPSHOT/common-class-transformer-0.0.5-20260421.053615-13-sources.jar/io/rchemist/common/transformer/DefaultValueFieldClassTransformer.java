/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
@Component
public class DefaultValueFieldClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final String TARGET_ANNOTATION = "io.rchemist.common.persistence.domain.annotation.DefaultValue";

  private static final int order = 500;

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    if (!transformedEntityClassNames.contains(result.getClassName())) {

      boolean doColumnTransform = false;
      boolean doColumnDefaultTransform = false;

      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<FieldInfo> fieldInfos = targetClassFile.getFields();
      Map<String, Annotation> defaultValues = getDeclaredDefaultValues(fieldInfos);

      if (MapUtils.isNotEmpty(defaultValues)) {

        for (FieldInfo info : fieldInfos) {

          if(defaultValues.containsKey(info.getName())){
            Annotation defaultValue = defaultValues.get(info.getName());
            String defaultValueStr = getProperDefaultValue(defaultValue);

            CtField field = targetClass.getDeclaredField(info.getName());
            AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);

            List<?> objects = info.getAttributes();
            Iterator<?> iters = objects.iterator();

            while (iters.hasNext()) {
              Object object = iters.next();
              if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
                AnnotationsAttribute attr = (AnnotationsAttribute) object;
                Annotation[] items = attr.getAnnotations();

                doColumnTransform = true;
                doColumnDefaultTransform = true;

                for (Annotation annotation : items) {
                  if (annotation.getTypeName().equals(Annotations.PERSISTENCE_COLUMN_CLASS)) {
                    if (annotation.getMemberValue("nullable") != null) {
                      log.warn("@DefaultValue(nullable) 이 붙은 필드에 @Column.nullable 속성이 설정되었습니다. @DefaultValue(nullable) 설정에 따라 해당 필드를 NotNull로 변경합니다. \n at " + targetClass.getName() + "." + field.getName());
                    }
                    MemberValue nullableValue = new BooleanMemberValue(false, constPool);
                    annotation.addMemberValue("nullable", nullableValue);
                  } else if (annotation.getTypeName().equals(Annotations.HIBERNATE_COLUMN_DEFAULT_CLASS)) {
                    log.warn("@DefultValue(value) 가 붙은 필드에 @ColumnDefault 가 설정되었습니다. @DefaultValue(value) 설정에 따라 해당 필드의 기본값을 "+defaultValueStr+"로 변경합니다. \n at " + targetClass.getName() + "." + field.getName());
                    doColumnDefaultTransform = false;
                    StringMemberValue columnDefaultValue = (StringMemberValue) annotation.getMemberValue("value");
                    columnDefaultValue.setValue(defaultValueStr);
                    annotation.addMemberValue("value", columnDefaultValue);
                  }
                  annotationsAttribute.addAnnotation(annotation);
                }
              }
            }

            if (doColumnDefaultTransform) {
              Annotation columnDefault = new Annotation(Annotations.HIBERNATE_COLUMN_DEFAULT_CLASS, constPool);
              StringMemberValue columnDefaultValue = new StringMemberValue(constPool);
              columnDefaultValue.setValue(defaultValueStr);
              columnDefault.addMemberValue("value", columnDefaultValue);
              annotationsAttribute.addAnnotation(columnDefault);

              info.addAttribute(annotationsAttribute);
            }
          }

        }

        transformedEntityClassNames.add(className);

        if (doColumnTransform || doColumnDefaultTransform) {
          result.arrangeTransformResultByClassFile(targetClassFile);
        }

      }

    }
    return result;
  }

  /**
   * DefaultValue 의 경우 '' 로 감싸지 않으면 Table create Script 에서 오류가 발생한다.
   * 해당 처리를 해 준다.
   * @param defaultValue
   * @return
   */
  private String getProperDefaultValue(Annotation defaultValue) {

    String value = getStringMemberValue(defaultValue.getMemberValue("value"));

    if(StringUtils.isBlank(value)){
      value = "''";
    }else{

      if(!StringUtils.startsWith(value, "'")){
        value = "'" + value;
      }

      if(!StringUtils.endsWith(value, "'")){
        value = value + "'";
      }
    }
    return value;
  }

  /**
   * ClassFile 에 선언된 모든 필드의 @DefaultValue 어노테이션 정보를 Map<필드명, 어노테이션> 으로 리턴한다
   * @param fieldInfos
   * @return
   * @throws NotFoundException
   */
  public Map<String, Annotation> getDeclaredDefaultValues(List<FieldInfo> fieldInfos) throws NotFoundException {
    Map<String, Annotation> defaultValues = new HashMap<>();
    for (FieldInfo info : fieldInfos) {
      List<?> objects = info.getAttributes();
      Iterator<?> iters = objects.iterator();

      while (iters.hasNext()) {
        Object object = iters.next();
        if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
          AnnotationsAttribute attr = (AnnotationsAttribute) object;
          Annotation[] items = attr.getAnnotations();

          if(ArrayUtils.isNotEmpty(items)){
            for(Annotation annotation : items){
              if(annotation.getTypeName().equals(TARGET_ANNOTATION)){
                defaultValues.put(info.getName(), annotation);
              }
            }
          }
        }
      }
    }
    return defaultValues;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
