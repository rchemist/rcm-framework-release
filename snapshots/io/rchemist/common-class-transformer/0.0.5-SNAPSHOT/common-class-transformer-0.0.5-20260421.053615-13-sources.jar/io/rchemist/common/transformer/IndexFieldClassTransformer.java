/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.lang.instrument.IllegalClassFormatException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Project : rchemist
 * Created by kunner
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class IndexFieldClassTransformer extends AbstractClassTransformer {

  private static final String DEFAULT_INDEX_PREFIX = "IDX";
  protected Set<String> transformedClassNames = new HashSet<>();
  private Map<String, Boolean> indexUniqueness = new HashMap<>();

  private static final int order = 300;

  private static final String TARGET_ANNOTATION = "io.rchemist.common.persistence.jpa.domain.annotation.IndexField";


  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws IllegalClassFormatException, CannotCompileException, NotFoundException, ClassNotFoundException{

    Class<?> annotationClass = resolveClass(TARGET_ANNOTATION, result.getClassLoader());
    if (annotationClass != null && !transformedClassNames.contains(result.getClassName())) {
      try {

        String className = result.getClassName();
        ClassFile targetClassFile = result.getTargetClassFile();
        CtClass targetClass = result.getTargetClass();

        AnnotationsAttribute annotationsAttribute = null;
        List<?> attributes = targetClassFile.getAttributes();
        boolean doClassTransform = false;

        Annotation tableAnnotation = null;
        String tableName;

        Iterator<?> itr = attributes.iterator();
        CHECK_DO_TRANSFORM:
        while (itr.hasNext()) {
          Object object = itr.next();

          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            Annotation[] annotations = ((AnnotationsAttribute) object).getAnnotations();
            if (!doClassTransform) {
              /**
               * 인덱스는 필드에 있는 정보를 읽어 Entity Class의 Type 어노테이션으로 바꾸는 것이다.
               * MappedSuperClass 나 Embeddable 에 있는 클래스의 값을 아무리 바꿔 봐야 실제 Entity 클래스가 바뀌지 않는다.
               * 따라서 이 IndexFieldClassTransformer의 대상은 반드시 @Entity 클래스여야 한다.
               */
              doClassTransform = BytecodeUtil.containsAnnotation(annotations
                  , Annotations.PERSISTENCE_ENTITY_CLASS
              );
            }

            for (Annotation annotation : annotations) {
              if (annotation.getTypeName().equals(Annotations.PERSISTENCE_TABLE_CLASS)) {
                tableAnnotation = annotation;
                annotationsAttribute = ((AnnotationsAttribute) object);
                break CHECK_DO_TRANSFORM;
              }
            }
          }
        }

        if (doClassTransform) {
          transformedClassNames.add(className);


          if (tableAnnotation == null) {
            log.warn(className + "Entity Class에 @Table을 명시적으로 선언하지 않은 경우 " + this.getClass().getName() + "을 사용할 수 없습니다.");
            return null;
          } else {

            tableName = StringUtil.toUpperCamelCase(getStringMemberValue(tableAnnotation.getMemberValue("name")), targetClass.getSimpleName());
            Map<String, String> indexFields = getPrevDeclaredTableIndex(tableAnnotation);

            indexFields = getDeclaredIndexFields(targetClassFile, tableName, indexFields, annotationClass);

            // 지정해야 하는 index field가 있다면
            if (MapUtils.isNotEmpty(indexFields)) {

              targetClassFile = transformByIndexField(targetClassFile, result.getConstPool(), tableAnnotation, annotationsAttribute, indexFields);

              result.arrangeTransformResultByClassFile(targetClassFile);

            }
          }

        }

        return result;

      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return result;
  }

  /**
   *
   * @param classFile
   * @param constPool
   * @param tableAnnotation
   * @param annotationsAttribute
   * @param indexFields
   * @return
   */
  private ClassFile transformByIndexField(ClassFile classFile, ConstPool constPool, Annotation tableAnnotation, AnnotationsAttribute annotationsAttribute, Map<String, String> indexFields) {
    List<AnnotationMemberValue> indexes = new ArrayList<>();
    for (Map.Entry<String, String> entry : indexFields.entrySet()) {
      Annotation annotation = new Annotation(Annotations.PERSISTENCE_INDEX_CLASS, constPool);
      annotation.addMemberValue("name", new StringMemberValue(entry.getKey(), constPool));
      if (StringUtils.isNotEmpty(entry.getValue())) {
        annotation.addMemberValue("columnList", new StringMemberValue(entry.getValue(), constPool));
      }
      // Add unique attribute if this index was marked as unique
      if (indexUniqueness.containsKey(entry.getKey()) && indexUniqueness.get(entry.getKey())) {
        BooleanMemberValue uniqueValue = new BooleanMemberValue(true, constPool);
        annotation.addMemberValue("unique", uniqueValue);
      }
      AnnotationMemberValue value = new AnnotationMemberValue(constPool);
      value.setValue(annotation);

      indexes.add(value);
    }

    ArrayMemberValue newIndexValue = new ArrayMemberValue(constPool);
    newIndexValue.setValue(indexes.toArray(new MemberValue[indexes.size()]));

    tableAnnotation.addMemberValue("indexes", newIndexValue);

    annotationsAttribute.addAnnotation(tableAnnotation);
    classFile.addAttribute(annotationsAttribute);
    return classFile;
  }

  private String getDefaultIndexName(String... str) {
    return StringUtils.upperCase(StringUtils.join(str, '_'));
  }

  /**
   *
   * @param classFile
   * @param tableName
   * @param indexFields
   * @return
   */
  private Map<String, String> getDeclaredIndexFields(ClassFile classFile, String tableName, Map<String, String> indexFields, Class<?> annotationClass){
    Set<FieldInfo> fieldInfos = super.getAllFields(classFile, annotationClass, null, false, true);
    Map<String, Boolean> indexUniqueness = new HashMap<>();

    for (FieldInfo info : fieldInfos) {
      List<?> objects = info.getAttributes();
      Iterator<?> iters = objects.iterator();

      while (iters.hasNext()) {
        Object obj = iters.next();
        if (AnnotationsAttribute.class.isAssignableFrom(obj.getClass())) {
          AnnotationsAttribute attr = (AnnotationsAttribute) obj;
          Annotation[] items = attr.getAnnotations();

          for (Annotation annotation : items) {
            if (annotation.getTypeName().equals(TARGET_ANNOTATION)) {
              String name = StringUtil.toUpperCamelCase(getStringMemberValue(annotation.getMemberValue("name")),
                    getDefaultIndexName(DEFAULT_INDEX_PREFIX, tableName, info.getName()));

              // Handle unique attribute
              boolean unique = false;
              if (annotation.getMemberValue("unique") != null) {
                unique = ((BooleanMemberValue) annotation.getMemberValue("unique")).getValue();
              }
              if (unique) {
                indexUniqueness.put(name, true);
              }

              if(annotation.getMemberValue("columnNames") != null){
                ArrayMemberValue arrayMemberValue = (ArrayMemberValue) annotation.getMemberValue("columnNames");
                StringBuilder sb = new StringBuilder();
                int i = 0;
                for(MemberValue mv : arrayMemberValue.getValue()){
                  if(i > 0){
                    sb.append(",");
                  }
                  sb.append(((StringMemberValue)mv).getValue());
                  i++;
                }
                indexFields.put(name, sb.toString());
              }else{
                indexFields.put(name, getAnnotationFieldValue(annotation, info, "columnList"));
              }
            }
          }
        }
      }
    }
    // Store uniqueness info in instance variable for later use
    this.indexUniqueness = indexUniqueness;
    return indexFields;
  }

  /**
   *
   * @param tableAnnotation
   * @return
   */
  protected Map<String, String> getPrevDeclaredTableIndex(Annotation tableAnnotation){
    Map<String, String> indexFields = new HashMap<>();
    if (tableAnnotation.getMemberValue("indexes") != null) {
      ArrayMemberValue indexesMemberValue = (ArrayMemberValue) tableAnnotation.getMemberValue("indexes");

      for (MemberValue value : indexesMemberValue.getValue()) {
        if (value instanceof AnnotationMemberValue) {
          AnnotationMemberValue indexMember = ((AnnotationMemberValue) value);
          String name = getStringMemberValue(indexMember.getValue().getMemberValue("name"));
          String columnList = getStringMemberValue(indexMember.getValue().getMemberValue("columnList"));
          indexFields.put(name, columnList);
          
          // Preserve existing unique attribute
          MemberValue uniqueMember = indexMember.getValue().getMemberValue("unique");
          if (uniqueMember instanceof BooleanMemberValue) {
            boolean unique = ((BooleanMemberValue) uniqueMember).getValue();
            if (unique) {
              if (indexUniqueness == null) {
                indexUniqueness = new HashMap<>();
              }
              indexUniqueness.put(name, true);
            }
          }
        }
      }
    }
    return indexFields;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
