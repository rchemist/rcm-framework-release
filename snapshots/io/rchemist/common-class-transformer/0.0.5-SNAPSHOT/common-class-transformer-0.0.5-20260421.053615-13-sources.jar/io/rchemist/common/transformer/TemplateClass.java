/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Project : rchemist
 * Created by kunner
 * <p>
 * weave 할 때 사용하는 템플릿 클래스를 지정한다
 *
 * 이 어노테이션으로 새 템플릿 클래스를 지정한 경우에는 반드시 Settings.classTransformConditions 으로 템플릿 클래스를 설정해야 한다.
 *
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
// @Component
public @interface TemplateClass {

  /**
   * 어떤 인터페이스를 처리하는 템플릿 클래스인지
   * @return
   */
  Class<?> value();

  Class<?>[] requiredAnnotations() default {};

}
