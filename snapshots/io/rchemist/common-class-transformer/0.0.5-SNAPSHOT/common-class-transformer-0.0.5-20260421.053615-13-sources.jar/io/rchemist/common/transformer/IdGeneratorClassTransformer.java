/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.EnumMemberValue;
import javassist.bytecode.annotation.IntegerMemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Project : rchemist Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class IdGeneratorClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final String DEFAULT_SEQUENCE_TABLE_NAME = "T_SEQUENCE_HIBERNATE_DEFAULT";

  private static final String SEQUENCE_GENERATOR_TABLE_NAME = "SEQUENCE_GENERATOR";

  private static final String ID_GENERATOR = "io.rchemist.common.persistence.domain.annotation.IdGenerator";
  private static final String UUID_GENERATOR = "io.rchemist.common.persistence.jpa.id.TSIDGenerator";
  private static final String LONG_TSID_GENERATOR = "io.rchemist.common.persistence.jpa.id.LongTSIDGenerator";
  private static final String ADMIN_FIELD = "io.rchemist.common.presentation.annotation.AdminField";
  private static final String HEADER_FIELD = "io.rchemist.common.presentation.annotation.HeaderField";
  private static final String GENERIC_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField";

  private static final String SORTABLE_TYPE = "org.hibernate.search.engine.backend.types.Sortable";
  private static final String PRESENTATION_FIELD_TYPE = "io.rchemist.common.presentation.type.PresentationFieldType";
  private static final String POOLED_LO_THREAD_LOCAL_OPTIMIZER = "pooled-lotl";
  private static final String DEFAULT_SEQUENCE_INCREMENT = "50";

  // copies from hibernate SequenceStyleGenerator
  private static final String SEQUENCE_PARAM = "sequence_name";
  private static final String ALT_SEQUENCE_PARAM = "sequence";
  private static final String CONFIG_SEQUENCE_PER_ENTITY_SUFFIX = "sequence_per_entity_suffix";
  private static final String DEF_SEQUENCE_SUFFIX = "_SEQ";
  private static final String FORCE_TBL_PARAM = "force_table_use";
  private static final String VALUE_COLUMN_PARAM = "value_column";
  private static final String DEF_VALUE_COLUMN = "next_val";
  private static final String INCREMENT_PARAM = "increment_size";;
  private static final String PREFERRED_POOLED_OPTIMIZER = "hibernate.id.optimizer.pooled.preferred";

  private static final int order = 100;

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses,
      Map<String, TransformCondition> classTransformConditions)
      throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {

    if (transformedEntityClassNames.contains(result.getClassName())) {
      // log.debug("Its duplicated class :: " + result.getClassName());
      return result;
    }

    if (!transformedEntityClassNames.contains(result.getClassName())) {

      // log.debug("Target class name is " + result.getClassName());

      boolean transformed = false;
      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<FieldInfo> fieldInfos = targetClassFile.getFields();

      CHECK_ID_GENERATOR:
      for (FieldInfo info : fieldInfos) {
        CtField field = targetClass.getDeclaredField(info.getName());
        AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(constPool,
            AnnotationsAttribute.visibleTag);

        List<?> objects = info.getAttributes();
        Iterator<?> iters = objects.iterator();

        boolean hasColumnAnnotation = field.hasAnnotation(Annotations.PERSISTENCE_COLUMN_CLASS);

        boolean hasAdminFieldAnnotation = field.hasAnnotation(ADMIN_FIELD);

        boolean hasGenericFieldAnnotation = field.hasAnnotation(GENERIC_FIELD);

        boolean doTransform = false;

        while (iters.hasNext()) {
          Object object = iters.next();
          if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
            AnnotationsAttribute attr = (AnnotationsAttribute) object;
            Annotation[] items = attr.getAnnotations();

            if (field.hasAnnotation(ID_GENERATOR)) {
              doTransform = true;
              for (Annotation annotation : items) {
                if (annotation.getTypeName().equals(ID_GENERATOR)) {

                  boolean uuid = (field.getType().getName().equals(String.class.getName()));

                  setDefaultIdGenerator(className, constPool, annotation, annotationsAttribute,
                      hasColumnAnnotation, hasAdminFieldAnnotation, uuid, hasGenericFieldAnnotation);
                  // 하나의 엔티티에는 하나의 IdGenerator 만 선언할 수 있다.
                  // log.debug("Entity Class " + className + " has transformed by IdGeneratorClassTransformer");
                } else {
                  annotationsAttribute.addAnnotation(annotation);
                }
              }
            } else {
              annotationsAttribute = attr;
            }
          }
        }

        if (doTransform) {
          info.addAttribute(annotationsAttribute);
          transformed = true;
        }
      }

      transformedEntityClassNames.add(className);

      if (transformed) {
        result.arrangeTransformResultByClassFile(targetClassFile);
      }

    }
    return result;
  }

  /**
   * @param className
   * @param constPool
   * @param idGenerator
   * @param annotationsAttribute
   * @param hasColumnAnnotation
   * @param hasAdminFieldAnnotation
   * @param useUUID
   * @param hasGenericFieldAnnotation
   * @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "sequence-generator" )  *
   * @SequenceGenerator( name = "sequence-generator", sequenceName = "product_sequence" )
   */
  private void setDefaultIdGenerator(String className, ConstPool constPool, Annotation idGenerator,
      AnnotationsAttribute annotationsAttribute, boolean hasColumnAnnotation,
      boolean hasAdminFieldAnnotation, boolean useUUID, boolean hasGenericFieldAnnotation) {
    String prefix = BytecodeUtil.getStringValue(idGenerator, "value");

    if(prefix == null)
      prefix = StringUtils.substringAfterLast(className, ".");

    String generatorId = prefix + "Id";

    Annotation generateValue = new Annotation(Annotations.PERSISTENCE_GENERATED_VALUE_CLASS, constPool);

    if(useUUID){

      generateValue.addMemberValue("generator", new StringMemberValue("UUID", constPool));
      annotationsAttribute.addAnnotation(generateValue);

      Annotation uuidGenerator = new Annotation(Annotations.HIBERNATE_GENERIC_GENERATOR_CLASS, constPool);
      uuidGenerator.addMemberValue("name", new StringMemberValue("UUID", constPool));
      uuidGenerator.addMemberValue("strategy", new StringMemberValue(UUID_GENERATOR, constPool));
      annotationsAttribute.addAnnotation(uuidGenerator);

    }else{

      generateValue.addMemberValue("generator", new StringMemberValue("TSID_LONG", constPool));
      annotationsAttribute.addAnnotation(generateValue);

      Annotation uuidGenerator = new Annotation(Annotations.HIBERNATE_GENERIC_GENERATOR_CLASS, constPool);
      uuidGenerator.addMemberValue("name", new StringMemberValue("TSID_LONG", constPool));
      uuidGenerator.addMemberValue("strategy", new StringMemberValue(LONG_TSID_GENERATOR, constPool));
      annotationsAttribute.addAnnotation(uuidGenerator);

      /*
      # Hibernate 의 Table Increment Generator 사용 방식은 아래 주석처리와 같다.
      # TSID 로 변경할 예정이므로 이건 필요 없다.

      EnumMemberValue generationType = new EnumMemberValue(constPool);
      generationType.setType(Annotations.PERSISTENCE_GENERATION_TYPE_CLASS);
      generationType.setValue(Annotations.PERSISTENCE_GENERATION_TYPE_SEQUENCE);
      generateValue.addMemberValue("strategy", generationType);
      generateValue.addMemberValue("generator", new StringMemberValue(generatorId, constPool));
      annotationsAttribute.addAnnotation(generateValue);

      boolean separate = BooleanUtils.toBoolean(
          BytecodeUtil.getBooleanValue(idGenerator, "separate"));

      String sequenceName = getSequenceName(idGenerator, prefix, separate);

      Annotation seqGenerator = new Annotation(Annotations.HIBERNATE_GENERIC_GENERATOR_CLASS, constPool);
      StringMemberValue name = new StringMemberValue(generatorId, constPool);
      StringMemberValue sequence = new StringMemberValue("sequence", constPool);
      seqGenerator.addMemberValue("name", name);
      seqGenerator.addMemberValue("strategy", sequence);


      ArrayMemberValue parameters = new ArrayMemberValue(constPool);

      AnnotationMemberValue paramSequence = getHibernateParameterValue(constPool,
          SEQUENCE_PARAM, sequenceName);

      Integer increment = BytecodeUtil.getIntegerValue(idGenerator, "increment");
      AnnotationMemberValue paramIncrement = getHibernateParameterValue(constPool,
          INCREMENT_PARAM, increment != null ? String.valueOf(increment) : DEFAULT_SEQUENCE_INCREMENT);

      AnnotationMemberValue paramOptimizer = getHibernateParameterValue(constPool,
          PREFERRED_POOLED_OPTIMIZER, POOLED_LO_THREAD_LOCAL_OPTIMIZER);

      parameters.setValue(new MemberValue[]{paramSequence, paramIncrement, paramOptimizer});

      seqGenerator.addMemberValue("parameters", parameters);

      annotationsAttribute.addAnnotation(seqGenerator);
      */
    }


    if (!hasColumnAnnotation) {
      String columnName = BytecodeUtil.getStringValue(idGenerator, "columnName");
      if(columnName == null){
        columnName = StringUtil.camelCaseToSnakeCase(prefix, true);
        // PK ID 의 필드 이름은 중간을 자르지 말자.
        // T_USER_PHONE 이 T_PHONE 을 manyToOne 으로 참조하게 되면 PHONE_ID 가 중복되는 문제가 발생할 수 있으므로
        // 그냥 USER_PHONE_ID 를 모두 가지는 방식으로 바꾼다.
        // 단, _가 4개 이상일 때는 하나를 줄이는 정도로 타협하기로 한다.
        if (StringUtils.countMatches(columnName, '_') > 3) {
          columnName = StringUtil.subStringAfter(columnName, "_");
        }
        /*if(StringUtils.contains(columnName, "_")){
          // _ 맨 앞의 _ 를 제외한 나머지
          columnName = StringUtil.subStringAfter(columnName, "_");
          // columnName = StringUtils.substringAfterLast(columnName, "_");
        }*/
        columnName = columnName + "_ID";
      }

      Annotation column = new Annotation(Annotations.PERSISTENCE_COLUMN_CLASS, constPool);
      StringMemberValue value = new StringMemberValue(columnName, constPool);
      column.addMemberValue("name", value);
      annotationsAttribute.addAnnotation(column);
    }

    if(!hasAdminFieldAnnotation){

      // ID 필드에 @AdminField 가 선언되지 않은 경우 기본값을 넣어 준다.
      // @AdminField(name = "ID", order = 1, fieldType = PresentationFieldType.ID, headerField = @HeaderField(order = 1))
      // 어차피 엔티티에 @AdminEntity 가 없으면 사용되지 않으므로 모든 엔티티에 자동으로 들어가도 무방하다.

      Annotation adminField = new Annotation(ADMIN_FIELD, constPool);
      IntegerMemberValue order = new IntegerMemberValue(constPool);
      order.setValue(1);

      EnumMemberValue fieldType = new EnumMemberValue(constPool);
      fieldType.setType(PRESENTATION_FIELD_TYPE);
      fieldType.setValue("ID");

      AnnotationMemberValue headerField = new AnnotationMemberValue(constPool);
      Annotation header = new Annotation(HEADER_FIELD, constPool);
      IntegerMemberValue headerOrder = new IntegerMemberValue(constPool);
      headerOrder.setValue(1);
      header.addMemberValue("order", headerOrder);
      headerField.setValue(header);

      adminField.addMemberValue("order", order);
      adminField.addMemberValue("fieldType", fieldType);
      adminField.addMemberValue("headerField", headerField);

      annotationsAttribute.addAnnotation(adminField);
    }

    if (!hasGenericFieldAnnotation) {
      // HibernateSearch 에서 id sort 를 지원하기 위해 id 필드를 @SortableField 로 지정한다.
      Annotation genericField = new Annotation(GENERIC_FIELD, constPool);
      EnumMemberValue sortable = new EnumMemberValue(constPool);
      sortable.setType(SORTABLE_TYPE);
      sortable.setValue("YES");
      genericField.addMemberValue("sortable", sortable);

      annotationsAttribute.addAnnotation(genericField);
    }

  }

  private AnnotationMemberValue getHibernateParameterValue(ConstPool constPool, String parameterName,
      String parameterValue) {
    AnnotationMemberValue value = new AnnotationMemberValue(constPool);
    Annotation annotation = new Annotation(Annotations.HIBERNATE_PARAMETER_CLASS, constPool);
    annotation.addMemberValue("name", new StringMemberValue(parameterName, constPool));
    annotation.addMemberValue("value", new StringMemberValue(parameterValue, constPool));

    value.setValue(annotation);
    return value;
  }

  private String getSequenceName(Annotation idGenerator, String prefix, boolean separate) {
    String sequenceName;
    if(separate){
      String separateIdTable = BytecodeUtil.getStringValue(idGenerator, "separateIdTable");
      if(StringUtils.isEmpty(separateIdTable)){
        sequenceName = "T_"+StringUtil.camelCaseToSnakeCase("Sequence" + StringUtil.toUpperCamelCase(prefix), true);
      }else{
        sequenceName = "T_"+StringUtil.camelCaseToSnakeCase("Sequence" + StringUtil.toUpperCamelCase(separateIdTable), true);
      }
    }else{
      sequenceName = DEFAULT_SEQUENCE_TABLE_NAME;
    }
    return sequenceName;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
