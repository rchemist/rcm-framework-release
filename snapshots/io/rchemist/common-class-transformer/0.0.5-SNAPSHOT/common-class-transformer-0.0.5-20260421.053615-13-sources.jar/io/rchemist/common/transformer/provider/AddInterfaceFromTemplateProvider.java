/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class AddInterfaceFromTemplateProvider extends AbstractTemplateBasedClassTransformProvider {

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 200;

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, NotFoundException {

    CtClass templateClass = result.getTemplateClass();
    CtClass targetClass = result.getTargetClass();

    if(ArrayUtils.isNotEmpty(templateClass.getInterfaces())){

      for (CtClass interfaceClass : templateClass.getInterfaces()) {
        checkInterfaces:
        {
          CtClass[] myInterfaces = targetClass.getInterfaces();
          for (CtClass myInterface : myInterfaces) {
            if (myInterface.getName().equals(interfaceClass.getName())) {
              break checkInterfaces;
            }
          }
          targetClass.addInterface(interfaceClass);
        }
      }

      return result.arrangeTransformResult();
    }

    return result;
  }

}
