/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class EvictCacheDTO implements Serializable {

  public EvictCacheDTO(String region, boolean contextual, boolean evictAll, boolean xref, String xrefParentProperty) {
    this.region = region;
    this.contextual = contextual;
    this.evictAll = evictAll;
    this.xref = xref;
    this.xrefParentProperty = xrefParentProperty;
  }

  protected String region;
  protected boolean contextual;
  protected boolean evictAll;
  protected boolean xref;
  protected String xrefParentProperty;

}
