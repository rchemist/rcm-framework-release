/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ConstPool;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class AddIndexAnnotationProvider extends AbstractTemplateBasedClassTransformProvider {

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 400;

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws IOException {

    Annotation[] annotations = getDeclaredAnnotationByClassName(result, Annotations.PERSISTENCE_TABLE_CLASS);

    if (ArrayUtils.isNotEmpty(annotations)) {
      AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(result.getConstPool(), AnnotationsAttribute.visibleTag);
      List<?> attributes = result.getTargetClassFile().getAttributes();
      Iterator<?> itr = attributes.iterator();
      Annotation existingTable = null;
      while (itr.hasNext()) {
        Object object = itr.next();
        if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
          AnnotationsAttribute attr = (AnnotationsAttribute) object;
          Annotation[] items = attr.getAnnotations();
          for (Annotation annotation : items) {
            String typeName = annotation.getTypeName();
            if (typeName.equals(Annotations.PERSISTENCE_TABLE_CLASS)) {
              existingTable = annotation;
              continue;
            }
            annotationsAttribute.addAnnotation(annotation);
          }
          itr.remove();
        }
      }

      Annotation newTable = getIndexes(result.getConstPool(), existingTable, annotations[0]);
      annotationsAttribute.addAnnotation(newTable);

      result.getTargetClassFile().addAttribute(annotationsAttribute);
      return result.arrangeTransformResultByClassFile(result.getTargetClassFile());
    }

    return result;
  }

  /**
   * 대상 필드에 지정되어 있던 인덱스 정보를 가져온다
   *
   * @param constantPool
   * @param existingTable
   * @param templateTable
   * @return
   */
  protected Annotation getIndexes(ConstPool constantPool, Annotation existingTable, Annotation templateTable) {
    Annotation newTable = new Annotation(Annotations.PERSISTENCE_TABLE_CLASS, constantPool);
    ArrayMemberValue indexArray = new ArrayMemberValue(constantPool);
    Set<MemberValue> indexMemberValues = new HashSet<>();
    {
      ArrayMemberValue templateIndexValues = (ArrayMemberValue) templateTable.getMemberValue("indexes");
      if (templateIndexValues != null) {
        indexMemberValues.addAll(Arrays.asList(templateIndexValues.getValue()));
      }
    }
    if (existingTable != null) {
      if (existingTable.getMemberValue("name") != null) {
        StringMemberValue name = new StringMemberValue(constantPool);
        name.setValue(((StringMemberValue) existingTable.getMemberValue("name")).getValue());
        newTable.addMemberValue("name", name);
      }
      ArrayMemberValue oldIndexValues = (ArrayMemberValue) existingTable.getMemberValue("indexes");
      if (oldIndexValues != null) {
        indexMemberValues.addAll(Arrays.asList(oldIndexValues.getValue()));
      }
    }
    List<MemberValue> deepCopyIndexes = new ArrayList<>();
    for (MemberValue value : indexMemberValues) {
      if (AnnotationMemberValue.class.isAssignableFrom(value.getClass())) {
        AnnotationMemberValue annotationMember = (AnnotationMemberValue) value;
        AnnotationMemberValue newAnnotationMember = new AnnotationMemberValue(constantPool);
        Annotation annotation = annotationMember.getValue();
        newAnnotationMember.setValue(cloneIndexAnnotation(annotation, constantPool));
        deepCopyIndexes.add(newAnnotationMember);
      }
    }
    indexArray.setValue(deepCopyIndexes.toArray(new MemberValue[deepCopyIndexes.size()]));
    newTable.addMemberValue("indexes", indexArray);

    return newTable;

  }

  /**
   * 필드에 인덱스 정보를 복제한다
   *
   * @param annotation
   * @param constantPool
   * @return
   */
  protected Annotation cloneIndexAnnotation(Annotation annotation, ConstPool constantPool) {
    Annotation newAnnotation = new Annotation(Annotations.PERSISTENCE_INDEX_CLASS, constantPool);
    if (annotation.getMemberValue("name") != null) {
      StringMemberValue name = new StringMemberValue(constantPool);
      name.setValue(((StringMemberValue) annotation.getMemberValue("name")).getValue());
      newAnnotation.addMemberValue("name", name);
    }
    if (annotation.getMemberValue("columnList") != null) {
      StringMemberValue columnList = new StringMemberValue(constantPool);
      columnList.setValue(((StringMemberValue) annotation.getMemberValue("columnList")).getValue());
      newAnnotation.addMemberValue("columnList", columnList);
    }
    if (annotation.getMemberValue("unique") != null) {
      BooleanMemberValue unique = new BooleanMemberValue(constantPool);
      unique.setValue(((BooleanMemberValue) annotation.getMemberValue("unique")).getValue());
      newAnnotation.addMemberValue("unique", unique);
    }

    return newAnnotation;
  }

}
