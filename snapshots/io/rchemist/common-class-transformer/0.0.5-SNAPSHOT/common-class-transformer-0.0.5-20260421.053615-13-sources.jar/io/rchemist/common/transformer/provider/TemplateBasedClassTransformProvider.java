/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import javassist.CannotCompileException;
import javassist.NotFoundException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface TemplateBasedClassTransformProvider {

  default TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException{
    return result;
  }

  default TransformResult transformClassWithNonCondition(TransformResult result) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException{
    return result;
  }

  int getOrder();

}
