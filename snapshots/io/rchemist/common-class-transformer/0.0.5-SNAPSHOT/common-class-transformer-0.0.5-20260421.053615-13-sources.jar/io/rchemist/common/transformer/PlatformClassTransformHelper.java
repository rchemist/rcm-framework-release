/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.util.StringUtil;
import java.io.IOException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * 애플리케이션 패키지·SearchProvider 설정을 해석하는 유틸 클래스.
 *
 * <p>0.1.0 이전에는 런타임 LoadTimeWeaver 기반 엔티티 바이트코드 위빙 진입점
 * ({@code initializeTransformedClasses(...)}, {@code build(...)}, {@code platformClassTransformers(...)},
 * {@code classTransformConditions(...)} 등) 을 이 클래스에 두었다. 0.1.0 에서 빌드 타임
 * Maven 플러그인 ({@code common-class-transformer-maven-plugin}) 이 변환을 전담하게 되면서
 * 런타임 진입점은 전부 제거되었다. 남은 책임은 {@link #getDefaultApplicationPackages()}
 * 와 {@link #getSearchProviderConfiguration(SearchProvider)} 등 **설정 해석 유틸** 뿐이다.</p>
 *
 * <p>향후 이 클래스는 보다 명확한 이름으로 이관될 수 있다 — 이름 변경 시 Consumer 영향을
 * 고려해 Breaking Release 에 포함.</p>
 */
@Slf4j
public class PlatformClassTransformHelper {

  private static final String DEFAULT_PACKAGE = "io.rchemist";

  private static final String SEARCH_PROVIDER_CONFIG = "platform.config.provider.search";

  private static final String BOOTSTRAP_YML = "bootstrap.yml";

  private static SearchProvider searchProvider;

  private PlatformClassTransformHelper() {
  }

  public static String[] getDefaultApplicationPackages() {
    return getPackagesToScan(getApplicationPackages());
  }

  public static String getApplicationPackages() {
    return System.getProperty("platform.config.application.packages", DEFAULT_PACKAGE);
  }

  public static String[] getPackagesToScan(String packages) {
    return StringUtil.splitWithNonEmpty(packages, ",");
  }

  public static SearchProvider getSearchProviderConfiguration(SearchProvider defaultProvider) {
    if (searchProvider != null) {
      return searchProvider;
    }

    // -Dplatform.config.provider.search=querydsl
    String provider = System.getProperty(SEARCH_PROVIDER_CONFIG);

    // load config from bootstrap.yml
    try {
      provider = getProviderConfigFromBootstrap(provider);

      if (StringUtils.isEmpty(provider)) {
        return defaultProvider;
      }

    } catch (Exception e) {
      if (log.isDebugEnabled()) {
        log.debug("Failed to get search provider configuration from bootstrap.yml: {}", e.getMessage());
      }
    }

    try {
      searchProvider = SearchProvider.valueOf(provider.toUpperCase());
    } catch (Exception e) {
      if (log.isDebugEnabled()) {
        log.debug("Invalid search provider value '{}', using default provider: {}", provider, defaultProvider, e);
      }
      searchProvider = defaultProvider;
    }

    return searchProvider;

  }

  private static String getProviderConfigFromBootstrap(String provider) {
    if (StringUtils.isEmpty(provider)) {
      // bootstrap 에 정의된 platform.config.provider.search 값
      Resource resource = new ClassPathResource(BOOTSTRAP_YML);

      YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
      try {
        List<PropertySource<?>> sources = loader.load("bootstrap_loader", resource);

        for (PropertySource<?> source : sources) {
          if (source.containsProperty(SEARCH_PROVIDER_CONFIG)) {
            provider = (String) source.getProperty(SEARCH_PROVIDER_CONFIG);
            break;
          }
        }

      } catch (IOException e) {
        if (log.isDebugEnabled()) {
          log.debug("Failed to load provider configuration from bootstrap.yml: {}", e.getMessage());
        }
      }
    }

    return provider;
  }
}
