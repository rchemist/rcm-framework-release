/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.transformer.provider.TemplateBasedClassTransformProvider;
import io.rchemist.common.util.BytecodeUtil;
import javassist.bytecode.ClassFile;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * Comment :
 **/
@Slf4j
public class TemplateBasedClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedClassNames = new HashSet<>();

  private static final int order = 200;

  protected List<TemplateBasedClassTransformProvider> transformProviders;

  private static final String TARGET_ANNOTATION = "io.rchemist.common.presentation.annotation.AdminEntity";


  public TemplateBasedClassTransformer() {
  }

  public TemplateBasedClassTransformer(
      List<TemplateBasedClassTransformProvider> transformProviders) {
    this.transformProviders = transformProviders;
  }

  protected boolean providerSorted = false;

  public void setTransformProviders(List<TemplateBasedClassTransformProvider> providers){
    this.transformProviders = providers;
  }

  public List<TemplateBasedClassTransformProvider> getTransformProviders() {
    if(!providerSorted){
      Collections.sort(transformProviders, Comparator.comparing(TemplateBasedClassTransformProvider::getOrder));
      providerSorted = true;
    }
    return transformProviders;
  }

  /**
   * 클래스가 독립적인 엔티티인지 확인
   * @Entity가 있고 @MappedSuperclass가 없으며, @Inheritance가 TABLE_PER_CLASS가 아닌 경우
   */
  protected boolean isIndependentEntity(CtClass ctClass) {
    try {
      // @Entity 어노테이션 확인
      boolean hasEntity = ctClass.hasAnnotation("javax.persistence.Entity") ||
          ctClass.hasAnnotation("jakarta.persistence.Entity");

      // @MappedSuperclass 어노테이션 확인
      boolean hasMappedSuperclass = ctClass.hasAnnotation("javax.persistence.MappedSuperclass") ||
          ctClass.hasAnnotation("jakarta.persistence.MappedSuperclass");

      // 독립 엔티티: @Entity가 있고 @MappedSuperclass가 없는 경우
      if (hasEntity && !hasMappedSuperclass) {
        // @Inheritance 전략 확인
        Object inheritanceAnnotation = ctClass.getAnnotation(Class.forName("javax.persistence.Inheritance"));
        if (inheritanceAnnotation == null) {
          inheritanceAnnotation = ctClass.getAnnotation(Class.forName("jakarta.persistence.Inheritance"));
        }

        if (inheritanceAnnotation != null) {
          // InheritanceType 확인
          Object strategy = inheritanceAnnotation.getClass().getMethod("strategy").invoke(inheritanceAnnotation);
          String strategyName = strategy.toString();

          // TABLE_PER_CLASS가 아닌 경우 독립 엔티티로 간주
          return !strategyName.equals("TABLE_PER_CLASS");
        }

        // @Inheritance가 없으면 기본적으로 SINGLE_TABLE이므로 독립 엔티티
        return true;
      }

      return false;
    } catch (Exception e) {
      // 어노테이션 확인 중 오류 발생시 안전하게 false 반환
      if (log.isDebugEnabled()) {
        log.debug("Error checking if class {} is independent entity: {}", ctClass.getName(), e.getMessage());
      }
      return false;
    }
  }

  protected Set<CtClass> getAllHierarchicalInterfaces(ClassPool classPool, Set<CtClass> result,
      String className)
      throws NotFoundException, ClassNotFoundException {
    // 현재 클래스가 독립 엔티티인지 확인
    CtClass currentClass = classPool.get(className);
    if (isIndependentEntity(currentClass)) {
      // 독립 엔티티인 경우 상위 계층 탐색 중단
      return result;
    }

    for (CtClass interClass : BytecodeUtil.getInterfaces(new HashSet<>(), classPool, className)) {

      if(!className.equals(interClass.getName())){
        result.add(interClass);

        Set<CtClass> subClasses = BytecodeUtil.getInterfaces(new HashSet<>(), classPool, interClass.getName());

        if(subClasses.size() > 1){
          for(CtClass ctClass : subClasses){
            if(!ctClass.getName().equals(interClass.getName())){
              result = getAllHierarchicalInterfaces(classPool, result, ctClass.getName());
            }
          }
        }

      }

      if(interClass.getSuperclass() != null && !interClass.getSuperclass().getName().equals(interClass.getName())){
        CtClass superClass = interClass.getSuperclass();
        // 부모 클래스가 독립 엔티티인지 확인
        if (!isIndependentEntity(superClass)) {
          result = getAllHierarchicalInterfaces(classPool, result, superClass.getName());
        }
      }

    }

    return result;
  }

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    if(!transformedClassNames.contains(result.getClassName())){

      /**
       * 엔티티 클래스만을 대상으로 한다
       */
      if(targetEntityClasses.contains(result.getClassName())){

        boolean transformed = false;

        ClassFile targetClassFile = result.getTargetClassFile();
        boolean adminEntity = BytecodeUtil.getDeclaredAnnotationOnType(targetClassFile, TARGET_ANNOTATION) != null;

        try {
          for (CtClass interfaceClass : BytecodeUtil.getAllInterfaces(result.getTargetClass())) {

            if (classTransformConditions.containsKey(interfaceClass.getName())) {
              TransformCondition condition = classTransformConditions.get(interfaceClass.getName());

              // 템플릿 인터페이스 클래스 변경
              CtClass templateClass = result.getClassPool().get(condition.getTemplateClassName());
              result.setTemplateClass(templateClass);

              for(TemplateBasedClassTransformProvider provider : getTransformProviders()){
                try{
                  result = provider.transformClass(condition, result);
                }catch (Exception e){
                  if (log.isDebugEnabled()) {
                    log.debug("Transform error in provider {} for template class {}: {}",
                        provider.getClass().getSimpleName(), condition.getTemplateClassName(), e.getMessage(), e);
                  }
                }
              }

              transformed = true;
            }


          }
        } catch (Exception e) {
          throw new RuntimeException(e);
        }

        if(adminEntity){
          String superClass = result.getTargetClassFile().getSuperclass();
          if(StringUtils.isNotEmpty(superClass) && !StringUtils.equals(superClass, Object.class.getName())){
            Set<CtClass> interfaces = getAllHierarchicalInterfaces(result.getClassPool(), new HashSet<>(), superClass);

            for(CtClass interfaceClass : interfaces){
              if (classTransformConditions.containsKey(interfaceClass.getName())) {
                TransformCondition condition = classTransformConditions.get(interfaceClass.getName());

                // 템플릿 인터페이스 클래스 변경
                CtClass templateClass = result.getClassPool().get(condition.getTemplateClassName());
                result.setTemplateClass(templateClass);

                for(TemplateBasedClassTransformProvider provider : getTransformProviders()){
                  try{
                    result = provider.transformClass(condition, result);
                  }catch (Exception e){
                    log.warn("Error Provider is " + provider.getClass().getSimpleName() + ":: Template Class is " + condition.getTemplateClassName());
                    log.warn(e.getMessage());
                    log.warn(e.toString());
                  }
                }

                transformed = true;
              }
            }

          }

        }


        if(transformed){
          result.setTransformed(true);
          transformedClassNames.add(result.getClassName());
        }
      }

    }

    return result;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
