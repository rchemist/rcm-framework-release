/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

/**
 * Project : rchemist
 * Created by kunner
 *
 * <p>
 * <p>
 * 엔티티에 OneToMany 로 매핑된 콜렉션 프로퍼티가 있을 때, 해당 콜렉션의 targetEntity가 SoftDelete 를 implements 한 경우
 * 자동으로 @Where 어노테이션을 붙여 준다.
 **/
@Slf4j
@Component
public class ExceptArchivedEntityClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final int order = 600;

  private static final String TARGET_ANNOTATION = "io.rchemist.common.persistence.jpa.domain.template.SoftDelete";

  private static final String WHERE_CLAUSE = "(IS_ARCHIVED is null or IS_ARCHIVED = false)";

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws IOException {
    if (!transformedEntityClassNames.contains(result.getClassName())) {

      boolean transformed = false;

      String className = result.getClassName();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();

      List<FieldInfo> fieldInfos = targetClassFile.getFields();
      Map<String, Annotation> defaultValues = getDeclaredOneToMany(fieldInfos);

      if (MapUtils.isNotEmpty(defaultValues)) {

        for (FieldInfo info : fieldInfos) {

          if(defaultValues.containsKey(info.getName())){
            AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);

            List<?> objects = info.getAttributes();
            Iterator<?> iters = objects.iterator();

            while (iters.hasNext()) {
              Object object = iters.next();
              if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
                AnnotationsAttribute attr = (AnnotationsAttribute) object;
                Annotation[] items = attr.getAnnotations();

                boolean whereClauseNeeded = false;

                CHECK_COLLECTION:
                for (Annotation annotation : items) {
                  annotationsAttribute.addAnnotation(annotation);

                  if (annotation.getTypeName().equals(Annotations.PERSISTENCE_ONE_TO_MANY_CLASS)) {

                    String targetEntityClass = null;

                    MemberValue memberValue = annotation.getMemberValue("targetEntity");
                    if (memberValue != null && memberValue instanceof ClassMemberValue) {
                      ClassMemberValue classMemberValue = (ClassMemberValue) memberValue;
                      targetEntityClass = classMemberValue.getValue();
                    }

                    if(targetEntityClass == null){
                      targetEntityClass = BytecodeUtil.inferTargetEntityClassNameFromFieldType(info);
                    }

                    if(targetEntityClass == null)
                      continue;

                    // Bytecode로 SoftDelete 인터페이스 구현 여부 확인 (클래스 로드 없이)
                    if (isImplementsSoftDeleteByBytecode(targetEntityClass)) {
                      // 이 SubCollection 의 엔티티 클래스가 SoftDelete 를 상속한 경우
                      whereClauseNeeded = true;
                    }
                  }else {
                    // 이미 @Where 가 있다면 더 이상 로직을 실행하지 않는다
                    if(annotation.getTypeName().equals(Annotations.HIBERNATE_WHERE_CLASS)) {
                      whereClauseNeeded = false;
                      break CHECK_COLLECTION;
                    }
                  }
                }

                if(whereClauseNeeded){
                  Annotation where = new Annotation(Annotations.HIBERNATE_WHERE_CLASS, constPool);
                  where.addMemberValue("clause", new StringMemberValue(WHERE_CLAUSE, constPool));
                  annotationsAttribute.addAnnotation(where);
                  transformed = true;
                }

              }
            }

            if (transformed) {
              info.addAttribute(annotationsAttribute);
            }
          }

        }

        transformedEntityClassNames.add(className);

        if (transformed) {
          result.arrangeTransformResultByClassFile(targetClassFile);
        }

      }

    }
    return result;
  }

  /**
   * Bytecode를 통해 클래스가 SoftDelete 인터페이스를 구현하는지 확인한다.
   * 실제 클래스를 로드하지 않고 Javassist를 사용하여 확인한다.
   */
  private boolean isImplementsSoftDeleteByBytecode(String className) {
    try {
      ClassPool pool = ClassPool.getDefault();
      CtClass ctClass = pool.get(className);

      // 인터페이스 확인
      CtClass[] interfaces = ctClass.getInterfaces();
      for (CtClass iface : interfaces) {
        if (TARGET_ANNOTATION.equals(iface.getName())) {
          return true;
        }
      }

      // 부모 클래스에서도 확인
      CtClass superClass = ctClass.getSuperclass();
      while (superClass != null) {
        interfaces = superClass.getInterfaces();
        for (CtClass iface : interfaces) {
          if (TARGET_ANNOTATION.equals(iface.getName())) {
            return true;
          }
        }
        superClass = superClass.getSuperclass();
      }

    } catch (NotFoundException e) {
      log.debug("Failed to check SoftDelete interface for class: " + className, e);
    }

    return false;
  }

  /**
   * ClassFile 에 선언된 모든 필드의 @DefaultValue 어노테이션 정보를 Map<필드명, 어노테이션> 으로 리턴한다
   * @param fieldInfos
   * @return
   */
  public Map<String, Annotation> getDeclaredOneToMany(List<FieldInfo> fieldInfos) {
    Map<String, Annotation> defaultValues = new HashMap<>();
    for (FieldInfo info : fieldInfos) {
      List<?> objects = info.getAttributes();
      Iterator<?> iters = objects.iterator();

      while (iters.hasNext()) {
        Object object = iters.next();
        if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
          AnnotationsAttribute attr = (AnnotationsAttribute) object;
          Annotation[] items = attr.getAnnotations();

          if(ArrayUtils.isNotEmpty(items)){
            for(Annotation annotation : items){
              if(annotation.getTypeName().equals(Annotations.PERSISTENCE_ONE_TO_MANY_CLASS)){
                defaultValues.put(info.getName(), annotation);
              }
            }
          }
        }
      }
    }
    return defaultValues;
  }

  @Override
  public int getOrder() {
    return order;
  }
}