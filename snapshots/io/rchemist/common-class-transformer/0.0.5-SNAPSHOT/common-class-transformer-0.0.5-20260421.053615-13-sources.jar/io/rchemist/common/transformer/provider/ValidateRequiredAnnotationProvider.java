/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.util.BytecodeUtil;
import javassist.CannotCompileException;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class ValidateRequiredAnnotationProvider extends AbstractTemplateBasedClassTransformProvider {

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException {

    if(condition.getRequiredAnnotations() != null && condition.getRequiredAnnotations().length > 0){
      // 템플릿 클래스에서 정의한 - 이를 상속 받을 클래스가 반드시 작성해야 하는 어노테이션이 있다면
      for(String required : condition.getRequiredAnnotations()){
        if(BytecodeUtil.getDeclaredAnnotationOnType(result.getTargetClassFile(), required) == null){
          String errorMessage = result.getTargetClass().getName() + "에서 클래스 " + result.getTemplateClass().getName() + "를 템플릿 클래스로 사용하려면 "+required +
              " 어노테이션을 반드시 작성해야 합니다. ";
          log.warn(errorMessage);

          throw new CannotCompileException(errorMessage);
        }
      }
    }

    return result;
  }

  /**
   * 무조건 처음 시작 되도록 한다
   * @return
   */
  @Override
  public int getOrder(){
    return Integer.MIN_VALUE;
  }
}
