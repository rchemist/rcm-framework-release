/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransformCondition {

  @NonNull private String interfaceClassName;
  @NonNull private String templateClassName;
  private String[] requiredAnnotations;
  private Class<?>[] entityListeners;
  @Default private boolean replaceSignatureOnMapping = false;

  public TransformCondition(String interfaceClassName, String templateClassName){
    this.interfaceClassName = interfaceClassName;
    this.templateClassName = templateClassName;
  }

}
