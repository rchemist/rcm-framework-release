/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.RegisterEntityBean;
import io.rchemist.common.transformer.dto.TransformCondition;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.List;
import java.util.Map;

/**
 * 빌드 타임 바이트코드 변환 체인의 총괄자 인터페이스.
 *
 * <p>0.1.0 이전에는 {@link java.lang.instrument.ClassFileTransformer} 를 구현해
 * JVM ClassFileTransformer callback 으로 런타임 위빙에 등록됐다. 0.1.0 에서 런타임
 * 경로가 제거되면서 {@code ClassFileTransformer} 확장을 해제하고, {@link
 * BuildTimeClassEnhancer} 가 직접 {@link #transform(ClassLoader, String, Class, ProtectionDomain, byte[])}
 * 을 호출하는 구조로 단순화된다. 시그니처는 유지 — Maven 플러그인이 호출하는 형태.</p>
 */
public interface ClassTransformManager {

  Map<String, TransformCondition> getClassTransformConditions();

  void addClassTransformCondition(TransformCondition condition);

  void setClassTransformConditions(Map<String, TransformCondition> classTransformConditions);

  List<String> getClassTransformTargetPackages();

  void setClassTransformTargetPackages(List<String> classTransformTargetPackages);

  boolean containsTargetPackages(String convertedClassName);

  default void registerEntityBean(RegisterEntityBean registerEntityBean) {
    // nothing to do
  }

  int getOrder();

  /**
   * 단일 클래스 바이트코드를 변환한다.
   *
   * @param loader             대상 프로젝트 classloader (빌드 타임에는 plugin 이 구성한 URLClassLoader)
   * @param className          JVM internal form (예: {@code io/rchemist/asset/staticasset/domain/Asset})
   * @param classBeingRedefined JVM ClassFileTransformer 호환 파라미터. 빌드 타임에는 항상 null
   * @param protectionDomain    동일. 빌드 타임에는 항상 null
   * @param classfileBuffer    소스 .class 파일 바이트. 반드시 non-null
   * @return 변환된 바이트 배열. 변환되지 않았으면 null
   */
  byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
      ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException;

}
