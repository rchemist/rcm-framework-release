/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer;

import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.CtNewMethod;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.EnumMemberValue;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class EnumTypeClassTransformer extends AbstractClassTransformer {

  protected Set<String> transformedEntityClassNames = new HashSet<>();

  private static final String ENUMTYPE_CLASSNAME = "io.rchemist.common.enumeration.EnumType";

  private static final int order = 500;

  @Override
  public TransformResult transform(TransformResult result, Set<String> targetEntityClasses, Map<String, TransformCondition> classTransformConditions) throws CannotCompileException, NotFoundException, ClassNotFoundException, IOException {
    if (!transformedEntityClassNames.contains(result.getClassName())) {

      String className = result.getClassName();
      CtClass targetClass = result.getTargetClass();
      ClassFile targetClassFile = result.getTargetClassFile();
      ConstPool constPool = result.getConstPool();
      ClassPool classPool = ClassPool.getDefault();

      if(targetClassFile.getSuperclass().contains(ENUMTYPE_CLASSNAME)){
        String methodName = "get"+targetClass.getSimpleName();

        // getter 메소드 생성, 메소드에 @com.fasterxml.jackson.annotation.JsonCreator 추가
        // String type 으로 EnumType 자신을 반환하는 메소드를 자동으로 만든다.

        CtMethod exist = null;

        try{
          exist = targetClass.getDeclaredMethod(methodName);
        }catch (Exception e){
          // nothing
        }

        if(exist == null){
          // 메소드 생성
          CtMethod getter = CtNewMethod.make(
              "public static " + className + " fromJson(String type) { " +
                  "if (type == null) {return null;}"+
                  "return (" + className + ") io.rchemist.common.util.EnumTypeUtil.getEnumType(" + className + ".class, type.toUpperCase(), null);" +
                  "}", targetClass);


          // 메소드에 @JsonCreator 어노테이션 추가
          MethodInfo methodInfo = getter.getMethodInfo();
          AnnotationsAttribute annotationsAttribute = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);
          Annotation annotation = new Annotation("com.fasterxml.jackson.annotation.JsonCreator", constPool);

          EnumMemberValue modeValue = new EnumMemberValue(constPool);
          modeValue.setType("com.fasterxml.jackson.annotation.JsonCreator$Mode");
          modeValue.setValue("DELEGATING");
          annotation.addMemberValue("mode", modeValue);

          annotationsAttribute.addAnnotation(annotation);
          methodInfo.addAttribute(annotationsAttribute);

          // 클래스에 메소드 추가
          targetClass.addMethod(getter);

          targetClassFile = targetClass.getClassFile();

          // 변환된 클래스 결과 업데이트
          result.arrangeTransformResultByClassFile(targetClassFile);

          transformedEntityClassNames.add(className);

          if (log.isDebugEnabled()) {
            log.debug("Method "+methodName+ "(String type) has created on the class " + className);
          }

        }

        // static 으로 선언된 객체들을 모두 load 한다.
        // Class.forName(className);

      }

    }


    return result;
  }

  @Override
  public int getOrder() {
    return order;
  }
}
