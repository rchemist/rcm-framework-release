/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import io.rchemist.common.util.RequestParameterUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.data.ParameterDTO;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.text.StringEscapeUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class ItemRequestUrl implements Serializable {

  private String raw;

  public ItemRequestUrl(String raw) {
    this.raw = raw;

    String protocol = StringUtil.subStringBefore(raw, "://");
    if(StringUtils.isEmpty(protocol)){
      this.protocol = "http";
    }else{
      this.protocol = protocol;
    }

    String port = StringUtil.subStringAfterLast(raw, ":");
    port = StringUtil.subStringBefore(port, "/");

    if(NumberUtils.isCreatable(port)){
      this.port = port;
    }else{
      this.port = "80";
    }

    String host = StringUtil.subStringAfter(raw, "://");
    host = StringUtil.subStringBefore(host, "/");
    if(StringUtils.contains(host, ":")){
      host = StringUtil.subStringBefore(host, ":");
    }
    List<String> hosts = StringUtil.split(host, ".");
    this.host = hosts.toArray(new String[0]);

    String path = StringUtil.subStringAfter(raw, host);
    path = StringUtil.between(path, "/", "?");
    List<String> paths = StringUtil.split(path, "/");
    this.path = paths.toArray(new String[0]);

    ParameterDTO parameters = RequestParameterUtil.parseParameters(raw);
    if(parameters.hasParameters()){
      query = new HashMap<>();
      for(String key : parameters.getParameterNames()){
        String value = parameters.getParameter(key);
        query.put(key, value);
      }
    }else{
      this.query = null;
    }

  }

  private final String protocol;
  private final String[] host;
  private final String port;
  private final String[] path;
  private final Map<String, String> query;

  public String toJson() {
    String json = StringUtil.toJson(this);

    return StringEscapeUtils.unescapeJava(json);
  }
}
