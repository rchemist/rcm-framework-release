/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ApiCollectionDTO implements Serializable {

  public ApiCollectionDTO(String postManId, String name, String schema){
    ApiDetail info = new ApiDetail(postManId, name, schema);
    this.info = info;
  }

  private final ApiDetail info;

  private List<Item> item;

  public ApiCollectionDTO addItem(Item item){
    if(this.item == null)
      this.item = new ArrayList<>();
    this.item.add(item);
    return this;
  }

  @Override
  public String toString(){
    String json = StringUtil.toJson(this);
    return StringUtils.replace(json, "\\u003d", "=");
  }

  public Item getRegisteredItem(String itemName){
    if(CollectionUtils.isNotEmpty(this.item)){
      for(Item item : this.item ){
        if(item.getName().equals(itemName)){
          return item;
        }
      }
    }
    return null;
  }

}
