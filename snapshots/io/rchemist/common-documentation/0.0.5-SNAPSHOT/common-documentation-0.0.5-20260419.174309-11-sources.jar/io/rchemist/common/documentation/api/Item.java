/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class Item implements Serializable {

  public Item(String name) {
    this.name = name;
  }

  private final String name;

  private ItemEvent event;

  private List<ItemRequest> request;

  private ItemResponse response;

  private ProtocolProfileBehavior protocolProfileBehavior;

  private List<Item> item;

  public Item withEvent(ItemEvent event) {
    this.event = event;
    return this;
  }

  public Item withRequest(List<ItemRequest> request) {
    this.request = request;
    return this;
  }

  public Item addRequest(ItemRequest request){
    if(this.request == null)
      this.request = new ArrayList<>();
    this.request.add(request);
    this.protocolProfileBehavior = new ProtocolProfileBehavior();
    return this;
  }

  public Item withResponse(ItemResponse response) {
    this.response = response;
    return this;
  }

  public Item withProtocolProfileBehavior(
      ProtocolProfileBehavior protocolProfileBehavior) {
    this.protocolProfileBehavior = protocolProfileBehavior;
    return this;
  }

  public Item addItem(Item item) {
    if(this.item == null)
      this.item = new ArrayList<>();
    this.item.add(item);
    return this;
  }

  public Item getRegisteredItemName(String itemName) {
    if(CollectionUtils.isNotEmpty(this.item)){
      for(Item item : this.item){
        if(item.getName().equals(itemName)){
          return item;
        }
      }
    }
    return null;
  }
}
