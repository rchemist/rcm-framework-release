/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ItemRequest implements Serializable {

  public ItemRequest(String url, String method){
    this.method = method;
    this.url = new ItemRequestUrl(url);
  }

  private final String method;

  private final ItemRequestUrl url;

  private List<ItemRequestAuth> auth;

  private String[] header;

  private ItemRequestBody body;

  private String description;

  public ItemRequest withDescription(String description) {
    this.description = description;
    return this;
  }

  public ItemRequest addHeader(String... headers){
    this.header = headers;
    return this;
  }

  public ItemRequest withHeader(String[] header) {
    this.header = header;
    return this;
  }

  public ItemRequest withBody(String jsonBody) {
    this.body = new ItemRequestBody(jsonBody);
    return this;
  }

  public ItemRequest withAuth(RestAuthType authType){
    if(this.auth == null)
      this.auth = new ArrayList<>();
    this.auth.add(new ItemRequestAuth(authType));
    return this;
  }

}
