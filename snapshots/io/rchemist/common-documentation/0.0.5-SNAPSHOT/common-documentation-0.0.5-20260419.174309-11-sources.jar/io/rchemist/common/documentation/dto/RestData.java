/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestData implements Serializable {

  private String name;

  private String property;

  private Class<?> type;

  private String description;

  private String example;

  private List<RestData> data = new ArrayList<>();

  public RestData withName(String name) {
    this.name = name;
    return this;
  }

  public RestData withDescription(String comment) {
    this.description = comment;
    return this;
  }

  public RestData withExample(String example) {
    this.example = example;
    return this;
  }

  public RestData withData(List<RestData> data) {
    this.data = data;
    return this;
  }

  public RestData addData(RestData data){
    this.data.add(data);
    return this;
  }

  public RestData withProperty(String property) {
    this.property = property;
    return this;
  }

  public RestData withType(Class<?> type) {
    this.type = type;
    return this;
  }
}
