/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation;

import io.rchemist.common.documentation.api.ApiCollectionDTO;
import io.rchemist.common.documentation.api.Item;
import io.rchemist.common.documentation.api.ItemEvent;
import io.rchemist.common.documentation.api.ItemRequest;
import io.rchemist.common.documentation.api.RestAuthType;
import io.rchemist.common.documentation.dto.RestData;
import io.rchemist.common.documentation.dto.RestDataPublisher;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.StringUtil;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class DocumentHelper {

  private static final String PARAM_SITE_URL = "siteUrl";
  private static final String PARAM_POSTMAN_ID = "postmanId";
  private static final String PARAM_APP_NAME = "appName";
  private static final String PARAM_POSTMAN_SCHEMA = "schema";

  public static void printRestData(String... packagesToScan){
    if(ArrayUtils.isEmpty(packagesToScan))
      packagesToScan = new String[]{"io.rchemist"};

    Map<String, RestData> restDataMap = new HashMap<>();
    for(String packageStr : packagesToScan) {
      Reflections reflections = new Reflections(packageStr);
      Set<Class<?>> classes = reflections.getTypesAnnotatedWith(io.rchemist.common.documentation.RestData.class);

      for(Class<?> clazz : CollectionUtils.emptyIfNull(classes)){

        io.rchemist.common.documentation.RestData type = clazz.getAnnotation(io.rchemist.common.documentation.RestData.class);

        if(type != null) {
          String className = clazz.getName();

          RestData restData = new RestData()
              .withName(type.name())
              .withDescription(type.description())
              .withExample(type.example())
              .withType(clazz)
              .withProperty(className);

          for(Field field : BytecodeUtil.getAllFields(clazz, false)){

            RestDataField fieldDescription = field.getDeclaredAnnotation(RestDataField.class);

            String property;
            String description;
            String example;
            String name;
            Class<?> fieldType = field.getType();

            if(fieldDescription != null){

              property = field.getName();
              description = fieldDescription.description();
              example = fieldDescription.example();
              name = StringUtils.defaultIfEmpty(fieldDescription.name(), property);

              if(fieldDescription.required()){
                name = name + "(*)";
              }

            }else{
              // RestDataField 어노테이션이 없어도 자동으로 처리한다.
              property = field.getName();
              description = "";
              example = "";
              name = property;
            }

            RestData fieldData = new RestData()
                .withName(name)
                .withProperty(property)
                .withDescription(description)
                .withExample(example)
                .withType(field.getType())
                ;

            restData.addData(fieldData);


          }

          restDataMap.put(restData.getProperty(), restData);
        }

      }

    }

    String fileName = RestDataPublisher.publish(restDataMap);

    fileName = fileName + "\n\n"
        + "cp " + fileName
        + " /Users/kunner/IdeaProjects/micro-shop/documents.adoc"
        + "\n\nasciidoctor "+ StringUtils.substringAfterLast(fileName, "/");

    log.info("###########################");
    log.info(fileName);
    log.info("###########################");

  }

  public static ApiCollectionDTO getRestApiCollections(
      String postmanSchema,
      String siteUrl, String postManId, String name, String... packagesToScan){
    Map<String, Integer> level1 = new HashMap<>();
    Map<String, Map<String, Integer>> level2 = new HashMap<>();
    Map<String, Map<String, Integer>> level3 = new HashMap<>();
    Set<String> addedEndpoint = new HashSet<>();

    if(ArrayUtils.isEmpty(packagesToScan))
      packagesToScan = new String[]{"io.rchemist"};

    ApiCollectionDTO dto = new ApiCollectionDTO(postManId, name, postmanSchema);

    for(String packageStr : packagesToScan) {
      Reflections reflections = new Reflections(packageStr);
      Set<Class<?>> classes = reflections.getTypesAnnotatedWith(RestDocument.class);

      for(Class<?> clazz : CollectionUtils.emptyIfNull(classes)){

        RestDocument document = clazz.getAnnotation(RestDocument.class);

        String project = document.project();
        int projectNumber = level1.size() + 1;
        if(level1.containsKey(project)){
          projectNumber = level1.get(project);
        }else{
          level1.put(project, projectNumber);
        }

        String urlPrefix = siteUrl;

        RequestMapping requestMapping = clazz.getAnnotation(RequestMapping.class);
        if(requestMapping != null){
          urlPrefix = urlPrefix + Arrays.stream(requestMapping.value()).findAny().get();
        }

        Item apiItem = dto.getRegisteredItem(document.value());
        if(apiItem == null){
          apiItem = new Item(document.value());
        }

        Item spec = new Item(projectNumber + "." + document.value());

        for(Method method : clazz.getMethods()){

          if(method.isAnnotationPresent(RestEndpoint.class)){

            RestEndpoint endpoint = method.getAnnotation(RestEndpoint.class);

            RequestMapping methodMapping = method.getAnnotation(RequestMapping.class);
            if(methodMapping != null){

              String[] urls = methodMapping.value();
              RequestMethod[] methods = methodMapping.method();

              setRequestInformation(method, addedEndpoint, spec, project, projectNumber, level2, level3, urlPrefix, endpoint, urls, methods);

            }

            GetMapping getMapping = method.getAnnotation(GetMapping.class);
            if(getMapping != null){
              String[] urls = getMapping.value();
              RequestMethod[] methods = new RequestMethod[]{RequestMethod.GET};
              setRequestInformation(method, addedEndpoint, spec, project, projectNumber, level2, level3, urlPrefix, endpoint, urls, methods);
            }

            PostMapping postMapping = method.getAnnotation(PostMapping.class);
            if(postMapping != null){
              String[] urls = postMapping.value();
              RequestMethod[] methods = new RequestMethod[]{RequestMethod.POST};
              setRequestInformation(method, addedEndpoint, spec, project, projectNumber, level2, level3, urlPrefix, endpoint, urls, methods);
            }

            DeleteMapping deleteMapping = method.getAnnotation(DeleteMapping.class);
            if(deleteMapping != null){
              String[] urls = deleteMapping.value();
              RequestMethod[] methods = new RequestMethod[]{RequestMethod.DELETE};
              setRequestInformation(method, addedEndpoint, spec, project, projectNumber, level2, level3, urlPrefix, endpoint, urls, methods);
            }

            PutMapping putMapping = method.getAnnotation(PutMapping.class);
            if(putMapping != null){
              String[] urls = putMapping.value();
              RequestMethod[] methods = new RequestMethod[]{RequestMethod.PUT};
              setRequestInformation(method, addedEndpoint, spec, project, projectNumber, level2, level3, urlPrefix, endpoint, urls, methods);
            }

          }

        }

        apiItem.addItem(spec);

        dto.addItem(apiItem);

      }

    }

    return dto;

  }

  private static int getNumber(Map<String, Map<String, Integer>> level3, String level2Stage,
      String level3Stage) {
    int number;
    if(level3.containsKey(level2Stage)){
      number = getRegisteredNumber(level3, level2Stage, level3Stage);
    }else{
      Map<String, Integer> value = new HashMap<>();
      value.put(level3Stage, 1);
      number = 1;
      level3.put(level2Stage, value);
    }
    return number;
  }

  private static int getOrder(Map<String, Map<String, Integer>> level2, String project,
      String level2Stage) {
    int order;
    if(level2.containsKey(project)){
      order = getRegisteredNumber(level2, project, level2Stage);
    }else{
      Map<String, Integer> value = new HashMap<>();
      order = 1;
      value.put(level2Stage, 1);
      level2.put(project, value);
    }
    return order;
  }

  private static int getRegisteredNumber(Map<String, Map<String, Integer>> level3, String level2Stage,
      String level3Stage) {
    int number;
    Map<String, Integer> value = level3.get(level2Stage);
    if(value.containsKey(level3Stage)){
      number = value.get(level3Stage);
    }else{
      number = value.size() + 1;
      value.put(level3Stage, number);
      level3.put(level2Stage, value);
    }
    return number;
  }

  private static void setRequestInformation(Method method, Set<String> addedEndpoint,
      Item spec,
      String project,
      int projectNumber,
      Map<String, Map<String, Integer>> level2,
      Map<String, Map<String, Integer>> level3,
      String urlPrefix, RestEndpoint endpoint, String[] urls,
      RequestMethod[] methods) {
    if(ArrayUtils.isEmpty(urls))
      urls = new String[]{""};
    for(String url : urls){

      String methodUrl = url;
      if(StringUtils.isNotEmpty(urlPrefix)){
        methodUrl = urlPrefix + url;
      }

      if(StringUtils.contains(methodUrl, "{")){
        methodUrl = StringUtils.replace(methodUrl, "{", "{{");
      }

      if(StringUtils.contains(methodUrl, "}")){
        methodUrl = StringUtils.replace(methodUrl, "}", "}}");
      }

      if(StringUtils.contains(methodUrl, "//")){
        methodUrl = StringUtils.replace(methodUrl, "//", "/");
        methodUrl = StringUtils.replace(methodUrl, ":/", "://");
      }

      for(RequestMethod requestMethod : methods){

        String level2Stage = projectNumber + "." + endpoint.stage();

        int order = getOrder(level2, project, level2Stage);

        String stageName = projectNumber + "." + order + ". " + endpoint.stage();

        String level3Stage = projectNumber + "." + order + "." + requestMethod.name() + endpoint.value();

        String itemName = projectNumber + "." + order + "." + getNumber(level3, level2Stage, level3Stage);

        Item item = new Item(itemName + ". " + endpoint.value());

        String endpointKey = requestMethod.name() + "||" +  methodUrl;
        if(!addedEndpoint.contains(endpointKey)){
          ItemRequest itemRequest = new ItemRequest(methodUrl, requestMethod.name())
              .withDescription(endpoint.description());

          if(!endpoint.auth().equals(RestAuthType.NONE)){
            itemRequest.withAuth(endpoint.auth());
          }

          item.addRequest(itemRequest);

          addedEndpoint.add(endpointKey);

          if(ArrayUtils.isNotEmpty(endpoint.scripts())){
            TestScript[] scripts = endpoint.scripts();
            Map<String, String> properties = new HashMap<>();
            for(TestScript script : scripts){
              String property = script.property();
              String variable = script.variable();
              properties.put(variable, property);
            }
            item.withEvent(new ItemEvent(properties));
          }

          if(CollectionUtils.isNotEmpty(item.getRequest())){
            for(Parameter parameter : method.getParameters()){
              RequestBody requestBody = parameter.getAnnotation(RequestBody.class);
              if(requestBody != null){
                try {

                  Example example = parameter.getAnnotation(Example.class);

                  if(example != null && StringUtils.isNotEmpty(example.value())){
                    for(ItemRequest request : item.getRequest()){
                      request.withBody(example.value());
                    }
                  }else{
                    Object body = parameter.getType().newInstance();

                    for(ItemRequest request : item.getRequest()){
                      request.withBody(StringUtil.toJson(body, true));
                    }
                  }
                } catch (InstantiationException e) {
                  e.printStackTrace();
                } catch (IllegalAccessException e) {
                  e.printStackTrace();
                }
              }
            }

            Item apiSpecItem = spec.getRegisteredItemName(stageName);
            if(apiSpecItem == null){
              apiSpecItem = new Item(stageName);
              spec.addItem(apiSpecItem);
            }

            apiSpecItem.addItem(item);



          }


        }



      }
    }
  }

  public static void exportPostman(String[] args, String appName, String postmanId, String postmanSchema, String siteUrl) {
    Map<String, String> arguments = new HashMap<>();
    if(ArrayUtils.isNotEmpty(args)){
      for(String arg : args){
        List<String> params = StringUtil.split(arg, "=");
        String value = "";
        if(params.size() > 1){
          value = params.get(1);
        }
        arguments.put(params.get(0), value);
      }
    }

    refineArgument(arguments, PARAM_APP_NAME, appName);
    refineArgument(arguments, PARAM_POSTMAN_ID, postmanId);
    refineArgument(arguments, PARAM_POSTMAN_SCHEMA, postmanSchema);
    refineArgument(arguments, PARAM_SITE_URL, siteUrl);

    ApiCollectionDTO dto = DocumentHelper.getRestApiCollections(
        arguments.get(PARAM_POSTMAN_SCHEMA),
        arguments.get(PARAM_SITE_URL),
        arguments.get(PARAM_POSTMAN_ID),
        arguments.get(PARAM_APP_NAME));

    LocalDateTime dateTime = LocalDateTime.now();
    File file = new File(System.getProperty("java.io.tmpdir") + System.getProperty("file.separator")
        + "postmanData_" + dateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
        + ".json");

    try {
      PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)), true);
      pw.println(dto.toString());

      String path = file.getPath();

      path = path + "\n\n"
          + "cp " + path
          + " /Users/hongin/IdeaProjects/micro-shop/postman-documents.json"
          + "\n\nasciidoctor "+ StringUtils.substringAfterLast(path, "/");

      log.info("###########################");
      log.info(path);
      log.info("###########################");

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void refineArgument(Map<String, String> arguments, String paramName, String defaultValue){
    if(!arguments.containsKey(paramName)){
      arguments.put(paramName, defaultValue);
    }
  }


}
