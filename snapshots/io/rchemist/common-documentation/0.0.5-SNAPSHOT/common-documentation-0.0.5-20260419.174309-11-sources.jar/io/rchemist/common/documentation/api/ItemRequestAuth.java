/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ItemRequestAuth implements Serializable {

  public ItemRequestAuth(RestAuthType authType) {

    Map<String, String> bearer = new HashMap<>();

    if(!authType.equals(RestAuthType.NONE)){
      bearer.put("key", "token");
      bearer.put("type", "string");
      if(authType.equals(RestAuthType.CUSTOMER)){
        bearer.put("value", "{{customerToken}}");
      }else if(authType.equals(RestAuthType.ADMIN)){
        bearer.put("value", "{{token}}");
      }
    }
    this.bearer = bearer;
  }

  private final String type = "bearer";
  private final Map<String, String> bearer;

}
