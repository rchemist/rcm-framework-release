/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ItemEventScript implements Serializable {

  private final String type = "text/javascript";
  private List<String> exec;

  public ItemEventScript(Map<String, String> properties){
    if(MapUtils.isNotEmpty(properties)){
      exec = new ArrayList<>();
      exec.add("var data = JSON.parse(responseBody);");
      for(Entry<String, String> entry : properties.entrySet()){

        String property = entry.getKey();
        String data = entry.getValue();

        exec.add("pm.environment.set(\"" + property + "\", data.data." + data + ");");
        exec.add("pm.globals.set(\"" + property + "\", data.data." + data + ");");
      }

    }
  }

}
