/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.documentation.dto;

import io.rchemist.common.util.StringUtil;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class RestDataPublisher {

  // String Classname, RestData
  public static String publish(Map<String, RestData> records){


    LocalDateTime dateTime = LocalDateTime.now();
    File file = new File(System.getProperty("java.io.tmpdir") + System.getProperty("file.separator")
        + "restData_"+dateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
        + ".adoc");

    try{

      PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)), true);
      pw.println("= REST DATA 정의서");
      pw.println(":toc: left");
      pw.println(":stylesheet: asciidoctor.css");
      pw.println(":hardbreaks:");
      pw.println(":doctype: book");
      pw.println(":icons: font");
      pw.println();

      Iterator<RestData> iterator = records.values().iterator();

      int count = 0;

      while(iterator.hasNext()){

        RestData restData = iterator.next();

        String title = "= " + ++count + ". " + restData.getName();
        pw.println("[["+restData.getProperty()+"]]");
        pw.println(title);
        pw.println();

        if(restData.getType() != null){
          pw.println(".Fully-Qualified-Classname" );
          pw.println(restData.getType().getName());
          pw.println();
        }

        if(StringUtils.isNotEmpty(restData.getDescription())){
          pw.println(".Description");
          pw.println(restData.getDescription());
          pw.println();
        }

        if(StringUtils.isNotEmpty(restData.getExample())){
          pw.println(".Example");
          pw.println("****");
          pw.println("[source, json]");
          pw.println("-----");
          pw.println(restData.getExample());
          pw.println("-----");
          pw.println("****");
          pw.println();
        }

        if(CollectionUtils.isNotEmpty(restData.getData())){
          pw.println("[caption=\"\"]");
          pw.println(".Metadata");
          pw.println("[cols=\"<.<1,<.<2,<.<2,<.^3,<.^2\"]");
          pw.println("|====================");

          for(RestData field : restData.getData()){
            pw.println("| " + field.getProperty() );
            pw.println("| " + field.getName() );
            if(field.getType() != null){
              String className = field.getType().getName();

              if(StringUtils.startsWith(className, "java.")){
                // java.lang.String 이면 String 만 남긴다.
                className = StringUtils.substringAfterLast(className, ".");
              }else{

                if(records.containsKey(className)){
                  String name = StringUtils.substringAfterLast(className, ".");
                  className = "link:#"+className+"["+name+"]";
                }

              }
              pw.println("| " + className );
            }
            pw.println("| " + StringUtil.toString(field.getDescription()) );
            pw.println("| " + StringUtil.toString(field.getExample()));
          }

          pw.println("|====================");

          pw.println();
          pw.println("{empty}");
          pw.println();

        }



      }



    }catch (Exception e){
      e.printStackTrace();
    }

    return file.getPath();

  }

}
