/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 사용자 ScopedValue context — Phase 1 의 3 키 중 하나. userId / username / roles 적용,
 * roles 는 immutable copy + hasRole helper 제공.
 **/
public record UserContext(String userId, String username, Set<String> roles) {

    private static final ScopedValue<UserContext> SCOPE = ScopedValue.newInstance();

    public UserContext {
        Objects.requireNonNull(userId, "userId");
        roles = roles == null ? Set.of() : Set.copyOf(roles);
    }

    public static UserContext current() {
        return SCOPE.get();
    }

    public static boolean isBound() {
        return SCOPE.isBound();
    }

    public static String currentUserIdOrNull() {
        return SCOPE.isBound() ? SCOPE.get().userId() : null;
    }

    public boolean hasRole(String role) {
        return roles.contains(role);
    }

    public static <R, X extends Throwable> R callWith(UserContext ctx, ScopedValue.CallableOp<R, X> task) throws X {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        return ScopedValue.where(SCOPE, ctx).call(task);
    }

    public static void runWith(UserContext ctx, Runnable task) {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        ScopedValue.where(SCOPE, ctx).run(task);
    }
}
