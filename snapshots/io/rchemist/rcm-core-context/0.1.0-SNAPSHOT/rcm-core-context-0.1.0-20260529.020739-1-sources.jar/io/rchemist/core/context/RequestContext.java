/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 요청 단위 ScopedValue context — Phase 1 의 3 키 (RequestContext / TenantContext / UserContext)
 * 중 하나. requestId / traceparent / tracestate 적용, ScopedValueMdcBinder 와 짝.
 **/
public record RequestContext(String requestId, String traceparent, String tracestate) {

    private static final ScopedValue<RequestContext> SCOPE = ScopedValue.newInstance();

    public RequestContext {
        Objects.requireNonNull(requestId, "requestId");
    }

    public static RequestContext current() {
        return SCOPE.get();
    }

    public static boolean isBound() {
        return SCOPE.isBound();
    }

    public static String currentRequestIdOrNull() {
        return SCOPE.isBound() ? SCOPE.get().requestId() : null;
    }

    public static <R, X extends Throwable> R callWith(RequestContext ctx, ScopedValue.CallableOp<R, X> task) throws X {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        return ScopedValue.where(SCOPE, ctx).call(task);
    }

    public static void runWith(RequestContext ctx, Runnable task) {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        ScopedValue.where(SCOPE, ctx).run(task);
    }
}
