/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 멀티테넌트 ScopedValue context — Phase 1 의 3 키 중 하나. tenantId / tenantName 적용,
 * SYSTEM_TENANT_ID = "__system__" 상수 + runAs / runAsSystem helper 제공.
 *
 * <p>Phase 3 task #5 (Decision #17 보강) — Background task / {@code @Scheduled} 명시 강제용
 * {@link #required()} Fail-loud + {@link #runAs(String, Runnable)} Runnable overload + {@link
 * #callAsSystem} Callable overload + {@link #forEachTenant} 다중 tenant 순회 helper.
 **/
public record TenantContext(String tenantId, String tenantName) {

    public static final String SYSTEM_TENANT_ID = "__system__";

    private static final ScopedValue<TenantContext> SCOPE = ScopedValue.newInstance();

    public TenantContext {
        Objects.requireNonNull(tenantId, "tenantId");
    }

    public static TenantContext current() {
        return SCOPE.get();
    }

    public static boolean isBound() {
        return SCOPE.isBound();
    }

    public static String currentTenantIdOrNull() {
        return SCOPE.isBound() ? SCOPE.get().tenantId() : null;
    }

    /**
     * Phase 3 task #5 — Fail-loud accessor (Decision #17). 미적용 시 {@link TenantContextMissingException}.
     * Background task / @Scheduled / Bootstrap 영역에서 silent system tenant fallback 차단.
     */
    public static TenantContext required() {
        if (!SCOPE.isBound()) {
            throw new TenantContextMissingException();
        }
        return SCOPE.get();
    }

    public static <R, X extends Throwable> R callWith(TenantContext ctx, ScopedValue.CallableOp<R, X> task) throws X {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        return ScopedValue.where(SCOPE, ctx).call(task);
    }

    public static void runWith(TenantContext ctx, Runnable task) {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        ScopedValue.where(SCOPE, ctx).run(task);
    }

    public static <R, X extends Throwable> R runAs(String tenantId, ScopedValue.CallableOp<R, X> task) throws X {
        return callWith(new TenantContext(tenantId, null), task);
    }

    /** Phase 3 task #5 — Runnable form of {@link #runAs(String, ScopedValue.CallableOp)}. */
    public static void runAs(String tenantId, Runnable task) {
        runWith(new TenantContext(tenantId, null), task);
    }

    /**
     * 현재 thread 의 {@link TenantContext} 를 {@code __system__} tenant 로 임시 바인딩 후 task 실행.
     *
     * <p>주 용도 — {@link io.rchemist.core.marker.TenantAlias} 적용 entity 의 <b>singleton seed
     * row (전역 default policy)</b> 조회/갱신. seed row 는 {@code TENANT_ID = '__system__'} 로
     * 적재되며, 다른 tenant context 에서 직접 조회하면 Hibernate 자동 필터에 의해 0 rows 반환됨.
     *
     * <pre>{@code
     * TenantContext.runAsSystem(() -> {
     *     RecommendationPolicy seed = repository.findById(SEED_POLICY_ID).orElseThrow();
     *     seed.setMaxRecommendations(10);
     *     repository.save(seed);
     * });
     * }</pre>
     *
     * <p><b>중요 — outer {@code @Transactional} 안에서 호출하지 말 것</b>. Hibernate 7
     * multi-tenancy 는 *session 생성 시점* 에 한 번 tenant 를 resolve 하여 session 에 pin 하므로,
     * outer {@code @Transactional} 이 이미 열린 session 의 tenant 를 본 메서드가 바꿀 수 없다.
     * 정합 패턴 — service 메서드에는 {@code @Transactional} 을 두지 않고, {@code runAsSystem} 안
     * 에서 repository 호출 (Spring Data JPA 의 default per-call tx) 이 매번 fresh tenant 를 resolve.
     */
    public static void runAsSystem(Runnable task) {
        runWith(new TenantContext(SYSTEM_TENANT_ID, "system"), task);
    }

    /**
     * Phase 3 task #5 — Callable form of {@link #runAsSystem(Runnable)}.
     *
     * <p>주 용도 — singleton seed row 조회의 return 값 캡쳐.
     * <pre>{@code
     * RecommendationPolicy seed = TenantContext.callAsSystem(() ->
     *     repository.findById(SEED_POLICY_ID).orElseThrow());
     * }</pre>
     */
    public static <R, X extends Throwable> R callAsSystem(ScopedValue.CallableOp<R, X> task) throws X {
        return callWith(new TenantContext(SYSTEM_TENANT_ID, "system"), task);
    }

    /**
     * Phase 3 task #5 — 다중 tenant 순회 helper (Decision #17 — Cross-tenant batch / forEachTenant).
     * 각 tenant 별로 {@link #runAs(String, Runnable)} scope 적용 후 task 실행. 한 tenant 실패가 다음 tenant
     * 실행을 중단시킨다 (Fail-fast). 부분 실패 허용이 필요하면 caller 가 try/catch.
     */
    public static void forEachTenant(Iterable<String> tenantIds, Consumer<String> task) {
        Objects.requireNonNull(tenantIds, "tenantIds");
        Objects.requireNonNull(task, "task");
        for (String tenantId : tenantIds) {
            runAs(tenantId, () -> task.accept(tenantId));
        }
    }
}
