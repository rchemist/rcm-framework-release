/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Background task / {@code @Scheduled} / 비-HTTP entry point 가 명시적으로 tenant
 * scope 적용 강제 marker (Decision #17 — Background task / Scheduled 명시 강제 / Fail loud). 어노테이션
 * 부착된 method 또는 type 진입 시 {@link TenantContext#required()} 가 호출되며, 미적용 시 {@link
 * TenantContextMissingException} 발생.
 *
 * <p>{@code rcm-starter-jpa} 의 {@code RequireTenantAspect} 가 AOP 위임. type 부착 시 모든 public
 * method 적용. method 부착 시 해당 method 만.
 **/
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RequireTenant {}
