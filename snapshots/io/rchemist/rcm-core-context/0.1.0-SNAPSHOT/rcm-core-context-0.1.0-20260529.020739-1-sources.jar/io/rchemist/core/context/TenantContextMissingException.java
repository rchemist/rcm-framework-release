/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — TenantContext 미적용 시 Fail-loud signal (Decision #17). Background task /
 * {@code @Scheduled} / Bootstrap 영역에서 tenant scope 누락을 silent default 로 묻지 않고 명시 실패시킴.
 * silent cross-tenant 차단 + 명시적 escape ({@link TenantContext#runAsSystem(Runnable)}) 강제.
 **/
public class TenantContextMissingException extends RuntimeException {

  public TenantContextMissingException() {
    super("TenantContext is not bound. Use TenantContext.runWith / runAs / runAsSystem to bind a tenant explicitly.");
  }

  public TenantContextMissingException(String message) {
    super(message);
  }
}
