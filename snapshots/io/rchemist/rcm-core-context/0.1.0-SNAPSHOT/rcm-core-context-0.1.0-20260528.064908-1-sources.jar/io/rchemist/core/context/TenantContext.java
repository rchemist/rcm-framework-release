/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.core.context;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 멀티테넌트 ScopedValue context — Phase 1 의 3 키 중 하나. tenantId / tenantName 적용,
 * SYSTEM_TENANT_ID = "__system__" 상수 + runAs / runAsSystem helper 제공.
 *
 * <p>Phase 3 task #5 (Decision #17 보강) — Background task / {@code @Scheduled} 명시 강제용
 * {@link #required()} Fail-loud + {@link #runAs(String, Runnable)} Runnable overload + {@link
 * #callAsSystem} Callable overload + {@link #forEachTenant} 다중 tenant 순회 helper.
 **/
public record TenantContext(String tenantId, String tenantName) {

    public static final String SYSTEM_TENANT_ID = "__system__";

    private static final ScopedValue<TenantContext> SCOPE = ScopedValue.newInstance();

    public TenantContext {
        Objects.requireNonNull(tenantId, "tenantId");
    }

    public static TenantContext current() {
        return SCOPE.get();
    }

    public static boolean isBound() {
        return SCOPE.isBound();
    }

    public static String currentTenantIdOrNull() {
        return SCOPE.isBound() ? SCOPE.get().tenantId() : null;
    }

    /**
     * Phase 3 task #5 — Fail-loud accessor (Decision #17). 미적용 시 {@link TenantContextMissingException}.
     * Background task / @Scheduled / Bootstrap 영역에서 silent system tenant fallback 차단.
     */
    public static TenantContext required() {
        if (!SCOPE.isBound()) {
            throw new TenantContextMissingException();
        }
        return SCOPE.get();
    }

    public static <R, X extends Throwable> R callWith(TenantContext ctx, ScopedValue.CallableOp<R, X> task) throws X {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        return ScopedValue.where(SCOPE, ctx).call(task);
    }

    public static void runWith(TenantContext ctx, Runnable task) {
        Objects.requireNonNull(ctx, "ctx");
        Objects.requireNonNull(task, "task");
        ScopedValue.where(SCOPE, ctx).run(task);
    }

    public static <R, X extends Throwable> R runAs(String tenantId, ScopedValue.CallableOp<R, X> task) throws X {
        return callWith(new TenantContext(tenantId, null), task);
    }

    /** Phase 3 task #5 — Runnable form of {@link #runAs(String, ScopedValue.CallableOp)}. */
    public static void runAs(String tenantId, Runnable task) {
        runWith(new TenantContext(tenantId, null), task);
    }

    public static void runAsSystem(Runnable task) {
        runWith(new TenantContext(SYSTEM_TENANT_ID, "system"), task);
    }

    /** Phase 3 task #5 — Callable form of {@link #runAsSystem(Runnable)}. */
    public static <R, X extends Throwable> R callAsSystem(ScopedValue.CallableOp<R, X> task) throws X {
        return callWith(new TenantContext(SYSTEM_TENANT_ID, "system"), task);
    }

    /**
     * Phase 3 task #5 — 다중 tenant 순회 helper (Decision #17 — Cross-tenant batch / forEachTenant).
     * 각 tenant 별로 {@link #runAs(String, Runnable)} scope 적용 후 task 실행. 한 tenant 실패가 다음 tenant
     * 실행을 중단시킨다 (Fail-fast). 부분 실패 허용이 필요하면 caller 가 try/catch.
     */
    public static void forEachTenant(Iterable<String> tenantIds, Consumer<String> task) {
        Objects.requireNonNull(tenantIds, "tenantIds");
        Objects.requireNonNull(task, "task");
        for (String tenantId : tenantIds) {
            runAs(tenantId, () -> task.accept(tenantId));
        }
    }
}
