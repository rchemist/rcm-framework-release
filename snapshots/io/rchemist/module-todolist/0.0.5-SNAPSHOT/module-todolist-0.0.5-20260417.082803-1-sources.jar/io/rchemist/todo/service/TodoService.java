/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.todo.dao.TodoRepository;
import io.rchemist.todo.data.TodoCreateForm;
import io.rchemist.todo.data.TodoUpdateForm;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.domain.Todo;
import io.rchemist.todo.service.exception.TodoServiceErrorType;
import io.rchemist.todo.service.exception.TodoServiceException;
import io.rchemist.todo.service.extension.TodoServiceExtensionManager;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.Instant;
import java.util.List;
import javax.cache.Cache;
import lombok.Getter;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Service;



/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 * Created by kunner
 **/
@Service("rcmTodoService")
public class TodoService implements ResponseEntityListService<Todo, TodoView, TodoCreateForm, TodoUpdateForm, SearchForm, Long, TodoServiceException> {

  @Getter
  protected final Cache<String, TodoView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  protected final TodoRepository repository;
  
  protected final TodoServiceExtensionManager extensionManager;

  public TodoService(TodoRepository repository, CommonCacheManager cacheManager, TodoServiceExtensionManager extensionManager) {
    this.repository = repository;
    this.entityCache = cacheManager.getOrCreateCache("Todo_entity_cache", 60 * 60 * 24, 1000, TodoView.class);
    this.searchResultCache = cacheManager.getOrCreateCache("Todo_search_list_cache", 60 * 60, 100, ResponseListWrapperCache.class);
    this.extensionManager = extensionManager;
  }

  @Override
  public CommonSearchRepository<Todo, Long> getRepository() {
    return repository;
  }

  @Override
  public TodoServiceException entityNotFoundException() {
    return new TodoServiceException(TodoServiceErrorType.NOT_FOUND);
  }

  @Override
  public Todo createEntity(TodoCreateForm createForm) throws TodoServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<TodoCreateForm> resultHolder = new ExtensionResultHolder<TodoCreateForm>().withResult(createForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preCreate(resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        createForm = resultHolder.getResult();
      }
    
      Todo entity = Todo.create(createForm);
      
      ExtensionResultHolder<Todo> postResultHolder = new ExtensionResultHolder<Todo>().withResult(entity);
      status = extensionManager.getProxy().postCreate(createForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
      
    } catch (Exception e) {
      throw new TodoServiceException(e);
    }
  }

  @Override
  public Todo updateEntity(Todo entity, TodoUpdateForm updateForm) throws TodoServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<TodoUpdateForm> resultHolder = new ExtensionResultHolder<TodoUpdateForm>().withResult(updateForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preUpdate(entity, resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        updateForm = resultHolder.getResult();
      }
    
      entity = entity.update(updateForm);
      
      ExtensionResultHolder<Todo> postResultHolder = new ExtensionResultHolder<Todo>().withResult(entity);
      status = extensionManager.getProxy().postUpdate(updateForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
    } catch (Exception e) {
      throw new TodoServiceException(e);
    }
  }

  @Override
  public TodoView getView(Todo entity, EntityViewType viewType) {
    TodoView view = entity.view(viewType);
    
    ExtensionResultHolder<TodoView> resultHolder = new ExtensionResultHolder<TodoView>().withResult(view);
    ExtensionResultStatusType status = extensionManager.getProxy().postView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return view;
  }

  @Override
  public SearchContext<Todo, SearchForm> getSearchContext(SearchForm searchForm) {
    SearchContext<Todo, SearchForm> context = new CommonSearchContext<>(Todo.class, searchForm);
    
    ExtensionResultHolder<SearchContext<Todo, SearchForm>> resultHolder = new ExtensionResultHolder<SearchContext<Todo, SearchForm>>().withResult(context);
    ExtensionResultStatusType status = extensionManager.getProxy().overrideSearchContext(searchForm, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return context;
  }
  
  public List<Todo> findAllById(List<Long> ids) {
    return repository.findAllById(ids);
  }



  public List<Todo> findByAvailableAtAndAvailableUntil(Instant availableAt, Instant availableUntil){
    return repository.findByAvailableAtAndAvailableUntil(availableAt, availableUntil);
  }

  public List<Todo> findByAvailableAtGreaterThanEqual(Instant availableAt){
    return repository.findByAvailableAtGreaterThanEqual(availableAt);
  }

  public List<Todo> findByAvailableAtLessThanEqual(Instant availableAt){
    return repository.findByAvailableAtLessThanEqual(availableAt);
  }

  public List<Todo> findByAvailableAtBetween(Instant availableAtFrom, Instant availableAtTo){
    return repository.findByAvailableAtBetween(availableAtFrom, availableAtTo);
  }

  public List<Todo> findByAvailableUntilGreaterThanEqual(Instant availableUntil){
    return repository.findByAvailableUntilGreaterThanEqual(availableUntil);
  }

  public List<Todo> findByAvailableUntilLessThanEqual(Instant availableUntil){
    return repository.findByAvailableUntilLessThanEqual(availableUntil);
  }

  public List<Todo> findByTitleLike(String title){
    return repository.findByTitleLike(title);
  }

  public List<Todo> findByContentLike(String content){
    return repository.findByContentLike(content);
  }

  public List<Todo> findByCreatedAtGreaterThanEqual(Instant createdAt){
    return repository.findByCreatedAtGreaterThanEqual(createdAt);
  }

  public List<Todo> findByCreatedAtLessThanEqual(Instant createdAt){
    return repository.findByCreatedAtLessThanEqual(createdAt);
  }

  public List<Todo> findByCreatedAtBetween(Instant createdAtFrom, Instant createdAtTo){
    return repository.findByCreatedAtBetween(createdAtFrom, createdAtTo);
  }

  public List<Todo> findByUpdatedAtGreaterThanEqual(Instant updatedAt){
    return repository.findByUpdatedAtGreaterThanEqual(updatedAt);
  }

  public List<Todo> findByUpdatedAtLessThanEqual(Instant updatedAt){
    return repository.findByUpdatedAtLessThanEqual(updatedAt);
  }

  public List<Todo> findByUpdatedAtBetween(Instant updatedAtFrom, Instant updatedAtTo){
    return repository.findByUpdatedAtBetween(updatedAtFrom, updatedAtTo);
  }

  public List<Todo> findByActive(Boolean active){
    return repository.findByActive(active);
  }

  public List<Todo> findByUserId(String userId){
    return repository.findByUserId(userId);
  }

  public List<Todo> findByUserIdIn(List<String> userIds){
    return repository.findByUserIdIn(userIds);
  }

  public List<Todo> findByUserName(String userName){
    return repository.findByUserName(userName);
  }

  public List<Todo> findByUserNameLike(String userName){
    return repository.findByUserNameLike(userName);
  }

  public List<Todo> findByDone(Boolean done){
    return repository.findByDone(done);
  }

  public List<Todo> findByDoneNotEquals(Boolean done){
    return repository.findByDoneNot(done);
  }

  public List<Todo> findByImportant(Boolean important){
    return repository.findByImportant(important);
  }

  public List<Todo> findByImportantNotEquals(Boolean important){
    return repository.findByImportantNot(important);
  }

  public Boolean processDone(Long id) throws TodoServiceException{

    Todo entity = repository.findById(id).orElseThrow(this::entityNotFoundException);
    entity.setDone(true);
    repository.save(entity);
    return true;

  }

  public Boolean processActive(Long id, Boolean active) throws TodoServiceException {
    Todo entity = repository.findById(id).orElseThrow(this::entityNotFoundException);
    entity.setActive(BooleanUtils.toBoolean(active));
    repository.save(entity);
    return true;
  }
}
