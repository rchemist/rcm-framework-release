/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

import io.rchemist.todo.service.type.TodoState;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * <p>Minimal default state machine — only permits {@code OPEN -> DONE}. Staying in the same
 * state is always allowed (idempotent no-op transition). Any transition that leaves a
 * terminal state is rejected.
 *
 * <p>Consumers wanting richer workflows register their own {@link TodoStateMachine} bean in
 * Spring (the framework auto-wires by type; any Consumer bean replaces this default).
 */
public class DefaultTodoStateMachine implements TodoStateMachine {

  @Override
  public TodoState initialState() {
    return TodoState.OPEN;
  }

  @Override
  public boolean isTerminal(TodoState state) {
    return TodoState.DONE.equals(state);
  }

  @Override
  public boolean canTransition(TodoState from, TodoState to) {
    if (to == null) {
      return false;
    }
    if (from == null) {
      // Transitioning from uninitialized. Allow any non-null target the machine knows.
      return allStates().contains(to);
    }
    if (from.equals(to)) {
      // Idempotent no-op is always permitted so callers can naively set the same state.
      return true;
    }
    if (isTerminal(from)) {
      // Terminal -> anything else is rejected.
      return false;
    }
    // Non-terminal transitions: only OPEN -> DONE.
    return TodoState.OPEN.equals(from) && TodoState.DONE.equals(to);
  }

  @Override
  public Set<TodoState> allStates() {
    return Collections.unmodifiableSet(
        Stream.of(TodoState.OPEN, TodoState.DONE).collect(LinkedHashSet::new, Set::add, Set::addAll));
  }
}
