/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.todo.domain.Todo;
import java.time.Instant;
import java.util.List;




/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 * Created by kunner
 **/
public interface TodoRepository extends CommonSearchRepository<Todo, Long> {



  public List<Todo> findByAvailableAtAndAvailableUntil(Instant availableAt, Instant availableUntil);

  List<Todo> findByAvailableAtGreaterThanEqual(Instant availableAt);

  List<Todo> findByAvailableAtLessThanEqual(Instant availableAt);

  List<Todo> findByAvailableAtBetween(Instant availableAtFrom, Instant availableAtTo);

  List<Todo> findByAvailableUntilGreaterThanEqual(Instant availableUntil);

  List<Todo> findByAvailableUntilLessThanEqual(Instant availableUntil);

  List<Todo> findByTitleLike(String title);

  List<Todo> findByContentLike(String content);

  List<Todo> findByCreatedAtGreaterThanEqual(Instant createdAt);

  List<Todo> findByCreatedAtLessThanEqual(Instant createdAt);

  List<Todo> findByCreatedAtBetween(Instant createdAtFrom, Instant createdAtTo);

  List<Todo> findByUpdatedAtGreaterThanEqual(Instant updatedAt);

  List<Todo> findByUpdatedAtLessThanEqual(Instant updatedAt);

  List<Todo> findByUpdatedAtBetween(Instant updatedAtFrom, Instant updatedAtTo);

  List<Todo> findByActive(Boolean active);

  List<Todo> findByUserId(String userId);

  List<Todo> findByUserIdIn(List<String> userIds);

  List<Todo> findByUserName(String userName);

  List<Todo> findByUserNameLike(String userName);

  List<Todo> findByDone(Boolean done);

  List<Todo> findByDoneNot(Boolean done);

  List<Todo> findByImportant(Boolean important);

  List<Todo> findByImportantNot(Boolean important);




}
  
