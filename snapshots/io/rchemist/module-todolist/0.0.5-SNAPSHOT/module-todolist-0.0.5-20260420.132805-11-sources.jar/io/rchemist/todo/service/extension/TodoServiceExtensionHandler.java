/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.extension;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.todo.data.TodoCreateForm;
import io.rchemist.todo.data.TodoUpdateForm;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.domain.Todo;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 * Created by kunner
 **/
public interface TodoServiceExtensionHandler extends ExtensionHandler {

    /**
    * Entity 를 새로 생성하기 전 CreateForm 을 Validation 하거나 CreateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preCreate(ExtensionResultHolder<TodoCreateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 새로 생성한 직후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postCreate(TodoCreateForm createForm, ExtensionResultHolder<Todo> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 Update 하기 전 UpdateForm 을 Validation 하거나 UpdateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preUpdate(Todo entity, ExtensionResultHolder<TodoUpdateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 수정한 후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postUpdate(TodoUpdateForm updateForm, ExtensionResultHolder<Todo> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 View 로 변환할 때 확장 로직
    * @return
    */
    default ExtensionResultStatusType postView(Todo entity, EntityViewType entityViewType, ExtensionResultHolder<TodoView> resultHolder) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 의 목록을 조회할 때 SearchContext 를 확장하는 로직
    * @return
    */
    default ExtensionResultStatusType overrideSearchContext(SearchForm searchForm, ExtensionResultHolder<SearchContext<Todo, SearchForm>> resultHolder) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }

}
