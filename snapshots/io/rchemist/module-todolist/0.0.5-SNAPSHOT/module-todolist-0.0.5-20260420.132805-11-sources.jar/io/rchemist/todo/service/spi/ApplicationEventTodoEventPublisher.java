/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

import io.rchemist.todo.service.event.TodoLifecycleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;

/**
 * <p>Default {@link TodoEventPublisher} that forwards each event to Spring's
 * {@link ApplicationEventPublisher}. Consumers subscribe via {@code @EventListener} on the
 * {@code TodoLifecycleEvent} type.
 *
 * <p>Null-safe: if no publisher is injected (e.g. in a non-Spring unit test), the call is a
 * no-op instead of an NPE. Exceptions from downstream subscribers are logged and swallowed so
 * a broken listener never fails todo CRUD.
 */
public class ApplicationEventTodoEventPublisher implements TodoEventPublisher {

  private static final Logger LOG = LoggerFactory.getLogger(ApplicationEventTodoEventPublisher.class);

  private final ApplicationEventPublisher delegate;

  public ApplicationEventTodoEventPublisher(ApplicationEventPublisher delegate) {
    this.delegate = delegate;
  }

  @Override
  public void publish(TodoLifecycleEvent event) {
    if (event == null || delegate == null) {
      return;
    }
    try {
      delegate.publishEvent(event);
    } catch (Exception ex) {
      LOG.warn("TodoLifecycleEvent publish failed; swallowing so CRUD survives. type={} todoId={} ({})",
          event.getType(), event.getTodoId(), ex.toString());
      LOG.debug("publish stack trace", ex);
    }
  }
}
