/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.domain;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.template.DeepCopy;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.AvailableDatetime;
import io.rchemist.common.persistence.jpa.domain.template.Contents;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.persistence.jpa.domain.template.TagsMapping;
import io.rchemist.common.persistence.jpa.domain.template.UUIDUserMapping;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.todo.data.TodoCreateForm;
import io.rchemist.todo.data.TodoUpdateForm;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.service.type.TodoPriorityType;
import io.rchemist.todo.service.type.TodoState;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * </p>
 * Created by kunner
 **/

@Entity
@Table(name = "T_TODO")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "ENTITY_TODO")
@Getter
@Setter
public class Todo implements AvailableDatetime<Todo>, Contents<Todo>, EssentialEntity<Todo>, SoftDelete<Todo>, TagsMapping<Todo>, UUIDUserMapping<Todo>, DeepCopy<Todo> {

  @Serial
  private static final long serialVersionUID = 1L;

  @Id
  @IdGenerator
  protected Long id;


  @IndexField
  @Column(name = "TODO_DONE")
  protected Boolean done;

  @IndexField
  @Column(name = "TODO_IMPORTANT")
  protected Boolean important;

  @Column(name = "TODO_PRIORITY")
  protected TodoPriorityType priority;

  /**
   * Generic state — populated alongside {@link #done} for backward compatibility.
   * When a Consumer plugs in a custom {@code TodoStateMachine}, this field carries the
   * domain-specific state; {@link #done} then reflects whatever the machine considers
   * terminal-and-equivalent-to-DONE.
   *
   * <p>Stored as the {@code TodoState} type name (String) so Consumer-defined state
   * constants round-trip through persistence.
   */
  @Column(name = "TODO_STATE", length = 64)
  protected String state;


  public Todo withDone(Boolean done) {
    this.done = done;
    return this;
  }

  public Todo withImportant(Boolean important) {
    this.important = important;
    return this;
  }

  public Todo withPriority(TodoPriorityType priority) {
    this.priority = priority;
    return this;
  }

  public Todo withState(TodoState state) {
    this.state = state != null ? state.getType() : null;
    return this;
  }

  /**
   * Convenience accessor returning the state as a {@link TodoState} instance (or {@code null}
   * if unset). Uses {@code EnumType.getInstance} so Consumer-defined subclasses resolve
   * correctly.
   */
  public TodoState getStateType() {
    return state == null ? null : TodoState.getInstance(TodoState.class, state);
  }

  public Todo setStateType(TodoState s) {
    this.state = s != null ? s.getType() : null;
    return this;
  }



  // TODO 필요한 필드가 있다면 추가하세요.

  /**
   * Form을 이용해 Todo 엔티티를 생성한다. 이 결과로 실제 DB에 저장된 것은 아니며 Entity Object 가 생성된 상태.
   * @param form 업데이트 폼
   * @return 생성된 Todo 엔티티
   */
  public static Todo create(TodoCreateForm form) throws ErrorTypeException {
    form.validate();

    Todo entity = new Todo();
        entity.setAvailableAt(form.getAvailableAt());
        entity.setAvailableUntil(form.getAvailableUntil());
        entity.setTitle(form.getTitle());
        entity.setContent(form.getContent());
        entity.setTags(form.getTags());
        entity.setUserId(form.getUserId());
        entity.setUserName(form.getUserName());
        entity.setDone(form.getDone());
        entity.setImportant(form.getImportant());
        entity.setPriority(EnumTypeUtil.getEnumType(TodoPriorityType.class, form.getPriority()));
        entity.setState(form.getState());
    return entity;
  }

  /**
   * Form을 이용해 Todo 엔티티를 업데이트한다.
   * @param form 업데이트 폼
   * @return 업데이트된 Todo 엔티티
   */
  public Todo update(TodoUpdateForm form) throws ErrorTypeException {
    form.validate();
      if (form.isUpdateTargetField("availableAt")){
        this.setAvailableAt(form.getAvailableAt());
    }
      if (form.isUpdateTargetField("availableUntil")){
        this.setAvailableUntil(form.getAvailableUntil());
    }
      if (form.isUpdateTargetField("title")){
        this.setTitle(form.getTitle());
    }
      if (form.isUpdateTargetField("content")){
        this.setContent(form.getContent());
    }
      if (form.isUpdateTargetField("tags")){
        this.setTags(form.getTags());
    }
      if (form.isUpdateTargetField("userId")){
        this.setUserId(form.getUserId());
    }
      if (form.isUpdateTargetField("userName")){
        this.setUserName(form.getUserName());
    }
      if (form.isUpdateTargetField("done")){
        this.setDone(form.getDone());
    }
      if (form.isUpdateTargetField("important")){
        this.setImportant(form.getImportant());
    }
      if (form.isUpdateTargetField("priority")){
        this.setPriority(EnumTypeUtil.getEnumType(TodoPriorityType.class, form.getPriority()));
    }
      if (form.isUpdateTargetField("state")){
        this.setState(form.getState());
    }
    return this;
  }

  /**
   * Todo 엔티티를 조회용 DTO로 변환한다.
   * @return Todo의 조회용 DTO
   */
  public TodoView view(EntityViewType viewType) {
    TodoView view = new TodoView();
    view.setId(this.getId());
    
    view.setAvailableAt(this.getAvailableAt());
    view.setAvailableUntil(this.getAvailableUntil());
    view.setTitle(this.getTitle());
    view.setContent(this.getContent());
    view.setCreatedAt(this.getCreatedAt());
    view.setUpdatedAt(this.getUpdatedAt());
    view.setActive(this.getActive());
    view.setTags(this.getTags());
    view.setUserId(this.getUserId());
    view.setUserName(this.getUserName());
    view.setDone(this.getDone());
    view.setImportant(this.getImportant());
    view.setPriority(getPriority());
    view.setState(this.getState());


    return view;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    Todo that = (Todo) o;
  
    return new EqualsBuilder()
      .append(getId(), that.getId())
      .append(getAvailableAt(), that.getAvailableAt())
      .append(getAvailableUntil(), that.getAvailableUntil())
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getUpdatedBy(), that.getUpdatedBy())
      .append(getUpdatedAt(), that.getUpdatedAt())
      .append(getActive(), that.getActive())
      .append(getTags(), that.getTags())
      .append(getUserId(), that.getUserId())
      .append(getUserName(), that.getUserName())
      .append(getDone(), that.getDone())
      .append(getImportant(), that.getImportant())
      .append(getPriority(), that.getPriority())
      .append(getState(), that.getState())
      .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getAvailableAt())
      .append(getAvailableUntil())
      .append(getTitle())
      .append(getContent())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getUpdatedBy())
      .append(getUpdatedAt())
      .append(getActive())
      .append(getTags())
      .append(getUserId())
      .append(getUserName())
      .append(getDone())
      .append(getImportant())
      .append(getPriority())
      .append(getState())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("availableAt", getAvailableAt())
      .append("availableUntil", getAvailableUntil())
      .append("title", getTitle())
      .append("content", getContent())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("updatedBy", getUpdatedBy())
      .append("updatedAt", getUpdatedAt())
      .append("active", getActive())
      .append("tags", getTags())
      .append("userId", getUserId())
      .append("userName", getUserName())
      .append("done", getDone())
      .append("important", getImportant())
      .append("priority", getPriority())
      .append("state", getState())
      .toString();
  }

  @Override
  public Todo deepCopy(boolean includeId, boolean includeSubEntities) {
    Todo clone = new Todo();
    clone.setId(includeId ? this.getId() : null);
    clone.setAvailableAt(getAvailableAt());
    clone.setAvailableUntil(getAvailableUntil());
    clone.setTitle(getTitle());
    clone.setContent(getContent());
    clone.setCreatedBy(getCreatedBy());
    clone.setCreatedAt(getCreatedAt());
    clone.setUpdatedBy(getUpdatedBy());
    clone.setUpdatedAt(getUpdatedAt());
    clone.setActive(getActive());
    clone.setTags(getTags());
    clone.setUserId(getUserId());
    clone.setUserName(getUserName());
    clone.setDone(getDone());
    clone.setImportant(getImportant());
    clone.setPriority(getPriority());
    clone.setState(getState());
    return clone;
  }
}