/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.configuration;

import io.rchemist.todo.service.spi.ApplicationEventTodoEventPublisher;
import io.rchemist.todo.service.spi.AssigneeResolver;
import io.rchemist.todo.service.spi.DefaultAssigneeResolver;
import io.rchemist.todo.service.spi.DefaultTodoStateMachine;
import io.rchemist.todo.service.spi.NoOpTodoEventPublisher;
import io.rchemist.todo.service.spi.TodoEventPublisher;
import io.rchemist.todo.service.spi.TodoStateMachine;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>Auto-wires the generic module-todolist SPIs. Each bean is registered with
 * {@link ConditionalOnMissingBean} so any Consumer-registered bean of the same type
 * transparently replaces the default.
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
@Configuration
@EnableConfigurationProperties(TodoListProperties.class)
public class TodoListConfiguration {

  @Bean
  @ConditionalOnMissingBean(TodoStateMachine.class)
  public TodoStateMachine defaultTodoStateMachine() {
    return new DefaultTodoStateMachine();
  }

  @Bean
  @ConditionalOnMissingBean(AssigneeResolver.class)
  public AssigneeResolver defaultAssigneeResolver() {
    return new DefaultAssigneeResolver();
  }

  @Bean
  @ConditionalOnMissingBean(TodoEventPublisher.class)
  public TodoEventPublisher defaultTodoEventPublisher(TodoListProperties properties,
                                                      ObjectProvider<ApplicationEventPublisher> publisherProvider) {
    if (!properties.getEvents().isEnabled()) {
      return new NoOpTodoEventPublisher();
    }
    ApplicationEventPublisher publisher = publisherProvider.getIfAvailable();
    return new ApplicationEventTodoEventPublisher(publisher);
  }
}
