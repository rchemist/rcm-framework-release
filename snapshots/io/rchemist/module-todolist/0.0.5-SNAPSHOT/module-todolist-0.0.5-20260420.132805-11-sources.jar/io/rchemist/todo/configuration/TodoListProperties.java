/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>Configuration properties controlling the module-todolist generic SPI.
 *
 * <p>All properties are optional and have sensible defaults so existing deployments do not
 * need to touch their {@code application.yml} when upgrading to 0.1.0.
 *
 * <p>Recognized keys (prefix {@code platform.todolist}):
 * <ul>
 *   <li>{@code state-machine.strict=false} — when {@code true}, illegal transitions throw
 *       {@code TodoServiceException(INVALID_STATE_TRANSITION)}. When {@code false} (the
 *       default), illegal transitions are logged and silently ignored so legacy callers that
 *       blindly set {@code done=true} keep working.</li>
 *   <li>{@code events.enabled=true} — when {@code false}, the framework wires in
 *       {@code NoOpTodoEventPublisher} instead of {@code ApplicationEventTodoEventPublisher},
 *       disabling all lifecycle-event publishing.</li>
 * </ul>
 *
 * <p>Created by kunner for 0.1.0 M5 generalization (DEC-017).
 */
@ConfigurationProperties(prefix = "platform.todolist")
public class TodoListProperties {

  private final StateMachine stateMachine = new StateMachine();
  private final Events events = new Events();

  public StateMachine getStateMachine() {
    return stateMachine;
  }

  public Events getEvents() {
    return events;
  }

  public static class StateMachine {
    private boolean strict = false;

    public boolean isStrict() {
      return strict;
    }

    public void setStrict(boolean strict) {
      this.strict = strict;
    }
  }

  public static class Events {
    private boolean enabled = true;

    public boolean isEnabled() {
      return enabled;
    }

    public void setEnabled(boolean enabled) {
      this.enabled = enabled;
    }
  }
}
