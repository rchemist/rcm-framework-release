/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.todo.configuration.TodoListProperties;
import io.rchemist.todo.dao.TodoRepository;
import io.rchemist.todo.data.TodoCreateForm;
import io.rchemist.todo.data.TodoUpdateForm;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.domain.Todo;
import io.rchemist.todo.service.event.TodoLifecycleEvent;
import io.rchemist.todo.service.event.TodoLifecycleEventType;
import io.rchemist.todo.service.exception.TodoServiceErrorType;
import io.rchemist.todo.service.exception.TodoServiceException;
import io.rchemist.todo.service.extension.TodoServiceExtensionManager;
import io.rchemist.todo.service.spi.AssigneeResolver;
import io.rchemist.todo.service.spi.TodoEventPublisher;
import io.rchemist.todo.service.spi.TodoStateMachine;
import io.rchemist.todo.service.type.TodoState;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.Instant;
import java.util.List;
import javax.cache.Cache;
import lombok.Getter;
import org.apache.commons.lang3.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;



/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 * Created by kunner
 **/
@Service("rcmTodoService")
public class TodoService implements ResponseEntityListService<Todo, TodoView, TodoCreateForm, TodoUpdateForm, SearchForm, Long, TodoServiceException> {

  private static final Logger LOG = LoggerFactory.getLogger(TodoService.class);

  @Getter
  protected final Cache<String, TodoView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  protected final TodoRepository repository;

  protected final TodoServiceExtensionManager extensionManager;

  protected final TodoStateMachine stateMachine;

  protected final AssigneeResolver assigneeResolver;

  protected final TodoEventPublisher eventPublisher;

  protected final TodoListProperties properties;

  public TodoService(TodoRepository repository,
                     CommonCacheManager cacheManager,
                     TodoServiceExtensionManager extensionManager,
                     TodoStateMachine stateMachine,
                     AssigneeResolver assigneeResolver,
                     TodoEventPublisher eventPublisher,
                     TodoListProperties properties) {
    this.repository = repository;
    this.entityCache = cacheManager.getOrCreateCache("Todo_entity_cache", 60 * 60 * 24, 1000, TodoView.class);
    this.searchResultCache = cacheManager.getOrCreateCache("Todo_search_list_cache", 60 * 60, 100, ResponseListWrapperCache.class);
    this.extensionManager = extensionManager;
    this.stateMachine = stateMachine;
    this.assigneeResolver = assigneeResolver;
    this.eventPublisher = eventPublisher;
    this.properties = properties;
  }

  @Override
  public CommonSearchRepository<Todo, Long> getRepository() {
    return repository;
  }

  @Override
  public TodoServiceException entityNotFoundException() {
    return new TodoServiceException(TodoServiceErrorType.NOT_FOUND);
  }

  @Override
  public Todo createEntity(TodoCreateForm createForm) throws TodoServiceException {
    // do override if needed
    try {

      ExtensionResultHolder<TodoCreateForm> resultHolder = new ExtensionResultHolder<TodoCreateForm>().withResult(createForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preCreate(resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        createForm = resultHolder.getResult();
      }

      // SPI: resolve assignee before entity construction
      AssigneeResolver.Assignee resolved = assigneeResolver.resolve(createForm.getUserId(), createForm.getUserName());
      createForm.setUserId(resolved.getUserId());
      createForm.setUserName(resolved.getUserName());

      // SPI: apply state machine's initial state when form omits it
      if (createForm.getState() == null) {
        TodoState initial = stateMachine.initialState();
        createForm.setState(initial != null ? initial.getType() : null);
      }

      Todo entity = Todo.create(createForm);
      syncDoneFromState(entity);

      ExtensionResultHolder<Todo> postResultHolder = new ExtensionResultHolder<Todo>().withResult(entity);
      status = extensionManager.getProxy().postCreate(createForm, postResultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }

      eventPublisher.publish(new TodoLifecycleEvent(
          TodoLifecycleEventType.CREATED,
          entity.getId(),
          entity.getUserId(),
          null,
          entity.getStateType(),
          Instant.now()));

      return entity;

    } catch (Exception e) {
      throw new TodoServiceException(e);
    }
  }

  @Override
  public Todo updateEntity(Todo entity, TodoUpdateForm updateForm) throws TodoServiceException {
    // do override if needed
    try {

      ExtensionResultHolder<TodoUpdateForm> resultHolder = new ExtensionResultHolder<TodoUpdateForm>().withResult(updateForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preUpdate(entity, resultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        updateForm = resultHolder.getResult();
      }

      // SPI: if the update targets userId / userName, run the resolver over the requested values
      if (updateForm.isUpdateTargetField("userId") || updateForm.isUpdateTargetField("userName")) {
        AssigneeResolver.Assignee resolved = assigneeResolver.resolve(updateForm.getUserId(), updateForm.getUserName());
        updateForm.setUserId(resolved.getUserId());
        updateForm.setUserName(resolved.getUserName());
      }

      // SPI: state transition guard if the update targets state
      TodoState previous = entity.getStateType();
      if (updateForm.isUpdateTargetField("state")) {
        TodoState target = updateForm.getState() == null ? null : TodoState.getInstance(TodoState.class, updateForm.getState());
        enforceTransition(previous, target);
      }

      entity = entity.update(updateForm);
      syncDoneFromState(entity);

      ExtensionResultHolder<Todo> postResultHolder = new ExtensionResultHolder<Todo>().withResult(entity);
      status = extensionManager.getProxy().postUpdate(updateForm, postResultHolder);

      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }

      TodoState current = entity.getStateType();
      TodoLifecycleEventType type = (previous == null ? current != null : !previous.equals(current))
          ? TodoLifecycleEventType.STATE_CHANGED
          : TodoLifecycleEventType.UPDATED;
      eventPublisher.publish(new TodoLifecycleEvent(
          type, entity.getId(), entity.getUserId(), previous, current, Instant.now()));

      return entity;
    } catch (Exception e) {
      throw new TodoServiceException(e);
    }
  }

  @Override
  public TodoView getView(Todo entity, EntityViewType viewType) {
    TodoView view = entity.view(viewType);
    
    ExtensionResultHolder<TodoView> resultHolder = new ExtensionResultHolder<TodoView>().withResult(view);
    ExtensionResultStatusType status = extensionManager.getProxy().postView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return view;
  }

  @Override
  public SearchContext<Todo, SearchForm> getSearchContext(SearchForm searchForm) {
    SearchContext<Todo, SearchForm> context = new CommonSearchContext<>(Todo.class, searchForm);
    
    ExtensionResultHolder<SearchContext<Todo, SearchForm>> resultHolder = new ExtensionResultHolder<SearchContext<Todo, SearchForm>>().withResult(context);
    ExtensionResultStatusType status = extensionManager.getProxy().overrideSearchContext(searchForm, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return context;
  }
  
  public List<Todo> findAllById(List<Long> ids) {
    return repository.findAllById(ids);
  }



  public List<Todo> findByAvailableAtAndAvailableUntil(Instant availableAt, Instant availableUntil){
    return repository.findByAvailableAtAndAvailableUntil(availableAt, availableUntil);
  }

  public List<Todo> findByAvailableAtGreaterThanEqual(Instant availableAt){
    return repository.findByAvailableAtGreaterThanEqual(availableAt);
  }

  public List<Todo> findByAvailableAtLessThanEqual(Instant availableAt){
    return repository.findByAvailableAtLessThanEqual(availableAt);
  }

  public List<Todo> findByAvailableAtBetween(Instant availableAtFrom, Instant availableAtTo){
    return repository.findByAvailableAtBetween(availableAtFrom, availableAtTo);
  }

  public List<Todo> findByAvailableUntilGreaterThanEqual(Instant availableUntil){
    return repository.findByAvailableUntilGreaterThanEqual(availableUntil);
  }

  public List<Todo> findByAvailableUntilLessThanEqual(Instant availableUntil){
    return repository.findByAvailableUntilLessThanEqual(availableUntil);
  }

  public List<Todo> findByTitleLike(String title){
    return repository.findByTitleLike(title);
  }

  public List<Todo> findByContentLike(String content){
    return repository.findByContentLike(content);
  }

  public List<Todo> findByCreatedAtGreaterThanEqual(Instant createdAt){
    return repository.findByCreatedAtGreaterThanEqual(createdAt);
  }

  public List<Todo> findByCreatedAtLessThanEqual(Instant createdAt){
    return repository.findByCreatedAtLessThanEqual(createdAt);
  }

  public List<Todo> findByCreatedAtBetween(Instant createdAtFrom, Instant createdAtTo){
    return repository.findByCreatedAtBetween(createdAtFrom, createdAtTo);
  }

  public List<Todo> findByUpdatedAtGreaterThanEqual(Instant updatedAt){
    return repository.findByUpdatedAtGreaterThanEqual(updatedAt);
  }

  public List<Todo> findByUpdatedAtLessThanEqual(Instant updatedAt){
    return repository.findByUpdatedAtLessThanEqual(updatedAt);
  }

  public List<Todo> findByUpdatedAtBetween(Instant updatedAtFrom, Instant updatedAtTo){
    return repository.findByUpdatedAtBetween(updatedAtFrom, updatedAtTo);
  }

  public List<Todo> findByActive(Boolean active){
    return repository.findByActive(active);
  }

  public List<Todo> findByUserId(String userId){
    return repository.findByUserId(userId);
  }

  public List<Todo> findByUserIdIn(List<String> userIds){
    return repository.findByUserIdIn(userIds);
  }

  public List<Todo> findByUserName(String userName){
    return repository.findByUserName(userName);
  }

  public List<Todo> findByUserNameLike(String userName){
    return repository.findByUserNameLike(userName);
  }

  public List<Todo> findByDone(Boolean done){
    return repository.findByDone(done);
  }

  public List<Todo> findByDoneNotEquals(Boolean done){
    return repository.findByDoneNot(done);
  }

  public List<Todo> findByImportant(Boolean important){
    return repository.findByImportant(important);
  }

  public List<Todo> findByImportantNotEquals(Boolean important){
    return repository.findByImportantNot(important);
  }

  public Boolean processDone(Long id) throws TodoServiceException{
    return transitionTo(id, TodoState.DONE);
  }

  /**
   * Transition the given todo to the target state, enforcing the {@link TodoStateMachine}
   * guard. Publishes a {@code STATE_CHANGED} lifecycle event on success.
   *
   * <p>When {@code platform.todolist.state-machine.strict=false} (the default), illegal
   * transitions are logged and the entity is left untouched, returning {@code false}. When
   * {@code strict=true}, the same situation throws
   * {@code TodoServiceException(INVALID_STATE_TRANSITION)}.
   */
  public Boolean transitionTo(Long id, TodoState target) throws TodoServiceException {
    Todo entity = repository.findById(id).orElseThrow(this::entityNotFoundException);
    TodoState previous = entity.getStateType();

    if (!stateMachine.canTransition(previous, target)) {
      if (properties.getStateMachine().isStrict()) {
        throw new TodoServiceException(TodoServiceErrorType.INVALID_STATE_TRANSITION);
      }
      LOG.debug("Illegal todo state transition ignored (strict=false). id={} from={} to={}",
          id, previous, target);
      return false;
    }

    if (target != null && target.equals(previous)) {
      // Idempotent no-op.
      return true;
    }

    entity.setStateType(target);
    syncDoneFromState(entity);
    repository.save(entity);

    eventPublisher.publish(new TodoLifecycleEvent(
        TodoLifecycleEventType.STATE_CHANGED,
        entity.getId(),
        entity.getUserId(),
        previous,
        target,
        Instant.now()));

    return true;
  }

  public Boolean processActive(Long id, Boolean active) throws TodoServiceException {
    Todo entity = repository.findById(id).orElseThrow(this::entityNotFoundException);
    entity.setActive(BooleanUtils.toBoolean(active));
    repository.save(entity);
    return true;
  }

  /**
   * Keep the legacy {@code done} boolean in sync with the generic {@code state} field.
   * {@code done == true} iff the current state is terminal per the state machine's
   * {@link TodoStateMachine#isTerminal(TodoState)}.
   *
   * <p>This maintains backward compatibility: existing callers that inspect {@code done}
   * continue to work regardless of how Consumer-defined state machines model completion.
   */
  protected void syncDoneFromState(Todo entity) {
    TodoState current = entity.getStateType();
    if (current == null) {
      // Leave done untouched when state is unspecified (legacy rows without state).
      return;
    }
    entity.setDone(stateMachine.isTerminal(current));
  }

  /**
   * Guard used by {@link #updateEntity(Todo, TodoUpdateForm)} when the update form targets
   * the {@code state} field. Honors {@code platform.todolist.state-machine.strict}.
   */
  protected void enforceTransition(TodoState from, TodoState to) throws TodoServiceException {
    if (stateMachine.canTransition(from, to)) {
      return;
    }
    if (properties.getStateMachine().isStrict()) {
      throw new TodoServiceException(TodoServiceErrorType.INVALID_STATE_TRANSITION);
    }
    LOG.debug("Illegal todo state transition tolerated (strict=false). from={} to={}", from, to);
  }
}
