/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.controller;

import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityController;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.todo.data.TodoCreateForm;
import io.rchemist.todo.data.TodoUpdateForm;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.domain.Todo;
import io.rchemist.todo.service.TodoService;
import lombok.Getter;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 *   이 모듈을 사용하려면 AbstractTodoController 를 extends 해 TodoController 를 만들어야 합니다.
 *
 *   예시)
 *
 *   @RestController(value = "rcmTodoController")
 * @RestDocument(project = "rcm", value = "TodoController")
 * @RequestMapping(TodoController.API_URL)
 * public class TodoController extends AbstractTodoController {
 *   public static final String API_URL = "/api/v1/todo";
 *
 *   public TodoController(TodoService service) {
 *     super(service);
 *   }
 * }
 *
 * </p>
 **/
public abstract class AbstractTodoController extends ResponseEntityController<Todo, TodoView, TodoCreateForm, TodoUpdateForm, SearchForm, Long> {

  @Getter
  protected final TodoService service;

  public AbstractTodoController(TodoService service) {
    this.service = service;
  }

  @Override
  @PostMapping
  public ResponseListData<TodoView, SearchForm> search(@RequestBody SearchForm searchForm) {
    return super.search(searchForm);
  }

  @Override
  @PostMapping("/add")
  public ResponseData<TodoView> create(@RequestBody TodoCreateForm form) {
    return super.create(form);
  }

  @PutMapping("/{id}")
  public ResponseData<TodoView> update(@PathVariable Long id, @RequestBody TodoUpdateForm form) {
    form.setId(id);
    return super.update(form);
  }

  @PostMapping("/{id}/done")
  public ResponseData<Boolean> processDone(@PathVariable Long id) {
    return ResponseHelper.result(() -> service.processDone(id));
  }


  @DeleteMapping("/{id}/active")
  public ResponseData<Boolean> processActive(@PathVariable Long id, @RequestParam(required = false, defaultValue = "false") Boolean active) {
    return ResponseHelper.result(() -> service.processActive(id, active));
  }

  @Override
  @DeleteMapping("/{id}")
  public ResponseData<Boolean> delete(@PathVariable Long id, @RequestParam(required = false) String revisionEntityName) {
    return super.delete(id, revisionEntityName);
  }

  @Override
  @GetMapping("/{id}")
  public ResponseData<TodoView> view(@PathVariable Long id) {
    return super.view(id);
  }

  @Override
  @DeleteMapping("/delete")
  public ResponseData<Integer> deleteMultiple(@RequestBody DeleteForm<Long> form) {
    return super.deleteMultiple(form);
  }

}
  