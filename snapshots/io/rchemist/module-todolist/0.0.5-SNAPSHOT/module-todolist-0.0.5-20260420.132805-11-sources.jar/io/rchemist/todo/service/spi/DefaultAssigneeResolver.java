/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.spi;

/**
 * <p>Pass-through default: simply returns whatever userId / userName was requested.
 *
 * <p>Consumers override by registering a Spring bean of {@link AssigneeResolver}; the
 * framework auto-wires the Consumer bean over this default.
 */
public class DefaultAssigneeResolver implements AssigneeResolver {

  @Override
  public Assignee resolve(String requestedUserId, String requestedUserName) {
    return Assignee.of(requestedUserId, requestedUserName);
  }
}
