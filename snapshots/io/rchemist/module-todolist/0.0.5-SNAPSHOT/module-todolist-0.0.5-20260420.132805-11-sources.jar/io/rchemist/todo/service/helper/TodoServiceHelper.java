/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.todo.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.todo.data.TodoView;
import io.rchemist.todo.domain.Todo;
import io.rchemist.todo.service.TodoService;
import io.rchemist.todo.service.exception.TodoServiceException;
import java.util.List;

/**
 * <p>
 * Project : * <p>
 *  Rcm Framework
 * </p>
 * Created by kunner
 *
 * <p>
 * Created by kunner
 **/
public class TodoServiceHelper {

  private static TodoService rcmTodoService;
  
  public static TodoService getTodoService() {
  
    if (rcmTodoService == null) {
      rcmTodoService = ApplicationContextHolder.getBean(TodoService.class);
    }
    
    return rcmTodoService;
  }
  
  public static Todo findEntityById(Long id) throws TodoServiceException {
    return getTodoService().findEntityById(id);
  }
  
  public static TodoView findViewById(Long id) throws TodoServiceException {
    return getTodoService().findViewById(id);
  }
  
  public static List<Todo> findAllById(List<Long> ids) {
    return getTodoService().findAllById(ids);
  }
  
  

}
