/**
 * <p>module-todolist — generic task-tracking infrastructure.
 *
 * <p>Since 0.1.0 M5 (DEC-017), this module provides SPI hooks so Consumers can build
 * domain-specific task / assignment / workflow-item features without forking:
 * <ul>
 *   <li>{@code TodoStateMachine} — pluggable state-transition rules. Default permits
 *       {@code OPEN -> DONE} only. Consumer registers a Spring bean of the same type to
 *       define arbitrary state graphs (with custom {@code TodoState} subclasses).</li>
 *   <li>{@code AssigneeResolver} — pluggable assignee resolution. Default is pass-through;
 *       Consumer can implement current-user / round-robin / workload-aware strategies.</li>
 *   <li>{@code TodoEventPublisher} — pluggable lifecycle event sink. Default bridges to
 *       Spring's {@code ApplicationEventPublisher} so Consumers subscribe via
 *       {@code @EventListener} on {@code TodoLifecycleEvent}. Disable entirely via
 *       {@code platform.todolist.events.enabled=false}.</li>
 * </ul>
 *
 * <p>Configuration is driven by {@code platform.todolist.*} properties (see
 * {@code TodoListProperties}).
 *
 * <p>Design decisions:
 * <ul>
 *   <li>No compile-time coupling to {@code module-notification} or {@code module-workflow}.
 *       Integrations are Consumer-side {@code @EventListener} subscriptions.</li>
 *   <li>Backward compatible: the legacy {@code done} boolean field is kept in sync with the
 *       new {@code state} field automatically.</li>
 * </ul>
 *
 * <p>Detail: {@code documents/refactor/15e-0.1.0-m5-todolist-generalization.md}.
 */
package io.rchemist.todo;
