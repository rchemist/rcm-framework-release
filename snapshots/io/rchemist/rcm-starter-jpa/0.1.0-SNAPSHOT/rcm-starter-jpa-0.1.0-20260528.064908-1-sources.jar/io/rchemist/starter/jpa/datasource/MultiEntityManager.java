/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import java.util.Set;
import java.util.function.BiConsumer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — Decision #18 의 cross-DataSource 명시 작업 SPI. Consumer 가 단일 inject
 * point 로 N 개 DataSource 영역에 접근.
 *
 * <p>예:
 * <pre>{@code
 * @Component
 * class CrossDataSourceAggregator {
 *   @Autowired MultiEntityManager multiEm;
 *   void aggregate() {
 *     long mainCount      = multiEm.on("main").count(Article.class);
 *     long reportingCount = multiEm.on("reporting").count(ArticleStats.class);
 *     multiEm.forEach((name, em) -> log.info("{} count = {}", name, em.count(Article.class)));
 *   }
 * }
 * }</pre>
 *
 * <p>baseline 영역 — single transaction per DataSource (Decision #18). cross-DB strict
 * consistency 가 필요한 시나리오는 Saga (Decision #2 Workflow Phase 7) + Outbox (Decision #8) 메커니즘
 * 활용 — 본 SPI 는 명시 cross-DataSource 작업 영역만.
 */
public interface MultiEntityManager {

  /** {@code name} DataSource 의 {@link EntityManagerExtensions} lookup — 미등록 = fail loud. */
  EntityManagerExtensions on(String name);

  /** 등록된 모든 DataSource 이름. order = 등록 순서 (primary 가 항상 첫 entry). */
  Set<String> dataSourceNames();

  /** primary DataSource 이름 — yml {@code platform.datasource.primary} (default {@code "main"}). */
  String primaryName();

  /** 모든 DataSource 순회 — Consumer 의 cross-DS aggregate 패턴. */
  void forEach(BiConsumer<String, EntityManagerExtensions> consumer);
}
