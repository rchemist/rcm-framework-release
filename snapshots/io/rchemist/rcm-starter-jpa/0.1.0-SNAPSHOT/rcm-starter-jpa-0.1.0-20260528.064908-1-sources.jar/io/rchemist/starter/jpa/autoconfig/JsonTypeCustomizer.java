/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.autoconfig;

import java.util.Map;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #1 — Hibernate 7 JSON column 자동 인식 baseline customizer.
 *
 * <p>{@code hibernate.type.json_format_mapper} 를 {@code "jackson"} 명시 적용. Hibernate 7 의
 * default = jackson auto-detect (jackson on classpath) 와 같은 결과지만, 명시값 적용로 선언적
 * baseline 보장. 사용자가 yml {@code spring.jpa.properties.hibernate.type.json_format_mapper}
 * 으로 override 가능 ({@code putIfAbsent} 적용 정합).
 *
 * <p>{@link org.hibernate.annotations.JdbcTypeCode @JdbcTypeCode(SqlTypes.JSON)} 어노테이션이
 * Records / Map / Java POJO 필드에 적용되면 Hibernate 7 가 자동 jsonb 매핑.
 **/
public class JsonTypeCustomizer implements HibernatePropertiesCustomizer {

  public static final String HIBERNATE_JSON_FORMAT_MAPPER = "hibernate.type.json_format_mapper";

  public static final String JACKSON = "jackson";

  @Override
  public void customize(Map<String, Object> hibernateProperties) {
    hibernateProperties.putIfAbsent(HIBERNATE_JSON_FORMAT_MAPPER, JACKSON);
  }
}
