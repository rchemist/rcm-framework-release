/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.time.Instant;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — async job 단일 record. id (UUID 또는 사용자 정의), type (job 종류), status,
 * progress (0~100), startedAt / completedAt, error message, retry count.
 *
 * <p>Records immutable — {@link AsyncJobTracker} 가 상태 변경 시마다 *신규 instance* 발급 (snapshot 패턴).
 **/
public record AsyncJob(
    String id,
    String type,
    AsyncJobStatus status,
    int progress,
    Instant queuedAt,
    @Nullable Instant startedAt,
    @Nullable Instant completedAt,
    @Nullable String error,
    int retryCount) {

  public AsyncJob {
    if (id == null || id.isBlank()) {
      throw new IllegalArgumentException("id is blank");
    }
    if (type == null || type.isBlank()) {
      throw new IllegalArgumentException("type is blank");
    }
    if (status == null) {
      throw new IllegalArgumentException("status is null");
    }
    if (progress < 0 || progress > 100) {
      throw new IllegalArgumentException("progress out of range [0,100]: " + progress);
    }
    if (queuedAt == null) {
      throw new IllegalArgumentException("queuedAt is null");
    }
    if (retryCount < 0) {
      throw new IllegalArgumentException("retryCount negative: " + retryCount);
    }
  }

  public static AsyncJob queued(String id, String type) {
    return new AsyncJob(id, type, AsyncJobStatus.QUEUED, 0, Instant.now(), null, null, null, 0);
  }

  public AsyncJob withStatus(AsyncJobStatus newStatus) {
    return new AsyncJob(
        id, type, newStatus, progress, queuedAt, startedAt, completedAt, error, retryCount);
  }

  public AsyncJob withProgress(int newProgress) {
    return new AsyncJob(
        id, type, status, newProgress, queuedAt, startedAt, completedAt, error, retryCount);
  }
}
