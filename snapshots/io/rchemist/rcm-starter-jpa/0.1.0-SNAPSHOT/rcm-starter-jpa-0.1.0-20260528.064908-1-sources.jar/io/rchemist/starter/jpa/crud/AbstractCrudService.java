/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.crud;

import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SearchResponse;
import io.rchemist.starter.jpa.cache.CrudCacheAdvisor;
import io.rchemist.starter.jpa.search.PlannedQuery;
import io.rchemist.starter.jpa.search.SchemaResolver;
import io.rchemist.starter.jpa.search.SearchRequestPlanner;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #10 — Decision #7 의 *얇은 base*. Consumer service 가 4 generic 으로 extends 하면
 * 5 표준 method (create / find / search / update / delete) + searchSchema 자동 동작. tenant /
 * audit / soft-delete 자동 통합 = JPA 표준 위임 (Hibernate 7 native {@code @TenantId} +
 * Spring Data Auditing + {@code @SoftDelete}) — 본 base 가 별도 영역 추가 X.
 *
 * <p>얇은 base 5 규칙 (Decision #7 적용):
 * <ol>
 *   <li>상속 깊이 1 — Consumer extends 한 줄 (3-계층 거부)</li>
 *   <li>protected hook 0 — service 차원 hook 메서드 없음. 비즈니스 override 는 Java 표준 {@code @Override}</li>
 *   <li>추상 메서드는 비즈니스만 — {@link #toEntity(Object)} (form → entity 신규 생성) +
 *       {@link #applyForm(Object, Object)} (entity 영역 update 적용) 단 2 개</li>
 *   <li>generic 4 type — entity / id / createForm / updateForm</li>
 *   <li>{@code @ConditionalOnMissingBean} 없음 — base 자체는 추상. Consumer 가 extends + {@code @Service}
 *       적용</li>
 * </ol>
 *
 * <p>Marker 자동 통합 (JPA 표준 위임 — base 가 직접 wire 하지 않음):
 * <ul>
 *   <li>{@code Auditable} — Spring Data Auditing 의 {@code @CreatedDate / @LastModifiedDate / @CreatedBy /
 *       @LastModifiedBy} 가 entity 의 {@code @EntityListeners(AuditingEntityListener.class)} 자동 적용</li>
 *   <li>{@code SoftDelete} — Hibernate 7 의 {@code @SoftDelete} 가 DELETE → UPDATE deleted=true 자동 변환
 *       + SELECT 자동 deleted=false 필터</li>
 *   <li>{@code TenantAlias} — Hibernate 7 의 {@code @TenantId} 가 tenant 별 자동 격리</li>
 *   <li>{@code Searchable} — APT 가 {@code Entity_Metadata} 자동 생성 → {@link SearchRequestPlanner}
 *       가 활용 + {@link SchemaResolver} 가 discovery 영역 응답</li>
 * </ul>
 *
 * <p>Phase 4 task #8 — Cache 자동 결합. {@link CrudCacheAdvisor} 가 nullable inject:
 * <ul>
 *   <li>entity class 가 {@code Cacheable} marker 적용 시 5 method 자동 cache 결합 (Read = entity_cache /
 *       search_list_cache 적재, Write = entity_cache + search_list_cache evict 또는 write-through put)</li>
 *   <li>marker 미적용 entity = advisor 가 통과 (Phase 3 의 raw 동작 그대로)</li>
 *   <li>advisor 자체가 null = cache 영역 전체 통과 (Phase 3 호환 유지)</li>
 * </ul>
 *
 * @param <E>          entity 타입 (JPA entity)
 * @param <ID>         식별자 타입
 * @param <CreateForm> create body Records
 * @param <UpdateForm> update body Records
 **/
public abstract class AbstractCrudService<E, ID, CreateForm, UpdateForm> {

  protected final CrudRepository<E, ID> repository;
  protected final Class<E> entityClass;
  private final SchemaResolver schemaResolver;

  @Nullable private final CrudCacheAdvisor cacheAdvisor;

  protected AbstractCrudService(CrudRepository<E, ID> repository, Class<E> entityClass) {
    this(repository, entityClass, new SchemaResolver(), null);
  }

  protected AbstractCrudService(
      CrudRepository<E, ID> repository,
      Class<E> entityClass,
      SchemaResolver schemaResolver) {
    this(repository, entityClass, schemaResolver, null);
  }

  protected AbstractCrudService(
      CrudRepository<E, ID> repository,
      Class<E> entityClass,
      SchemaResolver schemaResolver,
      @Nullable CrudCacheAdvisor cacheAdvisor) {
    this.repository = Objects.requireNonNull(repository, "repository");
    this.entityClass = Objects.requireNonNull(entityClass, "entityClass");
    this.schemaResolver = Objects.requireNonNull(schemaResolver, "schemaResolver");
    this.cacheAdvisor = cacheAdvisor;
  }

  // ---------------------------------------------------------------------
  // 5 표준 method
  // ---------------------------------------------------------------------

  /** 신규 entity 생성 — {@link #toEntity(Object)} + {@code repository.save} + cache write 결합. */
  public E create(CreateForm form) {
    Objects.requireNonNull(form, "form");
    E entity = toEntity(form);
    E saved = repository.save(entity);
    if (cacheAdvisor != null) {
      cacheAdvisor.recordWrite(entityClass, saved, null);
    }
    return saved;
  }

  /** 단건 lookup — cache 결합 시 entity_cache 통과. 미존재 = null. */
  public E find(ID id) {
    Objects.requireNonNull(id, "id");
    if (cacheAdvisor != null) {
      return cacheAdvisor.findCached(entityClass, id, () -> repository.findById(id).orElse(null));
    }
    return repository.findById(id).orElse(null);
  }

  /**
   * 검색 + 페이징 — {@link SearchRequestPlanner} 활용 + JPA Specification 구축. cache 결합 시 search_list_cache
   * 통과 ({@link SearchRequest} 자체가 Records → equals/hashCode 정합).
   */
  public Page<E> search(SearchRequest request) {
    Objects.requireNonNull(request, "request");
    if (cacheAdvisor != null) {
      return cacheAdvisor.searchCached(entityClass, request, () -> doSearch(request));
    }
    return doSearch(request);
  }

  /**
   * Phase 0.1.0 GA Gate T0-6 — 풍부 응답 검색 (Decision #31 정합 baseline).
   *
   * <p>{@link #search(SearchRequest)} 위임 + {@link SearchResponse} 변환 (페이징 메타 + sorts/searchRequest
   * echo). Phase 4 의 cache 결합도 {@link #search(SearchRequest)} 안에 적용 — 본 method 가 Page →
   * SearchResponse 변환만 책임.
   *
   * <p>preserve / restore cycle — service 가 client SearchRequest 받으면 → {@link SearchRequest#preserve()}
   * snapshot → 강제 주입 (userId/tenantId/scope) 영역은 Consumer 의 비즈니스 override → repository 실행 →
   * {@link SearchRequest#restore()} echo (Records 자연 immutability 라 별도 복원 X). 본 base 는 강제 주입
   * 단계가 비즈니스라 기본 *원본 request 그대로 echo* — Consumer 의 service override 가 preserve cycle 본격 적용.
   *
   * @param request SearchRequest (page/pageSize/filters/sorts)
   * @return content + 페이징 메타 + sorts/searchRequest echo
   */
  public SearchResponse<E> searchResponse(SearchRequest request) {
    Objects.requireNonNull(request, "request");
    Page<E> page = search(request);
    return new SearchResponse<>(
        page.getContent(),
        page.getNumber(),
        page.getSize(),
        page.getTotalElements(),
        page.getTotalPages(),
        request.sorts(),
        request,
        Map.of(),
        List.of());
  }

  /**
   * Phase 0.1.0 GA Gate T0-6 — 검색 조건 만족 count (Decision #31 정합).
   *
   * <p>{@link SearchRequestPlanner} 활용 + JPA Specification 구축 + {@code repository.count(spec)}.
   * page/pageSize 무시 — filters / quickSearch / mappedJoinFilters / unmappedJoins 만 사용 (효율
   * COUNT(*) 직접 query, content fetch 회피).
   *
   * @param request SearchRequest (filters / quickSearch — page/pageSize 무시)
   * @return 매칭 count
   */
  public long count(SearchRequest request) {
    Objects.requireNonNull(request, "request");
    SearchRequestPlanner<E> planner = SearchRequestPlanner.forEntity(entityClass);
    Specification<E> spec = (root, query, cb) -> {
      PlannedQuery planned = planner.plan(request, root, query, cb);
      // count query 는 distinct / orderBy 적용 불필요 (Spring Data 가 count 시 자동 제거).
      return planned.predicate();
    };
    return repository.count(spec);
  }

  /**
   * 부분 또는 전체 갱신 — find + {@link #applyForm(Object, Object)} + save + cache evict/put 결합.
   * 미존재 = {@link IllegalStateException} (Consumer override 시 도메인 ServiceException 으로 변환).
   */
  public E update(ID id, UpdateForm form) {
    Objects.requireNonNull(id, "id");
    Objects.requireNonNull(form, "form");
    E previous = repository.findById(id)
        .orElseThrow(() -> new IllegalStateException(
            "Entity not found: " + entityClass.getSimpleName() + "#" + id));
    applyForm(previous, form);
    E saved = repository.save(previous);
    if (cacheAdvisor != null) {
      cacheAdvisor.recordWrite(entityClass, saved, previous);
    }
    return saved;
  }

  /** 삭제 + cache evict — soft / hard 결정은 entity 의 {@code @SoftDelete} 어노테이션. */
  public void delete(ID id) {
    Objects.requireNonNull(id, "id");
    E deleted = cacheAdvisor != null ? repository.findById(id).orElse(null) : null;
    repository.deleteById(id);
    if (cacheAdvisor != null) {
      cacheAdvisor.recordDelete(entityClass, id, deleted);
    }
  }

  /**
   * Phase 0.1.0 GA Gate T0-6 — bulk 삭제 (Decision #31 정합).
   *
   * <p>{@code repository.deleteAllByIdInBatch(ids)} — 단일 SQL DELETE batch (개별 DELETE n 회 회피,
   * 효율 영역). cache 결합 시 각 id 별 evict 자동 (per-id loop 으로 cache 정합 유지).
   *
   * <p>soft / hard 결정은 entity 의 {@code @SoftDelete} 어노테이션 — Hibernate 7 가 자동 매핑.
   *
   * @param ids 삭제 대상 식별자 list (non-empty 강제, 호출 시 web layer 의 {@code BulkDeleteRequest}
   *            가 이미 검증)
   */
  public void bulkDelete(List<ID> ids) {
    Objects.requireNonNull(ids, "ids");
    if (ids.isEmpty()) {
      return;
    }
    // cache evict 영역 — 각 id 별 (deletedEntity null 으로 simple evict, fetch 영역 회피)
    if (cacheAdvisor != null) {
      for (ID id : ids) {
        cacheAdvisor.recordDelete(entityClass, id, null);
      }
    }
    repository.deleteAllByIdInBatch(ids);
  }

  private Page<E> doSearch(SearchRequest request) {
    SearchRequestPlanner<E> planner = SearchRequestPlanner.forEntity(entityClass);
    Pageable pageable = toPageable(request);
    Specification<E> spec = (root, query, cb) -> {
      PlannedQuery planned = planner.plan(request, root, query, cb);
      if (planned.distinct()) {
        query.distinct(true);
      }
      if (!planned.orders().isEmpty()) {
        query.orderBy(planned.orders());
      }
      return planned.predicate();
    };
    return repository.findAll(spec, pageable);
  }

  /** {@link SchemaResolver} 위임 — APT {@code Entity_Metadata} 활용해서 8 key Map 응답. */
  public Map<String, Object> searchSchema() {
    return schemaResolver.resolve(entityClass);
  }

  // ---------------------------------------------------------------------
  // 추상 2 — 비즈니스 (Decision #7 적용, hook 거부)
  // ---------------------------------------------------------------------

  /** {@code CreateForm} → 신규 entity 변환. id/audit/tenant 영역은 framework 가 자동 채움. */
  protected abstract E toEntity(CreateForm form);

  /** {@code UpdateForm} 의 변경 영역을 기존 entity 에 적용. partial update 허용 (null 필드 = 미변경). */
  protected abstract void applyForm(E entity, UpdateForm form);

  // ---------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------

  /**
   * {@link SearchRequest} → {@link Pageable} 변환. sort 영역은 planner 가 적용 → {@link Sort#unsorted()}
   * (Spring Data 가 추가 ORDER BY 안 추가).
   */
  private static Pageable toPageable(SearchRequest request) {
    int page = request.page() == null ? 0 : Math.max(0, request.page());
    int size = request.pageSize() == null ? 20 : Math.max(1, request.pageSize());
    return PageRequest.of(page, size, Sort.unsorted());
  }
}
