/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.time.Duration;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #5 — Decision #7 의 cache 영역 yml binding 단일 지점. {@code platform.cache.*} prefix.
 *
 * <p>{@code backend} = 4 모드 graceful degradation:
 * <ul>
 *   <li>{@code none} — {@code NoOpCacheManager} (cache 비활성, 모든 호출 통과)</li>
 *   <li>{@code local-only} (default) — Caffeine 단독 ({@link TwoTierCacheManager})</li>
 *   <li>{@code redis} — Redis 단독 (Phase 4 후속 또는 Consumer 명시 적용)</li>
 *   <li>{@code l1+l2} — Caffeine L1 + Redis L2 (Phase 4 후속)</li>
 * </ul>
 *
 * <p>{@code default*MaxSize} / {@code default*Ttl} = {@link TwoTierCacheManager} 의 per-tier default
 * spec yml override hook. Phase 4 task #2 의 hardcoded default (entity 1000/86400s + searchList 100/3600s)
 * 를 yml 로 override 가능.
 *
 * <p>{@code regions} = per-region 명시 override Map (region name → {@link Region}). Phase 4 task #6
 * 의 {@code @CacheStrategy} annotation 또는 본 yml 둘 중 우선순위 = yml > annotation > default.
 **/
@ConfigurationProperties(prefix = "platform.cache")
public record CacheProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("LOCAL_ONLY") CacheBackend backend,
    @DefaultValue("1000") long defaultEntityMaxSize,
    @DefaultValue("PT24H") Duration defaultEntityTtl,
    @DefaultValue("100") long defaultSearchMaxSize,
    @DefaultValue("PT1H") Duration defaultSearchTtl,
    @DefaultValue Map<String, Region> regions) {

  /**
   * Phase 4 task #5 + #6 — per-region override. 미적용 필드 ({@code null}) = global default 따라감.
   * {@code strategy} 는 Phase 4 task #6 에서 추가 — yml > annotation > default 우선순위.
   */
  public record Region(Long maxSize, Duration ttl, CacheWriteStrategy strategy) {}
}
