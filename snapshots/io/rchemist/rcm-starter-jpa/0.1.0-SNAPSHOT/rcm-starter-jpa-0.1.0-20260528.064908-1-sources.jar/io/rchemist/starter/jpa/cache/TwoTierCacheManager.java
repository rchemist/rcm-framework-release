/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #2 — region name suffix 기반 per-region Caffeine spec 차등 적용. {@link
 * CaffeineCacheManager} 는 default 가 single Caffeine spec → {@link #createNativeCaffeineCache(String)}
 * override 로 region 별 size/TTL 차등 적용.
 *
 * <p>default spec (Phase 4 task #5 의 {@code platform.cache.*} yml override 적용 전 baseline):
 * <ul>
 *   <li>{@link CacheTier#ENTITY} — maximumSize 1000 / expireAfterWrite 86400s (1d) — gjcu 일관 패턴 흡수</li>
 *   <li>{@link CacheTier#SEARCH_LIST} — maximumSize 100 / expireAfterWrite 3600s (1h)</li>
 *   <li>tier 미일치 region — {@link #setCaffeine(Caffeine)} 또는 default Caffeine spec</li>
 * </ul>
 *
 * <p>{@link #recordStats} default ON — Phase 4 task #4 Micrometer {@code CacheMeterBinder} 인입.
 **/
public class TwoTierCacheManager extends CaffeineCacheManager {

  public static final long DEFAULT_ENTITY_MAX_SIZE = 1000L;
  public static final Duration DEFAULT_ENTITY_TTL = Duration.ofSeconds(86400L);
  public static final long DEFAULT_SEARCH_LIST_MAX_SIZE = 100L;
  public static final Duration DEFAULT_SEARCH_LIST_TTL = Duration.ofSeconds(3600L);

  private long entityMaxSize = DEFAULT_ENTITY_MAX_SIZE;
  private Duration entityTtl = DEFAULT_ENTITY_TTL;
  private long searchListMaxSize = DEFAULT_SEARCH_LIST_MAX_SIZE;
  private Duration searchListTtl = DEFAULT_SEARCH_LIST_TTL;
  private Map<String, CacheProperties.Region> regionOverrides = Collections.emptyMap();

  @Nullable private CacheMetricsRegistrar metricsRegistrar;

  public TwoTierCacheManager() {
    super();
    setCaffeine(Caffeine.newBuilder().recordStats());
  }

  @Override
  protected com.github.benmanes.caffeine.cache.Cache<Object, Object> createNativeCaffeineCache(
      String name) {
    CacheTier tier = CacheRegionNames.tierOf(name);
    com.github.benmanes.caffeine.cache.Cache<Object, Object> nativeCache =
        (tier == null) ? super.createNativeCaffeineCache(name) : tieredBuilder(name, tier).build();
    if (metricsRegistrar != null) {
      metricsRegistrar.register(name, nativeCache);
    }
    return nativeCache;
  }

  /** Phase 4 task #4 hook — Micrometer 가용 시 manager 에 registrar inject. */
  public void setMetricsRegistrar(@Nullable CacheMetricsRegistrar metricsRegistrar) {
    this.metricsRegistrar = metricsRegistrar;
  }

  private Caffeine<Object, Object> tieredBuilder(String regionName, CacheTier tier) {
    Caffeine<Object, Object> builder = Caffeine.newBuilder().recordStats();
    long size;
    Duration ttl;
    switch (tier) {
      case ENTITY -> {
        size = entityMaxSize;
        ttl = entityTtl;
      }
      case SEARCH_LIST -> {
        size = searchListMaxSize;
        ttl = searchListTtl;
      }
      default -> throw new IllegalStateException("Unknown tier: " + tier);
    }
    CacheProperties.Region override = regionOverrides.get(regionName);
    if (override != null) {
      if (override.maxSize() != null) {
        size = override.maxSize();
      }
      if (override.ttl() != null) {
        ttl = override.ttl();
      }
    }
    return builder.maximumSize(size).expireAfterWrite(ttl);
  }

  /** Phase 4 task #5 — per-region 명시 override Map 적용 hook. */
  public void configureRegions(@Nullable Map<String, CacheProperties.Region> regions) {
    this.regionOverrides = regions == null ? Collections.emptyMap() : Map.copyOf(regions);
  }

  /** Phase 4 task #5 yml binding hook. */
  public void configureDefaults(
      @Nullable Long entityMaxSize,
      @Nullable Duration entityTtl,
      @Nullable Long searchListMaxSize,
      @Nullable Duration searchListTtl) {
    if (entityMaxSize != null) {
      this.entityMaxSize = entityMaxSize;
    }
    if (entityTtl != null) {
      this.entityTtl = entityTtl;
    }
    if (searchListMaxSize != null) {
      this.searchListMaxSize = searchListMaxSize;
    }
    if (searchListTtl != null) {
      this.searchListTtl = searchListTtl;
    }
  }

  public long entityMaxSize() {
    return entityMaxSize;
  }

  public Duration entityTtl() {
    return entityTtl;
  }

  public long searchListMaxSize() {
    return searchListMaxSize;
  }

  public Duration searchListTtl() {
    return searchListTtl;
  }
}
