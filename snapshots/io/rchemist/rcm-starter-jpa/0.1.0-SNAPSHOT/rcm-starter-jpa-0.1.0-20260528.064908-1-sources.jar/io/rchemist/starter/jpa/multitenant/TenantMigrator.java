/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.extension.ExtensionPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Tenant migration ExtensionPoint (Decision #17 — Flyway/Liquibase 자동). Consumer
 * 가 자체 Flyway / Liquibase / 자체 DDL runner 등록 시 onboard / startup 시점에 자동 호출. 다중 등록
 * 가능 (List, {@code @Order} 정렬 — Phase 5 에서 강제 ordering 결정).
 *
 * <p>framework default = 등록된 migrator 0 (Consumer 가 명시 적용). Phase 9 archetype 가 Flyway
 * adapter 를 default 로 적용 가능.
 **/
@ExtensionPoint("Tenant migration runner (Flyway / Liquibase / 자체 DDL)")
public interface TenantMigrator {

  /** 신규 onboard 또는 startup 시점에 호출. {@link TenantConfig} 가 가리키는 tenant 에 migration 실행. */
  void migrate(TenantConfig config);
}
