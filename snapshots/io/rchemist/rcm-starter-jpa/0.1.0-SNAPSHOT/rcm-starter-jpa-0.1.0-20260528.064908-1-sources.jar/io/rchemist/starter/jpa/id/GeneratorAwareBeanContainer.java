/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.id;

import org.hibernate.generator.Generator;
import org.hibernate.resource.beans.container.spi.BeanContainer;
import org.hibernate.resource.beans.container.spi.ContainedBean;
import org.hibernate.resource.beans.spi.BeanInstanceProducer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #21 — Spring Boot 4 + Hibernate 7 통합에서 {@code SpringBeanContainer} 가 {@link
 * org.hibernate.annotations.IdGeneratorType} 가 부착된 generator 클래스를 *Spring DI 후보* 로 인식하여
 * {@code (annotation, Member, GeneratorCreationContext)} 시그니처의 0번 파라미터 어노테이션 타입을
 * 빈으로 autowire 시도 → {@code NoSuchBeanDefinitionException} 으로 EMF 부팅 실패하는 영역 우회.
 *
 * <p>본 wrapper 는 {@link BeanContainer#getBean} 진입 시 {@code beanType} 이 {@link Generator} 의
 * 서브타입이면 delegate (Spring 의 {@code SpringBeanContainer}) 를 우회하고 Hibernate 가 전달한
 * {@link BeanInstanceProducer#produceBeanInstance fallback} 을 직접 호출 — Hibernate 의 special
 * ctor 정합. 그 외 타입은 delegate 그대로 → entity listener / converter / multi-tenant resolver
 * 등 Spring DI 가 필요한 영역 영향 0.
 *
 * <p>Hibernate 7 의 모든 generator (identifier / value generator) 는 {@link Generator} 베이스
 * 인터페이스 구현 → 단일 분기 조건으로 모든 케이스 흡수.
 **/
public class GeneratorAwareBeanContainer implements BeanContainer {

  private final BeanContainer delegate;

  public GeneratorAwareBeanContainer(BeanContainer delegate) {
    this.delegate = delegate;
  }

  @Override
  public <B> ContainedBean<B> getBean(
      Class<B> beanType, LifecycleOptions lifecycleOptions, BeanInstanceProducer fallbackProducer) {
    if (isGeneratorType(beanType)) {
      return new FallbackContainedBean<>(beanType, fallbackProducer.produceBeanInstance(beanType));
    }
    return delegate.getBean(beanType, lifecycleOptions, fallbackProducer);
  }

  @Override
  public <B> ContainedBean<B> getBean(
      String name,
      Class<B> beanType,
      LifecycleOptions lifecycleOptions,
      BeanInstanceProducer fallbackProducer) {
    if (isGeneratorType(beanType)) {
      return new FallbackContainedBean<>(
          beanType, fallbackProducer.produceBeanInstance(name, beanType));
    }
    return delegate.getBean(name, beanType, lifecycleOptions, fallbackProducer);
  }

  @Override
  public void stop() {
    delegate.stop();
  }

  /** 위임 받은 원본 container — test / 검증용 노출. */
  public BeanContainer delegate() {
    return delegate;
  }

  private static boolean isGeneratorType(Class<?> beanType) {
    return Generator.class.isAssignableFrom(beanType);
  }

  private static final class FallbackContainedBean<B> implements ContainedBean<B> {
    private final Class<B> beanClass;
    private final B instance;

    FallbackContainedBean(Class<B> beanClass, B instance) {
      this.beanClass = beanClass;
      this.instance = instance;
    }

    @Override
    public Class<B> getBeanClass() {
      return beanClass;
    }

    @Override
    public B getBeanInstance() {
      return instance;
    }
  }
}
