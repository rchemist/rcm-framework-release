/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — Decision #18 의 multi-DataSource routing marker. Repository / Service /
 * 메서드 / 필드 위에 부착해서 별도 DataSource ({@link MultiEntityManager} 의 등록 이름) 적용 명시.
 *
 * <p>baseline 적용 — annotation 자체는 메타 마커. Phase 4 의 Repository routing AOP / Spring Data
 * `entityManagerFactoryRef` resolver 가 본 어노테이션 인입. 본 task 는 marker + SPI ({@link
 * MultiEntityManager}) 까지의 baseline.
 *
 * <p>collision 영역 — Jakarta {@code javax.sql.DataSource} 와 simple name 동일이지만 본 어노테이션은
 * {@code io.rchemist.starter.jpa.datasource.DataSource} package 분리 + Records / sealed marker
 * baseline. Decision #20 (prefix 없음) 정합 — Consumer 가 import 시 명시 qualification.
 *
 * <p>예:
 * <pre>{@code
 * import io.rchemist.starter.jpa.datasource.DataSource;
 *
 * @Repository
 * @DataSource("reporting")
 * public interface ArticleStatsRepository extends Repository<ArticleStats, Long> { ... }
 * }</pre>
 */
@Documented
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface DataSource {

  /** {@link MultiEntityManager#on(String)} 의 lookup key. yml {@code platform.datasource.additional.<name>.*} 와 정합. */
  String value();
}
