/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — SCHEMA 전략 onboard 시 {@code CREATE SCHEMA} 실행 SPI. DefaultSchemaInitializer
 * 가 PostgreSQL {@code CREATE SCHEMA IF NOT EXISTS} 적용 (Decision #17). 다른 DBMS 또는 별도 권한
 * model 이 필요하면 Consumer 가 자체 impl 적용 → {@code @ConditionalOnMissingBean} 자동 교체.
 *
 * <p>{@link TenantManagementService#onboard(TenantConfig)} 가 SCHEMA 전략 활성 시 자동 호출.
 **/
public interface SchemaInitializer {

  /** {@link TenantConfig#schemaName()} 에 대한 schema 생성. 이미 존재하면 no-op (idempotent). */
  void createSchema(TenantConfig config);
}
