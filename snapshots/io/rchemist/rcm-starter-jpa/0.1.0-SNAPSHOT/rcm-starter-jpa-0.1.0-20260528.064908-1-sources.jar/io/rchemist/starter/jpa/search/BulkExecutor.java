/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.BulkDeleteRequest;
import io.rchemist.core.search.BulkUpdateRequest;
import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.SearchRequest;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaDelete;
import jakarta.persistence.criteria.CriteriaUpdate;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6j — Bulk update / delete 실행 helper. JPA standard {@code CriteriaUpdate} +
 * {@code CriteriaDelete}. WHERE 영역은 {@link SearchRequest} 의 filter 재사용 — {@link FilterDispatcher}
 * 위임 (24 QueryConditionType 영역).
 *
 * <p>주의: JPA standard CriteriaUpdate/Delete 는 JOIN 미지원 (root + WHERE 만). 다단 path
 * ({@code author.name} 같은 join 영역) 은 SubQuery 우회 또는 사전 ID lookup 후 IN clause 영역.
 *
 * <p>caller 는 {@code @Transactional} 컨텍스트 안에서 호출.
 */
public final class BulkExecutor<T> {

  private final EntityManager em;
  private final Class<T> entityClass;
  private final EntityMetadata<T> metadata;

  public BulkExecutor(EntityManager em, Class<T> entityClass) {
    this.em = Objects.requireNonNull(em, "em");
    this.entityClass = Objects.requireNonNull(entityClass, "entityClass");
    this.metadata = EntityMetadataRegistry.require(entityClass);
  }

  /**
   * Bulk UPDATE 실행 — 영향받은 row 수 반환.
   */
  public int update(BulkUpdateRequest req) {
    Objects.requireNonNull(req, "req");

    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaUpdate<T> cu = cb.createCriteriaUpdate(entityClass);
    Root<T> root = cu.from(entityClass);

    for (Map.Entry<String, String> entry : req.set().entrySet()) {
      String fieldPath = entry.getKey();
      if (fieldPath.contains(".")) {
        throw new IllegalArgumentException(
            "JPA standard CriteriaUpdate 영역에서 다단 path SET 미지원: " + fieldPath);
      }
      Path<Object> path = root.get(fieldPath);
      Object coerced = ValueCoercer.coerce(entry.getValue(), path.getJavaType());
      cu.set(path, coerced);
    }

    Predicate where = buildWhere(req.where(), root, cb);
    if (where != null) {
      cu.where(where);
    }
    return em.createQuery(cu).executeUpdate();
  }

  /**
   * Bulk DELETE 실행 — 영향받은 row 수 반환.
   */
  public int delete(BulkDeleteRequest req) {
    Objects.requireNonNull(req, "req");

    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaDelete<T> cd = cb.createCriteriaDelete(entityClass);
    Root<T> root = cd.from(entityClass);

    Predicate where = buildWhere(req.where(), root, cb);
    if (where != null) {
      cd.where(where);
    }
    return em.createQuery(cd).executeUpdate();
  }

  /**
   * Bulk WHERE — JPA CriteriaUpdate/Delete 영역에서 filter 처리. {@link JoinAliasManager} 는 single root
   * 에서만 동작 (JPA CriteriaUpdate 한계 — JOIN 없음). 다단 path 영역의 filter 는 SubQuery 권장.
   */
  private Predicate buildWhere(SearchRequest where, Root<T> root, CriteriaBuilder cb) {
    if (where == null || where.filters() == null || where.filters().isEmpty()) {
      return null;
    }
    JoinAliasManager joins = new JoinAliasManager(root, metadata);
    List<Predicate> groups = new ArrayList<>();
    for (Map.Entry<LogicalOperator, List<FilterItem>> e : where.filters().entrySet()) {
      List<Predicate> inner = new ArrayList<>(e.getValue().size());
      for (FilterItem item : e.getValue()) {
        // CriteriaQuery 가 아닌 CriteriaUpdate/Delete 영역 — 일부 EXISTS / SubQuery 영역 미지원.
        // baseline = path-based filter 만.
        inner.add(FilterDispatcher.build(item, joins, cb, null, metadata));
      }
      if (inner.isEmpty()) {
        continue;
      }
      Predicate[] arr = inner.toArray(Predicate[]::new);
      groups.add(switch (e.getKey()) {
        case AND -> cb.and(arr);
        case OR -> cb.or(arr);
        case NOT -> cb.not(cb.and(arr));
      });
    }
    if (groups.isEmpty()) {
      return null;
    }
    return groups.size() == 1 ? groups.get(0) : cb.and(groups.toArray(Predicate[]::new));
  }
}
