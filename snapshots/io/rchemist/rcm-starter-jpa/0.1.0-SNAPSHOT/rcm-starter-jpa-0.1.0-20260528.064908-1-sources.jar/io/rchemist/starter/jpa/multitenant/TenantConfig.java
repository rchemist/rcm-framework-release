/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Tenant 등록 시 필요한 metadata (Decision #17 — TenantManagementService.onboard).
 * DATABASE 전략 = {@code jdbcUrl/username/password} 전부 적용, SCHEMA 전략 = {@code schemaName} 적용 +
 * jdbcUrl 옵션 (default null = 공통 DataSource), DISCRIMINATOR 전략 = 모두 옵션 (tenantId 만 의미).
 *
 * <p>onboard 시 framework 가 strategy 별로 필요한 필드 검증 (Fail-loud).
 **/
public record TenantConfig(String tenantId, String jdbcUrl, String username, String password, String schemaName) {

  public TenantConfig {
    Objects.requireNonNull(tenantId, "tenantId");
  }

  /** 편의 factory — DATABASE 전략. */
  public static TenantConfig forDatabase(String tenantId, String jdbcUrl, String username, String password) {
    return new TenantConfig(tenantId, jdbcUrl, username, password, null);
  }

  /** 편의 factory — SCHEMA 전략. */
  public static TenantConfig forSchema(String tenantId, String schemaName) {
    return new TenantConfig(tenantId, null, null, null, schemaName);
  }

  /** 편의 factory — DISCRIMINATOR 전략 (tenantId 만 의미, 나머지는 placeholder). */
  public static TenantConfig forDiscriminator(String tenantId) {
    return new TenantConfig(tenantId, null, null, null, null);
  }
}
