/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.cache.CacheManager;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #2 — Cacheable entity 마다 2-tier region 사전 등록. {@link CacheManager#getCache(String)}
 * 호출이 dynamic 생성 트리거 → 후속 요청은 동일 인스턴스 재사용. {@link CacheableEntityRegistry} 의 entity 집합
 * 순회.
 *
 * <p>{@link SmartInitializingSingleton} 호출 시점 = 모든 singleton 초기화 후 (registry / manager 양쪽 가용
 * 보장).
 **/
public class CacheRegionInitializer implements SmartInitializingSingleton {

  private final CacheableEntityRegistry registry;
  private final CacheManager cacheManager;

  public CacheRegionInitializer(CacheableEntityRegistry registry, CacheManager cacheManager) {
    this.registry = registry;
    this.cacheManager = cacheManager;
  }

  @Override
  public void afterSingletonsInstantiated() {
    for (Class<?> entityClass : registry.cacheableEntities()) {
      cacheManager.getCache(CacheRegionNames.entityCacheName(entityClass));
      cacheManager.getCache(CacheRegionNames.searchListCacheName(entityClass));
    }
  }
}
