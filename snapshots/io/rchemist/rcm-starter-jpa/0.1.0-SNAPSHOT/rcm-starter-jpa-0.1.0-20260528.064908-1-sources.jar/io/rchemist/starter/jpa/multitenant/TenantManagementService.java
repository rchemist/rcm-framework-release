/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.extension.ExtensionPoint;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Multi-tenant lifecycle ExtensionPoint (Decision #17). Tenant onboard / offboard /
 * activeTenants 발견 진실 원천. Consumer 가 자체 impl 적용 시 자동 교체 ({@code @ConditionalOnMissingBean}).
 *
 * <p>{@code onboard} = 신규 tenant 등록 — DATABASE 전략 시 HikariCP DataSource 자동 생성, SCHEMA 전략 시
 * {@code CREATE SCHEMA} 자동 실행, DISCRIMINATOR 전략 시 단순 registry 등록. 이어서 등록된 모든
 * {@link TenantMigrator} 가 신규 tenant 에 migration 실행.
 *
 * <p>{@code offboard} = tenant 삭제 — DataSource pool close, registry 제거. 데이터 보관 정책은 framework
 * 책임 영역 밖 (Consumer 가 명시적으로 schema/database drop 결정).
 *
 * <p>{@code activeTenants} = 현재 등록된 tenantId 목록 — {@link TenantMigrationRunner} 가 startup
 * 시점에 순회. 변경 가능한 view 가 아닌 snapshot.
 **/
@ExtensionPoint("Multi-tenant lifecycle (onboard / offboard / activeTenants)")
public interface TenantManagementService {

  /**
   * 신규 tenant 등록. 이미 등록된 tenantId 면 {@link IllegalStateException} (Fail-loud — silent overwrite
   * 차단).
   */
  void onboard(TenantConfig config);

  /** Tenant 등록 해제. 미등록 tenantId 면 no-op (idempotent). */
  void offboard(String tenantId);

  /** 현재 등록된 tenantId 의 immutable snapshot. */
  List<String> activeTenants();

  /** 등록된 tenant 의 metadata 조회. */
  Optional<TenantConfig> findConfig(String tenantId);
}
