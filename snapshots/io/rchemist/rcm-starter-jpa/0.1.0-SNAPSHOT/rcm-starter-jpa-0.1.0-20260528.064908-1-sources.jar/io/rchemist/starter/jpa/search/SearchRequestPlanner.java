/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.UnmappedJoin;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — Universal {@link SearchRequest} → {@link PlannedQuery} 변환 진입점 (청사진 §5.5.4
 * + §5.5.5 + §5.5.6). 0.0.5 {@code AbstractSearchForm.validateFilters} + {@code PredicateMerger}
 * 흡수.
 *
 * <p>책임:
 * <ul>
 *   <li>{@link EntityMetadata} 활용 — searchable 화이트리스트 검증, FilterClassification 자동 분류</li>
 *   <li>{@link FilterDispatcher} 위임 — 24 QueryConditionType → Predicate</li>
 *   <li>{@link UnmappedJoinResolver} 위임 — 명시 매핑 없는 entity SubQuery</li>
 *   <li>{@link SortBuilder} 위임 — sort + JoinAliasManager 공유 (filter ↔ sort 정합)</li>
 *   <li>{@link JoinAliasManager#hasCollectionJoin()} 자동 → DISTINCT 트리거</li>
 *   <li>top-level {@link LogicalOperator} (AND/OR/NOT) 트리 + nested subFilters 재귀 처리</li>
 *   <li>quickSearchFields + searchTerm → OR group 자동 전개 (0.0.5 패턴)</li>
 * </ul>
 *
 * <p>Repository 사용 패턴:
 * <pre>{@code
 * return repository.findAll((root, query, cb) -> {
 *   PlannedQuery planned = planner.plan(req, root, query, cb);
 *   if (planned.distinct()) query.distinct(true);
 *   if (!planned.orders().isEmpty()) query.orderBy(planned.orders());
 *   return planned.predicate();
 * }, pageable);
 * }</pre>
 */
public final class SearchRequestPlanner<T> {

  private final EntityMetadata<T> metadata;

  public SearchRequestPlanner(EntityMetadata<T> metadata) {
    this.metadata = Objects.requireNonNull(metadata, "metadata");
  }

  /** Registry 에서 lookup — APT 적용된 metadata 자동 사용. */
  public static <T> SearchRequestPlanner<T> forEntity(Class<T> entityClass) {
    return new SearchRequestPlanner<>(EntityMetadataRegistry.require(entityClass));
  }

  public EntityMetadata<T> metadata() {
    return metadata;
  }

  public PlannedQuery plan(
      SearchRequest req, Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb
  ) {
    Objects.requireNonNull(req, "req");
    Objects.requireNonNull(root, "root");
    Objects.requireNonNull(query, "query");
    Objects.requireNonNull(cb, "cb");

    JoinAliasManager joins = new JoinAliasManager(root, metadata);

    // Phase 3 task #6i — FETCH JOIN 영역 (N+1 회피). plan 의 가장 첫 단계.
    boolean hasFetchCollection = applyFetchJoins(req, root);

    List<Predicate> active = new ArrayList<>(3);
    Predicate filterPredicate = buildFilters(req, root, query, cb, joins);
    if (filterPredicate != null) {
      active.add(filterPredicate);
    }
    Predicate quickSearch = buildQuickSearch(req, joins, cb);
    if (quickSearch != null) {
      active.add(quickSearch);
    }
    Predicate unmapped = buildUnmappedJoins(req, root, query, cb);
    if (unmapped != null) {
      active.add(unmapped);
    }
    Predicate joined = combine(cb, req.operator(), active);

    List<Order> orders = SortBuilder.build(req, joins, cb);

    boolean distinct = joins.hasCollectionJoin() || hasFetchCollection;
    return new PlannedQuery(joined, orders, distinct);
  }

  /**
   * FETCH JOIN 영역 적용 — {@code root.fetch(path, joinType)} chain. multi-segment path 영역 동작.
   *
   * @return collection (OneToMany/ManyToMany) fetch 발견 시 true → DISTINCT 자동 트리거
   */
  private boolean applyFetchJoins(SearchRequest req, Root<T> root) {
    boolean hasCollection = false;
    for (String path : req.fetchJoins()) {
      String[] parts = path.split("\\.");
      jakarta.persistence.criteria.FetchParent<?, ?> current = root;
      for (String part : parts) {
        current = current.fetch(part, jakarta.persistence.criteria.JoinType.LEFT);
      }
      // collection association 검사 — root 의 첫 segment 의 metadata classify 가 ONE_TO_MANY 면 true.
      String head = parts[0];
      if (metadata.classify(head)
          == io.rchemist.core.search.FilterClassification.ONE_TO_MANY) {
        hasCollection = true;
      }
    }
    return hasCollection;
  }

  private Predicate buildFilters(
      SearchRequest req, Root<T> root, CriteriaQuery<?> query,
      CriteriaBuilder cb, JoinAliasManager joins
  ) {
    if (req.filters() == null || req.filters().isEmpty()) {
      return null;
    }
    List<Predicate> groups = new ArrayList<>();
    for (Map.Entry<LogicalOperator, List<FilterItem>> e : req.filters().entrySet()) {
      List<Predicate> inner = new ArrayList<>(e.getValue().size());
      for (FilterItem item : e.getValue()) {
        if (item.hasSubFilters()) {
          inner.add(buildSubFilter(item, root, query, cb, joins));
        } else {
          inner.add(FilterDispatcher.build(item, joins, cb, query, metadata));
        }
      }
      groups.add(combineGroup(cb, e.getKey(), inner));
    }
    return groups.size() == 1 ? groups.get(0) : cb.and(groups.toArray(Predicate[]::new));
  }

  private Predicate buildSubFilter(
      FilterItem parent, Root<T> root, CriteriaQuery<?> query,
      CriteriaBuilder cb, JoinAliasManager joins
  ) {
    List<Predicate> subGroups = new ArrayList<>();
    for (Map.Entry<LogicalOperator, List<FilterItem>> e : parent.subFilters().entrySet()) {
      List<Predicate> inner = new ArrayList<>(e.getValue().size());
      for (FilterItem item : e.getValue()) {
        if (item.hasSubFilters()) {
          inner.add(buildSubFilter(item, root, query, cb, joins));
        } else {
          inner.add(FilterDispatcher.build(item, joins, cb, query, metadata));
        }
      }
      subGroups.add(combineGroup(cb, e.getKey(), inner));
    }
    return subGroups.size() == 1 ? subGroups.get(0) : cb.and(subGroups.toArray(Predicate[]::new));
  }

  private Predicate combineGroup(CriteriaBuilder cb, LogicalOperator op, List<Predicate> inner) {
    if (inner.isEmpty()) {
      return cb.conjunction();
    }
    Predicate[] arr = inner.toArray(Predicate[]::new);
    return switch (op) {
      case AND -> cb.and(arr);
      case OR -> cb.or(arr);
      case NOT -> cb.not(cb.and(arr));
    };
  }

  private Predicate buildQuickSearch(SearchRequest req, JoinAliasManager joins, CriteriaBuilder cb) {
    if (req.searchTerm() == null || req.searchTerm().isBlank()
        || req.quickSearchFields() == null || req.quickSearchFields().isEmpty()) {
      return null;
    }
    List<Predicate> ors = new ArrayList<>(req.quickSearchFields().size());
    String pattern = "%" + req.searchTerm().toLowerCase() + "%";
    for (String field : req.quickSearchFields()) {
      jakarta.persistence.criteria.Path<?> path = joins.resolvePath(field, null);
      @SuppressWarnings("unchecked")
      jakarta.persistence.criteria.Expression<String> stringPath
          = (jakarta.persistence.criteria.Expression<String>) path;
      ors.add(cb.like(cb.lower(stringPath), pattern));
    }
    return cb.or(ors.toArray(Predicate[]::new));
  }

  private Predicate buildUnmappedJoins(
      SearchRequest req, Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb
  ) {
    if (req.unmappedJoins() == null || req.unmappedJoins().isEmpty()) {
      return null;
    }
    List<Predicate> ps = new ArrayList<>(req.unmappedJoins().size());
    for (UnmappedJoin uj : req.unmappedJoins()) {
      ps.add(UnmappedJoinResolver.resolve(uj, root, query, cb, metadata));
    }
    return cb.and(ps.toArray(Predicate[]::new));
  }

  private Predicate combine(CriteriaBuilder cb, LogicalOperator topOp, List<Predicate> active) {
    if (active.isEmpty()) {
      return cb.conjunction();
    }
    if (active.size() == 1) {
      return active.get(0);
    }
    Predicate[] arr = active.toArray(Predicate[]::new);
    return switch (topOp == null ? LogicalOperator.AND : topOp) {
      case AND -> cb.and(arr);
      case OR -> cb.or(arr);
      case NOT -> cb.not(cb.and(arr));
    };
  }
}
