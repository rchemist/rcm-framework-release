/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.Direction;
import io.rchemist.core.search.NormalSortInfo;
import io.rchemist.core.search.PrioritySortInfo;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SortInfo;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — {@link SortInfo} sealed (NormalSortInfo / PrioritySortInfo) → JPA Criteria
 * {@link Order} 변환 (청사진 §5.5.6). 사용자 피드백 정합 — direction × NULLS FIRST/LAST × JoinType ×
 * Priority CASE WHEN 매트릭스 + filter ↔ sort JOIN alias 공유.
 *
 * <p>핵심 책임:
 * <ul>
 *   <li>{@link JoinAliasManager} 공유 — filter 가 만든 author JOIN 을 sort 가 그대로 재사용 (silent
 *       alias 중복 방지)</li>
 *   <li>NULLS FIRST/LAST — 표준 JPA {@code CriteriaBuilder} 에 nullsFirst/nullsLast 가 없어
 *       {@code CASE WHEN expr IS NULL THEN 0 ELSE 1 END} secondary order 로 구현 (DBMS 무관 + Hibernate
 *       API 의존 0)</li>
 *   <li>Priority CASE WHEN — {@code CASE WHEN field = priorityValue THEN 0 ELSE 1 END} secondary sort
 *       앞에 추가 (priority 가 가장 위, 그 다음 direction)</li>
 *   <li>다단 path ({@code author.department.name}) chain JOIN 자동</li>
 * </ul>
 */
final class SortBuilder {

  private SortBuilder() {
  }

  static List<Order> build(SearchRequest req, JoinAliasManager joins, CriteriaBuilder cb) {
    List<Order> orders = new ArrayList<>(req.sorts().size() * 3);
    for (SortInfo s : req.sorts()) {
      switch (s) {
        case NormalSortInfo normal -> appendNormal(orders, normal, joins, cb);
        case PrioritySortInfo priority -> appendPriority(orders, priority, joins, cb);
      }
    }
    return orders;
  }

  private static void appendNormal(
      List<Order> out, NormalSortInfo s, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    Path<?> path = joins.resolvePath(s.field(), s.joinType());
    appendNulls(out, path, s.nullsFirst(), cb);
    out.add(direction(s.direction(), path, cb));
  }

  private static void appendPriority(
      List<Order> out, PrioritySortInfo s, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    Path<?> path = joins.resolvePath(s.field(), s.joinType());
    Expression<Integer> caseExpr = cb.<Integer>selectCase()
        .when(cb.equal(path, s.priorityValue()), 0)
        .otherwise(1)
        .as(Integer.class);
    out.add(s.direction() == Direction.DESC ? cb.desc(caseExpr) : cb.asc(caseExpr));
    appendNulls(out, path, s.nullsFirst(), cb);
    out.add(direction(s.direction(), path, cb));
  }

  /**
   * NULLS FIRST/LAST — {@code CASE WHEN path IS NULL THEN ... END} secondary order 추가.
   * <ul>
   *   <li>nullsFirst=true → {@code CASE WHEN ... IS NULL THEN 0 ELSE 1 END ASC} (NULL 이 위)</li>
   *   <li>nullsFirst=false → {@code CASE WHEN ... IS NULL THEN 1 ELSE 0 END ASC} (NULL 이 아래)</li>
   *   <li>nullsFirst=null → 명시 default = NULLS LAST (DBMS 무관 일관성). PG/MSSQL 의 ASC default 와
   *       정합. MySQL 은 NULL 을 작은 값으로 취급해 ASC=FIRST 가 default 라 명시 적용로 일관 보장.</li>
   * </ul>
   */
  private static void appendNulls(
      List<Order> out, Path<?> path, Boolean nullsFirst, CriteriaBuilder cb
  ) {
    boolean effectiveFirst = nullsFirst != null && nullsFirst;
    int nullValue = effectiveFirst ? 0 : 1;
    int nonNullValue = effectiveFirst ? 1 : 0;
    Expression<Integer> nullCase = cb.<Integer>selectCase()
        .when(cb.isNull(path), nullValue)
        .otherwise(nonNullValue)
        .as(Integer.class);
    out.add(cb.asc(nullCase));
  }

  private static Order direction(Direction d, Expression<?> expr, CriteriaBuilder cb) {
    return d == Direction.DESC ? cb.desc(expr) : cb.asc(expr);
  }
}
