/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5b — JPA {@link AttributeConverter} for {@code Map<String, String>} that preserves
 * insertion order using {@link OrderedMapWrapper} (Hibernate dirty checking 정확도). 0.0.5 패턴 옮김
 * + Jackson 2 정합 (Phase 3 task #1 baseline).
 *
 * <p>jsonb 자동 매핑 (Hibernate 7 native {@code @JdbcTypeCode(SqlTypes.JSON)}) 은 PostgreSQL 의
 * binary 저장이라 키 순서 손실 — 순서 보존이 *진짜로 필요한 영역* 에서만 본 converter 적용. {@code TEXT}
 * 또는 {@code VARCHAR} 컬럼에 JSON 문자열로 저장.
 *
 * <p>Usage:
 * <pre>{@code
 * @Convert(converter = OrderedMapAttributeConverter.class)
 * @Column(columnDefinition = "TEXT")
 * private Map<String, String> attributes;
 * }</pre>
 *
 * <p>{@code autoApply = false} — 사용자가 명시적으로 {@code @Convert} 적용. silent global apply 차단.
 *
 * <p>**smart quotes recovery fallback**: macOS 의 "Smart Quotes" 자동 변환, 한글 IME, 워드/메신저
 * 복사 등으로 DB UPDATE 시 들어간 typographic quotes (U+201C/U+201D 등) 를 ASCII 따옴표로 정규화 후
 * 재시도. 정상 직렬화 path 에서는 hot path 비용 0 (catch 안에서만 동작).
 **/
@Converter(autoApply = false)
public class OrderedMapAttributeConverter implements AttributeConverter<Map<String, String>, String> {

  private static final Logger log = LoggerFactory.getLogger(OrderedMapAttributeConverter.class);
  private static final ObjectMapper objectMapper = new ObjectMapper();
  private static final TypeReference<LinkedHashMap<String, String>> TYPE_REF =
      new TypeReference<LinkedHashMap<String, String>>() {};

  @Override
  public String convertToDatabaseColumn(Map<String, String> attribute) {
    if (attribute == null || attribute.isEmpty()) {
      return null;
    }
    try {
      return objectMapper.writeValueAsString(attribute);
    } catch (JsonProcessingException e) {
      log.error("Failed to serialize Map to JSON", e);
      return null;
    }
  }

  @Override
  public Map<String, String> convertToEntityAttribute(String dbData) {
    if (dbData == null || dbData.isEmpty()) {
      return new OrderedMapWrapper();
    }
    try {
      LinkedHashMap<String, String> map = objectMapper.readValue(dbData, TYPE_REF);
      return new OrderedMapWrapper(map);
    } catch (IOException primaryError) {
      String normalized = normalizeQuotes(dbData);
      if (!normalized.equals(dbData)) {
        try {
          LinkedHashMap<String, String> map = objectMapper.readValue(normalized, TYPE_REF);
          log.warn(
              "OrderedMap JSON recovered via quote normalization. Source DB value contains "
                  + "non-ASCII quotes (e.g. U+201C/U+201D) and should be repaired: {}",
              dbData);
          return new OrderedMapWrapper(map);
        } catch (IOException ignored) {
          // 정규화 후에도 실패 → 원본 오류로 보고.
        }
      }
      log.error("Failed to deserialize OrderedMap JSON: {}", dbData, primaryError);
      return new OrderedMapWrapper();
    }
  }

  /**
   * Replace common typographic (smart) quotes with ASCII equivalents so JSON parsing can succeed
   * for legacy / manually-edited DB rows containing U+201C/U+201D/U+2018/U+2019.
   */
  private static String normalizeQuotes(String s) {
    return s.replace('“', '"') // LEFT DOUBLE QUOTATION MARK
        .replace('”', '"') // RIGHT DOUBLE QUOTATION MARK
        .replace('‘', '\'') // LEFT SINGLE QUOTATION MARK
        .replace('’', '\''); // RIGHT SINGLE QUOTATION MARK
  }
}
