/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Predicate;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — {@link SearchRequestPlanner} 의 결과 (청사진 §5.5.4 + §5.5.5).
 *
 * <p>{@code Specification<T>} 패턴 정합 — Consumer 가 단일 record 로 받아서 Repository CriteriaQuery 에
 * 바로 적용:
 * <ul>
 *   <li>{@link #predicate} → {@code query.where(predicate)}</li>
 *   <li>{@link #orders} → {@code query.orderBy(orders)}</li>
 *   <li>{@link #distinct} → {@code query.distinct(distinct)} (OneToMany/ManyToMany JOIN 감지 시 자동
 *       true — 사용자 피드백 정합)</li>
 * </ul>
 *
 * @param predicate 24 QueryConditionType + AND/OR/Not 트리 + UnmappedJoin SubQuery 종합 predicate
 * @param orders    sort path / direction / NULLS FIRST/LAST / JoinType / Priority CASE WHEN 종합
 * @param distinct  ONE_TO_MANY / ManyToMany JOIN 발견 시 자동 true (DISTINCT 강제)
 */
public record PlannedQuery(
    Predicate predicate,
    List<Order> orders,
    boolean distinct
) {
  public PlannedQuery {
    orders = orders == null ? List.of() : List.copyOf(orders);
  }
}
