/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #6 — entity-level cache 전략 명시 annotation. {@link AbstractCrudService} 가 entity
 * class 의 본 annotation 인식 후 {@link CacheStrategyResolver} 위임 — yml ({@code platform.cache.<region>.*})
 * override 가 우선이고, annotation 은 default fallback.
 *
 * <p>property 의 빈 값 (default) = global default 따라감 (Phase 4 task #5 의 {@link CacheProperties}).
 *
 * <p>예:
 * <pre>{@code
 * @Cacheable
 * @CacheStrategy(strategy = WRITE_THROUGH, ttl = "PT2H", entityMaxSize = 5000)
 * @Entity
 * public class Article implements io.rchemist.core.marker.Cacheable, io.rchemist.core.marker.Searchable { ... }
 * }</pre>
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CacheStrategy {

  /** entity_cache region name override. 빈 값 = {@code <entity-simple-name-lowercase>_entity_cache}. */
  String region() default "";

  /** ISO 8601 duration string (예: {@code "PT1H"} / {@code "PT30M"}). 빈 값 = global default. */
  String ttl() default "";

  /** entity_cache max size. 0 = global default. */
  long entityMaxSize() default 0L;

  /** search_list_cache max size. 0 = global default. */
  long searchMaxSize() default 0L;

  /** write 전략. */
  CacheWriteStrategy strategy() default CacheWriteStrategy.READ_THROUGH;
}
