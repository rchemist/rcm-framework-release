/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.core.context.TenantContext;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — Hibernate 7 {@link CurrentTenantIdentifierResolver}{@code <String>} baseline.
 * {@link TenantContext} ScopedValue 적용 시 그 tenantId 반환, 미적용 시 {@link
 * TenantContext#SYSTEM_TENANT_ID} fallback (Background task / @Scheduled / Bootstrap 영역 정합 —
 * Decision #17).
 *
 * <p>{@code validateExistingCurrentSessions()} = {@code false} (Phase 3 baseline) — 같은 session
 * 내 tenant 변경 시 validation 부담 회피, framework 가 명시적 tenant scope 보장.
 **/
public class TenantIdentifierResolver implements CurrentTenantIdentifierResolver<String> {

  @Override
  public String resolveCurrentTenantIdentifier() {
    String id = TenantContext.currentTenantIdOrNull();
    return id != null ? id : TenantContext.SYSTEM_TENANT_ID;
  }

  @Override
  public boolean validateExistingCurrentSessions() {
    return false;
  }
}
