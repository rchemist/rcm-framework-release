/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.FilterClassification;
import io.rchemist.core.search.JoinType;
import jakarta.persistence.criteria.From;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Root;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — JOIN alias 재사용 + 다단 path chain JOIN + JoinType 충돌 해소 (사용자 피드백 정합,
 * 청사진 §5.5.6 + 0.0.5 {@code unmappedJoinPaths} 흡수).
 *
 * <p>핵심 책임:
 * <ul>
 *   <li>같은 path prefix 는 같은 {@link From} 재사용 — filter 의 {@code author.id} + sort 의
 *       {@code author.name} 이 *동일 author JOIN* 공유 (silent alias 중복 방지)</li>
 *   <li>다단 path ({@code customer.user.name}) chain JOIN 자동 — {@code root.join("customer").join("user")}
 *       적용, leaf path 는 {@link Path#get(String)}</li>
 *   <li>JoinType 충돌 시 LEFT 우선 — NULL 보존 안전 (filter INNER + sort LEFT = LEFT, filter LEFT + sort
 *       INNER = LEFT)</li>
 *   <li>ONE_TO_MANY/ManyToMany JOIN 감지 — {@link #hasCollectionJoin()} = true → planner 가
 *       {@link PlannedQuery#distinct()} = true 적용</li>
 * </ul>
 *
 * <p>thread-unsafe — 단일 query 빌드 lifecycle 안에서만 사용. {@link SearchRequestPlanner} 가
 * 매 plan() 호출마다 신규 instance 적용.
 */
public class JoinAliasManager {

  private final Root<?> root;
  private final EntityMetadata<?> metadata;
  private final Map<String, From<?, ?>> joinCache = new HashMap<>();
  private final Map<String, jakarta.persistence.criteria.JoinType> typeCache = new HashMap<>();
  private boolean hasCollectionJoin = false;

  public JoinAliasManager(Root<?> root, EntityMetadata<?> metadata) {
    this.root = Objects.requireNonNull(root, "root");
    this.metadata = Objects.requireNonNull(metadata, "metadata");
  }

  /**
   * 다단 path 의 leaf {@link Path} 반환 — 중간 단계는 chain JOIN, 마지막은 column path.
   *
   * <p>예: {@code "author.department.name"} → {@code root.join("author").join("department").get("name")}.
   * {@code "title"} 같은 단일 column → {@code root.get("title")}.
   *
   * <p>JSON path ({@code "attributes.lang"}) 는 root path {@code attributes} 만 반환 — JSON 영역의
   * 상세 path 처리는 {@link FilterDispatcher} 의 {@code JSON_CONTAINS} branch 가 담당.
   *
   * @param fieldPath dot-separated entity property path
   * @param joinType  요청 JoinType (null = INNER default)
   */
  @SuppressWarnings("unchecked")
  public Path<?> resolvePath(String fieldPath, JoinType joinType) {
    Objects.requireNonNull(fieldPath, "fieldPath");
    String[] parts = fieldPath.split("\\.");
    if (parts.length == 1) {
      // 단일 column.
      return root.get(parts[0]);
    }
    // JSON path 가 root metadata 에 적용됐으면 root.get(json column) 으로 단축.
    if (metadata.isJsonAttribute(fieldPath)) {
      return root.get(parts[0]);
    }
    // multi-segment path — 마지막 segment 직전까지 chain JOIN.
    From<?, ?> current = root;
    StringBuilder accum = new StringBuilder();
    for (int i = 0; i < parts.length - 1; i++) {
      if (i > 0) {
        accum.append('.');
      }
      accum.append(parts[i]);
      String key = accum.toString();
      jakarta.persistence.criteria.JoinType resolvedType = resolveJoinType(joinType, key, parts[i]);
      From<?, ?> existing = joinCache.get(key);
      if (existing == null || resolvedType != typeCache.get(key)) {
        // 처음 적용 또는 LEFT 로 upgrade — re-join 후 cache 교체.
        From<?, ?> joined = current.join(parts[i], resolvedType);
        joinCache.put(key, joined);
        typeCache.put(key, resolvedType);
        if (isCollectionAssociation(parts[i])) {
          hasCollectionJoin = true;
        }
        current = joined;
      } else {
        current = existing;
      }
    }
    return current.get(parts[parts.length - 1]);
  }

  /**
   * 명시 JOIN ({@link UnmappedJoinResolver} 또는 mappedJoinFilters 등) — leaf path 가 아닌 {@link From}
   * 자체를 반환. {@code resolvePath} 와 동일 cache 공유 (sort path 와 정합).
   */
  public From<?, ?> resolveJoin(String fieldPath, JoinType joinType) {
    Objects.requireNonNull(fieldPath, "fieldPath");
    String[] parts = fieldPath.split("\\.");
    From<?, ?> current = root;
    StringBuilder accum = new StringBuilder();
    for (int i = 0; i < parts.length; i++) {
      if (i > 0) {
        accum.append('.');
      }
      accum.append(parts[i]);
      String key = accum.toString();
      jakarta.persistence.criteria.JoinType resolvedType = resolveJoinType(joinType, key, parts[i]);
      From<?, ?> existing = joinCache.get(key);
      if (existing == null || resolvedType != typeCache.get(key)) {
        From<?, ?> joined = current.join(parts[i], resolvedType);
        joinCache.put(key, joined);
        typeCache.put(key, resolvedType);
        if (isCollectionAssociation(parts[i])) {
          hasCollectionJoin = true;
        }
        current = joined;
      } else {
        current = existing;
      }
    }
    return current;
  }

  /**
   * JoinType 충돌 해소 — LEFT 우선 (NULL 보존 안전).
   * <ul>
   *   <li>이미 LEFT 적용 → 그대로 LEFT (downgrade 거부)</li>
   *   <li>이미 INNER + 새 LEFT 요청 → LEFT 로 upgrade</li>
   *   <li>이미 RIGHT + 새 INNER → 그대로 RIGHT (사용자 의도 보존)</li>
   *   <li>새 alias = 요청 그대로 (default INNER)</li>
   * </ul>
   */
  private jakarta.persistence.criteria.JoinType resolveJoinType(
      JoinType requested, String key, String segment
  ) {
    jakarta.persistence.criteria.JoinType requestedJpa = toJpa(requested);
    jakarta.persistence.criteria.JoinType existing = typeCache.get(key);
    if (existing == null) {
      // 첫 적용 — collection association 이면 자동 LEFT 권장 (DISTINCT 와 정합).
      if (isCollectionAssociation(segment)
          && requestedJpa == jakarta.persistence.criteria.JoinType.INNER) {
        return jakarta.persistence.criteria.JoinType.LEFT;
      }
      return requestedJpa;
    }
    if (existing == jakarta.persistence.criteria.JoinType.LEFT
        || requestedJpa == jakarta.persistence.criteria.JoinType.LEFT) {
      return jakarta.persistence.criteria.JoinType.LEFT;
    }
    // RIGHT + INNER 충돌 = RIGHT 보존 (드문 케이스).
    if (existing == jakarta.persistence.criteria.JoinType.RIGHT) {
      return jakarta.persistence.criteria.JoinType.RIGHT;
    }
    return existing;
  }

  /**
   * Collection association 검사 — metadata 의 root field 를 본다 (다단 path 의 첫 segment).
   */
  private boolean isCollectionAssociation(String segment) {
    FilterClassification c = metadata.classify(segment);
    return c == FilterClassification.ONE_TO_MANY;
  }

  static jakarta.persistence.criteria.JoinType toJpa(JoinType j) {
    if (j == null) {
      return jakarta.persistence.criteria.JoinType.INNER;
    }
    return switch (j) {
      case INNER -> jakarta.persistence.criteria.JoinType.INNER;
      case LEFT -> jakarta.persistence.criteria.JoinType.LEFT;
      case RIGHT -> jakarta.persistence.criteria.JoinType.RIGHT;
    };
  }

  /** ONE_TO_MANY / ManyToMany JOIN 발견 여부 — DISTINCT 자동 트리거 영역. */
  public boolean hasCollectionJoin() {
    return hasCollectionJoin;
  }

  public Root<?> root() {
    return root;
  }

  public EntityMetadata<?> metadata() {
    return metadata;
  }
}
