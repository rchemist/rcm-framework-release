/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6h — Filter / Sort path 영역에서 SQL 표준 함수 호출 인식 + JPA Criteria Expression 변환.
 *
 * <p>baseline whitelist (DBMS 무관 SQL:2003 표준):
 * <ul>
 *   <li>String: {@code lower(x)}, {@code upper(x)}, {@code trim(x)}, {@code length(x)},
 *       {@code concat(a, b, ...)}</li>
 *   <li>Date: {@code extract_year(x)}, {@code extract_month(x)}, {@code extract_day(x)}</li>
 *   <li>Math: {@code abs(x)}, {@code round(x)}, {@code ceil(x)}, {@code floor(x)}</li>
 *   <li>Conditional: {@code coalesce(a, b, ...)}</li>
 * </ul>
 *
 * <p>화이트리스트 외 함수 = SQL injection 거부 = fail-loud.
 *
 * <p>입력 영역 = "func(arg1, arg2, ...)" 단순 string. 인자 = entity property path 또는 literal
 * ({@code 'string'} or numeric).
 */
public final class ExpressionResolver {

  private ExpressionResolver() {
  }

  /** 함수 호출 패턴 매칭 — {@code "func(args)"}. */
  public static boolean isFunctionCall(String name) {
    if (name == null) {
      return false;
    }
    int open = name.indexOf('(');
    int close = name.lastIndexOf(')');
    return open > 0 && close == name.length() - 1;
  }

  /**
   * 함수 expression → JPA Criteria Expression. 화이트리스트 외 함수 = IllegalArgumentException.
   */
  public static Expression<?> resolve(
      String expression, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    String func = parseFunctionName(expression);
    List<String> args = parseArgs(expression);

    return switch (func.toLowerCase()) {
      case "lower" -> cb.lower(stringArg(args, 0, joins));
      case "upper" -> cb.upper(stringArg(args, 0, joins));
      case "trim" -> cb.trim(stringArg(args, 0, joins));
      case "length" -> cb.length(stringArg(args, 0, joins));
      case "concat" -> concat(args, joins, cb);
      case "extract_year" -> extract(args, "YEAR", joins, cb);
      case "extract_month" -> extract(args, "MONTH", joins, cb);
      case "extract_day" -> extract(args, "DAY", joins, cb);
      case "abs" -> cb.abs(numericArg(args, 0, joins));
      case "round" -> roundFn(args, joins, cb);
      case "ceil" -> cb.<Number>function("ceil", Number.class, numericArg(args, 0, joins));
      case "floor" -> cb.<Number>function("floor", Number.class, numericArg(args, 0, joins));
      case "coalesce" -> coalesce(args, joins, cb);
      default -> throw new IllegalArgumentException(
          "지원되지 않는 함수: '" + func + "'. 화이트리스트: lower, upper, trim, length, concat, "
              + "extract_year, extract_month, extract_day, abs, round, ceil, floor, coalesce");
    };
  }

  static String parseFunctionName(String expression) {
    int open = expression.indexOf('(');
    return expression.substring(0, open).trim();
  }

  static List<String> parseArgs(String expression) {
    int open = expression.indexOf('(');
    int close = expression.lastIndexOf(')');
    String inside = expression.substring(open + 1, close).trim();
    if (inside.isEmpty()) {
      return List.of();
    }
    List<String> out = new ArrayList<>();
    int depth = 0;
    boolean quoted = false;
    int last = 0;
    for (int i = 0; i < inside.length(); i++) {
      char c = inside.charAt(i);
      if (c == '\'') {
        quoted = !quoted;
      } else if (!quoted) {
        if (c == '(') {
          depth++;
        } else if (c == ')') {
          depth--;
        } else if (c == ',' && depth == 0) {
          out.add(inside.substring(last, i).trim());
          last = i + 1;
        }
      }
    }
    out.add(inside.substring(last).trim());
    return out;
  }

  @SuppressWarnings("unchecked")
  private static Expression<String> stringArg(
      List<String> args, int index, JoinAliasManager joins
  ) {
    String raw = args.get(index);
    if (isStringLiteral(raw)) {
      throw new IllegalArgumentException(
          "string literal 은 함수 인자 영역에서 받지 않음 — entity path 만 박아라: " + raw);
    }
    return (Expression<String>) joins.resolvePath(raw, null);
  }

  @SuppressWarnings("unchecked")
  private static Expression<Number> numericArg(
      List<String> args, int index, JoinAliasManager joins
  ) {
    String raw = args.get(index);
    return (Expression<Number>) joins.resolvePath(raw, null);
  }

  @SuppressWarnings("unchecked")
  private static Expression<Object> anyArg(
      List<String> args, int index, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    String raw = args.get(index);
    if (isStringLiteral(raw)) {
      return (Expression<Object>) (Expression<?>) cb.literal(stripQuotes(raw));
    }
    return (Expression<Object>) joins.resolvePath(raw, null);
  }

  private static boolean isStringLiteral(String raw) {
    return raw.length() >= 2 && raw.startsWith("'") && raw.endsWith("'");
  }

  private static String stripQuotes(String raw) {
    return raw.substring(1, raw.length() - 1);
  }

  @SuppressWarnings("unchecked")
  private static Expression<String> concat(
      List<String> args, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    if (args.size() < 2) {
      throw new IllegalArgumentException("concat 은 최소 2 인자: " + args);
    }
    Expression<String> result = stringOrLiteral(args.get(0), joins, cb);
    for (int i = 1; i < args.size(); i++) {
      result = cb.concat(result, stringOrLiteral(args.get(i), joins, cb));
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  private static Expression<String> stringOrLiteral(
      String raw, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    if (isStringLiteral(raw)) {
      return cb.literal(stripQuotes(raw));
    }
    return (Expression<String>) joins.resolvePath(raw, null);
  }

  private static Expression<Integer> extract(
      List<String> args, String unit, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    Path<?> path = joins.resolvePath(args.get(0), null);
    return cb.function("extract_" + unit.toLowerCase(), Integer.class, path);
  }

  private static Expression<? extends Number> roundFn(
      List<String> args, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    Expression<Number> arg = numericArg(args, 0, joins);
    if (args.size() >= 2) {
      Integer scale = Integer.parseInt(args.get(1).trim());
      return cb.function("round", Number.class, arg, cb.literal(scale));
    }
    return cb.function("round", Number.class, arg);
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Expression<?> coalesce(
      List<String> args, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    if (args.size() < 2) {
      throw new IllegalArgumentException("coalesce 는 최소 2 인자");
    }
    Expression<?> firstExpr = anyArg(List.of(args.get(0)), 0, joins, cb);
    Class<?> resultType = firstExpr.getJavaType();
    CriteriaBuilder.Coalesce coalesce = cb.coalesce();
    for (String arg : args) {
      coalesce = coalesce.value(anyArg(List.of(arg), 0, joins, cb));
    }
    if (resultType != null && resultType != Object.class) {
      return ((Expression<Object>) coalesce).as((Class<Object>) resultType);
    }
    return coalesce;
  }
}
