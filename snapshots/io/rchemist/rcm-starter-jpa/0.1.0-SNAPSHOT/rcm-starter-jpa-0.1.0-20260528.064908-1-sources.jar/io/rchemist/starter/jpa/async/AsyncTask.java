/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — Decision #13 의 method-level async hint annotation. {@code timeout} (ISO 8601 duration)
 * + {@code retry} (최대 retry 횟수). 본 annotation 자체는 metadata + {@link AsyncJobTracker} 의 추적 영역
 * 을 위한 hook — 실제 실행 영역은 Spring 의 {@code @Async} (Spring Boot 4 default = VirtualThread executor,
 * Decision #28).
 *
 * <p>Phase 4 baseline = annotation 정의 + tracker 결합 영역 SPI 노출. AOP 결합 (자동 retry / timeout enforcement)
 * 은 Phase 5 또는 Consumer 가 자체 적용 영역.
 **/
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AsyncTask {

  /** ISO 8601 duration string (예: {@code "PT10M"} / {@code "PT1H"}). */
  String timeout() default "PT10M";

  /** 최대 retry 횟수 (0 = 재시도 없음, default 3). */
  int retry() default 3;

  /** job type label — {@link AsyncJobTracker} 의 검색 영역. 빈 값 = method 명. */
  String type() default "";
}
