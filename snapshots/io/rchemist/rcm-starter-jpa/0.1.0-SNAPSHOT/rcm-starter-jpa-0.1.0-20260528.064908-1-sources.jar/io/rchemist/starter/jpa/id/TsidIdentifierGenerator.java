/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.id;

import io.hypersistence.tsid.TSID;
import java.lang.reflect.Member;
import java.util.EnumSet;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.generator.EventType;
import org.hibernate.generator.EventTypeSets;
import org.hibernate.generator.GeneratorCreationContext;
import org.hibernate.id.IdentifierGenerator;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Hibernate 7 {@link IdentifierGenerator} — {@link TsidGenerator} annotation 이 trigger.
 *
 * <p>필드 타입 자동 변환:
 * <ul>
 *   <li>{@code Long} / {@code long} → {@link TSID#toLong()}</li>
 *   <li>{@code String} → {@link TSID#toString()} (Crockford base 32, 13 char)</li>
 *   <li>{@code TSID} → instance 그대로</li>
 * </ul>
 *
 * <p>스레드 안전성: {@link TSID.Factory} 는 thread-safe (내부 atomic counter).
 **/
public class TsidIdentifierGenerator implements IdentifierGenerator {

    private final TSID.Factory factory;
    private final Class<?> targetType;

    public TsidIdentifierGenerator(
            TsidGenerator config, Member member, GeneratorCreationContext creationContext) {
        TSID.Factory.Builder builder = TSID.Factory.builder();
        if (config.node() >= 0) {
            builder = builder.withNode(config.node());
        }
        this.factory = builder.build();
        this.targetType = resolveType(member);
    }

    private static Class<?> resolveType(Member member) {
        if (member instanceof java.lang.reflect.Field f) {
            return f.getType();
        }
        if (member instanceof java.lang.reflect.Method m) {
            return m.getReturnType();
        }
        return Long.class;
    }

    @Override
    public Object generate(SharedSessionContractImplementor session, Object owner) {
        TSID tsid = factory.generate();
        if (targetType == String.class) {
            return tsid.toString();
        }
        if (targetType == TSID.class) {
            return tsid;
        }
        return tsid.toLong();
    }

    @Override
    public EnumSet<EventType> getEventTypes() {
        return EventTypeSets.INSERT_ONLY;
    }
}
