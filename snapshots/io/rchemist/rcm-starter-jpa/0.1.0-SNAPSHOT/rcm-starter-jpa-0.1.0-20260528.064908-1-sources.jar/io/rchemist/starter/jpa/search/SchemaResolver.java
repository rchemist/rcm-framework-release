/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FieldDescriptor;
import io.rchemist.core.search.FilterClassification;
import io.rchemist.core.search.QueryConditionType;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #7 — {@code GET /{path}/search/schema} discovery 응답 영역. APT 가 컴파일 시점에 생성한
 * {@link EntityMetadata} 를 frontend {@code rcm-listgrid} 가 인식 가능한 JSON 모양으로 변환.
 *
 * <p>응답 shape (Map 으로 그대로 직렬화):
 * <ul>
 *   <li>{@code entity} — entity simple name</li>
 *   <li>{@code fields} — APT 등록 순서 그대로의 필드 이름 list</li>
 *   <li>{@code types} — 필드 → 타입 FQN map (frontend 가 input control type 결정)</li>
 *   <li>{@code classifications} — 필드 → {@link FilterClassification} enum name map</li>
 *   <li>{@code supportedConditions} — 필드 → 적용 가능한 24
 *       {@link QueryConditionType} 부분집합 (frontend 가 condition selector 자동 generation)</li>
 *   <li>{@code searchable} / {@code sortable} 필드 list</li>
 *   <li>{@code autoMarker} — Auditable / SoftDelete / TenantAlias marker 가 자동 주입한 필드</li>
 *   <li>{@code jsonAttributes} — JSON column 필드 list (jsonb path 자동 인식 영역)</li>
 * </ul>
 *
 * <p>{@link QueryConditionType} 매트릭스 — 필드 type + classification 조합:
 * <ul>
 *   <li>String — EQUAL/NOT_EQUAL/IN/NOT_IN/LIKE/NOT_LIKE/IS_NULL/IS_NOT_NULL/IS_BLANK/IS_NOT_BLANK
 *       /NULL_OR_EQUAL/NULL_OR_BLANK</li>
 *   <li>Number (Integer/Long/Double/BigDecimal/...) —
 *       EQUAL/NOT_EQUAL/IN/NOT_IN/GREATER_THAN/.../LESS_THAN_EQUAL/BETWEEN/IN_RANGE/NOT_IN_RANGE
 *       /IS_NULL/IS_NOT_NULL/NULL_OR_EQUAL</li>
 *   <li>Temporal (Instant/LocalDate/...) — Number 매트릭스 + DATE_BEFORE/DATE_AFTER/DATE_BETWEEN</li>
 *   <li>Boolean — EQUAL/NOT_EQUAL/IS_NULL/IS_NOT_NULL</li>
 *   <li>Enum — EQUAL/NOT_EQUAL/IN/NOT_IN/IS_NULL/IS_NOT_NULL/NULL_OR_EQUAL</li>
 *   <li>UUID — Enum 매트릭스 정합</li>
 *   <li>JSON_ATTRIBUTE classification — JSON_CONTAINS/EQUAL/NOT_EQUAL/IS_NULL/IS_NOT_NULL</li>
 *   <li>MANY_TO_ONE / ONE_TO_MANY / EMBEDDED — EXISTS/IS_NULL/IS_NOT_NULL (자세한 nested
 *       path 검색은 sub-field schema 활용)</li>
 *   <li>그 외 — EQUAL/NOT_EQUAL/IS_NULL/IS_NOT_NULL minimal fallback</li>
 * </ul>
 *
 * <p>runtime reflection 0 — APT 가 적용한 {@link FieldDescriptor} 메타데이터만 활용.
 */
public final class SchemaResolver {

  /** {@link EntityMetadataRegistry} lookup → 미등록 시 fail loud. */
  public Map<String, Object> resolve(Class<?> entityClass) {
    return resolve(EntityMetadataRegistry.require(entityClass));
  }

  /** 직접 metadata 인스턴스 적용 — registry 미경유 path (test fixture / starter-web 직접 wire 영역). */
  public Map<String, Object> resolve(EntityMetadata<?> metadata) {
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("entity", metadata.entityName());

    List<String> fields = new ArrayList<>();
    Map<String, String> types = new LinkedHashMap<>();
    Map<String, String> classifications = new LinkedHashMap<>();
    Map<String, List<String>> supportedConditions = new LinkedHashMap<>();
    List<String> searchable = new ArrayList<>();
    List<String> sortable = new ArrayList<>();
    List<String> autoMarker = new ArrayList<>();
    List<String> jsonAttributes = new ArrayList<>();

    for (FieldDescriptor<?, ?> f : metadata.fields()) {
      String name = f.name();
      fields.add(name);
      types.put(name, f.type().getName());
      classifications.put(name, f.classification().name());
      supportedConditions.put(name, supportedConditions(f).stream()
          .map(Enum::name).toList());
      if (f.searchable()) {
        searchable.add(name);
      }
      if (f.sortable()) {
        sortable.add(name);
      }
      if (f.autoMarker()) {
        autoMarker.add(name);
      }
      if (f.classification() == FilterClassification.JSON_ATTRIBUTE) {
        jsonAttributes.add(name);
      }
    }

    out.put("fields", fields);
    out.put("types", types);
    out.put("classifications", classifications);
    out.put("supportedConditions", supportedConditions);
    out.put("searchable", searchable);
    out.put("sortable", sortable);
    out.put("autoMarker", autoMarker);
    out.put("jsonAttributes", jsonAttributes);
    return out;
  }

  /** {@link FieldDescriptor} 의 type + classification 조합 → 적용 가능한 24 condition 부분집합. */
  public Set<QueryConditionType> supportedConditions(FieldDescriptor<?, ?> field) {
    return supportedConditions(field.type(), field.classification());
  }

  /** type + classification 매트릭스 진입점 — 직접 호출 가능 (Consumer 자체 schema 확장 영역). */
  public Set<QueryConditionType> supportedConditions(
      Class<?> type, FilterClassification classification) {
    if (classification == FilterClassification.JSON_ATTRIBUTE) {
      return ordered(
          QueryConditionType.JSON_CONTAINS,
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL);
    }
    if (classification == FilterClassification.MANY_TO_ONE
        || classification == FilterClassification.ONE_TO_MANY
        || classification == FilterClassification.EMBEDDED) {
      return ordered(
          QueryConditionType.EXISTS,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL);
    }

    if (type == Boolean.class || type == boolean.class) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL);
    }
    if (CharSequence.class.isAssignableFrom(type)) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IN,
          QueryConditionType.NOT_IN,
          QueryConditionType.LIKE,
          QueryConditionType.NOT_LIKE,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL,
          QueryConditionType.IS_BLANK,
          QueryConditionType.IS_NOT_BLANK,
          QueryConditionType.NULL_OR_EQUAL,
          QueryConditionType.NULL_OR_BLANK);
    }
    if (Number.class.isAssignableFrom(type) || isPrimitiveNumeric(type)) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IN,
          QueryConditionType.NOT_IN,
          QueryConditionType.GREATER_THAN,
          QueryConditionType.GREATER_THAN_EQUAL,
          QueryConditionType.LESS_THAN,
          QueryConditionType.LESS_THAN_EQUAL,
          QueryConditionType.BETWEEN,
          QueryConditionType.IN_RANGE,
          QueryConditionType.NOT_IN_RANGE,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL,
          QueryConditionType.NULL_OR_EQUAL);
    }
    if (Temporal.class.isAssignableFrom(type)
        || Date.class.isAssignableFrom(type)
        || Calendar.class.isAssignableFrom(type)) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IN,
          QueryConditionType.NOT_IN,
          QueryConditionType.GREATER_THAN,
          QueryConditionType.GREATER_THAN_EQUAL,
          QueryConditionType.LESS_THAN,
          QueryConditionType.LESS_THAN_EQUAL,
          QueryConditionType.BETWEEN,
          QueryConditionType.DATE_BEFORE,
          QueryConditionType.DATE_AFTER,
          QueryConditionType.DATE_BETWEEN,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL,
          QueryConditionType.NULL_OR_EQUAL);
    }
    if (Enum.class.isAssignableFrom(type)) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IN,
          QueryConditionType.NOT_IN,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL,
          QueryConditionType.NULL_OR_EQUAL);
    }
    if (UUID.class == type) {
      return ordered(
          QueryConditionType.EQUAL,
          QueryConditionType.NOT_EQUAL,
          QueryConditionType.IN,
          QueryConditionType.NOT_IN,
          QueryConditionType.IS_NULL,
          QueryConditionType.IS_NOT_NULL,
          QueryConditionType.NULL_OR_EQUAL);
    }

    return ordered(
        QueryConditionType.EQUAL,
        QueryConditionType.NOT_EQUAL,
        QueryConditionType.IS_NULL,
        QueryConditionType.IS_NOT_NULL);
  }

  private static boolean isPrimitiveNumeric(Class<?> type) {
    return type == int.class
        || type == long.class
        || type == short.class
        || type == byte.class
        || type == double.class
        || type == float.class;
  }

  private static Set<QueryConditionType> ordered(QueryConditionType... values) {
    Set<QueryConditionType> set = new LinkedHashSet<>();
    for (QueryConditionType v : values) {
      set.add(v);
    }
    return set;
  }
}
