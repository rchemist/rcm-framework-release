/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.jpa;

import io.rchemist.starter.jpa.autoconfig.JsonTypeCustomizer;
import io.rchemist.starter.jpa.id.GeneratorAwareBeanContainerCustomizer;
import io.rchemist.starter.jpa.search.EntityMetadataInitializer;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * RCM Framework — JPA starter 진입점.
 *
 * <p>Phase 3 task #1 적용 — {@link JsonTypeCustomizer} 자동 등록 (Hibernate 7 JSON column 자동
 * 인식 baseline). 후속 Phase 3 task (audit / soft-delete / multi-tenant 3 전략 / search /
 * spatial / @DataSource / AbstractCrudService) 가 본 autoconfig 에 점진 추가.
 *
 * <p>Issue #21 fix — {@link GeneratorAwareBeanContainerCustomizer} 자동 등록. Spring Boot 4 +
 * Hibernate 7 의 {@code SpringBeanContainer} 가 {@code @IdGeneratorType} 마커 generator 를 Spring
 * DI 후보로 인식하여 EMF 부팅 단계에서 fail 하던 영역 우회.
 *
 * <p>Issue #25 fix — {@link EntityMetadataInitializer} 자동 등록. APT 산출 {@code
 * META-INF/services/io.rchemist.core.search.EntityMetadata} 의 모든 {@code <Entity>_Metadata} 가
 * application bootstrap 시점에 {@code ServiceLoader} 로 자동 적재 → consumer 가 자체 trigger 적용
 * 안 해도 list/search endpoint 의 EntityMetadataRegistry 등록 영역 자동 보장.
 **/
@AutoConfiguration
@ConditionalOnClass(name = {"jakarta.persistence.EntityManager", "org.hibernate.SessionFactory"})
public class StarterJpaAutoConfiguration {

  /**
   * Phase 3 task #1 — Hibernate 7 JSON column 자동 인식 customizer. {@code @ConditionalOnMissingBean}
   * (name 기반) 으로 Consumer 가 자체 customizer 제공 시 자동 교체.
   */
  @Bean(name = "rcmJpaJsonTypeCustomizer")
  @ConditionalOnMissingBean(name = "rcmJpaJsonTypeCustomizer")
  public HibernatePropertiesCustomizer rcmJpaJsonTypeCustomizer() {
    return new JsonTypeCustomizer();
  }

  /**
   * Issue #21 — Spring Boot 가 등록한 {@code SpringBeanContainer} 를 {@code
   * GeneratorAwareBeanContainer} 로 wrap. Hibernate 의 {@code @IdGeneratorType} generator 가 Spring
   * DI 우회 + Hibernate 의 special ctor (annotation, Member, GeneratorCreationContext) 정합 인스턴스화
   * 보장. {@code @ConditionalOnMissingBean} (name 기반) 으로 Consumer 가 자체 customizer 적용 시
   * 자동 양보.
   */
  @Bean(name = "rcmJpaGeneratorAwareBeanContainerCustomizer")
  @ConditionalOnMissingBean(name = "rcmJpaGeneratorAwareBeanContainerCustomizer")
  public HibernatePropertiesCustomizer rcmJpaGeneratorAwareBeanContainerCustomizer() {
    return new GeneratorAwareBeanContainerCustomizer();
  }

  /**
   * Issue #25 — APT 산출 {@code META-INF/services/io.rchemist.core.search.EntityMetadata} 의 모든
   * {@code <Entity>_Metadata} 를 application bootstrap 시점에 {@code java.util.ServiceLoader} 로 자동 적재.
   * Consumer 가 자체 trigger 적용 안 해도 모든 list/search endpoint 가 EntityMetadataRegistry 안
   * 등록 영역 사용 가능. {@code @ConditionalOnMissingBean} (type 기반) — Consumer 자체 Initializer
   * 보유 시 자동 양보.
   */
  @Bean
  @ConditionalOnMissingBean(EntityMetadataInitializer.class)
  public EntityMetadataInitializer rcmJpaEntityMetadataInitializer() {
    return new EntityMetadataInitializer();
  }
}
