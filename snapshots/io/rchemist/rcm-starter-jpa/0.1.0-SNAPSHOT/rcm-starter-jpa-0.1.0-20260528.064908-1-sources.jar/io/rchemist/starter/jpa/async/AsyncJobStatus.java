/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — Decision #13 의 async job lifecycle 상태. {@link AsyncJob} 의 status field.
 *
 * <p>전이 영역:
 * <ul>
 *   <li>{@link #QUEUED} → {@link #RUNNING} → ({@link #COMPLETED} | {@link #FAILED} | {@link #CANCELLED})</li>
 *   <li>{@link #FAILED} → ({@link #QUEUED} retry / {@link #DLQ} 최종 실패)</li>
 *   <li>terminal = COMPLETED / CANCELLED / DLQ</li>
 * </ul>
 **/
public enum AsyncJobStatus {

  QUEUED,

  RUNNING,

  COMPLETED,

  FAILED,

  CANCELLED,

  DLQ;

  public boolean isTerminal() {
    return this == COMPLETED || this == CANCELLED || this == DLQ;
  }
}
