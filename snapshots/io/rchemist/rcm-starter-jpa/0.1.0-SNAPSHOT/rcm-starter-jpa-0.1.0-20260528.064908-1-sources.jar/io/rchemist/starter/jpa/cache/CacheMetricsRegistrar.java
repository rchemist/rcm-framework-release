/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import com.github.benmanes.caffeine.cache.Cache;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #4 — Caffeine native cache 마다 Micrometer 의 {@link CaffeineCacheMetrics} 자동 binding.
 * dynamic cache 생성 시점 (예: {@link TwoTierCacheManager#createNativeCaffeineCache(String)}) 에서 본
 * registrar 의 {@link #register(String, Cache)} 호출 → 자동 노출.
 *
 * <p>중복 등록 회피 — region 별 1 회만 binding (concurrent 등록 가능).
 *
 * <p>노출 metric:
 * <ul>
 *   <li>{@code cache.gets{cache=...,result=hit/miss}}</li>
 *   <li>{@code cache.puts{cache=...}}</li>
 *   <li>{@code cache.evictions{cache=...}}</li>
 *   <li>{@code cache.size{cache=...}}</li>
 * </ul>
 **/
public class CacheMetricsRegistrar {

  private final MeterRegistry meterRegistry;
  private final Set<String> registered = ConcurrentHashMap.newKeySet();

  public CacheMetricsRegistrar(MeterRegistry meterRegistry) {
    this.meterRegistry = meterRegistry;
  }

  /** {@code (name, native cache)} → {@link CaffeineCacheMetrics} binding (idempotent). */
  public void register(String name, Cache<Object, Object> nativeCache) {
    if (!registered.add(name)) {
      return;
    }
    CaffeineCacheMetrics.monitor(meterRegistry, nativeCache, name, Tags.empty());
  }

  public boolean isRegistered(String name) {
    return registered.contains(name);
  }
}
