/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import io.rchemist.core.marker.Cacheable;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.metamodel.EntityType;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import org.springframework.beans.factory.InitializingBean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #1 — JPA metamodel 에 등록된 entity 중 {@link Cacheable} marker implement 영역만 자동
 * 인식. {@link CacheRegionFactory} 가 본 registry 를 활용해서 2-tier region 자동 생성 (task #2). 본
 * baseline 은 marker 인식 + 노출만 책임.
 *
 * <p>설계 적용:
 * <ul>
 *   <li>EntityManagerFactory 인입 = JPA bootstrap 후 호출 보장 ({@link InitializingBean})</li>
 *   <li>insertion-order 보존 (LinkedHashSet) — Hibernate 의 entity 등록 순서 = 결정적</li>
 *   <li>scan 결과 immutable snapshot — 후속 phase 에서 dynamic registration 영역 별도 검토</li>
 * </ul>
 **/
public class CacheableEntityRegistry implements InitializingBean {

  private final EntityManagerFactory entityManagerFactory;
  private Set<Class<?>> cacheableEntities = Collections.emptySet();

  public CacheableEntityRegistry(EntityManagerFactory entityManagerFactory) {
    this.entityManagerFactory = entityManagerFactory;
  }

  @Override
  public void afterPropertiesSet() {
    Set<Class<?>> entities = new LinkedHashSet<>();
    for (EntityType<?> entityType : entityManagerFactory.getMetamodel().getEntities()) {
      Class<?> javaType = entityType.getJavaType();
      if (javaType != null && Cacheable.class.isAssignableFrom(javaType)) {
        entities.add(javaType);
      }
    }
    this.cacheableEntities = Collections.unmodifiableSet(entities);
  }

  /** {@link Cacheable} implement entity 의 immutable 집합. */
  public Set<Class<?>> cacheableEntities() {
    return cacheableEntities;
  }

  /** entity class 가 {@link Cacheable} 영역인지 검사. */
  public boolean isCacheable(Class<?> entityClass) {
    return cacheableEntities.contains(entityClass);
  }
}
