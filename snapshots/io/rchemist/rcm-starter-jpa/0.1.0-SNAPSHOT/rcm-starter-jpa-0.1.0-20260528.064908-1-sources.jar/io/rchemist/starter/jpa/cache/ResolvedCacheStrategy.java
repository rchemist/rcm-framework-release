/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.time.Duration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #6 — entity 별 effective cache 설정 단일 객체. {@link CacheStrategyResolver} 가 yml >
 * annotation > default 우선순위 적용 후 본 record 반환. {@link AbstractCrudService} 결합 영역 (Phase 4
 * task #8) 이 본 record 인입해서 cache 동작.
 *
 * <p>{@code entityRegion} / {@code searchListRegion} = 실제 cache 호출 시 사용할 region name (yml
 * {@code platform.cache.<region>.*} 또는 {@code @CacheStrategy(region=...)} 명시 적용 후 결정).
 **/
public record ResolvedCacheStrategy(
    String entityRegion,
    String searchListRegion,
    Duration entityTtl,
    long entityMaxSize,
    Duration searchListTtl,
    long searchListMaxSize,
    CacheWriteStrategy writeStrategy) {}
