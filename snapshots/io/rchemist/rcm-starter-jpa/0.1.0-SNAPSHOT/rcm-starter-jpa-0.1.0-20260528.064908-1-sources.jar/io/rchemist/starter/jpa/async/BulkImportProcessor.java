/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #10 — Decision #13 의 Excel/CSV → entity 자동 변환 + 배치 트랜잭션 + row 단위 에러 누적
 * 영역. 0.0.5 {@code DataImportProcessor} 패턴 흡수 + 0.1.0 baseline (Records {@link RowError} /
 * {@link BulkImportResult} + VirtualThread executor + {@link AsyncJobTracker} 자동 결합).
 *
 * <p>처리 흐름:
 * <ol>
 *   <li>입력 row Iterable 순회 (인덱스 0-based)</li>
 *   <li>row → entity mapper 호출 ({@link Function} mapper, mapper 가 throw 시 RowError 누적 + skip)</li>
 *   <li>chunkSize 도달 또는 입력 종료 시 chunk consumer 호출 (Consumer 가 entity 저장 영역 책임 — 보통 repository.saveAll)</li>
 *   <li>chunk consumer 도 throw 시 chunk 전체 RowError 누적 (silent partial 거부)</li>
 *   <li>{@link AsyncJobTracker} 결합 시 자동 progress 갱신 (chunk 단위)</li>
 * </ol>
 *
 * <p>본 processor 는 *템플릿* — 실제 트랜잭션 경계 / Excel parser / CSV parser 는 Consumer 가 wire (Apache POI /
 * commons-csv 등). framework 책임 = chunk 분할 + 에러 누적 + progress 추적 + Records 결과 반환.
 *
 * @param <Row>    입력 row 영역 (Map<String,String> / String[] / 사용자 record 자유)
 * @param <Entity> 저장 entity 영역 (JPA entity)
 **/
public class BulkImportProcessor<Row, Entity> {

  private static final Logger log = LoggerFactory.getLogger(BulkImportProcessor.class);

  public static final int DEFAULT_CHUNK_SIZE = 100;

  private final Function<Row, Entity> mapper;
  private final Consumer<List<Entity>> chunkConsumer;
  private final int chunkSize;

  @Nullable private final AsyncJobTracker tracker;
  @Nullable private final String jobType;

  public BulkImportProcessor(
      Function<Row, Entity> mapper, Consumer<List<Entity>> chunkConsumer) {
    this(mapper, chunkConsumer, DEFAULT_CHUNK_SIZE, null, null);
  }

  public BulkImportProcessor(
      Function<Row, Entity> mapper,
      Consumer<List<Entity>> chunkConsumer,
      int chunkSize,
      @Nullable AsyncJobTracker tracker,
      @Nullable String jobType) {
    this.mapper = Objects.requireNonNull(mapper, "mapper");
    this.chunkConsumer = Objects.requireNonNull(chunkConsumer, "chunkConsumer");
    if (chunkSize <= 0) {
      throw new IllegalArgumentException("chunkSize must be positive: " + chunkSize);
    }
    this.chunkSize = chunkSize;
    this.tracker = tracker;
    this.jobType = jobType;
  }

  public BulkImportResult process(Iterable<Row> rows) {
    Objects.requireNonNull(rows, "rows");
    List<Row> snapshot = snapshot(rows);
    int total = snapshot.size();
    String jobId = startJob(total);

    List<RowError> errors = new ArrayList<>();
    List<Entity> currentChunk = new ArrayList<>(chunkSize);
    List<Integer> chunkOriginalIndexes = new ArrayList<>(chunkSize);
    List<Row> chunkOriginalRows = new ArrayList<>(chunkSize);
    int successCount = 0;
    int failureCount = 0;

    for (int i = 0; i < total; i++) {
      Row row = snapshot.get(i);
      Entity entity;
      try {
        entity = mapper.apply(row);
      } catch (RuntimeException ex) {
        errors.add(new RowError(i, ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage(), row));
        failureCount++;
        continue;
      }
      if (entity == null) {
        errors.add(new RowError(i, "mapper returned null", row));
        failureCount++;
        continue;
      }
      currentChunk.add(entity);
      chunkOriginalIndexes.add(i);
      chunkOriginalRows.add(row);

      if (currentChunk.size() >= chunkSize) {
        ChunkOutcome outcome =
            flushChunk(currentChunk, chunkOriginalIndexes, chunkOriginalRows, errors);
        successCount += outcome.successDelta();
        failureCount += outcome.failureDelta();
        updateProgress(jobId, successCount + failureCount, total);
      }
    }
    if (!currentChunk.isEmpty()) {
      ChunkOutcome outcome =
          flushChunk(currentChunk, chunkOriginalIndexes, chunkOriginalRows, errors);
      successCount += outcome.successDelta();
      failureCount += outcome.failureDelta();
      updateProgress(jobId, successCount + failureCount, total);
    }

    finishJob(jobId, errors.isEmpty());
    return new BulkImportResult(total, successCount, failureCount, errors, jobId);
  }

  // ---------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------

  private ChunkOutcome flushChunk(
      List<Entity> chunk,
      List<Integer> indexes,
      List<Row> originalRows,
      List<RowError> errors) {
    int chunkSizeBefore = chunk.size();
    try {
      chunkConsumer.accept(List.copyOf(chunk));
      chunk.clear();
      indexes.clear();
      originalRows.clear();
      return new ChunkOutcome(chunkSizeBefore, 0);
    } catch (RuntimeException ex) {
      log.warn(
          "BulkImport chunk failed (chunkSize={}, firstIndex={}): {}",
          chunkSizeBefore,
          indexes.isEmpty() ? -1 : indexes.get(0),
          ex.getMessage());
      String message =
          ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
      for (int idx = 0; idx < chunkSizeBefore; idx++) {
        errors.add(new RowError(indexes.get(idx), message, originalRows.get(idx)));
      }
      chunk.clear();
      indexes.clear();
      originalRows.clear();
      return new ChunkOutcome(0, chunkSizeBefore);
    }
  }

  private List<Row> snapshot(Iterable<Row> rows) {
    if (rows instanceof List<Row> list) {
      return list;
    }
    List<Row> copy = new ArrayList<>();
    rows.forEach(copy::add);
    return copy;
  }

  @Nullable
  private String startJob(int total) {
    if (tracker == null || jobType == null) {
      return null;
    }
    AsyncJob job = tracker.registerNew(jobType);
    tracker.start(job.id());
    log.info("BulkImport started: jobId={} type={} totalRows={}", job.id(), jobType, total);
    return job.id();
  }

  private void updateProgress(@Nullable String jobId, int processed, int total) {
    if (jobId == null || total == 0) {
      return;
    }
    int progress = (int) Math.min(100, ((long) processed * 100) / total);
    tracker.updateProgress(jobId, progress);
  }

  private void finishJob(@Nullable String jobId, boolean allSucceeded) {
    if (jobId == null) {
      return;
    }
    if (allSucceeded) {
      tracker.complete(jobId);
    } else {
      tracker.fail(jobId, "BulkImport finished with row errors");
    }
  }

  private record ChunkOutcome(int successDelta, int failureDelta) {}
}
