/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — Multi-tenant strategy / column 적용 (Decision #17). starter-jpa 영역 한정 —
 * starter-web 의 resolver / header 등 request 단 식별 영역은 별도 {@code WebTenantProperties} 적용.
 *
 * <p>{@code strategy} = {@code DISCRIMINATOR|DATABASE|SCHEMA} (Phase 3 task #4 baseline =
 * DISCRIMINATOR, task #5 에서 DATABASE/SCHEMA 추가). {@code column} = entity DB 컬럼 명 default
 * {@code tenant_id}. {@code enabled} = autoconfig 활성 toggle (default = true).
 *
 * <p>Phase 3 task #5 — {@link Pool} sub-record 적용 (per-tenant DataSource pool sizing + shared pool
 * sizing + maxActiveTenants LRU evict 임계). DATABASE 전략 활성 시 의미 (DISCRIMINATOR 전략 시 무시).
 **/
@ConfigurationProperties(prefix = "platform.tenant")
public record TenantProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("DISCRIMINATOR") Strategy strategy,
    @DefaultValue("tenant_id") String column,
    @DefaultValue Pool pool,
    @DefaultValue Migration migration) {

  public enum Strategy {
    DISCRIMINATOR,
    DATABASE,
    SCHEMA
  }

  /**
   * Phase 3 task #5 — Connection pool sizing (DATABASE 전략 적용). {@code maxActiveTenants} LRU evict
   * 임계 (기본 50 — 그 이상 onboard 시 LRU pool close 후 신규 발급). {@code perTenant.maximumPoolSize}
   * tenant 당 HikariCP pool size. {@code shared.maximumPoolSize} bootstrap / cross-tenant
   * {@code __system__} 영역 공유 pool size.
   */
  public record Pool(
      @DefaultValue("50") int maxActiveTenants,
      @DefaultValue PerTenant perTenant,
      @DefaultValue Shared shared) {

    public record PerTenant(@DefaultValue("10") int maximumPoolSize) {}

    public record Shared(@DefaultValue("20") int maximumPoolSize) {}
  }

  /**
   * Phase 3 task #5 — Migration runner 옵션 (Decision #17). {@code parallel=true} 시
   * {@link TenantMigrationRunner} 가 active tenant 병렬 migration. default = false (사용자 명시 opt-in).
   */
  public record Migration(@DefaultValue("false") boolean parallel) {}
}
