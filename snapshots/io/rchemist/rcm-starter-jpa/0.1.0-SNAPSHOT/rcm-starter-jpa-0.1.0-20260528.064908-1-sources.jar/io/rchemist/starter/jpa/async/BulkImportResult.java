/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.util.List;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #10 — Decision #13 의 BulkImportProcessor 결과 record. {@code totalRows} = 입력 row 수,
 * {@code successCount} + {@code failureCount} 합계 = totalRows. {@code errors} = row 단위 실패 누적
 * (immutable copy). {@code jobId} = {@link AsyncJobTracker} 결합 시 job 식별자 (미결합 시 null).
 **/
public record BulkImportResult(
    int totalRows, int successCount, int failureCount, List<RowError> errors, @Nullable String jobId) {

  public BulkImportResult {
    if (totalRows < 0) {
      throw new IllegalArgumentException("totalRows negative: " + totalRows);
    }
    if (successCount < 0) {
      throw new IllegalArgumentException("successCount negative: " + successCount);
    }
    if (failureCount < 0) {
      throw new IllegalArgumentException("failureCount negative: " + failureCount);
    }
    if (successCount + failureCount != totalRows) {
      throw new IllegalArgumentException(
          "successCount + failureCount != totalRows: "
              + successCount
              + " + "
              + failureCount
              + " != "
              + totalRows);
    }
    errors = errors == null ? List.of() : List.copyOf(errors);
  }

  public boolean hasFailures() {
    return failureCount > 0;
  }
}
