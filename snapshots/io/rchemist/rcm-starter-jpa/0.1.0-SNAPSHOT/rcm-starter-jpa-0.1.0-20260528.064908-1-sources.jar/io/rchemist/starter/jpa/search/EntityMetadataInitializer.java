/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import jakarta.annotation.PostConstruct;
import java.util.ServiceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #25 fix — APT {@code EntityMetadataProcessor} 가 {@code
 * META-INF/services/io.rchemist.core.search.EntityMetadata} 에 산출한 모든 {@code <Entity>_Metadata}
 * 영역을 application bootstrap 시점에 {@link ServiceLoader} 로 적재. 각 {@code <Entity>_Metadata}
 * 의 static initializer 가 {@link EntityMetadataRegistry#register} 를 발화하므로, 본 클래스는 *클래스
 * 로드 trigger* 책임 + 명시 register fallback (덮어쓰기 idempotent) 영역.
 *
 * <p>이전: Consumer 가 자체 {@code @PostConstruct} 안에서 {@code ServiceLoader.load} trigger 강제
 * → 누락 시 모든 list/search endpoint 가 {@code "EntityMetadata not registered"} 500 발화. 본 fix
 * 후 framework 가 자동 trigger → consumer 책임 0.
 *
 * <p>{@link StarterJpaAutoConfiguration} 가 {@code @ConditionalOnMissingBean} (type 기반) 으로 등록 —
 * Consumer 가 자체 Initializer 적용 시 자동 양보.
 **/
public final class EntityMetadataInitializer {

  private static final Logger log = LoggerFactory.getLogger(EntityMetadataInitializer.class);

  @PostConstruct
  public void registerAll() {
    int loaded = 0;
    for (EntityMetadata<?> metadata : ServiceLoader.load(EntityMetadata.class)) {
      registerOne(metadata);
      loaded++;
    }
    log.info(
        "[EntityMetadataInitializer] ServiceLoader 적재 완료 — loaded={}, registry size={}",
        loaded, EntityMetadataRegistry.size());
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  private static void registerOne(EntityMetadata<?> metadata) {
    Class<?> entityClass = metadata.entityClass();
    EntityMetadataRegistry.register((Class) entityClass, (EntityMetadata) metadata);
  }
}
