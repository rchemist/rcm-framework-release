/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.audit;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #2 — Spring Data JPA Auditing autoconfig. {@code @EnableJpaAuditing} 자동 활성화 +
 * {@link AuditorAwareImpl} baseline bean 등록. Consumer 가 자체 {@code AuditorAware} bean 제공 시
 * 자동 교체 ({@code @ConditionalOnMissingBean(AuditorAware.class)}).
 *
 * <p>opt-out = yml {@code platform.jpa.auditing.enabled=false} (default = true).
 **/
@AutoConfiguration
@ConditionalOnClass(EnableJpaAuditing.class)
@ConditionalOnProperty(prefix = "platform.jpa.auditing", name = "enabled", havingValue = "true",
    matchIfMissing = true)
@EnableJpaAuditing(auditorAwareRef = "rcmAuditorAware")
public class AuditingConfiguration {

  @Bean(name = "rcmAuditorAware")
  @ConditionalOnMissingBean(AuditorAware.class)
  public AuditorAware<String> rcmAuditorAware() {
    return new AuditorAwareImpl();
  }
}
