/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — 0.0.5 의 {@code EntityManagerWrapper}
 * ({@code io.rchemist.common.persistence.jpa.multitenant}) 흡수 (메모리
 * {@code feedback_no_feature_regression} 정합). JPA 표준 {@link EntityManager} 의 단순 delegate +
 * 도메인 helper ({@link #count(Class)} / {@link #findOptional(Class, Object)}).
 *
 * <p>naming = {@code EntityManagerExtensions} (Decision #20 의 prefix 없음 default + Jakarta
 * {@code EntityManager} 의 simple name 충돌 회피 정합). multi-EM 라우팅 영역은 {@link
 * MultiEntityManager} SPI.
 *
 * <p>{@link MultiEntityManager#on(String)} 가 매 호출마다 본 객체 신규 생성 — 내부 EM 은 lookup 시점에
 * factory 가 책임. Consumer 직접 inject 시 (single DS) JPA 표준 {@code @PersistenceContext EntityManager}
 * 그대로 + 본 helper 의 method 만 활용도 OK.
 */
public final class EntityManagerExtensions {

  private final EntityManager em;

  public EntityManagerExtensions(EntityManager em) {
    this.em = Objects.requireNonNull(em, "em");
  }

  /** 모든 row count — JPA Criteria {@code SELECT count(*) FROM Entity}. */
  public <T> long count(Class<T> entityClass) {
    Objects.requireNonNull(entityClass, "entityClass");
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<Long> cq = cb.createQuery(Long.class);
    Root<T> root = cq.from(entityClass);
    cq.select(cb.count(root));
    return em.createQuery(cq).getSingleResult();
  }

  /** {@code find(Class, id)} 의 Optional 변환 — null safety. */
  public <T> Optional<T> findOptional(Class<T> entityClass, Object id) {
    Objects.requireNonNull(entityClass, "entityClass");
    Objects.requireNonNull(id, "id");
    return Optional.ofNullable(em.find(entityClass, id));
  }

  /** raw {@link EntityManager} 노출 — 표준 API 필요 시. */
  public EntityManager unwrap() {
    return em;
  }
}
