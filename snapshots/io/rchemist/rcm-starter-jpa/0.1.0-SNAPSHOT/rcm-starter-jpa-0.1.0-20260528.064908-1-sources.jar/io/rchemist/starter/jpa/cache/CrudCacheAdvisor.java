/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import io.rchemist.core.marker.Cacheable;
import jakarta.persistence.EntityManagerFactory;
import java.util.Optional;
import java.util.function.Supplier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.domain.Page;
import org.springframework.lang.Nullable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #8 — Decision #7 의 *AbstractCrudService ↔ cache 자동 결합* facade. {@link
 * AbstractCrudService} 의 5 method 가 본 advisor 위임 — entity 가 {@link Cacheable} marker 미적용 시 no-op
 * (raw supplier 호출), 적용 시 cache 결합.
 *
 * <p>본 facade 의 책임:
 * <ul>
 *   <li>{@link CacheStrategyResolver} 의 결과로 entity 별 effective region / write strategy 결정</li>
 *   <li>{@link TenantAwareCacheKeyResolver} 로 tenant prefix 자동</li>
 *   <li>{@link EntityCacheStrategyRegistry} 의 hook 호출 (cacheKey override / shouldCache / onCustomEvict)</li>
 *   <li>{@link CacheWriteStrategy} 따라 write 시 entity_cache put 또는 evict</li>
 *   <li>모든 write = search_list_cache 일괄 clear (page 단위 결과 캐시 무효화)</li>
 * </ul>
 *
 * <p>{@code @Cacheable} marker 미적용 entity = baseline 단순 통과 → Phase 3 의 AbstractCrudService 동작
 * 동일 (cache 영역 부재).
 **/
public class CrudCacheAdvisor {

  private final CacheManager cacheManager;
  private final CacheStrategyResolver strategyResolver;
  private final TenantAwareCacheKeyResolver keyResolver;
  private final EntityCacheStrategyRegistry strategyRegistry;
  private final EntityManagerFactory entityManagerFactory;

  public CrudCacheAdvisor(
      CacheManager cacheManager,
      CacheStrategyResolver strategyResolver,
      TenantAwareCacheKeyResolver keyResolver,
      EntityCacheStrategyRegistry strategyRegistry,
      EntityManagerFactory entityManagerFactory) {
    this.cacheManager = cacheManager;
    this.strategyResolver = strategyResolver;
    this.keyResolver = keyResolver;
    this.strategyRegistry = strategyRegistry;
    this.entityManagerFactory = entityManagerFactory;
  }

  /** JPA persistence unit 의 표준 id 추출 — Hibernate / EclipseLink 양쪽 동일 동작. */
  public Object idOf(Object entity) {
    return entityManagerFactory.getPersistenceUnitUtil().getIdentifier(entity);
  }

  public boolean isCacheable(Class<?> entityClass) {
    return Cacheable.class.isAssignableFrom(entityClass);
  }

  /** Read-through find — cache hit 시 적재된 entity 반환, miss 시 supplier 호출 후 cache 적재. */
  public <E> E findCached(Class<E> entityClass, Object id, Supplier<E> loader) {
    if (!isCacheable(entityClass)) {
      return loader.get();
    }
    ResolvedCacheStrategy strategy = strategyResolver.resolve(entityClass);
    Cache cache = cacheManager.getCache(strategy.entityRegion());
    if (cache == null) {
      return loader.get();
    }
    Object key = key(entityClass, id);
    Cache.ValueWrapper hit = cache.get(key);
    if (hit != null) {
      @SuppressWarnings("unchecked")
      E hitEntity = (E) hit.get();
      return hitEntity;
    }
    E loaded = loader.get();
    if (loaded != null && shouldCache(entityClass, loaded)) {
      cache.put(key, loaded);
    }
    return loaded;
  }

  /** Read-through search — page 단위 결과 적재. SearchRequest hash key. */
  public <E> Page<E> searchCached(Class<E> entityClass, Object requestKey, Supplier<Page<E>> loader) {
    if (!isCacheable(entityClass)) {
      return loader.get();
    }
    ResolvedCacheStrategy strategy = strategyResolver.resolve(entityClass);
    Cache cache = cacheManager.getCache(strategy.searchListRegion());
    if (cache == null) {
      return loader.get();
    }
    Object key = key(entityClass, requestKey);
    Cache.ValueWrapper hit = cache.get(key);
    if (hit != null) {
      @SuppressWarnings("unchecked")
      Page<E> hitPage = (Page<E>) hit.get();
      return hitPage;
    }
    Page<E> loaded = loader.get();
    if (loaded != null) {
      cache.put(key, loaded);
    }
    return loaded;
  }

  /** create / update 직후 호출 — entity 의 id 자동 추출 + write strategy 따라 entity_cache + search_list 갱신. */
  public <E> void recordWrite(Class<E> entityClass, E entity, @Nullable E previous) {
    if (!isCacheable(entityClass) || entity == null) {
      return;
    }
    Object id = idOf(entity);
    if (id == null) {
      return;
    }
    ResolvedCacheStrategy strategy = strategyResolver.resolve(entityClass);
    Cache entityCache = cacheManager.getCache(strategy.entityRegion());
    Cache searchListCache = cacheManager.getCache(strategy.searchListRegion());
    Object key = key(entityClass, id);

    if (entityCache != null) {
      switch (strategy.writeStrategy()) {
        case WRITE_THROUGH -> {
          if (shouldCache(entityClass, entity)) {
            entityCache.put(key, entity);
          } else {
            entityCache.evict(key);
          }
        }
        case WRITE_AROUND, READ_THROUGH -> {
          if (previous != null && !shouldEvictOnUpdate(entityClass, previous, entity)) {
            // cache 유지 — Consumer 의 immutable-field-only update hint
          } else {
            entityCache.evict(key);
          }
        }
      }
    }
    if (searchListCache != null) {
      searchListCache.clear();
    }
    runOnCustomEvict(entityClass, entity);
  }

  /** delete 직후 호출 — entity_cache evict + search_list 일괄 clear + onCustomEvict. */
  public <E> void recordDelete(Class<E> entityClass, Object id, @Nullable E deletedEntity) {
    if (!isCacheable(entityClass) || id == null) {
      return;
    }
    ResolvedCacheStrategy strategy = strategyResolver.resolve(entityClass);
    Cache entityCache = cacheManager.getCache(strategy.entityRegion());
    Cache searchListCache = cacheManager.getCache(strategy.searchListRegion());
    Object key = key(entityClass, id);

    if (entityCache != null) {
      entityCache.evict(key);
    }
    if (searchListCache != null) {
      searchListCache.clear();
    }
    if (deletedEntity != null) {
      runOnCustomEvict(entityClass, deletedEntity);
    }
  }

  // ---------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------

  private <E> Object key(Class<E> entityClass, Object id) {
    Optional<EntityCacheStrategy<E>> strategy = strategyRegistry.find(entityClass);
    if (strategy.isPresent()) {
      Object override = strategy.get().cacheKey(id);
      if (override != null) {
        return override;
      }
    }
    return keyResolver.resolve(entityClass, id);
  }

  private <E> boolean shouldCache(Class<E> entityClass, E entity) {
    if (entity == null) {
      return false;
    }
    return strategyRegistry
        .find(entityClass)
        .map(s -> s.shouldCache(entity))
        .orElse(true);
  }

  private <E> boolean shouldEvictOnUpdate(Class<E> entityClass, E before, E after) {
    return strategyRegistry
        .find(entityClass)
        .map(s -> s.shouldEvictOnUpdate(before, after))
        .orElse(true);
  }

  private <E> void runOnCustomEvict(Class<E> entityClass, E entity) {
    strategyRegistry
        .find(entityClass)
        .ifPresent(s -> s.onCustomEvict(entity, cacheManager));
  }
}
