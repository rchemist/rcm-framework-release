/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.Map;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — Hibernate 7 multi-tenant DISCRIMINATOR strategy {@link
 * HibernatePropertiesCustomizer}. Decision #17 baseline = entity 의 {@code @TenantId} 필드 + Hibernate
 * 가 SELECT/UPDATE/DELETE 자동 tenant filter.
 *
 * <p>적용 hibernate property — {@code hibernate.tenant_identifier_resolver} (resolver bean 직접 wire).
 * Hibernate 7 는 entity 의 {@code @TenantId} 어노테이션 적용만으로 multi-tenant DISCRIMINATOR 동작
 * (별도 {@code hibernate.multi_tenant} property 불필요, JPA 영역 자동 detect).
 **/
public class DiscriminatorTenantConfig implements HibernatePropertiesCustomizer {

  public static final String HIBERNATE_TENANT_RESOLVER = "hibernate.tenant_identifier_resolver";

  private final CurrentTenantIdentifierResolver<String> resolver;

  public DiscriminatorTenantConfig(CurrentTenantIdentifierResolver<String> resolver) {
    this.resolver = resolver;
  }

  @Override
  public void customize(Map<String, Object> hibernateProperties) {
    hibernateProperties.putIfAbsent(HIBERNATE_TENANT_RESOLVER, resolver);
  }
}
