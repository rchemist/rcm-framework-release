/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.util.Locale;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #2 — 2-tier region naming convention 단일 지점. gjcu 의 {@code cacheManager.getOrCreateCache(...)}
 * 536 회 일관 패턴 흡수:
 * <ul>
 *   <li>{@link #entityCacheName(Class)} — {@code <entity>_entity_cache} (단건 lookup, default 1000/86400s)</li>
 *   <li>{@link #searchListCacheName(Class)} — {@code <entity>_search_list_cache} (검색 결과, default 100/3600s)</li>
 * </ul>
 *
 * <p>region prefix = entity simple name lowercase. 같은 simple name 의 다른 패키지 entity 충돌 시
 * Consumer 가 {@code @CacheStrategy(region = "...")} 로 명시 override (Phase 4 task #6).
 **/
public final class CacheRegionNames {

  public static final String ENTITY_SUFFIX = "_entity_cache";
  public static final String SEARCH_LIST_SUFFIX = "_search_list_cache";

  private CacheRegionNames() {}

  public static String entityCacheName(Class<?> entityClass) {
    return prefix(entityClass) + ENTITY_SUFFIX;
  }

  public static String searchListCacheName(Class<?> entityClass) {
    return prefix(entityClass) + SEARCH_LIST_SUFFIX;
  }

  /** region name → 2-tier 의 어느 tier 인지 검사. 미일치 시 {@code null}. */
  public static CacheTier tierOf(String regionName) {
    Objects.requireNonNull(regionName, "regionName");
    if (regionName.endsWith(ENTITY_SUFFIX)) {
      return CacheTier.ENTITY;
    }
    if (regionName.endsWith(SEARCH_LIST_SUFFIX)) {
      return CacheTier.SEARCH_LIST;
    }
    return null;
  }

  private static String prefix(Class<?> entityClass) {
    Objects.requireNonNull(entityClass, "entityClass");
    return entityClass.getSimpleName().toLowerCase(Locale.ROOT);
  }
}
