/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.spatial;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #8 — Spatial 경량 baseline. {@link io.rchemist.core.marker.Spatial} marker
 * 적용된 entity 가 {@code @JdbcTypeCode(SqlTypes.GEOMETRY)} 컬럼 자동 매핑. Hibernate 7 +
 * hibernate-spatial 가 classpath 에 있으면 PostGIS 영역 자동 동작 — framework 책임 = autoconfig
 * 진입점 + Consumer 의 spatial 의존 opt-in 영역.
 *
 * <p>활성 조건 (자동):
 * <ul>
 *   <li>{@code org.locationtech.jts.geom.Geometry} (jts-core) classpath</li>
 *   <li>{@code org.hibernate.spatial.JTSGeometryJavaType} (hibernate-spatial) classpath</li>
 *   <li>{@code platform.jpa.spatial.enabled} 미적용 또는 true (matchIfMissing)</li>
 * </ul>
 *
 * <p>Consumer 적용 패턴 — entity 가 {@link io.rchemist.core.marker.Spatial} marker implement +
 * Geometry 필드에 {@code @JdbcTypeCode(SqlTypes.GEOMETRY)} 어노테이션. Hibernate 가 SQL 자동
 * (PostGIS extension 가 DB 측 활성, ST_DWithin / ST_Contains / ST_Intersects 등 함수 JPQL 노출).
 *
 * <p>본 baseline 은 명시 PostGIS dialect override 영역 거부 — Hibernate 7 의 PostgreSQLDialect 가
 * hibernate-spatial classpath 자동 감지 → ServiceLoader 가 SpatialFunctionContributor 등록.
 * framework 가 추가 SQL 함수 wrap 가 필요한 영역은 Phase 4+ 영역 (사용 패턴 등록 후).
 **/
@AutoConfiguration
@ConditionalOnClass(name = {
    "org.locationtech.jts.geom.Geometry",
    "org.hibernate.spatial.JTSGeometryJavaType"
})
@ConditionalOnProperty(prefix = "platform.jpa.spatial", name = "enabled", matchIfMissing = true)
public class SpatialAutoConfiguration {
}
