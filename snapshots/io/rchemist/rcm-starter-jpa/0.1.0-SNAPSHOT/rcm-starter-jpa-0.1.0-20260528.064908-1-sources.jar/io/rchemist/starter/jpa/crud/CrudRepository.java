/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.crud;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #10 — {@link AbstractCrudService} 가 의존하는 표준 repository contract. Spring Data
 * 표준 {@link JpaRepository} (CRUD + paging) + {@link JpaSpecificationExecutor} (
 * {@code SearchRequestPlanner} 에서 produce 된 Specification 활용) 결합.
 *
 * <p>Decision #20 (prefix 없음 default) 정합 — Spring Data {@code CrudRepository} 와 simple name
 * 동일이지만 본 contract 는 {@code io.rchemist.starter.jpa.crud.CrudRepository} package 분리.
 * Consumer 가 명시 import 시 결정. Spring Data 의 {@code CrudRepository} 가 더 좁은 superinterface
 * (paging 없음) 라 본 contract 가 superset.
 *
 * <p>{@link NoRepositoryBean} 명시 — Spring Data 가 본 interface 자체의 bean 자동 생성 영역 거부
 * (Consumer 가 extends 한 sub interface 만 bean 생성).
 **/
@NoRepositoryBean
public interface CrudRepository<E, ID>
    extends JpaRepository<E, ID>, JpaSpecificationExecutor<E> {
}
