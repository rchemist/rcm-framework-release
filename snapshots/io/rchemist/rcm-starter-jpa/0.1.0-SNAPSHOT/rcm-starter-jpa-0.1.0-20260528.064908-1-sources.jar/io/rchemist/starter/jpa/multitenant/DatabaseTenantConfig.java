/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.Map;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — DATABASE 전략용 Hibernate {@link HibernatePropertiesCustomizer} (Decision #17).
 * 적용 hibernate property — {@code hibernate.tenant_identifier_resolver} ({@link
 * CurrentTenantIdentifierResolver} bean instance) + {@code hibernate.multi_tenant_connection_provider}
 * ({@link MultiTenantConnectionProvider} bean instance — DATABASE 전략 시 {@link
 * DataSourceTenantConnectionProvider} 인입).
 *
 * <p>{@code putIfAbsent} 적용 — Consumer 의 yml override 보존 ({@link
 * io.rchemist.starter.jpa.autoconfig.JsonTypeCustomizer} 정합).
 **/
public class DatabaseTenantConfig implements HibernatePropertiesCustomizer {

  public static final String HIBERNATE_TENANT_RESOLVER = "hibernate.tenant_identifier_resolver";
  public static final String HIBERNATE_MULTI_TENANT_CONNECTION_PROVIDER =
      "hibernate.multi_tenant_connection_provider";

  private final CurrentTenantIdentifierResolver<String> resolver;
  private final MultiTenantConnectionProvider<String> connectionProvider;

  public DatabaseTenantConfig(
      CurrentTenantIdentifierResolver<String> resolver,
      MultiTenantConnectionProvider<String> connectionProvider) {
    this.resolver = resolver;
    this.connectionProvider = connectionProvider;
  }

  @Override
  public void customize(Map<String, Object> hibernateProperties) {
    hibernateProperties.putIfAbsent(HIBERNATE_TENANT_RESOLVER, resolver);
    hibernateProperties.putIfAbsent(HIBERNATE_MULTI_TENANT_CONNECTION_PROVIDER, connectionProvider);
  }
}
