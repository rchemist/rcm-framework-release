/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.SearchPredicate;
import io.rchemist.core.search.UnmappedJoin;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — {@link UnmappedJoin} 의 SubQuery 자동 생성 (청사진 §5.5.6, 0.0.5
 * {@code PredicateMerger.mergeUnmappedConditions()} 흡수). 사용자 피드백 정합 — 명시 매핑 없는
 * entity 영역 검색 (Article 검색 + AuditLog entityId 매칭 같은 시나리오).
 *
 * <p>baseline = SubQuery 안 신규 Root + 명시 join condition (외부 entity 의 alias path) +
 * additionalFilter ({@link SearchPredicate} 재귀 처리). EXISTS predicate 으로 wrap.
 */
final class UnmappedJoinResolver {

  private UnmappedJoinResolver() {
  }

  static Predicate resolve(
      UnmappedJoin unmapped,
      Root<?> root,
      CriteriaQuery<?> query,
      CriteriaBuilder cb,
      EntityMetadata<?> outerMeta
  ) {
    Class<?> target = unmapped.targetEntityClass();
    Subquery<Long> sub = query.subquery(Long.class);
    Root<?> subRoot = sub.from(target);
    sub.select(cb.literal(1L));

    // joinCondition / additionalFilter = SearchPredicate sealed → FilterItem leaf 로 단순화.
    Predicate join = predicateOf(unmapped.joinCondition(), root, subRoot, query, cb, target);
    Predicate additional = unmapped.additionalFilter() == null
        ? cb.conjunction()
        : predicateOf(unmapped.additionalFilter(), root, subRoot, query, cb, target);
    sub.where(cb.and(join, additional));
    return cb.exists(sub);
  }

  /**
   * SearchPredicate sealed → SubQuery scope predicate. baseline = FilterItem leaf 의 단순 매칭만.
   * subRoot 의 컬럼에 대해 {@code FilterDispatcher} 와 별개의 mini dispatcher (단순 EQ / IN / IS NULL).
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Predicate predicateOf(
      SearchPredicate p, Root<?> outerRoot, Root<?> subRoot,
      CriteriaQuery<?> query, CriteriaBuilder cb, Class<?> targetClass
  ) {
    if (p instanceof FilterItem item) {
      EntityMetadata targetMeta = EntityMetadataRegistry.find(targetClass)
          .orElseGet(() -> new BareEntityMetadata(targetClass));
      JoinAliasManager subJoins = new JoinAliasManager(subRoot, targetMeta);
      return FilterDispatcher.build(item, subJoins, cb, query, targetMeta);
    }
    if (p instanceof UnmappedJoin nested) {
      EntityMetadata targetMeta = EntityMetadataRegistry.find(targetClass)
          .orElseGet(() -> new BareEntityMetadata(targetClass));
      return resolve(nested, outerRoot, query, cb, targetMeta);
    }
    return cb.conjunction();
  }
}
