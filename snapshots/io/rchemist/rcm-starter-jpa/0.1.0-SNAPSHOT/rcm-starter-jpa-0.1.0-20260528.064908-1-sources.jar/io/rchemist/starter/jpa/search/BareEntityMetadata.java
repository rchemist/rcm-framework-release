/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.FieldDescriptor;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — Registry 에 등록되지 않은 entity 의 fallback metadata. {@link UnmappedJoinResolver}
 * 가 SubQuery 를 만들 때 외부 entity 의 metadata 가 없을 수 있어 path resolve 만 가능한 minimal impl.
 *
 * <p>{@code findField(...)} = 항상 empty 반환 → {@link io.rchemist.core.search.FilterClassification#UNKNOWN}
 * fallthrough. caller (FilterDispatcher) 가 {@code path.getJavaType()} 으로 type 추론.
 */
final class BareEntityMetadata<T> implements EntityMetadata<T> {

  private final Class<T> entityClass;

  BareEntityMetadata(Class<T> entityClass) {
    this.entityClass = entityClass;
  }

  @Override
  public Class<T> entityClass() {
    return entityClass;
  }

  @Override
  public String entityName() {
    return entityClass.getSimpleName();
  }

  @Override
  public List<FieldDescriptor<T, ?>> fields() {
    return List.of();
  }

  @Override
  public Optional<FieldDescriptor<T, ?>> findField(String name) {
    return Optional.empty();
  }
}
