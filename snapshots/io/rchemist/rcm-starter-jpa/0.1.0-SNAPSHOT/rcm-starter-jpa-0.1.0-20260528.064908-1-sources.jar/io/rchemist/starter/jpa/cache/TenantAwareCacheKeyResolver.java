/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import io.rchemist.core.context.TenantContext;
import io.rchemist.core.marker.TenantAlias;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #3 — entity class 가 {@link TenantAlias} marker implement 시 cache key 자동 prefix
 * {@code <tenantId>:}. tenant 격리 보장 — 같은 id 라도 tenant 다르면 다른 cache 영역.
 *
 * <p>{@link TenantAlias} 미적용 entity 는 raw id 그대로 (전역 cache). {@link TenantContext}
 * 미바인딩 또는 {@link TenantContext#SYSTEM_TENANT_ID} 상태 = global namespace ({@code "__system__:" + id}
 * prefix 적용 X — silent global cache 회피, system 영역 cache 는 명시 적용).
 *
 * <p>본 resolver = stateless utility — singleton bean 등록 후 {@link AbstractCrudService} 와 같은
 * cache 결합 영역 (Phase 4 task #8) 이 인입.
 **/
public class TenantAwareCacheKeyResolver {

  /** entity class + id → cache key. */
  public Object resolve(Class<?> entityClass, Object id) {
    Objects.requireNonNull(entityClass, "entityClass");
    Objects.requireNonNull(id, "id");
    if (!TenantAlias.class.isAssignableFrom(entityClass)) {
      return id;
    }
    String tenantId = TenantContext.currentTenantIdOrNull();
    if (tenantId == null || TenantContext.SYSTEM_TENANT_ID.equals(tenantId)) {
      return id;
    }
    return tenantId + ":" + id;
  }
}
