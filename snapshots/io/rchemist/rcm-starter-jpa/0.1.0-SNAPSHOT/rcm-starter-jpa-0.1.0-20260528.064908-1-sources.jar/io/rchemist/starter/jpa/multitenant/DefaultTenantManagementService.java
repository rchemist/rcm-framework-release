/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.springframework.beans.factory.ObjectProvider;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — {@link TenantManagementService} default impl (Decision #17). 인메모리
 * {@link ConcurrentHashMap} 기반 registry. Consumer 가 영속화 (DB persistent / Redis) 가 필요하면 자체
 * impl 적용 → {@code @ConditionalOnMissingBean} 으로 자동 교체.
 *
 * <p>DATABASE 전략 시 onboard 가 {@link DataSourceRegistry} 위임 (HikariCP pool 생성 + LRU 관리).
 * SCHEMA 전략 시 onboard 가 {@link SchemaInitializer} 위임 (CREATE SCHEMA 실행). 등록된 모든
 * {@link TenantMigrator} 가 onboard 직후 호출.
 **/
public class DefaultTenantManagementService implements TenantManagementService {

  private final ConcurrentMap<String, TenantConfig> registry = new ConcurrentHashMap<>();

  private final ObjectProvider<DataSourceRegistry> dataSourceRegistry;
  private final ObjectProvider<SchemaInitializer> schemaInitializer;
  private final ObjectProvider<TenantMigrator> migrators;

  public DefaultTenantManagementService(
      ObjectProvider<DataSourceRegistry> dataSourceRegistry,
      ObjectProvider<SchemaInitializer> schemaInitializer,
      ObjectProvider<TenantMigrator> migrators) {
    this.dataSourceRegistry = Objects.requireNonNull(dataSourceRegistry, "dataSourceRegistry");
    this.schemaInitializer = Objects.requireNonNull(schemaInitializer, "schemaInitializer");
    this.migrators = Objects.requireNonNull(migrators, "migrators");
  }

  @Override
  public void onboard(TenantConfig config) {
    Objects.requireNonNull(config, "config");
    TenantConfig existing = registry.putIfAbsent(config.tenantId(), config);
    if (existing != null) {
      throw new IllegalStateException("Tenant already onboarded: " + config.tenantId());
    }
    dataSourceRegistry.ifAvailable(reg -> reg.register(config));
    schemaInitializer.ifAvailable(init -> init.createSchema(config));
    migrators.orderedStream().forEach(migrator -> migrator.migrate(config));
  }

  @Override
  public void offboard(String tenantId) {
    Objects.requireNonNull(tenantId, "tenantId");
    if (registry.remove(tenantId) != null) {
      dataSourceRegistry.ifAvailable(reg -> reg.evict(tenantId));
    }
  }

  @Override
  public List<String> activeTenants() {
    return List.copyOf(registry.keySet());
  }

  @Override
  public Optional<TenantConfig> findConfig(String tenantId) {
    return Optional.ofNullable(registry.get(tenantId));
  }
}
