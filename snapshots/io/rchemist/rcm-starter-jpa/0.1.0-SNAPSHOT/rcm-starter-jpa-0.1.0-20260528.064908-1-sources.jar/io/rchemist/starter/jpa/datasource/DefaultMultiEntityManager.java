/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import jakarta.persistence.EntityManagerFactory;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — {@link MultiEntityManager} default impl. 등록된 {@link EntityManagerFactory}
 * map + primary name 기반 routing. 매 {@link #on(String)} 호출마다 신규 EM 생성 (caller 책임 close).
 *
 * <p>{@link #forEach(BiConsumer)} 는 등록 순서 그대로 순회 — primary 가 항상 첫 entry.
 */
public final class DefaultMultiEntityManager implements MultiEntityManager {

  private final Map<String, EntityManagerFactory> factories;
  private final String primaryName;

  public DefaultMultiEntityManager(
      String primaryName, Map<String, EntityManagerFactory> factories) {
    Objects.requireNonNull(primaryName, "primaryName");
    Objects.requireNonNull(factories, "factories");
    if (!factories.containsKey(primaryName)) {
      throw new IllegalArgumentException(
          "primary DataSource not registered: " + primaryName
              + ". Registered = " + factories.keySet());
    }
    Map<String, EntityManagerFactory> ordered = new LinkedHashMap<>();
    ordered.put(primaryName, factories.get(primaryName));
    for (Map.Entry<String, EntityManagerFactory> e : factories.entrySet()) {
      if (!e.getKey().equals(primaryName)) {
        ordered.put(e.getKey(), e.getValue());
      }
    }
    this.factories = Collections.unmodifiableMap(ordered);
    this.primaryName = primaryName;
  }

  @Override
  public EntityManagerExtensions on(String name) {
    Objects.requireNonNull(name, "name");
    EntityManagerFactory factory = factories.get(name);
    if (factory == null) {
      throw new IllegalArgumentException(
          "DataSource not registered: '" + name
              + "'. Registered = " + factories.keySet());
    }
    return new EntityManagerExtensions(factory.createEntityManager());
  }

  @Override
  public Set<String> dataSourceNames() {
    return factories.keySet();
  }

  @Override
  public String primaryName() {
    return primaryName;
  }

  @Override
  public void forEach(BiConsumer<String, EntityManagerExtensions> consumer) {
    Objects.requireNonNull(consumer, "consumer");
    for (Map.Entry<String, EntityManagerFactory> e : factories.entrySet()) {
      EntityManagerExtensions ext = new EntityManagerExtensions(e.getValue().createEntityManager());
      try {
        consumer.accept(e.getKey(), ext);
      } finally {
        ext.unwrap().close();
      }
    }
  }
}
