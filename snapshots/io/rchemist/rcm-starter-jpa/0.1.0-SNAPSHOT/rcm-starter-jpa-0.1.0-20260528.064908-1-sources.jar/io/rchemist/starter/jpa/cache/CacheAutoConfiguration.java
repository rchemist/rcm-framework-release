/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.persistence.EntityManagerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.hibernate.autoconfigure.HibernateJpaAutoConfiguration;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.support.NoOpCacheManager;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #1 — Decision #7 의 Cache 자동 통합 진입점. {@link CacheBackend} 4 모드 graceful
 * degradation:
 * <ul>
 *   <li>{@code none} — {@link NoOpCacheManager} (cache 비활성, 모든 호출 통과)</li>
 *   <li>{@code local-only} (default) — Caffeine {@link CaffeineCacheManager}</li>
 *   <li>{@code redis} — Redis 단독 (Phase 4 후속 또는 Consumer 명시 적용)</li>
 *   <li>{@code l1+l2} — Caffeine L1 + Redis L2 (Phase 4 후속)</li>
 * </ul>
 *
 * <p>opt-out = yml {@code platform.cache.enabled=false} (default = true). Consumer 가 자체 {@link
 * CacheManager} bean 적용 시 자동 교체 ({@code @ConditionalOnMissingBean}).
 *
 * <p>{@link CacheableEntityRegistry} 는 {@code EntityManagerFactory} 가용 시점 ({@link
 * HibernateJpaAutoConfiguration} 이후) bean 등록 — JPA metamodel 기반 자동 인식. {@link
 * CacheRegionInitializer} 가 등록된 entity 마다 {@link TwoTierCacheManager} 의 2-tier region 사전 생성.
 **/
@AutoConfiguration(after = HibernateJpaAutoConfiguration.class)
@ConditionalOnClass(CacheManager.class)
@ConditionalOnProperty(
    prefix = "platform.cache",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true)
@EnableCaching
@EnableConfigurationProperties(CacheProperties.class)
public class CacheAutoConfiguration {

  private static final Logger log = LoggerFactory.getLogger(CacheAutoConfiguration.class);

  @Bean(name = "rcmCacheManager")
  @ConditionalOnMissingBean(CacheManager.class)
  public CacheManager rcmCacheManager(
      CacheProperties properties, ObjectProvider<CacheMetricsRegistrar> metricsRegistrar) {
    return switch (properties.backend()) {
      case NONE -> new NoOpCacheManager();
      case LOCAL_ONLY -> caffeineManager(properties, metricsRegistrar);
      case REDIS, L1_L2 -> {
        log.warn(
            "platform.cache.backend = {} 는 Phase 4 후속 영역. baseline 은 LOCAL_ONLY 로 fallback.",
            properties.backend());
        yield caffeineManager(properties, metricsRegistrar);
      }
    };
  }

  private TwoTierCacheManager caffeineManager(
      CacheProperties properties, ObjectProvider<CacheMetricsRegistrar> metricsRegistrar) {
    TwoTierCacheManager manager = new TwoTierCacheManager();
    manager.configureDefaults(
        properties.defaultEntityMaxSize(),
        properties.defaultEntityTtl(),
        properties.defaultSearchMaxSize(),
        properties.defaultSearchTtl());
    manager.configureRegions(properties.regions());
    metricsRegistrar.ifAvailable(manager::setMetricsRegistrar);
    return manager;
  }

  @Bean(name = "rcmCacheMetricsRegistrar")
  @ConditionalOnClass(MeterRegistry.class)
  @ConditionalOnBean(MeterRegistry.class)
  @ConditionalOnMissingBean(CacheMetricsRegistrar.class)
  public CacheMetricsRegistrar rcmCacheMetricsRegistrar(MeterRegistry meterRegistry) {
    return new CacheMetricsRegistrar(meterRegistry);
  }

  @Bean(name = "rcmCacheableEntityRegistry")
  @ConditionalOnBean(EntityManagerFactory.class)
  @ConditionalOnMissingBean(CacheableEntityRegistry.class)
  public CacheableEntityRegistry rcmCacheableEntityRegistry(
      EntityManagerFactory entityManagerFactory) {
    return new CacheableEntityRegistry(entityManagerFactory);
  }

  @Bean(name = "rcmCacheRegionInitializer")
  @ConditionalOnBean({CacheableEntityRegistry.class, CacheManager.class})
  @ConditionalOnMissingBean(CacheRegionInitializer.class)
  public CacheRegionInitializer rcmCacheRegionInitializer(
      CacheableEntityRegistry registry, CacheManager cacheManager) {
    return new CacheRegionInitializer(registry, cacheManager);
  }

  @Bean(name = "rcmTenantAwareCacheKeyResolver")
  @ConditionalOnMissingBean(TenantAwareCacheKeyResolver.class)
  public TenantAwareCacheKeyResolver rcmTenantAwareCacheKeyResolver() {
    return new TenantAwareCacheKeyResolver();
  }

  @Bean(name = "rcmCacheStrategyResolver")
  @ConditionalOnMissingBean(CacheStrategyResolver.class)
  public CacheStrategyResolver rcmCacheStrategyResolver(CacheProperties properties) {
    return new CacheStrategyResolver(properties);
  }

  @Bean(name = "rcmEntityCacheStrategyRegistry")
  @ConditionalOnMissingBean(EntityCacheStrategyRegistry.class)
  public EntityCacheStrategyRegistry rcmEntityCacheStrategyRegistry(
      ObjectProvider<EntityCacheStrategy<?>> strategies) {
    return new EntityCacheStrategyRegistry(strategies.orderedStream().toList());
  }

  @Bean(name = "rcmCrudCacheAdvisor")
  @ConditionalOnBean({CacheManager.class, EntityManagerFactory.class})
  @ConditionalOnMissingBean(CrudCacheAdvisor.class)
  public CrudCacheAdvisor rcmCrudCacheAdvisor(
      CacheManager cacheManager,
      CacheStrategyResolver strategyResolver,
      TenantAwareCacheKeyResolver keyResolver,
      EntityCacheStrategyRegistry strategyRegistry,
      EntityManagerFactory entityManagerFactory) {
    return new CrudCacheAdvisor(
        cacheManager, strategyResolver, keyResolver, strategyRegistry, entityManagerFactory);
  }
}
