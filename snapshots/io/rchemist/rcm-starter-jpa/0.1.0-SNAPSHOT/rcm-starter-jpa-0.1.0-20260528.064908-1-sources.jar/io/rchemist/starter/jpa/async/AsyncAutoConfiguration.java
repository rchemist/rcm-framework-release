/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — Decision #13 의 async 영역 autoconfig. {@link AsyncJobTracker} singleton + actuator
 * endpoint (`@Endpoint` 가 classpath 에 있을 때만).
 *
 * <p>opt-out = yml {@code platform.async.enabled=false} (default = true).
 **/
@AutoConfiguration
@ConditionalOnProperty(
    prefix = "platform.async",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true)
public class AsyncAutoConfiguration {

  @Bean(name = "rcmAsyncJobTracker")
  @ConditionalOnMissingBean(AsyncJobTracker.class)
  public AsyncJobTracker rcmAsyncJobTracker() {
    return new AsyncJobTracker();
  }

  @Bean(name = "rcmAsyncJobsEndpoint")
  @ConditionalOnClass(Endpoint.class)
  @ConditionalOnBean(AsyncJobTracker.class)
  @ConditionalOnMissingBean(AsyncJobsEndpoint.class)
  public AsyncJobsEndpoint rcmAsyncJobsEndpoint(AsyncJobTracker tracker) {
    return new AsyncJobsEndpoint(tracker);
  }
}
