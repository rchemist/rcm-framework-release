/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.FieldDescriptor;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.QueryConditionType;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Subquery;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — 24 종 {@link QueryConditionType} → JPA Criteria {@link Predicate} 변환 (청사진
 * §5.5.6, 0.0.5 {@code FilterMapSearchForm} 흡수). 사용자 피드백 정합 — 단순 EQ/LIKE 외에 EXISTS/NOT
 * EXISTS, JSON_CONTAINS, 다단 path 적용.
 *
 * <p>책임 분리:
 * <ul>
 *   <li>{@link JoinAliasManager} — path 해석 + JOIN cache</li>
 *   <li>{@link ValueCoercer} — String → target type 변환</li>
 *   <li>본 클래스 — 24 case 매트릭스 + NOT 토글</li>
 * </ul>
 */
final class FilterDispatcher {

  private FilterDispatcher() {
  }

  /** FilterItem → Predicate. */
  static Predicate build(
      FilterItem item,
      JoinAliasManager joins,
      CriteriaBuilder cb,
      CriteriaQuery<?> query,
      EntityMetadata<?> metadata
  ) {
    QueryConditionType type = item.queryConditionType();
    String name = item.name();
    Expression<?> expr;
    if (ExpressionResolver.isFunctionCall(name)) {
      expr = ExpressionResolver.resolve(name, joins, cb);
    } else {
      expr = joins.resolvePath(name, item.joinType());
    }
    Class<?> fieldType = resolveFieldType(metadata, item, expr);

    Predicate base = buildBase(type, item, expr, fieldType, cb, query, joins, metadata);
    return Boolean.TRUE.equals(item.not()) ? cb.not(base) : base;
  }

  private static Class<?> resolveFieldType(
      EntityMetadata<?> metadata, FilterItem item, Expression<?> expr
  ) {
    if (item.fieldType() != null) {
      return item.fieldType();
    }
    if (!ExpressionResolver.isFunctionCall(item.name())) {
      Optional<? extends FieldDescriptor<?, ?>> desc =
          metadata.findField(rootSegment(item.name()));
      if (desc.isPresent()) {
        String head = rootSegment(item.name());
        if (head.equals(item.name())) {
          return desc.get().type();
        }
      }
    }
    return expr.getJavaType();
  }

  private static String rootSegment(String dotPath) {
    int dot = dotPath.indexOf('.');
    return dot > 0 ? dotPath.substring(0, dot) : dotPath;
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Predicate buildBase(
      QueryConditionType type, FilterItem item, Expression<?> expr, Class<?> fieldType,
      CriteriaBuilder cb, CriteriaQuery<?> query,
      JoinAliasManager joins, EntityMetadata<?> metadata
  ) {
    return switch (type) {
      case EQUAL -> cb.equal(expr, ValueCoercer.coerce(item.value(), fieldType));
      case NOT_EQUAL -> cb.notEqual(expr, ValueCoercer.coerce(item.value(), fieldType));
      case IN -> {
        if (item.values().isEmpty()) {
          yield cb.disjunction();
        }
        List<Object> coerced = coerceList(item.values(), fieldType);
        CriteriaBuilder.In<Object> in = cb.in((Expression<Object>) expr);
        for (Object v : coerced) {
          in.value(v);
        }
        yield in;
      }
      case NOT_IN -> {
        if (item.values().isEmpty()) {
          yield cb.conjunction();
        }
        CriteriaBuilder.In<Object> in = cb.in((Expression<Object>) expr);
        for (Object v : coerceList(item.values(), fieldType)) {
          in.value(v);
        }
        yield cb.not(in);
      }
      case LIKE -> {
        Expression<String> stringExpr = (Expression<String>) expr;
        yield cb.like(cb.lower(stringExpr), likePattern(item.value()).toLowerCase(Locale.ROOT),
            LIKE_ESCAPE_CHAR);
      }
      case NOT_LIKE -> {
        Expression<String> stringExpr = (Expression<String>) expr;
        yield cb.notLike(cb.lower(stringExpr), likePattern(item.value()).toLowerCase(Locale.ROOT),
            LIKE_ESCAPE_CHAR);
      }
      case GREATER_THAN -> compare(true, false, expr, item.value(), fieldType, cb);
      case GREATER_THAN_EQUAL -> compare(true, true, expr, item.value(), fieldType, cb);
      case LESS_THAN -> compare(false, false, expr, item.value(), fieldType, cb);
      case LESS_THAN_EQUAL -> compare(false, true, expr, item.value(), fieldType, cb);
      case BETWEEN, IN_RANGE -> {
        if (item.values().size() < 2) {
          yield cb.disjunction();
        }
        yield betweenPredicate(expr, fieldType, item.values().get(0), item.values().get(1), cb);
      }
      case NOT_IN_RANGE -> {
        if (item.values().size() < 2) {
          yield cb.conjunction();
        }
        yield cb.not(betweenPredicate(expr, fieldType, item.values().get(0), item.values().get(1), cb));
      }
      case IS_NULL -> cb.isNull(expr);
      case IS_NOT_NULL -> cb.isNotNull(expr);
      case IS_BLANK -> {
        Expression<String> stringExpr = (Expression<String>) expr;
        yield cb.or(cb.isNull(stringExpr), cb.equal(stringExpr, ""));
      }
      case IS_NOT_BLANK -> {
        Expression<String> stringExpr = (Expression<String>) expr;
        yield cb.and(cb.isNotNull(stringExpr), cb.notEqual(stringExpr, ""));
      }
      case NULL_OR_EQUAL ->
          cb.or(cb.isNull(expr), cb.equal(expr, ValueCoercer.coerce(item.value(), fieldType)));
      case NULL_OR_BLANK -> {
        Expression<String> stringExpr = (Expression<String>) expr;
        yield cb.or(cb.isNull(stringExpr), cb.equal(stringExpr, ""));
      }
      case DATE_BEFORE -> compare(false, false, expr, item.value(), fieldType, cb);
      case DATE_AFTER -> compare(true, false, expr, item.value(), fieldType, cb);
      case DATE_BETWEEN -> {
        if (item.values().size() < 2) {
          yield cb.disjunction();
        }
        yield betweenPredicate(expr, fieldType, item.values().get(0), item.values().get(1), cb);
      }
      case JSON_CONTAINS -> jsonContains(expr, item, cb, metadata);
      case EXISTS -> existsSubQuery(item, query, cb, joins);
    };
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Predicate compare(
      boolean greater, boolean orEqual, Expression<?> expr, String value,
      Class<?> fieldType, CriteriaBuilder cb
  ) {
    Object coerced = ValueCoercer.coerce(value, fieldType);
    if (coerced instanceof Comparable c) {
      Expression comparableExpr = expr;
      if (greater) {
        return orEqual ? cb.greaterThanOrEqualTo(comparableExpr, c)
            : cb.greaterThan(comparableExpr, c);
      }
      return orEqual ? cb.lessThanOrEqualTo(comparableExpr, c)
          : cb.lessThan(comparableExpr, c);
    }
    return cb.disjunction();
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Predicate betweenPredicate(
      Expression<?> expr, Class<?> fieldType, String from, String to, CriteriaBuilder cb
  ) {
    Object f = ValueCoercer.coerce(from, fieldType);
    Object t = ValueCoercer.coerce(to, fieldType);
    if (f instanceof Comparable && t instanceof Comparable) {
      return cb.between((Expression) expr, (Comparable) f, (Comparable) t);
    }
    return cb.disjunction();
  }

  /**
   * LIKE 패턴 적용 — 사용자 입력의 {@code %} / {@code _} 자동 escape (untrusted input 안전).
   *
   * <p>baseline 적용 정책:
   * <ol>
   *   <li>{@code null} → {@code "%"} (모든 값 매칭)</li>
   *   <li>입력에 escape character (\\) 있으면 → 사용자가 직접 escape 한 패턴 — 그대로 유지</li>
   *   <li>입력에 raw {@code %} / {@code _} 있으면 → escape 처리 후 {@code %xxx%} 자동 wrap</li>
   *   <li>일반 substring → escape 처리 후 {@code %xxx%} wrap</li>
   * </ol>
   *
   * <p>JPA standard {@code cb.like(expr, pattern, escape)} 가 모든 DBMS (PG/MySQL/MSSQL) 에서
   * {@code LIKE 'pattern' ESCAPE '\\'} 로 동등 변환 — multi-DB 안전.
   */
  static String likePattern(String value) {
    if (value == null) {
      return "%";
    }
    if (value.indexOf(LIKE_ESCAPE_CHAR) >= 0) {
      // 사용자가 직접 escape — 그대로.
      return value;
    }
    String escaped = value
        .replace("%", LIKE_ESCAPE_CHAR + "%")
        .replace("_", LIKE_ESCAPE_CHAR + "_");
    return "%" + escaped + "%";
  }

  /** LIKE escape character — JPA Criteria 의 {@code cb.like(..., char)} 와 정합 (DBMS 무관 표준). */
  static final char LIKE_ESCAPE_CHAR = '\\';

  private static List<Object> coerceList(List<String> raw, Class<?> targetType) {
    List<Object> out = new ArrayList<>(raw.size());
    for (String v : raw) {
      out.add(ValueCoercer.coerce(v, targetType));
    }
    return out;
  }

  /**
   * JSON_CONTAINS — Hibernate 7 의 jsonb 영역. baseline = path 가 JSON column → key 기반 LIKE 매칭.
   * 다단 path ({@code attributes.lang}) 는 column 으로 cast + JSON path query (Hibernate function).
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  private static Predicate jsonContains(
      Expression<?> expr, FilterItem item, CriteriaBuilder cb, EntityMetadata<?> metadata
  ) {
    if (item.value() == null) {
      return cb.isNotNull(expr);
    }
    // baseline = JSON column 의 string serialization 안 substring 매칭. 정확한 jsonb path query 는
    // Hibernate 7 의 sql_function 적용 영역 (Phase 4 정교화).
    Expression<String> asStr = expr.as(String.class);
    return cb.like(asStr, "%" + item.value() + "%");
  }

  /**
   * EXISTS — 단순 형태. {@code subFilters} 를 사용하지 않고 단일 column not-null 매칭으로 적용. 정교한
   * EXISTS SubQuery 는 {@link UnmappedJoinResolver} 영역.
   */
  private static Predicate existsSubQuery(
      FilterItem item, CriteriaQuery<?> query, CriteriaBuilder cb, JoinAliasManager joins
  ) {
    Path<?> path = joins.resolvePath(item.name(), item.joinType());
    if (item.value() == null) {
      return cb.isNotNull(path);
    }
    Subquery<Long> sub = query.subquery(Long.class);
    sub.select(cb.literal(1L));
    sub.where(cb.equal(path, ValueCoercer.coerce(item.value(), path.getJavaType())));
    return cb.exists(sub);
  }
}
