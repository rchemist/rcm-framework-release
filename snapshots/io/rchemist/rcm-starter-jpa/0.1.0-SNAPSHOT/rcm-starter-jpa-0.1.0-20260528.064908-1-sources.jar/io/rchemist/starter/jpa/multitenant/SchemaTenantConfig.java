/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.Map;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — SCHEMA 전략용 Hibernate {@link HibernatePropertiesCustomizer} (Decision #17).
 * {@link DatabaseTenantConfig} 와 동일 property key — 차이는 wire 되는 {@link
 * MultiTenantConnectionProvider} 가 {@link SchemaTenantConnectionProvider} 라는 점. 단일 shared
 * DataSource 위 {@code SET search_path} 적용.
 **/
public class SchemaTenantConfig implements HibernatePropertiesCustomizer {

  public static final String HIBERNATE_TENANT_RESOLVER = "hibernate.tenant_identifier_resolver";
  public static final String HIBERNATE_MULTI_TENANT_CONNECTION_PROVIDER =
      "hibernate.multi_tenant_connection_provider";

  private final CurrentTenantIdentifierResolver<String> resolver;
  private final MultiTenantConnectionProvider<String> connectionProvider;

  public SchemaTenantConfig(
      CurrentTenantIdentifierResolver<String> resolver,
      MultiTenantConnectionProvider<String> connectionProvider) {
    this.resolver = resolver;
    this.connectionProvider = connectionProvider;
  }

  @Override
  public void customize(Map<String, Object> hibernateProperties) {
    hibernateProperties.putIfAbsent(HIBERNATE_TENANT_RESOLVER, resolver);
    hibernateProperties.putIfAbsent(HIBERNATE_MULTI_TENANT_CONNECTION_PROVIDER, connectionProvider);
  }
}
