/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.softdelete;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #3 — Hibernate 7 native {@code @SoftDelete} baseline. SQL 레벨 자동 처리는 Hibernate
 * 가 담당 (DELETE = UPDATE deleted=true / SELECT 자동 deleted=false 필터). framework 책임 = autoconfig
 * 진입점 적용 + 후속 phase (search/cache) 에서 {@link io.rchemist.core.marker.SoftDelete} marker
 * 인식 hook (search filter / cache evict 영역).
 *
 * <p><b>본 클래스는 진입점 stub — 자동 부착 메커니즘 없음.</b> {@code @ConditionalOnClass} 가 Hibernate
 * 7 의 {@code @SoftDelete} class presence 만 확인하고 끝. *Consumer entity 가 직접 두 영역 모두 부착해야*
 * soft-delete 가 실제로 동작:
 *
 * <ol>
 *   <li><b>{@code @org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")}</b> — Hibernate 7
 *       SQL 변환 (DELETE → UPDATE / SELECT 자동 필터). 컨벤션 정합 = {@code IS_DELETED} (boolean
 *       prefix + UPPER_SNAKE, misc/readme.md §2.1.1.6).</li>
 *   <li><b>{@code implements io.rchemist.core.marker.SoftDelete}</b> — framework search / cache 영역
 *       의 marker 인식.</li>
 * </ol>
 *
 * <p><b>주의 — 둘 중 하나만 부착하면 silent bug</b>: marker 만 implements 하고 Hibernate 어노테이션
 * 누락 시 *컴파일 / 빌드 에러 없이* delete = hard delete 로 동작. 반대로 어노테이션만 부착하면
 * framework 의 marker 기반 search filter / cache evict 가 인식 못함. 둘 다 부착이 baseline.
 *
 * <p><b>reference 사례</b>: showcase 5 entity ({@code Article} / {@code Member} / {@code Order} /
 * {@code Payment} / {@code FileMetadataEntity}) + framework {@code Asset} (rcm-starter-asset) +
 * test sample {@code TestSoftDeleteEntity} 모두 두 영역 동시 부착.
 *
 * <p><b>Hibernate 7 제약</b>: {@code @SoftDelete} entity 를 {@code @ManyToOne(fetch = FetchType.LAZY)}
 * 로 참조하면 metamodel build 실패 (UnsupportedMappingException). EAGER fetch 강제. 1:1 / @OneToMany
 * 도 동일 검토 필요.
 *
 * <p>future 개선 후보 (charter §의문) — Hibernate Integrator 로 marker implements 시 자동 어노테이션
 * 부착. 본 sharp edge 영구 제거. 0.2.0 후보.
 **/
@AutoConfiguration
@ConditionalOnClass(name = "org.hibernate.annotations.SoftDelete")
public class SoftDeleteAutoConfiguration {}
