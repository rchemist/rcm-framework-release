/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — {@code platform.datasource.*} yml binding (Decision #18).
 *
 * <p>{@code primary} = 기본 DataSource 의 lookup name (default {@code "main"}). {@link
 * MultiEntityManager#on(String)} 가 본 이름으로 primary EntityManagerFactory 영역 lookup.
 *
 * <p>{@code additional} = 추가 DataSource 정의 (Decision §5.3 의 reporting / log 등). Map
 * key = lookup name, value = JDBC 영역 + read-only flag. Phase 3 baseline 은 *명시 등록만* —
 * 자동 EntityManagerFactory 생성 영역은 Phase 4 (Repository routing AOP) 시점에 보강.
 *
 * <p>예:
 * <pre>{@code
 * platform:
 *   datasource:
 *     primary: main          # default = "main"
 *     additional:
 *       reporting:
 *         url: jdbc:postgresql://...
 *         username: ...
 *         password: ...
 *         read-only: true
 *       log:
 *         url: jdbc:postgresql://...
 * }</pre>
 *
 * @param primary primary DataSource 의 lookup name (default {@code "main"})
 * @param additional 추가 DataSource map (lookup name → config). null = empty.
 */
@ConfigurationProperties("platform.datasource")
public record MultiDataSourceProperties(
    String primary,
    Map<String, DataSourceConfig> additional) {

  public MultiDataSourceProperties {
    if (primary == null || primary.isBlank()) {
      primary = "main";
    }
    if (additional == null) {
      additional = new LinkedHashMap<>();
    }
  }

  /** primary 가 명시 적용 안 되었을 때 default. */
  public static String defaultPrimaryName() {
    return "main";
  }

  /**
   * 추가 DataSource 영역.
   *
   * @param url JDBC URL
   * @param username login
   * @param password login
   * @param driverClassName JDBC driver FQN (null = auto detect via url)
   * @param readOnly read-only flag (null = false)
   */
  public record DataSourceConfig(
      String url,
      String username,
      String password,
      String driverClassName,
      Boolean readOnly) {

    public boolean isReadOnly() {
      return Boolean.TRUE.equals(readOnly);
    }
  }
}
