/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.AggregationRequest;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6f — Aggregation 실행 helper. {@link AggregatePlanner} 의 결과를 받아 EntityManager 의
 * CriteriaBuilder 로 Tuple query 실행. 결과는 alias key 기반 Map 형태로 변환.
 *
 * <p>실 운영 사용 패턴:
 * <pre>{@code
 * AggregateExecutor<Article> executor = new AggregateExecutor<>(em, Article.class);
 * AggregationRequest req = ...;
 * List<Map<String, Object>> rows = executor.execute(req);
 * }</pre>
 */
public final class AggregateExecutor<T> {

  private final EntityManager em;
  private final Class<T> entityClass;
  private final AggregatePlanner<T> planner;

  public AggregateExecutor(EntityManager em, Class<T> entityClass) {
    this.em = Objects.requireNonNull(em, "em");
    this.entityClass = Objects.requireNonNull(entityClass, "entityClass");
    this.planner = AggregatePlanner.forEntity(entityClass);
  }

  /** Aggregation 실행 — 결과를 alias key 기반 Map list 로. */
  public List<Map<String, Object>> execute(AggregationRequest req) {
    List<Tuple> tuples = executeRaw(req);
    return toMaps(tuples);
  }

  /** Aggregation 실행 — Tuple list 그대로 (advanced 영역). */
  public List<Tuple> executeRaw(AggregationRequest req) {
    Objects.requireNonNull(req, "req");
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<Tuple> query = cb.createTupleQuery();
    Root<T> root = query.from(entityClass);

    PlannedAggregate planned = planner.plan(req, root, query, cb);

    query.multiselect(planned.selections());
    if (!planned.groupByPaths().isEmpty()) {
      query.groupBy(planned.groupByPaths());
    }
    if (planned.where() != null) {
      query.where(planned.where());
    }
    if (planned.having() != null) {
      query.having(planned.having());
    }
    if (planned.distinct()) {
      query.distinct(true);
    }

    TypedQuery<Tuple> typed = em.createQuery(query);
    return typed.getResultList();
  }

  private List<Map<String, Object>> toMaps(List<Tuple> tuples) {
    List<Map<String, Object>> rows = new java.util.ArrayList<>(tuples.size());
    for (Tuple t : tuples) {
      Map<String, Object> row = new LinkedHashMap<>();
      for (jakarta.persistence.TupleElement<?> elem : t.getElements()) {
        row.put(elem.getAlias(), t.get(elem));
      }
      rows.add(row);
    }
    return rows;
  }

  public Class<T> entityClass() {
    return entityClass;
  }
}
