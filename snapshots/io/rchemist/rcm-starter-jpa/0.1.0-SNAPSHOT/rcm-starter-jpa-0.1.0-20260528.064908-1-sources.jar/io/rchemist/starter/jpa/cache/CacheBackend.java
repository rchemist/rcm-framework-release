/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #1 — Decision #7 의 backend graceful degradation 4 모드. yml {@code platform.cache.backend}
 * 단일 키로 전환. 작은 SI 의 Redis 부재 환경 자연 지원.
 *
 * <p>{@link #NONE} = NoOp CacheManager (cache 비활성, 모든 호출 통과 — 개발/테스트 영역).
 * {@link #LOCAL_ONLY} = Caffeine 단독 (단일 인스턴스 / 멀티 노드 invalidation 미보장 — 작은 SI default).
 * {@link #REDIS} = Redis 단독 (멀티 노드 일관성 / 네트워크 hop 비용).
 * {@link #L1_L2} = Caffeine L1 + Redis L2 (hot data L1 / fallback L2 / Pub/Sub invalidation).
 **/
public enum CacheBackend {

  NONE,

  LOCAL_ONLY,

  REDIS,

  L1_L2
}
