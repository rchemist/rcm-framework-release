/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #4 — Multi-tenant baseline autoconfig (Decision #17). Phase 3 task #5 보강 — strategy
 * 별 autoconfig 가 별도 4 class 분리:
 * {@link DiscriminatorMultiTenantAutoConfiguration} / {@link DatabaseMultiTenantAutoConfiguration} /
 * {@link SchemaMultiTenantAutoConfiguration}.
 *
 * <p>본 class 는 strategy-agnostic 영역만 적용 — {@link CurrentTenantIdentifierResolver} +
 * {@link TenantManagementService} + {@link TenantMigrationRunner}. Consumer 가 자체 customizer /
 * resolver / management service 적용 시 자동 교체 ({@code @ConditionalOnMissingBean}).
 *
 * <p>opt-out = yml {@code platform.tenant.enabled=false} (default = true).
 **/
@AutoConfiguration
@ConditionalOnClass(name = "org.hibernate.context.spi.CurrentTenantIdentifierResolver")
@ConditionalOnProperty(
    prefix = "platform.tenant",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true)
@EnableConfigurationProperties(TenantProperties.class)
public class MultiTenantAutoConfiguration {

  @Bean(name = "rcmTenantIdentifierResolver")
  @ConditionalOnMissingBean(CurrentTenantIdentifierResolver.class)
  public CurrentTenantIdentifierResolver<String> rcmTenantIdentifierResolver() {
    return new TenantIdentifierResolver();
  }

  @Bean
  @ConditionalOnMissingBean(TenantManagementService.class)
  public TenantManagementService rcmTenantManagementService(
      ObjectProvider<DataSourceRegistry> dataSourceRegistry,
      ObjectProvider<SchemaInitializer> schemaInitializer,
      ObjectProvider<TenantMigrator> migrators) {
    return new DefaultTenantManagementService(dataSourceRegistry, schemaInitializer, migrators);
  }

  @Bean
  @ConditionalOnMissingBean(TenantMigrationRunner.class)
  public TenantMigrationRunner rcmTenantMigrationRunner(
      TenantManagementService tenantService,
      ObjectProvider<TenantMigrator> migrators,
      TenantProperties properties) {
    return new TenantMigrationRunner(
        tenantService, migrators.orderedStream().toList(), properties.migration().parallel());
  }
}
