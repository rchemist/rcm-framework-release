/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.core.context.TenantContext;
import java.util.List;
import java.util.Objects;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — startup 시점에 모든 active tenant 순회 + 등록된 모든 {@link TenantMigrator} 실행
 * (Decision #17). 신규 onboard 시점의 migration 은 {@link DefaultTenantManagementService#onboard}
 * 가 직접 호출 — 본 runner 는 application restart 시 *기존* tenant 의 누락된 migration 적용 적용.
 *
 * <p>{@code platform.tenant.migration.parallel=true} 시 {@code parallelStream} 사용 — 신규 tenant
 * 다수일 때 startup 시간 단축. default = false (직렬, 결정적 순서).
 *
 * <p>각 tenant migration 은 {@link TenantContext#runAs(String, Runnable)} scope 안에서 실행 —
 * migrator 가 Hibernate 의 multi-tenant connection 을 받기 위해. {@link Ordered#LOWEST_PRECEDENCE} —
 * 다른 ApplicationRunner 보다 늦게 (DataSource 가 fully initialized 상태에서).
 **/
@Order(Ordered.LOWEST_PRECEDENCE)
public class TenantMigrationRunner implements ApplicationRunner {

  private final TenantManagementService tenantService;
  private final List<TenantMigrator> migrators;
  private final boolean parallel;

  public TenantMigrationRunner(
      TenantManagementService tenantService, List<TenantMigrator> migrators, boolean parallel) {
    this.tenantService = Objects.requireNonNull(tenantService, "tenantService");
    this.migrators = List.copyOf(Objects.requireNonNull(migrators, "migrators"));
    this.parallel = parallel;
  }

  @Override
  public void run(ApplicationArguments args) {
    if (migrators.isEmpty()) {
      return;
    }
    List<String> tenants = tenantService.activeTenants();
    if (tenants.isEmpty()) {
      return;
    }
    if (parallel) {
      tenants.parallelStream().forEach(this::migrateTenant);
    } else {
      tenants.forEach(this::migrateTenant);
    }
  }

  private void migrateTenant(String tenantId) {
    TenantConfig config =
        tenantService
            .findConfig(tenantId)
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "Tenant disappeared between activeTenants() and findConfig(): "
                            + tenantId));
    TenantContext.runAs(tenantId, () -> migrators.forEach(migrator -> migrator.migrate(config)));
  }
}
