/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.id;

import java.util.Map;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.resource.beans.container.spi.BeanContainer;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.core.Ordered;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #21 — Spring Boot 가 등록한 {@code SpringBeanContainer} 를 {@link
 * GeneratorAwareBeanContainer} 로 wrap 하는 {@link HibernatePropertiesCustomizer}.
 *
 * <p>{@link Ordered#LOWEST_PRECEDENCE} 명시 — Spring Boot 자체 customizer (default-ordered) 가
 * {@link AvailableSettings#BEAN_CONTAINER} 항목을 properties 에 채운 *후* 본 customizer 가 그것을
 * 감싸서 replace. 가드: 항목이 {@link BeanContainer} 인스턴스 아닐 때 (consumer 자체 customizer 가
 * null 처리한 경우 등) no-op.
 *
 * <p>Consumer 가 자체 BeanContainer customizer 적용 시 {@link
 * org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean} (bean name 기반) 으로
 * 자동 양보 — autoconfig 에서 합류.
 **/
public class GeneratorAwareBeanContainerCustomizer
    implements HibernatePropertiesCustomizer, Ordered {

  @Override
  public int getOrder() {
    return Ordered.LOWEST_PRECEDENCE;
  }

  @Override
  public void customize(Map<String, Object> hibernateProperties) {
    Object existing = hibernateProperties.get(AvailableSettings.BEAN_CONTAINER);
    if (existing instanceof BeanContainer delegate
        && !(existing instanceof GeneratorAwareBeanContainer)) {
      hibernateProperties.put(
          AvailableSettings.BEAN_CONTAINER, new GeneratorAwareBeanContainer(delegate));
    }
  }
}
