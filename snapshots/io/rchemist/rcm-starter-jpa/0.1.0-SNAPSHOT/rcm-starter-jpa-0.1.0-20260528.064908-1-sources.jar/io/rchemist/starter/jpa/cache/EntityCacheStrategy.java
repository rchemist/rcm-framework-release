/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import io.rchemist.extension.ExtensionPoint;
import org.springframework.cache.CacheManager;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #7 — Decision #7 의 Consumer fine-grained cache override SPI. entity 별 cache 동작
 * 을 framework default 위에 *얇게* 끼어들기. {@link AbstractCrudService} ↔ cache 결합 영역 (Phase 4
 * task #8) 이 본 SPI 인입.
 *
 * <p>4 hook 모두 default = framework 기본 동작 통과 (override 없이 Consumer 등록 = 자동 결합 그대로).
 *
 * <p>cross-entity invalidation = {@link #onCustomEvict(Object, CacheManager)} 명시 작성 또는 Spring
 * 표준 {@code @CacheEvict} (Decision #9 — framework 추상화 X, gjcu 1~2% 영역).
 *
 * @param <T> entity 타입
 **/
@ExtensionPoint("Entity 별 cache 동작 fine-grained override")
public interface EntityCacheStrategy<T> {

  /** 본 strategy 가 어떤 entity class 를 담당하는지. {@link AbstractCrudService} 가 lookup 시 사용. */
  Class<T> entityType();

  /**
   * cache key 명시 적용 — null 반환 시 framework default ({@link TenantAwareCacheKeyResolver} 결과)
   * 사용. entity 자체는 cache write/evict 시점이라 advisor 가 결정 — Consumer 는 id 영역만으로 key 작성.
   */
  default Object cacheKey(Object id) {
    return null;
  }

  /** false 반환 시 본 entity 는 cache 적재 영역 통과 (skip). default = true (모든 entity cache 적재). */
  default boolean shouldCache(T entity) {
    return true;
  }

  /**
   * update 시점 evict 결정 — false 반환 시 cache 유지 (immutable field 만 변경되는 등 cache 무효화 불필요
   * 영역). default = true (모든 update 시 evict).
   */
  default boolean shouldEvictOnUpdate(T before, T after) {
    return true;
  }

  /**
   * cross-entity / 복합 evict 명시 작성 영역. {@link AbstractCrudService} 의 write (create/update/
   * delete) 직후 호출. default = no-op.
   */
  default void onCustomEvict(T entity, CacheManager cacheManager) {}
}
