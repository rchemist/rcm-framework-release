/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — {@code /actuator/async-jobs} read-only endpoint. {@link AsyncJobTracker} 의 store
 * 노출 — 운영 영역에서 진행 / 완료 / 실패 / DLQ job 목록 / 단건 조회.
 **/
@Endpoint(id = "async-jobs")
public class AsyncJobsEndpoint {

  private final AsyncJobTracker tracker;

  public AsyncJobsEndpoint(AsyncJobTracker tracker) {
    this.tracker = tracker;
  }

  @ReadOperation
  public Map<String, Object> jobs() {
    Map<String, Object> response = new LinkedHashMap<>();
    response.put("size", tracker.size());
    response.put("running", tracker.withStatus(AsyncJobStatus.RUNNING));
    response.put("queued", tracker.withStatus(AsyncJobStatus.QUEUED));
    response.put("failed", tracker.withStatus(AsyncJobStatus.FAILED));
    response.put("dlq", tracker.withStatus(AsyncJobStatus.DLQ));
    response.put("completed", tracker.withStatus(AsyncJobStatus.COMPLETED));
    return response;
  }

  @ReadOperation
  public List<AsyncJob> byStatus(@Selector AsyncJobStatus status) {
    return tracker.withStatus(status);
  }
}
