/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.converter;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5b — {@link LinkedHashMap} wrapper. {@code Map<String,String>} 입력 순서 보존 +
 * Hibernate dirty checking 정확도 적용 (Map 순서 변경도 dirty 감지). {@link
 * OrderedMapAttributeConverter} 와 짝.
 *
 * <p>{@link #equals(Object)} 가 *키 순서* 까지 비교 — 같은 (key, value) 집합이지만 순서가 다른 두 instance
 * 는 NOT equal. 0.0.5 의 동일 패턴 옮김 (실무 검증된 dirty checking 정확도).
 **/
public class OrderedMapWrapper implements Map<String, String> {

  private final LinkedHashMap<String, String> map;

  public OrderedMapWrapper() {
    this.map = new LinkedHashMap<>();
  }

  public OrderedMapWrapper(Map<String, String> source) {
    this.map = new LinkedHashMap<>();
    if (source != null) {
      this.map.putAll(source);
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;

    OrderedMapWrapper other = (OrderedMapWrapper) obj;

    if (map.size() != other.map.size()) return false;

    Iterator<String> thisIter = map.keySet().iterator();
    Iterator<String> otherIter = other.map.keySet().iterator();

    while (thisIter.hasNext() && otherIter.hasNext()) {
      String thisKey = thisIter.next();
      String otherKey = otherIter.next();

      if (!Objects.equals(thisKey, otherKey)) {
        return false;
      }
      if (!Objects.equals(map.get(thisKey), other.map.get(otherKey))) {
        return false;
      }
    }
    return true;
  }

  @Override
  public int hashCode() {
    int result = 1;
    for (Map.Entry<String, String> entry : map.entrySet()) {
      result = 31 * result + Objects.hashCode(entry.getKey());
      result = 31 * result + Objects.hashCode(entry.getValue());
    }
    return result;
  }

  @Override
  public String toString() {
    return map.toString();
  }

  @Override
  public int size() {
    return map.size();
  }

  @Override
  public boolean isEmpty() {
    return map.isEmpty();
  }

  @Override
  public boolean containsKey(Object key) {
    return map.containsKey(key);
  }

  @Override
  public boolean containsValue(Object value) {
    return map.containsValue(value);
  }

  @Override
  public String get(Object key) {
    return map.get(key);
  }

  @Override
  public String put(String key, String value) {
    return map.put(key, value);
  }

  @Override
  public String remove(Object key) {
    return map.remove(key);
  }

  @Override
  public void putAll(Map<? extends String, ? extends String> m) {
    map.putAll(m);
  }

  @Override
  public void clear() {
    map.clear();
  }

  @Override
  public Set<String> keySet() {
    return map.keySet();
  }

  @Override
  public Collection<String> values() {
    return map.values();
  }

  @Override
  public Set<Map.Entry<String, String>> entrySet() {
    return map.entrySet();
  }

  /** {@link LinkedHashMap} defensive copy. */
  public LinkedHashMap<String, String> getMap() {
    return new LinkedHashMap<>(map);
  }
}
