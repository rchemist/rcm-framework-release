/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — DISCRIMINATOR 전략 autoconfig (Decision #17 baseline, Phase 3 task #4 적용 영역).
 * {@code platform.tenant.strategy=discriminator} (default) 시 활성. entity 의 {@code @TenantId}
 * 어노테이션 단일 적용로 동작.
 **/
@AutoConfiguration(after = MultiTenantAutoConfiguration.class)
@ConditionalOnClass(name = "org.hibernate.context.spi.CurrentTenantIdentifierResolver")
@ConditionalOnProperty(
    prefix = "platform.tenant",
    name = "strategy",
    havingValue = "discriminator",
    matchIfMissing = true)
@EnableConfigurationProperties(TenantProperties.class)
public class DiscriminatorMultiTenantAutoConfiguration {

  @Bean(name = "rcmDiscriminatorTenantConfig")
  @ConditionalOnMissingBean(name = "rcmDiscriminatorTenantConfig")
  public HibernatePropertiesCustomizer rcmDiscriminatorTenantConfig(
      CurrentTenantIdentifierResolver<String> resolver) {
    return new DiscriminatorTenantConfig(resolver);
  }
}
