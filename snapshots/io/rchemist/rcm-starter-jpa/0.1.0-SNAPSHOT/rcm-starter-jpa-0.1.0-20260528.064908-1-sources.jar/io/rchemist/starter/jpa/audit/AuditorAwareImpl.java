/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.audit;

import io.rchemist.core.context.UserContext;
import java.util.Optional;
import org.springframework.data.domain.AuditorAware;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #2 — Spring Data {@link AuditorAware} baseline impl. {@link UserContext} ScopedValue
 * 적용 시 그 userId 인입, 미적용 시 {@link #SYSTEM_AUDITOR} ({@code __system__}) fallback.
 *
 * <p>Background task / @Scheduled / Bootstrap 영역에서는 UserContext 미적용가 자연 — 그 경우
 * {@code __system__} 으로 audit field 적용. Decision #17 의 Bootstrap connection / Cross-tenant
 * {@code runAsSystem} 와 정합.
 **/
public class AuditorAwareImpl implements AuditorAware<String> {

  public static final String SYSTEM_AUDITOR = "__system__";

  @Override
  public Optional<String> getCurrentAuditor() {
    String userId = UserContext.currentUserIdOrNull();
    return Optional.of(userId != null ? userId : SYSTEM_AUDITOR);
  }
}
