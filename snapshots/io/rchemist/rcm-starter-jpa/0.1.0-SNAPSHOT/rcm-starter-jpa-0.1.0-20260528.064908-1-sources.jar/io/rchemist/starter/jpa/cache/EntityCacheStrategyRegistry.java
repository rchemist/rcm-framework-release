/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #7 — {@link EntityCacheStrategy} 등록 영역 lookup. {@link AbstractCrudService} ↔ cache
 * 결합 (Phase 4 task #8) 이 entity Class → 등록된 strategy 조회. Spring DI 가 모든 implement bean 인입
 * 후 {@code entityType()} 으로 indexed Map 구축.
 *
 * <p>같은 entity 에 strategy 가 2 개 이상 등록되면 Fail-loud (마지막 등록만 살아남는 silent override 거부).
 **/
public class EntityCacheStrategyRegistry {

  private final Map<Class<?>, EntityCacheStrategy<?>> byEntityType;

  public EntityCacheStrategyRegistry(Collection<? extends EntityCacheStrategy<?>> strategies) {
    Map<Class<?>, EntityCacheStrategy<?>> map = new HashMap<>();
    for (EntityCacheStrategy<?> strategy : strategies) {
      Class<?> entityType = strategy.entityType();
      EntityCacheStrategy<?> existing = map.put(entityType, strategy);
      if (existing != null) {
        throw new IllegalStateException(
            "Duplicate EntityCacheStrategy for entity "
                + entityType.getName()
                + ": "
                + existing.getClass().getName()
                + " and "
                + strategy.getClass().getName());
      }
    }
    this.byEntityType = Collections.unmodifiableMap(map);
  }

  public EntityCacheStrategyRegistry() {
    this(List.of());
  }

  @SuppressWarnings("unchecked")
  public <T> Optional<EntityCacheStrategy<T>> find(Class<T> entityClass) {
    EntityCacheStrategy<?> strategy = byEntityType.get(entityClass);
    return Optional.ofNullable((EntityCacheStrategy<T>) strategy);
  }

  public int size() {
    return byEntityType.size();
  }
}
