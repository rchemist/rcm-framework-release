/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.core.context.TenantContext;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;
import javax.sql.DataSource;
import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Hibernate 7 {@link AbstractDataSourceBasedMultiTenantConnectionProviderImpl}
 * SCHEMA 전략 구현 (Decision #17). 단일 shared {@link DataSource} 위 {@code SET search_path TO
 * <tenantSchema>} 적용. PostgreSQL baseline (다른 dialect 시 SQL syntax 다름 — Consumer 가 자체
 * impl 적용).
 *
 * <p>{@link #getConnection(String)} 진입 시 {@link TenantManagementService#findConfig(String)} 로
 * schemaName 조회 + SQL 실행. {@link #releaseConnection(String, Connection)} 시 search_path
 * DEFAULT 복구 (HikariCP pool 재사용 시 영향 차단). {@link TenantContext#SYSTEM_TENANT_ID} tenant 는
 * search_path 변경 없이 default schema 사용.
 **/
public class SchemaTenantConnectionProvider
    extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl<String> {

  private final transient BootstrapConnectionProvider bootstrap;
  private final transient TenantManagementService tenantService;

  public SchemaTenantConnectionProvider(
      BootstrapConnectionProvider bootstrap, TenantManagementService tenantService) {
    this.bootstrap = Objects.requireNonNull(bootstrap, "bootstrap");
    this.tenantService = Objects.requireNonNull(tenantService, "tenantService");
  }

  @Override
  protected DataSource selectAnyDataSource() {
    return bootstrap.sharedDataSource();
  }

  @Override
  protected DataSource selectDataSource(String tenantIdentifier) {
    return bootstrap.sharedDataSource();
  }

  @Override
  public Connection getConnection(String tenantIdentifier) throws SQLException {
    Connection conn = super.getConnection(tenantIdentifier);
    if (tenantIdentifier == null || TenantContext.SYSTEM_TENANT_ID.equals(tenantIdentifier)) {
      return conn;
    }
    String schema = resolveSchema(tenantIdentifier);
    try (Statement stmt = conn.createStatement()) {
      stmt.execute("SET search_path TO " + quoteIdent(schema));
    } catch (SQLException e) {
      conn.close();
      throw e;
    }
    return conn;
  }

  @Override
  public void releaseConnection(String tenantIdentifier, Connection connection) throws SQLException {
    if (tenantIdentifier != null && !TenantContext.SYSTEM_TENANT_ID.equals(tenantIdentifier)) {
      try (Statement stmt = connection.createStatement()) {
        stmt.execute("SET search_path TO DEFAULT");
      } catch (SQLException ignored) {
        // pool 복귀 시 default 복구 실패는 fatal 이 아님 (다음 사용 시 재설정).
      }
    }
    super.releaseConnection(tenantIdentifier, connection);
  }

  private String resolveSchema(String tenantIdentifier) {
    TenantConfig config =
        tenantService
            .findConfig(tenantIdentifier)
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "Unknown tenant — onboard first via TenantManagementService: tenant="
                            + tenantIdentifier));
    String schemaName = config.schemaName();
    return schemaName != null ? schemaName : tenantIdentifier;
  }

  /** PostgreSQL identifier quoting — 대소문자 보존 + reserved word 방어. */
  private String quoteIdent(String name) {
    return "\"" + name.replace("\"", "\"\"") + "\"";
  }
}
