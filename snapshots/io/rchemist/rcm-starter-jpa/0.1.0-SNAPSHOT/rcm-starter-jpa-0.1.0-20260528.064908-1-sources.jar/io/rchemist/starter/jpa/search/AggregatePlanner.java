/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.Aggregation;
import io.rchemist.core.search.AggregationFunction;
import io.rchemist.core.search.AggregationRequest;
import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.SearchRequest;
import jakarta.persistence.Tuple;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Selection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6f — {@link AggregationRequest} → JPA Criteria Tuple query 변환.
 *
 * <p>JOIN alias 정합 = {@link SearchRequestPlanner} 와 동일 영역 — {@link JoinAliasManager} 공유.
 * filter ↔ groupBy ↔ having ↔ aggregations 의 path 가 같은 alias 로 join.
 *
 * <p>모든 함수 (COUNT/SUM/AVG/MIN/MAX) = SQL:2003 표준 — DBMS (PG/MySQL/MSSQL) 무관 일관 결과.
 */
public final class AggregatePlanner<T> {

  private final EntityMetadata<T> metadata;

  public AggregatePlanner(EntityMetadata<T> metadata) {
    this.metadata = Objects.requireNonNull(metadata, "metadata");
  }

  public static <T> AggregatePlanner<T> forEntity(Class<T> entityClass) {
    return new AggregatePlanner<>(EntityMetadataRegistry.require(entityClass));
  }

  public EntityMetadata<T> metadata() {
    return metadata;
  }

  /**
   * Aggregation plan 생성. caller 가 {@code query.multiselect / where / groupBy / having} 적용.
   */
  public PlannedAggregate plan(
      AggregationRequest req, Root<T> root, CriteriaQuery<Tuple> query, CriteriaBuilder cb
  ) {
    Objects.requireNonNull(req, "req");
    Objects.requireNonNull(root, "root");
    Objects.requireNonNull(query, "query");
    Objects.requireNonNull(cb, "cb");

    JoinAliasManager joins = new JoinAliasManager(root, metadata);

    // (1) GroupBy paths
    List<Expression<?>> groupByPaths = new ArrayList<>(req.groupBy().size());
    Map<String, Selection<?>> namedSelections = new LinkedHashMap<>();
    for (String groupField : req.groupBy()) {
      Path<?> path = joins.resolvePath(groupField, null);
      groupByPaths.add(path);
      namedSelections.put(groupField, path.alias(groupField));
    }

    // (2) Aggregation selections
    for (Aggregation agg : req.aggregations()) {
      Selection<?> sel = aggregateSelection(agg, root, joins, cb).alias(agg.alias());
      namedSelections.put(agg.alias(), sel);
    }

    // (3) Filter (where) — baseSearch 의 filter 영역 재사용
    Predicate wherePredicate = buildBaseFilter(req.baseSearch(), root, query, cb, joins);

    // (4) Having predicate — alias 또는 path 기반.
    Predicate havingPredicate = buildHaving(req.having(), namedSelections, root, joins, cb, query);

    boolean distinct = joins.hasCollectionJoin();
    return new PlannedAggregate(
        new ArrayList<>(namedSelections.values()),
        groupByPaths,
        wherePredicate,
        havingPredicate,
        distinct);
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  private Expression<?> aggregateSelection(
      Aggregation agg, Root<T> root, JoinAliasManager joins, CriteriaBuilder cb
  ) {
    if (agg.function() == AggregationFunction.COUNT && "*".equals(agg.field())) {
      return cb.count(root);
    }
    Path<?> path = joins.resolvePath(agg.field(), null);
    return switch (agg.function()) {
      case COUNT -> cb.count(path);
      case COUNT_DISTINCT -> cb.countDistinct(path);
      case SUM -> cb.sum((Expression<Number>) path);
      case AVG -> cb.avg((Expression<Number>) path);
      case MIN -> cb.least((Expression) path);
      case MAX -> cb.greatest((Expression) path);
    };
  }

  private Predicate buildBaseFilter(
      SearchRequest base, Root<T> root, CriteriaQuery<?> query,
      CriteriaBuilder cb, JoinAliasManager joins
  ) {
    if (base == null || base.filters() == null || base.filters().isEmpty()) {
      return null;
    }
    List<Predicate> groups = new ArrayList<>();
    for (Map.Entry<LogicalOperator, List<FilterItem>> e : base.filters().entrySet()) {
      List<Predicate> inner = new ArrayList<>(e.getValue().size());
      for (FilterItem item : e.getValue()) {
        inner.add(FilterDispatcher.build(item, joins, cb, query, metadata));
      }
      if (inner.isEmpty()) {
        continue;
      }
      Predicate[] arr = inner.toArray(Predicate[]::new);
      groups.add(switch (e.getKey()) {
        case AND -> cb.and(arr);
        case OR -> cb.or(arr);
        case NOT -> cb.not(cb.and(arr));
      });
    }
    if (groups.isEmpty()) {
      return null;
    }
    return groups.size() == 1 ? groups.get(0) : cb.and(groups.toArray(Predicate[]::new));
  }

  /**
   * HAVING — name 이 (a) aggregation alias (e.g. {@code "sum_viewCount"}) 또는 (b) groupBy field 일 수
   * 있다. alias 매칭이면 해당 selection expression 으로, 아니면 일반 path 영역 dispatcher 사용.
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  private Predicate buildHaving(
      List<FilterItem> having, Map<String, Selection<?>> namedSelections,
      Root<T> root, JoinAliasManager joins, CriteriaBuilder cb, CriteriaQuery<?> query
  ) {
    if (having == null || having.isEmpty()) {
      return null;
    }
    List<Predicate> ps = new ArrayList<>(having.size());
    for (FilterItem item : having) {
      Selection<?> sel = namedSelections.get(item.name());
      if (sel instanceof Expression<?> aliasedExpr) {
        ps.add(havingPredicateOnExpression((Expression<Object>) aliasedExpr, item, cb));
      } else {
        // alias 미매칭 — 일반 path filter 로 처리.
        ps.add(FilterDispatcher.build(item, joins, cb, query, metadata));
      }
    }
    if (ps.isEmpty()) {
      return null;
    }
    return cb.and(ps.toArray(Predicate[]::new));
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private Predicate havingPredicateOnExpression(
      Expression<Object> expr, FilterItem item, CriteriaBuilder cb
  ) {
    Class<?> targetType = expr.getJavaType();
    Object coerced = ValueCoercer.coerce(item.value(), targetType);
    Predicate base = switch (item.queryConditionType()) {
      case EQUAL -> cb.equal(expr, coerced);
      case NOT_EQUAL -> cb.notEqual(expr, coerced);
      case GREATER_THAN -> cb.greaterThan((Expression) expr, (Comparable) coerced);
      case GREATER_THAN_EQUAL -> cb.greaterThanOrEqualTo((Expression) expr, (Comparable) coerced);
      case LESS_THAN -> cb.lessThan((Expression) expr, (Comparable) coerced);
      case LESS_THAN_EQUAL -> cb.lessThanOrEqualTo((Expression) expr, (Comparable) coerced);
      case IS_NULL -> cb.isNull(expr);
      case IS_NOT_NULL -> cb.isNotNull(expr);
      case BETWEEN -> {
        if (item.values().size() < 2) {
          yield cb.disjunction();
        }
        Comparable from = (Comparable) ValueCoercer.coerce(item.values().get(0), targetType);
        Comparable to = (Comparable) ValueCoercer.coerce(item.values().get(1), targetType);
        yield cb.between((Expression) expr, from, to);
      }
      default -> throw new IllegalArgumentException(
          "HAVING 영역에서 미지원 QueryConditionType: " + item.queryConditionType());
    };
    return Boolean.TRUE.equals(item.not()) ? cb.not(base) : base;
  }
}
