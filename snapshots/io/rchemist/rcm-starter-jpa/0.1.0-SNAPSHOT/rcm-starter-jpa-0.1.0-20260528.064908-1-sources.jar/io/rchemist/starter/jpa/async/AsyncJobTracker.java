/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.async;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #9 — Decision #13 의 async job 추적 store. in-memory ({@link ConcurrentHashMap})
 * 단일 노드 baseline. 다중 노드 환경 = Consumer 가 자체 Redis-backed Tracker 적용 (`@ConditionalOnMissingBean`).
 *
 * <p>lifecycle 메서드:
 * <ul>
 *   <li>{@link #register(String, String)} — id 명시, QUEUED 상태로 신규 등록 (id 중복 시 Fail-loud)</li>
 *   <li>{@link #registerNew(String)} — id 자동 (UUID), QUEUED 상태로 신규 등록</li>
 *   <li>{@link #start(String)} — QUEUED → RUNNING</li>
 *   <li>{@link #updateProgress(String, int)} — RUNNING 상태에서 progress 갱신</li>
 *   <li>{@link #complete(String)} — RUNNING → COMPLETED (terminal)</li>
 *   <li>{@link #fail(String, String)} — RUNNING → FAILED (retry 가능 상태)</li>
 *   <li>{@link #cancel(String)} — RUNNING → CANCELLED (terminal)</li>
 *   <li>{@link #retry(String)} — FAILED → QUEUED (retryCount + 1)</li>
 *   <li>{@link #moveToDlq(String)} — FAILED → DLQ (terminal)</li>
 * </ul>
 **/
public class AsyncJobTracker {

  private final Map<String, AsyncJob> jobs = new ConcurrentHashMap<>();

  public AsyncJob register(String id, String type) {
    Objects.requireNonNull(id, "id");
    Objects.requireNonNull(type, "type");
    AsyncJob job = AsyncJob.queued(id, type);
    AsyncJob existing = jobs.putIfAbsent(id, job);
    if (existing != null) {
      throw new IllegalStateException("Async job already exists: " + id);
    }
    return job;
  }

  public AsyncJob registerNew(String type) {
    return register(UUID.randomUUID().toString(), type);
  }

  public AsyncJob start(String id) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.QUEUED) {
            throw new IllegalStateException(
                "Cannot start job from status " + existing.status() + ": " + id);
          }
          return new AsyncJob(
              existing.id(),
              existing.type(),
              AsyncJobStatus.RUNNING,
              0,
              existing.queuedAt(),
              Instant.now(),
              null,
              null,
              existing.retryCount());
        });
  }

  public AsyncJob updateProgress(String id, int progress) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.RUNNING) {
            throw new IllegalStateException(
                "Cannot update progress on non-running job (" + existing.status() + "): " + id);
          }
          return existing.withProgress(progress);
        });
  }

  public AsyncJob complete(String id) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.RUNNING) {
            throw new IllegalStateException(
                "Cannot complete job from status " + existing.status() + ": " + id);
          }
          return new AsyncJob(
              existing.id(),
              existing.type(),
              AsyncJobStatus.COMPLETED,
              100,
              existing.queuedAt(),
              existing.startedAt(),
              Instant.now(),
              null,
              existing.retryCount());
        });
  }

  public AsyncJob fail(String id, String error) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.RUNNING) {
            throw new IllegalStateException(
                "Cannot fail job from status " + existing.status() + ": " + id);
          }
          return new AsyncJob(
              existing.id(),
              existing.type(),
              AsyncJobStatus.FAILED,
              existing.progress(),
              existing.queuedAt(),
              existing.startedAt(),
              Instant.now(),
              error,
              existing.retryCount());
        });
  }

  public AsyncJob cancel(String id) {
    return mutate(
        id,
        existing -> {
          if (existing.status().isTerminal()) {
            throw new IllegalStateException(
                "Cannot cancel terminal job (" + existing.status() + "): " + id);
          }
          return new AsyncJob(
              existing.id(),
              existing.type(),
              AsyncJobStatus.CANCELLED,
              existing.progress(),
              existing.queuedAt(),
              existing.startedAt(),
              Instant.now(),
              existing.error(),
              existing.retryCount());
        });
  }

  public AsyncJob retry(String id) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.FAILED) {
            throw new IllegalStateException(
                "Cannot retry job from status " + existing.status() + ": " + id);
          }
          return new AsyncJob(
              existing.id(),
              existing.type(),
              AsyncJobStatus.QUEUED,
              0,
              existing.queuedAt(),
              null,
              null,
              null,
              existing.retryCount() + 1);
        });
  }

  public AsyncJob moveToDlq(String id) {
    return mutate(
        id,
        existing -> {
          if (existing.status() != AsyncJobStatus.FAILED) {
            throw new IllegalStateException(
                "Cannot move to DLQ from status " + existing.status() + ": " + id);
          }
          return existing.withStatus(AsyncJobStatus.DLQ);
        });
  }

  public Optional<AsyncJob> find(String id) {
    return Optional.ofNullable(jobs.get(id));
  }

  public List<AsyncJob> all() {
    return jobs.values().stream()
        .sorted(Comparator.comparing(AsyncJob::queuedAt).reversed())
        .toList();
  }

  public List<AsyncJob> withStatus(AsyncJobStatus status) {
    return jobs.values().stream()
        .filter(j -> j.status() == status)
        .sorted(Comparator.comparing(AsyncJob::queuedAt).reversed())
        .toList();
  }

  public int size() {
    return jobs.size();
  }

  private AsyncJob mutate(String id, java.util.function.UnaryOperator<AsyncJob> op) {
    Objects.requireNonNull(id, "id");
    AsyncJob updated =
        jobs.compute(
            id,
            (key, existing) -> {
              if (existing == null) {
                throw new IllegalStateException("Async job not found: " + key);
              }
              return op.apply(existing);
            });
    return updated;
  }
}
