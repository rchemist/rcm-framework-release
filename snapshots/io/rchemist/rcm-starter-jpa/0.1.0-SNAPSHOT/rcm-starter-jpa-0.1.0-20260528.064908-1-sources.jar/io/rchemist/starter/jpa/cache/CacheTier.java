/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #2 — 2-tier region 의 tier 구분. {@link #ENTITY} = 단건 lookup (id 키 + entity 값,
 * 큰 size + 긴 TTL), {@link #SEARCH_LIST} = 검색 결과 page (SearchRequest hash 키 + Page 값, 작은 size +
 * 짧은 TTL).
 **/
public enum CacheTier {

  ENTITY,

  SEARCH_LIST
}
