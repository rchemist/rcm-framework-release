/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.util.Objects;
import javax.sql.DataSource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Bootstrap / cross-tenant {@code __system__} 영역 공유 DataSource wrapper
 * (Decision #17 — Bootstrap connection / Cross-tenant runAsSystem). Hibernate 의 "any connection"
 * 요청 (DDL / 표준 metadata 조회) 과 {@link io.rchemist.core.context.TenantContext#SYSTEM_TENANT_ID}
 * tenant 진입 시 사용. Spring Boot 의 primary {@link DataSource} 가 default 적용 — Consumer 는 별도
 * autoconfig 적용 시 자동 교체.
 *
 * <p>thin wrapper — DATABASE 전략의 {@link DataSourceTenantConnectionProvider} 와 SCHEMA 전략의
 * {@link SchemaTenantConnectionProvider} 가 공통으로 받음. 테스트 격리 및 명시적 의도 표현 목적.
 **/
public class BootstrapConnectionProvider {

  private final DataSource sharedDataSource;

  public BootstrapConnectionProvider(DataSource sharedDataSource) {
    this.sharedDataSource = Objects.requireNonNull(sharedDataSource, "sharedDataSource");
  }

  public DataSource sharedDataSource() {
    return sharedDataSource;
  }
}
