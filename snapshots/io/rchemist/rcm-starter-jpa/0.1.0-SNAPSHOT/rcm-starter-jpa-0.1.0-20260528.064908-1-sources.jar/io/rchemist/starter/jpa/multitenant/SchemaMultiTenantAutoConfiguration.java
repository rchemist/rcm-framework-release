/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import javax.sql.DataSource;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — SCHEMA 전략 autoconfig (Decision #17). 단일 shared DataSource 위
 * {@code SET search_path} 적용. {@code platform.tenant.strategy=schema} 시 활성. PostgreSQL baseline
 * ({@link PostgresSchemaInitializer} default — 다른 DBMS 시 Consumer 가 자체 {@link SchemaInitializer}).
 **/
@AutoConfiguration(after = MultiTenantAutoConfiguration.class)
@ConditionalOnClass(name = "org.hibernate.context.spi.CurrentTenantIdentifierResolver")
@ConditionalOnProperty(prefix = "platform.tenant", name = "strategy", havingValue = "schema")
@EnableConfigurationProperties(TenantProperties.class)
public class SchemaMultiTenantAutoConfiguration {

  @Bean(name = "rcmBootstrapConnectionProvider")
  @ConditionalOnMissingBean(BootstrapConnectionProvider.class)
  public BootstrapConnectionProvider rcmBootstrapConnectionProvider(DataSource dataSource) {
    return new BootstrapConnectionProvider(dataSource);
  }

  @Bean(name = "rcmPostgresSchemaInitializer")
  @ConditionalOnMissingBean(SchemaInitializer.class)
  public SchemaInitializer rcmPostgresSchemaInitializer(BootstrapConnectionProvider bootstrap) {
    return new PostgresSchemaInitializer(bootstrap);
  }

  @Bean(name = "rcmSchemaTenantConnectionProvider")
  @ConditionalOnMissingBean(MultiTenantConnectionProvider.class)
  public MultiTenantConnectionProvider<String> rcmSchemaTenantConnectionProvider(
      BootstrapConnectionProvider bootstrap, TenantManagementService tenantService) {
    return new SchemaTenantConnectionProvider(bootstrap, tenantService);
  }

  @Bean(name = "rcmSchemaTenantConfig")
  @ConditionalOnMissingBean(name = "rcmSchemaTenantConfig")
  public HibernatePropertiesCustomizer rcmSchemaTenantConfig(
      CurrentTenantIdentifierResolver<String> resolver,
      MultiTenantConnectionProvider<String> connectionProvider) {
    return new SchemaTenantConfig(resolver, connectionProvider);
  }
}
