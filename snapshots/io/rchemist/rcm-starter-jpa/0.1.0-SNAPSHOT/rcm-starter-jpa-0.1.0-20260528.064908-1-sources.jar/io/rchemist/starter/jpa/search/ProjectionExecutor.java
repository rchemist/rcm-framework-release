/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import io.rchemist.core.search.EntityMetadata;
import io.rchemist.core.search.EntityMetadataRegistry;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.LogicalOperator;
import io.rchemist.core.search.NormalSortInfo;
import io.rchemist.core.search.PrioritySortInfo;
import io.rchemist.core.search.ProjectionRequest;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SortInfo;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Selection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6g — {@link ProjectionRequest} 실행 helper. Tuple 또는 DTO constructor projection.
 *
 * <p>Tuple 영역 = {@link #execute} 가 alias key 기반 {@code List<Map<String, Object>>} 반환.
 * DTO 영역 = {@link #executeDto} 가 사용자 DTO class instance list 반환.
 *
 * <p>filter / sort / pagination 영역 = {@link SearchRequestPlanner} 와 동일 — {@link JoinAliasManager}
 * 공유 + {@link FilterDispatcher} 위임 + {@link SortBuilder} 위임.
 */
public final class ProjectionExecutor<T> {

  private final EntityManager em;
  private final Class<T> entityClass;
  private final EntityMetadata<T> metadata;

  public ProjectionExecutor(EntityManager em, Class<T> entityClass) {
    this.em = Objects.requireNonNull(em, "em");
    this.entityClass = Objects.requireNonNull(entityClass, "entityClass");
    this.metadata = EntityMetadataRegistry.require(entityClass);
  }

  /** Tuple 영역 — alias = field path. */
  public List<Map<String, Object>> execute(ProjectionRequest req) {
    Objects.requireNonNull(req, "req");
    if (req.dtoClass() != null) {
      throw new IllegalArgumentException(
          "DTO projection 영역은 executeDto(...) 사용. dtoClass=" + req.dtoClass().getName());
    }

    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<Tuple> query = cb.createTupleQuery();
    Root<T> root = query.from(entityClass);
    JoinAliasManager joins = new JoinAliasManager(root, metadata);

    List<Selection<?>> selections = new ArrayList<>(req.fields().size());
    for (String field : req.fields()) {
      Path<?> path = joins.resolvePath(field, null);
      selections.add(path.alias(field));
    }
    query.multiselect(selections);

    applyFilter(req.baseSearch(), root, query, cb, joins);
    applySort(req.baseSearch(), query, cb, joins);
    applyDistinct(query, joins);

    TypedQuery<Tuple> typed = em.createQuery(query);
    applyPagination(typed, req.baseSearch());

    List<Tuple> tuples = typed.getResultList();
    return toMaps(tuples);
  }

  /** DTO constructor projection 영역. fields 의 type 이 dto constructor 와 정확 일치 필요. */
  @SuppressWarnings("unchecked")
  public <D> List<D> executeDto(ProjectionRequest req, Class<D> dtoClass) {
    Objects.requireNonNull(req, "req");
    Objects.requireNonNull(dtoClass, "dtoClass");

    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<D> query = cb.createQuery(dtoClass);
    Root<T> root = query.from(entityClass);
    JoinAliasManager joins = new JoinAliasManager(root, metadata);

    List<Selection<?>> selections = new ArrayList<>(req.fields().size());
    for (String field : req.fields()) {
      selections.add(joins.resolvePath(field, null));
    }
    query.select(cb.construct(dtoClass, selections.toArray(Selection[]::new)));

    applyFilter(req.baseSearch(), root, query, cb, joins);
    applySort(req.baseSearch(), query, cb, joins);
    applyDistinct(query, joins);

    TypedQuery<D> typed = em.createQuery(query);
    applyPagination(typed, req.baseSearch());
    return typed.getResultList();
  }

  private void applyFilter(
      SearchRequest base, Root<T> root, CriteriaQuery<?> query,
      CriteriaBuilder cb, JoinAliasManager joins
  ) {
    if (base == null || base.filters() == null || base.filters().isEmpty()) {
      return;
    }
    List<Predicate> groups = new ArrayList<>();
    for (Map.Entry<LogicalOperator, List<FilterItem>> e : base.filters().entrySet()) {
      List<Predicate> inner = new ArrayList<>(e.getValue().size());
      for (FilterItem item : e.getValue()) {
        inner.add(FilterDispatcher.build(item, joins, cb, query, metadata));
      }
      if (inner.isEmpty()) {
        continue;
      }
      Predicate[] arr = inner.toArray(Predicate[]::new);
      groups.add(switch (e.getKey()) {
        case AND -> cb.and(arr);
        case OR -> cb.or(arr);
        case NOT -> cb.not(cb.and(arr));
      });
    }
    if (!groups.isEmpty()) {
      query.where(groups.size() == 1 ? groups.get(0) : cb.and(groups.toArray(Predicate[]::new)));
    }
  }

  private void applySort(
      SearchRequest base, CriteriaQuery<?> query, CriteriaBuilder cb, JoinAliasManager joins
  ) {
    if (base == null || base.sorts() == null || base.sorts().isEmpty()) {
      return;
    }
    List<SortInfo> sorts = base.sorts();
    boolean hasOnlyValid = sorts.stream().allMatch(s ->
        s instanceof NormalSortInfo || s instanceof PrioritySortInfo);
    if (!hasOnlyValid) {
      return;
    }
    List<Order> orders = SortBuilder.build(base, joins, cb);
    if (!orders.isEmpty()) {
      query.orderBy(orders);
    }
  }

  private void applyDistinct(CriteriaQuery<?> query, JoinAliasManager joins) {
    if (joins.hasCollectionJoin()) {
      query.distinct(true);
    }
  }

  private void applyPagination(TypedQuery<?> typed, SearchRequest base) {
    if (base == null) {
      return;
    }
    if (base.page() != null && base.pageSize() != null
        && base.pageSize() > 0 && base.pageSize() < Integer.MAX_VALUE) {
      typed.setFirstResult(base.page() * base.pageSize());
      typed.setMaxResults(base.pageSize());
    }
  }

  private List<Map<String, Object>> toMaps(List<Tuple> tuples) {
    List<Map<String, Object>> rows = new ArrayList<>(tuples.size());
    for (Tuple t : tuples) {
      Map<String, Object> row = new LinkedHashMap<>();
      for (jakarta.persistence.TupleElement<?> elem : t.getElements()) {
        row.put(elem.getAlias(), t.get(elem));
      }
      rows.add(row);
    }
    return rows;
  }

  public Class<T> entityClass() {
    return entityClass;
  }
}
