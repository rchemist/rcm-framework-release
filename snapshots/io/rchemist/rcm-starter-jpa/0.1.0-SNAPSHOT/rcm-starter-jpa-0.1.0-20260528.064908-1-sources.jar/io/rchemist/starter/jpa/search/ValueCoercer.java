/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.UUID;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6c — String 값 (frontend wire format) → entity field 의 target type 자동 변환.
 * {@link io.rchemist.core.search.FieldDescriptor#type()} 기반.
 *
 * <p>{@link FilterDispatcher} 가 Predicate 빌드 직전 호출.
 */
final class ValueCoercer {

  private ValueCoercer() {
  }

  /** {@code null}-safe value coercion — null 입력 → null 반환. */
  static Object coerce(String value, Class<?> targetType) {
    if (value == null) {
      return null;
    }
    if (targetType == null || targetType == String.class || targetType == Object.class) {
      return value;
    }
    if (targetType == Long.class || targetType == long.class) {
      return Long.parseLong(value.trim());
    }
    if (targetType == Integer.class || targetType == int.class) {
      return Integer.parseInt(value.trim());
    }
    if (targetType == Short.class || targetType == short.class) {
      return Short.parseShort(value.trim());
    }
    if (targetType == Byte.class || targetType == byte.class) {
      return Byte.parseByte(value.trim());
    }
    if (targetType == Double.class || targetType == double.class) {
      return Double.parseDouble(value.trim());
    }
    if (targetType == Float.class || targetType == float.class) {
      return Float.parseFloat(value.trim());
    }
    if (targetType == Boolean.class || targetType == boolean.class) {
      return Boolean.parseBoolean(value.trim());
    }
    if (targetType == BigDecimal.class) {
      return new BigDecimal(value.trim());
    }
    if (targetType == BigInteger.class) {
      return new BigInteger(value.trim());
    }
    if (targetType == UUID.class) {
      return UUID.fromString(value.trim());
    }
    if (targetType == Instant.class) {
      return parseInstant(value);
    }
    if (targetType == LocalDate.class) {
      return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
    }
    if (targetType == LocalDateTime.class) {
      return LocalDateTime.parse(value, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }
    if (targetType == OffsetDateTime.class) {
      return OffsetDateTime.parse(value);
    }
    if (targetType == ZonedDateTime.class) {
      return ZonedDateTime.parse(value);
    }
    if (Enum.class.isAssignableFrom(targetType)) {
      @SuppressWarnings({"unchecked", "rawtypes"})
      Object e = Enum.valueOf((Class<Enum>) targetType, value.trim());
      return e;
    }
    return value;
  }

  /** Instant — ISO_INSTANT 우선, 실패 시 LocalDateTime 가정 (UTC offset). */
  private static Instant parseInstant(String value) {
    try {
      return Instant.parse(value);
    } catch (DateTimeParseException e) {
      try {
        return LocalDateTime.parse(value).toInstant(ZoneOffset.UTC);
      } catch (DateTimeParseException nested) {
        return LocalDate.parse(value).atStartOfDay().toInstant(ZoneOffset.UTC);
      }
    }
  }
}
