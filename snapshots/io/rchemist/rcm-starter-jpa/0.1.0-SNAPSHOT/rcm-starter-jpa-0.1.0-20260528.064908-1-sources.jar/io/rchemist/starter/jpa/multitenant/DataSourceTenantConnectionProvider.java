/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import io.rchemist.core.context.TenantContext;
import java.util.Objects;
import javax.sql.DataSource;
import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — Hibernate 7 {@link AbstractDataSourceBasedMultiTenantConnectionProviderImpl}
 * DATABASE 전략 구현 (Decision #17). tenant 별 별도 DataSource pool ({@link DataSourceRegistry} 위임).
 * {@link TenantContext#SYSTEM_TENANT_ID} = bootstrap shared DataSource (DDL / Hibernate metadata
 * 조회 영역).
 *
 * <p>{@link #selectAnyDataSource()} 가 {@link BootstrapConnectionProvider} 의 shared DataSource
 * 반환. {@link #selectDataSource(String)} 이 system tenant 면 shared, 그 외엔 registry 위임.
 **/
public class DataSourceTenantConnectionProvider
    extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl<String> {

  private final transient BootstrapConnectionProvider bootstrap;
  private final transient DataSourceRegistry registry;

  public DataSourceTenantConnectionProvider(
      BootstrapConnectionProvider bootstrap, DataSourceRegistry registry) {
    this.bootstrap = Objects.requireNonNull(bootstrap, "bootstrap");
    this.registry = Objects.requireNonNull(registry, "registry");
  }

  @Override
  protected DataSource selectAnyDataSource() {
    return bootstrap.sharedDataSource();
  }

  @Override
  protected DataSource selectDataSource(String tenantIdentifier) {
    if (tenantIdentifier == null || TenantContext.SYSTEM_TENANT_ID.equals(tenantIdentifier)) {
      return bootstrap.sharedDataSource();
    }
    return registry.getDataSource(tenantIdentifier);
  }
}
