/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.datasource;

import jakarta.persistence.EntityManagerFactory;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #9 — Decision #18 의 multi-DataSource baseline autoconfig. {@link
 * MultiEntityManager} bean 자동 등록 — primary {@link EntityManagerFactory} (Spring Boot 자동
 * 생성) 를 {@code primaryName} (default {@code "main"}) 로 등록 + Consumer 가 추가 EMF bean 등록 시
 * (Phase 4 의 Repository routing AOP 시점) 자동 흡수 (ObjectProvider 기반).
 *
 * <p>baseline 책임:
 * <ul>
 *   <li>{@link MultiDataSourceProperties} yml binding</li>
 *   <li>{@link MultiEntityManager} bean (기본 = primary EMF 만 등록된 단일 entry, Consumer
 *       추가 등록 시 자동 합성)</li>
 * </ul>
 *
 * <p>Phase 4 보강 영역 — {@link DataSource @DataSource} annotation AOP / Spring Data
 * {@code entityManagerFactoryRef} resolver / 추가 DataSource HikariDataSource pool 자동 생성 +
 * EntityManagerFactory 자동 등록은 후속 phase 영역. 본 task 는 SPI 와 baseline routing 까지.
 **/
@AutoConfiguration
@ConditionalOnClass(EntityManagerFactory.class)
@EnableConfigurationProperties(MultiDataSourceProperties.class)
public class MultiDataSourceAutoConfiguration {

  /**
   * primary {@link EntityManagerFactory} + Spring 이 모든 EMF bean 자동 수집한 map 흡수해서
   * {@link MultiEntityManager} bean 등록. 추가 EMF 등록 영역의 lookup name 은 bean name 기준 —
   * Consumer 가 {@code @Bean(name = "reporting") EntityManagerFactory ...} 적용 시 그대로 활용.
   *
   * <p>Spring 이 {@code Map<String, EntityManagerFactory>} 영역 → 모든 EMF bean 을 bean name
   * 키로 inject. primary 식별 = (a) {@link MultiDataSourceProperties#primary()} 에 명시된 bean
   * name 일치 영역 (b) Spring Boot default bean name {@code entityManagerFactory} 를 properties.primary()
   * 로 매핑. (a)/(b) 모두 누락 = primary 만 단일 entry 로 등록.
   */
  @Bean
  @ConditionalOnMissingBean(MultiEntityManager.class)
  public MultiEntityManager rcmMultiEntityManager(
      EntityManagerFactory primaryEntityManagerFactory,
      Map<String, EntityManagerFactory> entityManagerFactoryBeans,
      MultiDataSourceProperties properties) {
    String primary = properties.primary();
    Map<String, EntityManagerFactory> all = new LinkedHashMap<>();
    all.put(primary, primaryEntityManagerFactory);
    for (Map.Entry<String, EntityManagerFactory> e : entityManagerFactoryBeans.entrySet()) {
      if (e.getValue() == primaryEntityManagerFactory) {
        continue;
      }
      if (e.getKey().equals(primary)) {
        continue;
      }
      all.put(e.getKey(), e.getValue());
    }
    return new DefaultMultiEntityManager(primary, all);
  }
}
