/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.id;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import org.hibernate.annotations.IdGeneratorType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Hibernate 7 분산 TSID generator annotation — Decision #21 옵션. Consumer entity 의 ID 필드에 부착.
 *
 * <p>{@code hypersistence-tsid} 라이브러리 + Hibernate 7 의 {@link IdGeneratorType} 메커니즘. 필드 타입은
 * {@code Long} / {@code String} 모두 지원 — {@link TsidIdentifierGenerator} 가 런타임에 적합 변환.
 *
 * <p>사용 예:
 * <pre>{@code
 * @Id
 * @TsidGenerator
 * private Long id;
 * }</pre>
 *
 * <p>{@link #node()} 명시 시 분산 환경에서 노드별 분리 (default = JVM 자동 — hypersistence-tsid 의
 * {@code TSID.Factory.builder().withNode(node).build()} 위임).
 **/
@IdGeneratorType(TsidIdentifierGenerator.class)
@Retention(RUNTIME)
@Target({FIELD, METHOD})
public @interface TsidGenerator {

    /** 노드 ID — default {@code -1} = JVM 자동 (env / hostname). 명시 시 0..1023 범위. */
    int node() default -1;
}
