/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.search;

import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Selection;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6f — {@link AggregatePlanner} 의 결과. caller 가 query.multiselect / where /
 * groupBy / having 적용.
 *
 * @param selections   SELECT 영역 (groupBy paths + aggregation selections)
 * @param groupByPaths GROUP BY 영역 (groupBy column expressions)
 * @param where        WHERE predicate (null = no filter)
 * @param having       HAVING predicate (null = no having)
 * @param distinct     ONE_TO_MANY/ManyToMany JOIN 발견 시 자동 true
 */
public record PlannedAggregate(
    List<Selection<?>> selections,
    List<Expression<?>> groupByPaths,
    Predicate where,
    Predicate having,
    boolean distinct
) {
  public PlannedAggregate {
    selections = selections == null ? List.of() : List.copyOf(selections);
    groupByPaths = groupByPaths == null ? List.of() : List.copyOf(groupByPaths);
  }
}
