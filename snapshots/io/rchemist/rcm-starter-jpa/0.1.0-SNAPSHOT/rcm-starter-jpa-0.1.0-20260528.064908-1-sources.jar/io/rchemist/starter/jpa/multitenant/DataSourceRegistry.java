/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import javax.sql.DataSource;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — DATABASE 전략용 per-tenant {@link HikariDataSource} pool registry (Decision
 * #17). LRU evict 정책 (memory 보호) — {@code maxActiveTenants} 초과 시 가장 오래된 pool {@code close()}.
 * evict 된 tenant 는 다음 요청 시점에 {@link TenantConfig} 기반으로 재생성 (config 영구 보관).
 *
 * <p>{@link TenantManagementService#onboard(TenantConfig)} 가 {@link #register(TenantConfig)} 호출,
 * {@link DataSourceTenantConnectionProvider#selectDataSource(String)} 가 {@link
 * #getDataSource(String)} 호출. {@code close()} 는 {@link #closeAll()} (Spring shutdown).
 **/
public class DataSourceRegistry implements AutoCloseable {

  private final ConcurrentMap<String, TenantConfig> configs = new ConcurrentHashMap<>();

  /** access-order = true → LRU. {@link #removeEldestEntry} 가 maxActiveTenants 초과 시 close + evict. */
  private final LinkedHashMap<String, HikariDataSource> activePools;

  private final int maxActiveTenants;
  private final int perTenantMaximumPoolSize;

  public DataSourceRegistry(int maxActiveTenants, int perTenantMaximumPoolSize) {
    if (maxActiveTenants <= 0) {
      throw new IllegalArgumentException("maxActiveTenants must be > 0: " + maxActiveTenants);
    }
    if (perTenantMaximumPoolSize <= 0) {
      throw new IllegalArgumentException(
          "perTenantMaximumPoolSize must be > 0: " + perTenantMaximumPoolSize);
    }
    this.maxActiveTenants = maxActiveTenants;
    this.perTenantMaximumPoolSize = perTenantMaximumPoolSize;
    this.activePools =
        new LinkedHashMap<>(16, 0.75f, true) {
          @Override
          protected boolean removeEldestEntry(Map.Entry<String, HikariDataSource> eldest) {
            if (size() > DataSourceRegistry.this.maxActiveTenants) {
              eldest.getValue().close();
              return true;
            }
            return false;
          }
        };
  }

  public void register(TenantConfig config) {
    Objects.requireNonNull(config, "config");
    if (config.jdbcUrl() == null) {
      throw new IllegalArgumentException(
          "TenantConfig.jdbcUrl is required for DATABASE strategy: tenant=" + config.tenantId());
    }
    configs.put(config.tenantId(), config);
  }

  public synchronized DataSource getDataSource(String tenantId) {
    Objects.requireNonNull(tenantId, "tenantId");
    HikariDataSource pool = activePools.get(tenantId);
    if (pool != null) {
      return pool;
    }
    TenantConfig config = configs.get(tenantId);
    if (config == null) {
      throw new IllegalStateException(
          "Unknown tenant — onboard first via TenantManagementService: tenant=" + tenantId);
    }
    pool = createPool(config);
    activePools.put(tenantId, pool);
    return pool;
  }

  public synchronized void evict(String tenantId) {
    Objects.requireNonNull(tenantId, "tenantId");
    configs.remove(tenantId);
    HikariDataSource pool = activePools.remove(tenantId);
    if (pool != null) {
      pool.close();
    }
  }

  /** evict 가 발생했는지 테스트 검증 helper. */
  public synchronized int activePoolCount() {
    return activePools.size();
  }

  public boolean isRegistered(String tenantId) {
    return configs.containsKey(tenantId);
  }

  @Override
  public synchronized void close() {
    activePools.values().forEach(HikariDataSource::close);
    activePools.clear();
    configs.clear();
  }

  public synchronized void closeAll() {
    close();
  }

  protected HikariDataSource createPool(TenantConfig config) {
    HikariConfig hikari = new HikariConfig();
    hikari.setJdbcUrl(config.jdbcUrl());
    if (config.username() != null) {
      hikari.setUsername(config.username());
    }
    if (config.password() != null) {
      hikari.setPassword(config.password());
    }
    hikari.setMaximumPoolSize(perTenantMaximumPoolSize);
    hikari.setPoolName("rcm-tenant-" + config.tenantId());
    return new HikariDataSource(hikari);
  }
}
