/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.multitenant;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #5 — PostgreSQL용 {@link SchemaInitializer} default impl (Decision #17). {@code
 * CREATE SCHEMA IF NOT EXISTS <name>} 적용. {@link BootstrapConnectionProvider} shared DataSource
 * 위에서 실행 ({@code __system__} tenant 컨텍스트). 다른 DBMS / 별도 권한 model 이 필요하면 Consumer 가
 * 자체 impl 적용 → {@code @ConditionalOnMissingBean(SchemaInitializer.class)} 자동 교체.
 **/
public class PostgresSchemaInitializer implements SchemaInitializer {

  private final BootstrapConnectionProvider bootstrap;

  public PostgresSchemaInitializer(BootstrapConnectionProvider bootstrap) {
    this.bootstrap = Objects.requireNonNull(bootstrap, "bootstrap");
  }

  @Override
  public void createSchema(TenantConfig config) {
    Objects.requireNonNull(config, "config");
    String schema = config.schemaName() != null ? config.schemaName() : config.tenantId();
    try (Connection conn = bootstrap.sharedDataSource().getConnection();
        Statement stmt = conn.createStatement()) {
      stmt.execute("CREATE SCHEMA IF NOT EXISTS " + quoteIdent(schema));
    } catch (SQLException e) {
      throw new IllegalStateException(
          "Failed to create schema for tenant=" + config.tenantId() + " schema=" + schema, e);
    }
  }

  private String quoteIdent(String name) {
    return "\"" + name.replace("\"", "\"\"") + "\"";
  }
}
