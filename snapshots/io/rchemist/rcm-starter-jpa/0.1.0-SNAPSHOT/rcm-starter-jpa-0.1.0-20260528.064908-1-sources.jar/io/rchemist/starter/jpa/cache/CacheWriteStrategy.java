/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #6 — Decision #7 의 cache write 3 전략. {@link AbstractCrudService} 의 CRUD 5 method
 * 가 본 enum 따라 cache 동작 변경 (Phase 4 task #8 영역).
 *
 * <p>{@link #WRITE_THROUGH} — write (create/update) 시 즉시 entity_cache put + search_list evict.
 * read latency 최우선 (write 직후 동일 key read = cache hit). DB write + cache write 양쪽 비용.
 *
 * <p>{@link #WRITE_AROUND} — write 시 즉시 entity_cache evict + search_list evict (cache 갱신 X).
 * write 직후 read = cache miss + DB read + cache 적재. write 비용 최소화 + read 비일관성 영역 거부.
 *
 * <p>{@link #READ_THROUGH} (default) — read 시 자동 적재만. write = entity_cache evict + search_list
 * evict. 가장 일반적인 패턴. lazy load + write invalidation.
 **/
public enum CacheWriteStrategy {

  WRITE_THROUGH,

  WRITE_AROUND,

  READ_THROUGH
}
