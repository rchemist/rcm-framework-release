/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.jpa.cache;

import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 4 task #6 — entity Class → {@link ResolvedCacheStrategy} 변환. 우선순위 = yml ({@link
 * CacheProperties.Region}) > annotation ({@link CacheStrategy}) > {@link CacheProperties} global
 * default. 결과 cache (entity 당 1 회 resolve, immutable).
 *
 * <p>region naming 영역:
 * <ul>
 *   <li>{@code @CacheStrategy(region = "...")} 명시 적용 시 entity_cache region = 명시값 + 그대로 ({@link
 *       CacheRegionNames#ENTITY_SUFFIX} 안 붙음 — 사용자 의도 보존), search_list_cache region = 명시값 +
 *       {@code _search_list} suffix</li>
 *   <li>미명시 시 default = {@link CacheRegionNames#entityCacheName(Class)} / {@link
 *       CacheRegionNames#searchListCacheName(Class)}</li>
 * </ul>
 **/
public class CacheStrategyResolver {

  private final CacheProperties properties;
  private final Map<Class<?>, ResolvedCacheStrategy> cache = new ConcurrentHashMap<>();

  public CacheStrategyResolver(CacheProperties properties) {
    this.properties = Objects.requireNonNull(properties, "properties");
  }

  public ResolvedCacheStrategy resolve(Class<?> entityClass) {
    Objects.requireNonNull(entityClass, "entityClass");
    return cache.computeIfAbsent(entityClass, this::resolveInternal);
  }

  private ResolvedCacheStrategy resolveInternal(Class<?> entityClass) {
    CacheStrategy annotation = entityClass.getAnnotation(CacheStrategy.class);

    String entityRegion;
    String searchListRegion;
    if (annotation != null && !annotation.region().isEmpty()) {
      entityRegion = annotation.region();
      searchListRegion = annotation.region() + "_search_list";
    } else {
      entityRegion = CacheRegionNames.entityCacheName(entityClass);
      searchListRegion = CacheRegionNames.searchListCacheName(entityClass);
    }

    Duration entityTtl = properties.defaultEntityTtl();
    long entityMaxSize = properties.defaultEntityMaxSize();
    Duration searchListTtl = properties.defaultSearchTtl();
    long searchListMaxSize = properties.defaultSearchMaxSize();
    CacheWriteStrategy writeStrategy = CacheWriteStrategy.READ_THROUGH;

    if (annotation != null) {
      if (!annotation.ttl().isEmpty()) {
        Duration parsed = Duration.parse(annotation.ttl());
        entityTtl = parsed;
        searchListTtl = parsed;
      }
      if (annotation.entityMaxSize() > 0L) {
        entityMaxSize = annotation.entityMaxSize();
      }
      if (annotation.searchMaxSize() > 0L) {
        searchListMaxSize = annotation.searchMaxSize();
      }
      writeStrategy = annotation.strategy();
    }

    CacheProperties.Region entityRegionOverride = properties.regions().get(entityRegion);
    if (entityRegionOverride != null) {
      if (entityRegionOverride.maxSize() != null) {
        entityMaxSize = entityRegionOverride.maxSize();
      }
      if (entityRegionOverride.ttl() != null) {
        entityTtl = entityRegionOverride.ttl();
      }
      if (entityRegionOverride.strategy() != null) {
        writeStrategy = entityRegionOverride.strategy();
      }
    }
    CacheProperties.Region searchRegionOverride = properties.regions().get(searchListRegion);
    if (searchRegionOverride != null) {
      if (searchRegionOverride.maxSize() != null) {
        searchListMaxSize = searchRegionOverride.maxSize();
      }
      if (searchRegionOverride.ttl() != null) {
        searchListTtl = searchRegionOverride.ttl();
      }
    }

    return new ResolvedCacheStrategy(
        entityRegion,
        searchListRegion,
        entityTtl,
        entityMaxSize,
        searchListTtl,
        searchListMaxSize,
        writeStrategy);
  }
}
