/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0.
 */
package io.rchemist.jpa;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;

/**
 * RCM Framework — JPA starter 진입점.
 *
 * Phase 0 = 빈 골격. 후속 Phase 3~4 에서 multitenant native (@TenantId) / audit /
 * soft-delete / spatial / Searchable APT / universal SearchRequest /
 * Cacheable marker + Spring Cache 통합 추가.
 */
@AutoConfiguration
@ConditionalOnClass(name = "jakarta.persistence.EntityManager")
public class RcmStarterJpaAutoConfiguration {
}
