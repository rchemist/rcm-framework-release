/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0.
 */
package io.rchemist.external;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;

/**
 * RCM Framework — External API starter 진입점.
 *
 * Phase 0 = 빈 골격. 후속 Phase 6 에서 RestClient + Apache HttpClient 5 engine /
 * Resilience4j @ResilientApiCall / 표준 interceptor (traceparent / correlationId /
 * Micrometer) / ProblemDetail 매핑 추가.
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.springframework.web.client.RestClient")
public class RcmStarterExternalAutoConfiguration {
}
