/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.apt;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T0-7 (Decision #14 보강) — {@code @Entity} 부착한 entity 에 대해 컴파일 시점에
 * {@code {Entity}_DbSpec implements DbSpec<{Entity}>} 자동 생성. 0.0.5 의 {@code TableAnalyzeProvider}
 * (runtime reflection) 를 compile-time 으로 옮긴 진실 원천.
 *
 * <p>추출 영역 (5 layer 결합):
 * <ul>
 *   <li>{@code @Table(name)} — table 이름 (default = entity simple name 자연 변환)</li>
 *   <li>{@code @Column(name, length, nullable)} — 컬럼 메타 (default 자연 변환 / -1 / true)</li>
 *   <li>{@code @Id} / {@code @EmbeddedId} — primary key 표시</li>
 *   <li>{@code @Comment} (Hibernate {@code org.hibernate.annotations.Comment}) — DB comment 단일
 *       진실 원천 (DDL {@code COMMENT ON ...} 자동 + 본 APT 의 comment field 자동 채움). 별개
 *       {@code @Description} annotation 영역은 영구 거부 (redundant + DDL 누락 영역).</li>
 *   <li>{@code @Transient} — skip (DB 저장 영역 아님)</li>
 * </ul>
 *
 * <p>SQL type 자연 추론 매트릭스 (Java type → 일반 SQL type):
 * <ul>
 *   <li>{@code Long / long} → {@code BIGINT}</li>
 *   <li>{@code Integer / int} → {@code INTEGER}</li>
 *   <li>{@code String} → {@code VARCHAR}</li>
 *   <li>{@code Boolean / boolean} → {@code BOOLEAN}</li>
 *   <li>{@code java.time.Instant / LocalDateTime / OffsetDateTime} → {@code TIMESTAMP}</li>
 *   <li>{@code java.time.LocalDate} → {@code DATE}</li>
 *   <li>{@code BigDecimal} → {@code DECIMAL}</li>
 *   <li>그 외 — null (unknown)</li>
 * </ul>
 */
@SupportedSourceVersion(SourceVersion.RELEASE_25)
public class DbSpecProcessor extends AbstractProcessor {

  private static final String ENTITY_FQN = "jakarta.persistence.Entity";
  private static final String TABLE_FQN = "jakarta.persistence.Table";
  private static final String COLUMN_FQN = "jakarta.persistence.Column";
  private static final String ID_FQN = "jakarta.persistence.Id";
  private static final String EMBEDDED_ID_FQN = "jakarta.persistence.EmbeddedId";
  private static final String TRANSIENT_FQN = "jakarta.persistence.Transient";
  private static final String COMMENT_FQN = "org.hibernate.annotations.Comment";

  @Override
  public Set<String> getSupportedAnnotationTypes() {
    return Set.of("*");
  }

  @Override
  public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
    if (roundEnv.processingOver()) {
      return false;
    }
    TypeElement entityAnno = processingEnv.getElementUtils().getTypeElement(ENTITY_FQN);
    if (entityAnno == null) {
      // jakarta.persistence not on classpath — entity APT skipped (test-only / non-JPA module).
      return false;
    }
    for (Element element : roundEnv.getRootElements()) {
      if (!(element instanceof TypeElement type)) {
        continue;
      }
      if (type.getKind() != ElementKind.CLASS) {
        continue;
      }
      if (!hasAnnotation(type, ENTITY_FQN)) {
        continue;
      }
      try {
        generateDbSpec(type);
      } catch (IOException ex) {
        processingEnv.getMessager().printMessage(
            Diagnostic.Kind.ERROR,
            "[rcm-apt] failed to generate _DbSpec: " + ex.getMessage(),
            type);
      }
    }
    return false;
  }

  private void generateDbSpec(TypeElement entity) throws IOException {
    String pkg = processingEnv.getElementUtils().getPackageOf(entity).getQualifiedName().toString();
    String simpleName = entity.getSimpleName().toString();
    String generatedName = simpleName + "_DbSpec";
    String fqn = pkg.isEmpty() ? generatedName : pkg + "." + generatedName;

    String tableName = resolveTableName(entity, simpleName);
    String tableComment = resolveTableComment(entity);

    List<FieldSpec> fields = collectFields(entity);

    JavaFileObject file = processingEnv.getFiler().createSourceFile(fqn, entity);
    try (Writer w = file.openWriter()) {
      StringBuilder sb = new StringBuilder(2048);
      if (!pkg.isEmpty()) {
        sb.append("package ").append(pkg).append(";\n\n");
      }
      sb.append("import io.rchemist.core.marker.dbschema.DbFieldSpec;\n");
      sb.append("import io.rchemist.core.marker.dbschema.DbSpec;\n");
      sb.append("import java.util.List;\n\n");
      sb.append("/** Generated by io.rchemist.apt.DbSpecProcessor — do not edit. */\n");
      sb.append("public final class ").append(generatedName)
          .append(" implements DbSpec<").append(simpleName).append("> {\n\n");
      sb.append("  public static final ").append(generatedName).append(" INSTANCE = new ")
          .append(generatedName).append("();\n\n");

      sb.append("  private static final List<DbFieldSpec> FIELDS = List.of(\n");
      for (int i = 0; i < fields.size(); i++) {
        FieldSpec f = fields.get(i);
        sb.append("      new DbFieldSpec(")
            .append(quote(f.fieldName)).append(", ")
            .append(quote(f.columnName)).append(", ")
            .append(quote(f.javaType)).append(", ")
            .append(quote(f.sqlType)).append(", ")
            .append(f.length).append(", ")
            .append(f.nullable).append(", ")
            .append(f.primaryKey).append(", ")
            .append(quote(f.comment)).append(")");
        if (i < fields.size() - 1) {
          sb.append(",");
        }
        sb.append("\n");
      }
      sb.append("  );\n\n");

      sb.append("  public ").append(generatedName).append("() {}\n\n");
      sb.append("  @Override public Class<").append(simpleName).append("> entityClass() { return ")
          .append(simpleName).append(".class; }\n\n");
      sb.append("  @Override public String entityName() { return \"")
          .append(simpleName).append("\"; }\n\n");
      sb.append("  @Override public String tableName() { return ").append(quote(tableName))
          .append("; }\n\n");
      sb.append("  @Override public String tableComment() { return ").append(quote(tableComment))
          .append("; }\n\n");
      sb.append("  @Override public List<DbFieldSpec> fields() { return FIELDS; }\n");
      sb.append("}\n");
      w.write(sb.toString());
    }
  }

  private List<FieldSpec> collectFields(TypeElement entity) {
    LinkedHashSet<String> seen = new LinkedHashSet<>();
    List<FieldSpec> out = new ArrayList<>();
    collectFieldsRecursive(entity, seen, out);
    return out;
  }

  private void collectFieldsRecursive(
      TypeElement type, LinkedHashSet<String> seen, List<FieldSpec> out) {
    // 부모 먼저 (super → child 순서로 declared 순)
    TypeMirror superclass = type.getSuperclass();
    if (superclass.getKind() == TypeKind.DECLARED) {
      Element superElement = processingEnv.getTypeUtils().asElement(superclass);
      if (superElement instanceof TypeElement superType
          && !"java.lang.Object".equals(superType.getQualifiedName().toString())) {
        collectFieldsRecursive(superType, seen, out);
      }
    }
    for (Element e : type.getEnclosedElements()) {
      if (e.getKind() != ElementKind.FIELD) {
        continue;
      }
      if (e.getModifiers().contains(Modifier.STATIC)) {
        continue;
      }
      if (hasAnnotation(e, TRANSIENT_FQN)) {
        continue;
      }
      VariableElement v = (VariableElement) e;
      String name = v.getSimpleName().toString();
      if (!seen.add(name)) {
        continue;
      }
      out.add(describe(v));
    }
  }

  private FieldSpec describe(VariableElement field) {
    String fieldName = field.getSimpleName().toString();
    TypeMirror type = field.asType();
    String javaType = boxedTypeFqn(type);
    String columnName = resolveAnnotationStringValue(field, COLUMN_FQN, "name");
    if (columnName == null || columnName.isBlank()) {
      columnName = camelToSnake(fieldName);
    }
    int length = resolveAnnotationIntValue(field, COLUMN_FQN, "length", -1);
    boolean nullable = resolveAnnotationBooleanValue(field, COLUMN_FQN, "nullable", true);
    boolean primaryKey = hasAnnotation(field, ID_FQN) || hasAnnotation(field, EMBEDDED_ID_FQN);
    String comment = resolveColumnComment(field);
    String sqlType = guessSqlType(javaType);

    return new FieldSpec(fieldName, columnName, javaType, sqlType,
        length, nullable, primaryKey, comment);
  }

  private String resolveTableName(TypeElement entity, String simpleName) {
    String name = resolveAnnotationStringValue(entity, TABLE_FQN, "name");
    if (name == null || name.isBlank()) {
      return camelToSnake(simpleName);
    }
    return name;
  }

  /**
   * Table comment 추출 — JPA 3.2 표준 {@code @Table.comment} 우선, Hibernate {@code @Comment}
   * fallback. Hibernate 7 javadoc 이 후자를 deprecated 표시했으나 transition 영역 무손실 위해 둘 다 read.
   */
  private String resolveTableComment(TypeElement entity) {
    String jpa = resolveAnnotationStringValue(entity, TABLE_FQN, "comment");
    if (jpa != null) {
      return jpa;
    }
    return resolveAnnotationStringValue(entity, COMMENT_FQN, "value");
  }

  /**
   * Column comment 추출 — JPA 3.2 표준 {@code @Column.comment} 우선, Hibernate {@code @Comment}
   * fallback. Hibernate 7 javadoc 이 후자를 deprecated 표시했으나 transition 영역 무손실 위해 둘 다 read.
   */
  private String resolveColumnComment(VariableElement field) {
    String jpa = resolveAnnotationStringValue(field, COLUMN_FQN, "comment");
    if (jpa != null) {
      return jpa;
    }
    return resolveAnnotationStringValue(field, COMMENT_FQN, "value");
  }

  private String resolveAnnotationStringValue(Element element, String annoFqn, String memberName) {
    AnnotationMirror am = findAnnotationMirror(element, annoFqn);
    if (am == null) {
      return null;
    }
    AnnotationValue v = findAnnotationValue(am, memberName);
    if (v == null || v.getValue() == null) {
      return null;
    }
    String s = v.getValue().toString();
    return s.isBlank() ? null : s;
  }

  private int resolveAnnotationIntValue(
      Element element, String annoFqn, String memberName, int defaultVal) {
    AnnotationMirror am = findAnnotationMirror(element, annoFqn);
    if (am == null) {
      return defaultVal;
    }
    AnnotationValue v = findAnnotationValue(am, memberName);
    if (v == null || v.getValue() == null) {
      return defaultVal;
    }
    try {
      return Integer.parseInt(v.getValue().toString());
    } catch (NumberFormatException ex) {
      return defaultVal;
    }
  }

  private boolean resolveAnnotationBooleanValue(
      Element element, String annoFqn, String memberName, boolean defaultVal) {
    AnnotationMirror am = findAnnotationMirror(element, annoFqn);
    if (am == null) {
      return defaultVal;
    }
    AnnotationValue v = findAnnotationValue(am, memberName);
    if (v == null || v.getValue() == null) {
      return defaultVal;
    }
    return Boolean.parseBoolean(v.getValue().toString());
  }

  private AnnotationMirror findAnnotationMirror(Element element, String fqn) {
    for (AnnotationMirror am : element.getAnnotationMirrors()) {
      if (am.getAnnotationType().toString().equals(fqn)) {
        return am;
      }
    }
    return null;
  }

  private AnnotationValue findAnnotationValue(AnnotationMirror am, String memberName) {
    for (var entry : am.getElementValues().entrySet()) {
      ExecutableElement key = entry.getKey();
      if (key.getSimpleName().contentEquals(memberName)) {
        return entry.getValue();
      }
    }
    return null;
  }

  private boolean hasAnnotation(Element element, String fqn) {
    return findAnnotationMirror(element, fqn) != null;
  }

  private String boxedTypeFqn(TypeMirror t) {
    return switch (t.getKind()) {
      case BOOLEAN -> "java.lang.Boolean";
      case BYTE -> "java.lang.Byte";
      case SHORT -> "java.lang.Short";
      case INT -> "java.lang.Integer";
      case LONG -> "java.lang.Long";
      case CHAR -> "java.lang.Character";
      case FLOAT -> "java.lang.Float";
      case DOUBLE -> "java.lang.Double";
      default -> processingEnv.getTypeUtils().erasure(t).toString();
    };
  }

  private String guessSqlType(String javaTypeFqn) {
    return switch (javaTypeFqn) {
      case "java.lang.Long" -> "BIGINT";
      case "java.lang.Integer" -> "INTEGER";
      case "java.lang.Short" -> "SMALLINT";
      case "java.lang.Byte" -> "TINYINT";
      case "java.lang.Boolean" -> "BOOLEAN";
      case "java.lang.Float" -> "REAL";
      case "java.lang.Double" -> "DOUBLE";
      case "java.lang.String" -> "VARCHAR";
      case "java.math.BigDecimal" -> "DECIMAL";
      case "java.math.BigInteger" -> "NUMERIC";
      case "java.time.Instant", "java.time.LocalDateTime",
          "java.time.OffsetDateTime", "java.time.ZonedDateTime" -> "TIMESTAMP";
      case "java.time.LocalDate" -> "DATE";
      case "java.time.LocalTime", "java.time.OffsetTime" -> "TIME";
      case "java.util.UUID" -> "UUID";
      default -> null;
    };
  }

  private static String camelToSnake(String camel) {
    StringBuilder sb = new StringBuilder(camel.length() + 4);
    for (int i = 0; i < camel.length(); i++) {
      char c = camel.charAt(i);
      if (Character.isUpperCase(c)) {
        if (i > 0) {
          sb.append('_');
        }
        sb.append(Character.toLowerCase(c));
      } else {
        sb.append(c);
      }
    }
    return sb.toString();
  }

  private static String quote(String s) {
    if (s == null) {
      return "null";
    }
    String escaped = s.replace("\\", "\\\\").replace("\"", "\\\"")
        .replace("\n", "\\n").replace("\r", "\\r");
    return "\"" + escaped + "\"";
  }

  private record FieldSpec(
      String fieldName,
      String columnName,
      String javaType,
      String sqlType,
      int length,
      boolean nullable,
      boolean primaryKey,
      String comment
  ) {}
}
