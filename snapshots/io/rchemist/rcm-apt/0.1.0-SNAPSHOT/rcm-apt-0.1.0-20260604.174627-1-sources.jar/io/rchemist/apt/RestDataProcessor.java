/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.apt;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.RecordComponentElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — Phase 2 task #6 baseline. {@code @RestData} annotated 클래스 / Records 를 컴파일
 * 시점에 인식하여 {@code <Class>_OpenApiSchema.java} metadata class 를 generate. {@code @RestDataField}
 * 적용 필드도 함께 추출.
 *
 * <p>현재 처리 영역:
 * <ul>
 *   <li>{@code @RestData} 적용 class / record 단위 — name / description 추출</li>
 *   <li>field / record component 단위 {@code @RestDataField} 적용 — description / required / example
 *       추출</li>
 *   <li>{@code <Class>_OpenApiSchema} class 생성 — Phase 후속 customizer 가 활용</li>
 * </ul>
 *
 * <p>비-담당 (Phase 후속): springdoc {@code Schema} 객체 직접 합산.
 */
@SupportedAnnotationTypes("io.rchemist.starter.web.openapi.RestData")
@SupportedSourceVersion(SourceVersion.RELEASE_25)
public class RestDataProcessor extends AbstractProcessor {

  private static final String REST_DATA_FQN = "io.rchemist.starter.web.openapi.RestData";
  private static final String REST_DATA_FIELD_FQN =
      "io.rchemist.starter.web.openapi.RestDataField";

  @Override
  public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
    if (roundEnv.processingOver()) {
      return false;
    }
    TypeElement dataType = processingEnv.getElementUtils().getTypeElement(REST_DATA_FQN);
    if (dataType == null) {
      return false;
    }
    for (Element element : roundEnv.getElementsAnnotatedWith(dataType)) {
      if (!(element instanceof TypeElement type)) {
        continue;
      }
      if (type.getKind() != ElementKind.CLASS && type.getKind() != ElementKind.RECORD) {
        continue;
      }
      try {
        generateSchemaMetadata(type);
      } catch (IOException ex) {
        processingEnv.getMessager().printMessage(
            Diagnostic.Kind.ERROR,
            "[rcm-apt] failed to generate OpenApi schema metadata: " + ex.getMessage(),
            type);
      }
    }
    return false;
  }

  private void generateSchemaMetadata(TypeElement type) throws IOException {
    String pkg = processingEnv.getElementUtils().getPackageOf(type).getQualifiedName().toString();
    String simpleName = type.getSimpleName().toString();
    String generatedName = simpleName + "_OpenApiSchema";
    String fqn = pkg.isEmpty() ? generatedName : pkg + "." + generatedName;

    String[] dataMeta = extractRestData(type);
    String dataName = dataMeta[0].isEmpty() ? simpleName : dataMeta[0];
    String dataDesc = dataMeta[1];

    List<FieldMetadata> fields = new ArrayList<>();
    if (type.getKind() == ElementKind.RECORD) {
      // Records 의 경우 RecordComponent 만 순회 (synthetic field 와 중복 회피).
      for (RecordComponentElement comp : type.getRecordComponents()) {
        FieldMetadata fm = extractRestDataField(comp, comp.getSimpleName().toString());
        if (fm != null) {
          fields.add(fm);
        }
      }
    } else {
      for (Element enclosed : type.getEnclosedElements()) {
        if (enclosed.getKind() != ElementKind.FIELD) {
          continue;
        }
        VariableElement field = (VariableElement) enclosed;
        FieldMetadata fm = extractRestDataField(field, field.getSimpleName().toString());
        if (fm != null) {
          fields.add(fm);
        }
      }
    }

    JavaFileObject file = processingEnv.getFiler().createSourceFile(fqn, type);
    try (Writer w = file.openWriter()) {
      StringBuilder sb = new StringBuilder(1024);
      if (!pkg.isEmpty()) {
        sb.append("package ").append(pkg).append(";\n\n");
      }
      sb.append("import java.util.List;\n\n");
      sb.append("/** Generated by io.rchemist.apt.RestDataProcessor — do not edit. */\n");
      sb.append("public final class ").append(generatedName).append(" {\n\n");
      sb.append("    public record FieldMetadata(\n");
      sb.append("        String name,\n");
      sb.append("        String description,\n");
      sb.append("        boolean required,\n");
      sb.append("        String example\n");
      sb.append("    ) {}\n\n");
      sb.append("    public static final String SCHEMA_NAME = ").append(quote(dataName)).append(";\n");
      sb.append("    public static final String SCHEMA_DESCRIPTION = ").append(quote(dataDesc))
          .append(";\n\n");
      sb.append("    public static final List<FieldMetadata> FIELDS = List.of(");
      if (fields.isEmpty()) {
        sb.append(");\n");
      } else {
        sb.append("\n");
        for (int i = 0; i < fields.size(); i++) {
          FieldMetadata f = fields.get(i);
          sb.append("        new FieldMetadata(")
              .append(quote(f.name())).append(", ")
              .append(quote(f.description())).append(", ")
              .append(f.required()).append(", ")
              .append(quote(f.example())).append(")");
          if (i < fields.size() - 1) {
            sb.append(",");
          }
          sb.append("\n");
        }
        sb.append("    );\n");
      }
      sb.append("\n    private ").append(generatedName).append("() {}\n");
      sb.append("}\n");
      w.write(sb.toString());
    }
  }

  private String[] extractRestData(TypeElement type) {
    String name = "";
    String description = "";
    for (AnnotationMirror mirror : type.getAnnotationMirrors()) {
      if (!REST_DATA_FQN.equals(mirror.getAnnotationType().toString())) {
        continue;
      }
      Map<? extends ExecutableElement, ? extends AnnotationValue> values =
          processingEnv.getElementUtils().getElementValuesWithDefaults(mirror);
      for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> e : values.entrySet()) {
        String key = e.getKey().getSimpleName().toString();
        Object value = e.getValue().getValue();
        switch (key) {
          case "name" -> name = value.toString();
          case "description" -> description = value.toString();
          default -> {
            // ignore.
          }
        }
      }
    }
    return new String[]{name, description};
  }

  private FieldMetadata extractRestDataField(Element element, String name) {
    for (AnnotationMirror mirror : element.getAnnotationMirrors()) {
      if (!REST_DATA_FIELD_FQN.equals(mirror.getAnnotationType().toString())) {
        continue;
      }
      String description = "";
      boolean required = false;
      String example = "";
      Map<? extends ExecutableElement, ? extends AnnotationValue> values =
          processingEnv.getElementUtils().getElementValuesWithDefaults(mirror);
      for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> e : values.entrySet()) {
        String key = e.getKey().getSimpleName().toString();
        Object value = e.getValue().getValue();
        switch (key) {
          case "description" -> description = value.toString();
          case "required" -> required = Boolean.parseBoolean(value.toString());
          case "example" -> example = value.toString();
          default -> {
            // ignore.
          }
        }
      }
      return new FieldMetadata(name, description, required, example);
    }
    return null;
  }

  private static String quote(String s) {
    return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
  }

  /** 필드 단위 OpenAPI Schema property metadata Records. */
  public record FieldMetadata(String name, String description, boolean required, String example) {}
}
