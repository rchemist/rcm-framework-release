/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.apt;

import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 1 baseline (청사진 §3.4 + §5.5.4): {@code Searchable} marker 를 implement 한 entity 에 대해
 * {@code Entity_Search} metadata class 를 컴파일 시점에 생성. Phase 3 에서 type-safe FieldDescriptor /
 * 연관 / JSON / classify() 로 확장 (Entity_Metadata 통합).
 */
@SupportedSourceVersion(SourceVersion.RELEASE_25)
public class SearchableProcessor extends AbstractProcessor {

    private static final String SEARCHABLE_FQN = "io.rchemist.core.marker.Searchable";

    @Override
    public Set<String> getSupportedAnnotationTypes() {
        // marker interface 는 어노테이션이 아니라 매 round 의 root element 를 직접 검사한다.
        return Set.of("*");
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        if (roundEnv.processingOver()) {
            return false;
        }
        TypeElement searchable = processingEnv.getElementUtils().getTypeElement(SEARCHABLE_FQN);
        if (searchable == null) {
            return false;
        }
        TypeMirror searchableMirror = searchable.asType();
        for (Element element : roundEnv.getRootElements()) {
            if (!(element instanceof TypeElement type)) {
                continue;
            }
            if (type.getKind() != ElementKind.CLASS && type.getKind() != ElementKind.RECORD) {
                continue;
            }
            if (!implementsInterface(type, searchableMirror)) {
                continue;
            }
            try {
                generateMetadata(type);
            } catch (IOException ex) {
                processingEnv.getMessager().printMessage(
                    Diagnostic.Kind.ERROR,
                    "[rcm-apt] failed to generate Search metadata: " + ex.getMessage(),
                    type);
            }
        }
        return false;
    }

    private boolean implementsInterface(TypeElement type, TypeMirror iface) {
        Types types = processingEnv.getTypeUtils();
        for (TypeMirror impl : type.getInterfaces()) {
            if (types.isSameType(types.erasure(impl), types.erasure(iface))) {
                return true;
            }
            if (impl.getKind() == TypeKind.DECLARED) {
                Element implElement = ((DeclaredType) impl).asElement();
                if (implElement instanceof TypeElement implType
                    && implementsInterface(implType, iface)) {
                    return true;
                }
            }
        }
        TypeMirror superclass = type.getSuperclass();
        if (superclass.getKind() == TypeKind.DECLARED) {
            Element superElement = ((DeclaredType) superclass).asElement();
            if (superElement instanceof TypeElement superType) {
                return implementsInterface(superType, iface);
            }
        }
        return false;
    }

    private void generateMetadata(TypeElement entity) throws IOException {
        String pkg = processingEnv.getElementUtils().getPackageOf(entity).getQualifiedName().toString();
        String simpleName = entity.getSimpleName().toString();
        String generatedName = simpleName + "_Search";
        String fqn = pkg.isEmpty() ? generatedName : pkg + "." + generatedName;

        List<VariableElement> fields = entity.getEnclosedElements().stream()
            .filter(e -> e.getKind() == ElementKind.FIELD)
            .filter(e -> !e.getModifiers().contains(Modifier.STATIC))
            .map(e -> (VariableElement) e)
            .toList();

        JavaFileObject file = processingEnv.getFiler().createSourceFile(fqn, entity);
        try (Writer w = file.openWriter()) {
            StringBuilder sb = new StringBuilder(512);
            if (!pkg.isEmpty()) {
                sb.append("package ").append(pkg).append(";\n\n");
            }
            sb.append("import java.util.List;\n");
            sb.append("import java.util.Map;\n\n");
            sb.append("/** Generated by io.rchemist.apt.SearchableProcessor — do not edit. */\n");
            sb.append("public final class ").append(generatedName).append(" {\n\n");
            sb.append("    public static final String ENTITY_NAME = \"").append(simpleName).append("\";\n\n");

            sb.append("    public static final List<String> FIELDS = List.of(");
            for (int i = 0; i < fields.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append('"').append(fields.get(i).getSimpleName()).append('"');
            }
            sb.append(");\n\n");

            sb.append("    public static final Map<String, Class<?>> TYPES = ");
            if (fields.isEmpty()) {
                sb.append("Map.of();");
            } else {
                sb.append("Map.ofEntries(\n");
                for (int i = 0; i < fields.size(); i++) {
                    VariableElement f = fields.get(i);
                    sb.append("        Map.entry(\"")
                        .append(f.getSimpleName())
                        .append("\", ")
                        .append(typeOf(f))
                        .append(".class)");
                    if (i < fields.size() - 1) sb.append(",");
                    sb.append("\n");
                }
                sb.append("    );");
            }
            sb.append("\n\n");

            sb.append("    private ").append(generatedName).append("() {}\n");
            sb.append("}\n");
            w.write(sb.toString());
        }
    }

    private String typeOf(VariableElement field) {
        TypeMirror t = field.asType();
        return switch (t.getKind()) {
            case BOOLEAN -> "Boolean";
            case BYTE -> "Byte";
            case SHORT -> "Short";
            case INT -> "Integer";
            case LONG -> "Long";
            case CHAR -> "Character";
            case FLOAT -> "Float";
            case DOUBLE -> "Double";
            case DECLARED, ARRAY -> processingEnv.getTypeUtils().erasure(t).toString();
            default -> "Object";
        };
    }
}
