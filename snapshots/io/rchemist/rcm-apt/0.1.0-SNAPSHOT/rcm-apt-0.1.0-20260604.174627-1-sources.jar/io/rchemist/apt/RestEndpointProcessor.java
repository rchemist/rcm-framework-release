/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.apt;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #15 적용 — Phase 2 task #6 baseline. {@code @RestEndpoint} annotated 메소드를 컴파일 시점에
 * 인식하여 {@code <Class>_OpenApi.java} metadata class 를 generate. Phase 후속 customizer 통합 (자동
 * Schema / Parameter example 합산) 의 baseline.
 *
 * <p>현재 처리 영역:
 * <ul>
 *   <li>controller class 단위 메소드 순회 — {@code @RestEndpoint} 발견 시 메소드명 / summary /
 *       description / tag / deprecated / operationId 추출</li>
 *   <li>{@code <Class>_OpenApi} class 생성 — {@code public static final List<EndpointMetadata>
 *       ENDPOINTS} field 적용. Phase 후속 customizer 가 reflective lookup 또는 ServiceLoader 패턴으로
 *       활용 가능 (compile-time meta + runtime customizer 정합)</li>
 * </ul>
 *
 * <p>비-담당 (Phase 후속): 깊은 OpenAPI customizer 통합. 현재 baseline = metadata 생성 + 런타임의
 * {@code RestEndpointOperationCustomizer} 가 직접 Operation 갱신 (compile-time meta 미사용).
 */
@SupportedAnnotationTypes("io.rchemist.starter.web.openapi.RestEndpoint")
@SupportedSourceVersion(SourceVersion.RELEASE_25)
public class RestEndpointProcessor extends AbstractProcessor {

  private static final String REST_ENDPOINT_FQN = "io.rchemist.starter.web.openapi.RestEndpoint";

  @Override
  public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
    if (roundEnv.processingOver()) {
      return false;
    }
    TypeElement endpointType = processingEnv.getElementUtils().getTypeElement(REST_ENDPOINT_FQN);
    if (endpointType == null) {
      return false;
    }
    Map<TypeElement, List<EndpointMetadata>> byOwner = new LinkedHashMap<>();
    for (Element element : roundEnv.getElementsAnnotatedWith(endpointType)) {
      if (element.getKind() != ElementKind.METHOD) {
        continue;
      }
      ExecutableElement method = (ExecutableElement) element;
      Element owner = method.getEnclosingElement();
      if (!(owner instanceof TypeElement ownerType)) {
        continue;
      }
      EndpointMetadata meta = extractMetadata(method);
      byOwner.computeIfAbsent(ownerType, k -> new ArrayList<>()).add(meta);
    }
    for (Map.Entry<TypeElement, List<EndpointMetadata>> entry : byOwner.entrySet()) {
      try {
        generateOpenApiMetadata(entry.getKey(), entry.getValue());
      } catch (IOException ex) {
        processingEnv.getMessager().printMessage(
            Diagnostic.Kind.ERROR,
            "[rcm-apt] failed to generate OpenApi metadata: " + ex.getMessage(),
            entry.getKey());
      }
    }
    return false;
  }

  private EndpointMetadata extractMetadata(ExecutableElement method) {
    String methodName = method.getSimpleName().toString();
    String summary = "";
    String description = "";
    String tag = "";
    boolean deprecated = false;
    String operationId = "";
    for (AnnotationMirror mirror : method.getAnnotationMirrors()) {
      if (!REST_ENDPOINT_FQN.equals(mirror.getAnnotationType().toString())) {
        continue;
      }
      Map<? extends ExecutableElement, ? extends AnnotationValue> values =
          processingEnv.getElementUtils().getElementValuesWithDefaults(mirror);
      for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> e : values.entrySet()) {
        String key = e.getKey().getSimpleName().toString();
        Object value = e.getValue().getValue();
        switch (key) {
          case "summary" -> summary = value.toString();
          case "description" -> description = value.toString();
          case "tag" -> tag = value.toString();
          case "deprecated" -> deprecated = Boolean.parseBoolean(value.toString());
          case "operationId" -> operationId = value.toString();
          default -> {
            // ignore — 적용 영역 외 attribute 는 skip.
          }
        }
      }
    }
    return new EndpointMetadata(methodName, summary, description, tag, deprecated, operationId);
  }

  private void generateOpenApiMetadata(TypeElement owner, List<EndpointMetadata> endpoints)
      throws IOException {
    String pkg = processingEnv.getElementUtils().getPackageOf(owner).getQualifiedName().toString();
    String simpleName = owner.getSimpleName().toString();
    String generatedName = simpleName + "_OpenApi";
    String fqn = pkg.isEmpty() ? generatedName : pkg + "." + generatedName;

    JavaFileObject file = processingEnv.getFiler().createSourceFile(fqn, owner);
    try (Writer w = file.openWriter()) {
      StringBuilder sb = new StringBuilder(1024);
      if (!pkg.isEmpty()) {
        sb.append("package ").append(pkg).append(";\n\n");
      }
      sb.append("import java.util.List;\n\n");
      sb.append("/** Generated by io.rchemist.apt.RestEndpointProcessor — do not edit. */\n");
      sb.append("public final class ").append(generatedName).append(" {\n\n");
      sb.append("    public record EndpointMetadata(\n");
      sb.append("        String method,\n");
      sb.append("        String summary,\n");
      sb.append("        String description,\n");
      sb.append("        String tag,\n");
      sb.append("        boolean deprecated,\n");
      sb.append("        String operationId\n");
      sb.append("    ) {}\n\n");
      sb.append("    public static final String CONTROLLER = \"").append(simpleName).append("\";\n\n");
      sb.append("    public static final List<EndpointMetadata> ENDPOINTS = List.of(\n");
      for (int i = 0; i < endpoints.size(); i++) {
        EndpointMetadata m = endpoints.get(i);
        sb.append("        new EndpointMetadata(")
            .append(quote(m.method())).append(", ")
            .append(quote(m.summary())).append(", ")
            .append(quote(m.description())).append(", ")
            .append(quote(m.tag())).append(", ")
            .append(m.deprecated()).append(", ")
            .append(quote(m.operationId())).append(")");
        if (i < endpoints.size() - 1) {
          sb.append(",");
        }
        sb.append("\n");
      }
      sb.append("    );\n\n");
      sb.append("    private ").append(generatedName).append("() {}\n");
      sb.append("}\n");
      w.write(sb.toString());
    }
  }

  private static String quote(String s) {
    return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
  }

  /** 메소드 단위 OpenAPI metadata Records — Phase 후속 customizer baseline. */
  public record EndpointMetadata(
      String method,
      String summary,
      String description,
      String tag,
      boolean deprecated,
      String operationId) {}
}
