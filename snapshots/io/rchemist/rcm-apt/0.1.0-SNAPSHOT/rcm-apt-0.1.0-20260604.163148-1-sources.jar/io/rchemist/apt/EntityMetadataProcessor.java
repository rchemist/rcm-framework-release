/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.apt;

import io.rchemist.core.search.FilterClassification;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;
import javax.tools.FileObject;
import javax.tools.JavaFileObject;
import javax.tools.StandardLocation;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 3 task #6b — {@code Searchable} marker 를 implement 한 entity 에 대해 컴파일 시점에
 * {@code Entity_Metadata} 클래스를 생성하는 APT (청사진 §5.5.4 + §5.5.5). 0.0.5
 * {@code RegisterEntityBeanDTO} (Hibernate persistence SPI + runtime ClassTransformer 합성) 의 모든 책임을
 * compile-time 으로 옮긴 진실 원천.
 *
 * <p>JPA annotation 자동 분류:
 * <ul>
 *   <li>{@code @OneToMany} / {@code @ManyToMany} → {@link io.rchemist.core.search.FilterClassification#ONE_TO_MANY}</li>
 *   <li>{@code @ManyToOne} / {@code @OneToOne} → {@link io.rchemist.core.search.FilterClassification#MANY_TO_ONE}</li>
 *   <li>{@code @Embedded} / {@code @EmbeddedId} → {@link io.rchemist.core.search.FilterClassification#EMBEDDED}</li>
 *   <li>{@code Map} 타입 + ({@code @JdbcTypeCode} | {@code @Convert} | 무 annotation) → {@link io.rchemist.core.search.FilterClassification#JSON_ATTRIBUTE}</li>
 *   <li>그 외 default → {@link io.rchemist.core.search.FilterClassification#COLUMN}</li>
 * </ul>
 *
 * <p>Marker 자동 추가 — entity 가 marker 를 implement 하면 해당 marker 의 표준 필드를 자동 적용 (entity 가 명시
 * 적용 안 해도):
 * <ul>
 *   <li>{@code Auditable} → createdAt / updatedAt / createdBy / updatedBy ({@code autoMarker=true})</li>
 *   <li>{@code SoftDelete} → deleted ({@code autoMarker=true})</li>
 *   <li>{@code TenantAlias} → tenantId ({@code autoMarker=true})</li>
 * </ul>
 *
 * <p>ServiceLoader 자동 발견 — 매 entity 의 metadata FQN 을 {@code
 * META-INF/services/io.rchemist.core.search.EntityMetadata} 에 append. starter-jpa autoconfig 가
 * {@code ServiceLoader.load(EntityMetadata.class)} 로 자동 register.
 */
@SupportedSourceVersion(SourceVersion.RELEASE_25)
public class EntityMetadataProcessor extends AbstractProcessor {

  private static final String SEARCHABLE_FQN = "io.rchemist.core.marker.Searchable";
  private static final String AUDITABLE_FQN = "io.rchemist.core.marker.Auditable";
  private static final String SOFT_DELETE_FQN = "io.rchemist.core.marker.SoftDelete";
  private static final String TENANT_ALIAS_FQN = "io.rchemist.core.marker.TenantAlias";

  private static final String SERVICE_FILE = "META-INF/services/io.rchemist.core.search.EntityMetadata";

  private final Set<String> registeredFqns = new LinkedHashSet<>();

  @Override
  public Set<String> getSupportedAnnotationTypes() {
    return Set.of("*");
  }

  @Override
  public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
    if (roundEnv.processingOver()) {
      writeServiceFile();
      return false;
    }
    TypeElement searchable = processingEnv.getElementUtils().getTypeElement(SEARCHABLE_FQN);
    if (searchable == null) {
      return false;
    }
    TypeMirror searchableMirror = searchable.asType();
    for (Element element : roundEnv.getRootElements()) {
      if (!(element instanceof TypeElement type)) {
        continue;
      }
      if (type.getKind() != ElementKind.CLASS && type.getKind() != ElementKind.RECORD) {
        continue;
      }
      if (!implementsInterface(type, searchableMirror)) {
        continue;
      }
      try {
        String fqn = generateMetadata(type);
        registeredFqns.add(fqn);
      } catch (IOException ex) {
        processingEnv.getMessager().printMessage(
            Diagnostic.Kind.ERROR,
            "[rcm-apt] failed to generate Entity_Metadata: " + ex.getMessage(),
            type);
      }
    }
    return false;
  }

  private boolean implementsInterface(TypeElement type, TypeMirror iface) {
    Types types = processingEnv.getTypeUtils();
    for (TypeMirror impl : type.getInterfaces()) {
      if (types.isSameType(types.erasure(impl), types.erasure(iface))) {
        return true;
      }
      if (impl.getKind() == TypeKind.DECLARED) {
        Element implElement = ((DeclaredType) impl).asElement();
        if (implElement instanceof TypeElement implType
            && implementsInterface(implType, iface)) {
          return true;
        }
      }
    }
    TypeMirror superclass = type.getSuperclass();
    if (superclass.getKind() == TypeKind.DECLARED) {
      Element superElement = ((DeclaredType) superclass).asElement();
      if (superElement instanceof TypeElement superType) {
        return implementsInterface(superType, iface);
      }
    }
    return false;
  }

  private boolean implementsAnyMarker(TypeElement type, String markerFqn) {
    TypeElement marker = processingEnv.getElementUtils().getTypeElement(markerFqn);
    if (marker == null) {
      return false;
    }
    return implementsInterface(type, marker.asType());
  }

  private String generateMetadata(TypeElement entity) throws IOException {
    String pkg = processingEnv.getElementUtils().getPackageOf(entity).getQualifiedName().toString();
    String simpleName = entity.getSimpleName().toString();
    String generatedName = simpleName + "_Metadata";
    String fqn = pkg.isEmpty() ? generatedName : pkg + "." + generatedName;

    List<FieldInfo> fields = collectFields(entity);

    JavaFileObject file = processingEnv.getFiler().createSourceFile(fqn, entity);
    try (Writer w = file.openWriter()) {
      StringBuilder sb = new StringBuilder(2048);
      if (!pkg.isEmpty()) {
        sb.append("package ").append(pkg).append(";\n\n");
      }
      sb.append("import io.rchemist.core.search.EntityMetadata;\n");
      sb.append("import io.rchemist.core.search.EntityMetadataRegistry;\n");
      sb.append("import io.rchemist.core.search.FieldDescriptor;\n");
      sb.append("import io.rchemist.core.search.FilterClassification;\n");
      sb.append("import java.util.List;\n");
      sb.append("import java.util.Optional;\n\n");

      sb.append("/** Generated by io.rchemist.apt.EntityMetadataProcessor — do not edit. */\n");
      sb.append("public final class ").append(generatedName)
          .append(" implements EntityMetadata<").append(simpleName).append("> {\n\n");

      sb.append("  public static final ").append(generatedName).append(" INSTANCE = new ")
          .append(generatedName).append("();\n\n");

      for (FieldInfo f : fields) {
        sb.append("  public static final FieldDescriptor<").append(simpleName).append(", ")
            .append(f.boxedType).append("> ")
            .append(toConstantName(f.name)).append(" = new FieldDescriptor<>(\n")
            .append("      \"").append(f.name).append("\", ")
            .append(f.boxedType).append(".class, ").append(simpleName).append(".class,\n")
            .append("      FilterClassification.").append(f.classification.name()).append(", ")
            .append(f.searchable).append(", ").append(f.sortable).append(", ")
            .append(f.indexed).append(", ").append(f.autoMarker).append(");\n\n");
      }

      sb.append("  private static final List<FieldDescriptor<").append(simpleName)
          .append(", ?>> FIELDS = List.of(");
      for (int i = 0; i < fields.size(); i++) {
        if (i > 0) {
          sb.append(", ");
        }
        sb.append(toConstantName(fields.get(i).name));
      }
      sb.append(");\n\n");

      sb.append("  static { EntityMetadataRegistry.register(").append(simpleName)
          .append(".class, INSTANCE); }\n\n");

      sb.append("  public ").append(generatedName).append("() {}\n\n");

      sb.append("  @Override public Class<").append(simpleName).append("> entityClass() { return ")
          .append(simpleName).append(".class; }\n\n");
      sb.append("  @Override public String entityName() { return \"")
          .append(simpleName).append("\"; }\n\n");
      sb.append("  @Override public List<FieldDescriptor<").append(simpleName)
          .append(", ?>> fields() { return FIELDS; }\n\n");
      sb.append("  @Override public Optional<FieldDescriptor<").append(simpleName)
          .append(", ?>> findField(String name) {\n")
          .append("    for (FieldDescriptor<").append(simpleName)
          .append(", ?> f : FIELDS) { if (f.name().equals(name)) return Optional.of(f); }\n")
          .append("    return Optional.empty();\n  }\n\n");

      sb.append("}\n");
      w.write(sb.toString());
    }
    return fqn;
  }

  private List<FieldInfo> collectFields(TypeElement entity) {
    LinkedHashSet<String> seen = new LinkedHashSet<>();
    List<FieldInfo> out = new ArrayList<>();

    for (Element e : entity.getEnclosedElements()) {
      if (e.getKind() != ElementKind.FIELD) {
        continue;
      }
      if (e.getModifiers().contains(Modifier.STATIC)) {
        continue;
      }
      VariableElement v = (VariableElement) e;
      String name = v.getSimpleName().toString();
      if (!seen.add(name)) {
        continue;
      }
      FieldInfo info = describe(v);
      out.add(info);
    }

    addMarkerField(entity, AUDITABLE_FQN, "createdAt", "java.time.Instant",
        FilterClassification.COLUMN, true, true, false, true, seen, out);
    addMarkerField(entity, AUDITABLE_FQN, "updatedAt", "java.time.Instant",
        FilterClassification.COLUMN, true, true, false, true, seen, out);
    addMarkerField(entity, AUDITABLE_FQN, "createdBy", "String",
        FilterClassification.COLUMN, true, true, false, true, seen, out);
    addMarkerField(entity, AUDITABLE_FQN, "updatedBy", "String",
        FilterClassification.COLUMN, true, true, false, true, seen, out);
    addMarkerField(entity, SOFT_DELETE_FQN, "deleted", "Boolean",
        FilterClassification.COLUMN, true, false, false, true, seen, out);
    addMarkerField(entity, TENANT_ALIAS_FQN, "tenantId", "String",
        FilterClassification.COLUMN, true, true, false, true, seen, out);

    return out;
  }

  private void addMarkerField(
      TypeElement entity, String markerFqn, String name, String boxedType,
      FilterClassification classification, boolean searchable, boolean sortable,
      boolean indexed, boolean autoMarker,
      LinkedHashSet<String> seen, List<FieldInfo> out) {
    if (!implementsAnyMarker(entity, markerFqn)) {
      return;
    }
    if (!seen.add(name)) {
      return;
    }
    out.add(new FieldInfo(name, boxedType, classification, searchable, sortable, indexed, autoMarker));
  }

  private FieldInfo describe(VariableElement field) {
    String name = field.getSimpleName().toString();
    TypeMirror type = field.asType();
    boolean hasOneToMany = hasAnnotation(field, "jakarta.persistence.OneToMany")
        || hasAnnotation(field, "jakarta.persistence.ManyToMany");
    boolean hasManyToOne = hasAnnotation(field, "jakarta.persistence.ManyToOne")
        || hasAnnotation(field, "jakarta.persistence.OneToOne");
    boolean hasEmbedded = hasAnnotation(field, "jakarta.persistence.Embedded")
        || hasAnnotation(field, "jakarta.persistence.EmbeddedId");
    boolean isMapType = isAssignableToMap(type);

    FilterClassification classification;
    boolean sortable = true;
    if (hasOneToMany) {
      classification = FilterClassification.ONE_TO_MANY;
      sortable = false;
    } else if (hasManyToOne) {
      classification = FilterClassification.MANY_TO_ONE;
    } else if (hasEmbedded) {
      classification = FilterClassification.EMBEDDED;
      sortable = false;
    } else if (isMapType) {
      classification = FilterClassification.JSON_ATTRIBUTE;
      sortable = false;
    } else if (isCollectionType(type)) {
      classification = FilterClassification.ONE_TO_MANY;
      sortable = false;
    } else {
      classification = FilterClassification.COLUMN;
    }

    return new FieldInfo(name, boxedTypeName(type), classification,
        true, sortable, false, false);
  }

  private boolean hasAnnotation(VariableElement field, String fqn) {
    for (AnnotationMirror am : field.getAnnotationMirrors()) {
      if (am.getAnnotationType().toString().equals(fqn)) {
        return true;
      }
    }
    return false;
  }

  private boolean isAssignableToMap(TypeMirror t) {
    if (t.getKind() != TypeKind.DECLARED) {
      return false;
    }
    Types types = processingEnv.getTypeUtils();
    TypeElement mapElem = processingEnv.getElementUtils().getTypeElement("java.util.Map");
    if (mapElem == null) {
      return false;
    }
    return types.isAssignable(types.erasure(t), types.erasure(mapElem.asType()));
  }

  private boolean isCollectionType(TypeMirror t) {
    if (t.getKind() != TypeKind.DECLARED) {
      return false;
    }
    Types types = processingEnv.getTypeUtils();
    TypeElement coll = processingEnv.getElementUtils().getTypeElement("java.util.Collection");
    if (coll == null) {
      return false;
    }
    return types.isAssignable(types.erasure(t), types.erasure(coll.asType()));
  }

  private String boxedTypeName(TypeMirror t) {
    return switch (t.getKind()) {
      case BOOLEAN -> "Boolean";
      case BYTE -> "Byte";
      case SHORT -> "Short";
      case INT -> "Integer";
      case LONG -> "Long";
      case CHAR -> "Character";
      case FLOAT -> "Float";
      case DOUBLE -> "Double";
      case DECLARED -> processingEnv.getTypeUtils().erasure(t).toString();
      case ARRAY -> "Object";
      default -> "Object";
    };
  }

  private static String toConstantName(String camel) {
    StringBuilder sb = new StringBuilder(camel.length() + 4);
    for (int i = 0; i < camel.length(); i++) {
      char c = camel.charAt(i);
      if (i > 0 && Character.isUpperCase(c)) {
        sb.append('_');
      }
      sb.append(Character.toUpperCase(c));
    }
    return sb.toString();
  }

  private void writeServiceFile() {
    if (registeredFqns.isEmpty()) {
      return;
    }
    Filer filer = processingEnv.getFiler();
    LinkedHashSet<String> all = new LinkedHashSet<>();
    try {
      FileObject existing = filer.getResource(StandardLocation.CLASS_OUTPUT, "", SERVICE_FILE);
      try (InputStream in = existing.openInputStream();
           BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
        String line;
        while ((line = r.readLine()) != null) {
          String trimmed = line.trim();
          if (!trimmed.isEmpty()) {
            all.add(trimmed);
          }
        }
      } catch (IOException ignore) {
        // resource 가 아직 없는 경우 — empty 로 시작.
      }
    } catch (IOException ignore) {
      // initial round 의 file 미존재 = 정상.
    }
    all.addAll(registeredFqns);
    try {
      FileObject out = filer.createResource(StandardLocation.CLASS_OUTPUT, "", SERVICE_FILE);
      try (Writer w = out.openWriter()) {
        for (String fqn : all) {
          w.write(fqn);
          w.write('\n');
        }
      }
    } catch (IOException ex) {
      processingEnv.getMessager().printMessage(
          Diagnostic.Kind.WARNING,
          "[rcm-apt] failed to write " + SERVICE_FILE + ": " + ex.getMessage());
    }
  }

  private record FieldInfo(
      String name,
      String boxedType,
      FilterClassification classification,
      boolean searchable,
      boolean sortable,
      boolean indexed,
      boolean autoMarker
  ) {}
}
