-- Phase 11 task #3 — Member + 인증 schema (Decision #26).
-- 4 marker (Searchable + Auditable + SoftDelete + TenantAlias) + Decision #10 한국 region.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = MEMBER_ID + boolean = IS_*.

CREATE TABLE T_MEMBER
(
    MEMBER_ID                     BIGSERIAL PRIMARY KEY,
    LOGIN_ID                      VARCHAR(64)  NOT NULL UNIQUE,
    PASSWORD_HASH                 VARCHAR(255) NOT NULL,
    NAME                          VARCHAR(64),
    EMAIL                         VARCHAR(128),
    PHONE                         VARCHAR(32),
    RESIDENT_REGISTRATION_NUMBER  VARCHAR(64),
    IS_MFA_ENABLED                BOOLEAN      NOT NULL DEFAULT FALSE,
    TOTP_SECRET                   VARCHAR(128),
    TENANT_ID                     VARCHAR(64)  NOT NULL,
    IS_DELETED                    BOOLEAN      NOT NULL DEFAULT FALSE,
    CREATED_AT                    TIMESTAMP WITH TIME ZONE,
    UPDATED_AT                    TIMESTAMP WITH TIME ZONE,
    CREATED_BY                    VARCHAR(128),
    UPDATED_BY                    VARCHAR(128)
);

CREATE INDEX IDX_MEMBER_TENANT_LOGIN ON T_MEMBER (TENANT_ID, LOGIN_ID);
CREATE INDEX IDX_MEMBER_EMAIL ON T_MEMBER (EMAIL);
