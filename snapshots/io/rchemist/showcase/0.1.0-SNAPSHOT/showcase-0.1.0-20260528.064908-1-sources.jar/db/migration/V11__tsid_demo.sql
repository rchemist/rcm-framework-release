-- issue #28 — TSID Long PK + Jackson JSON String 자동 직렬화 시연용 단순 entity.
-- TSID = application-side ID 생성 (@TsidGenerator + hypersistence-tsid 2.1.4). DB 측은 BIGSERIAL/SEQUENCE 불요 —
-- 그냥 BIGINT NOT NULL PRIMARY KEY. application 이 INSERT 시점에 64-bit TSID Long 을 직접 제공.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = TSID_DEMO_ID.
CREATE TABLE T_TSID_DEMO (
  TSID_DEMO_ID  BIGINT       NOT NULL PRIMARY KEY,
  LABEL         VARCHAR(200) NOT NULL
);

COMMENT ON TABLE  T_TSID_DEMO              IS 'TSID Long PK + JSON String 자동 직렬화 시연 (issue #28)';
COMMENT ON COLUMN T_TSID_DEMO.TSID_DEMO_ID IS 'TSID Long PK — application-side 생성 (@TsidGenerator)';
COMMENT ON COLUMN T_TSID_DEMO.LABEL        IS '표시용 label';
