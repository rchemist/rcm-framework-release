-- Phase 0.1.0 GA Gate T8 — DB-backed MessageSource schema (Decision #32, rcm-starter-jpa-i18n).
-- T_MESSAGE = tenant 별 i18n 메시지 (admin GUI 편집 가능). DatabaseMessageSource 가 Caffeine cache
-- 사이로 lookup. (TENANT_ID, LOCALE, CODE) unique.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = MESSAGE_ID.

CREATE TABLE T_MESSAGE
(
    MESSAGE_ID  BIGSERIAL PRIMARY KEY,
    TENANT_ID   VARCHAR(64)   NOT NULL,
    LOCALE      VARCHAR(32)   NOT NULL,
    CODE        VARCHAR(200)  NOT NULL,
    MESSAGE     VARCHAR(4000) NOT NULL,
    CREATED_AT  TIMESTAMP WITH TIME ZONE NOT NULL,
    UPDATED_AT  TIMESTAMP WITH TIME ZONE NOT NULL,
    CREATED_BY  VARCHAR(64),
    UPDATED_BY  VARCHAR(64)
);

CREATE UNIQUE INDEX IX_MESSAGE_TENANT_LOCALE_CODE ON T_MESSAGE (TENANT_ID, LOCALE, CODE);
CREATE INDEX IDX_MESSAGE_TENANT_LOCALE ON T_MESSAGE (TENANT_ID, LOCALE);

-- 시드 데이터 — system tenant + 한국어 baseline 4 개
INSERT INTO T_MESSAGE (TENANT_ID, LOCALE, CODE, MESSAGE, CREATED_AT, UPDATED_AT, CREATED_BY)
VALUES ('__system__', 'ko-KR', 'showcase.welcome', '환영합니다 {0}', now(), now(), 'system'),
       ('__system__', 'ko-KR', 'showcase.bye', '안녕히 가세요 {0}', now(), now(), 'system'),
       ('__system__', 'en-US', 'showcase.welcome', 'Welcome, {0}', now(), now(), 'system'),
       ('acme', 'ko-KR', 'showcase.welcome', 'Acme 에 오신 것을 환영합니다 {0}', now(), now(), 'system');
