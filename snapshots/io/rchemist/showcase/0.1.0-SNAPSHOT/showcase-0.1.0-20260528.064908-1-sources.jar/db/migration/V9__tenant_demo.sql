-- T9-6 — Multi-tenant 3 전략 시연용 단순 entity (DISCRIMINATOR baseline 영역, default Flyway 적용).
-- DATABASE / SCHEMA strategy profile 활성 시 본 migration 은 spring.flyway.enabled=false 로 우회되고
-- TenantMigrator SPI 가 onboard 시점에 tenant 별 DDL 적용.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = TENANT_DEMO_ID.
CREATE TABLE T_TENANT_DEMO (
  TENANT_DEMO_ID  BIGSERIAL    NOT NULL PRIMARY KEY,
  TITLE           VARCHAR(200) NOT NULL,
  TENANT_ID       VARCHAR(64)  NOT NULL
);

CREATE INDEX IDX_TENANT_DEMO_TENANT_ID ON T_TENANT_DEMO (TENANT_ID);

COMMENT ON TABLE  T_TENANT_DEMO                 IS 'Multi-tenant 3 전략 시연용 단순 entity (T9-6)';
COMMENT ON COLUMN T_TENANT_DEMO.TENANT_DEMO_ID  IS 'PK';
COMMENT ON COLUMN T_TENANT_DEMO.TITLE           IS '표시용 제목';
COMMENT ON COLUMN T_TENANT_DEMO.TENANT_ID       IS 'Tenant 식별자 — Hibernate 7 @TenantId 자동';
