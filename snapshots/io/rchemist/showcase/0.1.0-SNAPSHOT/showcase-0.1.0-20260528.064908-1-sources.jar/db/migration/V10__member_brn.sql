-- T9-10 — Member 사업자등록번호 (BRN) 컬럼 추가. 한국 region helper (rcm-starter-kr) 의
-- @BusinessRegistrationNumber 검증 + MaskingUtil 응답 자동 masking 시연용.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE.
ALTER TABLE T_MEMBER
    ADD COLUMN BUSINESS_REGISTRATION_NUMBER VARCHAR(32);

COMMENT ON COLUMN T_MEMBER.BUSINESS_REGISTRATION_NUMBER IS '사업자등록번호 (선택, 법인 회원만)';
