-- Phase 11 task #1 baseline (Decision #26).
-- Flyway baseline 빈 schema. 도메인 schema = task #2 ~ #10 의 V2..V7 migration 으로 분리.
-- baseline-on-migrate=true 로 기존 DB 가 있어도 Flyway 가 본 V1 을 baseline 으로 인식.

CREATE TABLE IF NOT EXISTS schema_baseline (
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    version    VARCHAR(32)              DEFAULT '0.1.0'           NOT NULL,
    note       VARCHAR(255)             DEFAULT 'Phase 11 task #1 baseline (Decision #26)'
);

INSERT INTO schema_baseline (version, note)
VALUES ('0.1.0', 'Phase 11 task #1 — RCM Showcase baseline')
ON CONFLICT DO NOTHING;
