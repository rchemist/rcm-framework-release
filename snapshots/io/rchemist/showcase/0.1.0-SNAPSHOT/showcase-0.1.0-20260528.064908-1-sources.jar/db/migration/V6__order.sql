-- Phase 11 task #9 — Order Saga schema (Decision #2 + Decision #26).
-- 4 marker (Searchable + Auditable + SoftDelete + TenantAlias) + workflow_state field.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = ORDER_ID + boolean = IS_*.

CREATE TABLE T_ORDER
(
    ORDER_ID         BIGSERIAL PRIMARY KEY,
    CUSTOMER_ID      VARCHAR(64)    NOT NULL,
    TOTAL_AMOUNT     NUMERIC(18, 2) NOT NULL,
    STATUS           VARCHAR(16)    NOT NULL,
    WORKFLOW_STATE   VARCHAR(255),
    TENANT_ID        VARCHAR(64)    NOT NULL,
    IS_DELETED       BOOLEAN        NOT NULL DEFAULT FALSE,
    CREATED_AT       TIMESTAMP WITH TIME ZONE,
    UPDATED_AT       TIMESTAMP WITH TIME ZONE,
    CREATED_BY       VARCHAR(128),
    UPDATED_BY       VARCHAR(128)
);

CREATE INDEX IDX_ORDER_TENANT_CUSTOMER ON T_ORDER (TENANT_ID, CUSTOMER_ID);
CREATE INDEX IDX_ORDER_STATUS ON T_ORDER (STATUS);
