-- Phase 11 task #6 — File metadata schema (Decision #26 + Decision #12).
-- Storage SPI 의 *content* 와 분리 — DB metadata 만. tenant 별 자동 prefix.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = FILE_METADATA_ID + boolean = IS_* + size_bytes (Asset 정합).

CREATE TABLE T_FILE_METADATA
(
    FILE_METADATA_ID  BIGSERIAL PRIMARY KEY,
    STORAGE_KEY       VARCHAR(512) NOT NULL UNIQUE,
    ORIGINAL_NAME     VARCHAR(255) NOT NULL,
    CONTENT_TYPE      VARCHAR(128),
    SIZE_BYTES        BIGINT       NOT NULL,
    CHECKSUM          VARCHAR(128),
    TENANT_ID         VARCHAR(64)  NOT NULL,
    IS_DELETED        BOOLEAN      NOT NULL DEFAULT FALSE,
    CREATED_AT        TIMESTAMP WITH TIME ZONE,
    UPDATED_AT        TIMESTAMP WITH TIME ZONE,
    CREATED_BY        VARCHAR(128),
    UPDATED_BY        VARCHAR(128)
);

CREATE INDEX IDX_FILE_TENANT_CREATED ON T_FILE_METADATA (TENANT_ID, CREATED_AT DESC);
