/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service.extension;

import io.rchemist.extension.ExtensionResultHolder;
import io.rchemist.extension.ExtensionResultStatusType;
import io.rchemist.extension.RegisterExtensionHandler;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.showcase.blog.entity.Article;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Sample handler #1 — Article 본문/제목 sanitize. {@link RegisterExtensionHandler} annotation 부착으로
 * Spring scan 이 bean 발견 + ApplicationContextAware 영역에서 자동 manager 등록 (priority 50 — 먼저 실행).
 *
 * <p>제목의 trim + content 의 script tag 제거 (간단 sanitize 시연). 실제 production 에선 OWASP Java
 * HTML Sanitizer 등 라이브러리 사용 영역. 처리 후 {@link ExtensionResultStatusType#HANDLED_CONTINUE}
 * 반환 — 후속 audit handler 도 form/entity 처리 영역.
 **/
@RegisterExtensionHandler(manager = ArticleServiceExtensionManager.class, priority = 50)
public class ContentSanitizerArticleHandler implements ArticleServiceExtensionHandler {

  private static final String SCRIPT_TAG = "(?i)<script[^>]*>.*?</script>";

  @Override
  public ExtensionResultStatusType preCreate(ExtensionResultHolder<ArticleCreateForm> holder) {
    ArticleCreateForm form = holder.getResult();
    if (form == null) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    String sanitizedTitle = form.title() == null ? null : form.title().trim();
    String sanitizedContent = form.content() == null ? null : form.content().replaceAll(SCRIPT_TAG, "");
    if (sanitizedTitle == null || sanitizedTitle.equals(form.title())) {
      if (sanitizedContent == null || sanitizedContent.equals(form.content())) {
        return ExtensionResultStatusType.NOT_HANDLED;
      }
    }
    holder.withResult(new ArticleCreateForm(sanitizedTitle, sanitizedContent, form.viewCount()));
    holder.addContext("sanitized", true);
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  @Override
  public ExtensionResultStatusType preUpdate(Article entity,
                                              ExtensionResultHolder<ArticleUpdateForm> holder) {
    ArticleUpdateForm form = holder.getResult();
    if (form == null) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    String sanitizedContent = form.content() == null ? null : form.content().replaceAll(SCRIPT_TAG, "");
    if (sanitizedContent == null || sanitizedContent.equals(form.content())) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    holder.withResult(new ArticleUpdateForm(form.title(), sanitizedContent, form.viewCount()));
    holder.addContext("sanitized", true);
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }
}
