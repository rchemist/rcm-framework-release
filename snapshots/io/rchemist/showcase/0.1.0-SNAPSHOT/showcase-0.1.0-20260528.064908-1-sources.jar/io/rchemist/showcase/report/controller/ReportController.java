/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.report.controller;

import io.rchemist.showcase.report.dto.PaymentOrderReport;
import io.rchemist.showcase.report.dto.PaymentStatusReport;
import io.rchemist.showcase.report.dto.PaymentSummaryReport;
import io.rchemist.showcase.report.service.ReportingService;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * T9-1 — Payment 데이터 기반 집계 endpoint. framework AggregateExecutor 시연 (GROUP BY / HAVING /
 * COUNT_DISTINCT / SUM / AVG / MIN / MAX). 단순 CRUD 가 아닌 *분석* 영역 시연.
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code GET /api/v1/reports/payments/by-status?status=CHARGED} — 상태별 매출 집계
 *   <li>{@code GET /api/v1/reports/payments/by-order?threshold=10000} — 주문별 매출 + HAVING
 *   <li>{@code GET /api/v1/reports/payments/summary} — 전체 요약 (single row)
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/reports/payments")
public class ReportController {

  private final ReportingService reportingService;

  public ReportController(ReportingService reportingService) {
    this.reportingService = reportingService;
  }

  /** 상태별 매출 — status query param 으로 필터 옵션. */
  @GetMapping("/by-status")
  public List<PaymentStatusReport> byStatus(
      @RequestParam(value = "status", required = false) String status) {
    return reportingService.revenueByStatus(status);
  }

  /** 주문별 매출 — threshold 초과 주문만 (HAVING SUM(amount) > threshold). */
  @GetMapping("/by-order")
  public List<PaymentOrderReport> byOrder(
      @RequestParam(value = "threshold", defaultValue = "0") BigDecimal threshold) {
    return reportingService.revenueByOrder(threshold);
  }

  /** 전체 요약 — single row 6 집계. */
  @GetMapping("/summary")
  public PaymentSummaryReport summary() {
    return reportingService.summary();
  }

  /**
   * T9-2 (Decision #18) — cross-DataSource Payment count. main + reporting datasource 각각 별도
   * EntityManager 로 count 실행 후 합산. 등록된 datasource 모두 순회.
   */
  @GetMapping("/cross-ds-count")
  public java.util.Map<String, Long> crossDsCount() {
    return reportingService.crossDataSourcePaymentCount();
  }
}
