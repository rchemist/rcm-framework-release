/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.cache.controller;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.search.Search;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-9 — Cache hit / miss / put / evict / size 시연 endpoint. framework Phase 4
 * task #4 의 {@code CacheMetricsRegistrar} 가 Caffeine 의 native cache 마다 Micrometer
 * {@code CaffeineCacheMetrics} 자동 binding → 본 controller 가 {@link MeterRegistry} 에서 region
 * 별 stat 추출. {@code /actuator/metrics/cache.gets} 로도 동일 정보 노출, 본 endpoint 는 사람이 읽기 좋은
 * 통합 view.
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code GET /api/v1/cache-stats} — 모든 cache region 의 hit / miss / put / evict / size 단일 응답</li>
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/cache-stats")
public class CacheStatsController {

  private final CacheManager cacheManager;
  private final MeterRegistry meterRegistry;

  public CacheStatsController(CacheManager cacheManager, MeterRegistry meterRegistry) {
    this.cacheManager = cacheManager;
    this.meterRegistry = meterRegistry;
  }

  @GetMapping
  public List<CacheRegionStat> stats() {
    return cacheManager.getCacheNames().stream()
        .sorted()
        .map(this::stat)
        .collect(Collectors.toList());
  }

  private CacheRegionStat stat(String region) {
    return new CacheRegionStat(
        region,
        countOf("cache.gets", region, "result", "hit"),
        countOf("cache.gets", region, "result", "miss"),
        countOf("cache.puts", region, null, null),
        countOf("cache.evictions", region, null, null),
        gaugeOf("cache.size", region));
  }

  private long countOf(String name, String region, String tagKey, String tagValue) {
    Search search = meterRegistry.find(name).tag("cache", region);
    if (tagKey != null) {
      search = search.tag(tagKey, tagValue);
    }
    return search.counters().stream().mapToLong(c -> (long) c.count()).sum();
  }

  private long gaugeOf(String name, String region) {
    Search search = meterRegistry.find(name).tag("cache", region);
    return search.gauges().stream().mapToLong(g -> (long) g.value()).sum();
  }

  /** Cache region 별 hit / miss / put / evict / size 통계. */
  public record CacheRegionStat(
      String region, long hits, long misses, long puts, long evictions, long size) {}
}
