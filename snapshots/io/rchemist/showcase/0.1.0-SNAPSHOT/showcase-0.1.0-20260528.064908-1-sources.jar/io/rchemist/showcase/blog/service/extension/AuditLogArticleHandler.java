/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service.extension;

import io.rchemist.extension.ExtensionResultHolder;
import io.rchemist.extension.ExtensionResultStatusType;
import io.rchemist.extension.RegisterExtensionHandler;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.showcase.blog.entity.Article;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Sample handler #2 — Article CUD 후 audit log. priority 100 — Sanitizer (50) 다음 실행.
 *
 * <p>postCreate / postUpdate / postDelete 모두 {@link ExtensionResultStatusType#HANDLED_CONTINUE}
 * 반환 — 다른 handler 의 후속 처리도 영역.
 **/
@RegisterExtensionHandler(manager = ArticleServiceExtensionManager.class, priority = 100)
public class AuditLogArticleHandler implements ArticleServiceExtensionHandler {

  private static final Logger LOG = LoggerFactory.getLogger(AuditLogArticleHandler.class);

  @Override
  public ExtensionResultStatusType postCreate(ArticleCreateForm form,
                                                ExtensionResultHolder<Article> holder) {
    Article entity = holder.getResult();
    if (entity != null) {
      LOG.info("[AUDIT] article created — id={}, title={}", entity.getId(), entity.getTitle());
    }
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  @Override
  public ExtensionResultStatusType postUpdate(ArticleUpdateForm form,
                                                ExtensionResultHolder<Article> holder) {
    Article entity = holder.getResult();
    if (entity != null) {
      LOG.info("[AUDIT] article updated — id={}, title={}", entity.getId(), entity.getTitle());
    }
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  @Override
  public ExtensionResultStatusType postDelete(Article entity) {
    if (entity != null) {
      LOG.info("[AUDIT] article deleted — id={}, title={}", entity.getId(), entity.getTitle());
    }
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }
}
