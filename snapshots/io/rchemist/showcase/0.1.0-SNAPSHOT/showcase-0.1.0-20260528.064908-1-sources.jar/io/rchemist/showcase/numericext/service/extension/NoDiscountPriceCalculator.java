/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.extension;

import io.rchemist.core.numeric.money.Money;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-12 — Default {@link PriceCalculator} — 변경 없음. {@code @Order(0)} 으로 chain
 * 진입점.
 **/
@Component
@Order(0)
public class NoDiscountPriceCalculator implements PriceCalculator {

  @Override
  public String name() {
    return "no-discount";
  }

  @Override
  public Money calculate(Money price) {
    return price;
  }
}
