/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.controller;

import io.rchemist.showcase.file.dto.ImageVariantView;
import io.rchemist.showcase.file.service.ImageService;
import java.io.IOException;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (Decision #29 Q1) — image processing demo endpoint. multipart 업로드 →
 * resize variants (thumb / medium / large) 자동 생성 + Storage 저장 → 각 variant key 응답.
 *
 * <p>framework 의 {@code rcm-starter-asset} (asset.image sub-package — Thumbnailator + WebP/EXIF
 * 옵션) + {@code rcm-starter-storage} (LocalFileSystemStorage / S3 SPI) 가 결합 동작 시연.
 */
@RestController
@RequestMapping("/api/v1/images")
public class ImageController {

  private final ImageService imageService;

  public ImageController(ImageService imageService) {
    this.imageService = imageService;
  }

  /**
   * 이미지 업로드 + variant 자동 생성. 응답 = 원본 + 각 variant 의 storage key + size + MIME.
   *
   * <p>POST /api/v1/images/resize (multipart, field name = file)
   */
  @PostMapping("/resize")
  public ResponseEntity<List<ImageVariantView>> resize(@RequestParam("file") MultipartFile file)
      throws IOException {
    return ResponseEntity.ok(imageService.uploadAndGenerateVariants(file));
  }
}
