/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.dto;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (Decision #29 Q1) — image variant 응답. 원본 + 각 variant 의 storage key /
 * size / content type 노출.
 *
 * @param name        variant 이름 (e.g. {@code original}, {@code thumb}, {@code medium})
 * @param storageKey  storage backend 의 unique path
 * @param size        byte size
 * @param contentType MIME
 */
public record ImageVariantView(
    String name, String storageKey, long size, String contentType) {}
