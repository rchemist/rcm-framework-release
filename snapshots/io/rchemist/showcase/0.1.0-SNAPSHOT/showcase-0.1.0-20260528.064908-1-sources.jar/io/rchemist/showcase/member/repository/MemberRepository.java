/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.repository;

import io.rchemist.showcase.member.entity.Member;
import io.rchemist.starter.jpa.crud.CrudRepository;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member repository — RCM {@link CrudRepository} + 단건 finder ({@code findByLoginId}). RCM 컨벤션
 * (memory `feedback_layer_separated_packages`) — `find*` = 단일 결과 + NotFound 시 빈 Optional
 * (Service 가 throw 하는 패턴 정합).
 **/
public interface MemberRepository extends CrudRepository<Member, Long> {

  Optional<Member> findByLoginId(String loginId);
}
