/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.controller;

import io.rchemist.showcase.file.dto.FileMetadataView;
import io.rchemist.showcase.file.entity.FileMetadataEntity;
import io.rchemist.showcase.file.service.FileService;
import io.rchemist.starter.storage.s3.PresignedUrl;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #5 — File endpoint. multipart upload + download + presigned URL + delete.
 * framework 의 multipart 안전 default 가 size limit / MIME whitelist / extension 자동 (Decision
 * #23 — multipart 안전 default + Bean Validation i18n + Decision #24 — ServiceException 자동
 * ProblemDetail 매핑).
 **/
@RestController
@RequestMapping("/api/v1/files")
public class FileController {

  private final FileService fileService;

  public FileController(FileService fileService) {
    this.fileService = fileService;
  }

  @PostMapping
  public ResponseEntity<FileMetadataView> upload(@RequestParam("file") MultipartFile multipart)
      throws IOException {
    FileMetadataEntity meta = fileService.upload(multipart);
    return ResponseEntity.ok(toView(meta));
  }

  @GetMapping(value = "/{id}/download", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public ResponseEntity<InputStreamResource> download(@PathVariable Long id) {
    FileMetadataEntity meta = fileService.find(id);
    InputStream in = fileService.download(id);
    return ResponseEntity.ok()
        .header(
            HttpHeaders.CONTENT_DISPOSITION,
            "attachment; filename=\"" + meta.getOriginalName() + "\"")
        .contentType(MediaType.APPLICATION_OCTET_STREAM)
        .body(new InputStreamResource(in));
  }

  @GetMapping("/{id}/presigned-url")
  public ResponseEntity<PresignedUrl> presignedUrl(
      @PathVariable Long id, @RequestParam(defaultValue = "PT15M") Duration ttl) {
    return ResponseEntity.ok(fileService.issuePresignedDownloadUrl(id, ttl));
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable Long id) {
    fileService.delete(id);
    return ResponseEntity.noContent().build();
  }

  private static FileMetadataView toView(FileMetadataEntity meta) {
    return new FileMetadataView(
        meta.getId(),
        meta.getStorageKey(),
        meta.getOriginalName(),
        meta.getContentType(),
        meta.getSize(),
        meta.getChecksum(),
        meta.getTenantId(),
        meta.getCreatedAt());
  }
}
