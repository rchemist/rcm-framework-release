/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.service;

import io.rchemist.core.error.ServiceException;
import io.rchemist.showcase.member.entity.Member;
import io.rchemist.showcase.member.dto.MemberSignupForm;
import io.rchemist.showcase.member.dto.MemberUpdateForm;
import io.rchemist.showcase.member.repository.MemberRepository;
import io.rchemist.starter.jpa.crud.AbstractCrudService;
import io.rchemist.starter.web.crud.CrudErrorType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member service — Decision #7 의 얇은 base. 가입 시 BCrypt password hash + login lookup 추가.
 * MFA 활성화 / TOTP secret 저장은 별도 method ({@code enableMfa}).
 **/
@Service
@Transactional
public class MemberService
    extends AbstractCrudService<Member, Long, MemberSignupForm, MemberUpdateForm> {

  private final MemberRepository memberRepository;
  private final PasswordEncoder passwordEncoder;

  public MemberService(MemberRepository memberRepository, PasswordEncoder passwordEncoder) {
    super(memberRepository, Member.class);
    this.memberRepository = memberRepository;
    this.passwordEncoder = passwordEncoder;
  }

  @Override
  protected Member toEntity(MemberSignupForm form) {
    Member member = new Member();
    member.setLoginId(form.loginId());
    member.setPasswordHash(passwordEncoder.encode(form.password()));
    member.setName(form.name());
    member.setEmail(form.email());
    member.setPhone(form.phone());
    member.setResidentRegistrationNumber(form.residentRegistrationNumber());
    member.setBusinessRegistrationNumber(form.businessRegistrationNumber());
    return member;
  }

  @Override
  protected void applyForm(Member entity, MemberUpdateForm form) {
    if (form.name() != null) {
      entity.setName(form.name());
    }
    if (form.email() != null) {
      entity.setEmail(form.email());
    }
    if (form.phone() != null) {
      entity.setPhone(form.phone());
    }
  }

  @Override
  public Member update(Long id, MemberUpdateForm form) {
    try {
      return super.update(id, form);
    } catch (IllegalStateException ex) {
      throw new ServiceException(CrudErrorType.NOT_FOUND, String.valueOf(id));
    }
  }

  @Transactional(readOnly = true)
  public Member findByLoginId(String loginId) {
    return memberRepository
        .findByLoginId(loginId)
        .orElseThrow(() -> new ServiceException(CrudErrorType.NOT_FOUND, loginId));
  }

  public boolean verifyPassword(Member member, String rawPassword) {
    return passwordEncoder.matches(rawPassword, member.getPasswordHash());
  }

  public void changePassword(Long memberId, String currentPassword, String newPassword) {
    Member member = find(memberId);
    if (!verifyPassword(member, currentPassword)) {
      throw new ServiceException(CrudErrorType.NOT_FOUND, "current-password-mismatch");
    }
    member.setPasswordHash(passwordEncoder.encode(newPassword));
  }

  public void enableMfa(Long memberId, String totpSecret) {
    Member member = find(memberId);
    member.setMfaEnabled(true);
    member.setTotpSecret(totpSecret);
  }
}
