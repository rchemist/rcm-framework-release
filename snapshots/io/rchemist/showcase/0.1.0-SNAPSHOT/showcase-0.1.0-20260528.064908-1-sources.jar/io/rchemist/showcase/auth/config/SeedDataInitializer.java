/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.auth.config;

import io.rchemist.core.context.TenantContext;
import io.rchemist.showcase.member.entity.Member;
import io.rchemist.showcase.member.repository.MemberRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * #C2 — showcase 의 known-good demo 사용자 seed (showcase 단독 인증 e2e 영역). framework 영향 0
 * (showcase 자체 component). 사용자 = {@code admin} / {@code password123} (tenant {@code demo}).
 *
 * <p>{@link ApplicationReadyEvent} listener — Flyway migration 후 application context 가 준비된
 * 시점에서 1 회 실행. {@code MemberRepository.findByLoginId} 결과가 비어있을 때만 insert
 * (재기동 idempotent). multi-tenant scope 가 ScopedValue 기반이라 {@link TenantContext#runAs} 로
 * 명시 binding (showcase 의 X-TENANT 헤더 기본값 = {@code demo} 와 동일).
 *
 * <p>frontend e2e 시나리오에서 본 계정으로 로그인 + JWT 발급 + Article CRUD 호출. seed 가 없으면
 * AuthController 가 401 (NOT_FOUND credentials) 반환해 Playwright 가 회귀.
 **/
@Component
public class SeedDataInitializer {

  private static final Logger LOG = LoggerFactory.getLogger(SeedDataInitializer.class);

  private static final String DEMO_TENANT = "demo";
  private static final String DEMO_LOGIN_ID = "admin";
  private static final String DEMO_PASSWORD = "password123";

  private final MemberRepository memberRepository;
  private final PasswordEncoder passwordEncoder;

  public SeedDataInitializer(MemberRepository memberRepository, PasswordEncoder passwordEncoder) {
    this.memberRepository = memberRepository;
    this.passwordEncoder = passwordEncoder;
  }

  /**
   * Application 준비 후 1 회 실행. 멱등 — 이미 admin 이 있으면 skip. multi-tenant profile
   * (tenant-database / tenant-schema 등) 에서 'demo' tenant 가 onboard 미완료 상태면
   * IllegalStateException 발생 — startup 차단 회피용 silent skip (해당 IT 들이 자체 tenant
   * fixture 를 사용하므로 seed 가 들어가면 안 됨).
   */
  @EventListener(ApplicationReadyEvent.class)
  public void seed() {
    try {
      TenantContext.runAs(DEMO_TENANT, this::seedAdminUser);
    } catch (RuntimeException ex) {
      LOG.info(
          "[seed] skip — tenant '{}' 진입 불가 ({}: {}). multi-tenant profile 또는 tenant 미등록 환경 정합.",
          DEMO_TENANT,
          ex.getClass().getSimpleName(),
          ex.getMessage());
    }
  }

  @Transactional
  protected void seedAdminUser() {
    if (memberRepository.findByLoginId(DEMO_LOGIN_ID).isPresent()) {
      LOG.info("[seed] admin 사용자 이미 존재 — skip");
      return;
    }
    Member admin = new Member();
    admin.setLoginId(DEMO_LOGIN_ID);
    admin.setPasswordHash(passwordEncoder.encode(DEMO_PASSWORD));
    admin.setName("Showcase Admin");
    admin.setEmail("admin@rchemist.io");
    admin.setPhone("010-1234-5678");
    memberRepository.save(admin);
    LOG.info(
        "[seed] admin 사용자 신규 생성 완료 (loginId={}, tenantId={}) — frontend e2e 진입점",
        DEMO_LOGIN_ID,
        DEMO_TENANT);
  }
}
