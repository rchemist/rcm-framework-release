/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.entity;

import io.rchemist.core.marker.Auditable;
import io.rchemist.core.marker.Cacheable;
import io.rchemist.core.marker.Searchable;
import io.rchemist.core.marker.SoftDelete;
import io.rchemist.core.marker.TenantAlias;
import io.rchemist.starter.jpa.cache.CacheStrategy;
import io.rchemist.starter.jpa.cache.CacheWriteStrategy;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member — Phase 11 도메인 #2 (회원/인증). 4 marker (Searchable + Auditable + SoftDelete +
 * TenantAlias). 비밀번호 = BCrypt hash 저장 (Spring Security DelegatingPasswordEncoder).
 *
 * <p>한국 region 영역 (Decision #10) — {@code phone} / {@code residentRegistrationNumber} 컬럼은
 * {@link io.rchemist.starter.kr.phone.PhoneNumber} / {@link
 * io.rchemist.starter.kr.id.ResidentRegistrationNumber} 어노테이션이 DTO 영역에서 검증. entity 는
 * 검증된 값 저장만.
 **/
@Entity
@Table(name = "T_MEMBER", comment = "Member 회원/인증 entity — 4 marker + Decision #10 한국 region")
@EntityListeners(AuditingEntityListener.class)
@CacheStrategy(strategy = CacheWriteStrategy.WRITE_AROUND, ttl = "PT30M", entityMaxSize = 10000)
@org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")
@Getter
@Setter
@NoArgsConstructor
public class Member implements Searchable, Auditable, SoftDelete, TenantAlias, Cacheable {

  @Id
  @GeneratedValue
  @Column(name = "MEMBER_ID")
  private Long id;

  @Column(name = "LOGIN_ID", unique = true, nullable = false)
  private String loginId;

  @Column(name = "PASSWORD_HASH", nullable = false)
  private String passwordHash;

  @Column(name = "NAME")
  private String name;

  @Column(name = "EMAIL")
  private String email;

  @Column(name = "PHONE")
  private String phone;

  @Column(name = "RESIDENT_REGISTRATION_NUMBER")
  private String residentRegistrationNumber;

  @Column(name = "BUSINESS_REGISTRATION_NUMBER")
  private String businessRegistrationNumber;

  @Column(name = "IS_MFA_ENABLED")
  private boolean mfaEnabled;

  @Column(name = "TOTP_SECRET")
  private String totpSecret;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "TENANT_ID")
  private String tenantId;

  @CreatedDate
  @Column(name = "CREATED_AT")
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY")
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
