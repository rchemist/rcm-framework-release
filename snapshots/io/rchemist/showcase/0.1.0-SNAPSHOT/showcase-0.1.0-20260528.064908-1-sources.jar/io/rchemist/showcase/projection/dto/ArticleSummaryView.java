/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.projection.dto;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-13 — Article DTO constructor projection target. Records first (Decision #5).
 *
 * <p>{@link io.rchemist.starter.jpa.search.ProjectionExecutor#executeDto} 가 {@code (id, title,
 * viewCount)} 순으로 본 record 의 canonical constructor 호출 → SELECT id, title, view_count.
 * 결과는 entity hydration X (1 row 당 PK lookup + lazy collection 영역 미포함) — N+1 회피 + 메모리 절약.
 **/
public record ArticleSummaryView(Long id, String title, Integer viewCount) {}
