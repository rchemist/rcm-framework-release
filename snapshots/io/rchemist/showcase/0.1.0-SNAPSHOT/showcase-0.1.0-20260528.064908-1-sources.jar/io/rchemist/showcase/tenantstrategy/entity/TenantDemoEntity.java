/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.entity;

import io.rchemist.core.marker.TenantAlias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-6 — Multi-tenant 3 전략 (DISCRIMINATOR / DATABASE / SCHEMA) 시연용 단순 entity
 * (Decision #17). Article 같은 5 marker 결합 entity 와 달리 {@link TenantAlias} marker 1개 만 부착 — DATABASE
 * / SCHEMA 전략 IT 가 단일 entity 만으로 격리 검증.
 *
 * <p>전략 별 동작:
 * <ul>
 *   <li>DISCRIMINATOR (default profile) — 같은 DB / 같은 schema / {@code tenant_id} column 자동 채움 +
 *       SELECT 시 {@code WHERE tenant_id=?} 자동</li>
 *   <li>DATABASE (profile {@code tenant-database}) — tenant 별 별도 JDBC URL → tenant_id column 은 그대로
 *       채워지지만 격리 영역은 DataSource 분리로 자연 보장</li>
 *   <li>SCHEMA (profile {@code tenant-schema}) — 단일 DB / tenant 별 schema (search_path) → 같은 테이블 정의가
 *       tenant 별 분리된 row set 으로 동작</li>
 * </ul>
 **/
@Entity
@Table(name = "T_TENANT_DEMO",
    comment = "Multi-tenant 3 전략 (DISCRIMINATOR / DATABASE / SCHEMA) 시연용 단순 entity")
@Getter
@Setter
@NoArgsConstructor
public class TenantDemoEntity implements TenantAlias {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "TENANT_DEMO_ID", nullable = false, comment = "PK")
  private Long id;

  @Column(name = "TITLE", length = 200, nullable = false, comment = "표시용 제목")
  private String title;

  @TenantId
  @Column(name = "TENANT_ID", length = 64, nullable = false,
      comment = "Tenant 식별자 — Hibernate 7 @TenantId 가 INSERT 시 자동 채움 + SELECT 시 자동 WHERE")
  @Setter(lombok.AccessLevel.NONE)
  private String tenantId;

  public TenantDemoEntity(String title) {
    this.title = title;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
