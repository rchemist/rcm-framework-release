/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.bulk.service;

import io.rchemist.showcase.member.entity.Member;
import io.rchemist.showcase.member.repository.MemberRepository;
import io.rchemist.starter.jpa.async.AsyncJob;
import io.rchemist.starter.jpa.async.AsyncJobTracker;
import io.rchemist.starter.jpa.async.BulkImportProcessor;
import io.rchemist.starter.jpa.async.BulkImportResult;
import java.util.List;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #9 — Member bulk import facade. framework
 * {@link BulkImportProcessor} (Decision #13, Phase 4) + {@link AsyncJobTracker} 결합. Excel /
 * CSV row → Member entity 변환 + chunk 단위 persist + 진행률 polling.
 *
 * <p>Excel parser 는 외부 의존 (POI) 영역이라 본 demo = simple CSV (header line 제외 + comma split).
 * production 사용은 Apache POI / commons-csv wire (framework 책임 외).
 **/
@Service
@Transactional
public class MemberBulkImportService {

  private final MemberRepository memberRepository;
  private final PasswordEncoder passwordEncoder;
  private final AsyncJobTracker tracker;

  public MemberBulkImportService(
      MemberRepository memberRepository,
      PasswordEncoder passwordEncoder,
      AsyncJobTracker tracker) {
    this.memberRepository = memberRepository;
    this.passwordEncoder = passwordEncoder;
    this.tracker = tracker;
  }

  public BulkImportResult importCsv(String csvBody) {
    List<String[]> rows = parseCsv(csvBody);
    BulkImportProcessor<String[], Member> processor =
        new BulkImportProcessor<>(
            this::toMember, memberRepository::saveAll, 100, tracker, "member-bulk-import");
    return processor.process(rows);
  }

  public AsyncJob jobStatus(String jobId) {
    return tracker
        .find(jobId)
        .orElseThrow(() -> new IllegalStateException("job not found: " + jobId));
  }

  private Member toMember(String[] row) {
    if (row.length < 4) {
      throw new IllegalArgumentException("row needs 4 cols (loginId,password,name,email)");
    }
    Member member = new Member();
    member.setLoginId(row[0]);
    member.setPasswordHash(passwordEncoder.encode(row[1]));
    member.setName(row[2]);
    member.setEmail(row[3]);
    return member;
  }

  private static List<String[]> parseCsv(String body) {
    return body
        .lines()
        .skip(1)
        .filter(line -> !line.isBlank())
        .map(line -> line.split(",", -1))
        .toList();
  }
}
