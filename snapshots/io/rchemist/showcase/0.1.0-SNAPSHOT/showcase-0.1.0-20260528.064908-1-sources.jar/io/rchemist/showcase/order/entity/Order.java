/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.order.entity;

import io.rchemist.core.enumtype.EnumTypeUserType;
import io.rchemist.core.marker.Auditable;
import io.rchemist.core.marker.Searchable;
import io.rchemist.core.marker.SoftDelete;
import io.rchemist.core.marker.TenantAlias;
import io.rchemist.showcase.order.service.type.OrderStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.Instant;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.TenantId;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #8 — Order entity. 4 marker (Searchable + Auditable + SoftDelete + TenantAlias).
 * Workflow Saga (Decision #2) 가 4 step transition 책임 ({@link OrderStatus}).
 **/
@Entity
@Table(name = "T_ORDER",
    comment = "Order entity — Workflow Saga 4 step transition (Decision #2)")
@EntityListeners(AuditingEntityListener.class)
@org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")
@Getter
@Setter
@NoArgsConstructor
public class Order implements Searchable, Auditable, SoftDelete, TenantAlias {

  @Id
  @GeneratedValue
  @Column(name = "ORDER_ID")
  private Long id;

  @Column(name = "CUSTOMER_ID", nullable = false)
  private String customerId;

  @Column(name = "TOTAL_AMOUNT", nullable = false, precision = 18, scale = 2)
  private BigDecimal totalAmount;

  @Type(value = EnumTypeUserType.class,
      parameters = @Parameter(name = "enumClass",
          value = "io.rchemist.showcase.order.service.type.OrderStatus"))
  @Column(name = "STATUS", nullable = false, length = 16)
  private OrderStatus status;

  @Column(name = "WORKFLOW_STATE")
  private String workflowState;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "TENANT_ID")
  private String tenantId;

  @CreatedDate
  @Column(name = "CREATED_AT")
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY")
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
