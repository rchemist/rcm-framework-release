/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.format;

import io.rchemist.core.numeric.money.Money;
import java.text.NumberFormat;
import java.util.Locale;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Korean locale (ko-KR) {@link PriceFormatter} — `123,456 원` 패턴. {@code @Order(10)} 우선.
 **/
@Component
@Order(10)
public class KoreanWonFormatter implements PriceFormatter {

  @Override
  public boolean supports(Locale locale) {
    return locale != null && Locale.KOREA.getCountry().equals(locale.getCountry());
  }

  @Override
  public String format(Money money) {
    NumberFormat fmt = NumberFormat.getCurrencyInstance(Locale.KOREA);
    fmt.setCurrency(money.currency());
    return fmt.format(money.amount());
  }
}
