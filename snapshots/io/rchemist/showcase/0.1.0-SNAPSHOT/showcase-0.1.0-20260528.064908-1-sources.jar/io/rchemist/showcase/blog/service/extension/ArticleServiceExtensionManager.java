/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service.extension;

import io.rchemist.extension.ExtensionManager;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #6 ExtensionManager 시연 — Article 영역 chain dispatcher. {@link
 * ArticleServiceExtensionHandler} interface 의 8 hooks 영역에 대해 등록된 모든 handler 를 priority 순
 * chain invoke.
 *
 * <p>{@code continueOnHandled} default {@code false} (단일 처리 정지). 여러 handler 가 부분 처리해야 하면
 * 각 handler 가 {@code HANDLED_CONTINUE} 반환하도록 영역.
 **/
@Service
public class ArticleServiceExtensionManager extends ExtensionManager<ArticleServiceExtensionHandler> {

  public ArticleServiceExtensionManager() {
    super(ArticleServiceExtensionHandler.class);
  }
}
