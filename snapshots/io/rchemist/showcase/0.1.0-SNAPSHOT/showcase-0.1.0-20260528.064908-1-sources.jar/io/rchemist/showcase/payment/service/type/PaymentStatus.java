/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.payment.service.type;

import io.rchemist.core.enumtype.EnumType;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Payment 4 단계 — Workflow Saga (Decision #2) transition 책임. RCM {@link EnumType} 패턴 시연
 * (Decision #25) — Java enum 의 *확장 불가 / Jackson ordinal 기본 / description 표현 불가* 한계 해소.
 *
 * <p>{@link io.rchemist.core.enumtype.EnumTypeUserType} 와 짝 — {@code Payment.status} 는
 * {@code @Type(EnumTypeUserType.class)} 로 DB VARCHAR 저장. Consumer 가 정적 상수 추가 시 자동 등록
 * (LinkedHashMap 순서 보존).
 *
 * <p>REQUESTED → CHARGED (정상) | REQUESTED → FAILED (PG 실패) | CHARGED → REFUNDED (취소).
 **/
public final class PaymentStatus extends EnumType<PaymentStatus> {

  public static final PaymentStatus REQUESTED = new PaymentStatus("REQUESTED", "결제 요청");
  public static final PaymentStatus CHARGED = new PaymentStatus("CHARGED", "결제 완료");
  public static final PaymentStatus FAILED = new PaymentStatus("FAILED", "결제 실패");
  public static final PaymentStatus REFUNDED = new PaymentStatus("REFUNDED", "환불 완료");

  private PaymentStatus(String name, String description) {
    super(name, description);
  }

  /** 이름으로 instance 찾기. 못 찾으면 {@link IllegalArgumentException}. */
  public static PaymentStatus valueOf(String name) {
    return EnumType.valueOf(PaymentStatus.class, name);
  }

  /** 등록된 모든 instance — 등록 순서 보존. */
  public static List<PaymentStatus> values() {
    return EnumType.values(PaymentStatus.class);
  }
}
