/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.order.service;

import io.rchemist.core.error.ServiceException;
import io.rchemist.showcase.order.entity.Order;
import io.rchemist.showcase.order.service.type.OrderStatus;
import io.rchemist.showcase.order.dto.OrderRequest;
import io.rchemist.showcase.order.repository.OrderRepository;
import io.rchemist.starter.web.crud.CrudErrorType;
import io.rchemist.workflow.StepResult;
import io.rchemist.workflow.WorkflowDefinition;
import io.rchemist.workflow.WorkflowEngine;
import io.rchemist.workflow.WorkflowResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Order Saga service — request → 4 step Saga 실행 → 최종 status. Workflow Engine 위임.
 **/
@Service
@Transactional
public class OrderService {

  private final OrderRepository repository;
  private final WorkflowEngine workflowEngine;
  private final WorkflowDefinition<Order, Order> orderSaga;

  public OrderService(
      OrderRepository repository,
      WorkflowEngine workflowEngine,
      WorkflowDefinition<Order, Order> orderSaga) {
    this.repository = repository;
    this.workflowEngine = workflowEngine;
    this.orderSaga = orderSaga;
  }

  public Order placeOrder(OrderRequest req) {
    Order order = new Order();
    order.setCustomerId(req.customerId());
    order.setTotalAmount(req.totalAmount());
    order.setStatus(OrderStatus.NEW);
    order = repository.save(order);

    WorkflowResult<Order> result = workflowEngine.run(orderSaga, order);
    Order resolved = order;
    if (result.finalResult() instanceof StepResult.Success<Order> success) {
      resolved = success.output();
    } else if (result.compensationResult() instanceof StepResult.Success<?> comp
        && comp.output() instanceof Order o) {
      resolved = o;
    }
    return repository.save(resolved);
  }

  @Transactional(readOnly = true)
  public Order find(Long id) {
    return repository
        .findById(id)
        .orElseThrow(() -> new ServiceException(CrudErrorType.NOT_FOUND, String.valueOf(id)));
  }
}
