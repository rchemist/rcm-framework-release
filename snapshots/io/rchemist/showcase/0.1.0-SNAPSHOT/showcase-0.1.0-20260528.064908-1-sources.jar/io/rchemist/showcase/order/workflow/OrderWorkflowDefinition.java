/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.order.workflow;

import io.rchemist.showcase.order.entity.Order;
import io.rchemist.showcase.order.service.type.OrderStatus;
import io.rchemist.workflow.ParallelStep;
import io.rchemist.workflow.RetryPolicy;
import io.rchemist.workflow.StepResult;
import io.rchemist.workflow.WorkflowDefinition;
import io.rchemist.workflow.WorkflowDsl;
import io.rchemist.workflow.WorkflowStep;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #8 — Order Saga (Decision #2). 4 step pipeline (validate → reserve → charge →
 * finalize) + compensation (refund + release reservation).
 *
 * <p>각 step 은 lambda — framework 의 {@link WorkflowStep} functional interface 정합. 본 demo 는
 * single-process in-memory + DB persistence (Order entity 의 {@code workflowState} field).
 *
 * <p>compensation 은 첫 Failure 에서 호출 — Saga 의 *역순 보상* 패턴을 단일 step 으로 단순화.
 * production runtime 에서는 step 별 별도 compensation 분리 (rcm-workflow 후속 patch).
 **/
@Configuration(proxyBeanMethods = false)
public class OrderWorkflowDefinition {

  public static final String NAME = "order-saga";

  @Bean
  public WorkflowDefinition<Order, Order> orderSaga() {
    WorkflowStep<Order, Order> validate =
        (input, ctx) -> {
          if (input.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            return new StepResult.Failure<>(
                new IllegalArgumentException("amount must be positive"), true);
          }
          input.setStatus(OrderStatus.VALIDATED);
          return new StepResult.Success<>(input);
        };

    // §B1-2 showcase — 고액 주문 (>100k KRW) 만 risk-check 추가, 이외는 passthrough.
    // §B1-3 showcase — risk-check 내부에서 inventory + credit + fraud 3 종 ParallelStep
    // VirtualThread 동시 호출. 1 종이라도 Failure → 전체 risk-check Failure (compensate).
    WorkflowStep<Order, String> inventoryCheck =
        (input, ctx) -> new StepResult.Success<>("INVENTORY_OK");
    WorkflowStep<Order, String> creditCheck =
        (input, ctx) -> new StepResult.Success<>("CREDIT_OK");
    WorkflowStep<Order, String> fraudCheck =
        (input, ctx) -> new StepResult.Success<>("FRAUD_OK");
    WorkflowStep<Order, Order> riskCheckRaw =
        (input, ctx) -> {
          ParallelStep<Order, String> parallel =
              ParallelStep.of(List.of(inventoryCheck, creditCheck, fraudCheck));
          StepResult<List<String>> par = parallel.execute(input, ctx);
          if (par instanceof StepResult.Failure<List<String>> f) {
            return new StepResult.Failure<>(f.cause(), f.compensateRequired());
          }
          input.setWorkflowState("RISK_CHECKED:high-value");
          return new StepResult.Success<>(input);
        };
    // §B1-5 — DSL .optional() 가 BranchStep wrapping 흡수 (별도 BranchStep 변수 없음).

    // §B1-4 showcase — reserve 는 재고 lock 영역, 후속 step 실패 시 release 보상.
    WorkflowStep<Order, Order> reserve =
        new WorkflowStep<>() {
          @Override
          public StepResult<Order> execute(Order input, io.rchemist.workflow.WorkflowContext ctx) {
            input.setStatus(OrderStatus.RESERVED);
            input.setWorkflowState("RESERVED:inventory-locked");
            return new StepResult.Success<>(input);
          }

          @Override
          public StepResult<Void> compensate(
              Order completedOutput, io.rchemist.workflow.WorkflowContext ctx) {
            completedOutput.setWorkflowState("RELEASED:inventory-unlocked");
            return new StepResult.Success<>(null);
          }
        };

    // §B1-1 showcase — 외부 PG 호출 영역. 일시적 장애 시 fixed delay 3회 자동 재시도.
    // §B1-4 showcase — charge 는 결제 캡처 영역, 후속 step 실패 시 refund 보상.
    WorkflowStep<Order, Order> chargeRaw =
        new WorkflowStep<>() {
          @Override
          public StepResult<Order> execute(Order input, io.rchemist.workflow.WorkflowContext ctx) {
            input.setStatus(OrderStatus.CHARGED);
            input.setWorkflowState("CHARGED:pg-tx-" + System.nanoTime());
            return new StepResult.Success<>(input);
          }

          @Override
          public StepResult<Void> compensate(
              Order completedOutput, io.rchemist.workflow.WorkflowContext ctx) {
            completedOutput.setWorkflowState("REFUNDED:pg-reverse");
            return new StepResult.Success<>(null);
          }
        };
    // §B1-5 — DSL .retry() 가 RetryableStep wrapping 흡수 (별도 RetryableStep 변수 없음).

    WorkflowStep<Order, Order> finalize =
        (input, ctx) -> {
          input.setStatus(OrderStatus.FINALIZED);
          input.setWorkflowState("FINALIZED");
          return new StepResult.Success<>(input);
        };

    WorkflowStep<Order, Order> compensate =
        (input, ctx) -> {
          input.setStatus(OrderStatus.FAILED);
          input.setWorkflowState("COMPENSATED:refund + release");
          return new StepResult.Success<>(input);
        };

    // §B1-5 showcase — fluent DSL 로 5 step pipeline + definition-level compensation 구성.
    return WorkflowDsl.start(NAME, Order.class, Order.class)
        .step(validate)
        .optional(
            (Order order, io.rchemist.workflow.WorkflowContext ctx) ->
                order.getTotalAmount().compareTo(new BigDecimal("100000")) > 0,
            riskCheckRaw)
        .step(reserve)
        .retry(RetryPolicy.fixed(3, 50), chargeRaw)
        .step(finalize)
        .compensateWith(compensate)
        .build();
  }
}
