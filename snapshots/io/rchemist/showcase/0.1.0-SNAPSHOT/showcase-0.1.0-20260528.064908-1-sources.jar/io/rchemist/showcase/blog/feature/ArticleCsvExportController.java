/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.feature;

import io.rchemist.core.featureflag.ConditionalOnFeature;
import io.rchemist.core.featureflag.FeatureFlagService;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.blog.repository.ArticleRepository;
import java.nio.charset.StandardCharsets;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article CSV export endpoint — {@link ConditionalOnFeature} 시연 (Decision #33). yml 의
 * {@code platform.feature.article.export-csv.enabled=true} 일 때만 Bean 생성 → endpoint 노출.
 * 비활성 시 endpoint 자체가 ApplicationContext 에 없음 (404). FeatureFlag SPI 의 *Bean toggle*
 * 패턴 = 운영 환경에서 미사용 endpoint 의 attack surface 자동 차단.
 *
 * <p>{@link FeatureFlagService} 주입 = runtime 호출 토글 패턴 (Bean 토글과 양립). 본 controller 는
 * 양쪽 모두 시연 — class-level annotation = bean 토글, service 호출 = runtime check.
 **/
@RestController
@RequestMapping("/api/v1/articles/export")
@ConditionalOnFeature("article.export-csv")
public class ArticleCsvExportController {

  private final ArticleRepository repository;
  private final FeatureFlagService featureFlag;

  public ArticleCsvExportController(
      ArticleRepository repository, FeatureFlagService featureFlag) {
    this.repository = repository;
    this.featureFlag = featureFlag;
  }

  @GetMapping(value = ".csv", produces = "text/csv;charset=UTF-8")
  public ResponseEntity<byte[]> exportCsv() {
    featureFlag.requireEnabled("article.export-csv");

    var rows = new StringBuilder();
    rows.append("id,title,viewCount,tenantId,createdAt\n");
    for (Article a : repository.findAll()) {
      rows.append(a.getId())
          .append(',')
          .append(escape(a.getTitle()))
          .append(',')
          .append(a.getViewCount())
          .append(',')
          .append(escape(a.getTenantId()))
          .append(',')
          .append(a.getCreatedAt())
          .append('\n');
    }
    var bytes = rows.toString().getBytes(StandardCharsets.UTF_8);
    return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=articles.csv")
        .contentType(MediaType.parseMediaType("text/csv;charset=UTF-8"))
        .body(bytes);
  }

  private static String escape(String value) {
    if (value == null) {
      return "";
    }
    if (value.indexOf(',') < 0 && value.indexOf('"') < 0 && value.indexOf('\n') < 0) {
      return value;
    }
    return '"' + value.replace("\"", "\"\"") + '"';
  }
}
