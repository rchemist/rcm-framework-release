/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.index;

import io.rchemist.core.marker.Searchable;
import io.rchemist.core.marker.TenantAlias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article 의 denormalized search index (Decision #8 — `documents/9-search-engine-cookbook.md` 정합).
 *
 * <p>0.1.0 baseline = LIKE / EQ 기반. 검색 hit 시 본 index 의 {@code searchText} (title +
 * content_text 결합) 를 단일 LIKE — Article 본문 JOIN 없이 빠르게 hit. Article CRUD 시
 * {@link ArticleSearchIndexer} 가 자동 동기 갱신 (1:1 매핑).
 *
 * <p>0.2.0+ Consumer 수요 데이터 생기면 Elasticsearch SPI 로 진화 — index 자체는 유지 (LIKE 도
 * fallback 이고 ES 가 primary 가 되는 패턴, 메모리 `feedback_no_feature_regression` 정합).
 **/
@Entity
@Table(name = "T_ARTICLE_SEARCH_INDEX",
    comment = "Article denormalized search index — title + content_text 결합 LIKE 인덱스 (Decision #8)")
@Getter
@Setter
@NoArgsConstructor
public class ArticleSearchIndex implements Searchable, TenantAlias {

  @Id
  @Column(name = "ARTICLE_ID", comment = "Article 의 PK 와 1:1 매핑 (FK)")
  private Long articleId;

  @Column(name = "SEARCH_TEXT", comment = "title + content_text 결합 검색 hit 영역")
  private String searchText;

  @Column(name = "VIEW_COUNT", comment = "Article 의 조회수 mirror")
  private Integer viewCount;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "TENANT_ID", comment = "Tenant 식별자 — Hibernate 7 @TenantId 자동")
  private String tenantId;

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
