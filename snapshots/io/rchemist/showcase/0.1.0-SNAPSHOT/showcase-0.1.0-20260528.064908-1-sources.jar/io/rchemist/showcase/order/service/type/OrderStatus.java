/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.order.service.type;

import io.rchemist.core.enumtype.EnumType;
import java.util.List;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Order Saga 의 status 단계 — Phase 11 task #9 (Decision #2). RCM {@link EnumType} 패턴 시연
 * (Decision #25) — Java enum 의 *확장 불가 / Jackson ordinal 기본 / description 표현 불가* 한계 해소.
 *
 * <p>{@link io.rchemist.core.enumtype.EnumTypeUserType} 와 짝 — {@code Order.status} 는
 * {@code @Type(EnumTypeUserType.class)} 로 DB VARCHAR 저장.
 *
 * <p>NEW → VALIDATED → RESERVED → CHARGED → FINALIZED (정상). FAILED 는 compensation 결과.
 **/
public final class OrderStatus extends EnumType<OrderStatus> {

  public static final OrderStatus NEW = new OrderStatus("NEW", "주문 생성");
  public static final OrderStatus VALIDATED = new OrderStatus("VALIDATED", "검증 완료");
  public static final OrderStatus RESERVED = new OrderStatus("RESERVED", "재고 예약");
  public static final OrderStatus CHARGED = new OrderStatus("CHARGED", "결제 완료");
  public static final OrderStatus FINALIZED = new OrderStatus("FINALIZED", "배송 완료");
  public static final OrderStatus FAILED = new OrderStatus("FAILED", "실패 (compensation)");

  private OrderStatus(String name, String description) {
    super(name, description);
  }

  /** 이름으로 instance 찾기. 못 찾으면 {@link IllegalArgumentException}. */
  public static OrderStatus valueOf(String name) {
    return EnumType.valueOf(OrderStatus.class, name);
  }

  /** 등록된 모든 instance — 등록 순서 보존. */
  public static List<OrderStatus> values() {
    return EnumType.values(OrderStatus.class);
  }
}
