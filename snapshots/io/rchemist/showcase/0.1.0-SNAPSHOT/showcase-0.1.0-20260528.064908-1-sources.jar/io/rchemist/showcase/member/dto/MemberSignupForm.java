/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.dto;

import io.rchemist.starter.kr.id.BusinessRegistrationNumber;
import io.rchemist.starter.kr.id.ResidentRegistrationNumber;
import io.rchemist.starter.kr.phone.PhoneNumber;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member 가입 body — Decision #5 (Records baseline) + Decision #10 ({@link PhoneNumber} +
 * {@link ResidentRegistrationNumber} + {@link BusinessRegistrationNumber} 한국 region 어노테이션
 * 자동 검증). T9-10 (2026-05-05) — businessRegistrationNumber 추가 (법인 회원 영역 옵션).
 **/
public record MemberSignupForm(
    @NotBlank @Size(min = 4, max = 32) String loginId,
    @NotBlank @Size(min = 8, max = 128) String password,
    @NotBlank @Size(max = 64) String name,
    @Email String email,
    @PhoneNumber String phone,
    @ResidentRegistrationNumber String residentRegistrationNumber,
    @BusinessRegistrationNumber String businessRegistrationNumber) {}
