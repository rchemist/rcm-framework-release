/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service;

import io.rchemist.core.numeric.money.Money;
import io.rchemist.showcase.numericext.service.format.PriceFormatter;
import java.util.List;
import java.util.Locale;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring native multi-impl 시연 — {@link PriceFormatter} 의 다중 구현체를 `@Autowired List<X>` 패턴으로
 * 주입받아 사용자 locale 에 맞는 1 formatter 선택. chain control 불필요 + ResultHolder 불필요 + framework
 * 자산 신설 0 — Spring 표준 그대로.
 *
 * <p>{@code @Order} priority 순 정렬은 Spring 이 자동. 각 impl 의 {@link PriceFormatter#supports(Locale)}
 * 가 {@code true} 인 첫 hit 가 선택. KOREA → KoreanWonFormatter (Order 10), US → UsDollarFormatter
 * (Order 20), JAPAN → JapaneseYenFormatter (Order 30). 미지원 locale = {@link IllegalArgumentException}.
 **/
@Service
public class PriceFormatService {

  private final List<PriceFormatter> formatters;

  public PriceFormatService(List<PriceFormatter> formatters) {
    this.formatters = List.copyOf(formatters);
  }

  /** 사용자 locale 에 맞는 첫 formatter 1 hit 선택. supports == true 인 impl 부재 시 fail-loud. */
  public String format(Money money, Locale locale) {
    return formatters.stream()
        .filter(f -> f.supports(locale))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("locale 미지원: " + locale))
        .format(money);
  }

  /** Spring 이 주입한 (priority 순) formatter list 노출 — 시연 / 테스트용. */
  public List<PriceFormatter> formatters() {
    return formatters;
  }
}
