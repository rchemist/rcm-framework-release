/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.auth.dto;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Login / refresh 응답 — 두 토큰 한 묶음.
 **/
public record TokenResponse(String accessToken, String refreshToken) {}
