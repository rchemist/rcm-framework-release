/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.format;

import io.rchemist.core.numeric.money.Money;
import java.text.NumberFormat;
import java.util.Locale;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * US locale (en-US) {@link PriceFormatter} — `$123,456.00` 패턴. {@code @Order(20)} 두 번째 우선.
 **/
@Component
@Order(20)
public class UsDollarFormatter implements PriceFormatter {

  @Override
  public boolean supports(Locale locale) {
    return locale != null && Locale.US.getCountry().equals(locale.getCountry());
  }

  @Override
  public String format(Money money) {
    NumberFormat fmt = NumberFormat.getCurrencyInstance(Locale.US);
    fmt.setCurrency(money.currency());
    return fmt.format(money.amount());
  }
}
