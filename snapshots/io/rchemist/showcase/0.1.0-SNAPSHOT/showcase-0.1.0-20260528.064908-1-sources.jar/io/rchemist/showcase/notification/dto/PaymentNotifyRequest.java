/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.notification.dto;

import io.rchemist.starter.kr.phone.PhoneNumber;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 결제 알림 body — KakaoTalk AlimTalk + SMS fallback.
 **/
public record PaymentNotifyRequest(
    @PhoneNumber String phone, @NotBlank String paymentId, @Positive long amount) {}
