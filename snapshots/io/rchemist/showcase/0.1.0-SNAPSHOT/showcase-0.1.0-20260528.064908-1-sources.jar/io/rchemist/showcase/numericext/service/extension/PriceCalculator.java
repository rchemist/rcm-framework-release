/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.extension;

import io.rchemist.core.numeric.money.Money;
import io.rchemist.extension.ExtensionPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-12 — 가격 계산 ExtensionPoint sample (Decision #16, Phase 7). Spring Bean
 * 으로 등록된 모든 구현체가 {@code /actuator/extensions} 응답에 자동 노출 + Consumer 가 본 SPI 의
 * 다중 구현체 등록 시 framework 가 발견.
 *
 * <p>응답 = 변경된 {@link Money}. immutable Records — 산술 결과는 새 instance.
 *
 * <p><b>Strategy pattern 영역 — {@link io.rchemist.extension.ExtensionPoint}.</b> 다중 구현 중 사용자가
 * 1 strategy 선택 ({@code @ConfigurationProperties} 등 으로). interface metadata + actuator endpoint 노출.
 * Spring native 의존 주입 ({@code @Autowired List<PriceCalculator>} 또는 1 구현체 직접 주입). Decision
 * #6 의 {@link io.rchemist.extension.ExtensionManager} (Chain of Responsibility — 모든 handler
 * priority 순 chain) 와 별개 영역. ExtensionManager 시연 reference =
 * {@code blog/service/extension/ArticleServiceExtensionHandler.java}.
 *
 * <p>showcase 는 2 구현체 demo:
 * <ul>
 *   <li>{@link NoDiscountPriceCalculator} — original price 그대로 반환 (default)</li>
 *   <li>{@link TenPercentDiscountPriceCalculator} — 10% 할인 적용</li>
 * </ul>
 **/
@ExtensionPoint("Price calculation strategy — Money 산술 sample")
public interface PriceCalculator {

  /** 사람이 읽는 strategy 이름 (예: "10% discount"). */
  String name();

  /** 입력 가격에 strategy 적용 후 반환. */
  Money calculate(Money price);
}
