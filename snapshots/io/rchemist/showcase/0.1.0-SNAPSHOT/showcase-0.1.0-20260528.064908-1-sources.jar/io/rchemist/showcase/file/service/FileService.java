/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.service;

import io.rchemist.core.error.ServiceException;
import io.rchemist.showcase.file.entity.FileMetadataEntity;
import io.rchemist.showcase.file.repository.FileMetadataRepository;
import io.rchemist.starter.storage.core.ObjectMetadata;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import io.rchemist.starter.storage.s3.PresignedMethod;
import io.rchemist.starter.storage.s3.PresignedUrl;
import io.rchemist.starter.storage.s3.PresignedUrlIssuer;
import io.rchemist.starter.web.crud.CrudErrorType;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #5 — File upload / download service. framework Storage SPI (Decision #12) +
 * PresignedUrlIssuer SPI 호출 + DB metadata 영구 저장. multipart 안전 default = framework 의
 * UploadValidator 가 자동 (50MB 한도 / MIME whitelist / extension 검증 / virus scan SPI).
 *
 * <p>tenant 격리 — TenantAlias entity 가 자동 prefix. local storage backend 가 tenant 별 directory
 * 분리 (Decision #12 baseline).
 **/
@Service
@Transactional
public class FileService {

  private final Storage storage;
  private final PresignedUrlIssuer presignedUrlIssuer;
  private final FileMetadataRepository repository;

  public FileService(
      Storage storage,
      PresignedUrlIssuer presignedUrlIssuer,
      FileMetadataRepository repository) {
    this.storage = storage;
    this.presignedUrlIssuer = presignedUrlIssuer;
    this.repository = repository;
  }

  public FileMetadataEntity upload(MultipartFile multipart) throws IOException {
    String key = "uploads/" + UUID.randomUUID() + "-" + multipart.getOriginalFilename();
    StorageObject obj;
    try (InputStream in = multipart.getInputStream()) {
      obj =
          storage.put(
              key,
              in,
              multipart.getContentType(),
              ObjectMetadata.of(
                  Map.of("original-name", multipart.getOriginalFilename())));
    }

    FileMetadataEntity entity = new FileMetadataEntity();
    entity.setStorageKey(obj.key());
    entity.setOriginalName(multipart.getOriginalFilename());
    entity.setContentType(multipart.getContentType());
    entity.setSize(multipart.getSize());
    entity.setChecksum(obj.checksum());
    return repository.save(entity);
  }

  @Transactional(readOnly = true)
  public InputStream download(Long id) {
    FileMetadataEntity meta = find(id);
    return storage.open(meta.getStorageKey());
  }

  /** S3 / Azure / GCS backend 가 wired 시 — presigned URL (default Noop fail-loud). */
  public PresignedUrl issuePresignedDownloadUrl(Long id, Duration ttl) {
    FileMetadataEntity meta = find(id);
    return presignedUrlIssuer.issue(meta.getStorageKey(), PresignedMethod.GET, ttl);
  }

  public void delete(Long id) {
    FileMetadataEntity meta = find(id);
    storage.delete(meta.getStorageKey());
    repository.delete(meta);
  }

  @Transactional(readOnly = true)
  public FileMetadataEntity find(Long id) {
    return repository
        .findById(id)
        .orElseThrow(() -> new ServiceException(CrudErrorType.NOT_FOUND, String.valueOf(id)));
  }
}
