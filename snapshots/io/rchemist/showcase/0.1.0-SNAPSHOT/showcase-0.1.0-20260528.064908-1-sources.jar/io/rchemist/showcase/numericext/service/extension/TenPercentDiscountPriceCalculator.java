/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.extension;

import io.rchemist.core.numeric.money.Money;
import io.rchemist.core.numeric.percentage.Percentage;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-12 — 10% 할인 {@link PriceCalculator} — {@link Money#discount(Percentage)} 결합
 * 시연. {@code @Order(10)} 로 NoDiscount 다음 적용.
 **/
@Component
@Order(10)
public class TenPercentDiscountPriceCalculator implements PriceCalculator {

  private static final Percentage TEN_PERCENT = Percentage.of(10);

  @Override
  public String name() {
    return "10-percent-discount";
  }

  @Override
  public Money calculate(Money price) {
    return price.discount(TEN_PERCENT);
  }
}
