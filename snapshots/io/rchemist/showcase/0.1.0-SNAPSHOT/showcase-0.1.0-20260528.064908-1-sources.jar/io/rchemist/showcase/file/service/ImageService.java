/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.service;

import io.rchemist.showcase.file.dto.ImageVariantView;
import io.rchemist.starter.asset.image.core.ImageFormat;
import io.rchemist.starter.asset.image.core.ImageVariant;
import io.rchemist.starter.asset.image.storage.ImageStorageAdapter;
import io.rchemist.starter.storage.core.Storage;
import io.rchemist.starter.storage.core.StorageObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (Decision #29 Q1) — Image upload + auto-variant 데모. {@link
 * ImageStorageAdapter} 가 원본 + 3 variant (thumb 100x100 JPEG / medium 400x400 JPEG / large
 * 1000x1000 PNG) 자동 생성 후 Storage 에 저장.
 *
 * <p>tenant 격리 — Storage 의 {@code KeyGenerator} 가 wired 되어 있으면 자동 prefix.
 */
@Service
@Transactional
public class ImageService {

  private static final List<ImageVariant> DEFAULT_VARIANTS =
      List.of(
          ImageVariant.of("thumb", 100, 100, ImageFormat.JPEG),
          ImageVariant.of("medium", 400, 400, ImageFormat.JPEG),
          ImageVariant.of("large", 1000, 1000, ImageFormat.PNG));

  private final Storage storage;
  private final ImageStorageAdapter adapter;

  public ImageService(Storage storage, ImageStorageAdapter adapter) {
    this.storage = storage;
    this.adapter = adapter;
  }

  /**
   * Multipart 업로드 → 원본 + 3 variant 자동 저장. 각 variant 의 storage key + size + MIME 노출.
   */
  public List<ImageVariantView> uploadAndGenerateVariants(MultipartFile multipart)
      throws IOException {
    String baseKey = "demo/image/" + UUID.randomUUID() + "-" + multipart.getOriginalFilename();
    Map<String, StorageObject> stored;
    try (InputStream in = multipart.getInputStream()) {
      stored =
          adapter.processAndStore(
              storage, baseKey, multipart.getContentType(), in, DEFAULT_VARIANTS);
    }
    return stored.entrySet().stream()
        .map(
            e ->
                new ImageVariantView(
                    e.getKey(),
                    e.getValue().key(),
                    e.getValue().size(),
                    e.getValue().contentType()))
        .toList();
  }
}
