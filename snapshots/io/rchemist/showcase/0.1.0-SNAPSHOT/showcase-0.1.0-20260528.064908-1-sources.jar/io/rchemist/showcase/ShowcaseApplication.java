/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase;

import io.rchemist.core.search.EntityMetadata;
import java.util.ServiceLoader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.boot.data.redis.autoconfigure.DataRedisRepositoriesAutoConfiguration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * RCM Showcase 진입점 (Decision #26, Phase 11). framework 0.1.0 의 모든 9 starter + 6 도메인 marker +
 * 70+ template marker + 모든 ExtensionPoint 를 reference 사용 — 매뉴얼 그 자체.
 *
 * <p>{@code static} block — APT 가 생성한 모든 {@code Entity_Metadata} 를 ServiceLoader 로 강제
 * class load. {@code SchemaResolver} / {@code SearchRequestPlanner} 가 lookup 가능하게.
 * archetype 패턴 정합 (Phase 9, 0.1.0 후속 patch 후보).
 *
 * <p>{@code DataRedisRepositoriesAutoConfiguration} exclude — T9-14a (2026-05-04). showcase 는 Spring
 * Data Redis 를 *cache backend* 로만 사용 (Repository 없음). exclude 안 하면 multi Spring Data modules
 * strict mode 가 발동되어 JPA Repository 가 1개만 식별되는 회귀 발생 (MemberRepository / PaymentRepository
 * / OrderRepository / ArticleRepository 등 모두 bean 미생성). Spring Boot 4 + Spring Data JPA + Spring
 * Data Redis 조합의 표준 우회.
 **/
@SpringBootApplication(exclude = DataRedisRepositoriesAutoConfiguration.class)
@EnableJpaRepositories(basePackages = {
    "io.rchemist.showcase",
    "io.rchemist.starter.asset.entity"
})
@EntityScan(basePackages = {
    "io.rchemist.showcase",
    "io.rchemist.starter.jpai18n",
    "io.rchemist.starter.asset.entity"
})
public class ShowcaseApplication {

  static {
    ServiceLoader.load(EntityMetadata.class).forEach(metadata -> {});
  }

  public static void main(String[] args) {
    SpringApplication.run(ShowcaseApplication.class, args);
  }
}
