/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.dto;

import io.rchemist.starter.kr.phone.PhoneNumber;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member 부분 갱신 body — null 필드 = 미변경. login_id / 주민번호 = 불변 (가입 후 변경 불가).
 **/
public record MemberUpdateForm(
    @Size(max = 64) String name, @Email String email, @PhoneNumber String phone) {}
