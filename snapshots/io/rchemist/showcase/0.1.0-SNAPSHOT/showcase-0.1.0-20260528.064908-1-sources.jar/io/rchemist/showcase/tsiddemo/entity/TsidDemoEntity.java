/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tsiddemo.entity;

import io.rchemist.starter.jpa.id.TsidGenerator;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #28 — TSID Long PK + Jackson JSON String 자동 직렬화 (`TsidJacksonModule`) 시연용 단순 entity.
 *
 * <p>{@code @TsidGenerator @Id Long id} 패턴 — Hibernate 7 의 application-side ID 생성 (TSID 64-bit) +
 * Jackson 3 직렬화 시점에 {@code TsidJacksonModule} 가 {@code Long → String} 자동 변환 → JS
 * {@code Number} 53-bit 한계 회피. frontend 는 string 으로 받아 그대로 사용 ({@code Number(id)} 환산
 * 회피).
 *
 * <p>다른 marker (Searchable / Auditable / SoftDelete / TenantAlias) 부착 0 — TsidGenerator 만의 효과
 * 격리 (다른 marker 조합 부작용 검증 영역과 분리).
 **/
@Entity
@Table(name = "T_TSID_DEMO",
    comment = "TSID Long PK + JSON String 자동 직렬화 시연 (issue #28)")
@Getter
@Setter
@NoArgsConstructor
public class TsidDemoEntity {

  @Id
  @TsidGenerator
  @Column(name = "TSID_DEMO_ID", nullable = false, comment = "TSID Long PK")
  private Long id;

  @Column(name = "LABEL", length = 200, nullable = false, comment = "표시용 label")
  private String label;

  public TsidDemoEntity(String label) {
    this.label = label;
  }
}
