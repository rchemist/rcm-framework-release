/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.index;

import io.rchemist.core.search.index.outbox.SearchIndexEvent;
import io.rchemist.core.search.index.outbox.SearchIndexOutbox;
import io.rchemist.showcase.blog.entity.Article;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article CRUD 시 {@link ArticleSearchIndex} 자동 동기 갱신 (Decision #8 cookbook 패턴) +
 * #B2-9 ES dual-write outbox append (옵션 — outbox bean 있을 때만).
 *
 * <p>0.1.0 baseline = 단일 TX 안 sync 갱신 (Article + Index 한 묶음). 0.2.0+ ES dual-write =
 * SearchIndexOutbox 가 있으면 ArticleEsDocument INDEX/DELETE 이벤트도 동시 적재 → 별도 worker 가
 * tick. 메모리 `feedback_no_feature_regression` 정합 (DB index 유지 + ES 추가).
 **/
@Component
public class ArticleSearchIndexer {

  private final ArticleSearchIndexRepository indexRepository;
  private final ObjectProvider<SearchIndexOutbox> outbox;

  public ArticleSearchIndexer(
      ArticleSearchIndexRepository indexRepository, ObjectProvider<SearchIndexOutbox> outbox) {
    this.indexRepository = indexRepository;
    this.outbox = outbox;
  }

  @EventListener
  @Transactional(propagation = Propagation.MANDATORY)
  public void onArticleSaved(ArticleSavedEvent event) {
    Article article = event.article();
    ArticleSearchIndex index =
        indexRepository.findById(article.getId()).orElseGet(ArticleSearchIndex::new);
    index.setArticleId(article.getId());
    index.setSearchText(buildSearchText(article));
    index.setViewCount(article.getViewCount());
    indexRepository.save(index);

    // ES dual-write — outbox bean 있을 때만 (ES starter 미인입 환경 = no-op).
    SearchIndexOutbox out = outbox.getIfAvailable();
    if (out != null) {
      out.append(
          SearchIndexEvent.index(ArticleEsDocument.class, article.getId(), article.getTenantId()));
    }
  }

  @EventListener
  @Transactional(propagation = Propagation.MANDATORY)
  public void onArticleDeleted(ArticleDeletedEvent event) {
    indexRepository.deleteById(event.articleId());

    SearchIndexOutbox out = outbox.getIfAvailable();
    if (out != null) {
      out.append(SearchIndexEvent.delete(ArticleEsDocument.class, event.articleId()));
    }
  }

  private static String buildSearchText(Article article) {
    StringBuilder sb = new StringBuilder();
    if (article.getTitle() != null) {
      sb.append(article.getTitle()).append(' ');
    }
    if (article.getContentText() != null) {
      sb.append(article.getContentText());
    }
    return sb.toString().trim();
  }

  /** Application event — Article CRUD 후 publish. */
  public record ArticleSavedEvent(Article article) {}

  /** Application event — Article delete 후 publish. */
  public record ArticleDeletedEvent(Long articleId) {}
}
