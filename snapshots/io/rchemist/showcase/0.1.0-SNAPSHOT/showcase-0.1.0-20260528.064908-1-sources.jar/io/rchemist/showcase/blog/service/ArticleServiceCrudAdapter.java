/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service;

import io.rchemist.core.search.SearchRequest;
import io.rchemist.core.search.SearchResponse;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.starter.web.crud.BulkDeleteRequest;
import io.rchemist.starter.web.crud.CrudService;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article service adapter — JPA 의 {@link io.rchemist.starter.jpa.crud.AbstractCrudService} 를
 * Web 의 {@link CrudService} SPI 에 연결. {@link io.rchemist.starter.web.crud.AbstractCrudController}
 * 가 의존하는 SPI 영역.
 **/
@Component
public class ArticleServiceCrudAdapter
    implements CrudService<Article, Long, ArticleCreateForm, ArticleUpdateForm> {

  private final ArticleService delegate;

  public ArticleServiceCrudAdapter(ArticleService delegate) {
    this.delegate = delegate;
  }

  @Override
  public Article create(ArticleCreateForm form) {
    return delegate.create(form);
  }

  @Override
  public Article find(Long id) {
    return delegate.find(id);
  }

  @Override
  public Page<Article> search(SearchRequest request) {
    return delegate.search(request);
  }

  @Override
  public SearchResponse<Article> searchResponse(SearchRequest request) {
    // Phase 0.1.0 GA Gate T0-6 — efficient SearchResponse 위임 (default fallback 회피).
    return delegate.searchResponse(request);
  }

  @Override
  public long count(SearchRequest request) {
    // Phase 0.1.0 GA Gate T0-6 — efficient COUNT(*) 위임 (default search().getTotalElements() 회피).
    return delegate.count(request);
  }

  @Override
  public Article update(Long id, ArticleUpdateForm form) {
    return delegate.update(id, form);
  }

  @Override
  public void delete(Long id) {
    delegate.delete(id);
  }

  @Override
  public void bulkDelete(BulkDeleteRequest<Long> request) {
    // Phase 0.1.0 GA Gate T0-6 — deleteAllByIdInBatch 위임 (default per-id loop 회피).
    delegate.bulkDelete(request.ids());
  }

  @Override
  public Map<String, Object> searchSchema() {
    return delegate.searchSchema();
  }
}
