/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.i18n.controller;

import io.rchemist.starter.jpai18n.MessageRefreshedEvent;
import java.util.Locale;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T8 — DB-backed MessageSource demo (Decision #32, `rcm-starter-jpa-i18n`).
 *
 * <p>표준 Spring {@link MessageSource} bean 이 Composite chain (DB ▸ file ▸ default) — 본 컨트롤러는
 * 그냥 inject 해서 lookup. tenant 격리는 {@link io.rchemist.core.context.TenantContext} 자동 (X-TENANT
 * 헤더 resolver chain). cache 무효화는 {@link MessageRefreshedEvent} publish.
 *
 * <p>flyway V7 시드:
 * <ul>
 *   <li>{@code __system__/ko-KR/showcase.welcome} = "환영합니다 {0}"</li>
 *   <li>{@code __system__/ko-KR/showcase.bye} = "안녕히 가세요 {0}"</li>
 *   <li>{@code __system__/en-US/showcase.welcome} = "Welcome, {0}"</li>
 *   <li>{@code acme/ko-KR/showcase.welcome} = "Acme 에 오신 것을 환영합니다 {0}" (tenant override)</li>
 * </ul>
 *
 * <p>호출 예: {@code GET /api/v1/i18n/messages/showcase.welcome?name=홍길동} + {@code X-TENANT: acme}
 * → "Acme 에 오신 것을 환영합니다 홍길동". 헤더 없으면 system tenant default.
 **/
@RestController
@RequestMapping("/api/v1/i18n/messages")
public class MessageDemoController {

  private final MessageSource messageSource;
  private final ApplicationEventPublisher publisher;

  public MessageDemoController(MessageSource messageSource, ApplicationEventPublisher publisher) {
    this.messageSource = messageSource;
    this.publisher = publisher;
  }

  /**
   * 메시지 lookup. tenant 는 X-TENANT 헤더 chain (framework default).
   */
  @GetMapping("/{code}")
  public String lookup(
      @org.springframework.web.bind.annotation.PathVariable String code,
      @RequestParam(required = false, defaultValue = "ko-KR") String locale,
      @RequestParam(required = false, defaultValue = "world") String name) {
    return messageSource.getMessage(code, new Object[]{name}, Locale.forLanguageTag(locale));
  }

  /**
   * cache 무효화 — admin GUI 가 메시지 update 후 호출. tenantId/locale/code 모두 명시 시 single-key,
   * 모두 비우면 전체 cache clear.
   */
  @DeleteMapping("/cache")
  public void invalidate(
      @RequestParam(required = false) String tenantId,
      @RequestParam(required = false) String locale,
      @RequestParam(required = false) String code) {
    if (tenantId == null && locale == null && code == null) {
      publisher.publishEvent(MessageRefreshedEvent.all());
    } else {
      publisher.publishEvent(MessageRefreshedEvent.of(tenantId, locale, code));
    }
  }
}
