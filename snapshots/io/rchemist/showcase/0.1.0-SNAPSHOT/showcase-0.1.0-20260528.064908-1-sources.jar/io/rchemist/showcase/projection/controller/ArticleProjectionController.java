/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.projection.controller;

import io.rchemist.core.search.ProjectionRequest;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.projection.dto.ArticleSummaryView;
import io.rchemist.starter.jpa.search.ProjectionExecutor;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-13 — Article projection (Tuple/Map + DTO constructor) 시연 endpoint.
 * framework Phase 3 task #6g 의 {@link ProjectionExecutor} 위에 단순 wrapper. SELECT 영역 절약 +
 * entity hydration 회피 + N+1 회피 (관계 fetch 안 함).
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code POST /api/v1/articles/projection/map} — alias = field path 의 {@code Map<String, Object>}
 *       응답 (id / title / viewCount)</li>
 *   <li>{@code POST /api/v1/articles/projection/dto} — {@link ArticleSummaryView} Records constructor
 *       projection — Hibernate 가 직접 record 인스턴스 생성</li>
 * </ul>
 *
 * <p>입력 body 는 표준 {@link SearchRequest} (filter / sort / pagination 영역). projection 의 fields
 * 는 hard-coded ({@code id / title / viewCount}) — Consumer 가 자유 fields 적용 시 별도 ProjectionRequest
 * builder 적용.
 **/
@RestController
@RequestMapping("/api/v1/articles/projection")
@Transactional(readOnly = true)
public class ArticleProjectionController {

  private static final List<String> SUMMARY_FIELDS = List.of("id", "title", "viewCount");

  @PersistenceContext private EntityManager em;

  @PostMapping("/map")
  public List<Map<String, Object>> projectMap(@RequestBody(required = false) SearchRequest search) {
    ProjectionRequest req = ProjectionRequest.fields(SUMMARY_FIELDS, search);
    return new ProjectionExecutor<>(em, Article.class).execute(req);
  }

  @PostMapping("/dto")
  public List<ArticleSummaryView> projectDto(@RequestBody(required = false) SearchRequest search) {
    ProjectionRequest req = ProjectionRequest.toDto(ArticleSummaryView.class, SUMMARY_FIELDS, search);
    return new ProjectionExecutor<>(em, Article.class).executeDto(req, ArticleSummaryView.class);
  }
}
