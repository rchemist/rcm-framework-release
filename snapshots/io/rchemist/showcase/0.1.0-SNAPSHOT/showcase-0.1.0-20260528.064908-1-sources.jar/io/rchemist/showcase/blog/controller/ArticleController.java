/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.controller;

import io.rchemist.showcase.blog.dto.ArticleView;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.starter.web.crud.AbstractCrudController;
import io.rchemist.starter.web.crud.CrudService;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import io.rchemist.starter.web.crud.DefaultAccessRoute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article REST controller — Decision #7 의 얇은 base. {@link AbstractCrudController} extends +
 * 추상 메소드 1 개 ({@code toReadDTO}) + helper override ({@code extractId}). 5 표준 endpoint
 * (POST / GET list / GET {id} / PUT {id} / DELETE {id}) + GET /_search/schema discovery 자동.
 *
 * <p>OpenAPI 자동 — {@code rcm-starter-web} 의 springdoc-openapi 통합으로 {@code /swagger-ui.html}
 * 자동 노출 (Decision #15 정합).
 *
 * <p>issue #26 — {@link DefaultAccessRoute} 부착. {@link AbstractCrudController} 8 endpoint 자동 PDP
 * 매핑 (resource={@code Showcase.Article} + 8 action 자동 derive). consumer 가 method override 없이
 * 1 부착 → 8 endpoint 모두 보호. consumer 가 자체 {@link
 * io.rchemist.starter.security.access.AccessDecisionEvaluator} bean 등록 시 자동 enforce.
 **/
@RestController
@RequestMapping("/api/v1/articles")
@DefaultAccessRoute(resourcePrefix = "Showcase", entityName = "Article")
public class ArticleController
    extends AbstractCrudController<Article, Long, ArticleCreateForm, ArticleUpdateForm, ArticleView> {

  public ArticleController(
      CrudService<Article, Long, ArticleCreateForm, ArticleUpdateForm> service) {
    super(service);
  }

  @Override
  protected ArticleView toReadDTO(Article entity) {
    return new ArticleView(
        entity.getId(),
        entity.getTitle(),
        entity.getContent(),
        entity.getContentText(),
        entity.getViewCount(),
        entity.getTenantId(),
        entity.getCreatedAt(),
        entity.getUpdatedAt(),
        entity.getCreatedBy());
  }

  @Override
  protected Long extractId(Article entity) {
    return entity.getId();
  }

  /**
   * Issue #24 showcase 반영 — {@code @PreAuthorize("hasRole('ADMIN')")} 부착 endpoint. 미인증
   * 호출 시 {@code SecurityExceptionHandlers#handleAuthentication} 가 401 {@code
   * ACCESS.AUTHENTICATION_REQUIRED} ProblemDetail 반환, 인증되었지만 ADMIN role 부재 시
   * {@code SecurityExceptionHandlers#handleAccessDenied} 가 403 {@code ACCESS.DENIED} ProblemDetail
   * 반환 — manual 정합 시연.
   *
   * <p>본 endpoint 의 단순 동작 = article 강제 unpublish (관리자 권한 시연). 도메인 의미는 sample
   * 영역 — RFC 7807 ProblemDetail 매핑 영역의 시연이 본 endpoint 의 목적.
   */
  @PreAuthorize("hasRole('ADMIN')")
  @PostMapping("/{id}/_admin/force-unpublish")
  public ResponseEntity<Map<String, Object>> adminForceUnpublish(@PathVariable Long id) {
    return ResponseEntity.ok(Map.of(
        "articleId", id,
        "action", "force-unpublish",
        "by", "ADMIN"));
  }
}
