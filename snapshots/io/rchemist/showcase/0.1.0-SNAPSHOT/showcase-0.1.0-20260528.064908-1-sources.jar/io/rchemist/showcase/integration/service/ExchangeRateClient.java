/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.integration.service;

import io.rchemist.showcase.integration.dto.ExchangeRateResponse;
import io.rchemist.starter.external.autoconfig.NamedRestClientRegistry;
import io.rchemist.starter.external.resilience.ResilientApiCall;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-7 — 외부 환율 API 호출 client. {@link NamedRestClientRegistry} 의
 * {@code exchange-rate} 등록 client 사용 (yml {@code platform.external.clients.exchange-rate.base-url}).
 *
 * <p>{@link ResilientApiCall} 부착 — Resilience4j Retry + CircuitBreaker + Bulkhead 자동 결합.
 * yml {@code platform.external.resilience.policies.exchange-rate.*} 에서 override (default = 3 attempt /
 * 50% CB threshold / 25 concurrent).
 *
 * <p>traceparent + X-Correlation-Id 자동 propagation (framework default interceptor chain).
 * 4xx/5xx 응답은 {@link io.rchemist.starter.external.problem.ExternalApiException} 으로 자동 wrap.
 **/
@Component
public class ExchangeRateClient {

  private final RestClient client;

  public ExchangeRateClient(NamedRestClientRegistry registry) {
    this.client = registry.get("exchange-rate");
  }

  /**
   * {@code base} 통화 기준의 모든 환율을 외부 API 에서 조회.
   *
   * @param base 기준 통화 코드 (e.g. {@code "KRW"})
   * @return 외부 API 응답 (Records, parsed Jackson)
   */
  @ResilientApiCall("exchange-rate")
  public ExchangeRateResponse fetchRates(String base) {
    return client
        .get()
        .uri(uriBuilder -> uriBuilder.path("/latest").queryParam("base", base).build())
        .retrieve()
        .body(ExchangeRateResponse.class);
  }
}
