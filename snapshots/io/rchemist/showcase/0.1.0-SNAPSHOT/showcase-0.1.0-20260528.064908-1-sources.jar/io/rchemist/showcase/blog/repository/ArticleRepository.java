/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.repository;

import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.starter.jpa.crud.CrudRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article repository — RCM {@link CrudRepository} (Spring Data JPA + JpaSpecificationExecutor).
 * 0.1.0 framework 는 한 줄 extends 만 — 표준 CRUD + Specification + Page 자동.
 **/
public interface ArticleRepository extends CrudRepository<Article, Long> {}
