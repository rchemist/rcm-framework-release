/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.bulk.controller;

import io.rchemist.showcase.bulk.service.MemberBulkImportService;
import io.rchemist.starter.jpa.async.AsyncJob;
import io.rchemist.starter.jpa.async.BulkImportResult;
import java.io.IOException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #9 — Bulk import endpoint. CSV multipart 받아 Member chunked import +
 * AsyncJobTracker 진행률 polling.
 **/
@RestController
@RequestMapping("/api/v1/bulk")
public class BulkImportController {

  private final MemberBulkImportService bulkService;

  public BulkImportController(MemberBulkImportService bulkService) {
    this.bulkService = bulkService;
  }

  @PostMapping("/members")
  public ResponseEntity<BulkImportResult> importMembers(@RequestParam("file") MultipartFile file)
      throws IOException {
    String body = new String(file.getBytes(), java.nio.charset.StandardCharsets.UTF_8);
    return ResponseEntity.ok(bulkService.importCsv(body));
  }

  @GetMapping("/jobs/{jobId}")
  public ResponseEntity<AsyncJob> jobStatus(@PathVariable String jobId) {
    return ResponseEntity.ok(bulkService.jobStatus(jobId));
  }
}
