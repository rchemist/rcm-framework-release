/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.auth.config;

import io.rchemist.starter.security.jwt.TokenIssuer;
import io.rchemist.starter.security.tokenstore.RefreshRotator;
import io.rchemist.starter.security.tokenstore.TokenStore;
import java.time.Duration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * T9-14a (2026-05-04) — showcase 의 RefreshRotator manual wiring. framework
 * {@code SecurityAutoConfiguration.TokenStoreBeans#rcmRefreshRotator} 가 nested {@code @Configuration}
 * static class 안에서 {@code @AutoConfigureAfter} 가 무시되는 Spring Boot 4 한계로 인해
 * {@link TokenIssuer}, {@link TokenStore} bean 이 *같은* SecurityAutoConfiguration 의 다른 nested
 * class 에서 제공되어도 {@code @ConditionalOnBean} 매칭 시점에서 미발견 → bean 미생성.
 *
 * <p>showcase 가 *consumer* 입장에서 manual 로 wiring — Decision #29 정합 (Consumer 가 framework
 * 제공 SPI 에 직접 binding). framework 수정 (TokenStoreBeans 분리 또는 @AutoConfiguration 분리) 은
 * 0.1.x 후속 patch 후보.
 *
 * <p>Issue #24 showcase 반영 — {@code @EnableMethodSecurity} 부착 → showcase 의 {@code
 * @PreAuthorize("hasRole('ADMIN')")} endpoint (예: {@code ArticleController#adminForceUnpublish})
 * 가 동작 → framework {@code SecurityExceptionHandlers} 의 401/403 ProblemDetail 매핑 manual
 * 정합 시연.
 **/
@Configuration(proxyBeanMethods = false)
@EnableMethodSecurity
class AuthBeansConfig {

  @Bean
  RefreshRotator showcaseRefreshRotator(TokenIssuer issuer, TokenStore store) {
    return new RefreshRotator(issuer, store, Duration.ofMinutes(15), Duration.ofDays(30));
  }
}
