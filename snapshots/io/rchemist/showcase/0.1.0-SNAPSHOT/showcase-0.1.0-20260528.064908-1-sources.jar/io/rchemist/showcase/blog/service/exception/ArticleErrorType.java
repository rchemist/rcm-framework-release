/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service.exception;

import io.rchemist.core.enumtype.EnumType;
import io.rchemist.core.error.ErrorType;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article 도메인 ErrorType — Phase 0.1.0 GA Gate T0-1 (Decision #25) 패턴 sample.
 *
 * <p>0.0.5 의 {@code XxxServiceErrorType extends EnumType<T> implements ErrorType} 패턴 그대로
 * 흡수 — Java enum 의 *확장 불가* 한계 회피 위해 **instance singleton class** 패턴 (enum 이 아니라
 * class). 이게 EnumType abstract base 의 핵심 가치 (Hibernate UserType + Jackson Serializer 자동
 * 결합 + 도메인 별 새 instance 추가 자유 + i18n message key 자동 lookup).
 *
 * <p>Decision #24 의 {@link ErrorType} 와 결합 — {@link io.rchemist.core.error.ServiceException}
 * throw 시 {@code ProblemDetailAdvice} 가 자동 ProblemDetail 변환.
 *
 * <p>사용 패턴: {@code throw new ServiceException(ArticleErrorType.NOT_FOUND, articleId);}
 */
public final class ArticleErrorType extends EnumType<ArticleErrorType> implements ErrorType {

  public static final ArticleErrorType NOT_FOUND =
      new ArticleErrorType("ARTICLE.NOT_FOUND", HttpStatus.NOT_FOUND, "기사를 찾을 수 없음");

  public static final ArticleErrorType TITLE_DUPLICATE =
      new ArticleErrorType("ARTICLE.TITLE_DUPLICATE", HttpStatus.CONFLICT, "동일 제목 기사 존재");

  public static final ArticleErrorType VIEW_COUNT_NEGATIVE =
      new ArticleErrorType("ARTICLE.VIEW_COUNT_NEGATIVE", HttpStatus.BAD_REQUEST,
          "조회수는 음수일 수 없습니다");

  public static final ArticleErrorType CACHE_EVICT_FAILED =
      new ArticleErrorType("ARTICLE.CACHE_EVICT_FAILED", HttpStatus.INTERNAL_SERVER_ERROR,
          "캐시 무효화 실패");

  private final HttpStatus httpStatus;

  private ArticleErrorType(String code, HttpStatus httpStatus, String description) {
    super(code, description);
    this.httpStatus = httpStatus;
  }

  // ErrorType (Decision #24)
  @Override
  public String code() {
    return name();
  }

  @Override
  public HttpStatus httpStatus() {
    return httpStatus;
  }
}
