/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.controller;

import io.rchemist.showcase.tenantstrategy.entity.TenantDemoEntity;
import io.rchemist.showcase.tenantstrategy.repository.TenantDemoRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-6 — Multi-tenant 3 전략 시연용 minimal CRUD endpoint. 같은 코드가 active profile
 * (default DISCRIMINATOR / {@code tenant-database} / {@code tenant-schema}) 만 바꾸면 다른 strategy 로 동작.
 *
 * <p>endpoint 매트릭스:
 * <ul>
 *   <li>{@code POST /api/v1/tenant-demo} body {@code {"title": "..."}} + {@code X-TENANT} 헤더 → entity 등록</li>
 *   <li>{@code GET /api/v1/tenant-demo} + {@code X-TENANT} 헤더 → 해당 tenant row 만 list</li>
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/tenant-demo")
public class TenantDemoController {

  private final TenantDemoRepository repository;

  public TenantDemoController(TenantDemoRepository repository) {
    this.repository = repository;
  }

  @PostMapping
  public ResponseEntity<TenantDemoView> create(@Valid @RequestBody CreateRequest request) {
    TenantDemoEntity saved = repository.save(new TenantDemoEntity(request.title()));
    return ResponseEntity.ok(TenantDemoView.from(saved));
  }

  @GetMapping
  public List<TenantDemoView> list() {
    return repository.findAll().stream().map(TenantDemoView::from).toList();
  }

  /** DTO — Records first (Decision #5). */
  public record CreateRequest(@NotBlank String title) {}

  /** DTO — Records first (Decision #5). */
  public record TenantDemoView(Long id, String title, String tenantId) {

    public static TenantDemoView from(TenantDemoEntity entity) {
      return new TenantDemoView(entity.getId(), entity.getTitle(), entity.getTenantId());
    }
  }
}
