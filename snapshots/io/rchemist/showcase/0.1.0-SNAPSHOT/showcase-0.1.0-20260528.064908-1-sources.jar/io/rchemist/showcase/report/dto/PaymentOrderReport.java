/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.report.dto;

import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 주문별 매출 집계 row — GROUP BY orderId / COUNT(id) / SUM(amount) / AVG(amount). HAVING SUM(amount) >
 * threshold 적용 결과.
 *
 * @param orderId 주문 ID
 * @param count   해당 주문 결제 row 개수
 * @param total   해당 주문 amount 합 (KRW)
 * @param average 해당 주문 amount 평균 (KRW)
 **/
public record PaymentOrderReport(String orderId, Long count, BigDecimal total, BigDecimal average) {
}
