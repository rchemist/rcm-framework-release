/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service.extension;

import io.rchemist.extension.ExtensionHandler;
import io.rchemist.extension.ExtensionResultHolder;
import io.rchemist.extension.ExtensionResultStatusType;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.showcase.blog.dto.ArticleView;
import io.rchemist.showcase.blog.entity.Article;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Decision #6 ExtensionManager 시연 — ArticleService 의 8 hooks 영역. Consumer 가 본 interface 구현 +
 * {@code @RegisterExtensionHandler(manager = ArticleServiceExtensionManager.class, priority = ...)}
 * 부착으로 자동 chain 합류.
 *
 * <p>모든 hook 의 default = {@link ExtensionResultStatusType#NOT_HANDLED} — 본 handler 가 영역 아니면 chain
 * 다음 handler 로. {@link io.rchemist.extension.ExtensionPoint} (Strategy) 와 별개 영역.
 **/
public interface ArticleServiceExtensionHandler extends ExtensionHandler {

  /** Form 검증 / 변환. Sanitize / 정규화 등. holder 결과 갱신 시 service 가 sanitized form 사용. */
  default ExtensionResultStatusType preCreate(ExtensionResultHolder<ArticleCreateForm> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** Entity 후처리 — audit log / analytics / dual-write 등. */
  default ExtensionResultStatusType postCreate(ArticleCreateForm form,
                                                ExtensionResultHolder<Article> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** Form 검증 / 변환. */
  default ExtensionResultStatusType preUpdate(Article entity,
                                                ExtensionResultHolder<ArticleUpdateForm> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** Entity 후처리. */
  default ExtensionResultStatusType postUpdate(ArticleUpdateForm form,
                                                ExtensionResultHolder<Article> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** View 변환 전 — 별도 view 가 hooks 영역. holder.hasResult() 면 service 는 default 변환 skip. */
  default ExtensionResultStatusType preView(Article entity,
                                              ExtensionResultHolder<ArticleView> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** View 변환 후 — 관계 entity 채움 / 추가 metadata 등. */
  default ExtensionResultStatusType postView(Article entity,
                                              ExtensionResultHolder<ArticleView> holder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** 삭제 전 검증 / 관계 entity cascade 등. */
  default ExtensionResultStatusType preDelete(Article entity) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /** 삭제 후 audit log / cleanup. */
  default ExtensionResultStatusType postDelete(Article entity) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
