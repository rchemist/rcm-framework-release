/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.repository;

import io.rchemist.showcase.tenantstrategy.entity.TenantDemoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-6 — {@link TenantDemoEntity} Spring Data JPA repository. 표준 메서드만 사용 —
 * findAll() / save() / count() / deleteAll() 가 strategy 별 자동 격리 (Hibernate 7 multi-tenancy).
 **/
public interface TenantDemoRepository extends JpaRepository<TenantDemoEntity, Long> {
}
