/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tsiddemo.controller;

import io.rchemist.showcase.tsiddemo.entity.TsidDemoEntity;
import io.rchemist.showcase.tsiddemo.repository.TsidDemoRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #28 — TSID Long PK + Jackson JSON String 자동 직렬화 시연 controller.
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code POST /api/v1/tsid-demo} body {@code {"label": "..."}} → entity 등록 +
 *       응답의 {@code "id"} 가 JSON String (TsidJacksonModule 효과)</li>
 *   <li>{@code GET /api/v1/tsid-demo/{id}} → 단건 조회. {@code id} path variable 은 string-form Long
 *       (Spring MVC 의 {@code Long} converter 가 자동 parse)</li>
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/tsid-demo")
public class TsidDemoController {

  private final TsidDemoRepository repository;

  public TsidDemoController(TsidDemoRepository repository) {
    this.repository = repository;
  }

  @PostMapping
  public ResponseEntity<TsidDemoView> create(@Valid @RequestBody CreateRequest request) {
    TsidDemoEntity saved = repository.save(new TsidDemoEntity(request.label()));
    return ResponseEntity.ok(TsidDemoView.from(saved));
  }

  @GetMapping("/{id}")
  public ResponseEntity<TsidDemoView> findOne(@PathVariable Long id) {
    return repository.findById(id)
        .map(TsidDemoView::from)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.notFound().build());
  }

  /** DTO — Records first (Decision #5). */
  public record CreateRequest(@NotBlank String label) {}

  /** DTO — Records first (Decision #5). */
  public record TsidDemoView(Long id, String label) {

    public static TsidDemoView from(TsidDemoEntity entity) {
      return new TsidDemoView(entity.getId(), entity.getLabel());
    }
  }
}
