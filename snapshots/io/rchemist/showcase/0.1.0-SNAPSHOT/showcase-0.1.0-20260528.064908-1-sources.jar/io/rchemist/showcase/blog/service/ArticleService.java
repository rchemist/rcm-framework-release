/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.service;

import io.rchemist.core.error.ServiceException;
import io.rchemist.extension.ExtensionResultHolder;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.blog.index.ArticleSearchIndexer;
import io.rchemist.showcase.blog.repository.ArticleRepository;
import io.rchemist.showcase.blog.service.exception.ArticleErrorType;
import io.rchemist.showcase.blog.service.extension.ArticleServiceExtensionManager;
import io.rchemist.starter.jpa.crud.AbstractCrudService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article service — Decision #7 의 얇은 base. {@link AbstractCrudService} extends + 추상 메소드 2 개
 * ({@code toEntity} / {@code applyForm}) 만 구현. 5 표준 method (create / find / search / update /
 * delete) + searchSchema 자동.
 *
 * <p>HTML strip — {@code content} (HTML) 와 {@code contentText} (plain) 분리 저장. 검색 시
 * universal SearchRequest 가 {@code contentText} 필드 기반으로 LIKE / EQ — HTML tag noise 회피.
 *
 * <p>{@code update} 의 missing entity = {@link IllegalStateException} → {@link ServiceException}
 * (NOT_FOUND) 매핑 — framework 의 {@code ProblemDetailAdvice} 가 자동 404 ProblemDetail 변환
 * (Decision #1 + #24 — ServiceException 자동 ProblemDetail + field nullable + multi-error 흡수).
 * Bean Validation 메시지 i18n 도 framework 자동 (Decision #23).
 *
 * <p>Decision #6 ExtensionManager 시연 — {@link ArticleServiceExtensionManager} 가 등록된 handler
 * (ContentSanitizer + AuditLog) 를 priority 순 chain. {@code create / update / delete} 영역에서
 * pre / post hook 호출 — Consumer 가 {@code @RegisterExtensionHandler} 부착으로 자동 chain 합류.
 *
 * <p>TDD 강제 — 본 service 는 RED → GREEN → REFACTOR 사이클 정합 (Decision #19, JaCoCo 60%
 * 임계 Phase 10 GA).
 **/
@Service
@Transactional
public class ArticleService
    extends AbstractCrudService<Article, Long, ArticleCreateForm, ArticleUpdateForm> {

  private final ApplicationEventPublisher eventPublisher;
  private final ArticleServiceExtensionManager extensionManager;

  public ArticleService(ArticleRepository repository,
                        ApplicationEventPublisher eventPublisher,
                        ArticleServiceExtensionManager extensionManager) {
    super(repository, Article.class);
    this.eventPublisher = eventPublisher;
    this.extensionManager = extensionManager;
  }

  @Override
  public Article create(ArticleCreateForm form) {
    ExtensionResultHolder<ArticleCreateForm> formHolder = new ExtensionResultHolder<ArticleCreateForm>()
        .withResult(form);
    extensionManager.dispatch(h -> h.preCreate(formHolder));
    ArticleCreateForm effectiveForm = formHolder.getResult();

    Article saved = super.create(effectiveForm);

    ExtensionResultHolder<Article> entityHolder = new ExtensionResultHolder<Article>()
        .withResult(saved);
    extensionManager.dispatch(h -> h.postCreate(effectiveForm, entityHolder));
    eventPublisher.publishEvent(new ArticleSearchIndexer.ArticleSavedEvent(saved));
    return saved;
  }

  @Override
  public void delete(Long id) {
    Article entity = find(id);
    extensionManager.dispatch(h -> h.preDelete(entity));
    super.delete(id);
    extensionManager.dispatch(h -> h.postDelete(entity));
    eventPublisher.publishEvent(new ArticleSearchIndexer.ArticleDeletedEvent(id));
  }

  @Override
  protected Article toEntity(ArticleCreateForm form) {
    Article entity = new Article();
    entity.setTitle(form.title());
    entity.setContent(form.content());
    entity.setContentText(stripHtml(form.content()));
    entity.setViewCount(form.viewCount() == null ? 0 : form.viewCount());
    return entity;
  }

  @Override
  protected void applyForm(Article entity, ArticleUpdateForm form) {
    if (form.title() != null) {
      entity.setTitle(form.title());
    }
    if (form.content() != null) {
      entity.setContent(form.content());
      entity.setContentText(stripHtml(form.content()));
    }
    if (form.viewCount() != null) {
      entity.setViewCount(form.viewCount());
    }
  }

  @Override
  public Article update(Long id, ArticleUpdateForm form) {
    try {
      Article current = find(id);
      ExtensionResultHolder<ArticleUpdateForm> formHolder = new ExtensionResultHolder<ArticleUpdateForm>()
          .withResult(form);
      extensionManager.dispatch(h -> h.preUpdate(current, formHolder));
      ArticleUpdateForm effectiveForm = formHolder.getResult();

      Article updated = super.update(id, effectiveForm);

      ExtensionResultHolder<Article> entityHolder = new ExtensionResultHolder<Article>()
          .withResult(updated);
      extensionManager.dispatch(h -> h.postUpdate(effectiveForm, entityHolder));
      eventPublisher.publishEvent(new ArticleSearchIndexer.ArticleSavedEvent(updated));
      return updated;
    } catch (IllegalStateException ex) {
      // 도메인 ErrorType 사용 sample (Phase 0.1.0 GA Gate T0-1, EnumType<T> 패턴 — Decision #25).
      throw new ServiceException(ArticleErrorType.NOT_FOUND, String.valueOf(id));
    }
  }

  private static String stripHtml(String html) {
    if (html == null || html.isBlank()) {
      return html;
    }
    return html.replaceAll("<[^>]+>", "").trim();
  }
}
