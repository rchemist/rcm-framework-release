/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.controller;

import io.rchemist.showcase.member.dto.MemberView;
import io.rchemist.showcase.member.repository.MemberRepository;
import io.rchemist.showcase.member.service.MemberService;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * #C2 (2026-05-05) — Member read-only list endpoint. {@link AbstractCrudController} 를
 * 사용하지 않는다 — Member 는 자체 가입 endpoint (auth) + read-only admin 영역만 노출. 본 controller
 * 가 frontend listgrid 통합 e2e 영역에서 회원 목록 페이지 수신 + ProblemDetail / Page<T> 통합 기준
 * 동작 검증.
 *
 * <p>응답 = {@link Page} (Spring Data) — {@code rcm-starter-web} 의 Page wire format 표준 정합.
 * {@code phone} / {@code residentRegistrationNumber} 는 {@link MaskingUtil} 로 PII 마스킹 적용
 * (Decision #29 Q2). 직접 db 컬럼 평문 노출 영구 거부.
 **/
@RestController
@RequestMapping("/api/v1/members")
public class MemberController {

  private static final int MAX_PAGE_SIZE = 100;

  private final MemberRepository memberRepository;

  public MemberController(MemberRepository memberRepository) {
    this.memberRepository = memberRepository;
  }

  /**
   * Page<T> wire format. {@code page} 0-based + {@code size} default 20 cap 100 + sort {@code id,desc}.
   */
  @GetMapping
  public Page<MemberView> list(
      @RequestParam(defaultValue = "0") int page,
      @RequestParam(defaultValue = "20") int size) {
    int safeSize = Math.min(Math.max(size, 1), MAX_PAGE_SIZE);
    int safePage = Math.max(page, 0);
    PageRequest pageRequest =
        PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "id"));
    return memberRepository.findAll(pageRequest).map(MemberView::from);
  }

  /**
   * search by loginId substring. AbstractCrudController 의 SearchRequest 를 쓰지 않는 단순 사례.
   */
  @GetMapping("/search")
  public List<MemberView> search(@RequestParam String loginId) {
    if (loginId == null || loginId.isBlank()) {
      return List.of();
    }
    return memberRepository.findAll().stream()
        .filter(m -> m.getLoginId() != null && m.getLoginId().contains(loginId))
        .limit(MAX_PAGE_SIZE)
        .map(MemberView::from)
        .toList();
  }
}
