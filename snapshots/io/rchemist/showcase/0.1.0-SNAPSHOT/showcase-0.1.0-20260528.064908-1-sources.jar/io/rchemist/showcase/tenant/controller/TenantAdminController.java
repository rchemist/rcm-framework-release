/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenant.controller;

import io.rchemist.showcase.tenant.dto.TenantSummary;
import io.rchemist.showcase.tenant.dto.TenantOnboardRequest;
import io.rchemist.starter.jpa.multitenant.TenantConfig;
import io.rchemist.starter.jpa.multitenant.TenantManagementService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #7 — multi-tenant 관리자 endpoint. framework
 * {@link TenantManagementService} ExtensionPoint (Decision #17 — Phase 3 task #4) 흡수 +
 * onboard / offboard / activeTenants 단순 wrapper. ADMIN 권한 분리는 framework
 * SecurityFilterChain default + showcase 의 /api/v1/admin/** 경로 정합 (production runtime).
 *
 * <p>본 demo = DISCRIMINATOR 전략 baseline ({@code TenantConfig.forDiscriminator}). DATABASE /
 * SCHEMA 전략은 framework 의 동일 SPI 로 swap (Decision #17).
 **/
@RestController
@RequestMapping("/api/v1/admin/tenants")
public class TenantAdminController {

  private final TenantManagementService tenantService;

  public TenantAdminController(TenantManagementService tenantService) {
    this.tenantService = tenantService;
  }

  @PostMapping
  public ResponseEntity<TenantSummary> onboard(@Valid @RequestBody TenantOnboardRequest req) {
    tenantService.onboard(TenantConfig.forDiscriminator(req.tenantId()));
    return ResponseEntity.ok(new TenantSummary(req.tenantId(), "DISCRIMINATOR"));
  }

  @DeleteMapping("/{tenantId}")
  public ResponseEntity<Void> offboard(@PathVariable String tenantId) {
    tenantService.offboard(tenantId);
    return ResponseEntity.noContent().build();
  }

  @GetMapping
  public ResponseEntity<List<String>> active() {
    return ResponseEntity.ok(tenantService.activeTenants());
  }
}
