/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.controller;

import io.hypersistence.tsid.TSID;
import io.rchemist.core.numeric.money.Money;
import io.rchemist.core.numeric.percentage.Percentage;
import io.rchemist.showcase.numericext.service.extension.PriceCalculator;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-12 — Money / Percentage 산술 + ExtensionPoint chain + TsidGenerator 시연
 * endpoint. framework Phase 6.5 (rcm-core-numeric) + Phase 7 (rcm-extension) + Phase 1 (TsidGenerator).
 *
 * <p>endpoint 매트릭스:
 * <ul>
 *   <li>{@code POST /api/v1/pricing/calc} — 모든 등록된 {@link PriceCalculator} 가 chain 적용 (Order)</li>
 *   <li>{@code POST /api/v1/pricing/breakdown} — Money + Percentage 산술 매트릭스 (총액 / 부가세 /
 *       할인 / 1/N 분할)</li>
 *   <li>{@code GET /api/v1/pricing/tsid?count=5} — TSID 발급 (timestamp ordered + base32)</li>
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/pricing")
public class PricingDemoController {

  private static final TSID.Factory TSID_FACTORY = TSID.Factory.builder().build();

  private final List<PriceCalculator> calculators;

  public PricingDemoController(List<PriceCalculator> calculators) {
    this.calculators = List.copyOf(calculators);
  }

  /** 등록된 모든 {@link PriceCalculator} 가 chain 적용. */
  @PostMapping("/calc")
  public CalculationResult calc(@Valid @RequestBody PriceRequest request) {
    Money price = Money.of(request.amount(), request.currency());
    List<Step> steps = new ArrayList<>();
    Money current = price;
    for (PriceCalculator calculator : calculators) {
      Money result = calculator.calculate(current);
      steps.add(new Step(calculator.name(), result.amount(), result.currency().getCurrencyCode()));
      current = result;
    }
    return new CalculationResult(price.amount(), price.currency().getCurrencyCode(), steps);
  }

  /** Money + Percentage 산술 매트릭스 — 사용자가 매뉴얼로 사용 패턴 확인용. */
  @PostMapping("/breakdown")
  public Breakdown breakdown(@Valid @RequestBody BreakdownRequest request) {
    Money price = Money.of(request.amount(), request.currency());
    Percentage vat = Percentage.of(request.vatPercent());
    Percentage discount = Percentage.of(request.discountPercent());

    Money discounted = price.discount(discount);
    Money vatAmount = discounted.multiply(vat);
    Money total = discounted.plus(vatAmount);
    Money perPerson =
        request.splitAmong() > 1
            ? total.dividedBy(BigDecimal.valueOf(request.splitAmong()))
            : total;

    return new Breakdown(
        price.amount(),
        discounted.amount(),
        vatAmount.amount(),
        total.amount(),
        perPerson.amount(),
        price.currency().getCurrencyCode());
  }

  /** TSID 발급 — Decision #21 시연. timestamp ordered + base32 encoding. */
  @GetMapping("/tsid")
  public List<TsidSample> tsid(
      @org.springframework.web.bind.annotation.RequestParam(defaultValue = "5") int count) {
    List<TsidSample> result = new ArrayList<>(count);
    for (int i = 0; i < count; i++) {
      TSID tsid = TSID_FACTORY.generate();
      result.add(new TsidSample(tsid.toLong(), tsid.toString(), tsid.getInstant().toString()));
    }
    return result;
  }

  /** Body — Records (Decision #5). */
  public record PriceRequest(@Positive BigDecimal amount, @NotBlank String currency) {}

  /** Body — Records (Decision #5). */
  public record BreakdownRequest(
      @Positive BigDecimal amount,
      @NotBlank String currency,
      int vatPercent,
      int discountPercent,
      int splitAmong) {}

  /** 응답 — Records. */
  public record CalculationResult(BigDecimal originalAmount, String currency, List<Step> steps) {}

  /** 응답 — Records. */
  public record Step(String calculator, BigDecimal amount, String currency) {}

  /** 응답 — Records. */
  public record Breakdown(
      BigDecimal original,
      BigDecimal discounted,
      BigDecimal vat,
      BigDecimal total,
      BigDecimal perPerson,
      String currency) {}

  /** 응답 — Records. */
  public record TsidSample(long longValue, String stringValue, String instant) {}
}
