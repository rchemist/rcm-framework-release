/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.order.controller;

import io.rchemist.showcase.order.dto.OrderView;
import io.rchemist.showcase.order.entity.Order;
import io.rchemist.showcase.order.dto.OrderRequest;
import io.rchemist.showcase.order.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #8 — Order endpoint. POST = Saga 실행, GET = 결과 조회. Saga 의 4 step
 * (validate → reserve → charge → finalize) 자동 실행 + 첫 Failure 시 compensation.
 **/
@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

  private final OrderService service;

  public OrderController(OrderService service) {
    this.service = service;
  }

  @PostMapping
  public ResponseEntity<OrderView> place(@Valid @RequestBody OrderRequest req) {
    return ResponseEntity.ok(toView(service.placeOrder(req)));
  }

  @GetMapping("/{id}")
  public ResponseEntity<OrderView> read(@PathVariable Long id) {
    return ResponseEntity.ok(toView(service.find(id)));
  }

  private static OrderView toView(Order o) {
    return new OrderView(
        o.getId(),
        o.getCustomerId(),
        o.getTotalAmount(),
        o.getStatus(),
        o.getWorkflowState(),
        o.getTenantId(),
        o.getCreatedAt());
  }
}
