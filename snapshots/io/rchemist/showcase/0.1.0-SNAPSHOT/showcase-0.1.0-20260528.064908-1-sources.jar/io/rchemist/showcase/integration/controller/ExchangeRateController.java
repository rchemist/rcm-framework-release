/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.integration.controller;

import io.rchemist.showcase.integration.dto.ExchangeRateResponse;
import io.rchemist.showcase.integration.service.ExchangeRateClient;
import java.math.BigDecimal;
import java.math.RoundingMode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-7 — 환율 조회 / 변환 endpoint. {@link ExchangeRateClient} 의 외부 호출 위에
 * 단순 wrapper. WireMock IT 가 외부 호출 영역을 모두 검증.
 **/
@RestController
@RequestMapping("/api/v1/exchange-rate")
public class ExchangeRateController {

  private final ExchangeRateClient client;

  public ExchangeRateController(ExchangeRateClient client) {
    this.client = client;
  }

  /** {@code base} 기준 모든 환율을 외부 API 에서 조회. */
  @GetMapping
  public ExchangeRateResponse latest(@RequestParam(defaultValue = "KRW") String base) {
    return client.fetchRates(base);
  }

  /** {@code amount} 만큼의 {@code base} 를 {@code target} 으로 환산. */
  @GetMapping("/convert")
  public ConversionResult convert(
      @RequestParam String base,
      @RequestParam String target,
      @RequestParam(defaultValue = "1") BigDecimal amount) {
    ExchangeRateResponse rates = client.fetchRates(base);
    BigDecimal rate = rates.rates().get(target);
    if (rate == null) {
      throw new IllegalArgumentException(
          "target currency not in response: " + target + " (available=" + rates.rates().keySet() + ")");
    }
    BigDecimal converted = amount.multiply(rate).setScale(6, RoundingMode.HALF_UP);
    return new ConversionResult(base, target, amount, converted, rate, rates.date());
  }

  /** 변환 결과 — Records first (Decision #5). */
  public record ConversionResult(
      String base, String target, BigDecimal amount, BigDecimal converted, BigDecimal rate, String date) {}
}
