/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.async.service;

import io.rchemist.starter.storage.quota.ScanResult;
import io.rchemist.starter.storage.quota.VirusScanProvider;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-8 — Showcase 시연용 mock {@link VirusScanProvider}. {@code @Component} 등록만으로
 * framework default {@link io.rchemist.starter.storage.quota.NoopVirusScanProvider} 가 자동 양보
 * ({@code @ConditionalOnMissingBean}, Phase 6.8 baseline 정합).
 *
 * <p>동작 — deterministic, 시연용 fake. stream 의 첫 8KB 안에 trigger word ({@code infected} 또는
 * {@code virus} 또는 EICAR signature {@code X5O!P%@AP}) 가 포함되면 {@code MOCK.Test.Virus} 위협 검출.
 * 그 외엔 clean. 운영 환경에서는 ClamAV / Sophos / Microsoft Defender 어댑터로 교체.
 *
 * <p>{@code Asset} entity 의 {@code SCANNING} → {@code QUARANTINED} 전이 시연을 위해 결과가 명확히
 * 결정 가능한 형태 — random 이 아니라 input 기반 deterministic.
 **/
@Component
public class RandomVirusScanProvider implements VirusScanProvider {

  private static final String NAME = "showcase-mock";
  private static final String[] TRIGGERS = {"infected", "virus", "X5O!P%@AP"};
  private static final int PEEK_BYTES = 8192;

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public ScanResult scan(InputStream content) {
    if (content == null) {
      return ScanResult.clean();
    }
    try {
      byte[] peek = content.readNBytes(PEEK_BYTES);
      String text = new String(peek, StandardCharsets.UTF_8);
      for (String trigger : TRIGGERS) {
        if (text.contains(trigger)) {
          return ScanResult.infected("MOCK.Test.Virus." + trigger);
        }
      }
      return ScanResult.clean();
    } catch (IOException e) {
      return ScanResult.infected("MOCK.Test.IoError");
    }
  }
}
