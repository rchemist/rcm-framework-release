/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.entity;

import io.rchemist.starter.asset.entity.Asset;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — Article 의 첨부 파일 link entity (1:N).
 *
 * <p>설계: Article 본문 + 첨부 파일 분리 — 본문은 markdown / HTML, 첨부는 별도 파일 list. WYSIWYG
 * inline 이미지 (본문 안 직접 embed) vs 첨부 (본문 외부 파일 list) 둘 다 동일 Asset entity 사용.
 **/
@Entity
@Table(
    name = "T_ARTICLE_ATTACHMENT",
    comment = "Article 첨부 파일 link — Asset entity 와 1:1 매핑 + sort_order 정렬",
    indexes = {@Index(name = "IDX_ARTICLE_ATTACHMENT_ARTICLE", columnList = "ARTICLE_ID")})
@Getter
@Setter
@NoArgsConstructor
public class ArticleAttachment {

  @Id
  @GeneratedValue
  @Column(name = "ATTACHMENT_ID", nullable = false)
  private Long id;

  // EAGER fetch — Hibernate 7 제약: @SoftDelete entity (Article) 는 LAZY @ManyToOne 비호환.
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ARTICLE_ID", nullable = false, comment = "부모 Article (FK)")
  private Article article;

  // EAGER fetch — Hibernate 7 제약: @SoftDelete entity (Asset) 는 LAZY @ManyToOne 비호환.
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ASSET_ID", nullable = false, comment = "연결된 Asset (FK)")
  private Asset asset;

  @Column(name = "SORT_ORDER", nullable = false, comment = "정렬 순서 (UI 표시 순서)")
  private int sortOrder;

  public static ArticleAttachment of(Article article, Asset asset, int sortOrder) {
    ArticleAttachment a = new ArticleAttachment();
    a.setArticle(article);
    a.setAsset(asset);
    a.setSortOrder(sortOrder);
    return a;
  }
}
