/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.auth.controller;

import io.rchemist.core.context.UserContext;
import io.rchemist.core.error.ServiceException;
import io.rchemist.showcase.auth.dto.TokenResponse;
import io.rchemist.showcase.auth.dto.ChangePasswordRequest;
import io.rchemist.showcase.auth.dto.LoginRequest;
import io.rchemist.showcase.member.entity.Member;
import io.rchemist.showcase.member.service.MemberService;
import io.rchemist.starter.security.mfa.MfaProvider;
import io.rchemist.starter.security.ratelimit.RateLimit;
import io.rchemist.starter.security.tokenstore.RefreshRotator;
import io.rchemist.starter.web.crud.CrudErrorType;
import jakarta.validation.Valid;
import java.util.Base64;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #2 인증 endpoint — JWT issue + refresh rotation (Decision — Phase 5의 5개
 * 영역 활용 — JWT / RefreshRotator / TrustedProxy / RateLimit / TOTP MFA). framework 의
 * {@link RefreshRotator} 와 직접 연결, BCrypt 검증은 {@link MemberService#verifyPassword}.
 *
 * <p>{@code RateLimit} 자동 — framework 의 {@code @RateLimit} annotation 부착 시 5/min 자동.
 * 본 demo 는 활성화 표시용 — production runtime 에서 actual rate limit fence 작동 (Decision —
 * Phase 5 task #6). MFA 단계는 {@code @PostMapping("/mfa/verify")} 가 별도 단계 처리 (TOTP RFC
 * 6238).
 **/
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

  private final MemberService memberService;
  private final RefreshRotator refreshRotator;

  @Autowired(required = false)
  private MfaProvider mfaProvider;

  public AuthController(MemberService memberService, RefreshRotator refreshRotator) {
    this.memberService = memberService;
    this.refreshRotator = refreshRotator;
  }

  @RateLimit(name = "auth-login")
  @PostMapping("/login")
  public ResponseEntity<TokenResponse> login(@Valid @RequestBody LoginRequest request) {
    Member member = memberService.findByLoginId(request.loginId());
    if (!memberService.verifyPassword(member, request.password())) {
      throw new ServiceException(CrudErrorType.NOT_FOUND, "credentials");
    }
    UserContext user =
        new UserContext(String.valueOf(member.getId()), member.getLoginId(), Set.of("USER"));
    var pair = refreshRotator.issueInitialPair(user);
    return ResponseEntity.ok(new TokenResponse(pair.accessToken(), pair.refreshToken()));
  }

  @PostMapping("/refresh")
  public ResponseEntity<TokenResponse> refresh(@RequestBody RefreshRequest request) {
    var pair = refreshRotator.rotate(request.refreshToken());
    return ResponseEntity.ok(new TokenResponse(pair.accessToken(), pair.refreshToken()));
  }

  @PostMapping("/logout")
  public ResponseEntity<Void> logout(@RequestBody RefreshRequest request) {
    refreshRotator.revoke(request.refreshToken());
    return ResponseEntity.noContent().build();
  }

  @PostMapping("/change-password")
  public ResponseEntity<Void> changePassword(
      @Valid @RequestBody ChangePasswordRequest request) {
    memberService.changePassword(
        request.memberId(), request.currentPassword(), request.newPassword());
    return ResponseEntity.noContent().build();
  }

  /** {@code /refresh} + {@code /logout} 공용 body — refreshToken 단일 필드. */
  public record RefreshRequest(String refreshToken) {}

  /**
   * T9-3 (Phase 5 #5) — TOTP MFA enroll. {@link MfaProvider#enroll(String)} 가 secret + base32 +
   * otpauth URI 반환. Authenticator app (Google Authenticator / Authy 등) 이 otpauth URI 로 secret
   * 등록.
   *
   * <p>{@code platform.security.mfa.enabled=true} 시점에서 활성. 본 showcase 는 default false → 본
   * endpoint 가 503 Service Unavailable 반환 (mfaProvider null). production 활성 시 정상 동작.
   */
  @PostMapping("/mfa/setup")
  public ResponseEntity<Map<String, String>> mfaSetup(@RequestBody MfaSetupRequest request) {
    if (mfaProvider == null) {
      return ResponseEntity.status(503).body(Map.of(
          "error", "MFA disabled",
          "hint", "platform.security.mfa.enabled=true 후 재시도"));
    }
    var enrollment = mfaProvider.enroll(request.userId());
    return ResponseEntity.ok(Map.of(
        "secretBase32", enrollment.secretBase32(),
        "otpAuthUri", enrollment.otpAuthUri(),
        "qrCodeData", "otpauth-uri 를 QR 로 인코딩 (consumer 측 zxing / qrcode-generator)"));
  }

  /**
   * T9-3 — TOTP code verify. Authenticator app 의 6-digit code + 등록 시 받은 secretBase32 와 함께
   * verify. 성공 시 MFA verified flag (production = JWT mfa_verified claim 부여).
   */
  @PostMapping("/mfa/verify")
  public ResponseEntity<Map<String, Object>> mfaVerify(@RequestBody MfaVerifyRequest request) {
    if (mfaProvider == null) {
      return ResponseEntity.status(503).body(Map.of(
          "error", "MFA disabled",
          "hint", "platform.security.mfa.enabled=true 후 재시도"));
    }
    byte[] secret = Base64.getDecoder().decode(request.secretBase64());
    boolean ok = mfaProvider.verify(request.userId(), secret, request.code());
    return ResponseEntity.ok(Map.of("verified", ok));
  }

  /** MFA setup body — userId 만 (server 가 생성한 secret 반환). */
  public record MfaSetupRequest(String userId) {}

  /** MFA verify body — userId + Authenticator app 6-digit code + base64 secret. */
  public record MfaVerifyRequest(String userId, String code, String secretBase64) {}
}
