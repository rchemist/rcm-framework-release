/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.dto;

import jakarta.validation.constraints.Size;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article partial update body — null 필드 = 미변경. Service 의 {@code applyForm} 가 null 체크 후
 * 적용. Records baseline (Decision #5 정합).
 **/
public record ArticleUpdateForm(@Size(max = 255) String title, String content, Integer viewCount) {}
