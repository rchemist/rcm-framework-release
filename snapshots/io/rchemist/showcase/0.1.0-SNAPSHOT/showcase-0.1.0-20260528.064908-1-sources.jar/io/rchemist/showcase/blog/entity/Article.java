/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.entity;

import io.rchemist.core.marker.Auditable;
import io.rchemist.core.marker.Cacheable;
import io.rchemist.core.marker.Searchable;
import io.rchemist.core.marker.SoftDelete;
import io.rchemist.core.marker.TenantAlias;
import io.rchemist.starter.jpa.cache.CacheStrategy;
import io.rchemist.starter.jpa.cache.CacheWriteStrategy;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article — Phase 11 도메인 #1 (블로그/게시판). 5 marker 결합 (Searchable + Auditable + SoftDelete +
 * TenantAlias + Cacheable). framework 9 starter 의 핵심 패턴 동시 hit.
 *
 * <p>marker 별 자동 동작:
 * <ul>
 *   <li>{@link Searchable} (Decision #6) — APT 가 {@code Article_Metadata} 자동 생성 → universal
 *       SearchRequest 24 종 condition 매트릭스 + AND/OR 트리 자동</li>
 *   <li>{@link Auditable} — Spring Data {@code @CreatedDate} / {@code @LastModifiedDate} /
 *       {@code @CreatedBy} / {@code @LastModifiedBy} 자동 채움</li>
 *   <li>{@link SoftDelete} — Hibernate 7 native {@code @SoftDelete} baseline (Phase 3 task #3)</li>
 *   <li>{@link TenantAlias} — Hibernate 7 {@code @TenantId} 자동 채움 (X-TENANT 헤더 resolver)</li>
 *   <li>{@link Cacheable} (Decision #4 + Phase 4) — Spring Cache 자동 + 2-tier region (Local + Redis)
 *       + {@code Article_entity_cache} / {@code Article_search_list_cache} 2 region 자동</li>
 * </ul>
 *
 * <p>HTML strip 은 {@link ArticleService} 의 {@code applyForm} 영역에서 simple regex 로 처리
 * (0.1.0 baseline — Contents marker 는 framework 후속 patch 후보).
 *
 * <p>컨벤션 — Decision #20 (naming = prefix 없음, Rcm 영구 거부) + Decision #28 (Lombok 영역 분리:
 * Entity = mutable POJO 라 Lombok 사용, DTO = Records first). 모든 entity 가 동일 정합.
 **/
@Entity
@Table(name = "T_ARTICLE",
    comment = "블로그 / 게시판 article — 5 marker 결합 + Phase 0.1.0 GA Gate T0-7 DbSpec sample")
@EntityListeners(AuditingEntityListener.class)
@CacheStrategy(strategy = CacheWriteStrategy.WRITE_THROUGH, ttl = "PT2H", entityMaxSize = 5000)
@org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")
@Getter
@Setter
@NoArgsConstructor
public class Article
    implements Searchable, Auditable, SoftDelete, TenantAlias, Cacheable {

  @Id
  @GeneratedValue
  @Column(name = "ARTICLE_ID", nullable = false, comment = "Article 식별자 (PK)")
  private Long id;

  @Column(name = "TITLE", length = 200, nullable = false, comment = "기사 제목 (검색 인덱스 영역)")
  private String title;

  @Column(name = "CONTENT", length = 4000, comment = "HTML 본문")
  private String content;

  @Column(name = "CONTENT_TEXT", length = 4000,
      comment = "HTML strip 한 plain text — universal SearchRequest LIKE 영역")
  private String contentText;

  @Column(name = "VIEW_COUNT", nullable = false, comment = "조회수")
  private Integer viewCount;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  private String tenantId;

  @CreatedDate
  private Instant createdAt;

  @LastModifiedDate
  private Instant updatedAt;

  @CreatedBy
  private String createdBy;

  @LastModifiedBy
  private String updatedBy;

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
