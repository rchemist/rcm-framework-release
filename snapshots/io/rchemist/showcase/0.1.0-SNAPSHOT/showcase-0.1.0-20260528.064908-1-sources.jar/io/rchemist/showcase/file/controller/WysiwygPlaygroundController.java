/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.controller;

import io.rchemist.starter.asset.entity.Asset;
import io.rchemist.starter.asset.service.AssetService;
import io.rchemist.starter.asset.service.AssetUploadCommand;
import io.rchemist.starter.asset.service.AssetUploadResult;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T3 (재정의) — WYSIWYG playground. CKEditor / TinyMCE / Quill 등 wire
 * protocol 변환 *Consumer 책임* 패턴 시연.
 *
 * <p>endpoint:
 * <ul>
 *   <li>GET /demo/wysiwyg — 간단 HTML page (사용 사례 안내).</li>
 *   <li>POST /demo/wysiwyg/ckeditor-upload — CKEditor 의 {@code {url}} 형식 응답.</li>
 *   <li>POST /demo/wysiwyg/tinymce-upload — TinyMCE 의 {@code {location}} 형식 응답.</li>
 * </ul>
 *
 * <p>핵심: framework {@link AssetService} 1 회 호출 + Consumer 가 wire protocol 별 응답 변환.
 * framework 가 5종 wire protocol 다 안다고 가정 = over-engineering 영구 거부.
 **/
@RestController
@RequestMapping("/demo/wysiwyg")
public class WysiwygPlaygroundController {

  private static final String DEMO_HTML = """
      <html lang="ko">
      <head><meta charset="utf-8"><title>WYSIWYG Asset Upload Demo</title></head>
      <body>
      <h1>WYSIWYG 이미지 업로드 Demo</h1>
      <p>framework 단일 통합 endpoint <code>POST /api/v1/assets</code> 호출 + Consumer 가
         WYSIWYG wire protocol 별 응답 변환.</p>
      <ul>
        <li><b>CKEditor</b>: <code>POST /demo/wysiwyg/ckeditor-upload</code> → {url}</li>
        <li><b>TinyMCE</b>: <code>POST /demo/wysiwyg/tinymce-upload</code> → {location}</li>
        <li><b>Quill</b>: framework AssetController 직접 호출 → AssetView (Quill 측 직접 사용)</li>
      </ul>
      <h2>예제 — CKEditor</h2>
      <pre><code>// CKEditor config
      ClassicEditor.create(document.querySelector('#editor'), {
        ckfinder: { uploadUrl: '/demo/wysiwyg/ckeditor-upload' }
      });</code></pre>
      </body>
      </html>
      """;

  private final AssetService assetService;

  public WysiwygPlaygroundController(AssetService assetService) {
    this.assetService = assetService;
  }

  /** Static demo page. */
  @GetMapping(produces = MediaType.TEXT_HTML_VALUE)
  public ResponseEntity<String> demoPage() {
    return ResponseEntity.ok(DEMO_HTML);
  }

  /** CKEditor 5 wire protocol — { "url": "..." }. */
  @PostMapping(value = "/ckeditor-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<Map<String, String>> ckeditorUpload(
      @RequestParam("upload") MultipartFile file) throws IOException {
    Asset asset = upload(file).asset();
    String url = "/api/v1/assets/" + asset.getId();  // 실제로는 CDN URL
    return ResponseEntity.ok(Map.of("url", url));
  }

  /** TinyMCE wire protocol — { "location": "..." }. */
  @PostMapping(value = "/tinymce-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<Map<String, String>> tinymceUpload(
      @RequestParam("file") MultipartFile file) throws IOException {
    Asset asset = upload(file).asset();
    return ResponseEntity.ok(Map.of("location", "/api/v1/assets/" + asset.getId()));
  }

  private AssetUploadResult upload(MultipartFile file) throws IOException {
    AssetUploadCommand cmd = new AssetUploadCommand(
        file.getInputStream(),
        file.getContentType(),
        file.getOriginalFilename(),
        file.getSize(),
        "wysiwyg",
        null,
        Map.of("source", "wysiwyg-demo"));
    return assetService.upload(cmd);
  }

  /** Article attachment 시나리오 — 본문과 별개로 첨부 list. */
  @PostMapping(value = "/article-attach", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<List<Long>> attachToArticle(
      @RequestParam("articleId") Long articleId,
      @RequestParam("files") List<MultipartFile> files) throws IOException {
    return ResponseEntity.ok(files.stream()
        .map(f -> {
          try {
            AssetUploadCommand cmd = AssetUploadCommand.owned(
                f.getInputStream(), f.getContentType(), f.getOriginalFilename(),
                f.getSize(), "article", articleId);
            return assetService.upload(cmd).asset().getId();
          } catch (IOException e) {
            throw new RuntimeException(e);
          }
        })
        .toList());
  }
}
