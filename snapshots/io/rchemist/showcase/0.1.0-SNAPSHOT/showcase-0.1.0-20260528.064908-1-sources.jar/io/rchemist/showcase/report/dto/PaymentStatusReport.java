/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.report.dto;

import io.rchemist.showcase.payment.service.type.PaymentStatus;
import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 상태별 매출 집계 row — GROUP BY status / COUNT(id) / SUM(amount).
 *
 * @param status 결제 상태
 * @param count  해당 status row 개수
 * @param total  해당 status amount 합 (KRW)
 **/
public record PaymentStatusReport(PaymentStatus status, Long count, BigDecimal total) {
}
