/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.payment.service;

import io.rchemist.core.error.ServiceException;
import io.rchemist.showcase.payment.entity.Payment;
import io.rchemist.showcase.payment.service.type.PaymentStatus;
import io.rchemist.showcase.payment.dto.PaymentRequest;
import io.rchemist.showcase.payment.repository.PaymentRepository;
import io.rchemist.starter.web.crud.CrudErrorType;
import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Payment service — request → charge → refund 3 단계. Workflow Saga (Decision #2) 의 *charge*
 * step 이 본 service 의 {@link #charge(String, String)} 호출하는 패턴 (rcm-workflow MVP).
 **/
@Service
@Transactional
public class PaymentService {

  private final PaymentRepository repository;

  public PaymentService(PaymentRepository repository) {
    this.repository = repository;
  }

  public Payment request(PaymentRequest req) {
    Payment payment = new Payment();
    payment.setOrderId(req.orderId());
    payment.setAmount(req.amount());
    return repository.save(payment);
  }

  public Payment charge(String paymentId, String pgTransactionId) {
    Payment payment = find(paymentId);
    if (payment.getStatus() != PaymentStatus.REQUESTED) {
      throw new ServiceException(
          CrudErrorType.NOT_FOUND, "payment-not-requested:" + paymentId);
    }
    payment.setStatus(PaymentStatus.CHARGED);
    payment.setPgTransactionId(pgTransactionId);
    return payment;
  }

  public Payment refund(String paymentId) {
    Payment payment = find(paymentId);
    if (payment.getStatus() != PaymentStatus.CHARGED) {
      throw new ServiceException(
          CrudErrorType.NOT_FOUND, "payment-not-charged:" + paymentId);
    }
    payment.setStatus(PaymentStatus.REFUNDED);
    return payment;
  }

  public Payment fail(String paymentId, String reason) {
    Payment payment = find(paymentId);
    payment.setStatus(PaymentStatus.FAILED);
    payment.setPgTransactionId("FAILED:" + reason);
    return payment;
  }

  @Transactional(readOnly = true)
  public Payment find(String paymentId) {
    return repository
        .findById(paymentId)
        .orElseThrow(() -> new ServiceException(CrudErrorType.NOT_FOUND, paymentId));
  }

  @Transactional(readOnly = true)
  public BigDecimal totalChargedAmount(String orderId) {
    return repository.findByOrderId(orderId).stream()
        .filter(p -> p.getStatus() == PaymentStatus.CHARGED)
        .map(Payment::getAmount)
        .reduce(BigDecimal.ZERO, BigDecimal::add);
  }
}
