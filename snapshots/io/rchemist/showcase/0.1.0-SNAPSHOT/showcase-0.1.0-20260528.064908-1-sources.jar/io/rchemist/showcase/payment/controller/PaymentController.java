/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.payment.controller;

import io.rchemist.showcase.payment.dto.PaymentView;
import io.rchemist.showcase.payment.entity.Payment;
import io.rchemist.showcase.payment.dto.PaymentChargeRequest;
import io.rchemist.showcase.payment.dto.PaymentRequest;
import io.rchemist.showcase.payment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #4 결제 endpoint — request / charge / refund / fail 4 단계.
 * Workflow Saga (Decision #2) 와 분리 — 본 endpoint = manual 호출, Workflow = 자동 orchestration.
 **/
@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {

  private final PaymentService service;

  public PaymentController(PaymentService service) {
    this.service = service;
  }

  @PostMapping
  public ResponseEntity<PaymentView> request(@Valid @RequestBody PaymentRequest req) {
    return ResponseEntity.ok(toView(service.request(req)));
  }

  @PostMapping("/{id}/charge")
  public ResponseEntity<PaymentView> charge(
      @PathVariable String id, @Valid @RequestBody PaymentChargeRequest req) {
    return ResponseEntity.ok(toView(service.charge(id, req.pgTransactionId())));
  }

  @PostMapping("/{id}/refund")
  public ResponseEntity<PaymentView> refund(@PathVariable String id) {
    return ResponseEntity.ok(toView(service.refund(id)));
  }

  @PostMapping("/{id}/fail")
  public ResponseEntity<PaymentView> fail(@PathVariable String id, @RequestBody String reason) {
    return ResponseEntity.ok(toView(service.fail(id, reason)));
  }

  private static PaymentView toView(Payment p) {
    return new PaymentView(
        p.getId(),
        p.getOrderId(),
        p.getAmount(),
        p.getStatus(),
        p.getPgTransactionId(),
        p.getTenantId(),
        p.getCreatedAt());
  }
}
