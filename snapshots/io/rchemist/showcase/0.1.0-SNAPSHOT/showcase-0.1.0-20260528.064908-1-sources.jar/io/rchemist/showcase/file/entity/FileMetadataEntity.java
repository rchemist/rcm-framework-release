/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.file.entity;

import io.rchemist.core.marker.Auditable;
import io.rchemist.core.marker.SoftDelete;
import io.rchemist.core.marker.TenantAlias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #5 — File metadata. Storage backend (rcm-starter-storage) 의 *content* 와 분리,
 * DB 가 *metadata* 저장 (key + size + content type + uploader). TenantAlias 가 자동 prefix —
 * tenant 별 격리.
 *
 * <p>Decision #12 (Phase 6.8) — Storage SPI 가 backend 추상화 (local default + S3 / Azure / GCS
 * SPI override). 본 entity 는 *backend agnostic* — 어떤 backend 든 동일.
 **/
@Entity
@Table(name = "T_FILE_METADATA",
    comment = "File metadata — Storage backend agnostic (local / S3 / Azure / GCS, Decision #12)")
@EntityListeners(AuditingEntityListener.class)
@org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")
@Getter
@Setter
@NoArgsConstructor
public class FileMetadataEntity implements Auditable, SoftDelete, TenantAlias {

  @Id
  @GeneratedValue
  @Column(name = "FILE_METADATA_ID")
  private Long id;

  @Column(name = "STORAGE_KEY", nullable = false, unique = true, length = 512)
  private String storageKey;

  @Column(name = "ORIGINAL_NAME", nullable = false, length = 255)
  private String originalName;

  @Column(name = "CONTENT_TYPE", length = 128)
  private String contentType;

  @Column(name = "SIZE_BYTES", nullable = false)
  private long size;

  @Column(name = "CHECKSUM")
  private String checksum;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "TENANT_ID")
  private String tenantId;

  @CreatedDate
  @Column(name = "CREATED_AT")
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY")
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
