/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.index;

import io.rchemist.core.search.index.EntityIndexerRegistry;
import io.rchemist.starter.search.elasticsearch.indexer.ElasticsearchEntityIndexer;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * #B2-9 showcase ES dual-write 시연 — `ArticleElasticsearchIndexer` Bean 등록 + Registry 자동 등록.
 *
 * <p>활성 조건 — {@code platform.search.elasticsearch.enabled=true} (default true) +
 * {@link ElasticsearchOperations} classpath. Showcase 의 application.yml 가 default 활성. CI /
 * dev 환경에 ES 가 없으면 ArticleElasticsearchIndexer Bean 만 못 만들고 다른 영역은 그대로 동작.
 *
 * <p>Indexer 가 EntityIndexerRegistry 에 등록되면 {@link
 * io.rchemist.starter.search.elasticsearch.indexer.SearchIndexOutboxWorker} 가 outbox event
 * 처리 시 lookup. ArticleSearchIndexer 가 outbox.append 하는 시점은 ArticleSavedEvent 시.
 **/
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(ElasticsearchOperations.class)
@ConditionalOnProperty(
    prefix = "platform.search.elasticsearch",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true)
public class ArticleEsIndexerConfig {

  @Bean
  public ElasticsearchEntityIndexer<ArticleEsDocument> articleElasticsearchIndexer(
      ElasticsearchOperations operations) {
    return new ElasticsearchEntityIndexer<>(ArticleEsDocument.class, "showcase-articles", operations);
  }

  /** Registry 자동 등록 — worker / actuator endpoint 가 lookup. */
  @Bean
  public ArticleEsIndexerRegistration articleEsIndexerRegistration(
      ElasticsearchEntityIndexer<ArticleEsDocument> indexer) {
    return new ArticleEsIndexerRegistration(indexer);
  }

  static class ArticleEsIndexerRegistration {

    private final ElasticsearchEntityIndexer<ArticleEsDocument> indexer;

    ArticleEsIndexerRegistration(ElasticsearchEntityIndexer<ArticleEsDocument> indexer) {
      this.indexer = indexer;
    }

    @PostConstruct
    void register() {
      EntityIndexerRegistry.register(ArticleEsDocument.class, indexer);
    }
  }
}
