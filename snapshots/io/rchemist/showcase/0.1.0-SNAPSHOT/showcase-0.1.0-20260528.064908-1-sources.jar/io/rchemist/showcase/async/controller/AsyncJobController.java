/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.async.controller;

import io.rchemist.starter.jpa.async.AsyncJob;
import io.rchemist.starter.jpa.async.AsyncJobStatus;
import io.rchemist.starter.jpa.async.AsyncJobTracker;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-8 — Async job progress polling 통합 endpoint. {@link AsyncJobTracker} 의
 * in-memory store 를 직접 노출 (단일 노드 baseline). 다중 노드 환경 = Consumer 가 자체 Redis-backed
 * Tracker 적용 시 같은 endpoint 가 자동 동작.
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code GET /api/v1/async-jobs} — 모든 job (queuedAt 역순). status filter 옵션.</li>
 *   <li>{@code GET /api/v1/async-jobs/{id}} — 특정 job lookup. 미존재 = 404.</li>
 * </ul>
 *
 * <p>호출 예: bulk import 후 {@code GET /api/v1/bulk/jobs/{id}} 로 받은 jobId 를 {@code
 * /api/v1/async-jobs/{id}} 로도 동일 조회. Asset post-process (T9-8 mock virus scan) job 도 동일.
 **/
@RestController
@RequestMapping("/api/v1/async-jobs")
public class AsyncJobController {

  private final AsyncJobTracker tracker;

  public AsyncJobController(AsyncJobTracker tracker) {
    this.tracker = tracker;
  }

  @GetMapping
  public List<AsyncJob> list(@RequestParam(required = false) AsyncJobStatus status) {
    return status == null ? tracker.all() : tracker.withStatus(status);
  }

  @GetMapping("/{id}")
  public ResponseEntity<AsyncJob> get(@PathVariable String id) {
    return tracker
        .find(id)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.notFound().build());
  }
}
