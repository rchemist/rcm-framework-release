/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.numericext.service.format;

import io.rchemist.core.numeric.money.Money;
import java.util.Locale;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate (charter recovery PROGRESS Phase 3) — Spring native multi-impl 시연.
 *
 * <p><b>3 영역 비교 매트릭스 — Spring native 영역</b>:
 * <ul>
 *   <li>{@link io.rchemist.extension.ExtensionPoint} (Strategy) — 다중 구현 중 사용자 1 strategy 선택,
 *     interface metadata + actuator endpoint 노출 (`numericext.service.extension.PriceCalculator`)</li>
 *   <li>{@link io.rchemist.extension.ExtensionManager} (Chain) — 모든 handler priority 순 chain +
 *     lambda dispatch + ResultHolder + chain control (`blog.service.extension.ArticleServiceExtensionHandler`)</li>
 *   <li><b>Spring native multi-impl</b> — `@Autowired List<X>` + `@Order` 만으로 다중 impl 단순 호출 또는
 *     1 선택. chain control 0 / ResultHolder 0 / framework 자산 0 — Spring 표준 그대로 (본 영역)</li>
 * </ul>
 *
 * <p>본 영역 채택 기준 — chain control 불필요 + ResultHolder 불필요 + impl 별 자체 if/else (e.g. locale
 * matching) + 모든 impl 호출 또는 1 선택. ExtensionPoint / ExtensionManager 의 추상화 가치 없음.
 **/
public interface PriceFormatter {

  /** 본 formatter 가 주어진 locale 영역을 지원하는지. {@code true} 면 {@link #format(Money)} 호출 가능. */
  boolean supports(Locale locale);

  /** Money 를 locale 별 통화 표기로 변환. {@link #supports(Locale)} == true 인 경우만 호출. */
  String format(Money money);
}
