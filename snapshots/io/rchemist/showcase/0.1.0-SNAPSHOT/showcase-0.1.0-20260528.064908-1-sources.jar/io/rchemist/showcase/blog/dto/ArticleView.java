/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.dto;

import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article read response (List + Detail) — Records baseline (Decision #5 정합). Controller 의
 * {@code toReadDTO} 가 entity → view 변환. {@code contentText} = HTML strip 본문 (검색 hit 표시용).
 **/
public record ArticleView(
    Long id,
    String title,
    String content,
    String contentText,
    Integer viewCount,
    String tenantId,
    Instant createdAt,
    Instant updatedAt,
    String createdBy) {}
