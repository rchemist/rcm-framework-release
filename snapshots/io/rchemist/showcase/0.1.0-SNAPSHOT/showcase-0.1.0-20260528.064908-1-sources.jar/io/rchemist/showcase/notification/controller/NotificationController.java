/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.notification.controller;

import io.rchemist.showcase.notification.dto.BroadcastRequest;
import io.rchemist.showcase.notification.dto.PaymentNotifyRequest;
import io.rchemist.showcase.notification.dto.PushTestRequest;
import io.rchemist.showcase.notification.dto.WelcomeRequest;
import io.rchemist.showcase.notification.service.NotificationFacade;
import io.rchemist.starter.notification.core.NotificationResult;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #3 — 4 채널 알림 demo endpoint. framework 의 NotificationDispatcher 가 자동
 * 라우팅 + Outbox + Retry + DLQ + Idempotency-Key 자동 (Decision #11). showcase 는 endpoint
 * 진입 + facade 호출만.
 **/
@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationController {

  private final NotificationFacade facade;

  public NotificationController(NotificationFacade facade) {
    this.facade = facade;
  }

  @PostMapping("/welcome")
  public ResponseEntity<NotificationResult> welcome(@Valid @RequestBody WelcomeRequest request) {
    return ResponseEntity.ok(facade.sendWelcomeEmail(request.email(), request.name()));
  }

  @PostMapping("/payment")
  public ResponseEntity<NotificationResult> payment(
      @Valid @RequestBody PaymentNotifyRequest request) {
    return ResponseEntity.ok(
        facade.sendPaymentAlim(request.phone(), request.paymentId(), request.amount()));
  }

  @PostMapping("/password-changed")
  public ResponseEntity<NotificationResult> passwordChanged(
      @Valid @RequestBody PushTestRequest request) {
    return ResponseEntity.ok(
        facade.sendPasswordChangedPush(request.fcmToken(), request.loginId()));
  }

  @PostMapping("/broadcast")
  public ResponseEntity<NotificationResult> broadcast(
      @Valid @RequestBody BroadcastRequest request) {
    return ResponseEntity.ok(facade.sendSystemBroadcastSms(request.phone(), request.message()));
  }
}
