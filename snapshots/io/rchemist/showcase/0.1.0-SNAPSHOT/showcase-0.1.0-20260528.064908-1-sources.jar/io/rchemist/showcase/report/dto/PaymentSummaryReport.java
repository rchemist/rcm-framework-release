/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.report.dto;

import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * 전체 요약 single-row 집계 — COUNT(id) + COUNT_DISTINCT(orderId) + SUM/AVG/MIN/MAX(amount).
 *
 * @param totalCount     전체 결제 row 개수
 * @param distinctOrders 고유 주문 수 (COUNT_DISTINCT orderId)
 * @param sum            amount 합 (KRW)
 * @param average        amount 평균 (KRW)
 * @param min            amount 최소 (KRW)
 * @param max            amount 최대 (KRW)
 **/
public record PaymentSummaryReport(
    Long totalCount,
    Long distinctOrders,
    BigDecimal sum,
    BigDecimal average,
    BigDecimal min,
    BigDecimal max) {
}
