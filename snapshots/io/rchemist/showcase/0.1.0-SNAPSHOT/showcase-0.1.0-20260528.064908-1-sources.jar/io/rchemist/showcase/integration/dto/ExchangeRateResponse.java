/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.integration.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T9-7 — 외부 환율 API 응답 wire format. Records first (Decision #5).
 *
 * <p>shape (e.g. exchangerate.host):
 * <pre>
 * { "base": "KRW", "rates": { "USD": 0.00073, "JPY": 0.111 }, "date": "2026-05-05" }
 * </pre>
 *
 * <p>외부 API 가 추가 필드 (success / motd 등) 가 있어도 {@code @JsonIgnoreProperties} 로 무시.
 **/
@JsonIgnoreProperties(ignoreUnknown = true)
public record ExchangeRateResponse(String base, Map<String, BigDecimal> rates, String date) {}
