/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.report.service;

import io.rchemist.core.search.Aggregation;
import io.rchemist.core.search.AggregationRequest;
import io.rchemist.core.search.FilterItem;
import io.rchemist.core.search.QueryConditionType;
import io.rchemist.core.search.SearchRequest;
import io.rchemist.showcase.payment.entity.Payment;
import io.rchemist.showcase.payment.service.type.PaymentStatus;
import io.rchemist.showcase.report.dto.PaymentOrderReport;
import io.rchemist.showcase.report.dto.PaymentStatusReport;
import io.rchemist.showcase.report.dto.PaymentSummaryReport;
import io.rchemist.starter.jpa.datasource.MultiEntityManager;
import io.rchemist.starter.jpa.search.AggregateExecutor;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * T9-1 — Payment 데이터 기반 실제 GROUP BY / HAVING / COUNT_DISTINCT / SUM / AVG / MIN / MAX 집계 시연.
 * framework {@link AggregateExecutor} 직접 사용 (in-memory stream filter 영구 거부). Decision #18
 * ({@code MultiEntityManager} SPI + {@code @DataSource} routing) 기반 — 본 0.1.0 baseline 은 단일
 * datasource (T9-2 에서 reporting datasource routing 활성화 예정).
 *
 * <p>3 시연 endpoint:
 * <ol>
 *   <li>{@link #revenueByStatus(String)} — GROUP BY status, COUNT(*) + SUM(amount). 단일 컬럼 GROUP BY
 *   <li>{@link #revenueByOrder(BigDecimal)} — GROUP BY orderId, COUNT + SUM + AVG + HAVING SUM > threshold.
 *       HAVING 절 시연
 *   <li>{@link #summary()} — single row 전체 집계: COUNT + COUNT_DISTINCT(orderId) + SUM + AVG + MIN + MAX
 * </ol>
 **/
@Service
@Transactional(readOnly = true)
public class ReportingService {

  @PersistenceContext
  private EntityManager em;

  @Autowired(required = false)
  private MultiEntityManager multiEntityManager;

  /**
   * 상태별 매출 — GROUP BY status (CHARGED 만 옵션 필터). 결과 row = status / count / total.
   *
   * @param onlyStatus null/blank 면 모든 status, 그렇지 않으면 해당 status 만 필터
   */
  public List<PaymentStatusReport> revenueByStatus(String onlyStatus) {
    SearchRequest baseSearch = (onlyStatus == null || onlyStatus.isBlank())
        ? null
        : SearchRequest.builder().filterEquals("status", onlyStatus).build();

    AggregationRequest req = AggregationRequest.withFilter(
        List.of("status"),
        List.of(Aggregation.count("id"), Aggregation.sum("amount")),
        baseSearch
    );

    List<Map<String, Object>> rows = newExecutor().execute(req);
    return rows.stream()
        .map(r -> new PaymentStatusReport(
            asEnum(r.get("status")),
            asLong(r.get("count_id")),
            asBigDecimal(r.get("sum_amount"))))
        .toList();
  }

  /**
   * 주문별 매출 — GROUP BY orderId, COUNT + SUM + AVG + HAVING SUM(amount) > threshold. CHARGED 만 집계
   * (status=CHARGED filter 자동 결합).
   *
   * @param thresholdAmount HAVING 임계 (이 값 초과인 orderId 만 반환). null 시 0 (= 모든 주문)
   */
  public List<PaymentOrderReport> revenueByOrder(BigDecimal thresholdAmount) {
    BigDecimal threshold = thresholdAmount == null ? BigDecimal.ZERO : thresholdAmount;

    SearchRequest baseSearch = SearchRequest.builder()
        .filterEquals("status", PaymentStatus.CHARGED.name())
        .build();

    AggregationRequest req = new AggregationRequest(
        List.of("orderId"),
        List.of(
            Aggregation.count("id"),
            Aggregation.sum("amount"),
            Aggregation.avg("amount")),
        List.of(FilterItem.of("sum_amount", QueryConditionType.GREATER_THAN, threshold.toPlainString())),
        baseSearch
    );

    List<Map<String, Object>> rows = newExecutor().execute(req);
    return rows.stream()
        .map(r -> new PaymentOrderReport(
            (String) r.get("orderId"),
            asLong(r.get("count_id")),
            asBigDecimal(r.get("sum_amount")),
            asBigDecimal(r.get("avg_amount"))))
        .toList();
  }

  /**
   * 전체 요약 — single row. COUNT(*) + COUNT_DISTINCT(orderId) + SUM(amount) + AVG(amount) + MIN(amount)
   * + MAX(amount). status 무관 모든 Payment row 대상.
   */
  public PaymentSummaryReport summary() {
    AggregationRequest req = AggregationRequest.of(
        List.of(),
        List.of(
            Aggregation.count("id"),
            Aggregation.countDistinct("orderId"),
            Aggregation.sum("amount"),
            Aggregation.avg("amount"),
            Aggregation.min("amount"),
            Aggregation.max("amount"))
    );

    List<Map<String, Object>> rows = newExecutor().execute(req);
    if (rows.isEmpty()) {
      return new PaymentSummaryReport(0L, 0L, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
    }
    Map<String, Object> r = rows.get(0);
    return new PaymentSummaryReport(
        asLong(r.get("count_id")),
        asLong(r.get("count_distinct_orderId")),
        asBigDecimal(r.get("sum_amount")),
        asBigDecimal(r.get("avg_amount")),
        asBigDecimal(r.get("min_amount")),
        asBigDecimal(r.get("max_amount")));
  }

  private AggregateExecutor<Payment> newExecutor() {
    return new AggregateExecutor<>(em, Payment.class);
  }

  /**
   * T9-2 (Decision #18) — cross-DataSource Payment row 집계. {@link MultiEntityManager} 가 등록된
   * 모든 DataSource (main + reporting) 를 순회하여 각 DS 별 Payment count 반환. {@code MultiEntityManager}
   * 미주입 (단일 DS 환경) 시 main 만 단일 entry.
   */
  public Map<String, Long> crossDataSourcePaymentCount() {
    Map<String, Long> result = new LinkedHashMap<>();
    if (multiEntityManager == null) {
      result.put("main", (long) newExecutor()
          .execute(io.rchemist.core.search.AggregationRequest.of(
              List.of(),
              List.of(io.rchemist.core.search.Aggregation.count("id"))))
          .stream()
          .findFirst()
          .map(r -> ((Number) r.get("count_id")).longValue())
          .orElse(0L));
      return result;
    }
    multiEntityManager.forEach(
        (name, emExtensions) -> result.put(name, emExtensions.count(Payment.class)));
    return result;
  }

  private static Long asLong(Object v) {
    if (v == null) {
      return 0L;
    }
    return ((Number) v).longValue();
  }

  private static BigDecimal asBigDecimal(Object v) {
    if (v == null) {
      return BigDecimal.ZERO;
    }
    if (v instanceof BigDecimal bd) {
      return bd;
    }
    return BigDecimal.valueOf(((Number) v).doubleValue()).setScale(2, RoundingMode.HALF_UP);
  }

  private static PaymentStatus asEnum(Object v) {
    if (v == null) {
      return null;
    }
    if (v instanceof PaymentStatus s) {
      return s;
    }
    return PaymentStatus.valueOf(v.toString());
  }
}
