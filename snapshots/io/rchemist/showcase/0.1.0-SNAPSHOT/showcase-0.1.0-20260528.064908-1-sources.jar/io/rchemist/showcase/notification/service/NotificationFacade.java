/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.notification.service;

import io.rchemist.starter.notification.core.NotificationDispatcher;
import io.rchemist.starter.notification.core.NotificationResult;
import io.rchemist.starter.notification.email.EmailContentType;
import io.rchemist.starter.notification.email.EmailNotification;
import io.rchemist.starter.notification.kakao.BizMessageNotification;
import io.rchemist.starter.notification.kakao.BizMessageType;
import io.rchemist.starter.notification.kakao.SmsFallbackPolicy;
import io.rchemist.starter.notification.push.PushNotification;
import io.rchemist.starter.notification.push.PushPlatform;
import io.rchemist.starter.notification.sms.SmsNotification;
import io.rchemist.starter.notification.sms.SmsType;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #3 알림 facade — 4 채널 record 결합 helper. {@link NotificationDispatcher}
 * 직접 호출 + record builder 단순화. framework 의 dispatcher 가 type 기반 라우팅 + outbox + retry +
 * DLQ 자동 (Decision #11).
 *
 * <p>welcome / payment / passwordChanged / broadcast 4 시나리오 제공 — 각각 4 채널 모두 1 hit.
 **/
@Service
public class NotificationFacade {

  private final NotificationDispatcher dispatcher;

  public NotificationFacade(NotificationDispatcher dispatcher) {
    this.dispatcher = dispatcher;
  }

  /** 회원 가입 환영 — Email SMTP. */
  public NotificationResult sendWelcomeEmail(String to, String name) {
    EmailNotification email =
        new EmailNotification(
            List.of(to),
            List.of(),
            List.of(),
            "no-reply@rcm-showcase.local",
            "환영합니다, " + name + "님",
            "<h1>환영합니다</h1><p>회원 가입을 환영합니다, " + name + "님.</p>",
            EmailContentType.HTML,
            List.of());
    return dispatcher.send(email);
  }

  /** 결제 완료 — KakaoTalk AlimTalk + SMS fallback. */
  public NotificationResult sendPaymentAlim(String phone, String paymentId, long amount) {
    BizMessageNotification kakao =
        new BizMessageNotification(
            phone,
            "showcase-sender-key",
            BizMessageType.ALIM_TALK,
            "TPL_PAYMENT_DONE",
            "결제 완료 — 결제번호 #{paymentId}, 금액 #{amount} 원",
            Map.of("paymentId", paymentId, "amount", String.valueOf(amount)),
            List.of(),
            null,
            SmsFallbackPolicy.lms("결제 완료", "결제 완료 — #{paymentId}"));
    return dispatcher.send(kakao);
  }

  /** 비밀번호 변경 — Push (FCM). */
  public NotificationResult sendPasswordChangedPush(String fcmToken, String loginId) {
    PushNotification push =
        new PushNotification(
            "비밀번호 변경",
            loginId + " 계정의 비밀번호가 변경되었습니다.",
            PushPlatform.FCM,
            null,
            List.of(fcmToken),
            Map.of("event", "password-changed"),
            null,
            null);
    return dispatcher.send(push);
  }

  /** 시스템 공지 — SMS broadcast. */
  public NotificationResult sendSystemBroadcastSms(String phone, String message) {
    SmsNotification sms =
        new SmsNotification(phone, "010-0000-0000", message, "시스템 공지", SmsType.LMS);
    return dispatcher.send(sms);
  }
}
