/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.member.dto;

import io.rchemist.showcase.member.entity.Member;
import io.rchemist.starter.security.masking.MaskingUtil;
import java.time.Instant;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Member 조회 응답 — passwordHash / totpSecret 영구 미노출 (보안). T9-10 (2026-05-05) — PII 영역
 * (email / phone / residentRegistrationNumber / businessRegistrationNumber) 응답 시 {@link MaskingUtil}
 * 자동 적용 ({@link #from(Member)} factory). raw 값은 entity 안에만 존재 — 응답 wire format 은 항상 마스킹.
 **/
public record MemberView(
    Long id,
    String loginId,
    String name,
    String email,
    String phone,
    String residentRegistrationNumber,
    String businessRegistrationNumber,
    boolean mfaEnabled,
    String tenantId,
    Instant createdAt) {

  /** entity → masked DTO. PII 영역 5종 자동 마스킹. */
  public static MemberView from(Member member) {
    return new MemberView(
        member.getId(),
        member.getLoginId(),
        MaskingUtil.maskName(member.getName()),
        MaskingUtil.maskEmail(member.getEmail()),
        MaskingUtil.maskPhone(member.getPhone()),
        MaskingUtil.maskRrn(member.getResidentRegistrationNumber()),
        member.getBusinessRegistrationNumber(),
        member.isMfaEnabled(),
        member.getTenantId(),
        member.getCreatedAt());
  }
}
