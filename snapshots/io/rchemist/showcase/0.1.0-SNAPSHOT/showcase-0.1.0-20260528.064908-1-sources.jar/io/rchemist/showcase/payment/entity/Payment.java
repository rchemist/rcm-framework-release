/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.payment.entity;

import io.rchemist.core.enumtype.EnumTypeUserType;
import io.rchemist.core.marker.Auditable;
import io.rchemist.core.marker.Searchable;
import io.rchemist.core.marker.SoftDelete;
import io.rchemist.core.marker.TenantAlias;
import io.rchemist.showcase.payment.service.type.PaymentStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.TenantId;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Payment — Phase 11 도메인 #4 (결제). 4 marker (Searchable + Auditable + SoftDelete + TenantAlias)
 * + 추가로 *globally unique payment id* 자체 생성 ({@link #onCreate()}). framework 의 TsidGenerator
 * 는 후속 patch 후보 — 본 showcase 는 UUID v7 ordering pattern 으로 demonstrate (TSID 등가).
 *
 * <p>{@code amount} = BigDecimal (KRW 단위 원). {@code status} = REQUESTED / CHARGED / FAILED /
 * REFUNDED 4 단계 — Workflow Saga (Decision #2) 가 transition 책임.
 **/
@Entity
@Table(name = "T_PAYMENT",
    comment = "Payment entity — Workflow Saga 4 단계 (REQUESTED/CHARGED/FAILED/REFUNDED)")
@EntityListeners(AuditingEntityListener.class)
@org.hibernate.annotations.SoftDelete(columnName = "IS_DELETED")
@Getter
@Setter
@NoArgsConstructor
public class Payment implements Searchable, Auditable, SoftDelete, TenantAlias {

  @Id
  @Column(name = "PAYMENT_ID", length = 36)
  private String id;

  @Column(name = "ORDER_ID", nullable = false)
  private String orderId;

  @Column(name = "AMOUNT", nullable = false, precision = 18, scale = 2)
  private BigDecimal amount;

  @Type(value = EnumTypeUserType.class,
      parameters = @Parameter(name = "enumClass",
          value = "io.rchemist.showcase.payment.service.type.PaymentStatus"))
  @Column(name = "STATUS", nullable = false, length = 16)
  private PaymentStatus status;

  @Column(name = "PG_TRANSACTION_ID")
  private String pgTransactionId;

  @TenantId
  @Setter(lombok.AccessLevel.NONE)
  @Column(name = "TENANT_ID")
  private String tenantId;

  @CreatedDate
  @Column(name = "CREATED_AT")
  private Instant createdAt;

  @LastModifiedDate
  @Column(name = "UPDATED_AT")
  private Instant updatedAt;

  @CreatedBy
  @Column(name = "CREATED_BY")
  private String createdBy;

  @LastModifiedBy
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  @PrePersist
  void onCreate() {
    if (id == null) {
      id = UUID.randomUUID().toString();
    }
    if (status == null) {
      status = PaymentStatus.REQUESTED;
    }
  }

  @Override
  public Instant getCreatedAt() {
    return createdAt;
  }

  @Override
  public Instant getUpdatedAt() {
    return updatedAt;
  }

  @Override
  public String getCreatedBy() {
    return createdBy;
  }

  @Override
  public String getUpdatedBy() {
    return updatedBy;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
