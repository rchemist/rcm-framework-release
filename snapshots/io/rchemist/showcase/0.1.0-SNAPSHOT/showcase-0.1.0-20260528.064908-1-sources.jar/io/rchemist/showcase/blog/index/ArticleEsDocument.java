/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.index;

import io.rchemist.core.marker.Indexable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article 의 ES denormalized 문서 — DB {@link ArticleSearchIndex} 와 *짝* (DB fallback + ES primary
 * 패턴, Decision #8 + 메모리 `feedback_no_feature_regression` 정합).
 *
 * <p>{@link Indexable} marker = 외부 검색엔진 색인 대상 표식. {@code platform.search.elasticsearch.
 * enabled=true} 일 때 {@code ArticleElasticsearchIndexer} 가 색인. 비활성 시 (showcase default
 * baseline) DB index 만으로도 LIKE/EQ 검색은 자연 유지.
 *
 * <p>fields:
 * <ul>
 *   <li>{@code id} = Article PK (String 변환 — ES `_id` 표준)</li>
 *   <li>{@code title} = Article 제목 (Text — analyzer = consumer 가 yml override 시 korean)</li>
 *   <li>{@code contentText} = HTML strip 된 본문 텍스트 (Text)</li>
 *   <li>{@code viewCount} = 조회수 (Integer — sort/range)</li>
 *   <li>{@code tenantId} = multi-tenant 분리 (Keyword — exact match)</li>
 * </ul>
 **/
@Document(indexName = "showcase-articles")
@Getter
@Setter
@NoArgsConstructor
public class ArticleEsDocument implements Indexable {

  @Id private String id;

  @Field(type = FieldType.Text)
  private String title;

  @Field(type = FieldType.Text)
  private String contentText;

  @Field(type = FieldType.Integer)
  private Integer viewCount;

  @Field(type = FieldType.Keyword)
  private String tenantId;

  public ArticleEsDocument(String id, String title, String contentText, Integer viewCount, String tenantId) {
    this.id = id;
    this.title = title;
    this.contentText = contentText;
    this.viewCount = viewCount;
    this.tenantId = tenantId;
  }
}
