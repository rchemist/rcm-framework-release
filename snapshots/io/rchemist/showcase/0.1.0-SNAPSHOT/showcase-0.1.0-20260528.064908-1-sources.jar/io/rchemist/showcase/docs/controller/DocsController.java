/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.docs.controller;

import io.rchemist.starter.document.asciidoctor.DocumentRenderer;
import io.rchemist.starter.document.core.AsciidocFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 11 도메인 #6 — 문서 출력. framework rcm-starter-document (Decision #14) 의
 * {@link DocumentRenderer} JVM 직접 호출 — PDF / HTML / DocBook 3 format. 한국어 theme
 * (NotoSansKR + NanumGothic + D2Coding 폰트 embed) 가 framework default.
 *
 * <p>본 demo = 단순 매뉴얼 (asciidoc 본문 hard-coded) → 3 format 변환. production 사용은
 * 별도 .adoc 파일 + AsciidocTheme 어노테이션 + RestEndpoint 자동 매핑 (5 어노테이션).
 **/
@RestController
@RequestMapping("/api/v1/docs")
public class DocsController {

  private static final String SAMPLE_ADOC =
      """
      = RCM Showcase 매뉴얼
      :icons: font

      == 소개
      RCM framework 0.1.0 의 모든 기능을 1 hit 하는 reference 사이트.

      == 핵심 결정
      - Decision #1 — ProblemDetail 단독 (RFC 7807)
      - Decision #5 — DTO Records first (immutable)
      - Decision #7 — AbstractCrudService / AbstractCrudController 흡수
      - Decision #14 — AsciiDoctor + 한국어 theme

      == 도메인 목록
      1. 블로그 / 게시판 (5 marker)
      2. 회원 / 인증 (JWT + MFA + @ResidentRegistrationNumber)
      3. 알림 (4 채널)
      4. 결제 / 통계
      5. 파일 업로드 / 다운로드
      6. 문서 출력 (본 영역)
      """;

  private final DocumentRenderer renderer;

  public DocsController(DocumentRenderer renderer) {
    this.renderer = renderer;
  }

  @GetMapping(value = "/manual.pdf", produces = MediaType.APPLICATION_PDF_VALUE)
  public ResponseEntity<byte[]> manualPdf() {
    return ResponseEntity.ok(renderer.render(SAMPLE_ADOC, AsciidocFormat.PDF));
  }

  @GetMapping(value = "/manual.html", produces = MediaType.TEXT_HTML_VALUE)
  public ResponseEntity<byte[]> manualHtml() {
    return ResponseEntity.ok(renderer.render(SAMPLE_ADOC, AsciidocFormat.HTML));
  }

  @GetMapping(value = "/manual.xml", produces = MediaType.APPLICATION_XML_VALUE)
  public ResponseEntity<byte[]> manualDocbook() {
    return ResponseEntity.ok(renderer.render(SAMPLE_ADOC, AsciidocFormat.DOCBOOK));
  }
}
