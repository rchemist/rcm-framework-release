/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.service;

import io.rchemist.core.context.TenantContext;
import io.rchemist.showcase.tenantstrategy.entity.TenantPolicyEntity;
import io.rchemist.showcase.tenantstrategy.repository.TenantPolicyRepository;
import java.util.Optional;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #56 — singleton seed row 패턴 시연 service. {@code __system__} tenant 에 적재된 default
 * policy 를 모든 tenant 가 공유하는 사용 path 시연. Consumer 가 따라할 만한 3 메서드 제공:
 *
 * <ul>
 *   <li>{@link #findGlobalDefault(String)} — 어느 tenant context 에서든 system seed 조회 (callAsSystem wrap)</li>
 *   <li>{@link #updateGlobalDefault(String, String)} — system seed 갱신 (runAsSystem wrap)</li>
 *   <li>{@link #resolve(String)} — current tenant override 우선 + 부재 시 system seed fallback 패턴</li>
 * </ul>
 *
 * <p>이 패턴은 `documents/24-consumer-migration-guide.md` §4.3 의 정합 코드 시연이며, 실제 LMS
 * policy entity (`RecommendationPolicy`, `AutoGradingPolicy`) 가 따라야 할 사용 path 와 일치.
 *
 * <p><b>중요 — service 메서드에 {@code @Transactional} 을 두지 말 것</b>. Hibernate 7
 * multi-tenancy 는 *session 생성 시점* (= tx 시작 시점) 에 {@code resolveCurrentTenantIdentifier()}
 * 를 호출해서 그 tenant 로 session 을 pin 한다. 따라서 메서드에 {@code @Transactional} 이 붙어
 *있으면 내부의 {@code TenantContext.runAs(...)} / {@code callAsSystem(...)} 호출이 *이미 열린
 * session 의 tenant 를 바꿀 수 없다*. 정합 패턴 = 서비스가 tenant 컨텍스트만 책임지고 각
 * repository 호출이 자기 tx (Spring Data JPA 의 default {@code @Transactional}) 안에서 매번 fresh
 * tenant 를 resolve 하도록 함.
 **/
@Service
public class TenantPolicyService {

  private final TenantPolicyRepository repository;

  public TenantPolicyService(TenantPolicyRepository repository) {
    this.repository = repository;
  }

  /**
   * 어느 tenant context 에서든 system seed 조회. caller 가 현재 다른 tenant 에 binding 되어 있어도
   * {@link TenantContext#callAsSystem} wrap 으로 {@code __system__} binding 강제 → Hibernate 자동
   * 필터가 system seed row 를 조회.
   */
  public Optional<TenantPolicyEntity> findGlobalDefault(String policyKey) {
    return TenantContext.callAsSystem(() -> repository.findByPolicyKey(policyKey));
  }

  /**
   * System seed 갱신. {@link TenantContext#runAsSystem} wrap 안에서 호출하여 Hibernate 자동 필터가
   * {@code __system__} row 만 hit + INSERT 시 자동 {@code tenant_id = '__system__'} 채움.
   */
  public TenantPolicyEntity updateGlobalDefault(String policyKey, String newValue) {
    return TenantContext.callAsSystem(() -> {
      TenantPolicyEntity seed = repository.findByPolicyKey(policyKey)
          .orElseThrow(() -> new IllegalStateException(
              "System seed not found for policyKey=" + policyKey));
      seed.setPolicyValue(newValue);
      return repository.save(seed);
    });
  }

  /**
   * Current tenant override 우선 + 부재 시 system seed fallback. Tenant 별 override row 가 있으면
   * 그것을, 없으면 system seed 를 반환. 실제 consumer 의 policy resolve 패턴.
   */
  public TenantPolicyEntity resolve(String tenantId, String policyKey) {
    Optional<TenantPolicyEntity> override = TenantContext.runAs(tenantId,
        () -> repository.findByPolicyKey(policyKey));
    return override.orElseGet(() ->
        TenantContext.callAsSystem(() -> repository.findByPolicyKey(policyKey)
            .orElseThrow(() -> new IllegalStateException(
                "Neither tenant override nor system seed found for policyKey=" + policyKey))));
  }
}
