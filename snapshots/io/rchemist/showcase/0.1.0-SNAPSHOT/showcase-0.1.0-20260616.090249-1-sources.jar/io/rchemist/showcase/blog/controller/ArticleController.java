/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.blog.controller;

import io.rchemist.showcase.blog.dto.ArticleView;
import io.rchemist.showcase.blog.entity.Article;
import io.rchemist.showcase.blog.dto.ArticleCreateForm;
import io.rchemist.showcase.blog.dto.ArticleUpdateForm;
import io.rchemist.starter.web.crud.AbstractCrudController;
import io.rchemist.starter.web.crud.CrudService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Article REST controller — Decision #7 의 얇은 base. {@link AbstractCrudController} extends +
 * 추상 메소드 1 개 ({@code toReadDTO}) + helper override ({@code extractId}). 5 표준 endpoint
 * (POST / GET list / GET {id} / PUT {id} / DELETE {id}) + GET /_search/schema discovery 자동.
 *
 * <p>OpenAPI 자동 — {@code rcm-starter-web} 의 springdoc-openapi 통합으로 {@code /swagger-ui.html}
 * 자동 노출 (Decision #15 정합).
 **/
@RestController
@RequestMapping("/api/v1/articles")
public class ArticleController
    extends AbstractCrudController<Article, Long, ArticleCreateForm, ArticleUpdateForm, ArticleView> {

  public ArticleController(
      CrudService<Article, Long, ArticleCreateForm, ArticleUpdateForm> service) {
    super(service);
  }

  @Override
  protected ArticleView toReadDTO(Article entity) {
    return new ArticleView(
        entity.getId(),
        entity.getTitle(),
        entity.getContent(),
        entity.getContentText(),
        entity.getViewCount(),
        entity.getTenantId(),
        entity.getCreatedAt(),
        entity.getUpdatedAt(),
        entity.getCreatedBy());
  }

  @Override
  protected Long extractId(Article entity) {
    return entity.getId();
  }
}
