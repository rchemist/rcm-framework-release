/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.repository;

import io.rchemist.showcase.tenantstrategy.entity.TenantPolicyEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #56 — {@link TenantPolicyEntity} Spring Data JPA repository. Hibernate 7 {@code @TenantId}
 * 가 자동으로 모든 query 에 {@code WHERE tenant_id = :resolvedTenantId} 추가하므로 명시 tenant 필터
 * 불요. seed 조회 (`findByPolicyKey`) 는 caller 가 {@code TenantContext.callAsSystem(...)} 안에서
 * 호출해야 함 — 자세한 사용 패턴은 `documents/24-consumer-migration-guide.md` §4.3 참고.
 **/
public interface TenantPolicyRepository extends JpaRepository<TenantPolicyEntity, Long> {

  Optional<TenantPolicyEntity> findByPolicyKey(String policyKey);
}
