/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tsiddemo.controller;

import io.rchemist.showcase.tsiddemo.entity.TsidDemoEntity;
import io.rchemist.showcase.tsiddemo.repository.TsidDemoRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #28/#62 — TSID Long PK + Jackson JSON String 자동 직렬화 시연 controller.
 *
 * <p>{@code TsidJacksonModule} 은 *{@link io.rchemist.starter.jpa.id.TsidGenerator} 부착 Long 필드* 에만
 * {@code Long → String} 직렬화를 적용한다. 따라서 본 데모는 그 어노테이션을 보유한 {@link TsidDemoEntity}
 * 를 직접 응답으로 노출하여 module 의 end-to-end 효과(JSON {@code "id"} = quoted string)를 시연한다.
 * (plain {@code Long} 만 가진 DTO/Record 는 변환 대상이 아님 — 어노테이션이 키.)
 *
 * <p>endpoint:
 * <ul>
 *   <li>{@code POST /api/v1/tsid-demo} body {@code {"label": "..."}} → entity 등록 +
 *       응답의 {@code "id"} 가 JSON String (TsidJacksonModule 효과)</li>
 *   <li>{@code GET /api/v1/tsid-demo/{id}} → 단건 조회. {@code id} path variable 은 string-form Long
 *       (Spring MVC 의 {@code Long} converter 가 자동 parse)</li>
 * </ul>
 **/
@RestController
@RequestMapping("/api/v1/tsid-demo")
public class TsidDemoController {

  private final TsidDemoRepository repository;

  public TsidDemoController(TsidDemoRepository repository) {
    this.repository = repository;
  }

  @PostMapping
  public ResponseEntity<TsidDemoEntity> create(@Valid @RequestBody CreateRequest request) {
    TsidDemoEntity saved = repository.save(new TsidDemoEntity(request.label()));
    return ResponseEntity.ok(saved);
  }

  @GetMapping("/{id}")
  public ResponseEntity<TsidDemoEntity> findOne(@PathVariable Long id) {
    return repository.findById(id)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.notFound().build());
  }

  /** DTO — Records first (Decision #5). */
  public record CreateRequest(@NotBlank String label) {}
}
