/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.showcase.tenantstrategy.entity;

import io.rchemist.core.context.TenantContext;
import io.rchemist.core.marker.TenantAlias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TenantId;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Issue #56 — singleton seed row 패턴 시연용 entity. {@link TenantAlias} marker + Hibernate 7
 * {@code @TenantId} 결합. {@code T_TENANT_POLICY_DEMO} 에 {@code tenant_id = '__system__'} 단일
 * seed row 가 적재되며 ({@link TenantContext#SYSTEM_TENANT_ID}), 모든 tenant 가 공유하는 전역
 * default policy 시연.
 *
 * <p>핵심 차이 — {@code TenantDemoEntity} 는 tenant 별 row 격리 시연용, 본 entity 는 *모든 tenant
 * 가 같은 row 를 공유* 하는 system seed 시연용. 두 IT (`MultiTenantDatabaseStrategyIT` ↔
 * `TenantPolicySystemSeedIT`) 가 같은 framework 의 다른 사용 path 를 보여줌.
 **/
@Entity
@Table(name = "T_TENANT_POLICY_DEMO",
    comment = "Singleton seed row 패턴 시연 — 모든 tenant 공유 default policy (__system__ tenant 적재)")
@Getter
@Setter
@NoArgsConstructor
public class TenantPolicyEntity implements TenantAlias {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "TENANT_POLICY_ID", nullable = false, comment = "PK")
  private Long id;

  @Column(name = "POLICY_KEY", length = 100, nullable = false,
      comment = "Policy 식별 키 (예: recommendation.max-count)")
  private String policyKey;

  @Column(name = "POLICY_VALUE", length = 500, nullable = false, comment = "Policy 값 (문자열 직렬화)")
  private String policyValue;

  @TenantId
  @Column(name = "TENANT_ID", length = 64, nullable = false,
      comment = "Tenant 식별자 — singleton seed = __system__ (TenantContext.SYSTEM_TENANT_ID)")
  @Setter(lombok.AccessLevel.NONE)
  private String tenantId;

  public TenantPolicyEntity(String policyKey, String policyValue) {
    this.policyKey = policyKey;
    this.policyValue = policyValue;
  }

  @Override
  public String getTenantId() {
    return tenantId;
  }
}
