-- Phase 11 task #5 — Payment + Reporting schema (Decision #26).
-- 4 marker (Searchable + Auditable + SoftDelete + TenantAlias) + TsidGenerator 13 char TSID ID.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = PAYMENT_ID + boolean = IS_*.

CREATE TABLE T_PAYMENT
(
    PAYMENT_ID         VARCHAR(13) PRIMARY KEY,
    ORDER_ID           VARCHAR(64)    NOT NULL,
    AMOUNT             NUMERIC(18, 2) NOT NULL,
    STATUS             VARCHAR(16)    NOT NULL,
    PG_TRANSACTION_ID  VARCHAR(128),
    TENANT_ID          VARCHAR(64)    NOT NULL,
    IS_DELETED         BOOLEAN        NOT NULL DEFAULT FALSE,
    CREATED_AT         TIMESTAMP WITH TIME ZONE,
    UPDATED_AT         TIMESTAMP WITH TIME ZONE,
    CREATED_BY         VARCHAR(128),
    UPDATED_BY         VARCHAR(128)
);

CREATE INDEX IDX_PAYMENT_TENANT_ORDER ON T_PAYMENT (TENANT_ID, ORDER_ID);
CREATE INDEX IDX_PAYMENT_STATUS_CREATED ON T_PAYMENT (STATUS, CREATED_AT DESC);
