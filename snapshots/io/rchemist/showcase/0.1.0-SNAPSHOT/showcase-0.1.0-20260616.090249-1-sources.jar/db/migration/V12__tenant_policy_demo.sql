-- Issue #56 — singleton seed row 패턴 시연 (TenantPolicyEntity).
-- TENANT_ID = '__system__' (TenantContext.SYSTEM_TENANT_ID 정합) 로 적재 → 모든 tenant 가 공유하는
-- default policy 시연. NULL 적재 금지 — Hibernate 7 @TenantId 자동 필터의 resolvedTenantId 는
-- 항상 비-null 이라 NULL row 는 영원히 SELECT 매칭 X.
-- Column 컨벤션 (misc/readme.md §2.1.1.6): UPPER_SNAKE + PK = TENANT_POLICY_ID.
CREATE TABLE T_TENANT_POLICY_DEMO (
  TENANT_POLICY_ID  BIGSERIAL    NOT NULL PRIMARY KEY,
  POLICY_KEY        VARCHAR(100) NOT NULL,
  POLICY_VALUE      VARCHAR(500) NOT NULL,
  TENANT_ID         VARCHAR(64)  NOT NULL
);

CREATE UNIQUE INDEX IDX_TENANT_POLICY_DEMO_TENANT_KEY ON T_TENANT_POLICY_DEMO (TENANT_ID, POLICY_KEY);

COMMENT ON TABLE  T_TENANT_POLICY_DEMO                   IS 'Singleton seed row 패턴 시연 (issue #56)';
COMMENT ON COLUMN T_TENANT_POLICY_DEMO.TENANT_POLICY_ID  IS 'PK';
COMMENT ON COLUMN T_TENANT_POLICY_DEMO.POLICY_KEY        IS 'Policy 식별 키 (예: recommendation.max-count)';
COMMENT ON COLUMN T_TENANT_POLICY_DEMO.POLICY_VALUE      IS 'Policy 값 (문자열 직렬화)';
COMMENT ON COLUMN T_TENANT_POLICY_DEMO.TENANT_ID         IS 'Tenant 식별자 — singleton seed = ''__system__'' (TenantContext.SYSTEM_TENANT_ID)';

-- System seed row 적재 (전역 default policy)
INSERT INTO T_TENANT_POLICY_DEMO (POLICY_KEY, POLICY_VALUE, TENANT_ID) VALUES
  ('recommendation.max-count', '10', '__system__'),
  ('auto-grading.strictness',  'NORMAL', '__system__');
