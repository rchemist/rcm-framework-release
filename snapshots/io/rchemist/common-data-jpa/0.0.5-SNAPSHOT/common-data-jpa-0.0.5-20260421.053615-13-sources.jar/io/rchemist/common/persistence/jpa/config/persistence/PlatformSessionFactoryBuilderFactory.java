/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.persistence;

import io.rchemist.common.persistence.config.persistence.EntityBeanContext;
import io.rchemist.common.persistence.domain.annotation.RegisterEntityBean;
import io.rchemist.common.persistence.jpa.EntityManagerSetting;
import io.rchemist.common.persistence.jpa.config.mapping.MappingProvider;
import io.rchemist.common.persistence.jpa.config.persistence.type.PersistentInfo;
import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.EvictCacheDTO;
import io.rchemist.common.transformer.dto.RegisterEntityBeanDTO;
import io.rchemist.common.util.BytecodeUtil;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.ClassFile;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.internal.MetadataImpl;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.relational.Namespace;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.boot.spi.SessionFactoryBuilderFactory;
import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
import org.hibernate.mapping.MappedSuperclass;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.Table;
import org.hibernate.type.Type;
import org.springframework.lang.NonNull;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 *
 * <p>
 * 1. Hibernate SPI 를 이용해 metadata 의 모든 데이터를 retrieve 할 수 있다
 * 2. SessionFactory 를 생성할 때, CustomType 으로 설정된 Field 에 지정된 @Type 을 자동으로 추가한다
 *
 * <p>
 * 이 서비스를 사용하려면 META-INF/services/org.hibernate.boot.spi.SessionFactoryBuilderFactory 로 등록해야 한다
 * <p>
 * Created by kunner
 */
@Slf4j
public class PlatformSessionFactoryBuilderFactory implements SessionFactoryBuilderFactory {

  private static final List<MetadataImplementor> METADATA = new ArrayList<>();

  private static final Map<String, PersistentInfo> metadataMap = new ConcurrentHashMap<>();

  /**
   * 0.0.10.I Round 3 (BUG-032): {@code SessionFactoryBuilderFactory#getSessionFactoryBuilder} 콜백
   * 시점에 metadata.getDatabase().getDialect() 로부터 꺼내 캐시하는 dialect 클래스 FQN.
   * {@code QueryParser#buildJoinPath} 의 JSON 분기가 dialect 별 함수명을 고를 때 참조한다.
   * SessionFactoryBuilderFactory 는 Hibernate 부트스트랩 한 번만 실행되므로 volatile 로 충분.
   */
  private static volatile String cachedDialectClassName;

  /**
   * Hibernate의 ManagedEntityClass 를 반환한다.
   * PersistenceClass 에는 Hibernate mapping 정보가 모두 들어 있다.
   *
   * @param entityClass
   * @return
   */
  @Nullable
  public static PersistentInfo getMapping(String entityClass) {
    return metadataMap.get(entityClass);
  }

  /**
   * PersistentInfo 에서 PersistentClass 를 반환한다.
   *
   * @param entityClassName
   * @return
   */
  public static PersistentClass getPersistentClass(String entityClassName) {
    PersistentInfo info = getMapping(entityClassName);
    if (info == null) return null;
    return info.getPersistentClass();
  }

  /**
   * String className 으로 매핑된 엔티티 클래스 반환
   *
   * @param entityClassName
   * @return
   */
  public static Class<?> getMappedClass(String entityClassName) {
    PersistentClass persistentClass = getPersistentClass(entityClassName);
    return (persistentClass == null) ? null : persistentClass.getMappedClass();
  }

  /**
   * 모든 PersistentClass 정보를 반환한다.
   *
   * @return
   */
  @NonNull
  public static Collection<PersistentInfo> getAllMappings() {
    return metadataMap.values();
  }

  @Override
  public SessionFactoryBuilder getSessionFactoryBuilder(MetadataImplementor metadata, SessionFactoryBuilderImplementor defaultBuilder) {
    Collection<PersistentClass> classes = metadata.getEntityBindings();

    classes.forEach((clazz) -> {
      if (clazz != null && clazz.getClassName() != null) {

        transformPersistentClass(metadata, defaultBuilder, clazz);

        PersistentInfo info = new PersistentInfo(clazz);
        metadataMap.put(clazz.getClassName(), info);

        try {
          registerEntityBean(clazz.getTable().getName(), clazz.getClassName());
        } catch (NotFoundException e) {
          e.printStackTrace();
        }

      }
    });

    removeRedundantEntities(metadata);

    PlatformSessionFactoryBuilderFactory.METADATA.add(metadata);

    // 0.0.10.I Round 3 (BUG-032): JSON dispatch 가 참조할 dialect 를 캐시한다.
    //   metadata.getDatabase().getDialect() 는 Hibernate 부트스트랩 시점에만 접근 가능.
    //   여기가 가장 자연스러운 저장 지점이다.
    try {
      org.hibernate.dialect.Dialect dialect = metadata.getDatabase().getDialect();
      if (dialect != null) {
        cachedDialectClassName = dialect.getClass().getName();
      }
    } catch (Throwable t) {
      log.debug("Dialect 캐시 실패 — JSON dispatch 는 UNSUPPORTED 로 fallback: {}", t.getMessage());
    }

    return defaultBuilder;
  }

  /**
   * 쓸모없는 엔티티 클래스를 제거한다
   *
   * @param metadata
   * @return
   */
  public MetadataImplementor removeRedundantEntities(MetadataImplementor metadata) {

    Class<?> metadataClass = metadata.getClass();

    if (((MetadataImpl) metadata).getEntityBindingMap() != null && !((MetadataImpl) metadata).getEntityBindingMap().entrySet().isEmpty()) {
      Map<String, PersistentClass> entityBindingMap = ((MetadataImpl) metadata).getEntityBindingMap().entrySet().stream()
          .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
      this.setFieldValue(metadata, metadataClass, "entityBindingMap", entityBindingMap);
    }

    if (((MetadataImpl) metadata).getMappedSuperclassMap() != null && !((MetadataImpl) metadata).getMappedSuperclassMap().entrySet().isEmpty()) {
      Map<Class, MappedSuperclass> mappedSuperclassMap = ((MetadataImpl) metadata).getMappedSuperclassMap().entrySet().stream()
          .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
      this.setFieldValue(metadata, metadataClass, "mappedSuperclassMap", mappedSuperclassMap);
    }

    if (((MetadataImpl) metadata).getCollectionBindingMap() != null && !((MetadataImpl) metadata).getCollectionBindingMap().entrySet().isEmpty()) {
      Map<String, org.hibernate.mapping.Collection> collectionBindingMap = ((MetadataImpl) metadata).getCollectionBindingMap().entrySet().stream()
          .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
      this.setFieldValue(metadata, metadataClass, "collectionBindingMap", collectionBindingMap);
    }

    for (Namespace namespace : metadata.getDatabase().getNamespaces()) {
      Map<Identifier, Table> newTables = namespace.getTables().stream()
        .collect(Collectors.toMap(e -> Identifier.toIdentifier(e.getName()), e -> e));

      Class<?> namespaceClass = namespace.getClass();
      try {
        Field tables = namespaceClass.getDeclaredField("tables");
        tables.setAccessible(true);
        tables.set(namespace, newTables);
      } catch (NoSuchFieldException | IllegalAccessException e) {
        e.printStackTrace();
      }
    }

    return metadata;
  }

  protected void setFieldValue(Object parentObject, Class<?> clazz, String fieldName, Object newValue) {
    Field field;
    if (clazz == null) {
      clazz = parentObject.getClass();
    }

    try {
      field = clazz.getDeclaredField(fieldName);
      if (field != null) {
        field.setAccessible(true);
        field.set(parentObject, newValue);
      }
    } catch (NoSuchFieldException | IllegalAccessException e) {
      e.printStackTrace();
    }
  }

  /**
   * 등록된 mappingProvider 를 실행한다
   *
   * @param persistentClass
   */
  private void transformPersistentClass(MetadataImplementor metadata, SessionFactoryBuilderImplementor defaultBuilder, PersistentClass persistentClass) {
    if (CollectionUtils.isNotEmpty(EntityManagerSetting.STATIC_MAPPING_PROVIDERS)) {
      for (MappingProvider mappingProvider : EntityManagerSetting.STATIC_MAPPING_PROVIDERS) {
        mappingProvider.transformPersistentClass(metadata, defaultBuilder, persistentClass);
      }
    }
  }

  public static List<MetadataImplementor> getMetadata() {
    return METADATA;
  }

  public static Map<String, PersistentInfo> getMetadataMap() {
    return metadataMap;
  }

  public static Map<String, EntityBean<?>> getRegisterEntityBeanMap() {
    return EntityBeanContext.getRegisteredEntityBeans();
  }

  public static boolean isJoinedProperty(String className, String propertyName){
    if(!metadataMap.containsKey(className))
      return false;

    return metadataMap.get(className).getJoinProperties().containsKey(propertyName);
  }

  /**
   * 0.0.10.I Round 2 (BUG-032): {@code @Type(JsonType.class)} 등 hypersistence-utils JSON UserType
   * 으로 선언된 property 인지 판정한다. {@code QueryParser#buildJoinPath} 가 dot-notation 의 첫
   * segment 를 association join 으로 분해할지, JSON path 표현식으로 빌드할지 결정하는 근거.
   *
   * @param className entity class FQN
   * @param propertyName 첫 segment (예: "metadata")
   * @return metadata 가 JSON 컬럼으로 등록된 경우 true
   */
  public static boolean isJsonProperty(String className, String propertyName) {
    if (!metadataMap.containsKey(className)) {
      return false;
    }
    return metadataMap.get(className).getJsonProperties().contains(propertyName);
  }

  /**
   * 0.0.10.I Round 3 (BUG-032): {@link #getSessionFactoryBuilder} 호출 시 캐시된 Hibernate dialect
   * 의 클래스 FQN 을 반환한다. {@code null} 이거나 부트스트랩 전 시점이면 {@code null}.
   */
  public static String getCachedDialectClassName() {
    return cachedDialectClassName;
  }

  public static PersistentInfo getPersistentInfo(String className){
    return metadataMap.get(className);
  }


  public static EntityBean<?> getRegisterEntityBean(String className) {
    if (!EntityBeanContext.isRegisteredEntityBean(className)) {
      className = getCeilingEntityClassName(className);
    }
    return EntityBeanContext.getRegisterEntityBean(className);
  }

  private void registerEntityBean(String tableName, String className) throws NotFoundException {

    ClassPool classPool = ClassPool.getDefault();
    CtClass clazz = classPool.getCtClass(className);

    boolean isFrozen = clazz.isFrozen();

    try {
      if (isFrozen) {
        clazz.defrost();
      }

      ClassFile classFile = clazz.getClassFile();

      /**
       * Abstract entity class 는 bean 으로 등록할 수 없다
       */
      if(!classFile.isAbstract()){
        Class<?> mappingClass = BytecodeUtil.getClassByName(classFile.getName());

        Annotation register = BytecodeUtil.getDeclaredAnnotationOnType(classFile, RegisterEntityBean.class.getName());
        RegisterEntityBeanDTO bean = new RegisterEntityBeanDTO();
        bean.setEntityClass(tableName, mappingClass);

        if (register != null) {

          // 어노테이션으로 설정된 정보가 있다면 해당 정보를 기준으로 등록한다
          bean = (RegisterEntityBeanDTO) getRegisterEntityBean(classFile, register, bean);
        } else {

          /**
           * 어노테이션으로 설정된 정보가 없다면 기본값에 의해 처리한다.
           * 기본값은 엔티티 명명 규칙에 의해 Class의 Fully qualified class name 에서 맨 마지막 Impl 을 제외한 부분이다.
           * 그런데 만약 그런 이름의 인터페이스가 없다면 엔티티 클래스 이름 그 자체를 bean name 으로 등록한다
           */
          bean = getDefaultRegisterEntityBean(classFile, bean);

        }

        if(!bean.isEmpty()){
          log.debug("Prepare Registering Entity Bean " + bean.getName());

          Annotation adminEntity = BytecodeUtil.getDeclaredAnnotationOnType(classFile, AdminEntity.class.getName());
          if(adminEntity != null){

            /**
             * Entity class 의 metadata 를 생성한다.
             */
            buildEntityClassMetadata(bean, classFile, adminEntity);

          }

          if(bean.isSupportHibernateSearch()){
            EntityBeanContext.putHibernateSearchEntity(bean.getName(), bean.getEntityClass());
          }

          EntityBeanContext.addRegisteredEntityBean(bean.getName(), bean);
          EntityBeanContext.addCeilingEntityClassName(bean.getEntityClass().getName(), bean.getName());

        } else {
          throw new RuntimeException("Error occurred to register entity bean. ClassName is " + className);
        }
      }

    } finally {
      if (isFrozen) {
        clazz.freeze();
      }
    }

  }

  private void buildEntityClassMetadata(RegisterEntityBeanDTO bean, ClassFile classFile,
      Annotation adminEntity) {
    /*
     *  AdminEntity 의 evictCacheRegionOnMerge 어노테이션을 읽어 EntityBean 의 evictCacheRegionOnMerge 에 저장한다
     */
    addEvictCacheRegionOnMergeData(bean, adminEntity);

    /**
     *  AdminEntity 의 restrictOnDelete 어노테이션을 읽어 EntityBean 의 restrictOnDeletes 에 저장한다
     */
    addRestrictOnDeleteData(bean, adminEntity);
/*
    for(FieldInfo field : classFile.getFields()){

    }*/

  }

  private void addRestrictOnDeleteData(RegisterEntityBeanDTO bean, Annotation adminEntity) {
    if(adminEntity.getMemberValue("restrictOnDelete") != null){
      ArrayMemberValue arrayMemberValue = (ArrayMemberValue) adminEntity.getMemberValue("restrictOnDelete");
      if(ArrayUtils.isNotEmpty(arrayMemberValue.getValue())){
        Map<String, EvictCacheDTO> regions = new HashMap<>();
        for(MemberValue value : arrayMemberValue.getValue()){
          if(value instanceof AnnotationMemberValue){
            AnnotationMemberValue annoValue = (AnnotationMemberValue) value;
            Annotation annotation = annoValue.getValue();

            if(annotation.getMemberValue("entityClassName") != null){
              String entityClassName = ((StringMemberValue) annotation.getMemberValue("entityClassName")).getValue();
              String property = ((StringMemberValue) annotation.getMemberValue("property")).getValue();

              bean.addRestrictOnDelete(entityClassName, property);
            }



          }
        }
      }
    }
  }

  private void addEvictCacheRegionOnMergeData(RegisterEntityBeanDTO bean, Annotation adminEntity) {
    if(adminEntity.getMemberValue("evictCaches") != null){
      ArrayMemberValue arrayMemberValue = (ArrayMemberValue) adminEntity.getMemberValue("evictCaches");
      if(ArrayUtils.isNotEmpty(arrayMemberValue.getValue())){
        Map<String, EvictCacheDTO> regions = new HashMap<>();
        for(MemberValue value : arrayMemberValue.getValue()){
          if(value instanceof AnnotationMemberValue){
            AnnotationMemberValue annoValue = (AnnotationMemberValue) value;
            Annotation annotation = annoValue.getValue();

            String regionName = ((StringMemberValue) annotation.getMemberValue("value")).getValue();
            Boolean contextual = false;
            if(annotation.getMemberValue("contextual") != null) {
              contextual = ((BooleanMemberValue) annotation.getMemberValue("contextual")).getValue();
            }

            Boolean evictAll = true;
            if(annotation.getMemberValue("evictAll") != null) {
              evictAll = ((BooleanMemberValue) annotation.getMemberValue("evictAll")).getValue();
            }

            boolean xref = false;
            if(annotation.getMemberValue("xref") != null) {
              xref = ((BooleanMemberValue) annotation.getMemberValue("xref")).getValue();
            }

            String xrefParentProperty = null;

            if(annotation.getMemberValue("xrefPArentProperty") != null){
              xrefParentProperty = ((StringMemberValue) annotation.getMemberValue("xrefParentProperty")).getValue();
            }

            EvictCacheDTO cache = new EvictCacheDTO(regionName, contextual, evictAll, xref, xrefParentProperty);

            regions.put(regionName, cache);

          }
        }
        bean.setEvictCacheRegionOnMerge(regions);
      }
    }
  }

  private RegisterEntityBeanDTO getDefaultRegisterEntityBean(ClassFile classFile, RegisterEntityBeanDTO bean) {

    bean.setOrder(10000);   // default

    // entity naming 규칙에 의거해, 뒤에 Impl 이 붙어 있다면
    String beanName = getDefaultEntityBeanName(classFile);
    bean.setName(beanName);

    return bean;
  }

  private String getDefaultEntityBeanName(ClassFile classFile) {
    String beanName = classFile.getName();
    if(StringUtils.endsWith(beanName, "Impl")){
      String candidateBeanName = StringUtils.substringBeforeLast(beanName, "Impl");
      String[] interfaces = classFile.getInterfaces();
      if(ArrayUtils.contains(interfaces, candidateBeanName)){
        return candidateBeanName;
      }
    }
    return beanName;
  }

  private EntityBean<?> getRegisterEntityBean(ClassFile classFile, Annotation register, EntityBean<?> bean) {
    String name = BytecodeUtil.getStringValue(register, "value");

    if(StringUtils.isBlank(name))
      name = getDefaultEntityBeanName(classFile);

    Integer order = getRegisterEntityBeanOrder(register);

    if (EntityBeanContext.isRegisteredEntityBean(name)) {
      bean = EntityBeanContext.getRegisterEntityBean(name);
      if (bean.priorThan(order)) {
        // 새 bean 을 등록할 필요가 있다.
        return bean;
      }
    }

    bean.setName(name);
    bean.setOrder(order);

    MemberValue propValues = register.getMemberValue("properties");
    if (propValues != null) {
      ArrayMemberValue memberValue = (ArrayMemberValue) propValues;
      Map<String, String> props = new HashMap<>();
      for (MemberValue mv : memberValue.getValue()) {
        AnnotationMemberValue member = (AnnotationMemberValue) mv;
        Annotation memberAnnot = member.getValue();

        if (memberAnnot.getMemberValue("name") != null
            && memberAnnot.getMemberValue("ref") != null) {
          props.put(BytecodeUtil.getStringValue(memberAnnot, "name"), BytecodeUtil.getStringValue(memberAnnot, "ref"));
        }
      }
    }


    return bean;
  }

  public Integer getRegisterEntityBeanOrder(Annotation register) {
    Integer order = BytecodeUtil.getIntegerValue(register, "order");
    if (order == null)
      order = Integer.MAX_VALUE;
    return order;
  }

  public static Set<String> getRegisteredEntityBeanNames(){
    return EntityBeanContext.getRegisteredEntityBeanNames();
  }

  /**
   * 특정 엔티티 클래스의 Ceiling Class Name 을 반환한다
   *
   * io.rchemist.rchemist.event.webhook.domain.WebhookImpl -> io.rchemist.rchemist.event.webhook.domain.Webhook
   *
   * @param className
   * @return
   */
  public static String getCeilingEntityClassName(String className){
    return EntityBeanContext.getCeilingEntityClassName(className);
  }

  public static void loadLazyProperties(Object entity){
    try{
      if(getRegisterEntityBeanMap().containsKey(entity.getClass().getName())){
        getRegisterEntityBeanMap().get(entity.getClass().getName()).loadLazyProperties(entity);
      }
    }catch (Exception e){
      // do nothing
      e.printStackTrace();
    }
  }

  public static List<String> getPropertyNames(String entityClass) {
    List<String> propertyNames = new ArrayList<>();
    PersistentClass persistentClass = getPersistentClass(entityClass);
    if (persistentClass == null)
      return propertyNames;

    for (Property prop : persistentClass.getProperties()) {
      propertyNames.add(prop.getName());
    }
    return propertyNames;
  }

  public static Map<String, Type> getPropertyTypes(String entityClass) {
    Map<String, Type> propertyTypes = new HashMap<>();
    PersistentClass persistentClass = getPersistentClass(entityClass);
    if (persistentClass == null)
      return propertyTypes;

    for (Property prop : persistentClass.getProperties()) {
      propertyTypes.put(prop.getName(), prop.getType());
    }
    return propertyTypes;
  }

  public static Type getPropertyType(String entityClass, String propertyName) {
    return getPropertyTypes(entityClass).get(propertyName);
  }

  public static List<Class<?>> getHibernateSearchEntities(){
    return EntityBeanContext.getHibernateSearchEntityList();
  }

}
