/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.CollectionUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * QuerySpecification의 조건 병합 로직을 담당하는 클래스
 * 복잡한 조건 병합 과정을 분리하여 책임을 명확히 함
 */
@Slf4j
public class PredicateMerger<T extends Serializable> {

  private final Class<T> entityClass;
  private final Map<ConditionOperatorType, QueryCondition> conditions;
  private final Map<String, Join<T, ?>> joinPaths;
  private final Map<String, Root<?>> unmappedJoinPaths;
  private final Map<ConditionOperatorType, List<UnmappedJoinItem>> unmappedJoinItems;
  private final List<Predicate> mustPredicates;
  private final List<Predicate> shouldPredicates;

  public PredicateMerger(Class<T> entityClass,
                        Map<ConditionOperatorType, QueryCondition> conditions,
                        Map<String, Join<T, ?>> joinPaths,
                        Map<String, Root<?>> unmappedJoinPaths,
                        Map<ConditionOperatorType, List<UnmappedJoinItem>> unmappedJoinItems,
                        List<Predicate> mustPredicates,
                        List<Predicate> shouldPredicates) {
    this.entityClass = entityClass;
    this.conditions = conditions;
    this.joinPaths = joinPaths;
    this.unmappedJoinPaths = unmappedJoinPaths;
    this.unmappedJoinItems = unmappedJoinItems;
    this.mustPredicates = mustPredicates;
    this.shouldPredicates = shouldPredicates;
  }

  /**
   * 모든 조건을 병합하여 최종 Predicate 목록을 생성
   */
  public void mergeAllConditions(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
    log.debug("Starting predicate merge process");
    
    // 1. 기본 조건들 병합
    mergeRootConditions(root, criteriaBuilder);
    
    // 2. 매핑되지 않은 조인 조건들 병합
    mergeUnmappedConditions(root, query, criteriaBuilder);
    
    log.debug("Predicate merge completed. Must predicates: {}, Should predicates: {}", 
              mustPredicates.size(), shouldPredicates.size());
  }


  /**
   * 기본 조건들을 mustPredicates와 shouldPredicates로 분류하여 병합
   */
  private void mergeRootConditions(Root<T> root, CriteriaBuilder criteriaBuilder) {
    if (MapUtils.isEmpty(conditions)) {
      log.debug("No root conditions to merge");
      return;
    }

    for (Entry<ConditionOperatorType, QueryCondition> entry : conditions.entrySet()) {
      QueryCondition condition = entry.getValue();

      if (condition != null && !condition.isEmpty()) {
        QueryParser<T> parser = new QueryParser<>(entityClass, criteriaBuilder, root, joinPaths, condition.getAllQueryConditionItems());

        ConditionOperatorType operatorType = entry.getKey();
        Predicate parsedPredicate = parser.getPredicate(operatorType);

        if (MapUtils.isNotEmpty(parser.getJoinPaths())) {
          // join paths 동기화
          joinPaths.putAll(parser.getJoinPaths());
        }

        if (operatorType.isMust()) {
          this.mustPredicates.add(parsedPredicate);
        } else {
          this.shouldPredicates.add(parsedPredicate);
        }
      }
    }
  }


  /**
   * 매핑되지 않은 조인 조건들 병합
   */
  private void mergeUnmappedConditions(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
    if (MapUtils.isEmpty(unmappedJoinItems)) {
      log.debug("No unmapped join conditions to merge");
      return;
    }

    log.debug("Processing {} unmapped join conditions", unmappedJoinItems.size());
    
    for (Entry<ConditionOperatorType, List<UnmappedJoinItem>> entry : unmappedJoinItems.entrySet()) {
      ConditionOperatorType operatorType = entry.getKey();
      List<UnmappedJoinItem> items = entry.getValue();
      List<Predicate> predicates = new ArrayList<>();

      for (UnmappedJoinItem item : CollectionUtils.emptyIfNull(items)) {
        Root<?> join;

        if (unmappedJoinPaths.containsKey(item.getJoinAlias())) {
          // 이미 join이 되어 있다.
          join = unmappedJoinPaths.get(item.getJoinAlias());

          QueryConditionItem condition = item.getAdditionalCondition();

          if (condition != null) {
            QueryParser parser = new QueryParser(item.getTargetEntityClass(), criteriaBuilder, join, new HashMap<>(), CollectionUtil.list(condition));
            predicates.add(parser.getPredicate(ConditionOperatorType.AND));
          }

        } else {
          join = query.from(item.getTargetEntityClass());
          query.distinct(true);
          join.alias(item.getJoinAlias());

          // BUG-031 fix (0.0.10.H): rootJoinPath / targetPath 가 dot-notation ("testEntity.id") 일 때
          //   단일 attribute 로 해석하면 Hibernate 가 "Could not resolve attribute" 로 실패한다.
          //   resolveDotPath 로 분해해 ManyToOne implicit path 를 단계적으로 내려간다.
          Predicate joinPredicate = criteriaBuilder.equal(
              resolveDotPath(root, item.getRootJoinPath()),
              resolveDotPath(join, item.getTargetPath())
          );

          QueryConditionItem condition = item.getAdditionalCondition();

          if (condition != null) {
            QueryParser parser = new QueryParser(item.getTargetEntityClass(), criteriaBuilder, join, new HashMap<>(), CollectionUtil.list(condition));
            predicates.add(
                // and로 한번 더 감싸야 한다.
                criteriaBuilder.and(joinPredicate, parser.getPredicate(ConditionOperatorType.AND))
            );
          } else {
            predicates.add(joinPredicate);
          }

          unmappedJoinPaths.put(item.getJoinAlias(), join);
        }
      }

      if (CollectionUtils.isNotEmpty(predicates)) {
        if (operatorType.isMust()) {
          mustPredicates.addAll(predicates);
        } else {
          shouldPredicates.addAll(predicates);
        }
      }
    }
  }

  /**
   * dot-notation 경로 ("testEntity.id") 를 JPA Path 로 변환한다.
   *   ManyToOne 관계는 JPA implicit join 으로 자동 처리된다 (명시적 join 불필요).
   *   UnmappedJoinItem 의 rootJoinPath / targetPath 가 dot-path 를 허용하기 위한 헬퍼.
   */
  private Path<?> resolveDotPath(Path<?> base, String dotPath) {
    if (dotPath == null || dotPath.isEmpty()) {
      return base;
    }
    Path<?> path = base;
    for (String segment : StringUtils.split(dotPath, ".")) {
      path = path.get(segment);
    }
    return path;
  }

  /**
   * 매핑되지 않은 조건의 타입에 따라 분류
   */
  private void classifyUnmappedPredicate(ConditionOperatorType operatorType, Predicate predicate) {
    switch (operatorType) {
      case AND:
        mustPredicates.add(predicate);
        log.debug("Added unmapped AND predicate to must predicates");
        break;
      case OR:
        shouldPredicates.add(predicate);
        log.debug("Added unmapped OR predicate to should predicates");
        break;
      default:
        log.warn("Unknown unmapped operator type: {}, treating as AND", operatorType);
        mustPredicates.add(predicate);
        break;
    }
  }

  /**
   * 병합 결과 검증
   */
  public boolean hasPredicates() {
    return !mustPredicates.isEmpty() || !shouldPredicates.isEmpty();
  }

  /**
   * 병합 결과 통계 정보
   */
  public String getMergeStatistics() {
    return String.format("Must predicates: %d, Should predicates: %d, Total conditions: %d, Unmapped paths: %d",
                        mustPredicates.size(), shouldPredicates.size(), conditions.size(), unmappedJoinPaths.size());
  }
}