/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.datasource.provider;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.PropertyUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Component
public class HikariCpDataSourceBuilder extends AbstractDataSourceBuilder {

  @Value("${platform.config.datasource.provider.hikari:true}")
  protected boolean useHikariCp = true;

  private static final String[] HIKARI_PROPERTIES = ArrayUtil.make("username", "password"
      , "driverClassName", "jdbcUrl"
      , "dataSourceClassName", "dataSource"
      , "driver-class-name", "jdbc-url"
      , "url"
      // connection lifecycle / 타임아웃 계열. HikariConfig 가 camelCase setter 로 바로 받는다.
      , "connectionInitSql", "connection-init-sql"
      , "connectionTimeout", "connection-timeout"
      , "validationTimeout", "validation-timeout"
      , "idleTimeout", "idle-timeout"
      , "maxLifetime", "max-lifetime"
      , "leakDetectionThreshold", "leak-detection-threshold"
      , "keepaliveTime", "keepalive-time"
      , "minimumIdle", "minimum-idle"
      , "maximumPoolSize", "maximum-pool-size"
      , "poolName", "pool-name");

  @Override
  protected Map<String, Properties> transform(Map<String, Properties> parsedProps) {

    // key 이름을 camelCase로 변경한다.
    Map<String, Properties> transformed = new HashMap<>();
    for (Map.Entry<String, Properties> entry : parsedProps.entrySet()) {
      String puName = entry.getKey();
      Properties newProperties = new Properties();
      for (Map.Entry<Object, Object> ent : entry.getValue().entrySet()) {
        String propKey = (String) ent.getKey();
        if(ArrayUtils.contains(HIKARI_PROPERTIES, propKey)){
          newProperties.put(camelCase(ent), ent.getValue());
        }else{
          addAdditionalProperties(puName, propKey, ent.getValue());
        }
      }
      if(!newProperties.isEmpty()){
        transformed.put(puName, newProperties);
      }
    }

    return transformed;
  }

  @Override
  protected boolean canHandle(Properties properties) {
    return useHikariCp;
  }

  @Override
  public DataSource generateDataSource(String dataSourceName, Properties properties) {
    HikariConfig hikariConfig = new HikariConfig(properties);
    hikariConfig = addDataSourceProperty(hikariConfig, dataSourceName);
    return new HikariDataSource(hikariConfig);
  }

  private HikariConfig addDataSourceProperty(HikariConfig hikariConfig, String dataSourceName) {
    hikariConfig.addDataSourceProperty("cachePrepStmts", true);
    hikariConfig.addDataSourceProperty("prepStmtCacheSize", 250);
    hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", 2048);
    hikariConfig.addDataSourceProperty("useServerPrepStmts", true);
    hikariConfig.addDataSourceProperty("useLocalSessionState", true);
    hikariConfig.addDataSourceProperty("rewriteBatchedStatements", true);
    hikariConfig.addDataSourceProperty("cacheResultSetMetadata", true);
    hikariConfig.addDataSourceProperty("cacheServerConfiguration", true);
    hikariConfig.addDataSourceProperty("maintainTimeStats", false);
    hikariConfig.addDataSourceProperty("elideSetAutoCommits", true);
    hikariConfig.setIdleTimeout(300000);
    hikariConfig.setMaxLifetime(1200000);
    hikariConfig.setMinimumIdle(5);
    hikariConfig.setMaximumPoolSize(30);
    hikariConfig.setAutoCommit(true);
    hikariConfig.setPoolName(dataSourceName + "Pool");
    return hikariConfig;
  }

  protected Properties validate(Properties properties) {
    return PropertyUtil.replace(properties, "url", "jdbcUrl", true);
  }

}
