/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import org.apache.commons.lang3.StringUtils;

/**
 * 0.0.10.I Round 3 (BUG-032): JSON 컬럼 dot-notation 접근 시 dialect 별 SQL 함수/경로 문법을 선택한다.
 *
 * <p>현재 framework 가 실제로 지원하는 dialect 범위는 {@code common/common-data-jpa/pom.xml} 기준
 * Postgres / MySQL (+MariaDB) / H2 세 가지. Hibernate 6.6 은 JSON 함수를 dialect-neutral SQM 으로
 * 제공하지 않기 때문에, {@code CriteriaBuilder#function} 으로 dialect 별 native 함수를 직접
 * 호출해야 한다. 각 dialect 의 매핑:
 *
 * <ul>
 *   <li>{@link #POSTGRES}: {@code jsonb_extract_path_text(col, key1, key2, ...)} — 모든 segment 를
 *       가변 인수로 넘긴다. 반환 타입 text.</li>
 *   <li>{@link #MYSQL}: {@code json_unquote(json_extract(col, '$.key1.key2.<...>'))} — 경로 전체를
 *       하나의 JSON path 문자열로 묶는다. unquote 로 문자열 비교가 가능하도록 따옴표 제거.</li>
 *   <li>{@link #H2}: 테스트 환경 H2 2.2.224 는 {@code JSON_VALUE} 함수가 **없다** (H2 2.3.232+ 부터
 *       지원). hypersistence-utils JsonType 이 H2 에서는 JSON 을 VARCHAR 로 직렬화해 저장하므로
 *       기존 {@code SingleConditionItem#isJsonFilter} 경로의 LIKE 문자열 매칭 ({@code %"key":"value"%})
 *       으로 fallback 한다. {@code QueryParser} 가 이 dialect 를 받으면 LIKE 기반 predicate 를 직접
 *       빌드한다. Postgres/MySQL 환경으로 올리면 native JSON 함수 경로가 자연히 활성화된다.</li>
 *   <li>{@link #UNSUPPORTED}: 기타 dialect. Round 3 시점의 fallback — JSON 분기를 적용하지 않고
 *       원래 경로 (association join) 로 내려가 dialect 책임으로 실패시킨다. 사용 측에서 명시적으로
 *       SingleConditionItem#setJsonFilter(true) 를 호출하면 기존 LIKE 기반 JSON 문자열 매칭 경로가
 *       타는 하위 호환성도 그대로 유지된다.</li>
 * </ul>
 */
public enum JsonColumnDialect {
  POSTGRES,
  MYSQL,
  H2,
  UNSUPPORTED;

  /**
   * Hibernate {@code org.hibernate.dialect.Dialect} 클래스 이름으로부터 JsonColumnDialect 를 해석한다.
   * 정확한 class FQN 비교가 아닌 substring 매칭이라 subclass (PostgreSQLXXDialect / MariaDBDialect
   * 등) 도 올바르게 잡는다.
   */
  public static JsonColumnDialect fromDialectClassName(String dialectClassName) {
    if (StringUtils.isBlank(dialectClassName)) {
      return UNSUPPORTED;
    }
    String lower = dialectClassName.toLowerCase();
    if (lower.contains("postgres") || lower.contains("cockroach")) {
      return POSTGRES;
    }
    if (lower.contains("mysql") || lower.contains("mariadb")) {
      return MYSQL;
    }
    if (lower.contains("h2dialect") || lower.endsWith(".h2dialect") || lower.contains(".h2.")) {
      return H2;
    }
    return UNSUPPORTED;
  }
}
