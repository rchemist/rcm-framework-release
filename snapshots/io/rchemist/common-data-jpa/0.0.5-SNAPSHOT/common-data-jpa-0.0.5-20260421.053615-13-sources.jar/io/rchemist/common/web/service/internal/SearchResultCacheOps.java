/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.internal;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.extension.ResponseListExtensionManager;
import java.io.Serializable;
import javax.cache.Cache;

public interface SearchResultCacheOps<VIEW extends HasIdEntity<ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> {

  /**
   * LocalCacheManager 를 이용한 Search 결과 캐싱 처리 사용 여부
   */
  default boolean useSearchResultCache() {
    return getSearchResultCache() != null;
  }

  /**
   * Search 결과 캐싱을 사용하려면 직접 생성한다.
   */
  default Cache<String, ResponseListWrapperCache> getSearchResultCache() {
    return null;
  }

  default void clearSearchResultCache() {
    // try 로 각 구문을 나눈 이유는, 하나가 실패해도 나머지가 계속 수행되게 하기 위함이다.
    try {
      if (useSearchResultCache()) {
        getSearchResultCache().clear();
      }
    } catch (Exception e) {
      // silent ignore
    }

    try {
      ResponseListExtensionManager.clearSearchResultCache();
    } catch (Exception e) {
      // silent ignore
    }
  }

  /**
   * 검색 결과를 캐시로 저장하는 로직을 오버라이드 할 수 있다.
   */
  default void putSearchResultCache(ResponseListWrapper<VIEW, SEARCH_FORM> wrapper, String cacheKey) {
    ResponseListWrapperCache<VIEW, SEARCH_FORM, ID> cacheItem = new ResponseListWrapperCache<>(wrapper);
    getSearchResultCache().put(cacheKey, cacheItem);
  }
}
