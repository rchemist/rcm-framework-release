/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IndexKeyValue;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.converter.OrderedMapAttributeConverter;
import io.rchemist.common.persistence.jpa.domain.data.OrderedMapWrapper;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import java.util.Map;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(value = SimpleAttributes.class)
public class SimpleAttributesImpl implements EnhancedTemplate {

  @Column(name = "ATTRIBUTES", length = 8000)
  @Convert(converter = OrderedMapAttributeConverter.class)
  @Description(name = "Key/Value", comment = "추가 속성 정보의 Key/Value. {key:value, key:value...}의 형태로 저장된다.")
  protected Map<String, String> simpleAttributes = new OrderedMapWrapper();

  @IndexKeyValue(indexName = "attributes", derivedFrom = "simpleAttributes")
  public Map<String, String> getSimpleAttributes(){
    return simpleAttributes;
  }

  public void setSimpleAttributes(Map<String, String> simpleAttributes) {
    if (this.simpleAttributes == null) {
      this.simpleAttributes = new OrderedMapWrapper();
    }
    this.simpleAttributes.clear();
    if(MapUtils.isNotEmpty(simpleAttributes)){
      this.simpleAttributes.putAll(simpleAttributes);
    }
  }

  public void addSimpleAttribute(String key, String value){
    if (this.simpleAttributes == null) {
      this.simpleAttributes = new OrderedMapWrapper();
    }
    if(key != null){
      // prevent null
      value = StringUtil.toString(value);
      // BUG-040 fix (0.1.1.G): previously `Map values = getSimpleAttributes()` returned the
      // internal map, then `setSimpleAttributes(values)` called `this.simpleAttributes.clear()`
      // which also emptied the same-reference `values` before putAll — the newly added entry
      // was silently lost. Mutate the backing map directly instead.
      this.simpleAttributes.put(key, value);
    }
  }

  public String getSimpleAttributeValue(String key){
    if (this.simpleAttributes == null) {
      this.simpleAttributes = new OrderedMapWrapper();
    }
    if(MapUtils.isNotEmpty(getSimpleAttributes())){
      return getSimpleAttributes().get(key);
    }else {
      return null;
    }
  }

}
