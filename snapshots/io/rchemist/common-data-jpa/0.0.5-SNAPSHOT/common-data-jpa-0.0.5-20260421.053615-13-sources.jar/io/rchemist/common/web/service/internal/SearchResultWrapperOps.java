/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.internal;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.type.EntityViewType;
import java.io.Serializable;
import org.apache.commons.collections4.CollectionUtils;

public interface SearchResultWrapperOps<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> extends
    EntityCacheOps<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION>,
    SearchResultCacheOps<VIEW, SEARCH_FORM, ID, SERVICE_EXCEPTION> {

  /**
   * createResponseListWrapper 에서 사용할 searchForm 을 override 할 수 있다.
   * 검색폼에 고정적으로 추가할 파라미터가 있거나, 기타 검색폼을 변경할 필요가 있을 때 사용한다.
   */
  default SEARCH_FORM overrideSearchForm(SEARCH_FORM searchForm) {
    return searchForm;
  }

  @Override
  default ResponseListWrapper<VIEW, SEARCH_FORM> createResponseListWrapper(SEARCH_FORM searchForm) {

    String cacheKey = null;

    searchForm = overrideSearchForm(searchForm);
    EntityViewType entityViewType = searchForm.getEntityViewType();
    boolean cacheEnabled = useSearchResultCache() && !searchForm.isIgnoreCache();

    if (cacheEnabled) {
      // 캐시를 확인하기 위해 searchForm 을 변조하지 않도록 deepCopy 로 사용한다.
      SearchContext<ENTITY, SEARCH_FORM> context;
      try {
        context = getSearchContext(searchForm.deepCopy(false));
      } catch (ErrorTypeException e) {
        ResponseListWrapper<VIEW, SEARCH_FORM> wrapper = new ResponseListWrapper<>();
        wrapper.setError(new ErrorDTO(e));
        return wrapper;
      }

      cacheKey = context.getCacheKey(this.getClass().getSimpleName());

      if (WebRequestContext.getWebRequestContext().isAdmin()) {
        cacheKey = cacheKey + CACHE_KEY_SPLITTER + ADMIN_CACHE_KEY;
      }

      if (!context.isForceFetchFromDB()) {
        if (getSearchResultCache().containsKey(cacheKey)) {
          //noinspection unchecked
          ResponseListWrapperCache<VIEW, SEARCH_FORM, ID> listCache = (ResponseListWrapperCache<VIEW, SEARCH_FORM, ID>) getSearchResultCache().get(cacheKey);
          try {
            ResponseListWrapper<VIEW, SEARCH_FORM> cloned = listCache.getResponseListWrapper();
            if (CollectionUtils.isNotEmpty(listCache.getIdList())) {
              for (ID id : listCache.getIdList()) {
                VIEW entityView = findCachedViewById(id, entityViewType);
                cloned.addListItem(entityView);
              }
            }
            return cloned;
          } catch (Exception e) {
            // 에러 시 아래에서 재조회하므로 skip
            ExceptionUtil.printStackTrace(e);
          }
        }
      }
    }

    ResponseListWrapper<VIEW, SEARCH_FORM> wrapper = EntityCacheOps.super.createResponseListWrapper(searchForm);

    if (wrapper.isError() && !wrapper.isEmpty()) {
      wrapper = new ResponseListWrapper<VIEW, SEARCH_FORM>().withError(wrapper.getError());
      wrapper.setList(null);
    }

    if (!wrapper.isNull()) {
      if (cacheEnabled) {
        putSearchResultCache(wrapper, cacheKey);
      }
    }

    return wrapper;
  }
}
