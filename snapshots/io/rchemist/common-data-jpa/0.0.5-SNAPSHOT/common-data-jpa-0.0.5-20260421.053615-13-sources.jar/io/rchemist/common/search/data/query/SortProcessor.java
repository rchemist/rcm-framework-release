/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Sort.Direction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Processes sorting logic for QuerySpecification.
 * This class handles the creation of JPA Order objects from sort properties,
 * managing both simple and joined property sorting.
 */
@Slf4j
public class SortProcessor<T extends Serializable> {

    private final JoinManager<T> joinManager;

    public SortProcessor(JoinManager<T> joinManager) {
        this.joinManager = joinManager;
    }

    /**
     * Creates JPA Order objects from the given sort properties.
     * 
     * @param root JPA root entity
     * @param query JPA criteria query  
     * @param criteriaBuilder JPA criteria builder
     * @param joinedSortProperties List of sort properties that may require joins
     * @return List of Order objects for the query
     */
    public List<Order> createOrders(Root<T> root, 
                                   CriteriaQuery<?> query,
                                   CriteriaBuilder criteriaBuilder,
                                   List<JoinedSortProperty> joinedSortProperties) {
        
        List<Order> orders = new ArrayList<>();
        
        if (CollectionUtils.isEmpty(joinedSortProperties)) {
            log.debug("No sort properties provided, returning empty order list");
            return orders;
        }
        
        for (JoinedSortProperty property : joinedSortProperties) {
            try {
                Order order = createOrder(root, criteriaBuilder, property);
                if (order != null) {
                    orders.add(order);
                    log.debug("Created order for property: {}, direction: {}", 
                             property.getPath(), property.getDirection());
                }
            } catch (Exception e) {
                log.warn("Failed to create order for property: {}, error: {}", 
                        property.getPath(), e.getMessage());
                // Continue processing other properties instead of failing completely
            }
        }
        
        log.debug("Created {} sort orders from {} properties", orders.size(), joinedSortProperties.size());
        return orders;
    }
    
    /**
     * Creates a single Order from a JoinedSortProperty.
     */
    private Order createOrder(Root<T> root, CriteriaBuilder criteriaBuilder, JoinedSortProperty property) {
        String path = property.getPath();
        Direction direction = property.getDirection();
        JoinType joinType = property.getJoinType();
        
        if (path == null || path.trim().isEmpty()) {
            log.warn("Sort property path is null or empty, skipping");
            return null;
        }
        
        Expression<?> expression = createSortExpression(root, path, joinType);
        
        if (expression == null) {
            log.warn("Could not create expression for sort path: {}", path);
            return null;
        }
        
        return direction == Direction.ASC ? 
               criteriaBuilder.asc(expression) : 
               criteriaBuilder.desc(expression);
    }
    
    /**
     * Creates an Expression for sorting, handling both simple and joined properties.
     */
    private Expression<?> createSortExpression(Root<T> root, String path, JoinType joinType) {
        if (!path.contains(".")) {
            // Simple property - no join required
            return root.get(path);
        }
        
        // Joined property - need to create joins
        String joinPath = StringUtil.subStringBefore(path, ".");
        String propertyPath = StringUtil.subStringAfter(path, ".");
        
        if (joinPath.isEmpty() || propertyPath.isEmpty()) {
            log.warn("Invalid join path format: {}", path);
            return null;
        }
        
        // Use JoinManager to get or create the join
        JoinType effectiveJoinType = (joinType != null) ? joinType : JoinType.LEFT;
        
        try {
            Join<T, ?> join = joinManager.getOrCreateJoin(root, joinPath, effectiveJoinType);
            return join.get(propertyPath);
        } catch (Exception e) {
            log.warn("Error creating join for sort path: {}, error: {}", path, e.getMessage());
            return null;
        }
    }
    
    /**
     * Validates sort properties and removes invalid ones.
     */
    public List<JoinedSortProperty> validateSortProperties(List<JoinedSortProperty> properties) {
        if (CollectionUtils.isEmpty(properties)) {
            return new ArrayList<>();
        }
        
        List<JoinedSortProperty> validProperties = new ArrayList<>();
        
        for (JoinedSortProperty property : properties) {
            if (isValidSortProperty(property)) {
                validProperties.add(property);
            } else {
                log.warn("Invalid sort property: {}", property);
            }
        }
        
        return validProperties;
    }
    
    /**
     * Checks if a sort property is valid.
     */
    private boolean isValidSortProperty(JoinedSortProperty property) {
        if (property == null) {
            return false;
        }
        
        String path = property.getPath();
        if (path == null || path.trim().isEmpty()) {
            return false;
        }
        
        // Check for invalid path patterns
        if (path.startsWith(".") || path.endsWith(".") || path.contains("..")) {
            return false;
        }
        
        // Direction should be specified
        if (property.getDirection() == null) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Applies sort orders to the query if it's not a count query.
     */
    public void applySortToQuery(CriteriaQuery<?> query, List<Order> orders) {
        // Only apply sorting to data queries, not count queries
        if (query.getResultType() != Long.class && CollectionUtils.isNotEmpty(orders)) {
            query.orderBy(orders);
            log.debug("Applied {} sort orders to query", orders.size());
        }
    }
}