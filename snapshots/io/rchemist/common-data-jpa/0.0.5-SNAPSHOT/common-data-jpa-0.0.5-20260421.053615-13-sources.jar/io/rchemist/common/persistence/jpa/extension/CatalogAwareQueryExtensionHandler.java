/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.List;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = PlatformEntityExtensionManager.BEAN_NAME, priority = 300)
public class CatalogAwareQueryExtensionHandler implements PlatformEntityExtensionHandler{

  private static final String HANDLER_NAME = "CatalogAwareQueryExtensionHandler";
  private static final String PROPERTY_NAME = "catalogId";

  @Override
  public ExtensionResultStatusType resolveAdditionalPredicates(
      ExtensionResultHolder<List<Predicate>> erh, Set<Class<? extends PlatformEntityExtensionHandler>> prohibitExecuteHandlers, CriteriaBuilder builder, Root<?> root, Class<?> rootClass){


    if(isMember(HANDLER_NAME, root, PROPERTY_NAME) && !CollectionUtils.containsAny(prohibitExecuteHandlers, getClass())){

      WebRequestContext context = WebRequestContext.getWebRequestContext();
      if(!context.isAdmin() && context.getSiteAlias() != null){

        List<Predicate> predicates = erh.getResult();

        if(CollectionUtils.isEmpty(context.getManagedCatalogIds())){
          predicates.add(builder.isNull(root.get(PROPERTY_NAME)));
        }else{
          predicates.add(builder.and(
              builder.or(builder.isNull(root.get(PROPERTY_NAME)),
                  root.get(PROPERTY_NAME).in(context.getManagedCatalogIds()))));
        }

        erh.setResult(predicates);

        return ExtensionResultStatusType.HANDLED;
      }


    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
