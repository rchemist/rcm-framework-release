/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.sync.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.sync.domain.SyncStatus;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.QueryHints;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface SyncStatusRepository extends CommonSearchRepository<SyncStatus, Long> {

  // AbstractSyncInitializer 는 ApplicationReadyEvent 의 메인 스레드에서 이 쿼리를 호출한다.
  // DB 에 좀비 트랜잭션이 있어 락이 걸려 있는 경우 영구 블록되어 이후 리스너들이 전부 밀리므로,
  // 3 초 query timeout 을 걸어 실패로 떨어지게 한다. (AbstractSyncInitializer 는 예외를 잡아
  // syncStatusService.fail() 로 처리하고 다음 리스너로 계속 진행된다.)
  @QueryHints(@QueryHint(name = "jakarta.persistence.query.timeout", value = "3000"))
  SyncStatus findBySyncId(String syncStatusId);

  @Modifying
  void deleteBySyncId(String syncStatusId);
}
