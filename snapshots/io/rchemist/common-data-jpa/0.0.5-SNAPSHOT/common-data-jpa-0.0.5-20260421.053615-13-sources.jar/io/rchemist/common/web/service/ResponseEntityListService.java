/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.search.data.query.QuerySpecification;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.internal.CrudCacheOps;
import io.rchemist.common.web.service.internal.SearchResultWrapperOps;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.List;
import org.hibernate.jpa.AvailableHints;
import org.springframework.boot.logging.LogLevel;

/**
 * CRUD, Search 모두를 지원하는 ResponseEntityList 서비스
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ResponseEntityListService<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> extends
    CrudCacheOps<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION>,
    SearchResultWrapperOps<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION> {

  // @PersistenceContext 를 Service 별로 별도로 가져갈 수 있게 한다.
  EntityManager getEntityManager();

  default List<ID> getEntityIds(Class<ENTITY> entityClass, Class<ID> idClass, String idFieldName, SEARCH_FORM searchForm) throws SERVICE_EXCEPTION {
    CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
    CriteriaQuery<ID> query = builder.createQuery(idClass);
    Root<ENTITY> root = query.from(entityClass);

    query.select(root.get(idFieldName)).distinct(true);

    SearchContext<ENTITY, SEARCH_FORM> context = getSearchContext(searchForm);
    if (context instanceof CommonSearchContext<ENTITY, SEARCH_FORM> commonSearchContext) {
      QuerySpecification<ENTITY, SEARCH_FORM> specification = commonSearchContext.getSpecification();

      Predicate predicate = specification.toPredicate(root, query, builder);
      // BUG-011 fix (0.0.10.D): SearchForm 에 filter 가 없으면 toPredicate 가 null 을 반환하며,
      // Hibernate 6 의 SQM 은 query.where(null) 을 허용하지 않아 NPE 를 던진다. null 일 때는
      // where 절을 생략해 전체 조회로 동작하게 한다.
      if (predicate != null) {
        query.where(predicate);
      }
      query.orderBy(builder.desc(root.get(idFieldName)));

      TypedQuery<ID> typedQuery = getEntityManager().createQuery(query);
      typedQuery.setHint(AvailableHints.HINT_CACHEABLE, true);
      typedQuery.setHint(AvailableHints.HINT_CACHE_REGION, "query." + entityClass.getSimpleName() + ".Id." + idFieldName);
      typedQuery.setMaxResults(10000);

      List<ID> ids = typedQuery.getResultList();
      return CollectionUtil.getDistinctList(ids);
    }

    throw new RuntimeException("ID 를 조회할 수 없습니다. getSearchContext 에서 반드시 CommonSearchContext 를 구현해야 합니다.");
  }

  @Override
  default ResponseData<Long> getQuerySearchCount(SEARCH_FORM searchForm) {
    return ResponseHelper.result(() -> CrudCacheOps.super.getSearchCount(searchForm));
  }

  default Boolean clearCache() {
    try {
      if (useEntityCache()) {
        getEntityCache().clear();
      }
      if (useSearchResultCache()) {
        getSearchResultCache().clear();
      }
      return true;
    } catch (Exception e) {
      ExceptionUtil.printLog(e.getMessage(), LogLevel.WARN);
      return false;
    }
  }
}
