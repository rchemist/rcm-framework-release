/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.persistence.type;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Type;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
public class PersistentInfo implements Serializable {

  /**
   * 0.0.10.I Round 2 (BUG-032): {@code @Type(JsonType.class)} 로 선언된 field 를 감지하기 위해
   * UserType 클래스 이름 prefix 로 매칭한다. hypersistence-utils 의 JsonType / JsonBinaryType 계열을
   * 포함 (json-* Hibernate 6 변종까지 cover).
   */
  private static final String JSON_USERTYPE_CLASS_PREFIX =
      "io.hypersistence.utils.hibernate.type.json";

  public PersistentInfo(PersistentClass persistentClass) {
    this.persistentClass = persistentClass;

    // QuerySearch 에서 사용하기 위해 join 관련 정보를 따로 저장한다.
    // 어떤걸 join 으로 접근하고 어떤걸 get 으로 접근해야 하는지 쉽게 판단하기 위해서다.
    List<Property> properties = persistentClass.getProperties();

    for (Property property : CollectionUtils.emptyIfNull(properties)) {
      if(property.getType().isEntityType()){
        // many to one
        this.joinProperties.put(property.getName(), property.getType().getName());
      }else if(property.getType().isCollectionType()){
        // one to many collection

        String propertyClassName = StringUtils.substringBetween(property.getType().getName(), "(", ")");

        if(StringUtils.isNotEmpty(propertyClassName)
            && !StringUtils.equals(persistentClass.getClassName(), propertyClassName)){
          this.joinProperties.put(property.getName(), propertyClassName);
        }

      }else if(property.getType().isComponentType()){
        // component field
      }
    }

    // 0.0.10.I Round 2 (BUG-032): JSON 컬럼 감지. @Type(JsonType.class) 또는 hypersistence-utils 의
    //   JSON UserType 계열로 선언된 field 를 jsonProperties 에 등록한다. QueryParser#buildJoinPath
    //   가 dot-notation 첫 segment 를 JSON 컬럼으로 인식해 association join 이 아닌 JSON path
    //   표현식으로 빌드할 수 있게 해준다.
    collectJsonProperties(persistentClass);

  }

  /**
   * {@code persistentClass.getMappedClass()} (및 그 superclass) 의 field 를 reflection 으로 순회해
   * {@code @Type(JsonType.class)} 가 붙은 field 이름을 {@link #jsonProperties} 에 모은다.
   * Hibernate Property API 만으로는 UserType 의 구체 클래스에 접근하기가 불안정해 field annotation
   * 경로를 택했다.
   */
  private void collectJsonProperties(PersistentClass persistentClass) {
    Class<?> mappedClass = null;
    try {
      mappedClass = persistentClass.getMappedClass();
    } catch (Throwable t) {
      // abstract / transient 엔티티는 mappedClass 가 없을 수 있다.
      return;
    }
    if (mappedClass == null) {
      return;
    }

    Class<?> current = mappedClass;
    while (current != null && current != Object.class) {
      for (Field field : current.getDeclaredFields()) {
        Type typeAnnotation = field.getAnnotation(Type.class);
        if (typeAnnotation == null) {
          continue;
        }
        Class<?> userTypeClass = typeAnnotation.value();
        if (userTypeClass == null) {
          continue;
        }
        String userTypeName = userTypeClass.getName();
        if (userTypeName != null && userTypeName.startsWith(JSON_USERTYPE_CLASS_PREFIX)) {
          this.jsonProperties.add(field.getName());
        }
      }
      current = current.getSuperclass();
    }
  }

  protected final PersistentClass persistentClass;

  protected String name;

  protected boolean customFieldEnabled;

  protected final List<String> translatables = new ArrayList<>();

  protected final List<String> webhookTargetTypes = new ArrayList<>();

  protected final Map<String, String> joinProperties = new HashMap<>();

  /**
   * 0.0.10.I Round 2 (BUG-032): {@code @Type(JsonType.class)} 등 hypersistence-utils 기반 JSON
   * UserType 으로 선언된 field 이름 집합. {@code QueryParser#buildJoinPath} 가 dot-notation 의
   * 첫 segment 가 여기에 속하면 association join 으로 분해하지 않고 JSON path 표현식으로 빌드한다.
   */
  protected final Set<String> jsonProperties = new HashSet<>();

}
