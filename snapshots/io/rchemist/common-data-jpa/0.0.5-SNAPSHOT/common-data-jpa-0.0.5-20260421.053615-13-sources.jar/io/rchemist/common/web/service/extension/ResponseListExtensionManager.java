/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.extension;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionManager;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.RevisionEntityWrapper;
import io.rchemist.common.web.service.type.RevisionType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * ResponseEntityListService 에서 전체 Entity 에 공통으로 처리할 extension logic 을 확장처리하기 위해 사용하는 ExtensionManager
 * 인터페이스 ResponseEntityListService 에서 직접 호출할 수 있는 static method 를 가진다.
 * interface 만으로는 Bean 을 주입 받을 수 없기 때문이다.
 * 이때 캐싱에 대해서는 실시간, DB CUD 에 대해서는 async 로 처리한다.
 *
 * Created by kunner
 **/
@Service(ResponseListExtensionManager.BEAN_NAME)
@Slf4j
public class ResponseListExtensionManager extends ExtensionManager<ResponseListExtensionHandler> {

  public static final String BEAN_NAME = "rcmResponseListExtensionManager";

  private static ResponseListExtensionManager manager;

  // ResponseListExtensionHandler 의 async 처리를 위한 서비스
  private static AsyncResponseListExtensionService asyncResponseListExtensionService;

  public ResponseListExtensionManager() {
    super(ResponseListExtensionHandler.class);
  }

  static ResponseListExtensionManager getManager() {
    if (manager == null) {
      manager = ApplicationContextHolder.getBean(ResponseListExtensionManager.class);
    }
    return manager;
  }

  static AsyncResponseListExtensionService getAsyncResponseListExtensionService() {
    if (asyncResponseListExtensionService == null) {
      asyncResponseListExtensionService = ApplicationContextHolder.getBean(AsyncResponseListExtensionService.class);
    }
    return asyncResponseListExtensionService;
  }

  public static void clearEntityCache(Object... ids) {
    try {
      ResponseListExtensionManager extensionManager = getManager();
      if (extensionManager != null) {
        extensionManager.getProxy().clearEntityCache(ids);
      } else {
        log.warn("ResponseListExtensionManager is not found, clearEntityCache Extension is skipped");
      }
    }catch (Exception e) {
      throw e;
    }
  }

  public static void clearSearchResultCache() {
    try {
      ResponseListExtensionManager extensionManager = getManager();
      if (extensionManager != null) {
        extensionManager.getProxy().clearSearchResultCache();
      } else {
        log.warn("ResponseListExtensionManager is not found, clearSearchResultCache Extension is skipped");
      }
    }catch (Exception e) {
      log.warn("clearSearchResultCache failed: {}", e.getMessage());
      log.debug("stack trace", e);
    }
  }


  public static void logEntityViewRevision(String userId, String userName, RevisionType revisionType, String revisionEntityName, HasIdEntity<?> entity, RevisionEntityWrapper<?> form, HasIdEntity<?> view) {
    if (!WebRequestContext.isAnonymous() && WebRequestContext.getWebRequestContext().isAdmin()) {
      getAsyncResponseListExtensionService().asyncUpdateEntityRevision(userId, userName, revisionType, revisionEntityName, entity, form, view);
    }
  }

  public static void logEntityDeleteRevisionById(String userId, String userName, String revisionEntityName, Object id) {
    if (!WebRequestContext.isAnonymous() && WebRequestContext.getWebRequestContext().isAdmin()) {
      getAsyncResponseListExtensionService().asyncDeleteEntityRevisionById(userId, userName, revisionEntityName, id);
    }
  }

  public static <ENTITY extends HasIdEntity<?>> void checkAdditionalPermission(
      RevisionType revisionType, ENTITY entity, RevisionEntityWrapper<?> form) {
    if (!WebRequestContext.isAnonymous() && WebRequestContext.getWebRequestContext().isAdmin()) {
      getManager().getProxy().checkAdditionalPermission(revisionType, entity, form);
    }
  }
}
