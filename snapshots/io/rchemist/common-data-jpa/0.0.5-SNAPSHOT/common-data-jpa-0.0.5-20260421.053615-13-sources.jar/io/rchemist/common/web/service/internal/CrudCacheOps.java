/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.internal;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.data.SortedPriority;
import io.rchemist.common.persistence.jpa.domain.template.Priority;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityService;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.type.EntityViewType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.transaction.annotation.Transactional;

public interface CrudCacheOps<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> extends
    EntityCacheOps<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION>,
    SearchResultCacheOps<VIEW, SEARCH_FORM, ID, SERVICE_EXCEPTION> {

  @Override
  default ENTITY save(ENTITY entity) {
    try {
      return EntityCacheOps.super.save(entity);
    } finally {
      try {
        clearEntityCache(entity.getId());
        clearSearchResultCache();
      } catch (Exception e) {
        ExceptionUtil.printException(e);
      }
    }
  }

  @Override
  default List<ENTITY> saveAll(List<ENTITY> entities) {
    if (CollectionUtils.isEmpty(entities)) {
      return new ArrayList<>();
    }
    try {
      return EntityCacheOps.super.saveAll(entities);
    } finally {
      List<ID> list = new ArrayList<>();
      for (ENTITY entity : entities) {
        list.add(entity.getId());
      }
      clearEntityCache(list);
      clearSearchResultCache();
    }
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default boolean delete(ENTITY entity) {
    try {
      return EntityCacheOps.super.delete(entity);
    } finally {
      clearEntityCache(entity.getId());
      clearSearchResultCache();
    }
  }

  @Override
  default VIEW create(CREATE_FORM createForm) throws SERVICE_EXCEPTION {
    VIEW view = EntityCacheOps.super.create(createForm);
    if (useSearchResultCache()) {
      getSearchResultCache().clear();
    }
    view = overrideView(view, createForm.getViewType() == null ? EntityViewType.VIEW : createForm.getViewType());
    return view;
  }

  @Override
  default VIEW update(UPDATE_FORM form) throws SERVICE_EXCEPTION {
    VIEW view = EntityCacheOps.super.update(form);
    view = overrideView(view, form.getViewType() == null ? EntityViewType.VIEW : form.getViewType());
    clearEntityCache(view.getId());
    clearSearchResultCache();
    return view;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default List<VIEW> createEntities(List<CREATE_FORM> createForms) throws SERVICE_EXCEPTION {
    List<VIEW> result = new ArrayList<>();
    List<ENTITY> entities = new ArrayList<>();
    for (CREATE_FORM createForm : CollectionUtils.emptyIfNull(createForms)) {
      ENTITY entity = createEntity(createForm);
      entities.add(entity);
    }

    entities = saveAll(entities);

    for (ENTITY entity : entities) {
      result.add(getView(entity, EntityViewType.VIEW));
    }

    if (entities.size() == createForms.size()) {
      for (int i = 0; i < entities.size(); i++) {
        ENTITY entity = entities.get(i);
        CREATE_FORM createForm = createForms.get(i);
        postCreate(entity, createForm);
      }
    }

    return result;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default List<VIEW> updateEntities(List<UPDATE_FORM> updateForms) throws SERVICE_EXCEPTION {
    List<VIEW> result = new ArrayList<>();
    List<ENTITY> entities = new ArrayList<>();
    for (UPDATE_FORM updateForm : CollectionUtils.emptyIfNull(updateForms)) {
      ENTITY entity = EntityCacheOps.super.findEntityById(updateForm.getId());
      entity = updateEntity(entity, updateForm);
      entities.add(entity);
    }

    entities = saveAll(entities);

    for (ENTITY entity : entities) {
      for (UPDATE_FORM updateForm : CollectionUtils.emptyIfNull(updateForms)) {
        if (updateForm.getId().equals(entity.getId())) {
          postUpdate(entity, updateForm);
          break;
        }
      }
    }

    return result;
  }

  default DeleteForm<ID> preDeleteAllBySearchForm(DeleteForm<ID> idList, SEARCH_FORM searchForm) throws SERVICE_EXCEPTION {
    if (idList == null || idList.isEmpty() || searchForm == null) {
      return idList;
    }

    ResponseListData<VIEW, SEARCH_FORM> result = createResponseListData(searchForm);

    if (result.isEmpty()) {
      throw entityNotFoundException();
    }

    List<ID> ids = result.getData().stream().map(VIEW::getId).collect(Collectors.toList());

    return new DeleteForm<ID>()
        .withIds(ids)
        .withRevisionEntityName(idList.getRevisionEntityName())
        .withCause(idList.getCause());
  }

  default DeleteForm<ID> preDeleteAllBySearchForm(DeleteForm<ID> idList) throws SERVICE_EXCEPTION {
    return preDeleteAllBySearchForm(idList, preDeleteSearchForm(idList));
  }

  default SEARCH_FORM preDeleteSearchForm(DeleteForm<ID> idList) throws SERVICE_EXCEPTION {
    return null;
  }

  @Override
  default Integer deleteAll(DeleteForm<ID> deleteForm, Boolean batch) throws SERVICE_EXCEPTION {
    try {
      deleteForm = preDeleteAllBySearchForm(deleteForm);
    } catch (ErrorTypeException e) {
      throw new RuntimeException(e);
    }

    List<ENTITY> entities = new ArrayList<>();
    for (ID id : deleteForm.getIds()) {
      try {
        ENTITY entity = findEntityById(id);
        preDelete(entity);
        entities.add(entity);
      } catch (ErrorTypeException e) {
        throw new RuntimeException(e);
      }
    }

    int result = EntityCacheOps.super.deleteAll(deleteForm, batch);
    for (ENTITY entity : entities) {
      clearEntityCache(entity.getId());
      logEntityDeleteRevision(deleteForm.getRevisionEntityName(), entity);
      postDelete(entity, true);
    }
    clearSearchResultCache();
    return result;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default Integer deleteAll(DeleteForm<ID> list) throws SERVICE_EXCEPTION {
    return deleteAll(list, true);
  }

  @Transactional(rollbackFor = ErrorTypeException.class)
  default ResponseData<Boolean> updateEntityPriorities(SortedPriority<ID> priorities) {
    return ResponseHelper.result(() -> {
      if (priorities == null || priorities.isEmpty()) {
        return false;
      }

      List<ENTITY> entities = new ArrayList<>();
      for (ID id : priorities.getIds()) {
        ENTITY entity = findEntityById(id);
        if (entity instanceof Priority<?> priority) {
          priority.setPriority(priorities.getPriority(id));
        }
        entities.add(entity);
      }

      saveAll(entities);
      return true;
    });
  }
}
