/**
 * <strong>0.1.0 에서 신규 모듈/패키지로 이동 예정.</strong>
 *
 * <p>SearchForm 의존 역전 해소의 일환으로 본 패키지의 HTTP request 보조 클래스들도 함께
 * 재배치된다. common-data-jpa 가 HTTP 개념을 직접 참조하지 않도록 계층 정돈을 마무리한다.
 *
 * <p>마이그레이션 가이드: {@code documents/refactor/CHANGELOG.md}.
 */
package io.rchemist.common.web.request;
