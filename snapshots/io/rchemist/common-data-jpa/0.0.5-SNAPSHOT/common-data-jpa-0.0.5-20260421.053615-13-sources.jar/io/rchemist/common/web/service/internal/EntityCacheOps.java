/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.internal;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.service.ResponseEntityService;
import io.rchemist.common.web.service.ResponseListWrapperService;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.extension.ResponseListExtensionManager;
import io.rchemist.common.web.service.type.EntityViewType;
import java.io.Serializable;
import java.util.List;
import javax.cache.Cache;

public interface EntityCacheOps<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> extends
    ResponseEntityService<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION>,
    ResponseListWrapperService<ENTITY, SEARCH_FORM, VIEW, ID, SERVICE_EXCEPTION> {

  String CACHE_KEY_SPLITTER = "_";
  String ADMIN_CACHE_KEY = "ADMIN";

  // 두 super interface 가 getEntityBean 을 동시에 default 로 제공해 발생하는 diamond 를
  // 이 지점에서 해소한다. 구현은 원래 본체에 있던 것과 동일.
  @Override
  default EntityBean<?> getEntityBean(String entityClassName) {
    return PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(entityClassName);
  }

  // ResponseEntityService.super 경로의 default 를 명시적으로 선택해 diamond 를 해소한다.
  @Override
  default PageResult<ENTITY> getSearchResult(SEARCH_FORM searchForm) throws SERVICE_EXCEPTION {
    return ResponseEntityService.super.getSearchResult(searchForm);
  }

  /**
   * LocalCacheManager 를 이용한 ENTITY VIEW 캐싱 처리 사용 여부
   */
  default boolean useEntityCache() {
    return getEntityCache() != null;
  }

  /**
   * Entity Cache 를 사용하려면 직접 생성한다.
   */
  default Cache<String, VIEW> getEntityCache() {
    return null;
  }

  default String getEntityCacheKey(Object id) {
    return getEntityCacheKey(id, EntityViewType.VIEW);
  }

  default String getEntityCacheKey(Object id, EntityViewType viewType) {
    return getEntityCacheKey(id, viewType, WebRequestContext.getWebRequestContext().isAdmin());
  }

  default String getEntityCacheKey(Object id, EntityViewType viewType, boolean isAdmin) {
    String cacheKey = this.getClass().getSimpleName() + CACHE_KEY_SPLITTER + id + CACHE_KEY_SPLITTER + viewType.name();
    if (isAdmin) {
      return cacheKey + CACHE_KEY_SPLITTER + ADMIN_CACHE_KEY;
    }
    return cacheKey;
  }

  default void clearEntityCache(List<ID> ids) {
    for (ID id : ids) {
      clearEntityCache(id);
    }
  }

  default void clearEntityCache(ID id) {
    if (useEntityCache()) {
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.VIEW, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.VIEW, false));
      } catch (Exception e) {
        // silent ignore
      }
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.LIST, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.LIST, false));
      } catch (Exception e) {
        // silent ignore
      }
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.DETAIL, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.DETAIL, false));
      } catch (Exception e) {
        // silent ignore
      }
    }
    try {
      ResponseListExtensionManager.clearEntityCache(id);
    } catch (Exception e) {
      // silent ignore
    }
  }

  default VIEW findCachedViewById(ID id, EntityViewType entityViewType) throws SERVICE_EXCEPTION {

    String cacheKey = null;

    if (useEntityCache()) {
      cacheKey = getEntityCacheKey(id, entityViewType);
      if (getEntityCache().containsKey(cacheKey)) {
        VIEW view = getEntityCache().get(cacheKey);
        return overrideView(view, entityViewType);
      }
    }

    VIEW view = getView(findEntityById(id), entityViewType == null ? EntityViewType.LIST : entityViewType);

    if (useEntityCache()) {
      getEntityCache().put(cacheKey, view);
    }

    return overrideView(view, entityViewType);
  }

  @Override
  default VIEW findViewById(ID id) throws SERVICE_EXCEPTION {
    return findCachedViewById(id, EntityViewType.VIEW);
  }

  @Override
  default VIEW findViewById(ID id, EntityViewType entityViewType) throws SERVICE_EXCEPTION {
    return findCachedViewById(id, entityViewType);
  }
}
