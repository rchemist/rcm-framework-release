/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Slf4j
public class QueryParser<T> implements Serializable {

  private final CriteriaBuilder builder;

  private final Root<T> root;

  private final List<QueryConditionItem> conditionItems;

  private final Map<String, Join<T, ?>> joinPaths;

  private final Class<?> entityClass;

  private final String entityClassName;

  public QueryParser(Class<?> entityClass, CriteriaBuilder builder, Root<T> root, Map<String, Join<T, ?>> joinPaths, List<QueryConditionItem> items) {
    this.entityClass = entityClass;
    this.entityClassName = entityClass.getName();
    this.builder = builder;
    this.root = root;
    this.joinPaths = joinPaths;
    this.conditionItems = items;

    parse();

  }

  private void parse(){

  }

  public Predicate getPredicate(ConditionOperatorType operatorType){
    List<Predicate> predicate = new ArrayList<>();


    for(QueryConditionItem item : conditionItems){

      Predicate itemPredicate = getPredicate(operatorType, item);

      if(itemPredicate != null){
        predicate.add(itemPredicate);
      }

    }

    if(operatorType.isMust()){
      return builder.and(predicate.toArray(new Predicate[0]));
    }else{
      return builder.and(builder.or(predicate.toArray(new Predicate[0])));
    }

  }

  protected Predicate getPredicate(ConditionOperatorType parentOperatorType, QueryConditionItem item){
    if(item instanceof CombinedConditionItem combinedItem){

      ConditionOperatorType operatorType = combinedItem.getOperatorType();

      List<Predicate> predicates = new ArrayList<>();

      for(QueryConditionItem subItem : combinedItem.getSubConditions()){
        Predicate subPredicate = getPredicate(operatorType, subItem);

        if(subPredicate != null){
          predicates.add(subPredicate);
        }

      }

      if(!predicates.isEmpty()){
        if(operatorType.isMust()){
          return builder.and(predicates.toArray(new Predicate[0]));
        }else{
          return builder.or(predicates.toArray(new Predicate[0]));
        }
      }

      return null;

    }else{
      SingleConditionItem singleConditionItem = (SingleConditionItem) item;

      // 0.0.10.I Round 3 (BUG-032): dot-notation 의 첫 segment 가 JSON 컬럼 (@Type(JsonType.class))
      //   이면 association join 경로 대신 dialect 별 JSON 함수 호출 경로로 predicate 를 직접 빌드한다.
      Predicate jsonPredicate = tryBuildJsonPredicate(singleConditionItem);
      if (jsonPredicate != null) {
        return jsonPredicate;
      }

      // 1. Path 생성 (JOIN 포함)
      Path path = getPath(root, singleConditionItem);
      if (path == null) {
        return null;
      }

      // 2. Predicate 생성
      Predicate predicate = singleConditionItem.getPredicate(builder, path);
      if (predicate == null) {
        return null;
      }

      // 3. 적용 위치 결정 및 적용
      return handlePredicateApplication(path, predicate, singleConditionItem);
    }
  }

  /**
   * 0.0.10.I Round 3 (BUG-032): JSON 컬럼 dot-notation 을 dialect 별 JSON 함수 호출로 치환한다.
   * 대상 여부 판정:
   * <ul>
   *   <li>propertyName 에 dot 이 포함되어 있어야 한다.</li>
   *   <li>첫 segment 가 현재 entityClass (또는 root alias 스트립 후 entityClass) 의 JSON 컬럼이어야 한다.</li>
   *   <li>기존 {@code withJsonFilter(true)} 경로 (LIKE 기반 문자열 매칭) 는 하위 호환을 위해 그대로 둔다.
   *       호출 측이 명시적으로 isJsonFilter 를 켠 경우 SingleConditionItem#getPredicate 가 처리하도록
   *       그대로 넘긴다.</li>
   * </ul>
   *
   * @return 매칭되는 경우 JSON 함수 기반 Predicate. 아니면 null (기존 경로로 fallback).
   */
  private Predicate tryBuildJsonPredicate(SingleConditionItem item) {
    // 1. 명시적 isJsonFilter=true 는 기존 LIKE 기반 JSON 매칭 경로로 넘긴다 (호환성).
    if (item.isJsonFilter()) {
      return null;
    }

    String rawPropertyName = item.getPropertyName();
    if (StringUtils.isBlank(rawPropertyName) || !rawPropertyName.contains(".")) {
      return null;
    }

    // 2. alias prefix 스트립: propertyName 이 "alias:realPath" 또는 "alias.rest" 형식일 때
    //    실제 entityClass 기준 경로를 추출한다.
    String resolvedPropertyName = resolvePropertyNameForJsonCheck(rawPropertyName);
    if (resolvedPropertyName == null) {
      return null;
    }

    String firstSegment = StringUtils.substringBefore(resolvedPropertyName, ".");
    String jsonPath = StringUtils.substringAfter(resolvedPropertyName, ".");
    if (StringUtils.isBlank(firstSegment) || StringUtils.isBlank(jsonPath)) {
      return null;
    }

    if (!PlatformSessionFactoryBuilderFactory.isJsonProperty(entityClassName, firstSegment)) {
      return null;
    }

    // 3. dialect 판정 + JSON 함수 expression 빌드.
    JsonColumnDialect dialect = JsonColumnDialect.fromDialectClassName(
        PlatformSessionFactoryBuilderFactory.getCachedDialectClassName());
    if (dialect == JsonColumnDialect.UNSUPPORTED) {
      // dialect 가 지원 목록에 없으면 안전하게 기존 경로로 fallback.
      log.debug("Unsupported dialect for JSON dispatch — falling back to default path for property '{}'",
          resolvedPropertyName);
      return null;
    }

    Path<?> jsonColumn = root.get(firstSegment);

    // 0.0.10.I Round 3 (BUG-032): H2 2.2.224 는 JSON_VALUE 미지원이다. hypersistence-utils JsonType
    //   이 H2 에서 JSON 을 VARCHAR 문자열로 직렬화해 저장하므로, H2 경로는 LIKE 기반의 JSON 문자열
    //   매칭 ({@code %"key":"value"%}) 으로 fallback 한다. 기존 isJsonFilter=true 경로와 같은 패턴.
    if (dialect == JsonColumnDialect.H2) {
      return buildJsonLikePredicate(item, jsonColumn, jsonPath);
    }

    Expression<String> jsonValue = buildJsonPathExpression(dialect, jsonColumn, jsonPath);
    return buildJsonPredicate(item, jsonValue);
  }

  /**
   * 0.0.10.I Round 3 (BUG-032): H2 fallback — JSON 컬럼을 문자열로 간주하고 LIKE 매칭.
   * 지원 conditionType: EQUAL / NOT_EQUAL / LIKE / NOT_LIKE / NULL / NOT_NULL.
   * 기존 {@code SingleConditionItem#isJsonFilter} 경로와 동일한 패턴을 재사용.
   */
  private Predicate buildJsonLikePredicate(SingleConditionItem item, Path<?> jsonColumn,
      String jsonPath) {
    // jsonPath 는 내부 dot 을 포함할 수 있으나 (metadata.nested.key), H2 fallback 은 첫 key 기준
    //   단일 레벨 JSON 매칭만 의미가 있다. 중첩 JSON 은 Postgres / MySQL 환경에서 native 함수로
    //   처리되고, H2 는 dev/smoke 용도이므로 첫 key 만 사용해도 회귀 테스트 수준에서는 충분.
    String leafKey = jsonPath.contains(".") ? jsonPath.substring(jsonPath.lastIndexOf('.') + 1) : jsonPath;
    // jsonColumn 의 선언 타입이 Map 이므로 LIKE 대상이 될 수 없다. String cast 로 JSON 저장 문자열을
    // 그대로 비교하도록 강제한다 (hypersistence-utils JsonType 이 H2 환경에서는 VARCHAR 로 직렬화).
    Expression<String> stringColumn = jsonColumn.as(String.class);
    String keyLiteral = "\"" + leafKey + "\":";
    switch (item.getConditionType()) {
      case EQUAL:
      case LIKE:
        return builder.like(stringColumn, "%" + keyLiteral + "\"" + item.getValue() + "\"%");
      case NOT_EQUAL:
      case NOT_LIKE:
        return builder.notLike(stringColumn, "%" + keyLiteral + "\"" + item.getValue() + "\"%");
      case NULL:
        return builder.notLike(stringColumn, "%" + keyLiteral + "%");
      case NOT_NULL:
        return builder.like(stringColumn, "%" + keyLiteral + "%");
      default:
        log.debug("H2 JSON fallback 은 condition type '{}' 를 지원하지 않는다. fallback 실패.",
            item.getConditionType());
        return null;
    }
  }

  /**
   * propertyName 의 alias prefix / 별칭 (":") 을 정리해 JSON 판정에 쓸 경로를 반환한다.
   * {@code "metadata.type"} → {@code "metadata.type"},
   * {@code "displayName:metadata.type"} → {@code "metadata.type"}.
   * 결과가 dot 을 포함하지 않으면 JSON 분기 대상이 아니므로 {@code null}.
   */
  private String resolvePropertyNameForJsonCheck(String rawPropertyName) {
    String name = StringUtil.subStringAfter(rawPropertyName, ":");
    if (StringUtils.isBlank(name) || !name.contains(".")) {
      return null;
    }
    return name;
  }

  /**
   * dialect 별 JSON path 조회 함수 expression 을 빌드한다.
   * Postgres: {@code jsonb_extract_path_text(col, key1, key2, ...)} — 각 segment 를 가변 인수로 전달.
   * MySQL: {@code json_unquote(json_extract(col, '$.k1.k2'))} — 하나의 path 문자열로 묶음.
   * H2: {@code json_value(col, '$.k1.k2')}.
   */
  private Expression<String> buildJsonPathExpression(JsonColumnDialect dialect, Path<?> column,
      String jsonPath) {
    switch (dialect) {
      case POSTGRES: {
        String[] segments = StringUtils.split(jsonPath, ".");
        Expression<?>[] args = new Expression<?>[segments.length + 1];
        args[0] = column;
        for (int i = 0; i < segments.length; i++) {
          args[i + 1] = builder.literal(segments[i]);
        }
        return builder.function("jsonb_extract_path_text", String.class, args);
      }
      case MYSQL: {
        Expression<String> extracted = builder.function(
            "json_extract", String.class, column, builder.literal("$." + jsonPath));
        return builder.function("json_unquote", String.class, extracted);
      }
      case H2: {
        return builder.function(
            "json_value", String.class, column, builder.literal("$." + jsonPath));
      }
      default:
        throw new IllegalStateException("Unsupported JSON dialect: " + dialect);
    }
  }

  /**
   * JSON path expression 과 conditionType 을 조합해 Predicate 를 생성한다.
   * EQUAL / NOT_EQUAL / LIKE / NOT_LIKE / NULL / NOT_NULL / IN / NOT_IN 을 지원.
   */
  private Predicate buildJsonPredicate(SingleConditionItem item, Expression<String> jsonValue) {
    Object value = item.getValue();
    String stringValue = value == null ? null : String.valueOf(value);
    switch (item.getConditionType()) {
      case EQUAL:
        return builder.equal(jsonValue, stringValue);
      case NOT_EQUAL:
        return builder.notEqual(jsonValue, stringValue);
      case LIKE:
        return builder.like(jsonValue, stringValue);
      case NOT_LIKE:
        return builder.notLike(jsonValue, stringValue);
      case NULL:
        return builder.isNull(jsonValue);
      case NOT_NULL:
        return builder.isNotNull(jsonValue);
      case IN: {
        List<?> values = value instanceof List ? (List<?>) value :
            value != null && value.getClass().isArray() ? Arrays.asList((Object[]) value) :
            value != null ? List.of(value) : List.of();
        CriteriaBuilder.In<String> in = builder.in(jsonValue);
        for (Object v : values) {
          in.value(v == null ? null : String.valueOf(v));
        }
        return in;
      }
      case NOT_IN: {
        List<?> values = value instanceof List ? (List<?>) value :
            value != null && value.getClass().isArray() ? Arrays.asList((Object[]) value) :
            value != null ? List.of(value) : List.of();
        CriteriaBuilder.In<String> in = builder.in(jsonValue);
        for (Object v : values) {
          in.value(v == null ? null : String.valueOf(v));
        }
        return in.not();
      }
      default:
        log.debug("JSON dispatch 는 condition type '{}' 를 아직 지원하지 않는다. 기존 경로로 fallback.",
            item.getConditionType());
        return null;
    }
  }

  /**
   * Predicate를 ON절 또는 WHERE절에 적용하는 로직을 처리합니다.
   *
   * @param path 대상 경로
   * @param predicate 적용할 조건
   * @param conditionItem 조건 아이템
   * @return WHERE절에 적용할 Predicate (ON절에 적용된 경우 null 반환)
   */
  private Predicate handlePredicateApplication(Path path, Predicate predicate, SingleConditionItem conditionItem) {
    // applyOnClause가 true인 경우 ON절에 적용 시도
    if (conditionItem.isApplyOnClause()) {
      Join<?, ?> targetJoin = findApplicableJoin(path);

      if (targetJoin != null) {
        // ON절에 조건 적용
        targetJoin.on(predicate);
        return null; // WHERE절에는 추가하지 않음
      } else {
        // JOIN을 찾지 못한 경우 경고 로그 후 WHERE절에 적용
        // ApplyOnClause=true but no applicable JOIN found - applying to WHERE clause instead
      }
    }

    // WHERE절에 적용
    return predicate;
  }

  /**
   * 주어진 Path에서 ON절 조건을 적용할 수 있는 JOIN을 찾습니다.
   *
   * @param path 대상 경로
   * @return 적용 가능한 JOIN 객체, 없으면 null
   */
  private Join<?, ?> findApplicableJoin(Path path) {
    // 1. path의 직접 부모가 Join인 경우
    if (path.getParentPath() instanceof Join) {
      return (Join<?, ?>) path.getParentPath();
    }

    // 2. path 자체가 Join인 경우
    if (path instanceof Join) {
      return (Join<?, ?>) path;
    }

    // 3. path의 상위 경로들을 순회하여 Join 찾기
    Path currentPath = path;
    while (currentPath.getParentPath() != null) {
      if (currentPath.getParentPath() instanceof Join) {
        return (Join<?, ?>) currentPath.getParentPath();
      }
      currentPath = currentPath.getParentPath();
    }

    return null;
  }

  protected Path getPath(Root<T> root, SingleConditionItem conditionItem) {
    String propertyName = conditionItem.isJsonFilter()
        ? StringUtils.substringBefore(conditionItem.getPropertyName(), ".")
        : conditionItem.getPropertyName();

    JoinType joinType = conditionItem.getJoinType();

    // 기본값 처리
    if (StringUtils.isEmpty(propertyName)) {
      return root;
    }

    // 별칭 제거 (propertyName:actualPath 형태에서 actualPath 추출)
    propertyName = StringUtil.subStringAfter(propertyName, ":");

    // 0.0.10.I Round 3 (BUG-033): UnmappedJoin context 에서 root 의 alias 가 설정된 경우
    //   additionalCondition 의 propertyName 이 "alias.rest" 형태로 들어올 수 있다.
    //   첫 segment 가 root alias 와 일치하면 스트립해 이후 "rest" 를 attribute 경로로 해석한다.
    //   Root.getAlias() 는 UnmappedJoinItem 이 join.alias(joinAlias) 로 명시 설정한 경우에만 존재.
    propertyName = stripRootAliasPrefix(root, propertyName);

    // 단순 필드인 경우 (JOIN이 필요하지 않은 경우)
    if (!StringUtils.contains(propertyName, ".")) {
      return root.get(propertyName);
    }

    // JOIN이 필요한 복합 경로 처리
    return buildJoinPath(root, propertyName, joinType);
  }

  /**
   * 0.0.10.I Round 3 (BUG-033): propertyName 의 첫 segment 가 root 의 alias 와 일치하면 스트립한다.
   * UnmappedJoin 의 additionalCondition 에서 흔히 나타나는 패턴 ("related.relatedType") 대응.
   * alias 가 없거나 segment 가 일치하지 않으면 원본을 그대로 반환.
   */
  private String stripRootAliasPrefix(Root<T> root, String propertyName) {
    String alias = safeGetAlias(root);
    if (StringUtils.isBlank(alias) || !propertyName.contains(".")) {
      return propertyName;
    }
    String firstSegment = StringUtils.substringBefore(propertyName, ".");
    if (!StringUtils.equals(firstSegment, alias)) {
      return propertyName;
    }
    String remainder = StringUtils.substringAfter(propertyName, ".");
    log.debug("Stripped root alias '{}' from propertyName — '{}' -> '{}'",
        alias, propertyName, remainder);
    return remainder;
  }

  /**
   * Root 의 alias 를 안전하게 얻는다. Hibernate 에 따라 getAlias() 가 null 또는 빈 문자열일 수 있다.
   */
  private String safeGetAlias(Root<T> root) {
    try {
      return root.getAlias();
    } catch (Throwable t) {
      return null;
    }
  }

  /**
   * 복합 경로에 대해 적절한 JOIN을 생성하고 최종 Path를 반환합니다.
   *
   * @param root 엔티티 루트
   * @param propertyName 복합 경로 (예: "parent.name")
   * @param joinType JOIN 타입
   * @return 최종 Path 객체
   */
  private Path buildJoinPath(Root<T> root, String propertyName, JoinType joinType) {
    // 기본 JOIN 타입 설정
    joinType = (joinType == null) ? JoinType.INNER : joinType;

    String[] pathParts = StringUtil.split(propertyName, ".").toArray(new String[0]);
    Path currentPath = root;
    // 조인 경로를 순회하면서 현재 엔티티 클래스를 추적한다.
    // 루트 엔티티에서 시작하여, 조인이 발생할 때마다 대상 엔티티 클래스로 갱신한다.
    String currentEntityClassName = entityClassName;

    for (int i = 0; i < pathParts.length; i++) {
      String pathPart = pathParts[i];

      if (i < pathParts.length - 1) {
        // 중간 경로: JOIN이 필요한지 확인 (현재 엔티티 기준으로 체크)
        boolean isJoinedProperty = PlatformSessionFactoryBuilderFactory.isJoinedProperty(currentEntityClassName, pathPart);

        if (isJoinedProperty) {
          currentPath = getOrCreateJoin(currentPath, pathPart, joinType);
          // 조인 대상 엔티티 클래스로 갱신
          currentEntityClassName = currentPath.getJavaType().getName();
        } else {
          // 일반 필드 접근
          currentPath = currentPath.get(pathPart);
        }
      } else {
        // 최종 필드: 단순 접근
        currentPath = currentPath.get(pathPart);
      }
    }

    return currentPath;
  }

  /**
   * 기존 JOIN을 재사용하거나 새로 생성합니다.
   *
   * @param parentPath 부모 경로
   * @param joinProperty JOIN할 속성명
   * @param joinType JOIN 타입
   * @return JOIN Path
   */
  private Path getOrCreateJoin(Path parentPath, String joinProperty, JoinType joinType) {
    String joinMapKey = generateJoinKey(parentPath, joinProperty, joinType);

    // 기존 JOIN 재사용
    if (joinPaths.containsKey(joinMapKey)) {
      return joinPaths.get(joinMapKey);
    }

    // 새로운 JOIN 생성
    Join<?, ?> join;
    if (parentPath instanceof Root) {
      join = ((Root<?>) parentPath).join(joinProperty, joinType);
    } else if (parentPath instanceof Join) {
      join = ((Join<?, ?>) parentPath).join(joinProperty, joinType);
    } else {
      throw new IllegalArgumentException("Cannot create join from path type: " + parentPath.getClass());
    }

    // JOIN 캐시에 저장
    joinPaths.put(joinMapKey, (Join<T, ?>) join);

    // Created JOIN for property with specified type

    return join;
  }

  /**
   * JOIN 캐시 키를 생성합니다.
   *
   * @param parentPath 부모 경로
   * @param joinProperty JOIN할 속성명
   * @param joinType JOIN 타입
   * @return 캐시 키
   */
  private String generateJoinKey(Path parentPath, String joinProperty, JoinType joinType) {
    String parentAlias = (parentPath instanceof Root) ? "root" : parentPath.getAlias();
    return String.format("%s.%s||%s", parentAlias, joinProperty, joinType.name());
  }


}
