/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.type.PublishStatusType;
import io.rchemist.common.util.TSIDUtil;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface Version<T> extends ClassTransformTarget {

  default String getVersion() {
    throw new ClassTransformException();
  }

  default void setVersion(String version) {
    throw new ClassTransformException();
  }

  default void createNewVersion() {
    setVersion(TSIDUtil.tsId());
  }

  default T withVersion(String version) {
    setVersion(version);
    return (T) this;
  }

  default PublishStatusType getPublishStatus() {
    throw new ClassTransformException();
  }

  default void setPublishStatus(PublishStatusType publishStatusType) {
    throw new ClassTransformException();
  }

  default T withPublishStatus(PublishStatusType publishStatusType) {
    setPublishStatus(publishStatusType);
    return (T) this;
  }

}
