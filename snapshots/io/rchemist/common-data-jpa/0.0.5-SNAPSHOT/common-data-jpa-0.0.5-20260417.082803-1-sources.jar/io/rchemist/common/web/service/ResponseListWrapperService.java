/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.util.FieldHelper;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.type.EntityViewType;
import java.util.Map;
import java.util.Map.Entry;

/**
 * ResponseListData 를 생성할 때 사용되는 반복적인 코드를 제거하여 효율적인 코드를 만들기 위한 WrapperService
 *
 * #getSearchResult() 에서는 SearchForm 을 이용하여 Page 객체를 생성하여 반환한다.
 * #getView() 에서는 Page 에서 생성된 Entity 를 이용하여 View 객체를 생성하여 반환한다.
 *
 * 위 두개의 메소드만 구현하면 자동으로 ResponseListData 를 생성할 수 있다.
 * 컨트롤러나 ManageService 에서 #createResponseListData() 만 호출하면 된다.
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ResponseListWrapperService<ENTITY extends HasIdEntity<ID>, SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>, VIEW extends HasIdEntity<ID>, ID, SERVICE_EXCEPTION extends ErrorTypeException> {

  PageResult<ENTITY> getSearchResult(SEARCH_FORM searchform) throws SERVICE_EXCEPTION;

  VIEW getView(ENTITY item, EntityViewType viewType) throws SERVICE_EXCEPTION;

  /**
   * Entity Cache 에 저장된 VIEW 를 재정의 할 수 있다.
   * 이렇게 변경된 VIEW 는 캐시에 영향을 주지 않는다.
   *
   * 예를 들어 게시판 -> 게시물의 VIEW 정보를 조회할 때 게시물의 조회수가 DTO 안에 있고, 이 값을 캐시 데이터가 아닌 DB 에서 조회한 값으로 변경하고 싶을 때 사용한다.
   *
   * @param view
   * @param viewType
   * @return
   */
  default VIEW overrideView(VIEW view, EntityViewType viewType) throws SERVICE_EXCEPTION {
    return view;
  }

  default EntityBean<?> getEntityBean(String entityClassName) {
    // override this method if you want to use EntityBean
    return null;
  }


  default ResponseListWrapper<VIEW, SEARCH_FORM> createResponseListWrapper(SEARCH_FORM searchform) {
    try {
      PageResult<ENTITY> result = getSearchResult(searchform);
      return getEntityListView(searchform, result);
    } catch (Exception e) {
      ResponseListWrapper<VIEW, SEARCH_FORM> responseListWrapper = new ResponseListWrapper<>(searchform);
      responseListWrapper.setError(new ErrorDTO(e));
      return responseListWrapper;
    }
  }

  private ResponseListWrapper<VIEW, SEARCH_FORM> getEntityListView(SEARCH_FORM searchform, PageResult<ENTITY> result) {

    EntityViewType viewType = searchform.getEntityViewType();

    // SearchResult 처리가 끝난 후 responseListWrapper 를 생성하면 searchForm.revert 를 따로 처리할 필요가 없다.
    ResponseListWrapper<VIEW, SEARCH_FORM> responseListWrapper = new ResponseListWrapper<>(searchform);

    try {
      responseListWrapper.createResult(result.getPage(), item -> {
        VIEW view = ResponseListWrapperService.this.getView(item, viewType);

        if (!result.isBlankAttributes()) {
          EntityBean<?> registerEntityBean = getEntityBean(result.getEntityClass().getName());
          Map<String, String> attributeFields = registerEntityBean.getAttributeFields();

          for (Entry<String, String> entry : attributeFields.entrySet()) {
            FieldHelper.setValue(view, entry.getValue(), result.getAttributeValues().get(String.valueOf(item.getId())).get(entry.getValue()));
          }

        }
        return overrideView(view, viewType);
      });
    }catch (Exception e) {
      responseListWrapper.setError(new ErrorDTO(e));
    }

    return responseListWrapper;
  }


  default ResponseListData<VIEW, SEARCH_FORM> createResponseListData(SEARCH_FORM searchform) {
    return ResponseHelper.resultList(createResponseListWrapper(searchform));
  }



}

