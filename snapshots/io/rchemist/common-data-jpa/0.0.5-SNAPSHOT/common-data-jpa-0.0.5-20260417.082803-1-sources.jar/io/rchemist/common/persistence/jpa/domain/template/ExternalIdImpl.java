/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(value = ExternalId.class)
@Getter
@Setter
public class ExternalIdImpl implements Serializable, EnhancedTemplate {

  @Column(name = "EXTERNAL_ID")
  @KeywordField(sortable = Sortable.YES)
  /*// @AdminPresentation(friendlyName = "ExternalIdImpl_ExternalID",
      tab = PresentationVariables.Tab.Advanced.TYPE, tabOrder = PresentationVariables.Tab.Advanced.ORDER, order=6000
      , tooltip="ExternalIdImpl_ExternalID_Tooltip"
      , validationConfigurations = {// FieldName is Unique
      @ValidationConfiguration(
          validationImplementation="blUniqueValueValidator"
          , configurationItems = {
          @ConfigurationItem(itemName = ConfigurationItem.ERROR_MESSAGE,itemValue="admin.error.message.duplicated.key")
      })
      , @ValidationConfiguration(
      validationImplementation="blRegexPropertyValidator"
      , configurationItems = {
      @ConfigurationItem(itemName = ConfigurationItem.ERROR_MESSAGE,itemValue= RegexType.Message.NUMBER_ENGLISH_EXT)
      , @ConfigurationItem(itemName = ConfigurationItem.REGEX, itemValue=RegexType.Regex.NUMBER_ENGLISH_EXT)
  })})*/
  @Description(name = "외부 서비스 ID")
  protected String externalId;

  public ExternalIdImpl withExternalId(String externalId) {
    this.externalId = StringUtils.remove(externalId, " ");    // externalId 의 공백은 허용되지 않는다.
    return this;
  }
}
