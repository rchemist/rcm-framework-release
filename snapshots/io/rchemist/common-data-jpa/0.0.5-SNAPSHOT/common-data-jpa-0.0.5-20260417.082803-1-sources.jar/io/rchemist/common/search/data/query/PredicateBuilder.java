/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Responsible for building JPA Predicates from QueryConditions.
 * This class separates the predicate building logic from QuerySpecification 
 * to improve maintainability and testability.
 */
@Slf4j
public class PredicateBuilder<T extends Serializable> {

    /**
     * Builds a Predicate from the given conditions.
     * 
     * @param conditions Map of condition operator types to query conditions
     * @param mustPredicates List to store MUST predicates (AND conditions)
     * @param shouldPredicates List to store SHOULD predicates (OR conditions)
     * @param root JPA root entity
     * @param criteriaBuilder JPA criteria builder
     * @return Combined predicate or null if no conditions
     */
    public Predicate build(Map<ConditionOperatorType, QueryCondition> conditions,
                          List<Predicate> mustPredicates,
                          List<Predicate> shouldPredicates,
                          Root<T> root, 
                          CriteriaBuilder criteriaBuilder) {
        
        if (conditions == null || conditions.isEmpty()) {
            return null;
        }

        // Separate logic for different predicate types would go here
        // This is currently handled by mergeConditions in QuerySpecification
        // For now, we'll build the final predicate from the lists
        
        return buildFinalPredicate(mustPredicates, shouldPredicates, criteriaBuilder);
    }

    /**
     * Combines mustPredicates and shouldPredicates into a final Predicate.
     */
    public Predicate buildFinalPredicate(List<Predicate> mustPredicates,
                                        List<Predicate> shouldPredicates,
                                        CriteriaBuilder criteriaBuilder) {
        Predicate predicate = null;

        // Build AND predicates (MUST conditions)
        if (CollectionUtils.isNotEmpty(mustPredicates)) {
            predicate = criteriaBuilder.and(mustPredicates.toArray(new Predicate[0]));
        }

        // Build OR predicates (SHOULD conditions)
        if (CollectionUtils.isNotEmpty(shouldPredicates)) {
            Predicate shouldPredicate = criteriaBuilder.or(shouldPredicates.toArray(new Predicate[0]));
            
            if (predicate != null) {
                predicate = criteriaBuilder.and(predicate, shouldPredicate);
            } else {
                predicate = shouldPredicate;
            }
        }

        return predicate;
    }

    /**
     * Validates that the built predicate is not null and logs debug information.
     */
    public Predicate validateAndLog(Predicate predicate, String context) {
        if (predicate == null) {
            log.debug("Built predicate is null for context: {}", context);
        } else {
            log.debug("Successfully built predicate for context: {}", context);
        }
        return predicate;
    }
}