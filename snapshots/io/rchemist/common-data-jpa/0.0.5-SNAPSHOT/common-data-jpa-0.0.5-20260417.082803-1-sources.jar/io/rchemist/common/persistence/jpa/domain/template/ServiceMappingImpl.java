/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(ServiceMapping.class)
@Getter
@Setter
public class ServiceMappingImpl implements EnhancedTemplate {

  @Column(name = "SERVICE_ID")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "서비스 ID", comment = "ServiceMapping 을 사용하는 엔티티의 대표 이름. GROUP, GENERAL, ARTICLE 과 같은 서비스의 이름을 나타낸다.")
  protected String serviceId;

  @Column(name = "SERVICE_ALIAS")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "서비스 Alias", comment = "ServiceMapping 을 사용하는 엔티티의 Alias")
  protected String serviceAlias;

  @Column(name = "SERVICE_ENTITY_ID")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "서비스 엔티티 ID", comment = "ServiceMapping 을 사용하는 엔티티의 시퀀스 또는 유니크 ID")
  protected String serviceEntityId;

  /**
   * comment 에서만 사용하는 필드, GENERAL 게시판에는 없지만 ,Group.Board.Article.Comment 의 관계에서 특정 Group 의 모든 Comment 를 조회할 때 사용한다.
   */
  @Column(name = "PARENT_SERVICE_ENTITY_ID")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "부모 서비스 ID", comment = "comment 에서만 사용하는 필드, GENERAL 게시판에는 없지만 ,Group.Board.Article.Comment 의 관계에서 특정 Group 의 모든 Comment 를 조회할 때 사용한다.")
  protected String parentServiceEntityId;

}
