/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider;

import io.rchemist.common.persistence.domain.annotation.type.MappingType;
import io.rchemist.common.persistence.jpa.config.mapping.dto.RelationMappingDTO;
import io.rchemist.common.transformer.dto.TransformCondition;
import io.rchemist.common.transformer.dto.TransformResult;
import io.rchemist.common.transformer.provider.handler.ReplaceMappingHandler;
import io.rchemist.common.util.BytecodeUtil;
import jakarta.persistence.CascadeType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.EnumMemberValue;
import javassist.bytecode.annotation.IntegerMemberValue;
import javassist.bytecode.annotation.MemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class AdjustEntityMappingProvider extends AbstractTemplateBasedClassTransformProvider {

  /**
   * 수행 순서 : 낮을 수록 먼저 시작한다
   * 절대 ValidateRequiredAnnotationProvider 보다 낮은 값을 가질 수 없다
   */
  protected Integer order = 10000;

  protected List<ReplaceMappingHandler> replaceMappingHandlers = new ArrayList<>();

  private static final String TARGET_ANNOTATION = "io.rchemist.common.jpa.domain.annotation.AdjustEntityMapping";

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public TransformResult transformClass(TransformCondition condition, TransformResult result) throws CannotCompileException, ClassNotFoundException {
    try {

      Annotation adjust = BytecodeUtil.getDeclaredAnnotationOnType(result.getTargetClassFile(), TARGET_ANNOTATION);

      if(adjust != null && adjust.getMemberValue("properties") != null){

        ArrayMemberValue properties = (ArrayMemberValue) adjust.getMemberValue("properties");
        List<RelationMappingDTO> relationMappingDTOs = getRealtionMappingInformation(properties);

        if (CollectionUtils.isNotEmpty(relationMappingDTOs)) {
          for (RelationMappingDTO dto : relationMappingDTOs) {

            if(dto.getDeclaredClass().equals(result.getTemplateClass().getName())){
              CtField field = result.getTargetClass().getDeclaredField(dto.getPropertyName());

              boolean adjustMethod = StringUtils.isNotBlank(dto.getTargetMappingClass()) &&
                  !field.getType().getName().equals(dto.getTargetMappingClass());
              CtClass oldFieldType = field.getType();

              adjustFieldMapping(result, dto, field);

              if(adjustMethod){
                /*
                 TODO: Test 시점에서 메소드 시그니쳐의 변경이 정상적으로 수행되지 않는 문제가 있다.
                  메소드 리턴, 파라미터의 signature 변경이 필요한지 테스트 메소드 작성을 통해 확인해야 한다.
                 */
                // adjustMethodReturnType(dto, result, field, oldFieldType);
              }
            }
          }
          // 변경된 내용을 반영한다
          return result.arrangeTransformResult();
        }
      }
    } catch (NotFoundException e) {
      e.printStackTrace();
    }

    return result;
  }

  private void adjustFieldMapping(TransformResult result, RelationMappingDTO dto, CtField field) throws NotFoundException {
    if (dto.getMappingType().equals(MappingType.FIELD)) {
      // 단순 필드라면 mappingEntityType  만 변경한다
      // field.setType(result.getClassPool().get(dto.getTargetMappingClass()));
    } else {
      List<AttributeInfo> attributeInfos = field.getFieldInfo().getAttributes();
      if (CollectionUtils.isNotEmpty(attributeInfos)) {
        for (AttributeInfo info : attributeInfos) {

          if (AnnotationsAttribute.class.isAssignableFrom(info.getClass())) {

            AnnotationsAttribute attribute = (AnnotationsAttribute) info;
            List<Annotation> annotations = new ArrayList<>();

            for (Annotation annotation : attribute.getAnnotations()) {
              Annotation newAnno = new Annotation(annotation.getTypeName(), result.getConstPool());

              for (ReplaceMappingHandler handler : getReplaceMappingHandlers()) {
                newAnno = handler.replaceAnnotationValues(result, dto, annotation, newAnno);
              }
              annotations.add(newAnno);
            }
            attribute.setAnnotations(annotations.toArray(new Annotation[annotations.size()]));

          }

        }
      }
    }
  }

  private void adjustMethodReturnType(RelationMappingDTO dto, TransformResult result, CtField field, CtClass oldFieldType) throws NotFoundException {

    if(dto.getMappingType().equals(MappingType.ONE_TO_ONE)
        || dto.getMappingType().equals(MappingType.MANY_TO_ONE)
        || dto.getMappingType().equals(MappingType.FIELD)){

      CtClass newFieldType = result.getClassPool().get(dto.getTargetMappingClass());
      String newDescriptor = "L"+StringUtils.substringAfter(BytecodeUtil.getProperClassName(newFieldType.getName(), false), "L");

      field.setType(newFieldType);
      //field.setGenericSignature(newDescriptor);

      if(dto.hasReturnTypeMethods()){
        for(String methodName : dto.getReturnTypeMethods()){
          CtMethod method = result.getTargetClass().getDeclaredMethod(methodName);
          replaceMethodDescriptor("()"+newDescriptor, method);
        }
      }

      if(dto.hasParameterTypeMethods()){
        for(String methodName : dto.getParameterTypeMethods()){
          CtMethod method = result.getTargetClass().getDeclaredMethod(methodName);
          replaceMethodDescriptor("("+newDescriptor+")V", method);
        }
      }

      CtMethod[] methods = result.getTargetClass().getDeclaredMethods();

      Iterator<CtMethod> iterators = Arrays.stream(methods).iterator();
      while(iterators.hasNext()){
        CtMethod method = iterators.next();

        if(method.getReturnType() != null && method.getReturnType().equals(oldFieldType)){
          replaceMethodDescriptor("()"+newDescriptor, method);
        }

        if(ArrayUtils.isNotEmpty(method.getParameterTypes())){
          for(CtClass parameterType : method.getParameterTypes()){
            if(parameterType.equals(oldFieldType)){
              replaceMethodDescriptor("("+newDescriptor+")V", method);
            }
          }
        }
      }

    }else if(dto.getMappingType().equals(MappingType.ONE_TO_MANY)){
      // do nothing
    }

  }

  private void replaceMethodDescriptor(String newDescriptor, CtMethod method) {
    method.getMethodInfo().setDescriptor(newDescriptor);
    //method.setGenericSignature("()"+newDescriptor);
  }


  private List<RelationMappingDTO> getRealtionMappingInformation(ArrayMemberValue properties) {
    List<RelationMappingDTO> relationMappingDTOs = new ArrayList<>();
    for (MemberValue prop : properties.getValue()) {

      // @ByProperty[]
      AnnotationMemberValue annotationValue = (AnnotationMemberValue) prop;

      RelationMappingDTO dto = buildRelationMappingDTO(annotationValue);

      relationMappingDTOs.add(dto);

    }
    return relationMappingDTOs;
  }

  private RelationMappingDTO buildRelationMappingDTO(AnnotationMemberValue annotationValue) {
    String propertyName = getStringValueFromAnnotation(annotationValue, "propertyName");
    String targetMappingClass = getClassValueFromAnnotation(annotationValue, "targetMappingClass");
    String declaredClass = getClassValueFromAnnotation(annotationValue, "declaredClass");
    String mappedByKey = getStringValueFromAnnotation(annotationValue, "mappedByKey");
    String cacheRegionName = getStringValueFromAnnotation(annotationValue, "cacheRegionName");
    String mappingType = getEnumValueFromAnnotation(annotationValue, "mappingType");
    String cacheConcurrencyStrategy = getEnumValueFromAnnotation(annotationValue, "cacheConcurrencyStrategy");
    List<String> returnTypeMethods = getStringArrayValue(annotationValue, "returnTypeMethods");
    List<String> parameterTypeMethods = getStringArrayValue(annotationValue, "parameterTypeMethods");
    List<CascadeType> cascadeTypeList = getCascadeTypes(annotationValue);

    return RelationMappingDTO.builder()
        .propertyName(propertyName)
        .declaredClass(declaredClass)
        .mappingType((mappingType != null) ? MappingType.valueOf(mappingType) : null)
        .targetMappingClass(targetMappingClass)
        .cacheRegionName(cacheRegionName)
        .mappedByKey(mappedByKey)
        .cascadeTypes(cascadeTypeList)
        .returnTypeMethods(returnTypeMethods)
        .parameterTypeMethods(parameterTypeMethods)
        .cacheConcurrencyStrategy((cacheConcurrencyStrategy != null) ? CacheConcurrencyStrategy.valueOf(cacheConcurrencyStrategy) : null)
        .build();
  }


  /**
   * @param value
   * @return
   * @AdjustEntityMapping.ByProperty.cascadeTypes() 에 대한 정보를 탐색한다.
   */
  private List<CascadeType> getCascadeTypes(AnnotationMemberValue value) {

    List<CascadeType> cascadeTypeList = new ArrayList<>();

    MemberValue cascadeTypesAnno = value.getValue().getMemberValue("cascadeTypes");
    if (cascadeTypesAnno != null) {
      ArrayMemberValue cascadeTypes = (ArrayMemberValue) cascadeTypesAnno;
      MemberValue[] cascades = cascadeTypes.getValue();
      for (MemberValue val : cascades) {
        EnumMemberValue cascadeValue = (EnumMemberValue) val;
        cascadeTypeList.add(CascadeType.valueOf(cascadeValue.getValue()));
      }
    }
    return cascadeTypeList;

  }

  /**
   * @param value
   * @return
   * @AdjustEntityMapping.ByProperty.cascadeTypes() 에 대한 정보를 탐색한다.
   */
  private List<String> getStringArrayValue(AnnotationMemberValue value, String valueName) {

    List<String> list = new ArrayList<>();

    MemberValue anno = value.getValue().getMemberValue(valueName);
    if (anno != null) {
      MemberValue[] values = ((ArrayMemberValue) anno).getValue();
      for (MemberValue val : values) {
        StringMemberValue stringValue = (StringMemberValue) val;
        list.add(stringValue.getValue());
      }
    }
    return list;

  }

  private String getStringValueFromAnnotation(AnnotationMemberValue annotationValue, String method) {
    if (annotationValue != null && annotationValue.getValue() != null && annotationValue.getValue().getMemberValue(method) != null) {
      return ((StringMemberValue) annotationValue.getValue().getMemberValue(method)).getValue();
    }
    return null;
  }

  private String getClassValueFromAnnotation(AnnotationMemberValue annotationValue, String method) {
    if (annotationValue != null && annotationValue.getValue() != null && annotationValue.getValue().getMemberValue(method) != null) {
      return ((ClassMemberValue) annotationValue.getValue().getMemberValue(method)).getValue();
    }
    return null;
  }

  private Integer getIntegerValueFromAnnotation(AnnotationMemberValue annotationValue, String method, Integer defaultValue) {
    if (annotationValue != null && annotationValue.getValue() != null && annotationValue.getValue().getMemberValue(method) != null) {
      return ((IntegerMemberValue) annotationValue.getValue().getMemberValue(method)).getValue();
    }
    return defaultValue;
  }

  private String getEnumValueFromAnnotation(AnnotationMemberValue annotationValue, String method) {
    if (annotationValue != null && annotationValue.getValue() != null && annotationValue.getValue().getMemberValue(method) != null) {
      return ((EnumMemberValue) annotationValue.getValue().getMemberValue(method)).getValue();
    }
    return null;
  }


  public List<ReplaceMappingHandler> getReplaceMappingHandlers() {
    return replaceMappingHandlers;
  }

  public void setReplaceMappingHandlers(List<ReplaceMappingHandler> replaceMappingHandlers) {
    this.replaceMappingHandlers = replaceMappingHandlers;
  }
}
