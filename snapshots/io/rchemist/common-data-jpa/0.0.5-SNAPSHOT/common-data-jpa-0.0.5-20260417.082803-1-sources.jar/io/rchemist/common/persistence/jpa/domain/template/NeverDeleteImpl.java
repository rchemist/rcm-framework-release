/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Index;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(NeverDelete.class)
@Getter
@Setter
public class NeverDeleteImpl implements EnhancedTemplate {

  @Column(name = "IS_ACTIVE")
  @Index(name = "NEVER_DELETE_ACTIVE_INDEX", columnNames = {"IS_ACTIVE"})
  @GenericField(sortable = Sortable.YES)
  @Description(name = "활성화 여부", comment = "활성화 여부, 기본적으로 isActive는 archived 되지 않은 것이다.")
  @AdminField(order = 100, fieldType = PresentationFieldType.BOOLEAN, name = "SoftDeleteImpl_Active"
      , defaultValue = "true"
      , headerField = @HeaderField(order = 1000000, sortable = false)
      , tab = @ViewTab(type = TabEnumType.STATUS)
      , modifiableType = ModifiableType.MODIFY_ONLY)
  /*// @AdminPresentation(friendlyName = "SoftDeleteImpl_IsActive", order = Integer.MIN_VALUE, defaultValue = "true"
      , modifiableType = ModifiableType.MODIFY_ONLY, modifyOnList = true, prominent = true, gridOrder = Integer.MAX_VALUE)*/
  @Getter
  protected Boolean active = true;

}
