/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.multitenant;

import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionHandler;
import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionManager;
import io.rchemist.common.persistence.jpa.persistence.RegisterEntityBean;
import io.rchemist.common.persistence.multitenant.TenantInformationProvider;
import jakarta.persistence.EntityManager;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.query.EscapeCharacter;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
import org.springframework.data.querydsl.EntityPathResolver;
import org.springframework.data.querydsl.SimpleEntityPathResolver;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class MultiTenantJpaRepositoryFactoryBean <T extends Repository<S, ID>, S, ID> extends
    JpaRepositoryFactoryBean<T, S, ID> {
  private static TenantInformationProvider tenantIdProvider;
  static TenantInformationProvider getTenantIdProvider() {
    return tenantIdProvider;
  }

  private EntityPathResolver entityPathResolver;
  private EscapeCharacter escapeCharacter = EscapeCharacter.DEFAULT;

  private PlatformEntityExtensionManager extensionManager;
  private List<PlatformEntityExtensionHandler> queryExtensionHandlers;

  private RegisterEntityBean registerEntityBean;

  public MultiTenantJpaRepositoryFactoryBean(Class<? extends T> repositoryInterface) {
    super(repositoryInterface);
  }

  @Autowired
  public void setRegisterEntityBean(
    RegisterEntityBean registerEntityBean) {
    this.registerEntityBean = registerEntityBean;
  }

  @Autowired
  public void setExtensionManager(PlatformEntityExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Autowired
  public void setQueryExtensionHandlers(List<PlatformEntityExtensionHandler> queryExtensionHandlers) {
    this.queryExtensionHandlers = queryExtensionHandlers;
  }

  @Autowired
  @Override
  public void setEntityPathResolver(ObjectProvider<EntityPathResolver> resolver) {
    super.setEntityPathResolver(resolver);
    this.entityPathResolver = resolver.getIfAvailable(() -> SimpleEntityPathResolver.INSTANCE);
  }

  @Override
  public void setEscapeCharacter(char escapeCharacter) {
    super.setEscapeCharacter(escapeCharacter);

    this.escapeCharacter = EscapeCharacter.of(escapeCharacter);
  }

  protected RepositoryFactorySupport createRepositoryFactory(EntityManager entityManager) {
    JpaRepositoryFactory jpaRepositoryFactory = new MultiTenantJpaRepositoryFactory(entityManager, extensionManager, registerEntityBean, queryExtensionHandlers);
    jpaRepositoryFactory.setEntityPathResolver(entityPathResolver);
    jpaRepositoryFactory.setEscapeCharacter(escapeCharacter);
    return jpaRepositoryFactory;
  }

  @Autowired
  private void setTenantIdProvider(TenantInformationProvider tenantIdProvider) {
    this.tenantIdProvider = tenantIdProvider;
  }
}