/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * Bytecode assist를 이용해 attributes 관련 필드를 자동으로 추가한다
 * <p>
 **/

public interface NameValue<T> extends ClassTransformTarget {

  default String getName(){throw new ClassTransformException();}
  default void setName(String name){throw new ClassTransformException();}

  default String getValue(){throw new ClassTransformException();}
  default void setValue(String value){throw new ClassTransformException();}

  default Boolean getCustomField(){throw new ClassTransformException();}
  default void setCustomField(Boolean customField) {throw new ClassTransformException();}

  default boolean isCustomField(){
    return BooleanUtils.toBoolean(getCustomField());
  }

  default T withName(String name) {
    setName(name);
    return (T) this;
  }

  default T withValue(String value) {
    setValue(value);
    return (T) this;
  }

  default T withCustomField(Boolean customField) {
    setCustomField(customField);
    return (T) this;
  }
}
