/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NameDetailDescription<T> extends ClassTransformTarget, SearchableName {

  default String getName(){
    throw new ClassTransformException();
  }

  default void setName(String name){
    throw new ClassTransformException();
  }

  default String getDescription(){
    throw new ClassTransformException();
  }

  default void setDescription(String description){
    throw new ClassTransformException();
  }

  default String getLongDescription() {throw new ClassTransformException();}

  default void setLongDescription(String longDescription){
    throw new ClassTransformException();
  }

  default T withName(String name){
    setName(name);
    return (T) this;
  }

  default T withDescription(String description){
    setDescription(description);
    return (T) this;
  }

  default T withLongDescription(String longDescription){
    setLongDescription(longDescription);
    return (T) this;
  }

}
