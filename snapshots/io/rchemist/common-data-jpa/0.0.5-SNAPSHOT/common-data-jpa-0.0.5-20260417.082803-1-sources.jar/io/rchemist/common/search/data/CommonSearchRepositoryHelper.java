/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.StringUtil;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class CommonSearchRepositoryHelper {

  private static Boolean local;

  private static CommonSearchRepositoryHelper validator;

  public static CommonSearchRepositoryHelper getValidator() {
    if(validator == null){
      validator = ApplicationContextHolder.getBean(CommonSearchRepositoryHelper.class);
    }
    return validator;
  }

  public boolean isLocalMode(){
    if(local == null){
      String profile = StringUtil.toString(System.getProperty("spring.profiles.active"), "local");
      local = profile.equals("local");
    }
    return local;
  }

  public static Pageable getLatestPageable() {
    Pageable pageable = PageRequest.of(0, 1, getLatestSort());
    return pageable;
  }

  public static Sort getLatestSort() {
    return Sort.by(new Sort.Order(Direction.DESC, "createdAt"));
  }


}
