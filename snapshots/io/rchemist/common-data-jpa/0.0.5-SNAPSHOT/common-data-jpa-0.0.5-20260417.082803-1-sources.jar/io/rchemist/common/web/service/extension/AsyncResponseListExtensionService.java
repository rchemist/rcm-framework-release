/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.extension;

import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.RevisionEntityWrapper;
import io.rchemist.common.web.service.type.RevisionType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Service("rcmAsyncResponseListExtensionService")
@Slf4j
public class AsyncResponseListExtensionService {

  protected final ResponseListExtensionManager extensionManager;

  public AsyncResponseListExtensionService(ResponseListExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Async
  public void asyncUpdateEntityRevision(String userId, String userName, RevisionType revisionType, String revisionEntityName, HasIdEntity<?> entity, RevisionEntityWrapper<?> form, HasIdEntity<?> view) {
    try {
      extensionManager.getProxy().logEntityRevision(userId, userName, revisionType, revisionEntityName, entity, form, view);
    }catch (Exception e) {
      log.error(e.getMessage(), e);
    }
  }

  @Async
  public void asyncDeleteEntityRevisionById(String userId, String userName, String revisionEntityName, Object id) {
    try {
      extensionManager.getProxy().logDeleteEntityRevisionById(userId, userName, revisionEntityName, id);
    }catch (Exception e) {
      log.error(e.getMessage(), e);
    }
  }
}
