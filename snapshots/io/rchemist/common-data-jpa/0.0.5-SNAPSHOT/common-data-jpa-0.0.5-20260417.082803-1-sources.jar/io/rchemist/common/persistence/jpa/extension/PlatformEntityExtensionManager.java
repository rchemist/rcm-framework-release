/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionManager;
import io.rchemist.common.extension.ExtensionResultStatusType;
import java.lang.reflect.Method;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Service(PlatformEntityExtensionManager.BEAN_NAME)
public class PlatformEntityExtensionManager extends ExtensionManager<PlatformEntityExtensionHandler> {

  public static final String BEAN_NAME = "rcmPlatformEntityExtensionManager";

  public PlatformEntityExtensionManager(){
    super(PlatformEntityExtensionHandler.class);
  }

  @Override
  public boolean continueOnHandled() {
    return true;
  }

  @Override
  public boolean shouldContinue(ExtensionResultStatusType result, ExtensionHandler handler,
      Method method, Object[] args) {
    if (result != null) {
      if (ExtensionResultStatusType.HANDLED_STOP.equals(result)) {
        return false;
      }
      // HANDLED_STOP 이 아니면 계속 반복한다.
      return continueOnHandled();
    }
    return true;
  }
}
