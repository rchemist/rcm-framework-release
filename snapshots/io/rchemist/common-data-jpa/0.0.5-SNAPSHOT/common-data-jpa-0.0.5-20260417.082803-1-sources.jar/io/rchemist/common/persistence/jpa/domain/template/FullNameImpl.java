/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.embedded.Name;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Embedded;
import org.hibernate.search.engine.backend.types.ObjectStructure;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexedEmbedded;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(FullName.class)
public class FullNameImpl implements EnhancedTemplate {

  @Embedded
  @IndexedEmbedded(structure = ObjectStructure.FLATTENED)
  protected Name name;

  public Name getName() {
    initialize();
    return this.name;
  }

  public void setName(Name name) {
    this.name = name;
    initialize();
  }

  public String getFullName() {
    initialize();
    return this.name.getFullName();
  }

  public String getFirstName() {
    initialize();
    return this.name.getFirstName();
  }

  public String getLastName() {
    initialize();
    return this.name.getLastName();
  }

  public String getMiddleName() {
    initialize();
    return this.name.getMiddleName();
  }

  public void setFirstName(String firstName) {
    initialize();
    this.name.setFirstName(firstName);
  }

  public void setLastName(String lastName) {
    initialize();
    this.name.setLastName(lastName);
  }

  public void setMiddleName(String middleName) {
    initialize();
    this.name.setMiddleName(middleName);
  }


  private void initialize(){
    if(this.name == null)
      this.name = new Name();
  }

}
