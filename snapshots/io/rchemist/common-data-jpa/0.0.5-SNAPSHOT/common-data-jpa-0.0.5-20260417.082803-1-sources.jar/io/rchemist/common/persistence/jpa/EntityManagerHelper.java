/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa;

import io.rchemist.common.configuration.ApplicationContextHolder;
import jakarta.persistence.EntityManager;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class EntityManagerHelper {

  private static final Map<String, String> CACHED_ENTITY_MANAGER = new ConcurrentHashMap<>(10000);

  public static EntityManager getEntityManager(Class<?> entityClass){

    String className = entityClass.getName();

    if(CACHED_ENTITY_MANAGER.containsKey(className)){
      return ApplicationContextHolder.getBean(CACHED_ENTITY_MANAGER.get(className), EntityManager.class);
    }else{
      Map<String, EntityManager> managers = ApplicationContextHolder.getApplicationContext().getBeansOfType(EntityManager.class);

      for(String key : managers.keySet()){
        EntityManager em = managers.get(key);
        try{
          if(em.getEntityManagerFactory().getMetamodel().managedType(entityClass) != null){
            CACHED_ENTITY_MANAGER.put(className, key);
            return em;
          }
        }catch (Exception e){
          // not a managed type, skipping
        }
      }
      throw new RuntimeException("There is no entity manager for " + entityClass.getName());
    }



  }

}
