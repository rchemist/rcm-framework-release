/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * FilterMapSearchForm의 필터 처리를 담당하는 클래스
 * QuerySpecification에서 FilterMap 관련 로직을 분리
 */
@Slf4j
public class FilterMapProcessor<T extends Serializable, S extends SearchFormWrapper<S>> {

  private final FilterMapSearchForm<?> filterMapSearchForm;
  private final Map<ConditionOperatorType, QueryCondition> conditions;
  private final String[] propertyNames;

  public FilterMapProcessor(FilterMapSearchForm<?> filterMapSearchForm, 
                           Map<ConditionOperatorType, QueryCondition> conditions,
                           String[] propertyNames) {
    this.filterMapSearchForm = filterMapSearchForm;
    this.conditions = conditions;
    this.propertyNames = propertyNames;
  }

  /**
   * FilterMapSearchForm의 필터들을 처리하여 조건에 추가
   */
  public void process() {
    log.debug("Processing FilterMapSearchForm filters");
    
    for (Entry<ConditionOperatorType, FilterItem[]> entry : filterMapSearchForm.getFilters().entrySet()) {
      ConditionOperatorType conditionOperatorType = entry.getKey();
      Map<QueryConditionType, String[]> filterMap = new HashMap<>();

      if (ArrayUtils.isNotEmpty(entry.getValue())) {
        processFilterItems(entry.getValue(), filterMap);
      }

      if (MapUtils.isNotEmpty(filterMap)) {
        addFilterMapConditions(conditionOperatorType, filterMap);
      }
    }
    
    log.debug("FilterMapSearchForm processing completed");
  }

  private void processFilterItems(FilterItem[] filterItems, Map<QueryConditionType, String[]> filterMap) {
    for (FilterItem filterItem : filterItems) {
      String fieldName = filterItem.getName();

      // 복합 필드명(예: "parent.id")의 경우 첫 번째 부분(예: "parent")만 확인
      String rootFieldName = fieldName.contains(".") ? fieldName.substring(0, fieldName.indexOf(".")) : fieldName;

      if (ArrayUtils.contains(propertyNames, fieldName) || ArrayUtils.contains(propertyNames, rootFieldName)) {
        QueryConditionType condition = filterItem.getQueryConditionType();
        if (filterMap.containsKey(condition)) {
          filterMap.put(condition, ArrayUtil.addArray(filterMap.get(condition), fieldName));
        } else {
          filterMap.put(condition, new String[]{fieldName});
        }
      }
    }
  }

  private void addFilterMapConditions(ConditionOperatorType conditionOperatorType, 
                                    Map<QueryConditionType, String[]> filterMap) {
    for (Entry<QueryConditionType, String[]> subEntry : filterMap.entrySet()) {
      addConditions(conditionOperatorType, subEntry.getKey(), subEntry.getValue());
    }
  }

  /**
   * FilterMapSearchForm의 조건을 QueryCondition에 추가
   */
  private void addConditions(ConditionOperatorType conditionOperatorType, QueryConditionType conditionType, String... propertyNames) {
    if (propertyNames != null && ArrayUtils.isNotEmpty(propertyNames)) {
      QueryCondition queryCondition;
      if (conditions.containsKey(conditionOperatorType)) {
        queryCondition = conditions.get(conditionOperatorType);
      } else {
        queryCondition = new QueryCondition();
      }

      if (conditionType.equals(QueryConditionType.NULL)) {
        for (String propertyName : propertyNames) {
          // FilterItem에서 JoinType과 applyOnClause 정보를 가져와 적용
          FilterItem originalFilterItem = findFilterItemByName(propertyName, conditionOperatorType);
          SingleConditionItem nullCondition = SingleConditionItem.isNull(propertyName);
          if (originalFilterItem != null) {
            nullCondition = nullCondition.withJoinType(originalFilterItem.getJoinType());
            nullCondition.setApplyOnClause(originalFilterItem.isApplyOnClause());
          }
          queryCondition.addQueryItems(nullCondition);
          // NULL 조건이더라도 subFilters 가 있으면 처리
          processSubConditions(queryCondition, (S) filterMapSearchForm, conditionOperatorType, propertyName);
        }
      } else if (conditionType.equals(QueryConditionType.NOT_NULL)) {
        for (String propertyName : propertyNames) {
          // FilterItem에서 JoinType과 applyOnClause 정보를 가져와 적용
          FilterItem originalFilterItem = findFilterItemByName(propertyName, conditionOperatorType);
          SingleConditionItem notNullCondition = SingleConditionItem.notNull(propertyName);
          if (originalFilterItem != null) {
            notNullCondition = notNullCondition.withJoinType(originalFilterItem.getJoinType());
            notNullCondition.setApplyOnClause(originalFilterItem.isApplyOnClause());
          }
          queryCondition.addQueryItems(notNullCondition);
          // NOT_NULL 조건이더라도 subFilters 가 있으면 처리
          processSubConditions(queryCondition, (S) filterMapSearchForm, conditionOperatorType, propertyName);
        }
      } else {
        processRegularConditions(queryCondition, conditionOperatorType, conditionType, propertyNames);
      }

      conditions.put(conditionOperatorType, queryCondition);
    }
  }

  private void processRegularConditions(QueryCondition queryCondition, ConditionOperatorType conditionOperatorType, 
                                      QueryConditionType conditionType, String... propertyNames) {
    S searchForm = (S) filterMapSearchForm;
    
    for (String propertyName : propertyNames) {
      // join으로 매핑된 property는 propertyName:pathNames 형태로 설정됨
      String pathName = StringUtil.subStringAfter(propertyName, ":");
      Object value = searchForm.getValue(conditionOperatorType, conditionType, pathName);

      if (value != null) {
        processValueCondition(queryCondition, searchForm, conditionOperatorType, conditionType, propertyName, pathName, value);
      } else {
        processSubConditions(queryCondition, searchForm, conditionOperatorType, propertyName);
      }
    }
  }

  private void processValueCondition(QueryCondition queryCondition, S searchForm, ConditionOperatorType conditionOperatorType, 
                                   QueryConditionType conditionType, String propertyName, String pathName, Object value) {
    if (searchForm instanceof AbstractSearchForm<?> form) {
      FilterItem[] items = form.getFilterItems(conditionOperatorType, pathName);
      queryCondition.addConditions(items);
    } else {
      QueryConditionType queryConditionType = conditionType;

      if (value instanceof EnumType || value instanceof Boolean) {
        queryConditionType = QueryConditionType.EQUAL;
      }

      queryCondition.addConditions(queryConditionType, propertyName, value);
    }
  }

  private void processSubConditions(QueryCondition queryCondition, S searchForm, ConditionOperatorType conditionOperatorType, String propertyName) {
    // searchForm의 해당 이름의 필터가 subConditions으로 매핑된 경우
    if (searchForm instanceof AbstractSearchForm<?> form) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> subConditions = form.getSubConditions(conditionOperatorType, propertyName);

      if (MapUtils.isNotEmpty(subConditions)) {
        for (Entry<ConditionOperatorType, FilterItem[]> entry : subConditions.entrySet()) {
          ConditionOperatorType subConditionOperatorType = entry.getKey();
          FilterItem[] filterItems = entry.getValue();

          if (ArrayUtils.isNotEmpty(filterItems)) {
            QueryCondition subQueryCondition = new QueryCondition();

            for (FilterItem filterItem : filterItems) {
              subQueryCondition.addConditions(filterItem);
            }

            CombinedConditionItem subConditionItem = new CombinedConditionItem(subConditionOperatorType,
                subQueryCondition.getAllQueryConditionItems());

            queryCondition.addCombinedConditionItem(subConditionItem);
          }
        }
      }
    }
  }

  /**
   * 특정 이름의 FilterItem을 찾아 반환
   */
  private FilterItem findFilterItemByName(String propertyName, ConditionOperatorType conditionOperatorType) {
    FilterItem[] filterItems = filterMapSearchForm.getFilters().get(conditionOperatorType);
    if (filterItems != null) {
      for (FilterItem item : filterItems) {
        if (propertyName.equals(item.getName())) {
          return item;
        }
      }
    }
    return null;
  }
}