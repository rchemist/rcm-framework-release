/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.template.listener.IpAddressListener;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.DeviceType;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import java.io.Serializable;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(value = IpAddress.class)
@EntityListeners(IpAddressListener.class)
@Getter
@Setter
public class IpAddressImpl implements Serializable, EnhancedTemplate {

  @Column(name = "IP_ADDRESS")
  @KeywordField
  /*// @AdminPresentation(friendlyName = "IpAddressImpl_IpAddress"
      , order = 100000, tab = PresentationVariables.Tab.Status.TYPE, tabOrder = PresentationVariables.Tab.Status.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Description.TYPE, order = PresentationVariables.Group.Description.ORDER)
      , readOnly = true, modifiableType = ModifiableType.MODIFY_ONLY
  )*/
  @Description(name = "IP 주소", comment = "IP 주소")
  protected String ipAddress;

  @Column(name = "DEVICE_TYPE")
  /*// @AdminPresentation(friendlyName = "IpAddressImpl_DeviceType"
      , order = 100100, tab = PresentationVariables.Tab.Status.TYPE, tabOrder = PresentationVariables.Tab.Status.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Description.TYPE, order = PresentationVariables.Group.Description.ORDER)
      , readOnly = true, modifiableType = ModifiableType.MODIFY_ONLY
  )*/
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "디바이스 유형", comment = "디바이스 유형. (PC, MOBILE, MOBILE_APP, UNIDENTIFIED)")
  protected String deviceType;

  @Column(name = "MAC_ADDRESS")
  /*// @AdminPresentation(friendlyName = "IpAddressImpl_MacAddress"
      , order = 100200, tab = PresentationVariables.Tab.Status.TYPE, tabOrder = PresentationVariables.Tab.Status.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Description.TYPE, order = PresentationVariables.Group.Description.ORDER)
      , readOnly = true, modifiableType = ModifiableType.MODIFY_ONLY
  )*/
  @KeywordField
  @Description(name = "MAC 주소", comment = "MAC 주소")
  protected String macAddress;


  public DeviceType getDeviceType(){
    return EnumTypeUtil.getEnumType(DeviceType.class, deviceType);
  }

  public void setDeviceType(DeviceType deviceType){
    if(deviceType != null){
      this.deviceType = deviceType.getType();
    }else{
      this.deviceType = null;
    }
  }

}
