/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.template.presentation.ISeoMetadata;
import io.rchemist.common.util.StringUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * SEO 메타데이터 필드
 **/

public interface SeoMetadata<T> extends ClassTransformTarget, ISeoMetadata<T> {

  String METADATA_MODEL_ATTRIBUTE = "globalMetadata";

  // varchar(2000)
  default String getMetaHeader(){throw new ClassTransformException();}                // 헤더에 들어갈 내용을 ; 로 구분해 문자열로 입력
  default void setMetaHeader(String metaHeader){throw new ClassTransformException();}

  // varchar(255)
  default String getMetaTitle(){throw new ClassTransformException();}
  default void setMetaTitle(String metaTitle){throw new ClassTransformException();}

  // varchar(4000)
  default String getMetaDescription(){throw new ClassTransformException();}
  default void setMetaDescription(String metaDescription){throw new ClassTransformException();}

  default void setDefaultMetaTitle(String defaultMetaTitle){
    setMetaTitle(StringUtil.toString(getMetaTitle(), defaultMetaTitle));
  }
  default void setDefaultMetaDescription(String defaultMetaDescription){
    setMetaDescription(StringUtil.toString(getMetaDescription(), defaultMetaDescription));
  }

  default void setOverrideMetaTitle(String overrideMetaTitle){
    if(StringUtils.isNotBlank(overrideMetaTitle)){
      if(StringUtils.isNotBlank(getMetaTitle())){
        setMetaTitle(overrideMetaTitle + " > " + getMetaTitle());
      }else{
        setMetaTitle(overrideMetaTitle);
      }
    }
  }
  default void setOverrideMetaDescription(String overrideDescription){
    if(StringUtils.isNotBlank(overrideDescription)){
      if(StringUtils.isNotBlank(getMetaDescription())){
        setMetaDescription(overrideDescription + " > " + getMetaDescription());
      }else{
        setMetaDescription(overrideDescription);
      }
    }
  }

  /**
   * 이 인터페이스를 상속하는 엔티티 들이 반드시 따로 구현해야 할 메소드 : default 값 셋팅
   */
  void arrangeSeoMetadata();

  /**
   * 실제 Html 태그로 파싱된 문자열을 출력
   * @return
   */
  default String parse(){
    return parse(null, null);
  }

  /**
   * 실제 Html 태그로 파싱된 문자열을 출력. 기본값을 넣어 줄 수 있음
   * @param defaultTitle
   * @param defaultDescription
   * @return
   */
  default String parse(String defaultTitle, String defaultDescription){

    arrangeSeoMetadata();

    StringBuilder sb = new StringBuilder();

    String metaTitle = (getMetaTitle() == null) ? defaultTitle : getMetaTitle();
    String metaDescription = (getMetaDescription() == null) ? defaultDescription : getMetaDescription();

    if(StringUtils.isNotBlank(metaTitle)){
      sb.append("<meta property=\"og:title\" content=\"")
          .append(metaTitle)
          .append("\" />\n");
      sb.append("<title>")
          .append(metaTitle)
          .append("</title>\n");
    }

    if(StringUtils.isNotBlank(metaDescription)){
      sb.append("<meta property=\"og:description\"")
          .append(" content=\"")
          .append(metaDescription)
          .append("\" />\n");
      sb.append("<meta name=\"description\"")
          .append(" content=\"")
          .append(metaDescription)
          .append("\" />\n");
    }

    return sb.toString();
  }

  default T withMetaHeader(String metaHeader){
    setMetaHeader(metaHeader);
    return (T) this;
  }

  default T withMetaTitle(String metaTitle){
    setMetaTitle(metaTitle);
    return (T) this;
  }

  default T withMetaDescription(String metaDescription){
    setMetaDescription(metaDescription);
    return (T) this;
  }

  default T withOverrideMetaTitle(String overrideMetaTitle){
    if(StringUtils.isNotBlank(overrideMetaTitle)){
      if(StringUtils.isNotBlank(getMetaTitle())){
        setMetaTitle(overrideMetaTitle + " > " + getMetaTitle());
      }else{
        setMetaTitle(overrideMetaTitle);
      }
    }
    return (T) this;
  }
  default T withOverrideMetaDescription(String overrideDescription){
    if(StringUtils.isNotBlank(overrideDescription)){
      if(StringUtils.isNotBlank(getMetaDescription())){
        setMetaDescription(overrideDescription + " > " + getMetaDescription());
      }else{
        setMetaDescription(overrideDescription);
      }
    }
    return (T) this;
  }

  @Override
  default T withSeoMetadata(ISeoMetadata<?> seoMetadata) {
    setMetaHeader(seoMetadata.getMetaHeader());
    setMetaTitle(seoMetadata.getMetaTitle());
    setMetaDescription(seoMetadata.getMetaDescription());
    arrangeSeoMetadata();
    return (T) this;
  }

}
