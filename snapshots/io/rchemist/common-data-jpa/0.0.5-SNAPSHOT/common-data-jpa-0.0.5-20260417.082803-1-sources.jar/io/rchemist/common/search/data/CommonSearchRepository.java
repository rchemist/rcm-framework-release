/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.EssentialUUIDEntity;
import io.rchemist.common.search.data.query.QuerySpecification;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface CommonSearchRepository<T, ID> extends JpaRepository<T, ID>, JpaSpecificationExecutor<T> {

  default long getCount(SearchContext<?, ?> searchContext) {
    if (searchContext == null)
      throw new RuntimeException("SearchContext is null");

    long count = 0;

    if (searchContext.isShouldReturnEmpty()) {
      return count;
    }

    if (searchContext instanceof CommonSearchContext<?, ?> simpleSearchContext) {

      QuerySpecification specification = simpleSearchContext.getSpecification();
      return count(specification);

    } else {
      throw new IllegalArgumentException("Non CommonSearchContext is not supported");
    }
  }

  default Page<T> findAll(SearchContext<?, ?> searchContext){

    if (searchContext == null)
      throw new RuntimeException("SearchContext is null");

    Page<T> page;

    if (searchContext.isShouldReturnEmpty()) {
      return Page.empty();
    }

    if (searchContext instanceof CommonSearchContext<?, ?> simpleSearchContext) {

      QuerySpecification specification = simpleSearchContext.getSpecification();
      page = findAll(specification, simpleSearchContext.getPageable(false));

    } else {
      throw new IllegalArgumentException("Non CommonSearchContext is not supported");
    }

    return page;
  }


  static <T> void validateEquals(Page<T> page, Page<T> others, Class repository){

    try{

      if(page.getSize() != others.getSize()
          || page.getTotalPages() != others.getTotalPages()
          || page.getNumberOfElements() != others.getNumberOfElements()){
        throw new RuntimeException("Failed to validate!! - returned record size is not matched");
      }

      if(!page.isEmpty()){
        // 실제 데이터 비교
        int loopCount = 0;
        for(Object e : page.getContent()){

          Object other = others.getContent().get(loopCount);

          boolean equals = true;

          if(e instanceof EssentialEntity){
            equals = ((EssentialEntity) e).getId().equals(((EssentialEntity) other).getId());
          }else if(e instanceof EssentialUUIDEntity){
            equals = ((EssentialUUIDEntity) e).getId().equals(((EssentialUUIDEntity) other).getId());
          }

          if(!equals){
            throw new RuntimeException("Failed to validate!! - returned record order is not matched");
          }
          loopCount++;
        }
      }


    }catch (Exception e){

      e.printStackTrace();

      System.out.println("Error occurred during CommonSearchRepository#findAll -- " + repository.getName());

    }
  }

}
