/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config;

import io.rchemist.common.persistence.jpa.config.datasource.provider.DataSourceBuilder;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * TODO: 1. Multiple DataSource 를 Properties 로 정의하기
 *
 **/
@Configuration
public class Settings {

  public static final String DEFAULT = "DEFAULT";

  @Bean(name = "datasourceProperties")
  @ConfigurationProperties(prefix="spring.datasource.rcm-rdb")
  public Properties getDataSourceProperties(){
    return new Properties();
  }

  @Bean(name = "hibernateProperties")
  @ConfigurationProperties(prefix="spring.jpa.properties")
  public Properties getHibernateProperties(){
    return new Properties();
  }

  @Autowired
  protected List<DataSourceBuilder> datasourceBuilders;

  protected boolean buildersSorted = false;

  @Bean
  public List<DataSourceBuilder> dataSourceBuilders(){
    sortBuilders();
    return datasourceBuilders;
  }

  private void sortBuilders() {
    if(buildersSorted){
      Comparator<DataSourceBuilder> comparator = Comparable::compareTo;
      datasourceBuilders.sort(comparator);
      this.buildersSorted = true;
    }
  }

}
