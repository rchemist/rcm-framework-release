/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Column에 명시적인 UniqueConstraint 를 걸지 않고도,
 * Hibernate의 EntityManager에 merge 할 때 Unique Validation을 처리하기 위한 어노테이션이다.
 *
 * 예를 들어 필드 a, b, c를 가진 A 엔티티가 있고, 이 엔티티가 SoftDelete를 지원한다고 가정하자.
 * 여기에 a, b 필드가 unique 해야 한다고 할 때 각 필드에 명시적인 DB UniqueConstraint 를 걸면
 * SoftDelete에 의해 지워졌다고 판단되는 기존 데이터 때문에 새로운 데이터를 입력하지 못하게 될 수도 있다.
 * 따라서 DB 의 Constraint 가 아닌 어플리케이션의 Validation 을 통해 UniqueConstraint 를 처리해야 한다.
 *
 * 단, 이 어노테이션에서 정의된 필드는 자동으로 Index 를 부여받게 될 것이다(Unique 인덱스가 아님). - @IndexField
 *
 * 이 어노테이션을 적용하면 Hibernate의 EntityManager에서 onMerge 상황에서 자동으로 validation 을 처리하게 될 것이다.
 *
 **/
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@IndexField
@Documented
public @interface Unique{

  /**
   * 이 Validation 을 위배했을 때 출력할 에러메시지 - 앞에 #을 붙이면 i18n message 를 의미한다.
   * @return
   */
  String errorMessage() default "#error.validation.unique.constraint";

  @AliasFor(annotation = IndexField.class, value = "name")
  String name() default "";

  @AliasFor(annotation = IndexField.class, value = "columnList")
  String columnList() default "";
}
