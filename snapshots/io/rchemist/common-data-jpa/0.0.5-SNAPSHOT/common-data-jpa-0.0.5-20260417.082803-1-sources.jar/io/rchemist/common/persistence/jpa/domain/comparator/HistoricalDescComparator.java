/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.comparator;

import static io.rchemist.common.persistence.jpa.domain.comparator.HistoricalComparator.sortByLongId;

import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class HistoricalDescComparator implements Comparator<EssentialEntity<?>> {

  @Override
  public int compare(EssentialEntity<?> o1, EssentialEntity<?> o2) {
    // to null safe
    return sortByLongId(o1, o2, false);
  }

  public static <T extends EssentialEntity<?>> List<T> sort(List<T> collection) {
    if (CollectionUtils.isNotEmpty(collection)) {
      collection.sort((o1, o2) -> sortByLongId(o1, o2, false));
    }
    return collection;
  }


}
