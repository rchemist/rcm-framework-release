/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * </p>
 **/
public interface DynamicFieldValue<T> extends NameValue<T> {

  default String getTemplateAlias(){throw new ClassTransformException();}

  default void setTemplateAlias(String templateAlias){
    throw new ClassTransformException();
  }

  default boolean isEqualTemplateAlias(String compareTo){
    return StringUtils.equals(getTemplateAlias(), compareTo);
  }

  default T withTemplateAlias(String templateAlias){
    setTemplateAlias(templateAlias);
    return (T) this;
  }
}
