/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.List;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = PlatformEntityExtensionManager.BEAN_NAME, priority = 100)
public class SiteAwareQueryExtensionHandler implements PlatformEntityExtensionHandler{

  private static final String HANDLER_NAME = "SiteAwareQueryExtensionHandler";
  private static final String SITE_ALIAS = "siteAlias";
  private static final String SITE_ID = "siteId";

  @Override
  public ExtensionResultStatusType resolveAdditionalPredicates(
      ExtensionResultHolder<List<Predicate>> erh, Set<Class<? extends PlatformEntityExtensionHandler>> prohibitExecuteHandlers, CriteriaBuilder builder, Root<?> root, Class<?> rootClass){


    if (CollectionUtils.containsAny(prohibitExecuteHandlers, getClass()))
      return ExtensionResultStatusType.NOT_HANDLED;

    List<Predicate> predicates = erh.getResult();

    if(isMember(HANDLER_NAME, root, SITE_ALIAS)){

      WebRequestContext context = WebRequestContext.getWebRequestContext();
      if(!context.isAdmin() && context.getSiteAlias() != null){



        if(CollectionUtils.isEmpty(context.getSharedSiteIds())){
          predicates.add(builder.or(builder.isNull(root.get(SITE_ALIAS)), builder.equal(root.get(
              SITE_ALIAS), context.getSiteAlias())));
        }
      }
    }

    if (isMember(HANDLER_NAME, root, SITE_ID)) {

      WebRequestContext context = WebRequestContext.getWebRequestContext();
      if(!context.isAdmin() && context.getSiteAlias() != null) {

        if(CollectionUtils.isNotEmpty(context.getSharedSiteIds())) {
          predicates.add(builder.and(
              builder.or(builder.isNull(root.get(SITE_ID)),
                  root.get(SITE_ID).in(context.getSharedSiteIds()))));
        }
      }

    }

    erh.setResult(predicates);

    return ExtensionResultStatusType.HANDLED;
  }

}
