/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.metamodel.Attribute;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface PlatformEntityExtensionHandler extends ExtensionHandler {

  ConcurrentHashMap<String, Map<String, Boolean>> CACHE_FIELD_MAP = new ConcurrentHashMap<>();

  default ExtensionResultStatusType prePersist(ExtensionResultHolder<Object> erh, EntityManager em){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default ExtensionResultStatusType postPersist(EntityManager em, Object entity){
    // nothing to do;
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default ExtensionResultStatusType resolveAdditionalPredicates(ExtensionResultHolder<List<Predicate>> erh, Set<Class<? extends PlatformEntityExtensionHandler>> prohibitExecuteHandlers, CriteriaBuilder builder, Root<?> root, Class<?> rootClass){
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  @Override
  default boolean isEnabled(){
    return true;
  }

  default boolean isMember(String handlerName, Root<?> root, String propertyName){
    boolean member = false;

    if(CACHE_FIELD_MAP.contains(handlerName) && CACHE_FIELD_MAP.get(handlerName).containsKey(root.getJavaType().getName())){
      // 이미 캐시에 값이 존재하는 경우
      return CACHE_FIELD_MAP.get(handlerName).get(root.getJavaType().getName());
    }else{

      var attributes = root.getModel().getAttributes();
      for(Attribute attribute : attributes){
        if(attribute.getName().equals(propertyName)){
          member = true;
          break;
        }
      }

      Map<String, Boolean> cachedData;
      if(CACHE_FIELD_MAP.contains(handlerName)){
        cachedData = CACHE_FIELD_MAP.get(handlerName);
      }else{
        cachedData = new ConcurrentHashMap<>();
      }
      cachedData.put(root.getJavaType().getName(), member);
      CACHE_FIELD_MAP.put(handlerName, cachedData);

      return member;

    }
  }

  default ExtensionResultStatusType preMerge(ExtensionResultHolder<Object> erh, EntityManager em) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default <T> ExtensionResultStatusType postMerge(EntityManager em, T entity) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default ExtensionResultStatusType preRemove(ExtensionResultHolder<Object> erh, EntityManager em) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  default ExtensionResultStatusType postRemove(EntityManager em, Object entity) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
