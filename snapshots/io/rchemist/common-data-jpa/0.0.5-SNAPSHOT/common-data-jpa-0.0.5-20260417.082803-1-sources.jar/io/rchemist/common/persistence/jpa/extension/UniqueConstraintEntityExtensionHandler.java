/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.UniqueColumn;
import io.rchemist.common.transformer.dto.UniqueConstraint;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = PlatformEntityExtensionManager.BEAN_NAME, priority = 400)
public class UniqueConstraintEntityExtensionHandler implements PlatformEntityExtensionHandler{

  private static final String SOFT_DELETE_QUERY_CONDITION = " and (IS_ARCHIVED is null or IS_ARCHIVED = false) ";

  @Value("${platform.config.common.validator.unique.annotation:false}")
  private boolean useUniqueConstraintValidator;
  
  private static final String ERROR_MESSAGE = "error.validation.unique.constraint";
  
  private static final String SPACE = " ";
  
  private static final String AND = " and ";

  private static final String WHERE = " where ";

  private static final String EQUAL = " = ";
  
  private static final String SINGLE_QUOTE = "'";

  private static final String SELECT_COUNT_QUERY = "SELECT COUNT(*) FROM ";

  private static final String BLANK = "";
  private static final String NULL = "null";

  @Override
  public ExtensionResultStatusType prePersist(ExtensionResultHolder<Object> erh, EntityManager em) {

    Object entity = erh.getResult();

    String className = entity.getClass().getName();

    try{
      EntityBean<?> dto = PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(className);

      if(dto != null && dto.hasUniqueConstraint()){

        List<UniqueConstraint> constraints = dto.getUniqueConstraints();

        String tableName = dto.getTableName();

        if(tableName == null)
          return ExtensionResultStatusType.NOT_HANDLED;

        boolean supportSoftDelete = dto.isSupportSoftDelete();

        StringBuilder sb = new StringBuilder()
            .append(SELECT_COUNT_QUERY)
            .append(tableName)
            .append(WHERE);

        int loopCount = 0;

        boolean hasCondition = false;

        for(UniqueConstraint constraint : constraints){

          // get property value from

          List<UniqueColumn> uniqueColumns = constraint.getUniqueColumns();

          if(CollectionUtils.isEmpty(uniqueColumns)){

            String columnName = constraint.getColumnName();
            String value = getFieldValue(entity, constraint.getPropertyName());

            if(StringUtils.isNotEmpty(value)){
              if(loopCount++ > 0){
                sb.append(AND);
              }
              sb.append(SPACE).append(columnName).append(EQUAL);
              sb.append(SINGLE_QUOTE).append(value).append(SINGLE_QUOTE);
              hasCondition = true;
            }
          }else{
            for(UniqueColumn uniqueColumn : uniqueColumns){

              String columnName = uniqueColumn.getColumnName();
              String value = getFieldValue(entity, uniqueColumn.getPropertyName());

              if(StringUtils.isNotEmpty(value)){
                sb.append(SPACE).append(columnName).append(EQUAL);
                sb.append(SINGLE_QUOTE).append(value).append(SINGLE_QUOTE);
                hasCondition = true;
              }
            }
          }
        }

        if(!hasCondition)
          return ExtensionResultStatusType.NOT_HANDLED;

        if(supportSoftDelete){
          sb.append(SOFT_DELETE_QUERY_CONDITION);
        }

        String queryStr = sb.toString();

        Query query = em.createNativeQuery(queryStr);

        Object count = query.getSingleResult();

        if(NumberUtil.getLong(count).intValue() > 0){
          // 중복된 데이터가 존재한다.
          throw new UniqueConstraintException(MessageSourceHelper.getMessage(ERROR_MESSAGE));
        }

        return ExtensionResultStatusType.HANDLED;



      }
    }catch (Exception e){

      if(e instanceof UniqueConstraintException){
        throw e;
      }

      // 그 외의 오류는 무시한다.

      e.printStackTrace();
    }


    return ExtensionResultStatusType.NOT_HANDLED;
  }

  private String getFieldValue(Object entity, String propertyName){
    try {
      java.lang.reflect.Field field = BytecodeUtil.getSingleField(entity.getClass(), propertyName);

      if(field == null)
        return "";
      
      field.setAccessible(true);

      if(EnumType.class.isAssignableFrom(field.getType())){
        Class<?> typeClass = field.getType();
        Method method = typeClass.getMethod("getType");
        return (String) method.invoke(field);
      }

      String value = String.valueOf(new PropertyDescriptor(propertyName, entity.getClass()).getReadMethod().invoke(entity));

      value = StringUtil.toString(value);

      return value.equals(NULL) ? BLANK : value;

    }catch (Exception e){
      e.printStackTrace();
      return BLANK;
    }
  }

  @Override
  public boolean isEnabled() {
    return useUniqueConstraintValidator;
  }
}
