/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.listener.TenantAliasListener;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(TenantAlias.class)
@Getter
@Setter
@EntityListeners(TenantAliasListener.class)
@FilterDef(name = "tenantFilter", parameters = {@ParamDef(name = "tenantAlias", type = String.class)})
@Filter(name = "tenantFilter", condition = "tenant_alias = :tenantAlias")
public class TenantAliasImpl implements EnhancedTemplate {

  @GenericField(sortable = Sortable.YES)
  @Column(name = "TENANT_ALIAS")
  @Description(name = "Tenant Alias", comment = "사이트가 속한 테넌트 ALIAS")
  @IndexField
  protected String tenantAlias;

}
