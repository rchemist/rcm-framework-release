/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 *
 * unique 한 alias 와 달리 특정 alias 로 묶인 엔티티의 그룹을 만들기 위해 사용한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AliasGroup<T> {

  default String getAliasGroup(){
    throw new ClassTransformException();
  }

  default void setAliasGroup(String aliasGroup) {
    throw new ClassTransformException();
  }

  default T withAliasGroup(String aliasGroup) {
    setAliasGroup(aliasGroup);
    return (T) this;
  }

}
