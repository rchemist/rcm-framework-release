/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(AuditByAdmin.class)
@Getter
@Setter
public class AuditByAdminImpl implements Serializable, EnhancedTemplate {

  @Column(name = "AUDIT_ADM_DESC")
  @Description(name = "비고", comment = "이 엔티티의 값을 변경할 때 추가로 입력 받은 비고")
  @Text
  // @AdminPresentation(friendlyName = "AuditByAdminImpl_AuditDescription", order = 4000, tab = PresentationVariables.Tab.Status.TYPE, tabOrder = PresentationVariables.Tab.Status.ORDER)
  protected String auditDescription;

}
