/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.configuration.platform.DataSourceConfig;
import io.rchemist.common.persistence.jpa.config.datasource.provider.DataSourceBuilder;
import io.rchemist.common.persistence.jpa.config.mapping.MappingProvider;
import io.rchemist.common.persistence.jpa.transaction.TransactionHelper;
import io.rchemist.common.search.config.HibernateSearchMassIndexer;
import io.rchemist.common.search.config.SearchAnalyzerSetting;
import io.rchemist.common.util.PropertyUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public abstract class EntityManagerSetting {

  private static class CachedProperties{
    static final Map<String, Properties> CACHED_PROPERTIES = new HashMap<>();
  }
  public static Map<String, Properties> getCachedProperties(){
    return CachedProperties.CACHED_PROPERTIES;
  }

  @Autowired(required = false)
  protected SearchAnalyzerSetting searchAnalyzerSetting;

  @Autowired
  protected Properties hibernateProperties;

  @Autowired
  protected Properties datasourceProperties;

  @Autowired
  protected List<DataSourceBuilder> dataSourceBuilders;

  @Autowired
  protected DataSourceConfig dataSourceConfig;

  @Autowired(required = false)
  protected List<MappingProvider> mappingProviders;

  protected Properties defaultHibernateProperties;

  public static List<MappingProvider> STATIC_MAPPING_PROVIDERS = new ArrayList<>();

  public List<MappingProvider> loadMappingProviders(){
    STATIC_MAPPING_PROVIDERS = mappingProviders;
    return mappingProviders;
  }

  protected LocalContainerEntityManagerFactoryBean getEntityManagerFactory(DataSource dataSource, String puName, Properties jpaProperties, String... packageToScan) {

    loadMappingProviders();

    LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(dataSource);
    em.setPersistenceUnitName(puName);

    if(ArrayUtils.isNotEmpty(packageToScan)){
      em.setPackagesToScan(packageToScan);
    }

    em.setJpaVendorAdapter(getVendorAdapter());

    em.setJpaProperties(jpaProperties);

    if(getPersistenceUnitPostProcessors() != null){
      em.setPersistenceUnitPostProcessors(getPersistenceUnitPostProcessors());
    }

    return em;
  }

  private HibernateJpaVendorAdapter getVendorAdapter() {
    return new HibernateJpaVendorAdapter();
  }

  protected Properties jpaProperties(String dataSourceName) {
    Properties properties = getMergedJpaProperties(dataSourceName);
    if(getCachedProperties().containsKey(dataSourceName)){
      return getCachedProperties().get(dataSourceName);
    }else{
      getCachedProperties().put(dataSourceName, properties);
      return properties;
    }
  }

  protected Properties getMergedJpaProperties(String puName){
    Properties props = PropertyUtil.merge(true, getDefaultHibernateProperties(), hibernateProperties);
    if(DataSourceBuilder.ADDITIONAL_PROPERTIES.containsKey(puName)){
      props = PropertyUtil.merge(true, props, DataSourceBuilder.ADDITIONAL_PROPERTIES.get(puName));
    }
    return props;
  }

  private Properties getDefaultHibernateProperties() {
    if(defaultHibernateProperties != null && defaultHibernateProperties.size() > 0){
      return defaultHibernateProperties;
    }else{
      Properties props = new Properties();
      props.put("hibernate.hbm2ddl.auto", "create");
      props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
      props.put("hibernate.transaction.flush_before_completion", "false");
      props.put("hibernate.cache.region.factory_class", "org.redisson.hibernate.RedissonRegionFactory");
      props.put("hibernate.javax.cache.provider", "org.redisson.jcache.JCachingProvider");
      props.put("hibernate.cache.redisson.fallback", "true");
      props.put("hibernate.cache.redisson.config", "redisson-dev.yml");
      props.put("hibernate.cache.use_second_level_cache", "true");
      props.put("hibernate.cache.use_query_cache", "true");
      props.put("hibernate.generate_statistics", "false");
      props.put("hibernate.archive.autodetection", "false");
      props.put("hibernate.id.new_generator_mappings", "true");
      props.put("hibernate.id.optimizer.pooled.prefer_lo", "true");
      props.put("hibernate.jdbc.batch_size", "30");
      props.put("hibernate.order_inserts", "true");
      props.put("hibernate.order_updates", "true");
      props.put("hibernate.connection.provider_disables_autocommit", "false");
      props.put("hibernate.connection.zeroDateTimeBehavior", "convertToNull");
      props.put("hibernate.query.fail_on_pagination_over_collection_fetch", "true");
      props.put("hibernate.query.in_clause_parameter_padding", "true");
      props.put("hibernate.jdbc.batch_versioned_data", "true");
      props.put("hibernate.javax.cache.missing_cache_strategy", "create");
      props.put("hibernate.enhancer.enableLazyInitialization", "true");
      props.put("hibernate.bytecode.use_reflection_optimizer", "false");
      props.put("hibernate.bytecode.enforce_legacy_proxy_classnames", "true");
      // props.put("hibernate.bytecode.provider", "javassist"); // class transformer 가 별도로 동작하므로 이 설정은 아예 필요 없다

      return props;
    }
  }

  @Autowired
  protected List<PersistenceUnitPostProcessor> postPersistenceUnitProcessors;

  protected PersistenceUnitPostProcessor[] getPersistenceUnitPostProcessors(){
    PersistenceUnitPostProcessor[] processors = postPersistenceUnitProcessors.toArray(new PersistenceUnitPostProcessor[0]);

    return processors;
  }

  protected DataSource getDataSource(String dataSourceName){
    DataSource dataSource;

    Collections.sort(dataSourceBuilders, Comparator.comparing(Ordered::getOrder));

    for(DataSourceBuilder builder : dataSourceBuilders){
      Map<String, Properties> props = builder.translateDataSourceProperties(datasourceProperties, dataSourceName);
      if(MapUtils.isNotEmpty(props)){
        dataSource = builder.getDataSource(dataSourceName, props);
        if(dataSource != null){
          return dataSource;
        }
      }
    }

    throw new RuntimeException("There is no configured datasource");
  }

  public static void massIndex(String massIndexerBeanName, String targetEntityClassName){
    try {
      Class<?> entity = Class.forName(targetEntityClassName);

      massIndex(massIndexerBeanName, entity, 50);

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
      // nothing to do
    }
  }

  public static void massIndex(String massIndexerBeanName, Class<?> entity, Integer pageSize){
    HibernateSearchMassIndexer indexer = ApplicationContextHolder.getBean(massIndexerBeanName, HibernateSearchMassIndexer.class);

    if(indexer != null){

      if(pageSize == null)
        pageSize = 50;

      int allCount = indexer.getRecordCount(entity);

      if(allCount > 0){
        // paging 처리

        Object lastId = null;

        while(true) {

          TransactionStatus status = TransactionHelper.createTransaction("DO_MASS_INDEX",
              TransactionDefinition.PROPAGATION_REQUIRED);

          try {
            lastId = indexer.doMassIndexAndGetLastId(entity, pageSize, lastId);
            // get id
            TransactionHelper.finalizeTransaction(status, false);
          } catch (Exception e){
            TransactionHelper.finalizeTransaction(status, true);
          } finally {
            if(lastId == null){
              break;
            }
          }

        }
      }

    }

  }



}
