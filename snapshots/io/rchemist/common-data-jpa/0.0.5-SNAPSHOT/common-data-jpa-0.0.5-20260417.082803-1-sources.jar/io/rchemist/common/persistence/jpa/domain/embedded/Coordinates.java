/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.embedded;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.embedded.ICoordinate;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.search.engine.spatial.GeoPoint;
import org.hibernate.search.mapper.pojo.bridge.builtin.annotation.Latitude;
import org.hibernate.search.mapper.pojo.bridge.builtin.annotation.Longitude;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Builder
public class Coordinates implements GeoPoint, ICoordinate {

  @Longitude
  @Column(name = "LONGITUDE")
  @Description(name = "경도")
  private Double longitude;

  @Latitude
  @Column(name = "LATITUDE")
  @Description(name = "위도")
  private Double latitude;

  @Override
  public double longitude() {
    return longitude == null ? Double.NaN : longitude;
  }

  @Override
  public double latitude() {
    return latitude == null ? Double.NaN : latitude;
  }

  public Double getLongitude() {
    return longitude();
  }

  public Double getLatitude() {
    return latitude();
  }
}
