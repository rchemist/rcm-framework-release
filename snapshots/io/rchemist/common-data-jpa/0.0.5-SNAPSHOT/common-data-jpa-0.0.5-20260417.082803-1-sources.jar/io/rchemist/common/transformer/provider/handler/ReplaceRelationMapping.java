/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider.handler;

import io.rchemist.common.persistence.jpa.config.mapping.dto.RelationMappingDTO;
import io.rchemist.common.transformer.config.Annotations;
import io.rchemist.common.transformer.dto.TransformResult;
import jakarta.persistence.CascadeType;
import java.util.ArrayList;
import java.util.List;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.EnumMemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Component
public class ReplaceRelationMapping extends AbstractReplaceMappingHandler {

  @Override
  protected boolean canHandle(TransformResult result, RelationMappingDTO dto, Annotation annotation) {
    return annotation.getTypeName().equals(Annotations.PERSISTENCE_ONE_TO_MANY_CLASS)
        || annotation.getTypeName().equals(Annotations.PERSISTENCE_ONE_TO_ONE_CLASS)
        || annotation.getTypeName().equals(Annotations.PERSISTENCE_MANY_TO_ONE_CLASS)
        || annotation.getTypeName().equals(Annotations.PERSISTENCE_MANY_TO_MANY_CLASS);
  }

  @Override
  protected Annotation copyNewAnnotation(TransformResult result, RelationMappingDTO dto, Annotation annotation, Annotation newAnno, String valueName) {

    if (valueName.equals("targetEntity") && dto.hasTargetMappingClass()) {
      newAnno.addMemberValue(valueName, new ClassMemberValue(dto.getTargetMappingClass(), result.getConstPool()));
    } else if (valueName.equals("mappedBy") && dto.hasMappedByKey()) {
      newAnno.addMemberValue(valueName, new StringMemberValue(dto.getMappedByKey(), result.getConstPool()));
    } else if (valueName.equals("cascade") && dto.hasCascadeTypes()) {
      ArrayMemberValue cascades = new ArrayMemberValue(result.getConstPool());

      List<EnumMemberValue> newValues = new ArrayList<>();
      for (CascadeType cascadeType : dto.getCascadeTypes()) {
        EnumMemberValue value = new EnumMemberValue(result.getConstPool());
        value.setType(CascadeType.class.getName());
        value.setValue(cascadeType.name());
        newValues.add(value);
      }
      EnumMemberValue[] cascadeValues = newValues.toArray(new EnumMemberValue[newValues.size()]);
      cascades.setValue(cascadeValues);
      newAnno.addMemberValue(valueName, cascades);
    } else {
      newAnno.addMemberValue(valueName, annotation.getMemberValue(valueName));
    }

    return newAnno;
  }
}