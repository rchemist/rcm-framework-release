/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.jpa.domain.template.Historical;
import io.rchemist.common.persistence.jpa.domain.template.HistoricalUUID;
import io.rchemist.common.persistence.jpa.domain.template.Priority;
import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import io.rchemist.common.web.service.data.HasIdEntity;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Slf4j
public class QuerySpecification<T extends Serializable, S extends SearchFormWrapper<S>> implements Specification<T> {


  private final S searchForm;

  private final Class<T> entityClass;

  private final Map<ConditionOperatorType, QueryCondition> conditions = new LinkedHashMap<>();

  private final Map<String, Join<T, ?>> joinPaths = new LinkedHashMap<>();

  private final List<JoinedSortProperty> joinedSortProperties = new ArrayList<>();

  // unmapped join 을 위한 메타데이터. #mergeConditions 에 의해 query 및 predicate 로 전환된다.
  private final Map<ConditionOperatorType, List<UnmappedJoinItem>> unmappedJoinItems = new LinkedHashMap<>();

  // unmapped join 을 수행해 얻은 join 객체 Map<joinAlias, join>
  private final Map<String, Root<?>> unmappedJoinPaths = new LinkedHashMap<>();

  private final Map<String, String> unmappedJoinSortProperties = new LinkedHashMap<>();
  
  private final Map<String, SortJoinConfiguration> sortJoinConfigurations = new LinkedHashMap<>();

  private final List<Predicate> mustPredicates = new ArrayList<>();
  private final List<Predicate> shouldPredicates = new ArrayList<>();

  // Predicate caching for performance optimization
  private Predicate cachedDataPredicate;
  private Predicate cachedCountPredicate;

  // Helper classes for responsibility separation
  private final JoinManager<T> joinManager = new JoinManager<>();
  private final PredicateBuilder<T> predicateBuilder = new PredicateBuilder<>();
  private final SortProcessor<T> sortProcessor = new SortProcessor<>(joinManager);
  private final ConditionManager<T, S> conditionManager;
  private final PredicateMerger<T> predicateMerger;

  private String[] explicitFilterNames;

  @Setter
  private boolean preserveContext = false;

  @Getter(AccessLevel.NONE)
  private boolean shouldComputeOrders = true;

  @Setter
  private boolean preventDefaultOrders = false;

  private List<Order> orders;

  public QuerySpecification(Class<T> entityClass, S searchForm, String... propertyNames) {
    this.searchForm = searchForm;
    this.entityClass = entityClass;

    // 초기화 로직을 분리된 클래스에 위임
    QuerySpecificationInitializer<T, S> initializer = new QuerySpecificationInitializer<>(entityClass, searchForm, conditions);
    this.explicitFilterNames = initializer.initialize(propertyNames);
    
    // Helper 클래스들 초기화
    this.conditionManager = new ConditionManager<>(searchForm, conditions, explicitFilterNames);
    this.predicateMerger = new PredicateMerger<>(entityClass, conditions, joinPaths, unmappedJoinPaths, unmappedJoinItems, mustPredicates, shouldPredicates);
  }

  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, QueryConditionType conditionType, String... propertyNames){
    conditionManager.addConditions(conditionOperatorType, conditionType, propertyNames);
    return this;
  }


  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, String propertyName, QueryConditionType conditionType, Object value){
    conditionManager.addConditions(conditionOperatorType, propertyName, conditionType, value);
    return this;
  }

  public QuerySpecification<T, S> addConditionsWithJoin(ConditionOperatorType conditionOperatorType, String propertyName, QueryConditionType conditionType, Object value, JoinType joinType){
    conditionManager.addConditionsWithJoin(conditionOperatorType, propertyName, conditionType, value, joinType);
    return this;
  }

  public QuerySpecification<T, S> addConditions(ConditionOperatorType conditionOperatorType, QueryCondition... queryConditions){
    if(queryConditions == null || ArrayUtils.isEmpty(queryConditions))
      return this;
    
    conditionManager.addConditions(conditionOperatorType, queryConditions);
    return this;
  }


  public QuerySpecification<T, S> clearConditions(){
    this.conditions.clear();
    return this;
  }

  public QuerySpecification<T, S> clearCondition(String... propertyNames){
    if(propertyNames != null){
      for(String propertyName : propertyNames){
        this.conditions.remove(propertyName);
      }
    }
    return this;
  }

  public <J> Join<T, J> getJoinPath(Root<T> root, String path, JoinType joinType){
    // Delegate to JoinManager for consistent join handling
    Join<T, J> join = joinManager.getOrCreateJoin(root, path, joinType);
    
    // Sync with legacy joinPaths map for backward compatibility
    String key = path + "||" + joinType.name();
    if (!joinPaths.containsKey(key)) {
      joinPaths.put(key, join);
    }
    
    return join;
  }

  @Override
  public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
    try {
      // Determine if this is a count query by checking the result type
      boolean isCountQuery = query.getResultType() == Long.class;
      
      log.debug("Building predicate for entity: {}, isCountQuery: {}", entityClass.getSimpleName(), isCountQuery);
      
      // Return cached predicate if available
      if (isCountQuery && cachedCountPredicate != null) {
        log.debug("Returning cached count predicate");
        return cachedCountPredicate;
      } else if (!isCountQuery && cachedDataPredicate != null) {
        log.debug("Returning cached data predicate");
        return cachedDataPredicate;
      }

      Predicate predicate = null;

      // conditions 을 모두 mustPredicates 와 shouldPredicates 으로 묶는다.
      predicateMerger.mergeAllConditions(root, query, criteriaBuilder);

      // withDistinct() 가 설정된 경우 중복 결과를 제거한다.
      if (searchForm instanceof AbstractSearchForm<?> form && form.isDistinct()) {
        query.distinct(true);
      }

      // EXISTS 서브쿼리 처리
      if (searchForm instanceof AbstractSearchForm<?> form) {
        List<ExistsFilterItem> existsFilters = form.getExistsFilters();
        if (CollectionUtils.isNotEmpty(existsFilters)) {
          for (ExistsFilterItem existsFilter : existsFilters) {
            Predicate existsPredicate = buildExistsPredicate(existsFilter, root, query, criteriaBuilder);
            if (existsPredicate != null) {
              mustPredicates.add(existsPredicate);
            }
          }
        }
      }

      setSortOrders(root, query, criteriaBuilder);

      // Use PredicateBuilder to create the final predicate
      predicate = predicateBuilder.buildFinalPredicate(mustPredicates, shouldPredicates, criteriaBuilder);
      
      // Validate and log the result
      predicate = predicateBuilder.validateAndLog(predicate, entityClass.getSimpleName());

      // Cache the generated predicate for reuse
      if (isCountQuery) {
        cachedCountPredicate = predicate;
      } else {
        cachedDataPredicate = predicate;
      }

      if (!preserveContext) {
        /*
        SimpleJpaRepository 에서 specification#toPredicate 는 select row 쿼리에서 한번, select count 쿼리에서 한번, 두번 호출된다.
        두번째 실행할 때 앞에서 만든 임시 정보를 모두 제거해야 한다.
        하지만 필요에 따라 preserveContext 를 true 로 한 경우에는 값을 지우지 않는다.
       */
        resetContextForReuse();
      }

      // paging 처리
      return predicate;
      
    } catch (Exception e) {
      log.error("Error building predicate for entity: {}, error: {}", entityClass.getSimpleName(), e.getMessage(), e);
      
      // Reset context on error to prevent corrupted state
      if (!preserveContext) {
        resetContextForReuse();
      }
      
      // Rethrow as runtime exception to maintain existing API contract
      throw new IllegalStateException("Failed to build query predicate for " + entityClass.getSimpleName(), e);
    }
  }

  /**
   * SimpleJpaRepository 에서 specification#toPredicate 는 select row 쿼리에서 한번, select count 쿼리에서 한번, 두번 호출된다.
   * 두번째 실행할 때 앞에서 만든 임시 정보를 모두 제거해야 한다.
   */
  private void resetContextForReuse() {
    if (shouldComputeOrders) {
      this.mustPredicates.clear();
      this.shouldPredicates.clear();
      this.joinPaths.clear();
      this.unmappedJoinPaths.clear();
      this.shouldComputeOrders = false;
      
      // Clear helper class caches
      this.joinManager.clearCache();
    }
  }

  /**
   * ExistsFilterItem 으로부터 EXISTS (또는 NOT EXISTS) 서브쿼리 Predicate 를 생성한다.
   */
  private Predicate buildExistsPredicate(ExistsFilterItem item, Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
    // 1. 서브쿼리 생성 (EXISTS 는 존재 여부만 확인하므로 SELECT 1)
    Subquery<Integer> subquery = query.subquery(Integer.class);
    Root<?> subRoot = subquery.from(item.getTargetEntityClass());
    subquery.select(cb.literal(1));

    List<Predicate> subPredicates = new ArrayList<>();

    // 2. Join 조건: subRoot 의 targetJoinPath = root 의 rootJoinPath
    subPredicates.add(cb.equal(
        resolvePathFromRoot(subRoot, item.getTargetJoinPath()),
        resolvePathFromRoot(root, item.getRootJoinPath())
    ));

    // 3. 추가 조건: FilterItem[] 순회, QueryHelper.getConditionPredicate() 재사용
    FilterItem[] conditions = item.getConditions();
    if (ArrayUtils.isNotEmpty(conditions)) {
      for (FilterItem filterItem : conditions) {
        Path<?> conditionPath = resolvePathFromRoot(subRoot, filterItem.getName());
        Predicate conditionPredicate = QueryHelper.getConditionPredicate(
            cb, filterItem.getQueryConditionType(), conditionPath,
            filterItem.getValue(),
            filterItem.getValues() != null ? Arrays.asList(filterItem.getValues()) : null
        );
        if (conditionPredicate != null) {
          subPredicates.add(conditionPredicate);
        }
      }
    }

    subquery.where(subPredicates.toArray(new Predicate[0]));

    // 4. EXISTS 또는 NOT EXISTS 반환
    if (item.isNegated()) {
      return cb.exists(subquery).not();
    }
    return cb.exists(subquery);
  }

  /**
   * dot-notation 경로 ("selection.id") 를 JPA Path 로 변환한다.
   * ManyToOne 관계는 JPA implicit join 으로 자동 처리된다.
   */
  private Path<?> resolvePathFromRoot(Root<?> root, String dotPath) {
    Path<?> path = root;
    for (String segment : StringUtils.split(dotPath, ".")) {
      path = path.get(segment);
    }
    return path;
  }

  private void setSortOrders(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
    List<Order> orders = new ArrayList<>();

    // 1. JoinedSortProperty 처리 (기존 로직 유지)
    if(CollectionUtils.isNotEmpty(joinedSortProperties)){
      for(JoinedSortProperty property : joinedSortProperties){
        String path = property.getPath();
        JoinType joinType = property.getJoinType();

        String joinPath = StringUtil.subStringBefore(path, ".");
        String propertyPath = StringUtil.subStringAfter(path, ".");
        String joinMapKey = joinPath + "||" + joinType;

        Join join = null;
        if(joinPaths.containsKey(joinMapKey)){
          join = joinPaths.get(joinMapKey);
        }

        if(join == null){
          join = root.join(joinPath, property.getJoinType());
          joinPaths.put(joinMapKey, join);
        }

        Path sortPath = join;
        for(String p : StringUtil.split(propertyPath, ".")){
          sortPath = sortPath.get(p);
        }

        QueryConditionItem conditionItem = property.getJoinCondition();
        Path conditionPath;

        if(conditionItem instanceof SingleConditionItem){
          conditionPath = join.get(((SingleConditionItem) conditionItem).getPropertyName());
        }else{
          conditionPath = join;
        }

        join.on(property.getJoinCondition().getPredicate(criteriaBuilder, conditionPath));

        if(property.getDirection().equals(Direction.DESC)){
          orders.add(criteriaBuilder.desc(sortPath));
        }else{
          orders.add(criteriaBuilder.asc(sortPath));
        }
      }
    }

    // 2. SearchForm의 sorts 처리 (List<SortEntry> 구조)
    List<SortEntry> sortEntries = searchForm.getSorts();

    boolean sortedPriority = false;
    boolean sortedCreatedAt = false;
    boolean sortedId = false;

    if(CollectionUtils.isNotEmpty(sortEntries)){
      // List의 순서대로 처리 (동일 필드에 대한 다중 정렬 지원)
      for(SortEntry entry : sortEntries){
        String propertyName = entry.getFieldName();
        SortInfo sortInfo = entry.getSortInfo();

        if (sortInfo == null) {
          continue;
        }

        if (propertyName.equals("createdAt")) {
          sortedCreatedAt = true;
        } else if (propertyName.equals("id")) {
          sortedId = true;
        }

        // SortInfo에 JOIN 타입이 설정된 경우 적용
        if (sortInfo.getJoinType() != null) {
          configureSortJoin(propertyName, sortInfo.getJoinType());
        }

        // Path 해결 로직
        Path<?> path = resolveSortPath(root, query, propertyName);
        if(path == null) continue;

        // SortInfo에서 JPA Order들 생성 (우선순위 정렬의 경우 여러 Order 반환)
        List<Order> sortOrders = sortInfo.createJpaOrders(criteriaBuilder, path);
        orders.addAll(sortOrders);
      }
    }

    if (!preventDefaultOrders) {
      if (!sortedPriority && Priority.class.isAssignableFrom(entityClass)) {
        orders.add(criteriaBuilder.asc(
            criteriaBuilder.coalesce(root.get("priority"), 100)
        ));
      }


      if (!sortedCreatedAt) {
        if(EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)
            || EssentialUUIDEntity.class.isAssignableFrom(entityClass)
            || HistoricalUUID.class.isAssignableFrom(entityClass)
        ){
          orders.add(criteriaBuilder.desc(root.get("createdAt")));
        }
      }

      if (!sortedId) {
        // ID 는 반드시 TSID 또는 LONG 타입이어야 한다.
        if(HasIdEntity.class.isAssignableFrom(entityClass)) {
          orders.add(criteriaBuilder.desc(root.get("id")));
        }
      }

    }

    if(CollectionUtils.isNotEmpty(orders)){
      query.orderBy(orders);
      this.orders = orders;
    }

  }


  /**
   * 정렬 대상 Path를 해결하는 메서드
   * unmapped join, 일반 join, 단순 필드 순서로 처리
   */
  private Path<?> resolveSortPath(Root<T> root, CriteriaQuery<?> query, String propertyName) {
    Path<?> path;
    String fullPath = propertyName;
    
    // 1. unmapped join 처리
    if(unmappedJoinSortProperties.containsKey(propertyName)){
      String realPath = unmappedJoinSortProperties.get(propertyName);
      String rootAlias = StringUtil.subStringBefore(realPath, ".");
      Root<?> joinRoot = unmappedJoinPaths.get(rootAlias);

      if(joinRoot == null) return null;

      path = joinRoot;
      fullPath = StringUtil.subStringAfter(realPath, ".");
      query.distinct(false); // unmapped join에서 distinct 해제
    } else {
      path = root;
    }

    // 2. path 내비게이션 (일반 join 또는 단순 필드)
    if (fullPath.contains(".")) {
      // SortJoinConfiguration 확인
      SortJoinConfiguration sortConfig = sortJoinConfigurations.get(propertyName);
      JoinType joinTypeToUse = (sortConfig != null && sortConfig.isEnabled()) 
          ? sortConfig.getJoinType() 
          : JoinType.LEFT; // 기본값을 LEFT로 변경
      
      // join path 처리
      boolean joinPathFound = false;
      String joinPath = StringUtil.subStringBefore(fullPath, ".");
      String propertyPath = StringUtil.subStringAfter(fullPath, ".");

      // JOIN 타입을 포함한 키로 검색
      String joinKeyWithType = joinPath + "||" + joinTypeToUse.name();
      
      if (joinPaths.containsKey(joinKeyWithType)) {
        path = joinPaths.get(joinKeyWithType);
        joinPathFound = true;
      } else {
        // 해당 JOIN이 없으면 새로 생성
        Join<T, ?> newJoin = joinManager.getOrCreateJoin(root, joinPath, joinTypeToUse);
        joinPaths.put(joinKeyWithType, newJoin);
        path = newJoin;
        joinPathFound = true;
      }

      String[] pathArray = joinPathFound ? 
        StringUtils.split(propertyPath, ".") : 
        StringUtils.split(fullPath, ".");

      for (String prop : pathArray) {
        path = path.get(prop);
      }
    } else {
      // 단순 필드
      path = path.get(fullPath);
    }

    return path;
  }


  public boolean isEmpty(){
    boolean empty = MapUtils.isEmpty(conditions) && MapUtils.isEmpty(unmappedJoinItems);

    if(empty)
      return true;

    // key 만 존재하고 실제 condition 은 적용되지 않은 경우에도 empty true 를 반환한다.
    for(QueryCondition condition : conditions.values()){
      if(!condition.isEmpty()){
        return false;
      }
    }

    return false;   // unmapped join items 때문에 무조건 false 가 된다.

  }

  public QuerySpecification<T, S> sortByJoinedProperty(JoinType joinType, String joinPath, Direction direction, QueryConditionItem joinCondition) {
    direction = (direction == null) ? Direction.ASC : direction;
    for(JoinedSortProperty joinedSortProperty : CollectionUtils.emptyIfNull(joinedSortProperties)){
      if(joinedSortProperty.getPath().equals(joinPath)){
        return this;
      }
    }

    joinedSortProperties.add(new JoinedSortProperty(joinPath, joinType, direction, joinCondition));

    return this;
  }

  public QuerySpecification<T, S> addUnmappedConditions(ConditionOperatorType operator, UnmappedJoinItem... unmappedJoinItem) {
    List<UnmappedJoinItem> items;
    if(unmappedJoinItems.containsKey(operator)){
      items = unmappedJoinItems.get(operator);
      items.addAll(Arrays.asList(unmappedJoinItem));
    }else{
      items = CollectionUtil.list(unmappedJoinItem);
    }
    unmappedJoinItems.put(operator, items);
    return this;
  }

  public QuerySpecification<T, S> sortByUnmappedJoinedProperty(String sortProperty, String alternative) {
    this.unmappedJoinSortProperties.put(sortProperty, alternative);
    return this;
  }
  
  /**
   * 정렬 시 사용할 JOIN 타입을 설정합니다.
   * @param sortPath 정렬 경로 (예: "subject.major.name")
   * @param joinType JOIN 타입 (LEFT, INNER 등)
   * @return this
   */
  public QuerySpecification<T, S> configureSortJoin(String sortPath, JoinType joinType) {
    this.sortJoinConfigurations.put(sortPath, SortJoinConfiguration.builder()
        .sortPath(sortPath)
        .joinType(joinType)
        .build());
    return this;
  }
  
  /**
   * 정렬 시 사용할 JOIN 설정을 추가합니다.
   * @param configuration JOIN 설정
   * @return this
   */
  public QuerySpecification<T, S> configureSortJoin(SortJoinConfiguration configuration) {
    if (configuration != null && configuration.getSortPath() != null) {
      this.sortJoinConfigurations.put(configuration.getSortPath(), configuration);
    }
    return this;
  }

  // Getter methods for accessing internal state
  public S getSearchForm() {
    return searchForm;
  }

  public Class<T> getEntityClass() {
    return entityClass;
  }

  public Map<ConditionOperatorType, QueryCondition> getConditions() {
    return conditions;
  }

  public Map<String, Join<T, ?>> getJoinPaths() {
    return joinPaths;
  }

  public List<JoinedSortProperty> getJoinedSortProperties() {
    return joinedSortProperties;
  }

  public Map<ConditionOperatorType, List<UnmappedJoinItem>> getUnmappedJoinItems() {
    return unmappedJoinItems;
  }

  public Map<String, Root<?>> getUnmappedJoinPaths() {
    return unmappedJoinPaths;
  }

  public String[] getExplicitFilterNames() {
    return explicitFilterNames;
  }

  public List<Predicate> getMustPredicates() {
    return mustPredicates;
  }

  public List<Predicate> getShouldPredicates() {
    return shouldPredicates;
  }
}
