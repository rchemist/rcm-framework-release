/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.listener.SiteAliasListener;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(SiteAlias.class)
@Getter
@Setter
@EntityListeners(SiteAliasListener.class)
public class SiteAliasImpl implements EnhancedTemplate {

  @Column(name = "SITE_ALIAS")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "사이트 Alias", comment = "사이트 정보")
  protected String siteAlias;

  @Column(name = "TENANT_ID")
  @IndexField
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "테넌트 Alias", comment = "테넌트 정보")
  protected String tenantAlias;

}
