/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template.listener;

import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import java.lang.reflect.Method;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TenantIdListener {

  @PreUpdate
  @PreRemove
  @PrePersist
  public void setTenant(Object entity) {

    WebRequestContext context = WebRequestContext.getWebRequestContext();

    // admin 이 아닐 때만 실행한다
    if(context != null && !context.isAdmin() && context.getSiteAlias() != null){
      try {
        Method getTenantId = entity.getClass().getMethod("getTenantId");
        Object tenantId = getTenantId.invoke(entity);

        if (tenantId == null) {
          Method setTenantId = entity.getClass().getMethod("setTenantId", String.class);
          final String tenantIdValue = (WebRequestContext.getWebRequestContext() == null) ? null : WebRequestContext.getWebRequestContext().getTenantId();
          setTenantId.invoke(entity, tenantIdValue);
        }

      }catch (Exception e) {
        //silent ignore
      }
    }

  }

}
