/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(NameDescription.class)
@Getter
@Setter
public class NameDescriptionImpl implements Serializable, EnhancedTemplate {

  @Column(name = "NAME")
  @AdminField(name = "NameDescriptionImpl_Name", fieldType = PresentationFieldType.STRING, order = 200
      , headerField = @HeaderField(order = 200), required = true
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 200)
  )
  @GenericField(sortable = Sortable.YES)
  @Description(name = "이름", comment = "이름")
  protected String name;

  @Column(name = "DESCRIPTION")
  @Text
  @AdminField(name = "NameDescriptionImpl_Description", fieldType = PresentationFieldType.TEXT, order = 210
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 210)
  )
  @Description(name = "설명", comment = "설명")
  protected String description;

}
