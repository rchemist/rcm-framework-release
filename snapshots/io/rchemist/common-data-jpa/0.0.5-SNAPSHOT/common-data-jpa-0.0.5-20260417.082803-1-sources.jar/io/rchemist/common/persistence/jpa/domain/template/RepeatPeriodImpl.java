/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.RepeatPeriodType;
import jakarta.persistence.Column;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(RepeatPeriod.class)
@Getter
@Setter
public class RepeatPeriodImpl implements Serializable, EnhancedTemplate {

  @Column(name = "REPEAT_PERIOD_TYPE")
  /*// @AdminPresentation(friendlyName = "RepeatPeriodImpl_PeriodType", order = 2000
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Rank.TYPE, order = Rank.ORDER)
      , broadleafEnumeration = "io.rchemist.common.util.type.RepeatPeriodType"
      , tooltip = "RepeatPeriodImpl_PeriodType_Tooltip"
      , defaultValue = "MONTHLY"
      , dependentVisible = true
      , derivedVisible = {@DerivedVisibleValue(value = {"PER_MONTHS", "PER_DAYS"}, derivedPropertyName = {"repeatPeriod", "periodBaseDate"})
      , @DerivedVisibleValue(value = {"YEARLY"}, derivedPropertyName = {"periodMonthDay"})
      , @DerivedVisibleValue(value = {"MONTHLY"}, derivedPropertyName = {"dueDay"})}
      , fieldType = SupportedFieldType.BROADLEAF_ENUMERATION
      , validationConfigurations = {
      @ValidationConfiguration(validationImplementation = "rcmConditionalRequiredValidator",
          configurationItems = {@ConfigurationItem(itemDetails = {
              @ConfigurationItemDetail(itemName = "PER_DAYS:repeatPeriod,periodBaseDate", itemValue = "error.message.field.conditional.required.per.days")
            , @ConfigurationItemDetail(itemName = "PER_MONTHS:repeatPeriod,periodBaseDate", itemValue = "error.message.field.conditional.required.per.months")
            , @ConfigurationItemDetail(itemName = "YEARLY:periodMonthDay", itemValue = "error.message.field.conditional.required.yearly")
            , @ConfigurationItemDetail(itemName = "MONTHLY:dueDay", itemValue = "error.message.field.conditional.required.monthly")
          })})
  }
      , requiredOverride = RequiredOverride.REQUIRED)*/
  @Description(name = "반복되는 기간의 형태", comment = "n년 동안, n월 동안, n일 동안과 같은 반복되는 기간의 형태")
  protected String repeatPeriodType;

  @Column(name = "REPEAT_PERIOD_VALUE", length = 2)
  /*// @AdminPresentation(friendlyName = "RepeatPeriodImpl_Period", order = 3000
      , dependentVisible = true
        , tooltip = "RepeatPeriodImpl_Period_Tooltip"
      , validationConfigurations = {@ValidationConfiguration(validationImplementation = "rcmIsPositiveNumberValidator")}
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Rank.TYPE, order = Rank.ORDER))*/
  @Description(name = "반복 기간", comment = "반복 기간의 형태가 얼마 동안 지속할지에 대한 기간 정보")
  protected Integer repeatPeriod;

  @Column(name = "REPEAT_PERIOD_BASEDATE")
  /*// @AdminPresentation(friendlyName = "RepeatPeriodImpl_PeriodBaseDate", order = 3100
      , dependentVisible = true
      , fieldType = SupportedFieldType.DATE
      , prominent = true, gridOrder = 100300
      , hint = "YYYY-MM-DD"
      , tooltip = "RepeatPeriodImpl_PeriodBaseDate_Tooltip"
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Rank.TYPE, order = Rank.ORDER))*/
  @Description(name = "반복 시작 시간", comment = "repeatPeriodType 이 PER_MONTH, PER_DAYS 일 때 시작점이 되는 기준일")
  protected LocalDate periodBaseDate;

  @Column(name = "REPEAT_PERIOD_MONTH_DAY")
  /*// @AdminPresentation(friendlyName = "RepeatPeriodImpl_PeriodMonthDay", order = 3100
      , dependentVisible = true
      , fieldType = SupportedFieldType.MONTH_DAY
      , prominent = true, gridOrder = 100400
      , hint = "MM-DD"
      , tooltip = "RepeatPeriodImpl_PeriodMonthDay_Tooltip"
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Rank.TYPE, order = Rank.ORDER))*/
  @Description(name = "반복되는 기간의 형태", comment = "repeatPeriodType 이 YEARLY 일 때 몇월 몇일에 산정하는지")
  protected String periodMonthDay;

  @Column(name = "REPEAT_DUE_DAY", length = 2)
  /*// @AdminPresentation(friendlyName = "RepeatPeriodImpl_DueDay", order = 4000
      , dependentVisible = true
      , tooltip = "RepeatPeriodImpl_DueDay_Tooltip"
      , validationConfigurations = {@ValidationConfiguration(validationImplementation = "rcmCompareNumberValidator"
      , configurationItems = {
      @ConfigurationItem(itemName = "MIN_VALUE", itemValue = "1")
      , @ConfigurationItem(itemName = "MIN_VALUE_IS_PROPERTY", itemValue = "false")
      , @ConfigurationItem(itemName = "MAX_VALUE", itemValue = "31")
      , @ConfigurationItem(itemName = "MAX_VALUE_IS_PROPERTY", itemValue = "false")
  })}
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.Rank.TYPE, order = Rank.ORDER))*/
  @Description(name = "반복되는 기간의 형태", comment = "매월, PER 월 일 때 기준일. 1일 ~ 31 일 (29 이상의 날짜가 셋팅되는 경우 해당 월 마지막 날짜가 셋팅된 날짜보다 작으면 해당 월의 마지막 날짜로 자동 인식)")
  protected Integer dueDay;

  public RepeatPeriodType getRepeatPeriodType() {
    return EnumTypeUtil.getEnumType(RepeatPeriodType.class, repeatPeriodType);
  }

  public void setRepeatPeriodType(RepeatPeriodType repeatPeriodType) {
    this.repeatPeriodType = EnumTypeUtil.getType(repeatPeriodType);
  }

}
