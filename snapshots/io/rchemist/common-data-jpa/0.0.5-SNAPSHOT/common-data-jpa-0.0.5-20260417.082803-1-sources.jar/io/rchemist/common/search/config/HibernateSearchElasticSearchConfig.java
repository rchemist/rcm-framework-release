/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import io.rchemist.common.search.config.HibernateSearchConfig.HibernateSearchEnabled;
import org.hibernate.search.backend.elasticsearch.client.ElasticsearchHttpClientConfigurationContext;
import org.hibernate.search.backend.elasticsearch.client.ElasticsearchHttpClientConfigurer;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Conditional(HibernateSearchEnabled.class)
@Component
public class HibernateSearchElasticSearchConfig implements ElasticsearchHttpClientConfigurer {

  private static final int KEEP_ALIVE_MS = 20 * 60 * 1000;    // 20 minutes

  @Override
  public void configure(
      ElasticsearchHttpClientConfigurationContext context) {

    context.clientBuilder().setKeepAliveStrategy(((httpResponse, httpContext) -> KEEP_ALIVE_MS));

  }

}
