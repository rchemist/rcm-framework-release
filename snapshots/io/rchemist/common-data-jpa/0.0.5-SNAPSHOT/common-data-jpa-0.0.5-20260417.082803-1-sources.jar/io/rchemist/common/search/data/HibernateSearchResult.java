/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.util.NumberUtil;
import lombok.Getter;
import org.hibernate.search.engine.search.query.SearchResult;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class HibernateSearchResult<T> {

  public HibernateSearchResult(SearchResult<T> searchResult, int pageSize){
    int totalCount = NumberUtil.getInteger(searchResult.total().hitCount());
    this.result = searchResult;
    this.totalCount = totalCount;
    this.totalPage = totalCount == 0 ? 0 : (int) Math.ceil((double) totalCount / pageSize);
  }

  private final SearchResult<T> result;
  private final int totalCount;
  private final int totalPage;

}
