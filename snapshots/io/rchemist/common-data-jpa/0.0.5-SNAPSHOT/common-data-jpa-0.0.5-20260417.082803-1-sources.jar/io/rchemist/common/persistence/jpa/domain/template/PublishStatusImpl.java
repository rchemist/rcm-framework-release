/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.type.PublishStatusType;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.listener.PublishStatusListener;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(PublishStatus.class)
@EntityListeners(PublishStatusListener.class)
public class PublishStatusImpl implements EnhancedTemplate {

  @Column(name = "PUBLISH_STATUS")
  @IndexField
  @KeywordField
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @Description(name = "Publish 상태", comment = "PublishStatusType. PUBLISHED|DRAFT|OUT_DATED|DISCARDED")
  protected String publishStatus;

  public PublishStatusType getPublishStatus() {
    return EnumTypeUtil.getEnumType(PublishStatusType.class, this.publishStatus, PublishStatusType.DRAFT);
  }

  public void setPublishStatus(PublishStatusType publishStatus) {
    this.publishStatus = publishStatus == null ? PublishStatusType.DRAFT.getType() : publishStatus.getType();
  }

}
