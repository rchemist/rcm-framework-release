/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Value;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = PlatformEntityExtensionManager.BEAN_NAME, priority = 500)
public class RestrictTenantOnJpaEntityExtensionHandler implements PlatformEntityExtensionHandler {

  @Value("${platform.config.common.validator.restrict-tenant-on-jpa:true}")
  protected boolean restrictTenantOnJpa;

  @Override
  public boolean isEnabled() {
    return restrictTenantOnJpa;
  }

  @Override
  public ExtensionResultStatusType preMerge(ExtensionResultHolder<Object> erh, EntityManager em) {

    checkTenantAlias(erh);

    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  @Override
  public ExtensionResultStatusType preRemove(ExtensionResultHolder<Object> erh, EntityManager em) {
    checkTenantAlias(erh);
    return ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  private static void checkTenantAlias(ExtensionResultHolder<Object> erh) {
    if (erh != null && erh.hasResult() && TenantAlias.class.isAssignableFrom(
        erh.getResult().getClass())) {

      TenantAlias<?> tenantEntity = (TenantAlias<?>) erh.getResult();

      WebRequestContext context = WebRequestContext.getWebRequestContext();

      if (context == null) {
        // web request 에 의한 요청이 아닌 경우에는 체크하지 않는다.
        return;
      }

      // 관리자 게정인 경우에는 체크하지 않으며, allowedTenant 가 아닌 경우에는 exception 이 발생한다.
      if (!context.isAdmin() && !tenantEntity.isAllowedTenant(WebRequestContext.getCurrentTenantAlias())) {
        throw new PlatformSecurityException(PlatformSecurityErrorType.NOT_ALLOWED_TENANT_ALIAS);
      }

    }
  }

}
