/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.embedded.Coordinates;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Embedded;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.mapper.pojo.bridge.builtin.annotation.GeoPointBinding;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(Spatial.class)
@Getter
@Setter
public class SpatialImpl implements Serializable, EnhancedTemplate {

  @Embedded
  @GeoPointBinding
  protected Coordinates coordinates = new Coordinates();

  public double getLatitude(){
    initializeCoordinates();
    return coordinates.getLatitude();
  }

  public double getLongitude(){
    initializeCoordinates();
    return coordinates.getLongitude();
  }

  public void setLatitude(Double latitude){
    initializeCoordinates();
    coordinates.setLatitude(latitude);
  }

  public void setLongitude(Double longitude){
    initializeCoordinates();
    coordinates.setLongitude(longitude);
  }

  private void initializeCoordinates(){
    if (coordinates == null) {
      coordinates = new Coordinates();
    }
  }

}
