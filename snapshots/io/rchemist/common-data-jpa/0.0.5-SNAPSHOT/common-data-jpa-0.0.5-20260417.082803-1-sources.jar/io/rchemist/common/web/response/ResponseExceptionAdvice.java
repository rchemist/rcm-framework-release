/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import io.rchemist.common.exception.error.ErrorDTO;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RestControllerAdvice
@Slf4j
public class ResponseExceptionAdvice {

  @ExceptionHandler(Exception.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  protected ResponseData<?> defaultServerErrorException(HttpServletRequest request, Exception e){
    log.error(e.getMessage());
    
    // SSE 엔드포인트는 text/event-stream을 사용하므로 예외 처리 제외
    String contentType = request.getHeader("Accept");
    if (contentType != null && contentType.contains("text/event-stream")) {
      throw new RuntimeException(e);
    }

    if(e instanceof NoSuchBeanDefinitionException){
      return ResponseHelper.result(null, new ErrorDTO(e).withMessage("해당 기능을 지원하지 않습니다."));
    }

    return ResponseHelper.result(null, new ErrorDTO(e));
  }

}
