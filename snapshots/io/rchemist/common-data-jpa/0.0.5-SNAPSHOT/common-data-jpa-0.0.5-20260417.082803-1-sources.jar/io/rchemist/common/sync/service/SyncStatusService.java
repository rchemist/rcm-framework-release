/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.sync.service;

import io.rchemist.common.sync.dao.SyncStatusRepository;
import io.rchemist.common.sync.domain.SyncStatus;
import java.time.Duration;
import java.time.Instant;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Service("rcmSyncStatusService")
public class SyncStatusService {

  protected final SyncStatusRepository repository;

  private static final long defaultSeconds = 60 * 60;

  public SyncStatusService(SyncStatusRepository repository) {
    this.repository = repository;
  }

  /**
   * 해당 ID를 가진 서비스가 실행된 적이 있는지 여부
   * @param syncStatusId
   * @return
   */
  public boolean hasSynced(String syncStatusId) {
    SyncStatus syncStatus = repository.findBySyncId(syncStatusId);
    return syncStatus != null;
  }

  /**
   * 해당 ID를 가진 서비스가 X ms 이내에 실행된 적이 있는지 여부
   * @param syncStatusId
   * @param interval
   * @return
   */
  public boolean hasSynced(String syncStatusId, Long interval) {
    SyncStatus syncStatus = repository.findBySyncId(syncStatusId);
    if (syncStatus == null) {
      // syncStatus 가 null 이면 한번도 연동된 적이 없다는 뜻이다.
      return false;
    }

    if (interval == null) {
      // interval 이 null 이면 한번이라도 연동된 적이 있으면 true 라는 뜻이다.
      return true;
    }

    Instant now = Instant.now();
    Instant lastSynced = syncStatus.getLastUpdated();

    return Duration.between(lastSynced, now).getSeconds() <= interval;
  }

  @Transactional
  public void sync(String syncStatusId) {
    SyncStatus syncStatus = repository.findBySyncId(syncStatusId);
    if (syncStatus == null) {
      syncStatus = new SyncStatus();
      syncStatus.setSyncId(syncStatusId);
    } else {
      syncStatus.setUpdatedAt(Instant.now());
    }
    repository.save(syncStatus);
  }

  @Transactional
  public void fail(String syncStatusId) {
    repository.deleteBySyncId(syncStatusId);
  }

}
