/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import io.rchemist.common.configuration.type.ElasticSearchConfigType;
import io.rchemist.common.search.config.ElasticsearchProperties.ConfigEnabled;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@Conditional(ConfigEnabled.class)
@Configuration
@ConfigurationProperties(prefix = "spring.datasource.rcm-elastic.common")
public class ElasticsearchProperties {

  static class ConfigEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(context.getEnvironment().getProperty("platform.config.provider.elastic"), "NONE");
      config = config.toUpperCase();

      ElasticSearchConfigType configType = ElasticSearchConfigType.valueOf(config);

      return configType.equals(ElasticSearchConfigType.LOCAL);
    }
  }

  protected String host;

  protected String port;

  protected String username;

  protected String password;

  public ElasticsearchProperties setHostIfMissing(String host) {
    if(this.host == null) this.host = host;
    return this;
  }

  public ElasticsearchProperties setPortIfMissing(String port) {
    if(this.port == null) this.port = port;
    return this;
  }

  public ElasticsearchProperties setUsernameIfMissing(String username) {
    if(this.username == null) this.username = username;
    return this;
  }

  public ElasticsearchProperties setPasswordIfMissing(String password) {
    if(this.password == null) this.password = password;
    return this;
  }
}
