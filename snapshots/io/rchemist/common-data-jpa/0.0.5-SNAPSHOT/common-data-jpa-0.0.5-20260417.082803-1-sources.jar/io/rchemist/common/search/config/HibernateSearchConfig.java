/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Configuration
@Getter
@Setter
public class HibernateSearchConfig {

  @Value("${spring.jpa.properties.hibernate.search.enabled:false}")
  protected boolean hibernateSearchEnabled = false;

  static class HibernateSearchEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(context.getEnvironment().getProperty("spring.jpa.properties.hibernate.search.enabled"), "false");
      return BooleanUtils.toBoolean(config);
    }
  }

}
