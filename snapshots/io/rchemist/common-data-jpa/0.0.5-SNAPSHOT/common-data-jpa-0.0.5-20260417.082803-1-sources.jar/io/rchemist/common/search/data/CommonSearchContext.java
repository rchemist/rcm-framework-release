/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.jpa.domain.template.Historical;
import io.rchemist.common.persistence.jpa.domain.template.HistoricalUUID;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.query.JoinedSortProperty;
import io.rchemist.common.search.data.query.QueryCondition;
import io.rchemist.common.search.data.query.QueryConditionItem;
import io.rchemist.common.search.data.query.QuerySpecification;
import io.rchemist.common.search.data.query.QuerySpecificationCache;
import io.rchemist.common.search.data.query.UnmappedJoinItem;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class CommonSearchContext<T extends Serializable, S extends SearchFormWrapper<S>> implements SearchContext<T, S>{

  private static final String CACHE_KEY_SPLITTER = "_";

  @Getter
  private Class<T> entityClass;

  private S searchForm;

  private QuerySpecification<T, S> specification;

  private String[] explicitSearchFields;

  private Map<String, String> unmappedSortProperties = new HashMap<>();

  @Getter
  private boolean forceFetchFromDB = false;

  @Getter
  private boolean shouldReturnEmpty = false;

  public CommonSearchContext(Class<T> entityClass, S searchForm, String... explicitSearchFields) {
    this.entityClass = entityClass;

    // SearchForm 인 경우 filters, sorts 를 검증하고, preservedFilterAndSortCriteria 를 생성한다.
    if (searchForm instanceof FilterMapSearchForm<?> searchFormInstance) {
      searchFormInstance.preparePreservedFilterAndSortCriteria(entityClass, false);
    }

    this.searchForm = searchForm;

    if (ArrayUtils.isNotEmpty(explicitSearchFields)) {
      this.explicitSearchFields = explicitSearchFields;
    } else {
      if (searchForm instanceof AbstractSearchForm<?> searchFormInstance) {
        this.explicitSearchFields = searchFormInstance.getSearchFieldNames(entityClass);
      }
    }

    this.specification = new QuerySpecification<>(entityClass, searchForm, this.explicitSearchFields);

    addSearchPredicates(this.explicitSearchFields);

    if (searchForm instanceof AbstractSearchForm<?> searchFormInstance) {
      this.forceFetchFromDB = searchFormInstance.isForceFetchFromDB() || searchFormInstance.isIgnoreCache();
      this.shouldReturnEmpty = searchFormInstance.isShouldReturnEmpty();
    }

  }

  public CommonSearchContext<T, S> addSearchPredicates(String... propertyNames){

    QueryConditionType conditionType = searchForm.isExactMatch() ? QueryConditionType.EQUAL : QueryConditionType.LIKE;

    this.specification.addConditions(null, conditionType, propertyNames);
    return this;
  }

  public CommonSearchContext<T, S> addSearchPredicates(QueryConditionType conditionType, String... propertyNames){
    if(ArrayUtils.isEmpty(propertyNames))
      return this;

    this.specification.addConditions(null, conditionType, propertyNames);

    return this;
  }

  public CommonSearchContext<T, S> addSearchPredicate(String propertyName, QueryConditionType conditionType, Object value){
    return addSearchPredicate(null, propertyName, conditionType, value);
  }


  public CommonSearchContext<T, S> addSearchPredicate(ConditionOperatorType operator, String propertyName, QueryConditionType conditionType, Object value) {

    this.specification.addConditions(operator, propertyName, conditionType, value);

    return this;
  }

  public Pageable getPageable(boolean includeSort){
    if(includeSort){
      // Sort 관련 로직이 모두 QuerySpecification 으로 이동했다. specification 이 없을 때만 이 로직이 동작한다.
      if(EssentialEntity.class.isAssignableFrom(entityClass) || Historical.class.isAssignableFrom(entityClass)
      ){
        Sort sort = getPagingSort(null, null)
            .and(Sort.by(Direction.DESC, "createdAt", "id"));
        return PageRequest.of(searchForm.getPage(), searchForm.getPageSize(), sort);
      }

      if(EssentialUUIDEntity.class.isAssignableFrom(entityClass)
          || HistoricalUUID.class.isAssignableFrom(entityClass)
      ){
        Sort sort = getPagingSort(null, null)
            .and(Sort.by(Direction.DESC, "createdAt"));
        return PageRequest.of(searchForm.getPage(), searchForm.getPageSize(), sort);
      }

    }
    return PageRequest.of(searchForm.getPage(), searchForm.getPageSize());
  }

  public CommonSearchContext<T, S> addSearchConditions(ConditionOperatorType operatorType, QueryCondition... conditions) {
    specification.addConditions(operatorType, conditions);
    return this;
  }

  public CommonSearchContext<T, S> addSearchConditions(ConditionOperatorType operatorType, QueryConditionItem... conditionItems){
    if(conditionItems == null && ArrayUtils.isEmpty(conditionItems))
      return this;
    QueryCondition condition = new QueryCondition().addQueryItems(conditionItems);
    return addSearchConditions(operatorType, condition);
  }

  public CommonSearchContext<T, S> sortByJoinedProperty(JoinType joinType, String joinPath, Direction direction, QueryConditionItem joinCondition) {
    specification.sortByJoinedProperty(joinType, joinPath, direction, joinCondition);
    return this;
  }

  public CommonSearchContext<T, S> addSearchPredicates(ConditionOperatorType operator, String propertyName, QueryConditionType conditionType, Object value, JoinType joinType) {
    specification.addConditionsWithJoin(operator, propertyName, conditionType, value, joinType);
    return this;
  }

  public CommonSearchContext<T, S> sortByUnmappedJoinedProperty(String sortProperty, String alternative) {
    unmappedSortProperties.put(sortProperty, alternative);
    specification.sortByUnmappedJoinedProperty(sortProperty, alternative);
    return this;
  }

  public CommonSearchContext<T, S> addUnmappedConditions(ConditionOperatorType operator, UnmappedJoinItem unmappedJoinItem) {
    specification.addUnmappedConditions(operator, unmappedJoinItem);
    return this;
  }

  protected Sort getPagingSort(String defaultSortProperty, Direction direction) {


    Sort explicitSort = null;

    if(CollectionUtils.isNotEmpty(specification.getJoinedSortProperties())){
      // 명시적 join sort 가 있다면 해당 정보 부터 처리한다.
      List<Order> orders = new ArrayList<>();
      for(JoinedSortProperty sortProperty : specification.getJoinedSortProperties()){

        Order order = (sortProperty.getDirection().isAscending()) ? Order.asc(sortProperty.getPath()).nullsFirst()
            : Order.desc(sortProperty.getPath()).nullsLast();

        if(explicitSort == null){
          explicitSort = Sort.by(order);
        }else{
          explicitSort.and(order);
        }

      }
    }

    // 기본 sort 항목
    String[] sorts = getDefaultSortProperties(defaultSortProperty, direction);

    // searchForm 에 있는 명시적 sort 처리
    sorts = getExplicitSearchSortProperties(sorts);

    // unmapped property 에 대한 이름 변경이 필요한 경우
    sorts = convertUnmappedSortProperties(sorts);

    Sort sort = SearchServiceHelper.getPagingSortProperties(entityClass, sorts, defaultSortProperty, direction);

    if(explicitSort != null){
      sort = explicitSort.and(sort);
    }

    return sort;
  }

  private String[] convertUnmappedSortProperties(String[] sorts) {
    if(ArrayUtils.isNotEmpty(sorts) && MapUtils.isNotEmpty(unmappedSortProperties)){
      List<String> sortList = new ArrayList<>();
      boolean converted = false;
      for(String sort : sorts){
        String property = StringUtil.subStringBefore(sort, " ");
        String directionStr = StringUtil.subStringAfter(sort, " ", "DESC");

        if(unmappedSortProperties.containsKey(property)){
          property = unmappedSortProperties.get(property);
          converted = true;
        }

        sortList.add(property + " " + directionStr);

      }

      if(converted){
        sorts = sortList.toArray(new String[0]);
      }
    }
    return sorts;
  }

  private String[] getJoinedSortProperties(String[] sorts) {
    if(CollectionUtils.isNotEmpty(specification.getJoinedSortProperties())){
      // 명시적 join sort 가 있다면 해당 정보 부터 처리한다.
      List<String> sortList = new ArrayList<>();
      for(JoinedSortProperty sortProperty : specification.getJoinedSortProperties()){
        String sort = sortProperty.getPath() + " " + sortProperty.getDirection();
        sortList.add(sort);
      }

      if(ArrayUtils.isNotEmpty(sorts)){
        sortList.addAll(Arrays.asList(sorts));
      }

      sorts = sortList.toArray(new String[0]);

    }
    return sorts;
  }

  private String[] getExplicitSearchSortProperties(String[] sorts) {
    Map<String, String> alters = new HashMap<>();

    if(ArrayUtils.isNotEmpty(explicitSearchFields)) {
      for(String searchField : explicitSearchFields){
        if(searchField.contains(":")){
          alters.put(StringUtils.substringBefore(searchField, ":"), StringUtils.substringAfter(searchField, ":"));
        }
      }

      if(MapUtils.isNotEmpty(alters)){

        List<String> sortList = new ArrayList<>();
        if(ArrayUtils.isNotEmpty(sorts)){
          for(String sort : sorts){
            String propertyName = StringUtils.substringBefore(sort, " ");
            if(alters.containsKey(propertyName)){
              sortList.add(alters.get(propertyName) + " " + StringUtils.substringAfter(sort, " "));
            }else{
              sortList.add(sort);
            }
          }
        }

        sorts = sortList.toArray(new String[0]);

      }
    }

    return sorts;
  }

  private String[] getDefaultSortProperties(String defaultSortProperty, Direction direction) {
    String[] sorts = searchForm.getSortArray();

    if(ArrayUtils.isEmpty(sorts)){
      SearchServiceHelper.getPagingSortProperties(entityClass, null, defaultSortProperty, direction);
    }

    return sorts;
  }

  public String getCacheKey() {
    return getCacheKey(null);
  }

  public String getCacheKey(String prefix) {

    QuerySpecificationCache cache = new QuerySpecificationCache(specification);

    String cacheKey = cache.getCacheKey();

    if (StringUtils.isNotEmpty(prefix)) {
      return prefix + cacheKey;
    }

    return cacheKey;
  }

  @Override
  public void revertSearchForm() {
    if (searchForm != null && searchForm instanceof FilterMapSearchForm filterMapSearchForm) {
      filterMapSearchForm.revertPreservedFilterAndSortCriteria();
    }
  }

}
