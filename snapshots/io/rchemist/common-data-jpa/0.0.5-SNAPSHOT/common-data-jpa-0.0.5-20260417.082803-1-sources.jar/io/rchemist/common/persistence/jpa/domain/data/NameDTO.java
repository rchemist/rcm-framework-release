/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.data;

import com.google.common.base.Objects;
import io.rchemist.common.persistence.jpa.domain.embedded.Name;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class NameDTO implements Serializable {

  private String fullName;

  private String firstName;

  private String lastName;

  private String middleName;

  public NameDTO withFullName(String fullName) {
    this.fullName = fullName;
    return this;
  }

  public NameDTO withFirstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  public NameDTO withLastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  public NameDTO withMiddleName(String middleName) {
    this.middleName = middleName;
    return this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NameDTO nameDTO = (NameDTO) o;
    return Objects.equal(fullName, nameDTO.fullName)
        && Objects.equal(firstName, nameDTO.firstName)
        && Objects.equal(lastName, nameDTO.lastName)
        && Objects.equal(middleName, nameDTO.middleName);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(fullName, firstName, lastName, middleName);
  }

  public static NameDTO create(Name name) {
    return new NameDTO()
        .withFullName(name.getFullName())
        .withFirstName(name.getFirstName())
        .withLastName(name.getLastName())
        .withMiddleName(name.getMiddleName());
  }

}
