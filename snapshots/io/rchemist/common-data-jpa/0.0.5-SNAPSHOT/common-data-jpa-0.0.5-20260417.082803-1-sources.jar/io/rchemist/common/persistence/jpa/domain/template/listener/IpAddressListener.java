/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template.listener;

import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.IpAddressUtil;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.PrePersist;
import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * IpAddress 인터페이스를 상속한 엔티티를 persist 할 때 동작한다
 *
 **/
public class IpAddressListener {

  /**
   * Persist 때만 입력하고 수정이 불가능하다
   * @param entity
   */
  @PrePersist
  public void prePersist(Object entity){

      try {

        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if (requestAttributes instanceof ServletRequestAttributes servletRequestAttributes) {
          HttpServletRequest request = servletRequestAttributes.getRequest();

          String ipAddress = getClientIp(request);
          String macAddress = IpAddressUtil.getMacAddress();

          Method setIpAddress = entity.getClass().getMethod("setIpAddress", String.class);
          setIpAddress.invoke(entity, ipAddress);

          Method setMacAddress = entity.getClass().getMethod("setMacAddress", String.class);
          setMacAddress.invoke(entity, macAddress);

          WebRequestContext context = WebRequestContext.getWebRequestContext();
          if (context != null && context.getDeviceType() != null) {
            DeviceType deviceType = context.getDeviceType();
            Method setDeviceType = entity.getClass().getMethod("setDeviceType", DeviceType.class);
            setDeviceType.invoke(entity, deviceType);
          }

        }

      } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
        e.printStackTrace();
      }

  }


  private static String getClientIp(HttpServletRequest request) {

    final String[] headers = {
      "X-Forwarded-For",
      "X-FORWARDED-FOR",
      "Proxy-Client-IP",
      "WL-Proxy-Client-IP",
      "HTTP_X_FORWARDED_FOR",
      "HTTP_X_FORWARDED",
      "HTTP_X_CLUSTER_CLIENT_IP",
      "HTTP_CLIENT_IP",
      "HTTP_FORWARDED_FOR",
      "HTTP_FORWARDED",
      "HTTP_VIA",
      "REMOTE_ADDR"
    };

    try {
      for (String headerName : headers) {
        String ip = request.getHeader(headerName);
        if (!StringUtils.isBlank(ip) && !"unknown".equalsIgnoreCase(ip)) {
          return ip;
        }
      }

      return request.getRemoteAddr();

    } catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
    }

    return null;
  }

}
