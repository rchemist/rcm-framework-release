/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.search.data.HibernateSearchContext;
import io.rchemist.common.search.data.HibernateSearchResult;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.StopWatchUtil;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.service.data.HasIdEntity;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.boot.logging.LogLevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.util.StopWatch;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HibernateSearchResponseEntityService<
    ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> {

  /**
   * 서비스 별로 스톱워치를 on / off 할 수 있다.
   * @return
   */
  default boolean shouldPrintStopWatch() {
    return false;
  }

  default Integer getHibernateSearchCount(SEARCH_FORM form) {

    StopWatch stopWatch;

    if (shouldPrintStopWatch()) {
      stopWatch = new StopWatch();
      stopWatch.start("하이버네이트 검색 시작");
    } else {
      stopWatch = null;
    }

    try {
      HibernateSearchContext<ENTITY, SEARCH_FORM> context = createHibernateSearchContext(form);

      if (stopWatch != null) {
        stopWatch.stop();
      }

      if (context == null) {
        String errorMessage = String.format("%s 에서 Hibernate Search 를 사용하려면 반드시 createHibernateSearchContext() 를 구현해야 합니다. DB 에서 데이터를 조회합니다.", getClass().getSimpleName());
        ExceptionUtil.printLog(errorMessage, LogLevel.DEBUG);
        return null;
      }

      if (!context.isSupportHibernateSearch()) {
        return null;
      }


      if (stopWatch != null) {
        stopWatch.start("하이버네이트 검색 - Elasticsearch 조회");
      }

      Integer count = context.getSearchCount();

      if (stopWatch != null) {
        StopWatchUtil.print(stopWatch);
        stopWatch.stop();
      }

      return count;

    }catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
      // Failover 일반 DB Fetch 로 결과를 내보내야 한다.
      return null;
    }

  }

  default PageResult<ENTITY> getHibernateSearchResult(
      SEARCH_FORM form) {

    StopWatch stopWatch;

    if (shouldPrintStopWatch()) {
      stopWatch = new StopWatch();
      stopWatch.start("하이버네이트 검색 시작");
    } else {
      stopWatch = null;
    }

    try {
      HibernateSearchContext<ENTITY, SEARCH_FORM> context = createHibernateSearchContext(form);

      if (stopWatch != null) {
        stopWatch.stop();
      }

      if (context == null) {
        String errorMessage = String.format("%s 에서 Hibernate Search 를 사용하려면 반드시 createHibernateSearchContext() 를 구현해야 합니다. DB 에서 데이터를 조회합니다.", getClass().getSimpleName());
        ExceptionUtil.printLog(errorMessage, LogLevel.DEBUG);
        return null;
      }

      if (!context.isSupportHibernateSearch()) {
        return null;
      }


      if (stopWatch != null) {
        stopWatch.start("하이버네이트 검색 - Elasticsearch 조회");
      }

      HibernateSearchResult<ENTITY> result = context.getResult();

      Pageable pageable = PageRequest.of(form.getPage(), form.getPageSize());

      if (stopWatch != null) {
        stopWatch.stop();
        stopWatch.start("하이버네이트 검색 - 결과 변환");
      }

      Page<ENTITY> page = new PageImpl<>(result.getResult().hits(), pageable, result.getTotalCount());

      if (stopWatch != null) {
        stopWatch.stop();
      }

      PageResult<ENTITY> pageResult = PageResult.create(context.getEntityClass(), page);

      appendAttributeDocuments(context, page, pageResult);

      if (stopWatch != null) {
        StopWatchUtil.print(stopWatch);
      }

      return pageResult;
    }catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
      // Failover 일반 DB Fetch 로 결과를 내보내야 한다.
      return null;
    }

  }

  default void appendAttributeDocuments(HibernateSearchContext<ENTITY, SEARCH_FORM> context, Page<ENTITY> page,
      PageResult<ENTITY> pageResult) {

    if (!page.isEmpty()) {
      // attribute name 이 지정되어 있으면, 해당 attribute 를 조회한다.

      EntityBean<?> entityBean = PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(
          context.getEntityClass().getName());

      if (entityBean != null && !entityBean.isEmpty() && entityBean.hasAttributeFields()) {

        for(Entry<String, String> entry : entityBean.getAttributeFields().entrySet()) {

          String actualPropertyName = entry.getKey();
          String propertyName = entry.getValue();

          // 실제 entity 가 매핑되어야 한다.
          if (entityBean.getClassMappingProperties().containsKey(actualPropertyName)) {

            List<JsonObject> documents = context.getDocuments(null);

            for(JsonObject object : CollectionUtils.emptyIfNull(documents)){
              Map<String, String> attributes = new HashMap<>();

              String id = object.get("entityId").getAsString();

              JsonObject attrs = object.getAsJsonObject(propertyName);

              if (attrs == null || attrs.isEmpty()) {
                continue;
              }

              Map<String, JsonElement> objects = attrs.asMap();
              for (Entry<String, JsonElement> elementEntry : objects.entrySet()) {
                String name = elementEntry.getKey();
                String value = elementEntry.getValue().getAsString();

                attributes.put(name, value);

              }

              pageResult.setAttributes(id, propertyName, attributes);
            }
          }

        }


      }
    }
  }

  /**
   * Hibernate Search 를 지원하는 Service 에서 이 메소드를 오버라이드 해야 한다.
   * @return
   */
  default HibernateSearchContext<ENTITY, SEARCH_FORM> createHibernateSearchContext(SEARCH_FORM form) throws SERVICE_EXCEPTION {
    return null;
  }

}
