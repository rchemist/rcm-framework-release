/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping;

import io.rchemist.common.util.ExceptionUtil;
import jakarta.persistence.Embedded;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.ClassFile;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.mapping.Component;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.Value;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public abstract class AbstractMappingProvider implements MappingProvider {

  protected abstract Integer getMaxCascadeLevel();

  /**
   * Property의 Value 가 Component Value 인 경우,
   * 즉 Embedded 필드처럼 여러 필드가 모여 하나의 Value 를 이루는 경우
   * 하위 Property 들을 List<Property> 로 전달한다
   * @param property
   * @return
   */
  protected Map<String, Property> getComponentProperties(Map<String, Property> propertyMap, String prefix, Property property) {
    Value value = property.getValue();

    if (value instanceof Component) {
      Iterator<Property> iterators = ((Component) value).getPropertyIterator();

      while(iterators.hasNext()){
        Property prop = iterators.next();
        String newPrefix = property.getName() + ".";
        if(StringUtils.isNotBlank(prefix)){
          newPrefix = prefix + newPrefix ;
        }

        propertyMap = getComponentProperties(propertyMap, newPrefix, prop);
      }

      return propertyMap;
    } else {
      propertyMap.put(prefix + property.getName(), property);
    }
    return propertyMap;
  }

  /**
   * 특정 Class 파일에 정의된 모든 필드
   * = (자기 자신 클래스에 정의된 필드(declaredFields) + 슈퍼 클래스 필드 + Embedded 필드의 하위 필드)
   *
   * @param classPool
   * @param className
   * @param prefix
   * @param fieldInfos
   * @return
   */
  protected Map<String, Class<?>> getFieldInformation(int level, ClassPool classPool, String className, String prefix, Map<String, Class<?>> fieldInfos) {

    if(level > getMaxCascadeLevel()){
      // 무한 loop 를 막기 위해 hierarchy가 10 depth를 넘으면 그냥 끝낸다
      return fieldInfos;
    }

    CtClass ctClass = null;
    try {
      ctClass = classPool.getCtClass(className);

      try {
        if (ctClass.getSuperclass() != null) {
          fieldInfos.putAll(getFieldInformation(level + 1, classPool, ctClass.getSuperclass().getName(), prefix, fieldInfos));
        }
      } catch (NotFoundException e) {
        // nothing
      }

      boolean freeze = ctClass.isFrozen();
      if (ctClass.isFrozen()) {
        ctClass.defrost();
        freeze = true;
      }

      ClassFile classFile = ctClass.getClassFile();

      for (FieldInfo info : classFile.getFields()) {
        boolean isEmbeddedField = checkEmbeddedFieldAndGetFieldInformation(level, classPool, prefix, fieldInfos, info);

        if(!isEmbeddedField){
          String normarlizedName = normarlizeClassName(info.getDescriptor());
          try {
            Class<?> clz = null;
            if(normarlizedName.startsWith("[L")){
              // 배열이다
              clz = Class.forName(StringUtils.removeStart(normarlizedName, "[L"));
              clz = Array.newInstance(clz, 0).getClass();
            }else{
              clz = Class.forName(normarlizedName);
            }
            fieldInfos.put(prefix + info.getName(), clz);
          } catch (ClassNotFoundException e) {
            // nothing;
            if(StringUtils.length(normarlizedName) > 1){    // primitive type으로 인한 오류는 무시한다
              log.warn(StringUtils.join("There is an error during mapping custom type provider {} - {} - {}", info.getName(), className, normarlizedName));
              log.warn(e.getMessage());
            }
          }
        }
      }

      if (freeze) {
        ctClass.freeze();
      }
    } catch (NotFoundException e) {
      ExceptionUtil.printStackTrace(e);
    }

    return fieldInfos;
  }

  private boolean checkEmbeddedFieldAndGetFieldInformation(int level, ClassPool classPool, String prefix, Map<String, Class<?>> fieldInfos, FieldInfo info) {
    boolean isEmbeddedField = false;
    List<AttributeInfo> attributes = info.getAttributes();
    if (CollectionUtils.isNotEmpty(attributes)) {
      for (AttributeInfo info1 : attributes) {
        if (info1 instanceof AnnotationsAttribute) {
          for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
            if (anno.getTypeName().equals(Embedded.class.getName())) {
              fieldInfos.putAll(getFieldInformation(level + 1, classPool, normarlizeClassName(info.getDescriptor()), prefix + info.getName() + ".", fieldInfos));
              isEmbeddedField = true;
              break;
            }
          }
        }
      }
    }
    return isEmbeddedField;
  }

  /**
   * Class 파일을 읽어 특정 필드가 Embedded 인지 확인 후 fieldInfos에 하위 필드 추가
   * 필드의 AttributeInfo에서 Annotation 정보를 읽어 Annotation의 TypeName이 @Embedded 인지 확인한다
   *
   * @param classPool
   * @param fieldInfos
   * @param classFile
   */
  protected void getEmbeddedFieldInfo(int level, ClassPool classPool, String prefix, Map<String, Class<?>> fieldInfos, ClassFile classFile) {
    for (FieldInfo info : classFile.getFields()) {
      List<AttributeInfo> attributes = info.getAttributes();
      if (CollectionUtils.isNotEmpty(attributes)) {
        for (AttributeInfo info1 : attributes) {
          if (info1 instanceof AnnotationsAttribute) {
            for (Annotation anno : ((AnnotationsAttribute) info1).getAnnotations()) {
              if (anno.getTypeName().equals(Embedded.class.getName())) {
                fieldInfos.putAll(getFieldInformation(level + 1, classPool, normarlizeClassName(info.getDescriptor()), prefix + info.getName() + ".", fieldInfos));
                break;
              }
            }
          }
        }
      }

    }
  }
}
