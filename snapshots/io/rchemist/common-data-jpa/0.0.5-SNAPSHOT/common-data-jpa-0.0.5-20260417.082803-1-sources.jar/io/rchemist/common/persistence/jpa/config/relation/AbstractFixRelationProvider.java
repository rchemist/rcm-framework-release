/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.relation;

import io.rchemist.common.persistence.jpa.config.mapping.dto.RelationMappingDTO;
import org.hibernate.boot.internal.MetadataImpl;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.type.Type;
import org.springframework.core.Ordered;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public abstract class AbstractFixRelationProvider implements FixRelationProvider, Ordered {

  public MetadataImpl transformRelationMapping(MetadataImpl metadata, PersistentClass clazz, RelationMappingDTO mappingDTO){

    if(clazz.getProperty(mappingDTO.getPropertyName()) != null){
      
      Property property = clazz.getProperty(mappingDTO.getPropertyName());
      Type hibernateMappingType = property.getType();

      if(canHandle(metadata, clazz, mappingDTO, property, hibernateMappingType)){

        transform(metadata, clazz, mappingDTO, property);

      }
      
    }
    
    return metadata;
  }

  /**
   * 각  Provider의 동작 조건 설정
   * @param metadata
   * @param clazz
   * @param mappingDTO
   * @param property
   * @param hibernateMappingType
   * @return
   */
  protected abstract boolean canHandle(MetadataImpl metadata, PersistentClass clazz, RelationMappingDTO mappingDTO, Property property, Type hibernateMappingType);

  /**
   * 실제 metadata를 제어하는 부분
   * @param metadata
   * @param clazz
   * @param mappingDTO
   * @param property
   */
  protected abstract void transform(MetadataImpl metadata, PersistentClass clazz, RelationMappingDTO mappingDTO, Property property);

}
