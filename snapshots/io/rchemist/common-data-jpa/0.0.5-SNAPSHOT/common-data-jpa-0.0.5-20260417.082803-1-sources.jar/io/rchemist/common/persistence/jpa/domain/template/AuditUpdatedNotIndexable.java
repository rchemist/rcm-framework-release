/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Updated by kunner
 * <p>
 * 반드시 weave 해야 한다
 **/

public interface AuditUpdatedNotIndexable<T> extends ClassTransformTarget {

  default Instant getUpdatedAt() {
    throw new ClassTransformException();
  }

  default void setUpdatedAt(Instant dateUpdated) {
    throw new ClassTransformException();
  }

  @JsonIgnore
  default LocalDateTime getUpdatedAtLocalDateTime() {
    return getUpdatedAtLocalDateTime(ZoneId.systemDefault());
  }

  @JsonIgnore
  default LocalDateTime getUpdatedAtLocalDateTime(ZoneId zoneId) {
    return LocalDateTime.ofInstant(getUpdatedAt(), zoneId);
  }

  default String getUpdatedBy() {
    throw new ClassTransformException();
  }

  default void setUpdatedBy(String createdBy) {
    throw new ClassTransformException();
  }

  default AuditUserType getUpdatedByUserType(){throw new ClassTransformException();}

  default void setUpdatedByUserType(AuditUserType updatedByUserType){
    throw new ClassTransformException();
  }

  @JsonIgnore
  default int compareTo(AuditUpdatedNotIndexable<?> a) {
    if(a.getUpdatedAt().isAfter(getUpdatedAt())){
      return -1;
    }else if(a.getUpdatedAt().equals(getUpdatedAt())){
      return 0;
    }else{
      return 1;
    }
  }

  default T withUpdatedAt(Instant updatedAt) {
    setUpdatedAt(updatedAt);
    return (T) this;
  }

  default T withUpdatedBy(String updatedBy) {
    setUpdatedBy(updatedBy);
    return (T) this;
  }

  default T withUpdatedByUserType(AuditUserType updatedByUserType) {
    setUpdatedByUserType(updatedByUserType);
    return (T) this;
  }

}
