/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
import org.hibernate.mapping.PersistentClass;
import org.springframework.core.Ordered;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface MappingProvider extends Ordered {

  /**
   * Hibernate가 관리하는 PersistentClass 를 transform 한다
   * @param metadata
   * @param defaultBuilder
   * @param persistentClass
   * @return
   */
  void transformPersistentClass(MetadataImplementor metadata, SessionFactoryBuilderImplementor defaultBuilder, PersistentClass persistentClass);

  /**
   * Javasisst.CtClass 에는 클래스 이름이 . 대신 / 로 되어 있고, 맨 앞과 맨 뒤에 각각 L과 ;가 붙어 있다.
   * 이를 일반적인 ClassName 으로 변경하는 메소드
   *
   * @param descriptor
   * @return
   */
  default String normarlizeClassName(String descriptor) {
    return
        StringUtils.removeEnd(
            StringUtils.removeStart(
                descriptor
                    .replace('/', '.'), "L"), ";");
  }

}
