/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.type.EntityViewType;
import java.io.Serializable;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * ResponseEntityListService 를 이용해 CRUD REST Controller 를 쉽게 생성할 수 있게 하는 abstract 클래스
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class ResponseEntityController<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable> {

  protected abstract ResponseEntityListService<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, ? extends ErrorTypeException> getService();

  public ResponseData<Long> count(@RequestBody SEARCH_FORM searchForm) {
    return getService().getQuerySearchCount(searchForm);
  }

  public ResponseData<Boolean> clearCache() {
    return ResponseHelper.result(() -> getService().clearCache());
  }

  public ResponseData<Boolean> clearEntityCache(ID id) {
    return ResponseHelper.result(() -> {
      getService().clearEntityCache(id);
      return true;
    });
  }

  public ResponseListData<VIEW, SEARCH_FORM> search(@RequestBody SEARCH_FORM searchForm) {
    return getService().createResponseListData(searchForm);
  }

  public ResponseData<VIEW> create(@RequestBody CREATE_FORM createForm) {
    return ResponseHelper.result(() -> getService().create(createForm));
  }

  public ResponseData<VIEW> update(@RequestBody UPDATE_FORM updateForm) {
    return ResponseHelper.result(() -> getService().update(updateForm));
  }

  public ResponseData<Boolean> delete(@RequestBody DeleteForm<ID> form) {
    return ResponseHelper.result(() -> getService().deleteByForm(form));
  }

  public ResponseData<Boolean> delete(@PathVariable ID id, @RequestParam(required = false) String revisionEntityName) {
    DeleteForm<ID> form = new DeleteForm<>(id, revisionEntityName);
    return delete(form);
  }

  public ResponseData<VIEW> view(@PathVariable ID id) {
    return view(id, EntityViewType.VIEW);
  }

  public ResponseData<VIEW> view(@PathVariable ID id, @RequestParam(required = false) EntityViewType viewType) {
    return ResponseHelper.result(() -> getService().findViewById(id, viewType == null ? EntityViewType.VIEW : viewType));
  }

  public ResponseData<Integer> deleteMultiple(@RequestBody DeleteForm<ID> deleteForm) {
    int size = deleteForm != null ? CollectionUtils.size(deleteForm.getIds()) : 0;
    if (size == 0) {
      return ResponseHelper.result(() -> 0);
    } else if (size > 20) {
      return ResponseHelper.result(() -> getService().deleteAll(deleteForm));
    }
    return ResponseHelper.result(() -> getService().deleteAll(deleteForm, false));
  }

}
