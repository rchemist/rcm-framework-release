/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.rchemist.common.persistence.jpa.config.persistence;

import java.util.Properties;
import org.springframework.orm.jpa.persistenceunit.MutablePersistenceUnitInfo;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class JCachePersistenceUnitPostProcessor implements PersistenceUnitPostProcessor {

  @Override
  public void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo pui) {
    Properties properties = pui.getProperties();
    // properties.setProperty("hibernate.javax.cache.uri", JCacheManagerFactoryBean.XML_RESOURCE_URI.toString());
  }

}