/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.sync.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntityNotIndexable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_SYNC_STATUS")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "ENTITY_SYNC_STATUS")
@Getter
@Setter
@Indexed
@Description(name = "데이터 초기화 현황", comment = "SyncStatusService 의 동작 여부를 확인. 각 SyncID 에 해당하는 서비스가 동작한 경우 기록을 남겨 서버 부팅 시 해당 서비스가 다시 동작하지 않게 한다.")
public class SyncStatus implements EssentialEntityNotIndexable<SyncStatus> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "SYNC_ID")
  @Description(name = "서비스 ID")
  @IndexField
  protected String syncId;

}
