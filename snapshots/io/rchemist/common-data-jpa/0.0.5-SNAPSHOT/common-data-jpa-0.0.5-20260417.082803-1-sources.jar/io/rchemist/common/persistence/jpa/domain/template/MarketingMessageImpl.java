/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;


import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(value = MarketingMessage.class)
@Getter
@Setter
public class MarketingMessageImpl implements Serializable, EnhancedTemplate {

  @Column(name = "MARKETING_MESSAGE")
  @Text
  // @AdminPresentation(friendlyName = "MarketingMessageImpl_MarketingMessage", order = 3000, largeEntry = true, translatable = true, tooltip = "MarketingMessageImpl_MarketingMessage_Tooltip")
  @Description(name = "마케팅 메세지", comment = "마케팅 메세지 내용")
  protected String marketingMessage;

  @Column(name = "MARKETING_LINK")
  /*// @AdminPresentation(friendlyName = "MarketingMessageImpl_MarketingLink", order = 3100, tooltip = "MarketingMessageImpl_MarketingLink_Tooltip"
      , validationConfigurations = {@ValidationConfiguration(validationImplementation = "blUriPropertyValidator")}
  )*/
  @Description(name = "링크 주소", comment = "링크 주소")
  protected String marketingLink;

  /*public String getMarketingMessage() {
    return null;
    // return DynamicTranslationProvider.getValue(this, "marketingMessage", marketingMessage);
  }*/

}
