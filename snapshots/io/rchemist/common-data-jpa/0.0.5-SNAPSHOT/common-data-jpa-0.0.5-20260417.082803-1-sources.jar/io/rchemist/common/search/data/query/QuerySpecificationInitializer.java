/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;

/**
 * QuerySpecification 초기화 로직을 담당하는 클래스
 * QuerySpecification 생성자의 복잡도를 줄이기 위해 분리됨
 */
@Slf4j
public class QuerySpecificationInitializer<T extends Serializable, S extends SearchFormWrapper<S>> {

  private final Class<T> entityClass;
  private final S searchForm;
  private final Map<ConditionOperatorType, QueryCondition> conditions;

  public QuerySpecificationInitializer(Class<T> entityClass, S searchForm, 
                                     Map<ConditionOperatorType, QueryCondition> conditions) {
    this.entityClass = entityClass;
    this.searchForm = searchForm;
    this.conditions = conditions;
  }

  /**
   * QuerySpecification 초기화를 수행
   */
  public String[] initialize(String... propertyNames) {
    log.debug("Initializing QuerySpecification for entity: {}", entityClass.getSimpleName());
    
    // 1. ExtensionManager 처리
    String[] explicitFilterNames = processExtensionManager();
    
    // 2. PropertyNames 처리 (FilterMapSearchForm 포함)
    String[] finalFilterNames = processPropertyNames(explicitFilterNames, propertyNames);
    
    log.debug("QuerySpecification initialization completed for entity: {}", entityClass.getSimpleName());
    
    return finalFilterNames;
  }

  private String[] processExtensionManager() {
    ExtensionManagerProcessor<T, S> processor = new ExtensionManagerProcessor<>(entityClass, searchForm, conditions);
    return processor.process();
  }

  private String[] processPropertyNames(String[] explicitFilterNames, String... propertyNames) {
    // propertyNames로 지정했지만 ExtensionHandler에서 자동으로 처리한 필터는 제외
    if (propertyNames != null && ArrayUtils.isNotEmpty(propertyNames)) {
      
      Set<String> additionalFilterNames = new HashSet<>(Arrays.asList(propertyNames));
      if (ArrayUtils.isNotEmpty(explicitFilterNames)) {
        Arrays.asList(explicitFilterNames).forEach(additionalFilterNames::remove);
      }

      if (searchForm instanceof FilterMapSearchForm<?> filterMapSearchForm) {
        FilterMapProcessor<T, S> processor = new FilterMapProcessor<>(filterMapSearchForm, conditions, propertyNames);
        processor.process();
      }

      return ArrayUtil.merge(explicitFilterNames, additionalFilterNames.toArray(new String[0]));
    }
    
    return explicitFilterNames;
  }

}