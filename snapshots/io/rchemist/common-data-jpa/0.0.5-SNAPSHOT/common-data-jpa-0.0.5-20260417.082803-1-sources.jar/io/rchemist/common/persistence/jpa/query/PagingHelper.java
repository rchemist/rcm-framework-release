/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.query;

import io.rchemist.common.persistence.query.Paging;
import io.rchemist.common.persistence.query.dto.SearchCondition;
import io.rchemist.common.util.NumberUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PagingHelper {

  private static final String PAGE_NAME = "page";
  private static final String PAGE_SIZE_NAME = "pageSize";
  private static final String PAGE_LIST_SIZE_NAME = "pageListSize";

  public static Paging create(HttpServletRequest request) {
    return create(request, PAGE_NAME, PAGE_SIZE_NAME, PAGE_LIST_SIZE_NAME);
  }

  public static Paging create(HttpServletRequest request, String pageName, String pageSizeName, String pageListSizeName) {
    Paging page = new Paging();
    page.setPage(NumberUtil.getInteger(request.getParameter(pageName), 1));
    page.setPageSize(NumberUtil.getInteger(request.getParameter(pageSizeName), 20));
    page.setPageListSize(NumberUtil.getInteger(request.getParameter(pageListSizeName), 10));
    page.setSearchCondition(new SearchCondition(request.getParameterMap()));
    return page;
  }

  public static Pageable getFirstIdDesc() {
    return PageRequest.of(0, 1, Direction.DESC, "id");
  }

  public static Pageable getFirstIdAsc() {
    return PageRequest.of(0, 1, Direction.ASC, "id");
  }

  public static Pageable getFirstCreatedAtDesc() {
    return PageRequest.of(0, 1, Direction.DESC, "createdAt");
  }
  public static Pageable getFirstCreatedAtAsc() {
    return PageRequest.of(0, 1, Direction.ASC, "createdAt");
  }

}
