/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 *
 * YYYY, MM, DD, HH 값을 인덱싱 해야 하는 기간 별 데이터(통계 등) 에서 사용하는 Periodic 템플릿 클래스
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface Periodic<T> extends ClassTransformTarget {

  String PERIODIC_YEAR = "PERIODIC_YEAR";
  String PERIODIC_MONTH = "PERIODIC_MONTH";
  String PERIODIC_DAY = "PERIODIC_DAY";
  String PERIODIC_HOUR = "PERIODIC_HOUR";

  default String getPeriodicYear(){throw new ClassTransformException();}
  default void setPeriodicYear(String periodicYear){throw new ClassTransformException();}

  default String getPeriodicMonth(){throw new ClassTransformException();}
  default void setPeriodicMonth(String periodicMonth){throw new ClassTransformException();}

  default String getPeriodicDay(){throw new ClassTransformException();}
  default void setPeriodicDay(String periodicDay){throw new ClassTransformException();}

  default String getPeriodicHour(){throw new ClassTransformException();}
  default void setPeriodicHour(String periodicHour){throw new ClassTransformException();}

  default T withPeriodicYear(String periodicYear){
    setPeriodicYear(periodicYear);
    return (T) this;
  }

  default T withPeriodicMonth(String periodicMonth){
    setPeriodicMonth(periodicMonth);
    return (T) this;
  }

  default T withPeriodicDay(String periodicDay){
    setPeriodicDay(periodicDay);
    return (T) this;
  }

  default T withPeriodicHour(String periodicHour){
    setPeriodicHour(periodicHour);
    return (T) this;
  }
}
