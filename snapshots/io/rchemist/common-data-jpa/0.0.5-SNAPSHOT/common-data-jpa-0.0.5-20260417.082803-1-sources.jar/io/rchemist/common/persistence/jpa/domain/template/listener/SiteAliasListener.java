/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template.listener;

import io.rchemist.common.web.request.WebRequestContext;
import jakarta.persistence.PrePersist;
import java.lang.reflect.Method;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * SiteAware 는 Admin 인 경우에는 자동 처리 하지 않으며,
 * Front site 에서만 SiteAwareListener 를 이용해 자동 처리한다.
 **/
public class SiteAliasListener {

  /**
   * Persist 때만 입력하고 수정이 불가능하다
   * @param entity
   */
  @PrePersist
  public void prePersist(Object entity){

    // 먼저 현재 시스템이 Admin 인지 Front 인지를 판단해야 한다.
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    // admin 이 아닐 때만 실행한다
    if(context != null && !context.isAdmin() && context.getSiteAlias() != null){

      try {
        // TODO SITE 정보 처리

        Method setSiteAlias = entity.getClass().getMethod("setSiteAlias", String.class);
        setSiteAlias.invoke(entity, context.getSiteAlias());
        Method setTenantAlias = entity.getClass().getMethod("setTenantAlias", String.class);
        setTenantAlias.invoke(entity, context.getTenantAlias());

      } catch (Exception e) {
        e.printStackTrace();
      }

    }

  }

}
