/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(UserUUId.class)
@Getter
@Setter
public class UserUUIdImpl implements EnhancedTemplate {

  @Column(name = "USER_ID")
  @IndexField
  @GenericField(sortable = Sortable.YES)
  @Description(name = "사용자 ID", comment = "User 가 매핑된 엔티티에서 사용자 ID 를 저장하는 필드, 굳이 정규화 하지 않는다.")
  protected String userId;

}
