/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.LocalDateUtil;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface AvailableDate<T> {

  default void setAvailableDate(String[] availalbleDate) throws ErrorTypeException {
    if (availalbleDate != null && availalbleDate.length == 2) {
      setAvailableDateAt(availalbleDate[0]);
      setAvailableDateUntil(availalbleDate[1]);
    } else {
      throw new ErrorTypeException("availableDate", "시작일 ~ 종료일을 입력해야 합니다");
    }
  }

  default String[] getAvailableDate() {
    if (StringUtils.isNotEmpty(getAvailableDateAt()) && StringUtils.isNotEmpty(getAvailableDateUntil())) {
      return new String[]{getAvailableDateAt(), getAvailableDateUntil()};
    }
    return null;
  }

  default String getAvailableDateAt(){
    throw new ClassTransformException();
  }
  default void setAvailableDateAt(String availableDateAt){
    throw new ClassTransformException();
  }

  default String getAvailableDateUntil(){
    throw new ClassTransformException();
  }

  default void setAvailableDateUntil(String availableDateUntil){
    throw new ClassTransformException();
  }

  default boolean isAvailableNow() {
    LocalDate now = LocalDate.now();
    return isAvailable(LocalDateUtil.format(now));
  }

  default boolean isStartedNow(){
    // 시작일이 지정되어 있지 않다면 언제나 OK
    if (StringUtils.isEmpty(getAvailableDateAt()))
      return true;
    LocalDate now = LocalDate.now();
    LocalDate availableDateAt = LocalDateUtil.parse(getAvailableDateAt());
    return availableDateAt.equals(now) || availableDateAt.isBefore(now);
  }

  default boolean isEndedNow(){
    // 종료일이 지정되어 있지 않다면 언제나 OK
    if (StringUtils.isEmpty(getAvailableDateUntil()))
      return false;
    LocalDate now = LocalDate.now();
    LocalDate availableDateUntil = LocalDateUtil.parse(getAvailableDateUntil());
    return now.isAfter(availableDateUntil);
  }

  default boolean isAvailable(LocalDate compareDate) {
    if (StringUtils.isEmpty(getAvailableDateAt()) && StringUtils.isEmpty(getAvailableDateUntil())) {
      // 시작일, 종료일 설정이 되어 있지 않으면 언제나 OK
      return true;
    }


    if (StringUtils.isNotEmpty(getAvailableDateAt())) {
      LocalDate availableDateAt = LocalDateUtil.parse(getAvailableDateAt());
      if (availableDateAt.isAfter(compareDate)) {
        return false;
      }
    }

    if (StringUtils.isNotEmpty(getAvailableDateUntil())) {
      LocalDate availableDateUntil = LocalDateUtil.parse(getAvailableDateUntil());
      if (availableDateUntil.isBefore(compareDate)) {
        return false;
      }
    }
    
    return true;
  }
  
  default boolean isAvailable(String compareDate) {
    // compareDate 시각이 AvailableDateAt 과 AvailableDateUntil 사이에 있는지 확인
    LocalDate compare = LocalDateUtil.parse(compareDate);
    if (compare == null)
      compare = LocalDate.now();
    return isAvailable(compare); 
  }

  default T withAvailableDateAt(String availableDateAt) {
    setAvailableDateAt(availableDateAt);
    return (T) this;
  }

  default T withAvailableDateUntil(String availableDateUntil) {
    setAvailableDateUntil(availableDateUntil);
    return (T) this;
  }

  default boolean validateAvailableDates() {
    if (StringUtils.isNotEmpty(getAvailableDateAt()) && StringUtils.isNotEmpty(getAvailableDateUntil())) {
      // availableDateAt 이 availableDateUntil 과 같거나 앞선 날짜여야 한다.
      LocalDate availableDateAt = LocalDate.parse(getAvailableDateAt());
      LocalDate availableDateUntil = LocalDate.parse(getAvailableDateUntil());
      
      return availableDateAt.equals(availableDateUntil) || availableDateAt.isBefore(availableDateUntil);
    }
    return true;
  }
  
  /**
   * availableDateUntil 기준으로 오늘 날짜에 가장 가까운 것을 선택하는 Comparator를 반환합니다.
   * 이 comparator는 종료일이 오늘에 가장 가까운 순서로 정렬합니다.
   * 
   * @param <T> AvailableDate를 구현한 타입
   * @return 종료일 기준 오늘 날짜 근접도 Comparator
   */
  static <T extends AvailableDate<T>> Comparator<T> closestToTodayByEndDate() {
    return closestToDateByEndDate(LocalDate.now());
  }
  
  /**
   * availableDateUntil 기준으로 지정된 날짜에 가장 가까운 것을 선택하는 Comparator를 반환합니다.
   * 
   * @param <T> AvailableDate를 구현한 타입
   * @param targetDate 비교 기준 날짜
   * @return 종료일 기준 지정 날짜 근접도 Comparator
   */
  static <T extends AvailableDate<T>> Comparator<T> closestToDateByEndDate(LocalDate targetDate) {
    return (e1, e2) -> {
      String date1 = e1.getAvailableDateUntil();
      String date2 = e2.getAvailableDateUntil();
      
      // null 처리
      if (date1 == null && date2 == null) return 0;
      if (date1 == null) return 1;
      if (date2 == null) return -1;
      
      try {
        // 목표 날짜와의 차이를 비교 (절대값으로 가장 가까운 날짜 선택)
        LocalDate endDate1 = LocalDateUtil.parse(date1);
        LocalDate endDate2 = LocalDateUtil.parse(date2);
        
        long diff1 = Math.abs(ChronoUnit.DAYS.between(targetDate, endDate1));
        long diff2 = Math.abs(ChronoUnit.DAYS.between(targetDate, endDate2));
        
        return Long.compare(diff1, diff2);
      } catch (Exception e) {
        return 0; // 비교 불가능한 경우
      }
    };
  }
  
  /**
   * availableDateAt 기준으로 오늘 날짜에 가장 가까운 것을 선택하는 Comparator를 반환합니다.
   * 이 comparator는 시작일이 오늘에 가장 가까운 순서로 정렬합니다.
   * 
   * @param <T> AvailableDate를 구현한 타입
   * @return 시작일 기준 오늘 날짜 근접도 Comparator
   */
  static <T extends AvailableDate<T>> Comparator<T> closestToTodayByStartDate() {
    return closestToDateByStartDate(LocalDate.now());
  }
  
  /**
   * availableDateAt 기준으로 지정된 날짜에 가장 가까운 것을 선택하는 Comparator를 반환합니다.
   * 
   * @param <T> AvailableDate를 구현한 타입
   * @param targetDate 비교 기준 날짜
   * @return 시작일 기준 지정 날짜 근접도 Comparator
   */
  static <T extends AvailableDate<T>> Comparator<T> closestToDateByStartDate(LocalDate targetDate) {
    return (e1, e2) -> {
      String date1 = e1.getAvailableDateAt();
      String date2 = e2.getAvailableDateAt();
      
      // null 처리
      if (date1 == null && date2 == null) return 0;
      if (date1 == null) return 1;
      if (date2 == null) return -1;
      
      try {
        // 목표 날짜와의 차이를 비교 (절대값으로 가장 가까운 날짜 선택)
        LocalDate startDate1 = LocalDateUtil.parse(date1);
        LocalDate startDate2 = LocalDateUtil.parse(date2);
        
        long diff1 = Math.abs(ChronoUnit.DAYS.between(targetDate, startDate1));
        long diff2 = Math.abs(ChronoUnit.DAYS.between(targetDate, startDate2));
        
        return Long.compare(diff1, diff2);
      } catch (Exception e) {
        return 0; // 비교 불가능한 경우
      }
    };
  }
}
