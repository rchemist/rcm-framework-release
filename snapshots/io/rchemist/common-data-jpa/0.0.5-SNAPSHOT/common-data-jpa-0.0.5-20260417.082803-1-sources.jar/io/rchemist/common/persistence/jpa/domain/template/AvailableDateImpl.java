/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Searchable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(AvailableDate.class)
@Getter
@Setter
public class AvailableDateImpl implements Serializable, EnhancedTemplate {

  @Column(name = "AVAILABLE_DATE_AT")
  @Description(name = "이용가능 시작 일자", comment = "이용가능 시작 일자")
  @GenericField(searchable = Searchable.YES, sortable = Sortable.YES)
  protected String availableDateAt;

  @Column(name = "AVAILABLE_DATE_UNTIL")
  @Description(name = "이용가능 마감 일자", comment = "이용가능 마감 일자")
  @GenericField(searchable = Searchable.YES, sortable = Sortable.YES)
  protected String availableDateUntil;

}
