/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.GsonUtil;
import io.rchemist.common.util.MapUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class QuerySpecificationCache implements Serializable {

  private static final String DEFAULT_CACHE_KEY = "DEFAULT";

  private static final String CACHE_KEY_SPLITTER = "_";

  private static final String NULL_VALUE = "_NULL_";

  private final Integer page;
  private final Integer pageSize;
  private final String[] sort;

  private final String searchFormCacheKey;

  private final Map<ConditionOperatorType, QueryCondition> conditions;

  private final Map<String, Join> joinPaths;

  private final List<JoinedSortProperty> joinedSortProperties;

  // unmapped join 을 위한 메타데이터. #mergeConditions 에 의해 query 및 predicate 로 전환된다.
  private final Map<ConditionOperatorType, List<UnmappedJoinItem>> unmappedJoinItems;

  // unmapped join 을 수행해 얻은 join 객체 Map<joinAlias, join>
  private final Map<String, Root<?>> unmappedJoinPaths;

  private final Map<String, String> unmappedJoinSortProperties;

  public QuerySpecificationCache(QuerySpecification specification) {

    SearchFormWrapper<?> searchForm = specification.getSearchForm();

    this.page = searchForm != null ? searchForm.getPage() : null;
    this.pageSize = searchForm != null ? searchForm.getPageSize() : null;
    this.sort = searchForm != null ? searchForm.getSortArray() : null;
    this.searchFormCacheKey = searchForm != null ? searchForm.getCacheKey() : null;
    this.conditions = specification.getConditions();
    this.joinPaths = specification.getJoinPaths();
    this.joinedSortProperties = specification.getJoinedSortProperties();
    this.unmappedJoinItems = specification.getUnmappedJoinItems();
    this.unmappedJoinPaths = specification.getUnmappedJoinPaths();
    this.unmappedJoinSortProperties = specification.getUnmappedJoinSortProperties();
  }

  protected boolean shouldCreateCacheKey() {
    if (page != null && page > 0) {
      return true;
    }
    if (pageSize != null && pageSize != 10) {
      return true;
    }

    if (StringUtils.isNotEmpty(searchFormCacheKey)) {
      return true;
    }

    if (ArrayUtils.isNotEmpty(sort)) {
      return true;
    }
    if (MapUtils.isNotEmpty(conditions)) {
      return true;
    }
    if (MapUtils.isNotEmpty(joinPaths)) {
      return true;
    }
    if (CollectionUtils.isNotEmpty(joinedSortProperties)) {
      return true;
    }
    if (MapUtils.isNotEmpty(unmappedJoinItems)) {
      return true;
    }
    if (MapUtils.isNotEmpty(unmappedJoinPaths)) {
      return true;
    }
    if (MapUtils.isNotEmpty(unmappedJoinSortProperties)) {
      return true;
    }
    return false;
  }

  public String getCacheKey() {
    if (!shouldCreateCacheKey()) {
      return DEFAULT_CACHE_KEY;
    }

    // searchForm 의 cacheKey 가 존재한다면 해당 key 를 사용한다.
    if (StringUtils.isNotEmpty(searchFormCacheKey)) {
      return searchFormCacheKey;
    }

    StringBuilder sb = new StringBuilder();

    try {
      sb.append(GsonUtil.toJson(this));
    } catch (Exception e) {
      sb.append(getCacheKeys(page, pageSize, sort, searchFormCacheKey, MapUtil.toString(conditions), MapUtil.toString(joinPaths), StringUtil.toString(joinedSortProperties), MapUtil.toString(unmappedJoinPaths), MapUtil.toString(unmappedJoinSortProperties)));
    }

    String cacheKey = sb.toString();
    return String.valueOf(Objects.hash(cacheKey));
  }

  private String getCacheKeys(Object... values) {
    if (values == null) {
      return NULL_VALUE;
    }
    StringBuilder sb = new StringBuilder();
    int loopCount = 1;
    int length = values.length;
    for (Object value : values) {
      sb.append(getCacheKeySeparate(value));
      if (loopCount ++ <= length) {
        sb.append(CACHE_KEY_SPLITTER);
      }
    }
    return sb.toString();
  }


  private String getCacheKeySeparate(Object value) {
    if (value == null) {
      return NULL_VALUE;
    }
    String key;
    try {
      key = GsonUtil.toJson(value);
    }catch (Exception e) {
      key = String.valueOf(value);
    }
    return key;
  }

}
