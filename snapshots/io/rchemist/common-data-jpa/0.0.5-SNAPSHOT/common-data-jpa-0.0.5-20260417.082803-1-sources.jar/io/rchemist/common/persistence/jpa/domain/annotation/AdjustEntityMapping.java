/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.annotation;

import io.rchemist.common.persistence.domain.annotation.type.MappingType;
import jakarta.persistence.CascadeType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Generic 으로 매핑된 엔티티를 실제 엔티티 클래스로 매핑 설정을 변경할 수 있도록 하는 어노테이션이다
 *
 * @See ConfigurableFieldImpl
 *
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface AdjustEntityMapping {

  ByProperty[] properties() default {};

  @Target({})
  @Retention(RetentionPolicy.RUNTIME)
  @interface ByProperty {

    /**
     * 프로퍼티를 변경할 대상 템플릿 클래스
     * @return
     */
    Class<?> declaredClass();

    /**
     * 매핑 정보를 변경할 entity.property 명
     * @return
     */
    String propertyName();

    /**
     * 해당 property와 매핑될 실제 엔티티 클래스
     * @return
     */
    Class<?> targetMappingClass();

    /**
     * 변경할 매핑 방식
     *
     * @return
     */
    MappingType mappingType();

    /**
     * OneToMany 타입인 경우 mappedByKey 값을 변경할 수 있다
     * @return
     */
    String mappedByKey() default "";

    /**
     * OneToMany 타입인 경우 cacheRegionName을 변경할 수 있다
     * @return
     */
    String cacheRegionName() default "";

    /**
     * CascadeType 을 새로 지정한다
     * @return
     */
    CascadeType[] cascadeTypes() default {};

    /**
     * Cache 전략을 새로 지정한다
     * @return
     */
    CacheConcurrencyStrategy[] cacheConcurrencyStrategy() default {};

    /**
     * ManyToOne 매핑에서 @JoinColumn() 에 들어갈 컬럼명을 입력한다.
     * @return
     */
    String joinColumnName() default "";

    /**
     * SortComparator : OneToMany 일 때만 가능
     * @return
     */
    Class<?>[] sortComparators() default {};

    /**
     * @BatchSize
     * @return
     */
    int batchSize() default 0;      // 0 이면 batchSize를 따로 설정하지 않는다는 뜻이다

    String[] returnTypeMethods() default {};

    String[] parameterTypeMethods() default {};

  }

}
