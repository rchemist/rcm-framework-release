/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.extension;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.search.data.query.QueryConditionItem;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class QueryConditionResult {

  @Getter
  LinkedHashMap<ConditionOperatorType, List<QueryConditionItem>> queryItemMap = new LinkedHashMap<>();

  public QueryConditionResult() {
  }

  public QueryConditionResult(LinkedHashMap<ConditionOperatorType, List<QueryConditionItem>> queryItemMap) {
    this.queryItemMap = queryItemMap;
  }

  public QueryConditionResult addQueryItems(ConditionOperatorType operator, QueryConditionItem... items) {
    addQueryItems(operator, Arrays.asList(items));
    return this;
  }

  public QueryConditionResult addQueryItems(ConditionOperatorType operator, List<QueryConditionItem> items) {
    List<QueryConditionItem> queryItems = queryItemMap.get(operator);
    if (queryItems == null) {
      queryItems = new java.util.ArrayList<>();
      queryItemMap.put(operator, queryItems);
    }
    queryItems.addAll(items);
    return this;
  }

  public boolean isBlank() {
    return MapUtils.isEmpty(queryItemMap);
  }

  public QueryConditionResult or(QueryConditionItem... items) {
    return addQueryItems(ConditionOperatorType.OR, items);
  }

  public QueryConditionResult and(QueryConditionItem... items) {
    return addQueryItems(ConditionOperatorType.AND, items);
  }
}
