/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.persistence;

import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanDTO;
import io.rchemist.common.util.ExceptionUtil;
import jakarta.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.GenericWebApplicationContext;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component
@Lazy
public class RegisterEntityBean implements ApplicationContextAware, ApplicationListener<ContextRefreshedEvent> {

  private final ConcurrentHashMap<String, Class<?>> entityMap = new ConcurrentHashMap<>(500);

  private final GenericWebApplicationContext webApplicationContext;
  private ApplicationContext applicationContext;

  public RegisterEntityBean(GenericWebApplicationContext webApplicationContext) {
    this.webApplicationContext = webApplicationContext;
    registerEntityBeans();
  }

  @PostConstruct    // refresh entity bean
  public void registerEntityBeans(){
    Map<String, EntityBean<?>> registerEntityBeanDTOMap = PlatformSessionFactoryBuilderFactory.getRegisterEntityBeanMap();
    if(MapUtils.isNotEmpty(registerEntityBeanDTOMap)){
      for (Map.Entry<String, EntityBean<?>> entry : registerEntityBeanDTOMap.entrySet()) {
        if (entry.getValue() instanceof RegisterEntityBeanDTO dto) {
          try{
            webApplicationContext.getBean(dto.getName());
          }catch(NoSuchBeanDefinitionException e){
            registerEntityBean(dto, e);
          }catch (Exception e){
            ExceptionUtil.printStackTrace(e);
          }
        }

      }
    }
  }

  private void registerEntityBean(RegisterEntityBeanDTO dto, NoSuchBeanDefinitionException e) {
    GenericBeanDefinition bd = new GenericBeanDefinition();
    bd.setBeanClass(dto.getEntityClass());
    bd.setScope("prototype");

    if(MapUtils.isNotEmpty(dto.getProperties())){
      MutablePropertyValues propertyValues = new MutablePropertyValues();
      for(Map.Entry<String, String> propEntry : dto.getProperties().entrySet()){
        try{
          propertyValues.addPropertyValue(propEntry.getKey(), applicationContext.getBean(propEntry.getValue()));
        }catch (Exception ee){
          ExceptionUtil.printStackTrace(e);
        }
      }
    }
    webApplicationContext.registerBeanDefinition(dto.getName(), bd);
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

  public Class<?> lookupEntityClass(String beanId) {
    Class<?> clazz;
    if (entityMap.containsKey(beanId)) {
      clazz = entityMap.get(beanId);
    } else {
      Object object = applicationContext.getBean(beanId);
      clazz = object.getClass();
      entityMap.put(beanId, clazz);
    }
    return clazz;
  }

  public String[] getEntityBeanNames() {
    return applicationContext.getBeanDefinitionNames();
  }

  public <T> Class<T> lookupEntityClass(String beanId, Class<T> resultClass) {
    Class<T> clazz;
    if (entityMap.containsKey(beanId)) {
      clazz = (Class<T>) entityMap.get(beanId);
    } else {
      Object object = applicationContext.getBean(beanId);
      clazz = (Class<T>) object.getClass();
      entityMap.put(beanId, clazz);
    }
    return clazz;
  }

  public Object createEntityInstance(String beanId) {
    return applicationContext.getBean(beanId);
  }

  public <T> T createEntityInstance(String beanId, Class<T> resultClass) {
    return (T) applicationContext.getBean(beanId);
  }

  @Override
  public void onApplicationEvent(ContextRefreshedEvent event) {
    registerEntityBeans();
  }
}
