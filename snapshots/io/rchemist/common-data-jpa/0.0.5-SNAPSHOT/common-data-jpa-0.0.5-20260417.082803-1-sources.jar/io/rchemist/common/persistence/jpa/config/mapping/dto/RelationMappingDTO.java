/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping.dto;

import io.rchemist.common.persistence.domain.annotation.type.MappingType;
import jakarta.persistence.CascadeType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PACKAGE)
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Builder
public class RelationMappingDTO implements Serializable {

  String propertyName;
  String declaredClass;
  String targetMappingClass;
  String mappedByKey;
  String joinColumnName;
  MappingType mappingType;
  String cacheRegionName;
  String sortComparator;     // 어노테이션에서는 default 값 때문에 배열로 처리했지만 실제로는 1개만 생성한다
  CacheConcurrencyStrategy cacheConcurrencyStrategy;
  List<CascadeType> cascadeTypes = new ArrayList<>();
  List<String> returnTypeMethods = new ArrayList<>();
  List<String> parameterTypeMethods = new ArrayList<>();
  Integer batchSize;
  String typeName;

  public int getBatchSize(){
    if(batchSize != null && batchSize > 0){
      return batchSize;
    }else{
      return 50;
    }
  }


  public boolean hasPropertyName() {
    return (StringUtils.isNotBlank(propertyName));
  }

  public boolean hasTargetMappingClass() {
    return (StringUtils.isNotBlank(targetMappingClass));
  }

  public boolean hasMappedByKey() {
    return (StringUtils.isNotBlank(mappedByKey));
  }

  public boolean hasJoinColumnName() {
    return (StringUtils.isNotBlank(joinColumnName));
  }

  public boolean hasMappingType() {
    return (mappingType != null);
  }

  public boolean hasCacheRegionName() {
    return (StringUtils.isNotBlank(cacheRegionName));
  }

  public boolean hasSortComparator() {
    return (StringUtils.isNotBlank(sortComparator));
  }

  public boolean hasCacheConcurrencyStrategy() {
    return (cacheConcurrencyStrategy != null);
  }

  public boolean hasCascadeTypes() {
    return (CollectionUtils.isNotEmpty(cascadeTypes));
  }

  public boolean hasBatchSize() { return batchSize != null && batchSize > 0;}

  public boolean hasReturnTypeMethods() {return CollectionUtils.isNotEmpty(returnTypeMethods);}

  public boolean hasParameterTypeMethods() {return CollectionUtils.isNotEmpty(parameterTypeMethods);}
}