/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.configuration;

import io.rchemist.common.configuration.CommonElasticsearchConfig.ConfigEnabled;
import io.rchemist.common.configuration.type.ElasticSearchConfigType;
import io.rchemist.common.search.config.AbstractElasticsearchConfig;
import io.rchemist.common.search.config.ElasticsearchProperties;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

/**
 * Elasticsearch 는 전역에서 참조한다. 굳이 서비스 별로 나눌 필요가 없지만
 * 나눠야 한다면 Repositories 를 구분해 사용하면 된다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Conditional(ConfigEnabled.class)
@Configuration
@EnableElasticsearchRepositories(basePackages = {"io.rchemist.**.**.dao.elastic"}
, elasticsearchTemplateRef= CommonElasticsearchConfig.COMMON_TEMPLATE)
public class CommonElasticsearchConfig extends AbstractElasticsearchConfig {

  public static final String COMMON_TEMPLATE = "commonElasticSearchTemplate";
  public static final String COMMON_CLIENT = "commonElasticSearchClient";
  public static final String COMMON_PROPERTIES = "commonElasticSearchProperties";
  
  private final ElasticsearchProperties properties;

  public CommonElasticsearchConfig(ElasticsearchProperties properties) {
    this.properties = properties;
  }

  @Override
  public ClientConfiguration clientConfiguration() {
    String hostAndPort = properties.getHost() + ":" + properties.getPort();

    final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
    credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(properties.getUsername(), properties.getPassword()));

    ClientConfiguration configuration = ClientConfiguration.builder()
        .connectedTo(hostAndPort)
        .withBasicAuth(properties.getUsername(), properties.getPassword())
        .withConnectTimeout(5000)
        .build();

    return configuration;
  }

  static class ConfigEnabled implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
      String config = StringUtils.defaultIfBlank(context.getEnvironment().getProperty("platform.config.provider.elastic"), "NONE");
      config = config.toUpperCase();

      ElasticSearchConfigType configType = ElasticSearchConfigType.valueOf(config);

      return configType.equals(ElasticSearchConfigType.LOCAL);
    }
  }


/*
  @Override
  @Bean(COMMON_CLIENT)
  @Primary
  public RestClient elasticsearchRestClient() {
    ElasticsearchProperties props = elasticsearchProperties();
    setDefaultValues(props);
    return getRestClient(properties.getHost(), properties.getPort(), properties.getUsername(), properties.getPassword());
  }*/



}
