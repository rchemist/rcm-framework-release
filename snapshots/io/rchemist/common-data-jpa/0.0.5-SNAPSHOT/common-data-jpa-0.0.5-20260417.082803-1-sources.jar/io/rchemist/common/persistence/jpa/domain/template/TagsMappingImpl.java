/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.rchemist.common.persistence.jpa.domain.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.data.StringListFieldPropertyBridge;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.mapper.pojo.bridge.mapping.annotation.PropertyBinderRef;
import org.hibernate.search.mapper.pojo.common.annotation.Param;
import org.hibernate.search.mapper.pojo.extractor.mapping.annotation.ContainerExtract;
import org.hibernate.search.mapper.pojo.extractor.mapping.annotation.ContainerExtraction;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexingDependency;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.ObjectPath;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyBinding;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyValue;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by kunner
 **/
@TemplateClass(value = TagsMapping.class)
@Getter
@Setter
public class TagsMappingImpl implements Serializable, EnhancedTemplate {

  @Column(name = "TAGS", length = 2000)
  //@JdbcTypeCode(SqlTypes.JSON)
  @Description(name = "태그", comment = "상품에 대한 태그 정보, 기본적으로 컴마로 구분해서 작성되며, 이 정보는 검색 엔진에서 상품에 태그 정보로서 인덱스 된다.")
  protected String[] tags;

  @JsonIgnore
  /*@GenericField
  @IndexedEmbedded
  @IndexingDependency(derivedFrom = @ObjectPath(@PropertyValue(propertyName = "tags")))*/
  @PropertyBinding(binder = @PropertyBinderRef(type = StringListFieldPropertyBridge.class, params = {
      @Param(name = "indexName", value = "tags")}))
  @IndexingDependency(derivedFrom = {
      @ObjectPath(@PropertyValue(propertyName = "tags")),}, extraction =
  @ContainerExtraction(extract = ContainerExtract.NO))
  public List<String> getSearchTags() {
    return (ArrayUtils.isNotEmpty(tags)) ? Arrays.asList(tags) : new ArrayList<>();
  }

  @JsonIgnore
  public void setSearchTags(List<String> searchTags) {
    if (CollectionUtils.isNotEmpty(searchTags)) {
      this.tags = searchTags.toArray(new String[0]);
    } else {
      this.tags = null;
    }
  }

  public void setTags(String[] tags) {
    if (tags == null || tags.length == 0) {
      this.tags = null;
    } else {
      List<String> tagList = new ArrayList<>();
      for (String tag : tags) {
        if (StringUtils.isNotEmpty(tag)) {
          tagList.add(tag);
        }
      }
      if (CollectionUtils.isNotEmpty(tagList)) {
        this.tags = tagList.toArray(new String[0]);
      } else {
        this.tags = null;
      }
    }
  }

}
