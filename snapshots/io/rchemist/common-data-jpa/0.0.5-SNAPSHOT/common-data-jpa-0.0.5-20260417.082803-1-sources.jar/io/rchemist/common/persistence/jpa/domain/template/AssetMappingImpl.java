/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Searchable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(AssetMapping.class)
public class AssetMappingImpl implements Serializable, EnhancedTemplate {

  @KeywordField(searchable = Searchable.YES, sortable = Sortable.YES)
  @Column(name = "ASSET_KEY")
  @Description(name = "매핑 키", comment = "시스템에서 사용하는 매핑 키 값")
  @AdminField(order = Integer.MAX_VALUE, fieldType = PresentationFieldType.STRING, hidden = true)
  protected String assetKey;

  @KeywordField(searchable = Searchable.YES, sortable = Sortable.YES)
  @Column(name = "ASSET_URL")
  @AdminField(order = 1000, fieldType = PresentationFieldType.UPLOAD, name = "AssetMappingImpl_AssetUrl"
    , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 1000))
  @Description(name = "URL", comment = "ASSET에 접근할 수 있는 실제 URL")
  protected String assetUrl;

  @Column(name = "ASSET_TAGS", length = 2000)
  @AdminField(order = 1010, fieldType = PresentationFieldType.STRING_LIST, name = "AssetMappingImpl_AssetTags")
  @Description(name = "TAGS", comment = "ASSET 에 지정한 태그")
  protected String[] assetTags;

  @Column(name = "ASSET_FILESIZE")
  @AdminField(order = Integer.MAX_VALUE, fieldType = PresentationFieldType.STRING, hidden = true)
  @Description(name = "FILE SIZE", comment = "파일 용량")
  protected Long fileSize;

  @Column(name = "ASSET_LINK")
  @AdminField(order = 1020, fieldType = PresentationFieldType.STRING, name = "AssetMappingImpl_AssetLink")
  @Description(name = "LINK", comment = "ASSET 에 지정된 링크 URL")
  protected String assetLink;

}
