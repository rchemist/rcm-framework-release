/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.jpa.domain.template.AvailableDate;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * AvailableDate 를 implements 한 Entity 에서 availableDate 필드에 YYYY-MM-DD ~ YYYY-MM-DD 로 sort 하는 경우 availableDate -> availableDateAt 으로 바꿔야 한다.
 *
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component
public class AvailableDateFieldSortModifier implements SearchFieldModifier, SortFieldModifier {

  @Override
  public ModifySortRequest modifySorts(ModifySortRequest request) {

    EntityBean<?> entityBean = request.getEntityBean();

    if (AvailableDate.class.isAssignableFrom(entityBean.getEntityClass()) && request.getSortEntries() != null && !request.getSortEntries().isEmpty()) {
      List<SortEntry> newSortEntries = new ArrayList<>();
      for (SortEntry entry : request.getSortEntries()) {
        String sortKey = entry.getFieldName();
        if (StringUtils.equals(sortKey, "availableDate")) {
          newSortEntries.add(new SortEntry("availableDateAt", entry.getSortInfo()));
        } else {
          newSortEntries.add(entry);
        }
      }

      request.withSortEntries(newSortEntries);
    }
    return request;
  }


  @Override
  public int getOrder() {
    return 1000;
  }
}
