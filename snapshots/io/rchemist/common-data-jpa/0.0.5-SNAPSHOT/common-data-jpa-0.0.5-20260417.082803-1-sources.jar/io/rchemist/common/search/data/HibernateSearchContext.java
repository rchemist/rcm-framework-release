/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import com.google.gson.JsonObject;
import io.rchemist.common.persistence.jpa.EntityManagerHelper;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.persistence.jpa.domain.template.AuditCreated;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.elasticsearch.client.RestClient;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.backend.elasticsearch.ElasticsearchBackend;
import org.hibernate.search.backend.elasticsearch.ElasticsearchExtension;
import org.hibernate.search.backend.elasticsearch.search.query.dsl.ElasticsearchSearchQueryOptionsStep;
import org.hibernate.search.engine.backend.Backend;
import org.hibernate.search.engine.search.predicate.SearchPredicate;
import org.hibernate.search.engine.search.predicate.dsl.BooleanPredicateClausesStep;
import org.hibernate.search.engine.search.predicate.dsl.SearchPredicateFactory;
import org.hibernate.search.engine.search.query.SearchResult;
import org.hibernate.search.engine.search.sort.dsl.SortOrder;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.mapping.SearchMapping;
import org.hibernate.search.mapper.orm.scope.SearchScope;
import org.hibernate.search.mapper.orm.search.loading.dsl.SearchLoadingOptionsStep;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class HibernateSearchContext<T, S extends SearchFormWrapper> {

  @Getter
  private final Class<T> entityClass;
  @Getter
  private final EntityManagerFactory entityManagerFactory;
  @Getter
  private final Session session;
  @Getter
  private final SearchSession searchSession;
  @Getter
  private final SearchScope<T> scope;
  @Getter
  private final SearchPredicateFactory factory;
  @Getter
  private final SearchMapping searchMapping;

  @Getter
  private boolean supportHibernateSearch = true;

  private ElasticsearchBackend backend;

  /**
   * AND 로 묶여야 하는 Predicates
   */
  @Getter
  private List<SearchPredicate> mustPredicates = new ArrayList<>();

  /**
   * OR 로 묶여야 하는 Predicates
   */
  @Getter
  private List<SearchPredicate> shouldPredicates = new ArrayList<>();

  @Getter
  private Map<String, String> searchQuery = new HashMap<>();

  @Getter
  private Integer pageSize;
  @Getter
  private Pageable pageable;

  @Getter
  private S searchForm;

  @Getter
  private String[] explicitFilterNames;

  private static final Set<String> UNSUPPORTED_ENTITY_CLASS_NAMES = new ConcurrentSkipListSet<>();

  public HibernateSearchContext(Class<T> entityClass) {
    this(entityClass, null, (String) null);
  }

  /**
   * @param entityClass
   * @param searchForm
   * @param propertyNames
   */
  public HibernateSearchContext(Class<T> entityClass, S searchForm, String... propertyNames) {
    this(entityClass, searchForm, null, propertyNames);
  }

  /**
   * @param entityClass
   * @param searchForm
   * @param propertyNames
   */
  public HibernateSearchContext(Class<T> entityClass, S searchForm, EntityManager em, String... propertyNames) {
    this.entityClass = entityClass;

    if (UNSUPPORTED_ENTITY_CLASS_NAMES.contains(entityClass.getName())) {
      this.supportHibernateSearch = false;
      this.entityManagerFactory = null;
      this.session = null;
      this.searchSession = null;
      this.scope = null;
      this.factory = null;
      this.pageSize = null;
      this.searchMapping = null;
      return;
    }

    EntityBean<?> registerEntityBeanDTO = PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(
        entityClass.getName());
    if (registerEntityBeanDTO == null) {
      throw new RuntimeException("Hibernate 로 관리되는 Entity 가 아닙니다. : " + entityClass.getName());
    } else {
      this.supportHibernateSearch = registerEntityBeanDTO.isSupportHibernateSearch();

      if (!this.supportHibernateSearch) {
        this.entityManagerFactory = null;
        this.session = null;
        this.searchSession = null;
        this.scope = null;
        this.factory = null;
        this.pageSize = null;
        this.searchMapping = null;
        UNSUPPORTED_ENTITY_CLASS_NAMES.add(entityClass.getName());
      } else {

        this.entityManagerFactory = Objects.requireNonNullElseGet(em, () -> EntityManagerHelper.getEntityManager(entityClass)).getEntityManagerFactory();
        this.session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        this.searchSession = Search.session(session);
        this.scope = searchSession.scope(entityClass);
        this.factory = scope.predicate();
        this.pageSize = searchForm.getPageSize();
        this.searchMapping = Search.mapping(entityManagerFactory);

        initializeContext(entityClass, searchForm, propertyNames);

      }
    }
  }

  private void initializeContext(Class<T> entityClass, S searchForm, String[] propertyNames) {
    // SearchForm 인 경우 filters, sorts 를 검증하고, preservedFilterAndSortCriteria 를 생성한다.
    if (searchForm instanceof FilterMapSearchForm searchFormInstance) {
      searchFormInstance.preparePreservedFilterAndSortCriteria(entityClass, true);
    }

    this.searchForm = searchForm;
    this.pageSize = searchForm.getPageSize();

    Sort sort;

    if (AuditCreated.class.isAssignableFrom(entityClass)) {
      sort = searchForm.getSort("createdAt", Direction.DESC).and(
          searchForm.getSort("id", Direction.DESC));
    } else {
      sort = searchForm.getSort("id", Direction.DESC);
    }

    this.pageable = PageRequest.of(searchForm.getPage(), pageSize, sort);

    if (ArrayUtils.isNotEmpty(propertyNames)) {
      explicitFilterNames = propertyNames;
      addSearchPredicates(propertyNames);
    } else {
      if (searchForm instanceof AbstractSearchForm<?> searchFormInstance) {
        propertyNames = searchFormInstance.getHibernateSearchFieldNames(entityClass);
        if (ArrayUtils.isNotEmpty(propertyNames)) {
          explicitFilterNames = propertyNames;
          addSearchPredicates(propertyNames);
        }
      }
    }

    EntityBean<?> registerEntityBean = PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(
        entityClass.getName());

    if (registerEntityBean != null && registerEntityBean.hasAttributeFields()) {
      // appendAttributePredicates(registerEntityBean.getAttributeFields());
    }
  }

  private void appendAttributePredicates(Map<String, String> attributeNames) {
    // fieldSearchForm 은 deprecated 되므로 SearchForm 만 대상으로 처리한다.
    if (searchForm instanceof AbstractSearchForm<?> form) {

      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();

      if (MapUtils.isNotEmpty(filters)) {

        for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {

          FilterItem[] filterItems = entry.getValue();
          if (ArrayUtils.isNotEmpty(filterItems)) {

            List<Pair<String, Object>> predicateValues = new ArrayList<>();

            for (FilterItem filterItem : filterItems) {

              String propertyName = filterItem.getName();

              if (StringUtils.contains(propertyName, ".")) {

                String previous = StringUtils.substringBefore(propertyName, ".");

                if (attributeNames.containsKey(previous)) {

                  String attrNameField = attributeNames.get(previous) + ".name";
                  String attrValueField = attributeNames.get(previous) + ".value";

                  predicateValues.add(new ImmutablePair<>(attrNameField,
                      StringUtils.substringAfter(propertyName, ".")));
                  predicateValues.add(
                      new ImmutablePair<>(attrValueField, String.valueOf(filterItem.getValue())));

                }
              }

              if (CollectionUtils.isNotEmpty(predicateValues)) {
                shouldAttributesMatch(entry.getKey(), predicateValues);
              }

            }
          }

        }

      }

    }
  }


  public JsonObject getDocument() {
    List<JsonObject> list = getDocuments(1);

    if (CollectionUtils.isNotEmpty(list)) {
      return list.get(0);
    }

    return null;
  }

  public List<JsonObject> getDocuments() {
    return getDocuments(null);
  }

  public List<JsonObject> getDocuments(Integer size) {
    SearchPredicate predicate = mergeSearchPredicates();    // TODO predicate 가 null 일 경우, mergeSearchPredicates 를 할 수 있도록

    List<JsonObject> list;

    ElasticsearchSearchQueryOptionsStep<JsonObject, SearchLoadingOptionsStep> step = searchSession.search(
            entityClass)
        .extension(ElasticsearchExtension.get())
        .select(f ->
            f.source())
        .where(f ->
            f.bool()
                .must(predicate))
        .sort(f -> f.composite(
            b -> {
              for (Order order : pageable.getSort()) {
                b.add(f.field(order.getProperty())
                    .order(SortOrder.valueOf(order.getDirection().name())));
              }
            }
        ));

    if (pageable != null) {
      list = step.fetchHits((int) pageable.getOffset(), NumberUtil.getInteger(size, pageSize));
    } else {
      list = step.fetchHits(NumberUtil.getInteger(size, pageSize));
    }

    return list;
  }

  public List<JsonObject> getAllDocuments() {
    SearchPredicate predicate = mergeSearchPredicates();    // TODO predicate 가 null 일 경우, mergeSearchPredicates 를 할 수 있도록

    List<JsonObject> list = searchSession.search(entityClass)
        .extension(ElasticsearchExtension.get())
        .select(f ->
            f.source())
        .where(f ->
            f.bool()
                .must(predicate))
        .fetchAllHits();

    return list;
  }

  /**
   * 단수 equal
   *
   * @param propertyName
   * @param value
   */
  public HibernateSearchContext<T, S> match(String propertyName, Object value) {
    return match(null, propertyName, value);
  }

  public HibernateSearchContext<T, S> match(ConditionOperatorType operator, String propertyName,
      Object value) {
    if (value != null) {
      SearchPredicate predicate = factory.bool().with(
          b -> b.must(
              factory.match().field(propertyName).matching(value))
      ).toPredicate();
      addPredicate(operator, predicate);
    }
    return this;
  }

  /**
   * equal 비교
   *
   * @param matchValues
   */
  public HibernateSearchContext<T, S> match(Map<String, Object> matchValues) {
    return match(ConditionOperatorType.INHERITED, matchValues);
  }

  /**
   * ConditionOperatorType 을 지정한 equal 비교
   *
   * @param operator
   * @param matchValues
   * @return
   */
  public HibernateSearchContext<T, S> match(ConditionOperatorType operator,
      Map<String, Object> matchValues) {

    SearchPredicate predicate = factory.bool().with(
        b -> matchValues.entrySet().stream().forEach(
            (k) -> b.must(factory.match().field(k.getKey()).matching(k.getValue()))
        )
    ).toPredicate();
    addPredicate(operator, predicate);
    return this;
  }

  /**
   * Or 검색
   *
   * @param matchValues
   */
  public void shouldMatch(Map<String, Object> matchValues) {
    shouldMatch(ConditionOperatorType.INHERITED, matchValues);
  }

  public void shouldMatch(ConditionOperatorType operator, Map<String, Object> matchValues) {
    SearchPredicate should = factory.bool().with(
        b -> matchValues.entrySet().stream().forEach(
            (k) -> b.should(factory.match().field(k.getKey()).matching(k.getValue()))
        )
    ).toPredicate();
    addPredicate(operator, should);
  }

  public void shouldAttributesMatch(ConditionOperatorType operator,
      List<Pair<String, Object>> attributeConditions) {
    // need to create conditions that all of the attributeConditions satisfy.
    SearchPredicate should = factory.bool().with(
        b -> attributeConditions.forEach(
            (k) -> b.must(factory.match().field(k.getKey()).matching(k.getValue()))
        )
    ).toPredicate();
    addPredicate(operator, should);
  }

  /**
   * Or 검색
   *
   * @param propertyName
   * @param matchValues
   */
  public void shouldMatch(String propertyName, Object... matchValues) {
    shouldMatch(ConditionOperatorType.INHERITED, propertyName, matchValues);
  }

  /**
   * ConditionType 을 지정해 OR 검색절 추가
   *
   * @param operator
   * @param propertyName
   * @param matchValues
   */
  public void shouldMatch(ConditionOperatorType operator, String propertyName,
      Object... matchValues) {
    SearchPredicate predicate = factory.bool().with(
        b -> Arrays.stream(matchValues).forEach(
            value -> b.should(factory.match().field(propertyName).matching(value)))
    ).toPredicate();
    addPredicate(operator, predicate);
  }

  public void wildCard(Object value, String... propertyNames) {
    wildCard(value, false, propertyNames);
  }

  public void wildCard(Object value, boolean bidirectional, String... propertyNames) {
    wildCard(ConditionOperatorType.INHERITED, value, bidirectional, propertyNames);
  }

  public void wildCard(ConditionOperatorType operator, Object value, boolean bidirectional,
      String... propertyNames) {
    SearchPredicate predicate;

    if (bidirectional) {
      predicate = factory.wildcard().fields(propertyNames).matching(
          HibernateSearchQueryHelper.getWildcardQueryString(value, true)).toPredicate();
    } else {
      predicate = factory.wildcard().fields(propertyNames)
          .matching(HibernateSearchQueryHelper.getWildcardQueryString(value, false)).toPredicate();
    }

    addPredicate(operator, predicate);
  }


  public void addPredicate(SearchPredicate... predicates) {
    addPredicate(null, predicates);
  }

  private void initializePredicates() {
    if (this.mustPredicates == null) {
      this.mustPredicates = new ArrayList<>();
    }
    if (this.shouldPredicates == null) {
      this.shouldPredicates = new ArrayList<>();
    }
  }

  public void addPredicate(ConditionOperatorType operator, SearchPredicate... predicates) {

    initializePredicates();

    if (ArrayUtils.isNotEmpty(predicates)) {
      if (operator == null || operator.equals(ConditionOperatorType.INHERITED)) {
        operator = getSearchFormOperator();
      }
      if (operator.isMust()) {
        this.mustPredicates.addAll(Arrays.asList(predicates));
      } else {
        this.shouldPredicates.addAll(Arrays.asList(predicates));
      }
    }
  }

  public SearchPredicate mergeSearchPredicates() {

    initializePredicates();

    HibernateSearchPredicateHolder resultHolder = SearchServiceHelper.addHibernateSearchPredicates(
        this);
    this.mustPredicates = resultHolder.getMustPredicates();
    this.shouldPredicates = resultHolder.getShouldPredicates();

    List<SearchPredicate> predicates = new ArrayList<>();

    if (CollectionUtils.isNotEmpty(this.mustPredicates)) {
      BooleanPredicateClausesStep<?> booleanJunction = factory.bool();
      for (SearchPredicate predicate : this.mustPredicates) {
        booleanJunction.must(predicate);
      }
      predicates.add(booleanJunction.toPredicate());
    }

    if (CollectionUtils.isNotEmpty(this.shouldPredicates)) {
      BooleanPredicateClausesStep<?> booleanJunction = factory.bool();
      for (SearchPredicate predicate : this.shouldPredicates) {
        booleanJunction.should(predicate);
      }
      predicates.add(booleanJunction.toPredicate());
    }

    /**
     * merge must + should
     */
    if (predicates.size() == 0) {
      // 조건이 하나도 없는 경우
      return factory.matchAll().toPredicate();
    } else if (predicates.size() == 1) {
      return predicates.get(0);
    } else {
      BooleanPredicateClausesStep<?> booleanJunction = factory.bool();

      // 각 조건은 모두 must 로 합쳐져야 한다.
      for (SearchPredicate predicate : predicates) {
        booleanJunction.must(predicate);
      }
      return booleanJunction.toPredicate();
    }
  }

  public HibernateSearchResult<T> getResult() {
    SearchResult<T> result = getSearchResult();
    return new HibernateSearchResult<>(result, pageSize);
  }

  public Integer getSearchCount() {
    SearchPredicate predicate = mergeSearchPredicates();

    return NumberUtil.getInteger(searchSession.search(entityClass)
        .where(predicate).fetchTotalHitCount());
  }

  public SearchResult<T> getSearchResult() {

    SearchPredicate predicate = mergeSearchPredicates();

    SearchResult<T> result;

    if (pageable != null) {

      result = searchSession.search(entityClass)
          .where(predicate)
          .sort(f -> f.composite(
              b -> {
                for (Order order : pageable.getSort()) {
                  b.add(f.field(order.getProperty())
                      .order(SortOrder.valueOf(order.getDirection().name())));
                }
              }
          ))
          .fetch((int) pageable.getOffset(), pageSize);

    } else {
      result = searchSession.search(entityClass)
          .where(predicate)
          .fetch(pageSize);
    }

    return result;
  }

  public void matchingId(List<Long> idValues) {
    matchingId(ConditionOperatorType.INHERITED, idValues);
  }

  public void matchingId(ConditionOperatorType operator, List<Long> idValues) {
    SearchPredicate predicate = factory.bool().with(
        b -> b.must(factory.id().matchingAny(idValues))
    ).toPredicate();
    addPredicate(operator, predicate);
  }

  public void notMatchingId(List<Long> idValues) {
    matchingId(ConditionOperatorType.INHERITED, idValues);
  }

  public void notMatchingId(ConditionOperatorType operator, List<Long> idValues) {
    SearchPredicate predicate = factory.bool().with(
        b -> b.mustNot(factory.id().matchingAny(idValues))
    ).toPredicate();
    addPredicate(operator, predicate);
  }

  /**
   * TODO SeachForm 인 경우에는 QueryConditionType 을 searchForm 에서 가져오도록 수정
   *
   * @param propertyNames
   * @return
   */
  public HibernateSearchContext<T, S> addSearchPredicates(String... propertyNames) {

    if (searchForm instanceof AbstractSearchForm<?> sForm) {

      FilterItem[] filters = sForm.getFilterItems(ConditionOperatorType.AND);
      if (ArrayUtils.isNotEmpty(filters)) {
        for (FilterItem filter : filters) {
          if (filter.hasSubFilters()) {

            for (Entry<ConditionOperatorType, FilterItem[]> subFilters : filter.getSubFilters()
                .entrySet()) {

              addPredicate(ConditionOperatorType.AND, extractSubSearchPredicates(subFilters).toPredicate());

            }

          } else {
            addSearchPredicate(ConditionOperatorType.AND,
                filter.getName(), filter.getQueryConditionType(), filter.getValue());
          }

        }
      }

      filters = sForm.getFilterItems(ConditionOperatorType.OR);
      if (ArrayUtils.isNotEmpty(filters)) {
        for (FilterItem filter : filters) {

          if (filter.hasSubFilters()) {

            for (Entry<ConditionOperatorType, FilterItem[]> subFilters : filter.getSubFilters()
                .entrySet()) {

              addPredicate(ConditionOperatorType.OR, extractSubSearchPredicates(subFilters).toPredicate());

            }

          } else {
            addSearchPredicate(ConditionOperatorType.OR,
                filter.getName(), filter.getQueryConditionType(), filter.getValue());
          }

        }
      }

      return this;

    } else {
      QueryConditionType conditionType = (searchForm.isExactMatch())
          ? QueryConditionType.EQUAL : QueryConditionType.LIKE;

      return addSearchPredicates(getSearchFormOperator(), conditionType, propertyNames);
    }

  }

  public BooleanPredicateClausesStep<?> extractSubSearchPredicates(Entry<ConditionOperatorType, FilterItem[]> subFilters) {
    ConditionOperatorType subOperator = subFilters.getKey();
    FilterItem[] subFilterItems = subFilters.getValue();

    BooleanPredicateClausesStep<?> booleanJunction = factory.bool();

    for (FilterItem item : subFilterItems) {
      SearchPredicate predicate = HibernateSearchQueryHelper.predicate(factory,
          item.getQueryConditionType(),
          item.getValue(), item.getName());
      if (subOperator.equals(ConditionOperatorType.OR)) {
        booleanJunction.should(predicate);
      } else {
        booleanJunction.must(predicate);
      }
    }
    return booleanJunction;
  }

  public HibernateSearchContext<T, S> addSearchPredicates(ConditionOperatorType operator,
      QueryConditionType conditionType, String... propertyNames) {
    if (ArrayUtils.isNotEmpty(propertyNames)) {
      for (String propertyName : propertyNames) {
        if (searchForm.getValue(propertyName) != null) {
          Object objectValue = searchForm.getValue(propertyName);
          if (objectValue instanceof String) {
            // String 일 때만 like
          } else {
            conditionType = QueryConditionType.EQUAL;
          }
        }

        if (StringUtils.contains(propertyName, ":")) {
          String[] names = StringUtil.splitWithNonEmpty(propertyName, ":");
          if (ArrayUtils.isNotEmpty(names) && names.length == 2) {
            addSearchPredicate(operator, names[0], names[1], conditionType);
          }
        } else {
          addSearchPredicate(operator, propertyName, conditionType);
        }
      }
    }
    return this;
  }

  public HibernateSearchContext<T, S> addSearchPredicate(String propertyName,
      QueryConditionType conditionType) {
    // search form 에서 value 꺼내기
    return addSearchPredicate(getSearchFormOperator(), propertyName, propertyName, conditionType);
  }

  public HibernateSearchContext<T, S> addSearchPredicate(ConditionOperatorType operator,
      String propertyName, QueryConditionType conditionType) {
    // search form 에서 value 꺼내기
    return addSearchPredicate(operator, propertyName, propertyName, conditionType);
  }

  public HibernateSearchContext<T, S> addSearchPredicate(String indexFieldName,
      QueryConditionType equal, Object value) {
    return addSearchPredicate(null, indexFieldName, equal, value);
  }

  public HibernateSearchContext<T, S> addSearchPredicate(ConditionOperatorType operator,
      String propertyName, String indexFieldName, QueryConditionType conditionType) {
    // search form 에서 value 꺼내기
    if (searchForm != null) {
      Object value = searchForm.getValue(propertyName);
      indexFieldName = StringUtil.toString(indexFieldName, propertyName);
      return addSearchPredicate(operator, indexFieldName, conditionType, value);
    }
    return this;
  }

  public HibernateSearchContext<T, S> addSearchPredicate(ConditionOperatorType operator,
      String indexFieldName, QueryConditionType conditionType, Object value) {

    SearchPredicate predicate = HibernateSearchQueryHelper.predicate(factory, conditionType,
        value, indexFieldName);
    if (predicate != null) {
      addPredicate(operator, predicate);
    }

    return this;
  }

  public HibernateSearchContext<T, S> addBetweenPredicate(ConditionOperatorType operator,
      String indexFieldName, Object value1, Object value2) {
    SearchPredicate predicate = HibernateSearchQueryHelper.predicate(factory,
        QueryConditionType.BETWEEN, List.of(value1, value2), indexFieldName);
    if (predicate != null) {
      addPredicate(operator, predicate);
    }
    return this;
  }

  public HibernateSearchContext<T, S> addNotBetweenPredicate(ConditionOperatorType operator,
      String indexFieldName, Object value1, Object value2) {
    SearchPredicate predicate = HibernateSearchQueryHelper.predicate(factory,
        QueryConditionType.NOT_BETWEEN, List.of(value1, value2), indexFieldName);
    if (predicate != null) {
      addPredicate(operator, predicate);
    }
    return this;
  }

  public HibernateSearchContext<T, S> addSearchTermPredicates(
      String... indexFieldNames) {

    if (searchForm == null || ArrayUtils.isEmpty(indexFieldNames) || StringUtils.isEmpty(
        searchForm.getSearchTerm())) {
      return this;
    }

    QueryConditionType conditionType =
        searchForm.isExactMatch() ? QueryConditionType.EQUAL : QueryConditionType.LIKE;

    for (String name : indexFieldNames) {
      addSearchPredicate(getSearchFormOperator(), name, conditionType, searchForm.getSearchTerm());
    }

    return this;

  }

  protected ConditionOperatorType getSearchFormOperator() {
    return searchForm == null ? ConditionOperatorType.AND : searchForm.getOperator();
  }

  public HibernateSearchPredicateHolder createSearchPredicateResultHolder() {
    HibernateSearchPredicateHolder holder = new HibernateSearchPredicateHolder(
        getSearchFormOperator()
        , getMustPredicates()
        , getShouldPredicates());
    return holder;
  }

  public ElasticsearchBackend getBackend() {
    if (backend == null) {
      Backend backend = searchMapping.backend();
      this.backend = backend.unwrap(ElasticsearchBackend.class);
    }

    return backend;
  }

  public RestClient getRestClient() {
    return getBackend().client(RestClient.class);
  }

}
