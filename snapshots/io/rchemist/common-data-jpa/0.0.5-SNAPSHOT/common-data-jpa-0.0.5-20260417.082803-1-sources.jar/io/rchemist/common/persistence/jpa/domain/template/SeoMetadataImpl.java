/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(SeoMetadata.class)
@Getter
@Setter
public class SeoMetadataImpl implements EnhancedTemplate {

  @Column(name = "META_TITLE")
  @Description(name = "메타 제목", comment = "메타 데이터 제목에 들어갈 내용")
  /*// @AdminPresentation(friendlyName = "SeoMetadataImpl_MetaTitle", order = 1000, tooltip = "SeoMetadataImpl_MetaTitle_Tooltip"
      , tab = PresentationVariables.Tab.SeoMetadata.TYPE, tabOrder = PresentationVariables.Tab.SeoMetadata.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.SeoMetadata.TYPE, order = PresentationVariables.Group.SeoMetadata.ORDER))*/
  protected String metaTitle;

  @Column(name = "META_DESC", length = 1000)
  @Description(name = "메타 설명", comment = "메타 데이터 설명에 들어갈 내용")
  /*// @AdminPresentation(friendlyName = "SeoMetadataImpl_MetaDescription", order = 2000, largeEntry = true, tooltip = "SeoMetadataImpl_MetaDescription_Tooltip"
      , tab = PresentationVariables.Tab.SeoMetadata.TYPE, tabOrder = PresentationVariables.Tab.SeoMetadata.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.SeoMetadata.TYPE, order = PresentationVariables.Group.SeoMetadata.ORDER))*/
  protected String metaDescription;

  @Column(name = "META_HEADER")
  @Text
  @Description(name = "메타 헤더", comment = "메타 데이터 헤더에 들어갈 내용을 \\';\\' 로 구분해 문자열로 입력")
  /*// @AdminPresentation(excluded = true, friendlyName = "SeoMetadataImpl_MetaHeader", order = 3000, largeEntry = true, tooltip = "SeoMetadataImpl_MetaHeader_Tooltip"
      , tab = PresentationVariables.Tab.SeoMetadata.TYPE, tabOrder = PresentationVariables.Tab.SeoMetadata.ORDER
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.SeoMetadata.TYPE, order = PresentationVariables.Group.SeoMetadata.ORDER))*/
  protected String metaHeader;

  /**
   * HTML 관련 태그 제거
   * @return
   */
  public String getMetaTitle() {
    String metaTitle = StringUtil.sanitize(this.metaTitle);
    return (metaTitle == null || metaTitle.equals("NULL")) ? null : metaTitle;
  }

  /**
   * HTML 관련 태그 제거
   * @return
   */
  public String getMetaDescription() {
    String metaDescription = StringUtil.sanitize(this.metaDescription);
    return (metaDescription == null || metaDescription.equals("NULL")) ? null : metaDescription;
  }
}
