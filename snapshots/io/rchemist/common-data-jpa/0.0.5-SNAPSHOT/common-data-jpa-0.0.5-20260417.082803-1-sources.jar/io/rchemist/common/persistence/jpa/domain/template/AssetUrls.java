/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetUrls<T> extends ClassTransformTarget {

  default String[] getAssetUrls() {
    throw new ClassTransformException();
  }

  default void setAssetUrls(String[] assetUrls) {
    throw new ClassTransformException();
  }

  default void setAssetUrls(List<String> assetUrls) {
    if (CollectionUtils.isEmpty(assetUrls)) {
      return;
    }
    setAssetUrls(assetUrls.toArray(new String[0]));
  }

  default T withAssetUrls(String[] assetUrls) {
    setAssetUrls(assetUrls);
    return (T) this;
  }

  default T withAssetUrls(List<String> assetUrls) {
    setAssetUrls(assetUrls);
    return (T) this;
  }

  default boolean hasAssetUrls() {
    return ArrayUtils.isNotEmpty(getAssetUrls());
  }

  default T addAssetUrls(String... links) {
    setAssetUrls(links);
    return (T) this;
  }

  default T removeAssetUrl(String... links) {
    List<String> assetUrls = new ArrayList<>(Arrays.asList(getAssetUrls()));
    if (CollectionUtils.isNotEmpty(assetUrls)) {
      assetUrls.removeAll(Arrays.asList(links));
    }
    setAssetUrls(assetUrls.toArray(new String[0]));
    return (T) this;
  }


}
