/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.Objects;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface TenantId<T> extends ClassTransformTarget {

  default String getTenantId(){
    throw new ClassTransformException();
  }

  default void setTenantId(String tenantId){
    throw new ClassTransformException();
  }

  default boolean isEqualTenant(String tenantId){
    return Objects.equals(getTenantId(), tenantId);
  }

  default T withTenantId(String tenantId){
    setTenantId(tenantId);
    return (T) this;
  }


}
