/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * Bytecode assist를 이용해 priority 필드를 자동으로 추가한다
 * <p>
 * dao 에서 필요한 경우 자동으로 정렬 옵션을 추가한다
 **/

public interface Priority<T> extends ClassTransformTarget, Comparable<Priority<T>> {

  default Integer getPriority() {
    throw new ClassTransformException();
  }

  default void setPriority(Integer priority) {
    throw new ClassTransformException();
  }

  /**
   * 리턴되는 int값이 음수이면 현재 인스턴스가 비교대상인 인스턴스보다 작고, 양수이면 크고, 0 이면 같다
   * @param p
   * @return
   */
  default int compareTo(Priority p) {
    Integer thisPriority = this.getPriority() != null ? this.getPriority() : Integer.MAX_VALUE;
    Integer otherPriority = p.getPriority() != null ? p.getPriority() : Integer.MAX_VALUE;
    return thisPriority.compareTo(otherPriority);
  }

  default int getPriorityNumber(){
    return getPriority() != null ? getPriority() : 0;
  }

  default T withPriority(Integer priority) {
    setPriority(priority);
    return (T) this;
  }

  default void increasePriority() {
    setPriority(getPriorityNumber() + 1);
  }

}
