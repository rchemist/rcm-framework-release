/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * QuerySpecification의 조건 추가 및 관리를 담당하는 클래스
 * 조건 추가 관련 로직을 분리하여 책임을 명확히 함
 */
@Slf4j
public class ConditionManager<T extends Serializable, S extends SearchFormWrapper<S>> {

  private final S searchForm;
  private final Map<ConditionOperatorType, QueryCondition> conditions;
  private final String[] explicitFilterNames;

  public ConditionManager(S searchForm, 
                         Map<ConditionOperatorType, QueryCondition> conditions,
                         String[] explicitFilterNames) {
    this.searchForm = searchForm;
    this.conditions = conditions;
    this.explicitFilterNames = explicitFilterNames;
  }

  /**
   * 조건 추가 - 프로퍼티 이름 배열 방식
   */
  public void addConditions(ConditionOperatorType conditionOperatorType, 
                           QueryConditionType conditionType, 
                           String... propertyNames) {
    
    // 원본과 동일한 순서: null 체크를 먼저 수행
    if (conditionOperatorType == null) {
      addConditions(ConditionOperatorType.AND, conditionType, propertyNames);
      addConditions(ConditionOperatorType.OR, conditionType, propertyNames);
      return;
    }
    
    ConditionOperatorType resolvedOperatorType = resolveOperatorType(conditionOperatorType);

    if (propertyNames != null && ArrayUtils.isNotEmpty(propertyNames)) {
      QueryCondition queryCondition = getOrCreateQueryCondition(resolvedOperatorType);
      
      if (isNullCondition(conditionType)) {
        addNullConditions(queryCondition, conditionType, propertyNames);
      } else {
        // addRegularConditions는 변경된 queryCondition을 반환할 수 있음
        queryCondition = addRegularConditions(queryCondition, resolvedOperatorType, conditionType, propertyNames);
      }

      conditions.put(resolvedOperatorType, queryCondition);
    }
  }

  /**
   * 조건 추가 - 단일 프로퍼티와 값 방식
   */
  public void addConditions(ConditionOperatorType conditionOperatorType, 
                           String propertyName, 
                           QueryConditionType conditionType, 
                           Object value) {
    addConditionsWithJoin(conditionOperatorType, propertyName, conditionType, value, null);
  }

  /**
   * 조건 추가 - 조인과 함께
   */
  public void addConditionsWithJoin(ConditionOperatorType conditionOperatorType, 
                                   String propertyName, 
                                   QueryConditionType conditionType, 
                                   Object value, 
                                   JoinType joinType) {
    
    ConditionOperatorType resolvedOperatorType = resolveOperatorType(conditionOperatorType);
    QueryCondition context = getOrCreateQueryCondition(resolvedOperatorType);
    
    if (joinType != null) {
      context.addConditions(joinType, conditionType, propertyName, value);
    } else {
      context.addConditions(conditionType, propertyName, value);
    }
    
    conditions.put(resolvedOperatorType, context);
  }

  /**
   * 조건 추가 - QueryCondition 직접 추가
   */
  public void addConditions(ConditionOperatorType conditionOperatorType, 
                           QueryCondition... queryConditions) {
    
    ConditionOperatorType resolvedOperatorType = resolveOperatorType(conditionOperatorType);
    
    if (conditions.containsKey(resolvedOperatorType)) {
      QueryCondition condition = conditions.get(resolvedOperatorType);
      
      for (QueryCondition c : queryConditions) {
        condition = condition.merge(c);
      }
      
      conditions.put(resolvedOperatorType, condition);
    } else {
      
      if (queryConditions.length > 1) {
        QueryCondition condition = new QueryCondition();
        
        for (QueryCondition c : queryConditions) {
          condition = condition.merge(c);
        }
        
        conditions.put(resolvedOperatorType, condition);
      } else {
        conditions.put(resolvedOperatorType, queryConditions[0]);
      }
    }
  }

  private ConditionOperatorType resolveOperatorType(ConditionOperatorType conditionOperatorType) {
    if (conditionOperatorType == null || conditionOperatorType.equals(ConditionOperatorType.INHERITED)) {
      return searchForm.getOperator();
    }
    return conditionOperatorType;
  }

  private QueryCondition getOrCreateQueryCondition(ConditionOperatorType operatorType) {
    return conditions.computeIfAbsent(operatorType, k -> new QueryCondition());
  }

  private boolean isNullCondition(QueryConditionType conditionType) {
    return conditionType.equals(QueryConditionType.NULL) || 
           conditionType.equals(QueryConditionType.NOT_NULL);
  }

  private void addNullConditions(QueryCondition queryCondition, 
                                QueryConditionType conditionType, 
                                String... propertyNames) {
    for (String propertyName : propertyNames) {
      if (conditionType.equals(QueryConditionType.NULL)) {
        queryCondition.addQueryItems(SingleConditionItem.isNull(propertyName));
      } else {
        queryCondition.addQueryItems(SingleConditionItem.notNull(propertyName));
      }
    }
  }

  private QueryCondition addRegularConditions(QueryCondition queryCondition, 
                                            ConditionOperatorType operatorType, 
                                            QueryConditionType conditionType, 
                                            String... propertyNames) {
    for (String propertyName : propertyNames) {
      
      if (isExplicitlyFiltered(propertyName)) {
        continue;
      }

      String pathName = StringUtil.subStringAfter(propertyName, ":");
      Object value = searchForm.getValue(operatorType, conditionType, pathName);

      if (value != null) {
        processValueCondition(queryCondition, operatorType, conditionType, propertyName, pathName, value);
      } else {
        // processSubConditions는 변경된 queryCondition을 반환할 수 있음
        queryCondition = processSubConditions(queryCondition, operatorType, propertyName);
      }
    }
    return queryCondition;
  }

  private boolean isExplicitlyFiltered(String propertyName) {
    return ArrayUtils.contains(explicitFilterNames, propertyName);
  }

  private void processValueCondition(QueryCondition queryCondition, 
                                    ConditionOperatorType operatorType,
                                    QueryConditionType conditionType,
                                    String propertyName,
                                    String pathName, 
                                    Object value) {
    if (searchForm instanceof AbstractSearchForm<?> form) {
      FilterItem[] items = form.getFilterItems(operatorType, pathName);
      queryCondition.addConditions(items);
    } else {
      // 원본과 동일한 로직: conditionType을 기본값으로 사용
      QueryConditionType queryConditionType = conditionType;

      if(value instanceof EnumType || value instanceof Boolean) {
        queryConditionType = QueryConditionType.EQUAL;
      }

      // 원본과 동일하게 propertyName 사용
      queryCondition.addConditions(queryConditionType, propertyName, value);
    }
  }

  private QueryCondition processSubConditions(QueryCondition queryCondition, 
                                             ConditionOperatorType operatorType, 
                                             String propertyName) {
    if (searchForm instanceof AbstractSearchForm<?> form) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> subConditions = 
          form.getSubConditions(operatorType, propertyName);

      if (MapUtils.isNotEmpty(subConditions)) {
        for (Entry<ConditionOperatorType, FilterItem[]> entry : subConditions.entrySet()) {
          ConditionOperatorType subOperatorType = entry.getKey();
          FilterItem[] filterItems = entry.getValue();

          if (ArrayUtils.isNotEmpty(filterItems)) {
            QueryCondition subQueryCondition = new QueryCondition();

            for (FilterItem filterItem : filterItems) {
              // single filter
              subQueryCondition.addConditions(filterItem);
            }

            CombinedConditionItem subConditionItem = new CombinedConditionItem(
                subOperatorType, subQueryCondition.getAllQueryConditionItems());

            // 원본과 동일하게 반환값을 다시 할당
            queryCondition = queryCondition.addCombinedConditionItem(subConditionItem);
            // conditions.put(subConditionOperatorType, subQueryCondition); // 원본 주석도 보존
          }
        }
      }
    }
    return queryCondition;
  }
}