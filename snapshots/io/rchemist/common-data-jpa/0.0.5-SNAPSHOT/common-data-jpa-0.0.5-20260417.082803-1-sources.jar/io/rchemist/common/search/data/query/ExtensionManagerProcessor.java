/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.search.data.extension.SearchServiceExtensionManager;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.Serializable;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;

/**
 * ExtensionManager 처리를 담당하는 클래스
 * QuerySpecification에서 확장 기능 관련 로직을 분리
 */
@Slf4j
public class ExtensionManagerProcessor<T extends Serializable, S extends SearchFormWrapper<S>> {

  private static SearchServiceExtensionManager extensionManager;

  private final Class<T> entityClass;
  private final S searchForm;
  private final Map<ConditionOperatorType, QueryCondition> conditions;

  public ExtensionManagerProcessor(Class<T> entityClass, S searchForm, 
                                 Map<ConditionOperatorType, QueryCondition> conditions) {
    this.entityClass = entityClass;
    this.searchForm = searchForm;
    this.conditions = conditions;
  }

  /**
   * ExtensionManager를 통한 조건 추가 처리
   * @return 명시적으로 필터링된 프로퍼티 이름들
   */
  public String[] process() {
    log.debug("Processing ExtensionManager for entity: {}", entityClass.getSimpleName());
    
    ExtensionResultHolder<QuerySpecificationResultHolder> erh = new ExtensionResultHolder<>();

    getExtensionManager().getProxy().addQueryPredicates(entityClass, searchForm, erh);

    if (erh.getResult() != null) {
      
      // 확장된 조건들을 기존 조건에 병합
      Map<ConditionOperatorType, QueryCondition> result = erh.getResult().getResult();
      mergeExtensionConditions(result);

      // 필터링된 프로퍼티 이름 반환
      if (erh.getResult().isFiltered()) {
        String[] filtered = erh.getResult().getFiltered();
        log.debug("ExtensionManager filtered properties: {}", (Object) filtered);
        return filtered;
      }
    }

    log.debug("ExtensionManager processing completed for entity: {}", entityClass.getSimpleName());
    return null;
  }

  private void mergeExtensionConditions(Map<ConditionOperatorType, QueryCondition> extensionConditions) {
    if (MapUtils.isNotEmpty(extensionConditions)) {
      extensionConditions.entrySet().forEach(entry -> {
        ConditionOperatorType key = entry.getKey();
        QueryCondition extensionCondition = entry.getValue();

        if (conditions.containsKey(key)) {
          QueryCondition prevCondition = conditions.get(key);
          prevCondition.merge(extensionCondition);
          conditions.put(key, prevCondition);
        } else {
          conditions.put(key, extensionCondition);
        }
      });
      
      log.debug("Merged {} extension conditions", extensionConditions.size());
    }
  }

  private static SearchServiceExtensionManager getExtensionManager() {
    if (extensionManager == null) {
      extensionManager = ApplicationContextHolder.getBean(SearchServiceExtensionManager.class);
    }
    return extensionManager;
  }
}