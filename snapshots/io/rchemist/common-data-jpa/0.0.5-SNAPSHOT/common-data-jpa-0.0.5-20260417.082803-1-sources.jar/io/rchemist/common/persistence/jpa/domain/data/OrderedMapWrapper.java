/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.data;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * 
 * A wrapper around LinkedHashMap that properly implements equals() to detect order changes
 * for JPA dirty checking
 **/
public class OrderedMapWrapper implements Map<String, String> {

  private final LinkedHashMap<String, String> map;

  public OrderedMapWrapper() {
    this.map = new LinkedHashMap<>();
  }

  public OrderedMapWrapper(Map<String, String> source) {
    this.map = new LinkedHashMap<>();
    if (source != null) {
      this.map.putAll(source);
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    
    OrderedMapWrapper other = (OrderedMapWrapper) obj;
    
    // Check size first
    if (map.size() != other.map.size()) return false;
    
    // Check both content and order by comparing key sequences
    Iterator<String> thisIter = map.keySet().iterator();
    Iterator<String> otherIter = other.map.keySet().iterator();
    
    while (thisIter.hasNext() && otherIter.hasNext()) {
      String thisKey = thisIter.next();
      String otherKey = otherIter.next();
      
      // Check if keys are in same order
      if (!Objects.equals(thisKey, otherKey)) {
        return false;
      }
      
      // Check if values are equal
      if (!Objects.equals(map.get(thisKey), other.map.get(otherKey))) {
        return false;
      }
    }
    
    return true;
  }

  @Override
  public int hashCode() {
    // Hash should consider both content and order
    int result = 1;
    for (Map.Entry<String, String> entry : map.entrySet()) {
      result = 31 * result + Objects.hashCode(entry.getKey());
      result = 31 * result + Objects.hashCode(entry.getValue());
    }
    return result;
  }

  @Override
  public String toString() {
    return map.toString();
  }

  // Delegate all Map operations to the underlying LinkedHashMap
  @Override
  public int size() {
    return map.size();
  }

  @Override
  public boolean isEmpty() {
    return map.isEmpty();
  }

  @Override
  public boolean containsKey(Object key) {
    return map.containsKey(key);
  }

  @Override
  public boolean containsValue(Object value) {
    return map.containsValue(value);
  }

  @Override
  public String get(Object key) {
    return map.get(key);
  }

  @Override
  public String put(String key, String value) {
    return map.put(key, value);
  }

  @Override
  public String remove(Object key) {
    return map.remove(key);
  }

  @Override
  public void putAll(Map<? extends String, ? extends String> m) {
    map.putAll(m);
  }

  @Override
  public void clear() {
    map.clear();
  }

  @Override
  public Set<String> keySet() {
    return map.keySet();
  }

  @Override
  public Collection<String> values() {
    return map.values();
  }

  @Override
  public Set<Map.Entry<String, String>> entrySet() {
    return map.entrySet();
  }

  // Helper method to get the underlying LinkedHashMap
  public LinkedHashMap<String, String> getMap() {
    return new LinkedHashMap<>(map);
  }
}