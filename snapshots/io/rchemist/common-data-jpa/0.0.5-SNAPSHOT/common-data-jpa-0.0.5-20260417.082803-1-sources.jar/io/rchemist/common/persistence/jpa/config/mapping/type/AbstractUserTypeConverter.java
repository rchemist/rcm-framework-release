/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping.type;

import java.util.Enumeration;
import java.util.Properties;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.usertype.ParameterizedType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public abstract class AbstractUserTypeConverter implements ParameterizedType {

  public static final String PARAMETER_CLASS_NAME = "PARAMETER_CLASS_NAME|";
  protected String className = "";

  @Override
  public void setParameterValues(Properties parameters) {
    setClassName(parameters);
  }

  public void setClassName(Properties parameters) {
    Enumeration<?> parameterNames = parameters.propertyNames();
    while(parameterNames.hasMoreElements()){
      String parameterName = (String) parameterNames.nextElement();
      if(parameterName.startsWith(PARAMETER_CLASS_NAME)){
        this.className = parameters.getProperty(parameterName);
        break;
      }
    }
  }

  public String getClassName() {
    return className;
  }

  protected Class getReturnedClassType() throws ClassNotFoundException {
    return ClassUtils.getClass(className);
  }

  protected Class getProperClass() throws ClassNotFoundException {
    Class aClass = getReturnedClassType();
    String className = aClass.getCanonicalName();
    if(className.contains("[]")){
      return Class.forName(StringUtils.substringBefore(className, "[]"));
    }
    return aClass;
  }
}
