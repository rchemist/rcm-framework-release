/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import io.rchemist.common.configuration.platform.DataProviderConfig;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.jpa.domain.template.NeverDelete;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.RevisionEntityWrapper;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.extension.ResponseListExtensionManager;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.common.web.service.type.RevisionType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.boot.logging.LogLevel;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ResponseEntityService<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException>
    extends HibernateSearchResponseEntityService<ENTITY, VIEW, SEARCH_FORM, ID, SERVICE_EXCEPTION> {

  /**
   * Revision log 를 사용할 때 기본 지정하는 엔티티 이름. 없으면 entityClassName 을 기본으로 사용한다.
   * CreateForm, UpdateForm 에서 따로 entityName 을 지정해 전달할 수 있다.
   * 우선순위는 Form.entityName > this.getEntityName() > entity.getClass().getSimpleName() 순이다.
   * @return
   */
  default String getRevisionEntityName() {
    return null;
  }

  /**
   * Entity revision logging 기능을 사용할지 여부
   * 엔티티의 CUD 가 발생할 때 Revision Entity 를 저장할지 여부
   * 단순 logging 엔티티의 경우 불필요하게 Revision 이 생성될 수 있기 때문에 이 값을 false 로 해야 한다.
   * 기본값은 true 로 모든 revision entity 의 CUD 저장한다.
   * @return
   */
  default boolean isUseLogEntityRevision() {
    return true;
  }

  /**
   * ResponseEntityService 차원에서 CUD 프로세스에 대한 추가적인 권한 체크 확장 기능을 사용할 것인지 여부
   * @return
   */
  default boolean isUseAdditionalEntityPermission() {
    return true;
  }

  /**
   * Data 조회를 위한 Repository
   * @return Repository
   */
  CommonSearchRepository<ENTITY, ID> getRepository();

  /**
   * Entity 가 존재하지 않았을 때 발생하는 예외
   * @return ErrorTypeServiceException
   */
  SERVICE_EXCEPTION entityNotFoundException();

  /**
   * 실제 DB 트랜잭션을 의미하는 것이 아님
   * User.create(form) 과 같은 메소드를 연결해주는 역할
   * @param form CreateForm
   * @return Entity
   */
  ENTITY createEntity(CREATE_FORM form) throws SERVICE_EXCEPTION;

  ENTITY updateEntity(ENTITY entity, UPDATE_FORM form) throws SERVICE_EXCEPTION;

  /**
   * 실제 DB 트랜잭션을 의미하는 것이 아님
   * UserView.create(entity) 과 같은 메소드를 연결해주는 역할
   * @param entity Entity
   * @return View
   */
  VIEW getView(ENTITY entity, EntityViewType viewType) throws SERVICE_EXCEPTION;

  /**
   * 여러 엔티티를 한번에 생성
   * @param forms CreateForms
   * @return Views
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  List<VIEW> createEntities(List<CREATE_FORM> forms) throws SERVICE_EXCEPTION;

  /**
   * 여러 엔티티를 한번에 수정
   * @param forms UpdateForms
   * @return Views
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  List<VIEW> updateEntities(List<UPDATE_FORM> forms) throws SERVICE_EXCEPTION;

  /**
   * 검색을 위한 Context 생성
   * context 에 검색 조건을 추가할 수 있다.
   * @param form SearchForm
   * @return SearchContext
   */
  SearchContext<ENTITY, SEARCH_FORM> getSearchContext(SEARCH_FORM form) throws SERVICE_EXCEPTION;

  /**
   * DB 에서 엔티티를 조회하고 존재하지 않으면 ENTITY_NOT_FOUND Exception 발생
   * @param id ID
   * @return Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default ENTITY findEntityById(ID id) throws SERVICE_EXCEPTION {
    if (id == null)
      throw entityNotFoundException();
    return findOptionalEntityById(id).orElseThrow(this::entityNotFoundException);
  }

  /**
   * Controller 에서 사용할 수 있게 ID 를 VIEW 로 변환하는 메소드
   * @param id ID
   * @return View
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default VIEW findViewById(ID id) throws SERVICE_EXCEPTION {
    if (id == null)
      throw entityNotFoundException();
    return findViewById(id, EntityViewType.VIEW);
  }

  /**
   * Controller 에서 사용할 수 있게 ID 를 VIEW 로 변환하는 메소드
   * @param id ID
   * @param entityViewType ViewType
   * @return View
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default VIEW findViewById(ID id, EntityViewType entityViewType) throws SERVICE_EXCEPTION {
    if (id == null)
      throw entityNotFoundException();
    return getView(findEntityById(id), entityViewType == null ? EntityViewType.LIST : entityViewType);
  }

  /**
   * DB에서 Optional<ENTITY> 반환
   * @param id ID
   * @return Optional<Entity>
   */
  default Optional<ENTITY> findOptionalEntityById(ID id) throws SERVICE_EXCEPTION{
    if (id == null)
      throw entityNotFoundException();
    ENTITY entity = getRepository().findById(id).orElse(null);

    if (entity instanceof SoftDelete<?> softDelete) {
      if (softDelete.isArchived()) {
        entity = null;
      }
    }

    return Optional.ofNullable(entity);
  }

  /**
   * DB 에 엔티티를 저장하고 저장된 엔티티를 반환
   * 트랜잭션 처리를 위해 @Transactional(rollbackFor = ErrorTypeException.class) 어노테이션을 붙여준다.
   * @param entity Entity
   * @return Entity
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default ENTITY save(ENTITY entity) {
    if (entity == null)
      return null;
    return getRepository().save(entity);
  }

  /**
   * 여러 엔티티를 한번에 저장
   * @param entities Entities
   * @return Entities
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default List<ENTITY> saveAll(List<ENTITY> entities) {
    if (CollectionUtils.isEmpty(entities))
      return new ArrayList<>();

    try {
      return getRepository().saveAll(entities);
    }catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * deleteById 를 실행하기 전 custom validate 를 할 수 있게 만든 메소드
   * @param id ID
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default void preDeleteById(ID id) throws SERVICE_EXCEPTION {
    // do nothing
  }

  /**
   * ID 를 이용해 DB 에서 엔티티를 삭제하고 성공 여부를 반환
   * 트랜잭션 처리를 위해 @Transactional(rollbackFor = ErrorTypeException.class) 어노테이션을 붙여준다.
   * @param id ID
   * @return error 여부
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default boolean deleteById(ID id) {
    return deleteByForm(new DeleteForm<ID>().withId(id));
  }

  @Transactional(rollbackFor = ErrorTypeException.class)
  default boolean deleteByForm(DeleteForm<ID> form) {
    if (form == null || form.isEmpty())
      return false;

    boolean result = false;
    ENTITY entity = null;

    ID id = form.getId() == null ? form.getIds().get(0) : form.getId();
    try {
      preDeleteById(id);
      entity = findEntityById(id);

      checkAdditionalPermission(RevisionType.DELETE, entity, null);

      result = delete(entity);
      return result;
    } catch (ErrorTypeException e) {
      ExceptionUtil.printStackTrace(e);
      return false;
    } finally {
      if (result && entity != null) {
        logEntityDeleteRevision(form.getRevisionEntityName(), entity);
      }
    }
  }

  /**
   * delete 를 실행하기 전 custom validate 를 할 수 있게 만든 메소드
   * @param entity Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default void preDelete(ENTITY entity) throws SERVICE_EXCEPTION {
    // do nothing
  }

  /**
   * 삭제하고 난 후 처리, 여기서는 Exception 을 내면 안 된다.
   * @param entity Entity
   * @param isDeleted 삭제 성공 여부
   */
  default void postDelete(ENTITY entity, boolean isDeleted) {

  }

  /**
   * DB 에서 엔티티를 삭제하고 성공 여부를 반환
   * 트랜잭션 처리를 위해 @Transactional(rollbackFor = ErrorTypeException.class) 어노테이션을 붙여준다.
   * @param entity Entity
   * @return 삭제 성공 여부
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default boolean delete(ENTITY entity) {
    boolean result = false;
    try {
      preDelete(entity);
      if (entity instanceof NeverDelete neverDelete) {
        // 삭제해서는 안 되는 경우
        neverDelete.setActive(false);
        getRepository().save(entity);
      } else {
        getRepository().delete(entity);
      }
      result = true;
      return true;
    }catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
      return false;
    }finally {
      postDelete(entity, result);
    }
  }

  /**
   * CREATE_FORM 을 이용해 엔티티를 생성, 저장하고 VIEW 를 반환
   * 실제 DB 처리된다.
   * 트랜잭션 처리를 위해 @Transactional(rollbackFor = ErrorTypeException.class) 어노테이션을 붙여준다.
   * @param form CreateForm
   * @return View
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default VIEW create(CREATE_FORM form) throws SERVICE_EXCEPTION {
    ENTITY entity = createAndSave(form);
    VIEW view = getView(entity, form.getViewType() == null ? EntityViewType.DETAIL : form.getViewType());
    logEntityCreateRevision(entity, form, view);
    return view;
  }

  /**
   * CREATE_FORM 을 이용해 엔티티가 생성되고 SAVE 된 후 후처리가 필요한 경우 이 메소드를 override 한다.
   * @param entity Entity
   * @param form CreateForm
   * @return Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default ENTITY postCreate(ENTITY entity, CREATE_FORM form) throws SERVICE_EXCEPTION {
    return entity;
  }

  /**
   * UPDATE_FORM 을 이용해 엔티티를 조회, 수정, 저장한 후 후처리가 필요한 경우 이 메소드를 override 한다.
   * @param entity Entity
   * @param form UpdateForm
   * @return Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default ENTITY postUpdate(ENTITY entity, UPDATE_FORM form) throws SERVICE_EXCEPTION {
    return entity;
  }

  /**
   * CREATE_FORM 을 이용해 엔티티를 생성, 저장하고 ENTITY 를 반환
   * @param form CreateForm
   * @return DB 저장된 Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default ENTITY createAndSave(CREATE_FORM form) throws SERVICE_EXCEPTION {
    ENTITY entity = createEntity(form);

    checkAdditionalPermission(RevisionType.CREATE, entity, form);

    overrideCreate(entity, form);

    entity = save(entity);
    return postCreate(entity, form);
  }

  default void overrideCreate(ENTITY entity, CREATE_FORM form) {
    // override if you want
  }

  /**
   * UPDATE_FORM 을 이용해 엔티티를 조회, 수정, 저장하고 VIEW 를 반환
   * 실제 DB 처리된다.
   * 트랜잭션 처리를 위해 @Transactional(rollbackFor = ErrorTypeException.class) 어노테이션을 붙여준다.
   * @param form UpdateForm
   * @return View
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default VIEW update(UPDATE_FORM form) throws SERVICE_EXCEPTION {
    ENTITY entity = updateAndSave(form);
    VIEW view = getView(entity, form.getViewType() == null ? EntityViewType.DETAIL : form.getViewType());
    logEntityUpdateRevision(entity, form, view);
    return view;
  }

  /**
   * UPDATE_FORM 을 이용해 엔티티를 조회, 수정, 저장하고 ENTITY 를 반환
   * @param form UpdateForm
   * @return Entity
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default ENTITY updateAndSave(UPDATE_FORM form) throws SERVICE_EXCEPTION {
    ENTITY entity = updateEntity(findEntityById(form.getId()), form);

    overrideUpdate(entity, form);

    checkAdditionalPermission(RevisionType.UPDATE, entity, form);

    entity = save(entity);
    return postUpdate(entity, form);
  }

  default void overrideUpdate(ENTITY entity, UPDATE_FORM form) {
    // override if you want
  }

  /**
   * Page<ENTITY> 결과 반환
   * SEARCH_FORM 을 이용해 CommonSearchContext 를 생성하고 Repository 에서 결과를 반환한다.
   * @param form SearchForm
   * @return PageResult<Entity>
   */
  default PageResult<ENTITY> getSearchResult(SEARCH_FORM form) throws SERVICE_EXCEPTION {
    if (DataProviderConfig.useHibernateSearch() && !form.isForceFetchFromDB() && !form.isShouldReturnEmpty()) {

      // HibernateSearch 로 인덱싱된 엔티티가 아닐 때는 null 을 반환하게 되어 있다.
      PageResult<ENTITY> result = getHibernateSearchResult(form);

      if (result != null) {
        // HibernateSearch 가 동작할 때만 해당 결과를 리턴한다.
        return result;
      }

    }

    SearchContext<ENTITY, SEARCH_FORM> context = getSearchContext(form);

    return PageResult.create(context.getEntityClass(), getRepository().findAll(context));
  }

  /**
   * SearchForm 으로 검색한 레코드의 수
   * @param form SearchForm
   * @return 레코드 수
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default long getSearchCount(SEARCH_FORM form) throws SERVICE_EXCEPTION{
    if (DataProviderConfig.useHibernateSearch() && !form.isForceFetchFromDB() && !form.isShouldReturnEmpty()) {
      return getHibernateSearchCount(form);
    }

    SearchContext<ENTITY, SEARCH_FORM> searchContext = getSearchContext(form);

    return getRepository().getCount(searchContext);
  }

  /**
   * DeleteAll 을 수행하기 전 custom validate 할 수 있게 만든 메소드
   * 실제 삭제될 대상을 정제할 때 사용한다.
   * @param list 삭제 대상 IDs
   * @return IDs
   * @throws SERVICE_EXCEPTION ErrorTypeServiceException
   */
  default DeleteForm<ID> preDeleteAll(DeleteForm<ID> list) throws SERVICE_EXCEPTION {
    return list;
  }

  /**
   * SearchForm 을 이용해 검색한 레코드의 수
   * @param searchForm SearchForm
   * @return ResponseData<검색 건 수>
   */
  ResponseData<Long> getQuerySearchCount(SEARCH_FORM searchForm);

  /**
   * 여러 엔티티를 한번에 삭제
   * @param deleteForm IdList
   * @param batch 배치 실행 여부
   * @return 삭제 된 레코드의 수
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default Integer deleteAll(DeleteForm<ID> deleteForm, Boolean batch) throws SERVICE_EXCEPTION {

    boolean result = false;

    try {

      deleteForm = preDeleteAll(deleteForm);

      if (deleteForm == null || deleteForm.isEmpty()) {
        return 0;
      }

      List<ENTITY> entities = getRepository().findAllById(deleteForm.getIds());
      if (CollectionUtils.isEmpty(entities)) {
        return 0;
      }

      checkAdditionalPermission(RevisionType.DELETE, entities.get(0), null);

      List<ID> ids = deleteForm.getIds();

      int totalCount = getCountById(ids);

      if (totalCount == 0) {
        return 0;
      }

      if (totalCount != ids.size()) {
        throw new RuntimeException("삭제할 데이터가 존재하지 않습니다. (totalCount : " + totalCount + ", ids.size() : " + ids.size() + ")");
      }

      // ENTITY 가 NeverDelete 를 상속한 경우에는 실제 삭제하지 않아야 한다.
      if (entities.get(0) instanceof NeverDelete) {
        for(ENTITY entity : entities) {
          ((NeverDelete) entity).setActive(false);
        }
        getRepository().saveAll(entities);
      } else {
        if (BooleanUtils.toBoolean(batch)) {
          getRepository().deleteAllByIdInBatch(deleteForm.getIds());
        } else {
          getRepository().deleteAllById(deleteForm.getIds());
        }
      }

      result = true;

      return totalCount;

    } catch (Exception e) {
      System.out.println("deleteAll error : " + e.getMessage());
      return 0;
    } finally {
      if (result) {
        for (ID id : deleteForm.getIds()) {
          logEntityDeleteRevisionById(deleteForm.getRevisionEntityName(), id);
        }
      }
    }

  }

  /**
   * deleteAll 의 편의성 메소드
   * @param list IDs
   * @return 삭제된 레코드 수
   */
  @Transactional(rollbackFor = ErrorTypeException.class)
  default Integer deleteAll(DeleteForm<ID> list) throws SERVICE_EXCEPTION {
    return deleteAll(list, true);
  }

  /**
   * ID 로 검색된 레코드 수
   * @param ids IdList
   * @return 검색된 수
   */
  default Integer getCountById(List<ID> ids) {
    Specification<ENTITY> specification = (root, query, criteriaBuilder) -> root.get("id").in(ids);
    long count = getRepository().count(specification);
    return NumberUtil.getInteger(count);
  }


  default void logEntityCreateRevision(ENTITY entity, CREATE_FORM form, VIEW view) {
    if (isUseLogEntityRevision()) {
      try {
        SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();
        if (authentication != null) {
          String userId = authentication.getUserId();
          String userName = authentication.getUserName();
          ResponseListExtensionManager.logEntityViewRevision(userId, userName, RevisionType.CREATE, StringUtil.toString(form.getRevisionEntityName(), getRevisionEntityName()), entity, form, view);
        }
      }catch (Exception e) {
        ExceptionUtil.printLog("Failed to logging revision during create" + e.getMessage(), LogLevel.DEBUG);
      }
    }
  }

  default void logEntityUpdateRevision(ENTITY entity, UPDATE_FORM form, VIEW view) {
    if (isUseLogEntityRevision()) {
      try {
        SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();
        if (authentication != null) {
          String userId = authentication.getUserId();
          String userName = authentication.getUserName();
          ResponseListExtensionManager.logEntityViewRevision(userId, userName, RevisionType.UPDATE, StringUtil.toString(form.getRevisionEntityName(), getRevisionEntityName()), entity, form, view);
        }
      }catch (Exception e) {
        ExceptionUtil.printLog("Failed to logging revision during update" + e.getMessage(), LogLevel.DEBUG);
      }
    }
  }

  default void logEntityDeleteRevision(String revisionEntityName, ENTITY entity) {
    if (isUseLogEntityRevision()) {
      try {
        SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();
        if (authentication != null) {
          String userId = authentication.getUserId();
          String userName = authentication.getUserName();
          ResponseListExtensionManager.logEntityViewRevision(userId, userName, RevisionType.DELETE, StringUtil.toString(revisionEntityName, getRevisionEntityName()), entity, null, null);
        }
      }catch (Exception e) {
        ExceptionUtil.printLog("Failed to logging revision during delete" + e.getMessage(), LogLevel.DEBUG);
      }
    }
  }

  default void logEntityDeleteRevisionById(String revisionEntityName, ID id) {
    if (isUseLogEntityRevision()) {
      try {
        SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();
        if (authentication != null) {
          String userId = authentication.getUserId();
          String userName = authentication.getUserName();
          ResponseListExtensionManager.logEntityDeleteRevisionById(userId, userName, revisionEntityName, id);
        }
      }catch (Exception e) {
        ExceptionUtil.printLog("Failed to logging revision during delete" + e.getMessage(), LogLevel.DEBUG);
      }
    }
  }

  default void checkAdditionalPermission(RevisionType revisionType, ENTITY entity, RevisionEntityWrapper<?> form) {
    // 이 확장 로직을 이용해 관리자 메뉴에 기반한 추가 퍼미션 체크를 할 수 있다.
    // RevisionEntityWrapper 의 revisionEntityName 을 이용한다.
    // 그런데 revisionEntityName 을 조작하면 이에 대한 대응은 어떻게 하지?
    // referrer 를 사용해야 하나?
    // 퍼미션 체크 오류가 발생할 때는 PlatformSecurityException (Runtime Exception)을 발생시킨다.
    if (isUseAdditionalEntityPermission()) {
      ResponseListExtensionManager.checkAdditionalPermission(revisionType, entity, form);
    }
  }


}
