/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.KoreanUtil;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(FullTextName.class)
@Getter
@Setter
public class FullTextNameImpl implements Serializable, EnhancedTemplate {

  @Column(name = "NAME")
  @GenericField(sortable = Sortable.YES)
  @IndexField
  @Description(name = "이름", comment = "이름")
  protected String name;

  @Column(name = "NAME_CONSONANT")
  @KeywordField
  @Description(name = "이름 초성", comment = "검색엔진을 사용하지 않는 경우에도 초성 검색이 가능하도록 하기 위해 사용")
  @Setter(AccessLevel.PRIVATE)
  protected String nameConsonant;

  @Column(name = "NAME_PHONEME")
  @KeywordField
  @Description(name = "이름 자소", comment = "검색엔진을 사용하지 않는 경우에도 자소 검색이 가능하도록 하기 위해 사용")
  @Setter(AccessLevel.PRIVATE)
  protected String namePhoneme;

  public void setName(String name) {
    this.name = name;
    this.nameConsonant = KoreanUtil.getConsonants(name);
    this.namePhoneme = KoreanUtil.getPhonemes(name);
  }

}
