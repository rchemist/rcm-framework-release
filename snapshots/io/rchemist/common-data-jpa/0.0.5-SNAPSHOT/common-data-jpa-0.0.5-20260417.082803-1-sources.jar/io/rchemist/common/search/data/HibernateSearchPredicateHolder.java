/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.search.engine.search.predicate.SearchPredicate;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class HibernateSearchPredicateHolder implements Serializable {

  public HibernateSearchPredicateHolder(
      ConditionOperatorType defaultOperator,
      List<SearchPredicate> mustPredicates,
      List<SearchPredicate> shouldPredicates) {
    this.defaultOperator = defaultOperator;
    this.mustPredicates = mustPredicates;
    this.shouldPredicates = shouldPredicates;
  }

  private ConditionOperatorType defaultOperator;
  private List<SearchPredicate> mustPredicates;
  private List<SearchPredicate> shouldPredicates;

  /**
   * SearchForm 의 ADD / OR 설정에 따라 operator 가 결정되는 방식
   * @param predicates
   * @return
   */
  public HibernateSearchPredicateHolder addPredicate(SearchPredicate... predicates){
    return addPredicate(null, predicates);
  }

  public HibernateSearchPredicateHolder addPredicate(ConditionOperatorType operator, SearchPredicate... predicates){
    if(ArrayUtils.isNotEmpty(predicates)){
      operator = operator == null ? defaultOperator : operator;
      List<SearchPredicate> list = Arrays.asList(predicates);
      if(operator.isMust()){
        mustPredicates.addAll(list);
      }else{
        shouldPredicates.addAll(list);
      }
    }
    return this;
  }

  public int getTotalPredicateCount(){
    return CollectionUtils.size(mustPredicates) + CollectionUtils.size(shouldPredicates);
  }

}
