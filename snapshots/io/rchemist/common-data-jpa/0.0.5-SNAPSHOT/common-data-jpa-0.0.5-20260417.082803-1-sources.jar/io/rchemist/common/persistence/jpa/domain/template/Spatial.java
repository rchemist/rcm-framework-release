/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;


import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.jpa.domain.embedded.Coordinates;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface Spatial<T> extends ClassTransformTarget {

  default double getLongitude(){
    throw new ClassTransformException();
  }
  default void setLongitude(Double longitude) {
    throw new ClassTransformException();
  }

  default double getLatitude() {
    throw new ClassTransformException();
  }
  default void setLatitude(Double latitude) {
    throw new ClassTransformException();
  }

  default Coordinates getCoordinates(){
    throw new ClassTransformException();
  }

  default void setCoordinates(Coordinates coordinate){
    throw new ClassTransformException();
  }

  default void setCoordinates(Double longitude, Double latitude){
    setCoordinates(new Coordinates(longitude, latitude));
  }

  default T withLongitude(Double longitude){
    setLongitude(longitude);
    return (T) this;
  }

  default T withLatitude(Double latitude){
    setLatitude(latitude);
    return (T) this;
  }

  default T withCoordinates(Coordinates coordinate){
    setCoordinates(coordinate);
    return (T) this;
  }


}
