/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.type.LimitTimePeriodType;
import java.time.LocalDateTime;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

public interface RewardCondition<T> {

  /**
   * 시간 제한이 있는지
   * @return
   */
  default boolean isTimeLimited() {
    throw new ClassTransformException();
  }
  default LimitTimePeriodType getLimitTimePeriodType() {
    throw new ClassTransformException();
  }
  default void setLimitTimePeriodType(LimitTimePeriodType limitTimePeriodType){
    throw new ClassTransformException();
  }

  /**
   * 시간 제한이 있다면 며칠(몇개월,몇년) 동안인지 null 이면 무한
   * @return
   */
  default Integer getLimitDifference() {
    throw new ClassTransformException();
  }
  default void setLimitDifference(Integer limitDifference) {
    throw new ClassTransformException();
  }

  default LocalDateTime getSpecificLimitDate(){
    throw new ClassTransformException();
  }

  default void setSpecificLimitDate(LocalDateTime specificLimitDate){
    throw new ClassTransformException();
  }


  /**
   * 지정한 날짜에 설정된 날짜 제한을 계산해 나온 날짜. reward 종료일이 된다.
   * @return
   */
  default LocalDateTime getLimitedAvailableUntil(LocalDateTime availableAt){
    throw new ClassTransformException();
  }

  /**
   * repeatable 이 false 이고, resetPeriodically 가 true 라면 반복 횟수를 집계하기 위한 기간의 시작일
   *
   * rewardQueue 의 기록을 뒤져 해당 고객이 시작일 ~ 현재 시각 사이에 보상 받은 기록이 없으면 보상이 가능하다는 뜻이 된다.
   *
   * @return
   */
  default LocalDateTime getPreviousPeriodStartedAt(){
    throw new ClassTransformException();
  }

  /**
   * 반복 적용이 가능한지 여부
   * @return
   */
  default boolean isRepeatable() {
    return BooleanUtils.toBoolean(getRepeatable());
  }
  default Boolean getRepeatable() {
    throw new ClassTransformException();
  }
  default void setRepeatable(Boolean repeatable) {
    throw new ClassTransformException();
  }

  /**
   * RewardCondition 의 limitPeriodType 이 THIS_MONTH 거나 THIS_YEAR 일 때
   * repeatable 이 false 라면 반복 여부를 계산할 때
   * 최초 1회 한정인지, 주기적으로 횟수를 리셋할지
   *
   * 예를 들어 limitPeriodType 이 THIS_MONTH 이고,
   * repeatable 이 false 이면서
   * 이 값이 true 라면
   * 반복 적용 여부를 결정할 때 해당 월의 적용 여부만 판단하게 될 것이다.
   *
   * @return
   */
  default boolean isResetPeriodically() {
    return BooleanUtils.toBoolean(getResetPeriodically());
  }
  default Boolean getResetPeriodically() {
    throw new ClassTransformException();
  }

  default void setResetPeriodically(Boolean resetPeriodically){
    throw new ClassTransformException();
  }

  default T withLimitTimePeriodType(LimitTimePeriodType limitTimePeriodType){
    setLimitTimePeriodType(limitTimePeriodType);
    return (T) this;
  }

  default T withLimitDifference(Integer limitDifference) {
    setLimitDifference(limitDifference);
    return (T) this;
  }

  default T withSpecificLimitDate(LocalDateTime specificLimitDate){
    setSpecificLimitDate(specificLimitDate);
    return (T) this;
  }

  default T withRepeatable(Boolean repeatable) {
    setRepeatable(repeatable);
    return (T) this;
  }

  default T withResetPeriodically(Boolean resetPeriodically){
    setResetPeriodically(resetPeriodically);
    return (T) this;
  }
}
