/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping.type;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.ExceptionUtil;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Objects;
import org.apache.commons.lang3.ClassUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.usertype.UserType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class MoneyConverter extends AbstractUserTypeConverter implements UserType {

  @Override
  public int getSqlType() {
    return StandardBasicTypes.BIG_DECIMAL.getSqlTypeCode();
  }

  @Override
  public Class returnedClass() {
    try {
      if(Money.class.isAssignableFrom(ClassUtils.getClass(className))) {
        return ClassUtils.getClass(className);
      }
    } catch (ClassNotFoundException e) {
      // ExceptionUtil.printStackTrace(e);
    }

    return Money.class;
  }

  @Override
  public boolean equals(Object x, Object y) throws HibernateException {
    if(x == null && y == null)
      return true;

    if(x == null && y != null)
      return false;

    if(x != null && y == null)
      return false;

    try{

      Money xMoney = (Money) x;
      Money yMoney = (Money) y;

      return xMoney.equals(yMoney);


    }catch (Exception e){
      return false;
    }

  }

  @Override
  public int hashCode(Object x) throws HibernateException {
    return Objects.hashCode(x);
  }

  /*

  String columnName = names[0];
    String columnValue = (String) rs.getObject( columnName );
    logger.debug("Result set column {0} value is {1}", columnName, columnValue);
    // return columnValue == null ? null :;

    Class c = returnedClass();
    Method m = null;
    try {
      m = c.getMethod("getInstance", String.class);
      Object result = m.invoke(null, columnValue);

      return result;
    } catch (NoSuchMethodException e) {
      ExceptionUtil.printStackTrace(e);
    } catch (IllegalAccessException e) {
      ExceptionUtil.printStackTrace(e);
    } catch (InvocationTargetException e) {
      ExceptionUtil.printStackTrace(e);
    }
   */

  @Override
  public Object nullSafeGet(ResultSet resultSet, int index, SharedSessionContractImplementor sharedSessionContractImplementor, Object o) throws HibernateException, SQLException {
    try {

      if(resultSet.wasNull())
        return null;

      return new Money(resultSet.getString(index));


    } catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
    }
    return null;
  }

  @Override
  public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session) throws HibernateException, SQLException {
    if(value != null) {
      st.setBigDecimal(index, ((Money) value).getAmount());
    } else {
      st.setNull(index, Types.BIGINT);
    }
  }


  @Override
  public Object deepCopy(Object value) throws HibernateException {
    return value;
  }

  @Override
  public boolean isMutable() {
    return true;
  }

  @Override
  public Serializable disassemble(Object value) throws HibernateException {
    return (Serializable) value;
  }

  @Override
  public Object assemble(Serializable cached, Object owner) throws HibernateException {
    return cached;
  }

  @Override
  public Object replace(Object original, Object target, Object owner) throws HibernateException {
    return original;
  }
}
