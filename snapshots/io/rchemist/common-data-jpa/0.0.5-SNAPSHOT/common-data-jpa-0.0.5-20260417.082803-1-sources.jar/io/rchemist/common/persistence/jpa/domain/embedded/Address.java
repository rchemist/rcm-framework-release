/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.embedded;

import com.google.common.base.MoreObjects;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.embedded.IAddress;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.Enumeration;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Address implements Serializable, IAddress {

  @Column(name = "COUNTRY")
  @IndexField
  @AdminField(name = "Address_Country", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=1000, fieldType = PresentationFieldType.ENUMERATION, enumeration = @Enumeration(values = "KOR"))
  @KeywordField
  @Description(name = "국가 코드", comment = "ISO 3166-1 국가 코드, ALPHA-3 코드")
  protected String country;         // ISO country code

  @Column(name = "STATE")
  @IndexField
  @AdminField(name = "Address_State", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=2000, fieldType = PresentationFieldType.STRING)
  @GenericField
  @Description(name = "주 코드", comment = "ISO 주 코드. 한국은 특별/광역시/도 등의 정보가 들어간다. ")
  protected String state;           // ISO state code. 특별/광역시/도

  @Column(name = "CITY")
  @IndexField
  @AdminField(name = "Address_City", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=3000, fieldType = PresentationFieldType.STRING)
  @GenericField
  @Description(name = "시", comment = "도시")
  protected String city;            // 도시

  @Column(name = "ADDRESS1")
  @AdminField(name = "Address_Address1", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=4000, fieldType = PresentationFieldType.STRING)
  @GenericField
  @Description(name = "주소 1", comment = "주소 1")
  protected String address1;        // 주소1

  @Column(name = "ADDRESS2")
  @AdminField(name = "Address_Address2", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=5000, fieldType = PresentationFieldType.STRING)
  @Description(name = "주소 2", comment = "주소 2")
  protected String address2;        // 주소 2

  @Column(name = "ADDRESS_DETAIL")
  @AdminField(name = "Address_AddressDetail", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=7000, fieldType = PresentationFieldType.STRING)
  @Description(name = "상세 주소", comment = "상세 주소, 사용자 입력 추가 주소. 111동 111호와 같은 정보가 들어감")
  protected String addressDetail;   // 사용자 입력 추가 주소

  @Column(name = "POSTAL_CODE")
  @AdminField(name = "Address_PostalCode", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=8000, fieldType = PresentationFieldType.STRING)
  @GenericField
  @Description(name = "우편 번호", comment = "우편 번호")
  protected String postalCode;

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("country", country)
        .add("state", state)
        .add("city", city)
        .add("address1", address1)
        .add("address2", address2)
        .add("addressDetail", addressDetail)
        .add("postalCode", postalCode)
        .toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Address)) {
      return false;
    }
    Address address = (Address) o;
    return Objects.equals(getCountry(), address.getCountry()) && Objects.equals(
        getState(), address.getState()) && Objects.equals(getCity(), address.getCity())
        && Objects.equals(getAddress1(), address.getAddress1()) && Objects.equals(
        getAddress2(), address.getAddress2()) && Objects.equals(getPostalCode(),
        address.getPostalCode());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getCountry(), getState(), getCity(), getAddress1(), getAddress2(),
        getPostalCode());
  }

  public Address withCountry(String country) {
    this.country = country;
    return this;
  }

  public Address withState(String state) {
    this.state = state;
    return this;
  }

  public Address withCity(String city) {
    this.city = city;
    return this;
  }

  public Address withAddress1(String address1) {
    this.address1 = address1;
    return this;
  }

  public Address withAddress2(String address2) {
    this.address2 = address2;
    return this;
  }

  public Address withAddressDetail(String addressDetail) {
    this.addressDetail = addressDetail;
    return this;
  }

  public Address withPostalCode(String postalCode) {
    this.postalCode = postalCode;
    return this;
  }
}
