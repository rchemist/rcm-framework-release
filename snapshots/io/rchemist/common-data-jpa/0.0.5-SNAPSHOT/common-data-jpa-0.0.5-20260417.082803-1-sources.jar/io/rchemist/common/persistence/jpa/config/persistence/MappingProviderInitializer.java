/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.persistence;

import io.rchemist.common.persistence.jpa.config.mapping.MappingProvider;
import jakarta.annotation.PostConstruct;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component("rcmMappingProviderInitializer")
public class MappingProviderInitializer {

  @Autowired(required = false)
  protected List<MappingProvider> mappingProviders;

  @Autowired(required = false)
  protected Set<String> redundantEntities;

  protected List<MappingProvider> staticMappingProviders;
  protected Set<String> staticRedundantEntities;

  @PostConstruct
  public void onLoad(){
    arrangeMappingProviders();
    arrangeRedundantEntities();
  }

  /**
   * PostConstruct 시점에 이 메소드를 호출해야 한다.
   */
  protected void arrangeMappingProviders(){
    if(CollectionUtils.isNotEmpty(mappingProviders)){
      staticMappingProviders = mappingProviders;
    }
  }

  /**
   * PostConstruct 시점에 이 메소드를 호출해야 한다.
   */
  protected void arrangeRedundantEntities(){
    if(CollectionUtils.isNotEmpty(redundantEntities)){
      staticRedundantEntities = redundantEntities;
    }else{
      staticRedundantEntities = new HashSet<>();
    }
  }

  public List<MappingProvider> getStaticMappingProviders(){
    return staticMappingProviders;
  }

  public Set<String> getStaticRedundantEntities(){
    return staticRedundantEntities;
  }

}
