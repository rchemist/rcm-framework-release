/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.persistence.type;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
public class PersistentInfo implements Serializable {

  public PersistentInfo(PersistentClass persistentClass) {
    this.persistentClass = persistentClass;

    // QuerySearch 에서 사용하기 위해 join 관련 정보를 따로 저장한다.
    // 어떤걸 join 으로 접근하고 어떤걸 get 으로 접근해야 하는지 쉽게 판단하기 위해서다.
    List<Property> properties = persistentClass.getProperties();

    for (Property property : CollectionUtils.emptyIfNull(properties)) {
      if(property.getType().isEntityType()){
        // many to one
        this.joinProperties.put(property.getName(), property.getType().getName());
      }else if(property.getType().isCollectionType()){
        // one to many collection

        String propertyClassName = StringUtils.substringBetween(property.getType().getName(), "(", ")");

        if(StringUtils.isNotEmpty(propertyClassName)
            && !StringUtils.equals(persistentClass.getClassName(), propertyClassName)){
          this.joinProperties.put(property.getName(), propertyClassName);
        }

      }else if(property.getType().isComponentType()){
        // component field
      }
    }

  }

  protected final PersistentClass persistentClass;

  protected String name;

  protected boolean customFieldEnabled;

  protected final List<String> translatables = new ArrayList<>();

  protected final List<String> webhookTargetTypes = new ArrayList<>();

  protected final Map<String, String> joinProperties = new HashMap<>();

}
