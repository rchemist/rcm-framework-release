/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.rchemist.common.persistence.jpa.EntityManagerSetting;
import jakarta.persistence.Cache;
import jakarta.persistence.EntityManager;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Component
@Configuration
@Slf4j
public class HibernateCacheValidator implements ApplicationListener<ApplicationReadyEvent> {

  protected final EntityManager[] em;

  public HibernateCacheValidator(EntityManager[] em) {
    this.em = em;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    EntityManagerSetting.getCachedProperties().forEach((s, properties) -> {
      if(StringUtils.equalsAnyIgnoreCase(properties.getProperty("hibernate.hbm2ddl.auto"), "create", "create-drop")){
        Arrays.stream(em).forEach(e -> {
          Cache cache = e.getEntityManagerFactory().getCache();
          cache.evictAll();
        });
        log.info("Hibernate 2nd cache has cleared due to hibernate.hbm2ddl.auto is create or create-drop.");
      }
    });
  }
}
