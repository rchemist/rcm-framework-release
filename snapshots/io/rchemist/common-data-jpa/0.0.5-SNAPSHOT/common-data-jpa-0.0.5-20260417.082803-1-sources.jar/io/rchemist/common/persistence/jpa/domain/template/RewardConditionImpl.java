/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.type.LimitTimePeriodType;
import jakarta.persistence.Column;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(RewardCondition.class)
@Getter
@Setter
public class RewardConditionImpl implements Serializable, EnhancedTemplate {

  @Column(name = "LIMITED_TIME_PERIOD_TYPE")
  /*// @AdminPresentation(friendlyName = "RewardConditionImpl_LimitTimePeriodType", order = 300, gridOrder = 300, prominent = true
      , group = // @AdminPresentationGroup(name = Group.RewardCondition.TYPE, order = Group.RewardCondition.ORDER)
    , fieldType = SupportedFieldType.BROADLEAF_ENUMERATION
      , broadleafEnumeration = "io.rchemist.common.util.type.LimitTimePeriodType"
      , defaultValue = "UNLIMITED"
      , tooltip = "RewardConditionImpl_LimitTimePeriodType_Tooltip"
      , requiredOverride = RequiredOverride.REQUIRED
      , derivedVisible = {
      @DerivedVisibleValue(value = "SPECIFIC_DAYS", derivedPropertyName = {"specificLimitDate"})
      , @DerivedVisibleValue(value = {"DAYS", "MONTHS", "YEARS", "HOURS"}, derivedPropertyName = {"limitDifference"})
      , @DerivedVisibleValue(value = {"THIS_YEAR", "THIS_MONTH"}, derivedPropertyName = {"resetPeriodically"})
  } , validationConfigurations = {
      @ValidationConfiguration(validationImplementation = "rcmConditionalRequiredValidator",
          configurationItems = {@ConfigurationItem(itemDetails = {
              @ConfigurationItemDetail(itemName = "DAYS:limitDifference", itemValue = "error.message.field.conditional.required.per.days")
              , @ConfigurationItemDetail(itemName = "MONTHS:limitDifference", itemValue = "error.message.field.conditional.required.per.months")
              , @ConfigurationItemDetail(itemName = "YEARS:limitDifference", itemValue = "error.message.field.conditional.required.yearly")
              , @ConfigurationItemDetail(itemName = "HOURS:limitDifference", itemValue = "error.message.field.conditional.required")
          })})
  }

  )*/
  @Description(name = "리워드 사용 기간 제한 유형", comment = "리워드 지급 시 언제까지 사용할 수 있을지에 대한 기간에 대한 유형. "
      + " SPECIFIC_DAYS 일 경우 specificLimitDate 에 사용자 지정 날짜를 입력할 수 있으며, "
      + " DAYS, MONTHS, YEARS, HOURS 일 경우 limitDifference 에 몇일(달, 년, 시간) 정보를 입력할 수 있으며, "
      + " THIS_YEAR, THIS_MONTH 일 경우 매월, 매년 새로 발급이 가능하게 하려면 설정resetPeriodically 값을 True, 최초 1회만 발급하게 하려면 False 로 설정해야 한다. LimitTimePeriodType 참고")
  protected String limitTimePeriodType;

  @Column(name = "LIMITED_DIFFERENCE")
  /*// @AdminPresentation(friendlyName = "RewardConditionImpl_LimitDifference", order = 400, dependentVisible = true
      , group = // @AdminPresentationGroup(name = Group.RewardCondition.TYPE, order = Group.RewardCondition.ORDER)
      , tooltip = "RewardConditionImpl_LimitDifference_Tooltip"
      , validationConfigurations = {@ValidationConfiguration(validationImplementation = "rcmIsPositiveNumberValidator")
      , @ValidationConfiguration(validationImplementation = "rcmIsPositiveNumberValidator")}
  )*/
  @Description(name = "기간 제한", comment = "리워드 사용 기간 제한(limitTimePeriodType) 이 DAYS, MONTHS, YEARS, HOURS 일 경우 몇일, 몇달, 몇년, 몇시간인지에 대한 정보")
  protected Integer limitDifference;

  @Column(name = "SPECIFIC_LIMITED_DATE")
  /*// @AdminPresentation(friendlyName = "RewardConditionImpl_SpecificLimitDate", order = 500
      , group = // @AdminPresentationGroup(name = Group.RewardCondition.TYPE, order = Group.RewardCondition.ORDER)
      , dependentVisible = true, tooltip = "RewardConditionImpl_SpecificLimitDate_Tooltip")*/
  @Description(name = "사용자 지정 리워드 사용 기간", comment = "리워드 사용 기간 제한(limitTimePeriodType)이 SPECIFIC_DAYS 일 경우 사용자가 지정한 날짜 정보")
  protected LocalDateTime specificLimitDate;

  @Column(name = "REPEATABLE")
  /*// @AdminPresentation(friendlyName = "RewardConditionImpl_Repeatable", tooltip = "RewardConditionImpl_Repeatable_Tooltip"
      , group = // @AdminPresentationGroup(name = Group.RewardCondition.TYPE, order = Group.RewardCondition.ORDER)
      , order = 600, gridOrder = 600, prominent = true, defaultValue = "false")*/
  @Description(name = "반복 적용 가능 여부", comment = "반복 적용이 가능한지 여부")
  protected Boolean repeatable = false;

  @Column(name = "IS_RESET_PERIODIC")
  /*// @AdminPresentation(friendlyName = "RewardConditionImpl_ResetPeriodically"
      , tooltip = "RewardConditionImpl_ResetPeriodically_Tooltip", order = 700
      , defaultValue = "true"
      , dependentVisible = true
      , group = // @AdminPresentationGroup(name = Group.RewardCondition.TYPE, order = Group.RewardCondition.ORDER)
  )*/
  @Description(name = "주기별 반복횟수 초기화 여부", comment = "리워드 사용 기간 제한(limitTimePeriodType) 이 THIS_YEAR, THIS_MONTH 일 경우 해당 기간 이후로 다시 발급을 가능하게 하려면 이 값을 True 설정해야한다. 즉, 매월, 매년 새로 발급이 가능하게 하려면 이 값을 True, 최초 1회만 발급하게 하려면 False 로 설정")
  protected Boolean resetPeriodically = true;

  /**
   * 지정한 날짜에 설정된 날짜 제한을 더한 날짜. reward 종료일이 된다.
   * @return
   */
  public LocalDateTime getLimitedAvailableUntil(LocalDateTime availableAt){

    // 시간 제약이 없다면 null 반환
    if(!isTimeLimited())
      return null;

    LimitTimePeriodType type = getLimitTimePeriodType();

    if(type.equals(LimitTimePeriodType.SPECIFIC_DAYS)){
      return type.getAvailableUntil(getSpecificLimitDate(), null);
    }

    Long difference = NumberUtil.getLong(limitDifference, null);
    return type.getAvailableUntil(availableAt, difference);

  }

  /**
   * repeatable 이 false 이고, resetPeriodically 가 true 라면 반복 횟수를 집계하기 위한 기간의 시작일
   *
   * rewardQueue 의 기록을 뒤져 해당 고객이 시작일 ~ 현재 시각 사이에 보상 받은 기록이 없으면 보상이 가능하다는 뜻이 된다.
   *
   * @return
   */
  public LocalDateTime getPreviousPeriodStartedAt(){
    LimitTimePeriodType type = getLimitTimePeriodType();

    if(getRepeatable())   // 반복이 true 면 최근 집계일을 구할 필요가 없다.
      return null;

    if(!getResetPeriodically() || !isTimeLimited() || (type != null && type.equals(LimitTimePeriodType.SPECIFIC_DAYS)))   // 주기적 반복이 아니라면 시스템 최초 일시로 - 이 값을 받는 쪽에서 LocalDateTime.MIN 에 대한 조건 처리를 해야 한다.
      return LocalDateTime.MIN;

    Long difference = NumberUtil.getLong(limitDifference, null);
    return type.getPreviousPeriodStartedAt(difference);
  }

  public boolean isTimeLimited() {
    return getLimitTimePeriodType() != null && !getLimitTimePeriodType().equals(
        LimitTimePeriodType.UNLIMITED);
  }


  public LimitTimePeriodType getLimitTimePeriodType() {
    return EnumTypeUtil.getEnumType(LimitTimePeriodType.class, limitTimePeriodType);
  }

  public void setLimitTimePeriodType(LimitTimePeriodType limitTimePeriodType){
    this.limitTimePeriodType = EnumTypeUtil.getType(limitTimePeriodType);
  }

  public Boolean getRepeatable() {
    return BooleanUtils.toBooleanDefaultIfNull(repeatable, false);
  }

  public Boolean getResetPeriodically() {
    return BooleanUtils.toBooleanDefaultIfNull(resetPeriodically, true);
  }

}
