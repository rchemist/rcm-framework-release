/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.data;

import io.rchemist.common.persistence.domain.template.presentation.HasAttributes;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.Data;

@Data
public class SimpleAttributeParser implements Serializable {

    private Set<String> removedKeys;

    private Map<String, String> addedAttributes;

    public SimpleAttributeParser addRemoveKeys(String... keys) {
        if (removedKeys == null) {
            removedKeys = new HashSet<>();
        }

        if (keys != null) {
            removedKeys.addAll(Set.of(keys));
        }
        return this;
    }

    public SimpleAttributeParser addAttributes(String key, String value) {
        if (addedAttributes == null) {
            // 기본적으로 map 이더라도 순서를 지켜 값을 내보낼 수 있어야 한다.
            addedAttributes = new java.util.LinkedHashMap<>();
        }
        addedAttributes.put(key, value);
        return this;
    }

    public SimpleAttributeParser withRemovedKeys(Set<String> removedKeys) {
        this.removedKeys = removedKeys;
        return this;
    }

    public SimpleAttributeParser withAddedAttributes(Map<String, String> addedAttributes) {
        this.addedAttributes = addedAttributes;
        return this;
    }

    public Map<String, String> parse(Map<String, String> previousAttributes) {

        if (previousAttributes == null) {
            return addedAttributes;
        }

        if (removedKeys != null) {
            removedKeys.forEach(previousAttributes::remove);
        }

        if (addedAttributes != null) {
            previousAttributes.putAll(addedAttributes);
        }

        return previousAttributes;
    }

    /**
     * DTO 가 SimpleAttributes 를 구현하고 있을 경우, modifiedFields 에 attribute 필드가 있는 경우 최신 정보를 리턴한다.
     * 만약 modifiedFields 에는 값이 있는데 SimpleAttributes 에 값이 없을 때는 해당 key 를 삭제한다는 뜻이다.
     *
     * @param dto Form DTO
     * @param previousAttributes 기존 저장되어 있는 Map 정보
     * @param attributePrefix modifiedFields 에 attribute 필드가 있는 경우, attributePrefix 를 제외한 나머지 부분이 attribute key 가 된다.
     * @param modifiedFields Form DTO 에서 수정된 필드 목록
     * @return
     */
    public static Map<String, String> getModifiedSimpleAttributes(Object dto, Map<String, String> previousAttributes, String attributePrefix, String... modifiedFields) {

        if (dto == null || modifiedFields == null || modifiedFields.length < 1)
            return previousAttributes;

        Class<?> dtoClass = dto.getClass();

        if (!HasAttributes.class.isAssignableFrom(dtoClass))
            return previousAttributes;

        HasAttributes entity = (HasAttributes) dto;

        String prefix = entity.getAttributePrefix(attributePrefix);

        Map<String, String> attributes = entity.getAttributes();

        SimpleAttributeParser parser = new SimpleAttributeParser();

        for (String fieldName : modifiedFields) {

            if (fieldName.startsWith(prefix)) {
                String attributeName = fieldName.substring(prefix.length());
                if (!attributes.containsKey(attributeName)) {
                    parser.addRemoveKeys(attributeName);
                } else {
                    parser.addAttributes(attributeName, attributes.get(attributeName));
                }
            }

        }

        return parser.parse(previousAttributes);
    }

}
