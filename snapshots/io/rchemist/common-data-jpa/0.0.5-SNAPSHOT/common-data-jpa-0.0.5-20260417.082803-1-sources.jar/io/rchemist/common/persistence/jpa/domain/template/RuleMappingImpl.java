/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(RuleMapping.class)
@Getter
@Setter
public class RuleMappingImpl implements Serializable, EnhancedTemplate {

  @Column(name = "RULE_KEY")
  @Description(name = "Rule 매핑 키", comment = "시스템에서 사용하는 Rule 매핑 키 값")
  protected String ruleKey;

  @Column(name = "RULE_EXPRESSION")
  @Text
  @Description(name = "룰 표현식", comment = "룰에 대한 표현식")
  protected String rule;

}
