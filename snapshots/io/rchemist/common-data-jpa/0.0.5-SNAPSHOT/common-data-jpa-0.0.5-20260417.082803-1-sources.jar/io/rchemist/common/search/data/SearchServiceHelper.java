/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.extension.SearchServiceExtensionManager;
import io.rchemist.common.web.request.PagingHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class SearchServiceHelper {

  private static SearchServiceExtensionManager extensionManager;

  protected static SearchServiceExtensionManager getExtensionManager(){
    if(extensionManager == null){
      extensionManager = ApplicationContextHolder.getBean(SearchServiceExtensionManager.MANAGER_NAME, SearchServiceExtensionManager.class);
    }
    return extensionManager;
  }

  public static HibernateSearchPredicateHolder addHibernateSearchPredicates(HibernateSearchContext<?, ?> context){
    ExtensionResultHolder<HibernateSearchPredicateHolder> erh = new ExtensionResultHolder<>();
    HibernateSearchPredicateHolder holder = context.createSearchPredicateResultHolder();
    erh.setResult(holder);

    ExtensionResultStatusType status = getExtensionManager().getProxy().addHibernateSearchPredicates(context, erh);

    return erh.getResult();

  }

  public static <T extends Serializable> Sort getPagingSortProperties(Class<T> entityClass, String[] sortProperties, String defaultSortProperty, Direction direction) {

    if(ArrayUtils.isNotEmpty(sortProperties)){
      List<String> sortList = new ArrayList<>(Arrays.asList(sortProperties));

      ExtensionResultHolder<List<String>> erh = new ExtensionResultHolder<>();
      erh.setResult(sortList);

      ExtensionResultStatusType status = getExtensionManager().getProxy().getPagingSortProperties(entityClass, erh, sortList);

      if(status.equals(ExtensionResultStatusType.NOT_HANDLED)){
        // 아무 것도 실행되지 않았다. 원래 값을 그냥 사용한다.
      }else{
        sortList = erh.getResult();

        if(CollectionUtils.isNotEmpty(sortList)){
          sortProperties = sortList.toArray(new String[0]);
        }else{
          sortProperties = null;
        }
      }
    }

    Sort sort = PagingHelper.getSort(sortProperties, defaultSortProperty, direction);

    return sort;

  }
}
