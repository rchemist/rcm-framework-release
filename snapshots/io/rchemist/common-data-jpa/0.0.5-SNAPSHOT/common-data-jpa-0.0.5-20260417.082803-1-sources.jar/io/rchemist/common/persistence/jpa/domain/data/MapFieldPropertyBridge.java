/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.data;

import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.search.engine.backend.document.DocumentElement;
import org.hibernate.search.engine.backend.document.IndexObjectFieldReference;
import org.hibernate.search.engine.backend.document.model.dsl.IndexSchemaElement;
import org.hibernate.search.engine.backend.document.model.dsl.IndexSchemaObjectField;
import org.hibernate.search.engine.backend.types.Projectable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.bridge.PropertyBridge;
import org.hibernate.search.mapper.pojo.bridge.binding.PropertyBindingContext;
import org.hibernate.search.mapper.pojo.bridge.mapping.programmatic.PropertyBinder;
import org.hibernate.search.mapper.pojo.bridge.runtime.PropertyBridgeWriteContext;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class MapFieldPropertyBridge implements PropertyBinder {

  @Override
  public void bind(PropertyBindingContext context) {

    log.info(String.valueOf(context.bridgedElement().properties()));

    String indexName = context.paramOptional("indexName")
        .orElseGet(() -> context.bridgedElement().name()).toString();

    context.dependencies().useRootOnly();
    IndexSchemaElement schemaElement = context.indexSchemaElement();
    IndexSchemaObjectField attributesField = schemaElement.objectField(indexName);
    attributesField.fieldTemplate(
        "attributeMapFieldTemplate",
        fieldTypeFactory -> fieldTypeFactory.asString()
            // .analyzer("default")
            .projectable(Projectable.YES)
            .sortable(Sortable.YES)
    );
    final AttributeMapFieldPropertyBridge bridge = new AttributeMapFieldPropertyBridge(attributesField.toReference());
    context.bridge(Map.class, bridge);

  }

  public static class AttributeMapFieldPropertyBridge implements PropertyBridge<Map> {

    private final IndexObjectFieldReference mapFieldReference;

    public AttributeMapFieldPropertyBridge(IndexObjectFieldReference mapFieldReference) {
      this.mapFieldReference = mapFieldReference;
    }

    @Override
    public void write(DocumentElement documentElement, Map map,
        PropertyBridgeWriteContext propertyBridgeWriteContext) {

      if (map == null) {
        map = new HashMap<String, String>();
      }

      DocumentElement mapField = documentElement.addObject(mapFieldReference);
      ((Map<String, String>) map).forEach(mapField::addValue);
    }
  }

}
