/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Slf4j
public class QueryParser<T> implements Serializable {

  private final CriteriaBuilder builder;

  private final Root<T> root;

  private final List<QueryConditionItem> conditionItems;

  private final Map<String, Join<T, ?>> joinPaths;

  private final Class<?> entityClass;

  private final String entityClassName;

  public QueryParser(Class<?> entityClass, CriteriaBuilder builder, Root<T> root, Map<String, Join<T, ?>> joinPaths, List<QueryConditionItem> items) {
    this.entityClass = entityClass;
    this.entityClassName = entityClass.getName();
    this.builder = builder;
    this.root = root;
    this.joinPaths = joinPaths;
    this.conditionItems = items;

    parse();

  }

  private void parse(){

  }

  public Predicate getPredicate(ConditionOperatorType operatorType){
    List<Predicate> predicate = new ArrayList<>();


    for(QueryConditionItem item : conditionItems){

      Predicate itemPredicate = getPredicate(operatorType, item);

      if(itemPredicate != null){
        predicate.add(itemPredicate);
      }

    }

    if(operatorType.isMust()){
      return builder.and(predicate.toArray(new Predicate[0]));
    }else{
      return builder.and(builder.or(predicate.toArray(new Predicate[0])));
    }

  }

  protected Predicate getPredicate(ConditionOperatorType parentOperatorType, QueryConditionItem item){
    if(item instanceof CombinedConditionItem combinedItem){

      ConditionOperatorType operatorType = combinedItem.getOperatorType();

      List<Predicate> predicates = new ArrayList<>();

      for(QueryConditionItem subItem : combinedItem.getSubConditions()){
        Predicate subPredicate = getPredicate(operatorType, subItem);

        if(subPredicate != null){
          predicates.add(subPredicate);
        }

      }

      if(!predicates.isEmpty()){
        if(operatorType.isMust()){
          return builder.and(predicates.toArray(new Predicate[0]));
        }else{
          return builder.or(predicates.toArray(new Predicate[0]));
        }
      }

      return null;

    }else{
      SingleConditionItem singleConditionItem = (SingleConditionItem) item;

      // 1. Path 생성 (JOIN 포함)
      Path path = getPath(root, singleConditionItem);
      if (path == null) {
        return null;
      }

      // 2. Predicate 생성
      Predicate predicate = singleConditionItem.getPredicate(builder, path);
      if (predicate == null) {
        return null;
      }

      // 3. 적용 위치 결정 및 적용
      return handlePredicateApplication(path, predicate, singleConditionItem);
    }
  }

  /**
   * Predicate를 ON절 또는 WHERE절에 적용하는 로직을 처리합니다.
   *
   * @param path 대상 경로
   * @param predicate 적용할 조건
   * @param conditionItem 조건 아이템
   * @return WHERE절에 적용할 Predicate (ON절에 적용된 경우 null 반환)
   */
  private Predicate handlePredicateApplication(Path path, Predicate predicate, SingleConditionItem conditionItem) {
    // applyOnClause가 true인 경우 ON절에 적용 시도
    if (conditionItem.isApplyOnClause()) {
      Join<?, ?> targetJoin = findApplicableJoin(path);

      if (targetJoin != null) {
        // ON절에 조건 적용
        targetJoin.on(predicate);
        return null; // WHERE절에는 추가하지 않음
      } else {
        // JOIN을 찾지 못한 경우 경고 로그 후 WHERE절에 적용
        // ApplyOnClause=true but no applicable JOIN found - applying to WHERE clause instead
      }
    }

    // WHERE절에 적용
    return predicate;
  }

  /**
   * 주어진 Path에서 ON절 조건을 적용할 수 있는 JOIN을 찾습니다.
   *
   * @param path 대상 경로
   * @return 적용 가능한 JOIN 객체, 없으면 null
   */
  private Join<?, ?> findApplicableJoin(Path path) {
    // 1. path의 직접 부모가 Join인 경우
    if (path.getParentPath() instanceof Join) {
      return (Join<?, ?>) path.getParentPath();
    }

    // 2. path 자체가 Join인 경우
    if (path instanceof Join) {
      return (Join<?, ?>) path;
    }

    // 3. path의 상위 경로들을 순회하여 Join 찾기
    Path currentPath = path;
    while (currentPath.getParentPath() != null) {
      if (currentPath.getParentPath() instanceof Join) {
        return (Join<?, ?>) currentPath.getParentPath();
      }
      currentPath = currentPath.getParentPath();
    }

    return null;
  }

  protected Path getPath(Root<T> root, SingleConditionItem conditionItem) {
    String propertyName = conditionItem.isJsonFilter()
        ? StringUtils.substringBefore(conditionItem.getPropertyName(), ".")
        : conditionItem.getPropertyName();

    JoinType joinType = conditionItem.getJoinType();

    // 기본값 처리
    if (StringUtils.isEmpty(propertyName)) {
      return root;
    }

    // 별칭 제거 (propertyName:actualPath 형태에서 actualPath 추출)
    propertyName = StringUtil.subStringAfter(propertyName, ":");

    // 단순 필드인 경우 (JOIN이 필요하지 않은 경우)
    if (!StringUtils.contains(propertyName, ".")) {
      return root.get(propertyName);
    }

    // JOIN이 필요한 복합 경로 처리
    return buildJoinPath(root, propertyName, joinType);
  }

  /**
   * 복합 경로에 대해 적절한 JOIN을 생성하고 최종 Path를 반환합니다.
   *
   * @param root 엔티티 루트
   * @param propertyName 복합 경로 (예: "parent.name")
   * @param joinType JOIN 타입
   * @return 최종 Path 객체
   */
  private Path buildJoinPath(Root<T> root, String propertyName, JoinType joinType) {
    // 기본 JOIN 타입 설정
    joinType = (joinType == null) ? JoinType.INNER : joinType;

    String[] pathParts = StringUtil.split(propertyName, ".").toArray(new String[0]);
    Path currentPath = root;
    // 조인 경로를 순회하면서 현재 엔티티 클래스를 추적한다.
    // 루트 엔티티에서 시작하여, 조인이 발생할 때마다 대상 엔티티 클래스로 갱신한다.
    String currentEntityClassName = entityClassName;

    for (int i = 0; i < pathParts.length; i++) {
      String pathPart = pathParts[i];

      if (i < pathParts.length - 1) {
        // 중간 경로: JOIN이 필요한지 확인 (현재 엔티티 기준으로 체크)
        boolean isJoinedProperty = PlatformSessionFactoryBuilderFactory.isJoinedProperty(currentEntityClassName, pathPart);

        if (isJoinedProperty) {
          currentPath = getOrCreateJoin(currentPath, pathPart, joinType);
          // 조인 대상 엔티티 클래스로 갱신
          currentEntityClassName = currentPath.getJavaType().getName();
        } else {
          // 일반 필드 접근
          currentPath = currentPath.get(pathPart);
        }
      } else {
        // 최종 필드: 단순 접근
        currentPath = currentPath.get(pathPart);
      }
    }

    return currentPath;
  }

  /**
   * 기존 JOIN을 재사용하거나 새로 생성합니다.
   *
   * @param parentPath 부모 경로
   * @param joinProperty JOIN할 속성명
   * @param joinType JOIN 타입
   * @return JOIN Path
   */
  private Path getOrCreateJoin(Path parentPath, String joinProperty, JoinType joinType) {
    String joinMapKey = generateJoinKey(parentPath, joinProperty, joinType);

    // 기존 JOIN 재사용
    if (joinPaths.containsKey(joinMapKey)) {
      return joinPaths.get(joinMapKey);
    }

    // 새로운 JOIN 생성
    Join<?, ?> join;
    if (parentPath instanceof Root) {
      join = ((Root<?>) parentPath).join(joinProperty, joinType);
    } else if (parentPath instanceof Join) {
      join = ((Join<?, ?>) parentPath).join(joinProperty, joinType);
    } else {
      throw new IllegalArgumentException("Cannot create join from path type: " + parentPath.getClass());
    }

    // JOIN 캐시에 저장
    joinPaths.put(joinMapKey, (Join<T, ?>) join);

    // Created JOIN for property with specified type

    return join;
  }

  /**
   * JOIN 캐시 키를 생성합니다.
   *
   * @param parentPath 부모 경로
   * @param joinProperty JOIN할 속성명
   * @param joinType JOIN 타입
   * @return 캐시 키
   */
  private String generateJoinKey(Path parentPath, String joinProperty, JoinType joinType) {
    String parentAlias = (parentPath instanceof Root) ? "root" : parentPath.getAlias();
    return String.format("%s.%s||%s", parentAlias, joinProperty, joinType.name());
  }


}
