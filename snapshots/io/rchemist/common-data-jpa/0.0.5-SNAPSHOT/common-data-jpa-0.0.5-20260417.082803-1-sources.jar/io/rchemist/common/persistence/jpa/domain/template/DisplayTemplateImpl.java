/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(DisplayTemplate.class)
@Getter
@Setter
public class DisplayTemplateImpl implements Serializable, EnhancedTemplate {

  @Column(name = "TEMPLATE_PATH")
  @KeywordField(sortable = Sortable.YES)
  @Description(name = "템플릿 Path", comment = "뷰에서 템플릿 Path를 재정의 할 때 필요한 정보를 찾기 위해 사용한다")
  /*// @AdminPresentation(friendlyName = "DisplayTemplate_TemplatePath"
      , group = // @AdminPresentationGroup(name = PresentationVariables.Group.View.TYPE, order = PresentationVariables.Group.View.ORDER)
      , order = 5000
      , requiredOverride = RequiredOverride.REQUIRED
      , tooltip = "DisplayTemplate_TemplatePath_Tooltip"
      , validationConfigurations = {@ValidationConfiguration(validationImplementation = "rcmTemplatePathPropertyValidator")}
  )*/
  protected String templatePath;

}
