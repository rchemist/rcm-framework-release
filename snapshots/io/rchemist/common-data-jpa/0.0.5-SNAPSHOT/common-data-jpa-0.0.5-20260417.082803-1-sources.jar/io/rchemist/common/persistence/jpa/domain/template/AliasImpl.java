/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.type.RegexType.Regex;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Index;
import org.hibernate.search.engine.backend.types.Searchable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(Alias.class)
@Getter
@Setter
public class AliasImpl implements EnhancedTemplate {

  @Column(name = "ALIAS_KEY")
  @KeywordField(searchable = Searchable.YES, sortable = Sortable.YES)
  @Index(name = "ALIAS_KEY_INDEX", columnNames = {"ALIAS_KEY"})    // Class Transform 을 이용한 @IndexField 를 사용해서는 안 된다.
  @AdminField(name = "AliasImpl_Alias", order = 110, fieldType = PresentationFieldType.STRING, required = true, helpText = "AliasImpl_Alias_HelpText", regexValidation = Regex.NUMBER_ENGLISH_EXT, errorMessage = "AliasImpl_Alias_ErrorMessage", modifiableType = ModifiableType.ADD_ONLY)
  @Description(name = "ALIAS KEY", comment = "이 엔티티의 Unique 한 KEY 를 지정할 때 사용한다")
  protected String alias;

}
