/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping.type;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.usertype.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class StringArrayTypeConverter implements UserType<String[]> {

  public static final String SPLIT_CODE = "|||";

  public static final StringArrayTypeConverter INSTANCE = new StringArrayTypeConverter();
  protected static Logger logger = LoggerFactory.getLogger(StringArrayTypeConverter.class);

  @Override
  public int getSqlType() {
    return StandardBasicTypes.STRING.getSqlTypeCode();
  }

  @Override
  public Class returnedClass() {
    return String[].class;
  }

  @Override
  public boolean equals(String[] x, String[] y) throws HibernateException {
    if(x == null && y == null)
      return true;

    if(x == null && y != null)
      return false;

    if(x != null && y == null)
      return false;

    try{
      return Arrays.equals(x, y);
    }catch (Exception e){
      return false;
    }
  }

  @Override
  public int hashCode(String[] x) throws HibernateException {
    return Objects.hashCode(x);
  }

  @Override
  public String[] nullSafeGet(ResultSet rs, int index, SharedSessionContractImplementor session, Object owner) throws HibernateException, SQLException {
    String columnValue = (String) rs.getObject( index );
    if(columnValue == null)
      return null;

    // 검색 편의를 위해 모든 string[] 값 앞뒤로 SPLIT_CODE 를 붙인다.
    columnValue = StringUtils.removeStart(columnValue, SPLIT_CODE);
    columnValue = StringUtils.removeEnd(columnValue, SPLIT_CODE);

    return StringUtils.split(columnValue, SPLIT_CODE);
  }

  @Override
  public void nullSafeSet(PreparedStatement st, String[] value, int index,
      SharedSessionContractImplementor sharedSessionContractImplementor) throws SQLException {
    if ( value == null ) {
      logger.debug("Binding null to parameter {0} ",index);
      st.setNull( index, Types.VARCHAR );
    }
    else {
      String stringValue = StringUtil.mergeWithSplitCode(SPLIT_CODE, value);

      // 검색 편의를 위해 모든 string[] 값 앞뒤로 SPLIT_CODE 를 붙인다.
      stringValue = SPLIT_CODE + stringValue + SPLIT_CODE;

      logger.debug("Binding {0} to parameter {1} ", stringValue, index);
      st.setString( index, stringValue );
    }
  }

  @Override
  public String[] deepCopy(String[] value) throws HibernateException {

    if(value == null){
      return null;
    }else{
      String[] origin;
      if(value.getClass().equals(String.class)){
        origin = value;
      }else{
        if(value.length == 0){
          return null;
        }
        origin = value;
      }

      String[] copied = new String[origin.length];
      System.arraycopy(origin, 0, copied, 0, origin.length);
      return copied;
    }
  }

  @Override
  public boolean isMutable() {
    return true;
  }

  @Override
  public Serializable disassemble(String[] strings) {
    return deepCopy(strings);
  }

  @Override
  public String[] assemble(Serializable cached, Object owner) throws HibernateException {
    return deepCopy((String[]) cached);
  }

  @Override
  public String[] replace(String[] original, String[] target, Object owner) {
    return deepCopy(original);
  }

}
