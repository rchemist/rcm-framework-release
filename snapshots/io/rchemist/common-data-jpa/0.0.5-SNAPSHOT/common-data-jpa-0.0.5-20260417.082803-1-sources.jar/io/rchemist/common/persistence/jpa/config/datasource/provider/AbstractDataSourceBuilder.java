/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.datasource.provider;

import io.rchemist.common.util.PropertyUtil;
import io.rchemist.common.util.StringUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public abstract class AbstractDataSourceBuilder implements DataSourceBuilder{

  protected Integer order = Integer.MAX_VALUE;

  private static class CachedSettings{
    static final Map<String, DataSource> CACHED_DATASOURCES = new HashMap<>();
  }
  public static Map<String, DataSource> getCachedSettings(){
    return CachedSettings.CACHED_DATASOURCES;
  }

  @Override
  public DataSource getDataSource(String dataSourceName, Map<String, Properties> properties) {
    Properties props = validate(properties.get(dataSourceName));

    if(getCachedSettings().containsKey(dataSourceName)){
      return getCachedSettings().get(dataSourceName);
    }else{
      DataSource dataSource = generateDataSource(dataSourceName, props);
      getCachedSettings().put(dataSourceName, dataSource);
      return dataSource;
    }
  }

  protected abstract DataSource generateDataSource(String dataSourceName, Properties props);

  protected abstract Properties validate(Properties properties);

  protected Object camelCase(Map.Entry<Object, Object> ent) {
    return StringUtil.toLowerCamelCase((String) ent.getKey(),"", "-");
  }

  /**
   * HikariCP와 관계 없는 AdditionalValue 만 따로 모아 ADDITIONAL_PROPERTIES 로 저장한다.
   * @param puName
   * @param propKey
   * @param value
   */
  protected void addAdditionalProperties(String puName, String propKey, Object value) {

    Properties properties;
    synchronized (ADDITIONAL_PROPERTIES){

      if(ADDITIONAL_PROPERTIES.containsKey(puName)){
        properties = ADDITIONAL_PROPERTIES.get(puName);
      }else{
        properties = new Properties();
      }

      properties.put(propKey, value);

      ADDITIONAL_PROPERTIES.put(puName, properties);
    }
  }

  @Override
  public Map<String, Properties> translateDataSourceProperties(Properties properties, String... prefixes) {
    if(properties != null && properties.size() > 0){
      if(canHandle(properties)){

        Map<String, Properties> parsedProps = PropertyUtil.separateByPrefix(prefixes[0], properties, prefixes);

        return transform(parsedProps);
      }
    }
    return null;
  }


  protected abstract Map<String, Properties> transform(Map<String, Properties> propsMap);


  protected abstract boolean canHandle(Properties properties);

  @Override
  public int getOrder() {
    return order;
  }

  @Override
  public int compareTo(DataSourceBuilder b){
    if(b.getOrder() > getOrder()){
      return -1;
    }else if(b.getOrder() == getOrder()){
      return 0;
    }else{
      return 1;
    }
  }





}
