/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.search.engine.backend.document.DocumentElement;
import org.hibernate.search.engine.backend.document.IndexFieldReference;
import org.hibernate.search.engine.backend.document.model.dsl.IndexSchemaElement;
import org.hibernate.search.engine.backend.types.Aggregable;
import org.hibernate.search.engine.backend.types.Projectable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.bridge.PropertyBridge;
import org.hibernate.search.mapper.pojo.bridge.binding.PropertyBindingContext;
import org.hibernate.search.mapper.pojo.bridge.mapping.programmatic.PropertyBinder;
import org.hibernate.search.mapper.pojo.bridge.runtime.PropertyBridgeWriteContext;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
public class StringListFieldPropertyBridge implements PropertyBinder {

  @Override
  public void bind(PropertyBindingContext context) {

    log.info(String.valueOf(context.bridgedElement().properties()));

    String indexName = context.paramOptional("indexName")
        .orElseGet(() -> context.bridgedElement().name()).toString();

    context.dependencies().useRootOnly();
    IndexSchemaElement schemaElement = context.indexSchemaElement();

    IndexFieldReference reference = schemaElement.field(indexName,
        context.typeFactory()
            .asString()
            .projectable(Projectable.YES)
            .sortable(Sortable.YES)
            .aggregable(Aggregable.YES)
            .toIndexFieldType())
        .multiValued()
        .toReference();

    final StringListFieldMappingPropertyBridge bridge = new StringListFieldMappingPropertyBridge(
        reference
    );
    context.bridge(List.class, bridge);

  }

  public static class StringListFieldMappingPropertyBridge implements PropertyBridge<List> {

    private final IndexFieldReference stringIndexFieldReference;


    public StringListFieldMappingPropertyBridge(IndexFieldReference stringIndexFieldReference) {
      this.stringIndexFieldReference = stringIndexFieldReference;
    }

    @Override
    public void write(DocumentElement documentElement, List list,
        PropertyBridgeWriteContext propertyBridgeWriteContext) {

      if (list == null || CollectionUtils.isEmpty(list)) {
        return;
      }

      List<String> values = new ArrayList<>(list);
      Collections.sort(values);

      for (String value : values) {
        documentElement.addValue(stringIndexFieldReference, value);
      }

    }
  }

}
