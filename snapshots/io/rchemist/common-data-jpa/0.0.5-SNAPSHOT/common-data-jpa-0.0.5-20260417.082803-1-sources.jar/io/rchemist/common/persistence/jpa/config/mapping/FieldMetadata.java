/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping;

import java.util.HashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * 
 * Holds metadata about a field including its type and annotations
 **/
@Getter
@Setter
public class FieldMetadata {
  private Class<?> fieldType;
  private Set<String> annotationNames = new HashSet<>();
  
  public FieldMetadata(Class<?> fieldType) {
    this.fieldType = fieldType;
  }
  
  public void addAnnotation(String annotationName) {
    this.annotationNames.add(annotationName);
  }
  
  public boolean hasAnnotation(String annotationName) {
    return annotationNames.contains(annotationName);
  }
}