/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.rchemist.common.persistence.jpa.domain.data.OrderedMapWrapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * 
 * JPA AttributeConverter for Map<String, String> that preserves insertion order
 * using OrderedMapWrapper to properly detect order changes for dirty checking
 **/
@Converter(autoApply = false)
public class OrderedMapAttributeConverter implements AttributeConverter<Map<String, String>, String> {

  private static final Logger log = LoggerFactory.getLogger(OrderedMapAttributeConverter.class);
  private static final ObjectMapper objectMapper = new ObjectMapper();
  private static final TypeReference<LinkedHashMap<String, String>> TYPE_REF = 
      new TypeReference<LinkedHashMap<String, String>>() {};

  @Override
  public String convertToDatabaseColumn(Map<String, String> attribute) {
    if (attribute == null || attribute.isEmpty()) {
      return null;
    }
    
    try {
      return objectMapper.writeValueAsString(attribute);
    } catch (JsonProcessingException e) {
      log.error("Failed to serialize Map to JSON", e);
      return null;
    }
  }

  @Override
  public Map<String, String> convertToEntityAttribute(String dbData) {
    if (dbData == null || dbData.isEmpty()) {
      return new OrderedMapWrapper();
    }
    
    try {
      LinkedHashMap<String, String> map = objectMapper.readValue(dbData, TYPE_REF);
      return new OrderedMapWrapper(map);
    } catch (IOException e) {
      log.error("Failed to deserialize JSON to LinkedHashMap: {}", dbData, e);
      return new OrderedMapWrapper();
    }
  }
}