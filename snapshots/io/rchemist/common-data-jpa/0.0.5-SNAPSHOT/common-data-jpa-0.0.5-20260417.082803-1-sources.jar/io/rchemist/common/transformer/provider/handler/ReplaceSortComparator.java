/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.provider.handler;

import io.rchemist.common.persistence.jpa.config.mapping.dto.RelationMappingDTO;
import io.rchemist.common.transformer.dto.TransformResult;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.ClassMemberValue;
import org.hibernate.annotations.SortComparator;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Component
public class ReplaceSortComparator extends AbstractReplaceMappingHandler {

  @Override
  protected boolean canHandle(TransformResult result, RelationMappingDTO dto, Annotation annotation) {
    return annotation.getTypeName().equals(SortComparator.class.getName());
  }

  @Override
  protected Annotation copyNewAnnotation(TransformResult result, RelationMappingDTO dto, Annotation annotation, Annotation newAnno, String valueName) {

    if (valueName.equals("value") && dto.hasSortComparator()) {
      newAnno.addMemberValue(valueName, new ClassMemberValue(dto.getSortComparator(), result.getConstPool()));
    } else {
      newAnno.addMemberValue(valueName, annotation.getMemberValue(valueName));
    }

    return newAnno;
  }


}
