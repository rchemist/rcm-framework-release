/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.multitenant;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.jpa.domain.template.AuditCreated;
import io.rchemist.common.persistence.jpa.domain.template.AuditUpdated;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.persistence.jpa.extension.CatalogAwareQueryExtensionHandler;
import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionHandler;
import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionManager;
import io.rchemist.common.persistence.jpa.extension.SiteAwareQueryExtensionHandler;
import io.rchemist.common.persistence.jpa.extension.TenantAliasQueryExtensionHandler;
import io.rchemist.common.persistence.jpa.persistence.RegisterEntityBean;
import io.rchemist.common.persistence.multitenant.TenantInformation;
import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.dto.QueryConditionDTO;
import io.rchemist.common.persistence.query.dto.SortField;
import io.rchemist.common.persistence.query.dto.SubCollectionStructure;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.data.VersionDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.LockModeType;
import jakarta.persistence.Query;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaDelete;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.CriteriaUpdate;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Selection;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.jpa.QueryHints;
import org.hibernate.query.sqm.tree.domain.SqmBasicValuedSimplePath;
import org.hibernate.query.sqm.tree.predicate.SqmJunctionPredicate;
import org.hibernate.query.sqm.tree.predicate.SqmNullnessPredicate;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class PlatformEntityManager extends EntityManagerWrapper implements ApplicationListener<ApplicationReadyEvent> {

  protected final PlatformEntityExtensionManager extensionManager;

  protected final RegisterEntityBean registerEntityBean;

  protected final List<PlatformEntityExtensionHandler> queryExtensionHandlers;

  private EntityManagerFactory entityManagerFactory;

  PlatformEntityManager(
      EntityManager em,
      PlatformEntityExtensionManager extensionManager,
    RegisterEntityBean registerEntityBean, List<PlatformEntityExtensionHandler> queryExtensionHandlers
      ) {
    super(em);
    this.extensionManager = extensionManager;
    this.registerEntityBean = registerEntityBean;
    this.queryExtensionHandlers = queryExtensionHandlers;

    entityManagerFactory = em.getEntityManagerFactory();
  }


  @Override
  public void persist(Object entity) {
    ExtensionResultHolder<Object> erh = new ExtensionResultHolder<>().withResult(entity);

    ExtensionResultStatusType statusType = extensionManager.getProxy().prePersist(erh, em);

    if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
      entity = erh.getResult();
    }

    em.persist(entity);

    extensionManager.getProxy().postPersist(em, entity);
  }

  @Override
  public <T> T merge(T entity) {
    ExtensionResultHolder<Object> erh = new ExtensionResultHolder<>().withResult(entity);
    ExtensionResultStatusType statusType = extensionManager.getProxy().preMerge(erh, em);
    if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
      entity = (T) erh.getResult();
    }
    entity = super.merge(entity);
    extensionManager.getProxy().postMerge(em, entity);
    return entity;
  }

  @Override
  public void remove(Object entity) {
    ExtensionResultHolder<Object> erh = new ExtensionResultHolder<>().withResult(entity);
    ExtensionResultStatusType statusType = extensionManager.getProxy().preRemove(erh, em);
    if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
      entity = erh.getResult();
    }
    super.remove(entity);
    extensionManager.getProxy().postRemove(em, entity);
  }

  @Override
  public <T> T find(Class<T> entityClass, Object primaryKey) {
    T entity = super.find(entityClass, primaryKey);
    return checkTenantAlias(entity);
  }

  @Override
  public <T> T find(Class<T> entityClass, Object primaryKey, Map<String, Object> properties) {
    T entity = super.find(entityClass, primaryKey, properties);
    return checkTenantAlias(entity);
  }

  @Override
  public <T> T find(Class<T> entityClass, Object primaryKey, LockModeType lockMode) {
    T entity = super.find(entityClass, primaryKey, lockMode);
    return checkTenantAlias(entity);
  }

  @Override
  public <T> T find(Class<T> entityClass, Object primaryKey, LockModeType lockMode, Map<String, Object> properties) {
    T entity = super.find(entityClass, primaryKey, lockMode, properties);
    return checkTenantAlias(entity);
  }

  @Override
  public <T> T getReference(Class<T> entityClass, Object primaryKey) {
    T entity = super.getReference(entityClass, primaryKey);
    return checkTenantAlias(entity);
  }

  @Override
  public Query createQuery(String qlString) {
    return super.createQuery(qlString);
  }

  @Override
  public <T> TypedQuery<T> createQuery(CriteriaQuery<T> criteriaQuery) {

    Set<Class<? extends PlatformEntityExtensionHandler>> skippingHandlers = getSkippingExecuteHandlers(criteriaQuery.getRestriction());

    boolean shouldExecute = (CollectionUtils.isEmpty(queryExtensionHandlers) || skippingHandlers.size() != queryExtensionHandlers.size());

    if(shouldExecute){
      Root<?> root = criteriaQuery.getRoots().stream().findFirst().get();
      Class<?> rootClass = root.getJavaType();

      CriteriaBuilder builder = super.getCriteriaBuilder();

      List<Predicate> predicates = new ArrayList<>();
      if(criteriaQuery.getRestriction() != null){
        predicates.add(criteriaQuery.getRestriction());
      }

      ExtensionResultHolder<List<Predicate>> erh = new ExtensionResultHolder().withResult(predicates);
      ExtensionResultStatusType statusType = extensionManager.getProxy().resolveAdditionalPredicates(erh, skippingHandlers, builder, root, rootClass);

      if(!statusType.equals(ExtensionResultStatusType.NOT_HANDLED)){
        predicates = erh.getResult();
        criteriaQuery.where(predicates.toArray(new Predicate[predicates.size()]));
      }
    }

    TypedQuery<T> query = super.createQuery(criteriaQuery);
    return query;
  }

  @Override
  public Query createQuery(CriteriaUpdate updateQuery) {
    return super.createQuery(updateQuery);
  }

  @Override
  public Query createQuery(CriteriaDelete deleteQuery) {
    return super.createQuery(deleteQuery);
  }

  @Override
  public <T> TypedQuery<T> createQuery(String qlString, Class<T> resultClass) {
    return super.createQuery(qlString, resultClass);
  }

  @Override
  public Query createNamedQuery(String name) {
    return super.createNamedQuery(name);
  }

  @Override
  public <T> TypedQuery<T> createNamedQuery(String name, Class<T> resultClass) {
    return super.createNamedQuery(name, resultClass);
  }

  @Override
  public Query createNativeQuery(String sqlString) {
    return super.createNativeQuery(sqlString);
  }

  @Override
  public Query createNativeQuery(String sqlString, Class resultClass) {
    return super.createNativeQuery(sqlString, resultClass);
  }

  @Override
  public Query createNativeQuery(String sqlString, String resultSetMapping) {
    return super.createNativeQuery(sqlString, resultSetMapping);
  }

  @Override
  public StoredProcedureQuery createNamedStoredProcedureQuery(String name) {
    return super.createNamedStoredProcedureQuery(name);
  }

  @Override
  public StoredProcedureQuery createStoredProcedureQuery(String procedureName) {
    return super.createStoredProcedureQuery(procedureName);
  }

  @Override
  public StoredProcedureQuery createStoredProcedureQuery(String procedureName, Class... resultClasses) {
    return super.createStoredProcedureQuery(procedureName, resultClasses);
  }

  @Override
  public StoredProcedureQuery createStoredProcedureQuery(String procedureName, String... resultSetMappings) {
    return super.createStoredProcedureQuery(procedureName, resultSetMappings);
  }

  /**
   *
   * @param predicate
   * @return
   */
  private Set<Class<? extends PlatformEntityExtensionHandler>> getSkippingExecuteHandlers(Predicate predicate) {
    Set<Class<? extends PlatformEntityExtensionHandler>> handlers = new HashSet<>();
    try{
      if(predicate.getExpressions() != null){
        for(Expression expression : CollectionUtils.emptyIfNull(predicate.getExpressions())){
          handlers = getSkippingExecuteHandlers(expression, handlers);
        }
      }
    }catch(Exception e){
      // nothing to do;
    }
    return handlers;
  }

  private Set<Class<? extends PlatformEntityExtensionHandler>> getSkippingExecuteHandlers(Expression expression, Set<Class<? extends PlatformEntityExtensionHandler>> handlers){

    if(expression instanceof SqmJunctionPredicate){
      for(Expression subExpression : CollectionUtils.emptyIfNull(((SqmJunctionPredicate) expression).getExpressions())){
        return getSkippingExecuteHandlers(subExpression, handlers);
      }
    }else{

      if(expression instanceof SqmNullnessPredicate){

        SqmNullnessPredicate e = (SqmNullnessPredicate) expression;

        if(e.getExpression() instanceof SqmBasicValuedSimplePath<?>){
          String propertyName = ((SqmBasicValuedSimplePath) e.getExpression()).getNavigablePath().getLocalName();

          if(propertyName.equals("siteAlias")){
            handlers.add(SiteAwareQueryExtensionHandler.class);
          } else if (propertyName.equals("catalogId")) {
            handlers.add(CatalogAwareQueryExtensionHandler.class);
          } else if (propertyName.equals("tenantAlias")) {
            handlers.add(TenantAliasQueryExtensionHandler.class);
          }

        }

      }

    }

    /*if(expression instanceof CompoundPredicate) {
      for (Expression subExpression : CollectionUtils.emptyIfNull(((CompoundPredicate) expression).getExpressions())) {
        return getSkippingExecuteHandlers(subExpression, handlers);
      }
    }else{
      if(expression instanceof NullnessPredicate){
        if(((NullnessPredicate)expression).getOperand() instanceof SingularAttributePath){
          SingularAttributePath path = (SingularAttributePath) ((NullnessPredicate)expression).getOperand();
          String propertyName = path.getAttribute().getName();
          if(propertyName.equals("siteAlias")){
            handlers.add(SiteAwareQueryExtensionHandler.class);
          } else if (propertyName.equals("catalogId")) {
            handlers.add(CatalogAwareQueryExtensionHandler.class);
          } else if (propertyName.equals("tenantAlias")) {
            handlers.add(TenantAwareQueryExtensionHandler.class);
          }
        }
      }
    }*/

    return handlers;
  }

  public <T> T save(T entity, boolean flush) {

    if(contains(entity)){
      entity = merge(entity);
    }else{
      persist(entity);
    }

    if(flush){
      flush();
    }

    return entity;
  }

  public <T> T create(Class<?> beanClass) {
    return create(beanClass.getName());
  }

  public <T> T create(String beanName) {
    return (T) registerEntityBean.createEntityInstance(beanName);
  }

  public <T> T create(String beanName, Class<?> resultClass) {
    return (T) registerEntityBean.createEntityInstance(beanName, resultClass);
  }

  public <T> List<T> getList(Class<?> implClass, List<QueryConditionDTO> conditions, List<SortField> sortFields, Integer maxResults) {

    if (maxResults == null)
      maxResults = 50;    // 최대 개수 고정

    if(CollectionUtils.isEmpty(conditions))
      return null;    // 조건 없이 모두 조회하게 하면 너무 위험하다.

    try {
      CriteriaBuilder builder = getCriteriaBuilder();
      CriteriaQuery criteria = builder.createQuery();
      Root root = criteria.from(implClass);

      criteria.select(root);


      List<Predicate> predicates = new ArrayList<>();
      for(QueryConditionDTO condition : conditions){

        String propertyName = condition.getPropertyName();
        QueryConditionType type = condition.getCondition();
        List<?> values = condition.getValues();

        if(StringUtils.isEmpty(propertyName) || CollectionUtils.isEmpty(values))
          continue;

        Path path = QueryHelper.getPath(root, propertyName);

        Predicate predicate = QueryHelper.getConditionPredicate(builder, type, path, values.get(0), values);
        predicates.add(predicate);

      }

      if(CollectionUtils.isEmpty(predicates))
        return null;

      criteria.where(predicates.toArray(new Predicate[0]));

      if(CollectionUtils.isNotEmpty(sortFields)){

        if(sortFields.size() > 1){
          sortFields.sort(new BeanComparator("order"));
        }
        List<Order> orders = new ArrayList<>();
        for(SortField sortField : sortFields){
          Path path = QueryHelper.getPath(root, sortField.getName());
          if(sortField.getType().equalsIgnoreCase(SortField.SORT_ASC)){
            orders.add(builder.asc(path));
          }else{
            orders.add(builder.desc(path));
          }
        }
        criteria.orderBy(orders.toArray(new Order[0]));
      }


      List result = createQuery(criteria).getResultList();

      return result;

    } catch (IllegalArgumentException e) {
      return null;
    }
  }

  public int getTotalCount(Class<?> implClass, List<QueryConditionDTO> conditions) {
    CriteriaBuilder builder = getCriteriaBuilder();
    CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
    Root root = criteria.from(implClass);

    criteria.select(builder.count(root));

    List<Predicate> predicates = new ArrayList<>();
    for(QueryConditionDTO condition : conditions){

      String propertyName = condition.getPropertyName();
      QueryConditionType type = condition.getCondition();
      List<?> values = condition.getValues();

      if(StringUtils.isEmpty(propertyName) || CollectionUtils.isEmpty(values))
        continue;

      Path path = QueryHelper.getPath(root, propertyName);

      Predicate predicate = QueryHelper.getConditionPredicate(builder, type, path, values.get(0), values);
      predicates.add(predicate);

    }

    criteria.where(predicates.toArray(new Predicate[0]));

    Long result = createQuery(criteria).getSingleResult();

    return (result == null) ? 0 : result.intValue();
  }

  public String getVersionCode(Class<?> implClass) {
    String versionCode;

    try {
      CriteriaBuilder builder = getCriteriaBuilder();
      CriteriaQuery<VersionDTO> criteria = builder.createQuery(VersionDTO.class);
      Root root = criteria.from(implClass);

      if(AuditUpdated.class.isAssignableFrom(implClass)){
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt"))
            , builder.max(root.get("updatedAt")));
      }else{
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt")));
      }

      versionCode = createQuery(criteria).getSingleResult().toString();
    } catch (IllegalArgumentException e) {
      versionCode = "0";
    }

    return versionCode;
  }

  public String getVersionCode(Class<?> implClass, Long id) {
    String versionCode;

    try {
      CriteriaBuilder builder = getCriteriaBuilder();
      CriteriaQuery<VersionDTO> criteria = builder.createQuery(VersionDTO.class);
      Root root = criteria.from(implClass);

      if(AuditUpdated.class.isAssignableFrom(implClass)){
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt"))
            , builder.max(root.get("updatedAt")));
      }else{
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt")));
      }

      criteria.where(builder.equal(root.get("id"), id));

      versionCode = createQuery(criteria).getSingleResult().toString();
    } catch (IllegalArgumentException e) {
      versionCode = (id == null) ? "0" : id.toString();
    }

    return versionCode;
  }

  public String getMergedVersionCode(Class<?> implClass, List<Long> ids) {
    String versionCode;

    try {
      CriteriaBuilder builder = getCriteriaBuilder();
      CriteriaQuery<VersionDTO> criteria = builder.createQuery(VersionDTO.class);
      Root root = criteria.from(implClass);

      if(AuditUpdated.class.isAssignableFrom(implClass)){
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt"))
            , builder.max(root.get("updatedAt")));
      }else{
        criteria.multiselect(builder.count(root.get("id")).as(Long.class)
            , builder.max(root.get("createdAt")));
      }

      criteria.where(root.get("id").in(ids));

      versionCode = createQuery(criteria).getSingleResult().toString();
    } catch (IllegalArgumentException e) {
      versionCode = (CollectionUtils.isEmpty(ids)) ? "0" : ids.toString();
    }

    return versionCode;
  }

  protected List<Selection> getMergedSelections(List<Selection> selections, CriteriaBuilder builder, Class<?> implClass, Path path){
    selections.add(builder.count(path.get("id").as(Long.class)));
    if(AuditCreated.class.isAssignableFrom(implClass) || AuditUpdated.class.isAssignableFrom(implClass)){
      if(AuditCreated.class.isAssignableFrom(implClass)){
        selections.add(builder.max(path.get("createdAt")));
      }
      if(AuditUpdated.class.isAssignableFrom(implClass)){
        selections.add(builder.max(path.get("updatedAt")));
      }
    }else{
      selections.add(builder.sum(path.get("id").as(Long.class)));
    }

    return selections;
  }

  protected String getVersionCodeFromArray(Object[] results){
    StringBuilder sb = new StringBuilder();

    for(Object obj : results){
      sb.append(obj).append("-");
    }

    return String.valueOf(sb.toString().hashCode());
  }

  public String getVersionCodeWithSubCollection(Class<?> implClass, Long id, SubCollectionStructure... subCollectionClasses) {
    String versionCode;

    LocalDateTime limitDate = LocalDateTime.now().minusDays(1l);

    try {
      CriteriaBuilder builder = getCriteriaBuilder();
      CriteriaQuery criteria = builder.createQuery();
      Root root = criteria.from(implClass);

      List<Selection> selections = new ArrayList<>();

      if(id != null){
        selections.add(root.get("id"));
      }

      selections = getMergedSelections(selections, builder, implClass, root);

      List<Predicate> predicates = new ArrayList<>();

      if(ArrayUtils.isNotEmpty(subCollectionClasses)){
        for(SubCollectionStructure structure : subCollectionClasses) {

          String joinPath = structure.getJoinPath();
          Class<?> subCollectionClass = structure.getSubCollectionClass();

          Join sub = root.join(joinPath, JoinType.LEFT);

          selections = getMergedSelections(selections, builder, subCollectionClass, sub);

          Predicate predicate = createLimitDatePredicate(builder, criteria, subCollectionClass, sub, limitDate);

          if(predicate != null){
            predicates.add(predicate);
          }
        }
      }

      criteria.multiselect(selections);

      if(id != null){
        predicates.add(builder.equal(root.get("id"), id));
      }


      Predicate predicate = createLimitDatePredicate(builder, criteria, implClass, root, limitDate);

      if(predicate != null){
        predicates.add(predicate);
      }

      if(CollectionUtils.isNotEmpty(predicates)){
        criteria.where(predicates.toArray(new Predicate[0]));
      }


      Query query = createQuery(criteria);
      query.setHint(QueryHints.HINT_CACHEABLE, false);
      List result = query.getResultList();

      if(result != null){
        Object[] results = (Object[]) result.get(0);
        versionCode = getVersionCodeFromArray(results);
        return versionCode;
      }

      throw new IllegalArgumentException();

    } catch (IllegalArgumentException e) {

      if(id == null)
        return "0";

      try{
        Object obj = super.find(implClass, id);
        if(obj instanceof AuditCreated){
          versionCode = ((AuditCreated) obj).getCreatedAt().toString();
        }else{
          versionCode = id.toString();
        }
      }catch(Exception ee){
        // skip
        versionCode = id.toString();
      }


    }

    return versionCode;
  }

  private Predicate createLimitDatePredicate(CriteriaBuilder builder, CriteriaQuery criteria, Class<?> implClass, Path path, LocalDateTime limitDate) {
    if(AuditCreated.class.isAssignableFrom(implClass) && AuditUpdated.class.isAssignableFrom(implClass)) {
      builder.and(builder.greaterThan(path.get("createdAt"), limitDate)
          , builder.greaterThan(path.get("updatedAt"), limitDate)
      );
    } else {
      if(AuditCreated.class.isAssignableFrom(implClass)){
        return builder.greaterThan(path.get("createdAt"), limitDate);
      }
      if(AuditUpdated.class.isAssignableFrom(implClass)){
        return builder.greaterThan(path.get("updatedAt"), limitDate);
      }
    }
    return null;
  }

  private Session getCurrentSession(){
    Session session;

    // 1. Try to get session
    session = (Session) em.getDelegate();
    if (session.isOpen()){
      return session;
    }

    // 2. Try to get session
    SessionFactory sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
    try{
      session = sessionFactory.getCurrentSession();
    }catch (HibernateException e){
      session = sessionFactory.openSession();
    }

    return session;
  }

  private <T> T checkTenantAlias(T entity) {
    TenantInformation information = MultiTenantJpaRepositoryFactoryBean.getTenantIdProvider().getTenantInformation();
    String tenantAlias = (information == null) ? null : information.getTenantAlias();
    if(StringUtils.isEmpty(tenantAlias))
      return entity;

    if (entity instanceof TenantAlias){
      if (!((TenantAlias<?>) entity).isAllowedTenant(tenantAlias)) {
        return null;
      }
    }

    return entity;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {

  }
}
