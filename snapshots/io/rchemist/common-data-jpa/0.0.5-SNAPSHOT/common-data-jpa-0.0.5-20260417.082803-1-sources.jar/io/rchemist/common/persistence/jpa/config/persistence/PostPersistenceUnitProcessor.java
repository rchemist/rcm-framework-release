/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.persistence;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.transformer.DefaultClassTransformManager;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.jpa.persistenceunit.MutablePersistenceUnitInfo;
import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
@Component
public class PostPersistenceUnitProcessor implements PersistenceUnitPostProcessor {

  @Value("${platform.config.common.post-persistence.packages:io.rchemist}")
  protected String[] packagesToScan;

  @Override
  public void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo pui) {
    Reflections reflections = new Reflections(packagesToScan);
    Set<Class<? extends Serializable>> classes = reflections.getSubTypesOf(Serializable.class);
    Set<Class<? extends EnumType>> enumClasses = reflections.getSubTypesOf(EnumType.class);

    initializeEnumTypeFields(enumClasses);

    for( Class<?> clazz : classes){
      if(!DefaultClassTransformManager.TRANSFORMED_CLASS_NAMES.contains(clazz.getName())){
        if(ClassTransformTarget.class.isAssignableFrom(clazz)){
          log.debug(clazz.getName() + " did not transformed.");
        }
      }
    }

    initializeEnumTypeFields(enumClasses);

    preLoadManagedEntityClasses(pui);
  }

  /**
   * Static final field 로 설정된 EnumType 들이 초기화가 되지 않을 때 null 로 인식되는 문제가 있다.
   * 시스템 부팅 시점에 EnumType Class 를 강제로 로딩해 static final 로 선언된 EnumType 들을 초기화 해 준다.
   * @param enumClasses
   */
  private static Map<String, String> enumTypes = new HashMap<>();
  private void initializeEnumTypeFields(Set<Class<? extends EnumType>> enumClasses) {

    boolean printMode = false;

    for(Class<? extends EnumType> type : enumClasses){
      Field[] fields = type.getDeclaredFields();
      for(Field field : fields){
        field.setAccessible(true);
        String name = field.getName();
        try {
          EnumType staticField = (EnumType)  field.get(type);//type.getField(name).get(null);

          if(printMode){
            if(StringUtils.startsWith(staticField.getMessageKey(), "global.")){
              if(!enumTypes.containsKey(staticField.getMessageKey())){
                log.debug(staticField.getMessageKey() + "=" + staticField.getDescription());
                enumTypes.put(staticField.getMessageKey(), staticField.getDescription());
              }
            }
          }

        } catch (Exception e) {
          // do nothing
        }
      }
    }
  }

  /**
   * Hibernate가 bootstrap 되기 전에 ClassTransformer 가 동작하도록
   * Managed Entity Class 를 모두 ClassLoader에 로딩한다.
   * @param pui
   */
  private void preLoadManagedEntityClasses(MutablePersistenceUnitInfo pui) {
    List<String> managedClassNames = new ArrayList<>();
    for (String managedClassName : pui.getManagedClassNames()) {
      if (!managedClassNames.contains(managedClassName)) {
        try {
          Class.forName(managedClassName, true, getClass().getClassLoader());
        } catch (ClassNotFoundException e) {
          e.printStackTrace();
        }
        managedClassNames.add(managedClassName);
      }
    }
  }


}
