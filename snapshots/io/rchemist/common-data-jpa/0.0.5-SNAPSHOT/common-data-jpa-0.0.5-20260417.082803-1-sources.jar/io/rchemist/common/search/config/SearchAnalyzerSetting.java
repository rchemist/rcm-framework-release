/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import io.rchemist.common.search.config.HibernateSearchConfig.HibernateSearchEnabled;
import lombok.Getter;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Conditional(HibernateSearchEnabled.class)
@Configuration
public class SearchAnalyzerSetting {

  public static final String FULLTEXT_ANALYZER = "FULLTEXT_ANALYZER";
  public static final String SIMPLE_STRING = "SIMPLE_STRING";

  @Getter
  private static String awsRegion;

  @Getter
  private static Boolean awsSigningEnabled;

  private static String synonymPath;

  private static String userDictPath;

  public static FullTextAnalyzerType fullTextAnalyzer;

  public static FullTextAnalyzerType getFullTextAnalyzer() {
    if(isUseAwsOpenSearch()){
      // AWS 오픈서치를 사용하는 경우에는 SEUNJEON 으로 고정한다.
      return FullTextAnalyzerType.SEUNJEON;
    }
    return fullTextAnalyzer;
  }

  @Value("${spring.data.elasticsearch.synonym-path:synonyms_ko.txt}")
  public void setSynonymPath(String synonymPath){
    SearchAnalyzerSetting.synonymPath = synonymPath;
  }

  @Value("${spring.data.elasticsearch.user-dict-path:userdict_ko.txt}")
  public void setUserDictPath(String userDictPath){
    SearchAnalyzerSetting.userDictPath = userDictPath;
  }

  @Value("${platform.config.search.fulltext-analyzer:NORI}")
  public void setFullTextAnalyzer(String fullTextAnalyzer){
    String mode = StringUtils.isNotEmpty(fullTextAnalyzer) ? fullTextAnalyzer : "NORI";
    try{
      SearchAnalyzerSetting.fullTextAnalyzer = FullTextAnalyzerType.valueOf(mode);
    }catch (Exception e){
      SearchAnalyzerSetting.fullTextAnalyzer = FullTextAnalyzerType.NORI;
    }
  }

  @Value("${hibernate.search.backend.aws.region:}")
  public void withAwsRegion(String awsRegion) {
    SearchAnalyzerSetting.awsRegion = awsRegion;
  }

  @Value("${hibernate.search.backend.signing.enabled:false}")
  public void withAwsSigningEnabled(Boolean awsSigningEnabled) {
    SearchAnalyzerSetting.awsSigningEnabled = awsSigningEnabled;
  }

  public static boolean isUseAwsOpenSearch(){
    return StringUtils.isNotEmpty(getAwsRegion()) && BooleanUtils.isTrue(getAwsSigningEnabled());
  }

  public static String getSynonymPath(){
    return SearchAnalyzerSetting.synonymPath;
  }

  public static String getUserDictPath(){
    return SearchAnalyzerSetting.userDictPath;
  }

}
