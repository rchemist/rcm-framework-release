/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * View 에서 Template path를 override할 때 필요한 정보를 찾기 위해 사용한다
 **/

public interface DisplayTemplate<T> extends ClassTransformTarget {

  default String getTemplatePath() {
    throw new ClassTransformException();
  }

  default void setTemplatePath(String templatePath) {
    throw new ClassTransformException();
  }

  default T withTemplatePath(String templatePath) {
    setTemplatePath(templatePath);
    return (T) this;
  }
}
