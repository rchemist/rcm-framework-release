/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.data.AuditDTO;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.jpa.domain.service.AuditUtil;
import io.rchemist.common.web.service.data.HasIdEntity;
import java.time.Instant;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface EssentialUUIDEntity<T> extends HasIdEntity<String>, AuditCreated<T>, AuditUpdated<T>,
    ClassTransformTarget {

  String getId();
  void setId(String id);

  @JsonIgnore
  default Instant getLastUpdated(){
    return (getUpdatedAt() != null) ? getUpdatedAt() : getCreatedAt();
  }

  @JsonIgnore
  default AuditDTO<?> getAudit(){
    return AuditUtil.create(this);
  }

  default T withId(String id) {
    setId(id);
    return (T) this;
  }

}
