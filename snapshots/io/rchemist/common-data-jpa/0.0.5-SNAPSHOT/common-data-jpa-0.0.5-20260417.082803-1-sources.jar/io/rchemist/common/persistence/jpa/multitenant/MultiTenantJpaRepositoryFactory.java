/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.multitenant;

import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionHandler;
import io.rchemist.common.persistence.jpa.extension.PlatformEntityExtensionManager;
import io.rchemist.common.persistence.jpa.persistence.RegisterEntityBean;
import jakarta.persistence.EntityManager;
import java.util.List;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;

class MultiTenantJpaRepositoryFactory extends JpaRepositoryFactory {
  MultiTenantJpaRepositoryFactory(EntityManager entityManager,
      PlatformEntityExtensionManager extensionManager,
    RegisterEntityBean registerEntityBean,
      List<PlatformEntityExtensionHandler> queryExtensionHandlers) {
    super(new PlatformEntityManager(entityManager, extensionManager, registerEntityBean,
      queryExtensionHandlers));
  }
}
