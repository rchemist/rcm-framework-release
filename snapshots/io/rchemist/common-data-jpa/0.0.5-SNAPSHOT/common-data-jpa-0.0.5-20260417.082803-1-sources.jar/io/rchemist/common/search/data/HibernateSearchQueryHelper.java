/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.StringUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.engine.search.predicate.SearchPredicate;
import org.hibernate.search.engine.search.predicate.dsl.BooleanPredicateClausesStep;
import org.hibernate.search.engine.search.predicate.dsl.SearchPredicateFactory;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class HibernateSearchQueryHelper {

  public static SearchPredicate predicate(SearchPredicateFactory factory, QueryConditionType conditionType, Object value, String... indexNames){

    if(ArrayUtils.isEmpty(indexNames))
      return null;

    if (conditionType.isNoValue()) {
      // null, not null

      switch (conditionType) {
        case NULL:{
          BooleanPredicateClausesStep<?> booleanJunction = factory.bool();
          for(String field : indexNames){
            booleanJunction.must(factory.exists().field(field));
          }

          return factory.matchAll().except(booleanJunction).toPredicate();
        }
        case NOT_NULL:{
          BooleanPredicateClausesStep<?> booleanJunction = factory.bool();
          for(String field : indexNames){
            booleanJunction.must(factory.exists().field(field));
          }

          return booleanJunction.toPredicate();
        }
      }

    } else {
      if (value == null) {
        return null;
      }
    }

    switch (conditionType){

      case EQUAL_IGNORECASE:    // case in sensitive 설정은 normalizer 를 이용한다.
      case EQUAL:{

        if(boolean.class.isAssignableFrom(value.getClass()) || Boolean.class.isAssignableFrom(value.getClass())){
          // value 가 Boolean 타입인 경우 EQUAL 은 true 거나 null 인 것
          BooleanPredicateClausesStep<?> booleanJunction = factory.bool();
          booleanJunction.should(factory.match().fields(indexNames).matching(true));

          BooleanPredicateClausesStep<?> subJunction = factory.bool();
          for(String indexName : indexNames){
            subJunction.should(factory.matchAll().except(factory.exists().field(indexName)));
          }

          booleanJunction.should(subJunction.toPredicate());

          return booleanJunction.toPredicate();

        }else{
          return factory.match().fields(indexNames).matching(value).toPredicate();
        }


      }
      case NOT_EQUAL:{
        return factory.bool( b -> factory
            .matchAll().except(
                factory.match().fields(indexNames).matching(value)
            )).toPredicate();
      }
      case IN:{
        BooleanPredicateClausesStep<?> booleanJunction = factory.bool();

        if (value == null)
          return factory.bool().toPredicate();

        for(Object val : getPluralValues(value)){
          booleanJunction.should(factory.match().fields(indexNames).matching(val));
        }

        return booleanJunction.toPredicate();
      }
      case NOT_IN:{
        BooleanPredicateClausesStep<?> booleanJunction = factory.bool();

        for(Object val : getPluralValues(value)){
          booleanJunction.mustNot(factory.match().fields(indexNames).matching(val));
        }

        return booleanJunction.toPredicate();
      }

      case END_WITH:
      case START_WITH:    // tokenizer 를 이용해야 한다.
      case LIKE:{

        if(!(value instanceof String)){
          return factory.match().fields(indexNames).matching(value).toPredicate();
        }

        if(StringUtils.contains(String.valueOf(value), " ")){
          // 공백으로 끊어서 loop
          BooleanPredicateClausesStep booleanJunction = factory.bool();
          for(String val : StringUtil.splitWithTrim(String.valueOf(value), " ", false)){
            if(val.length() > 1){
              // 복합 키워드 검색일 때는 2 글자 이상일 때만 like 검색어로 인정한다.
              booleanJunction.should(factory.wildcard().fields(indexNames).matching(getWildcardQueryString(val)));
            }
          }
          return booleanJunction.toPredicate();
        }

        if(StringUtils.isEmpty(String.valueOf(value)))
          return null;

        return factory.wildcard().fields(indexNames).matching(getWildcardQueryString(value)).toPredicate();
      }
      case NOT_END_WITH:
      case NOT_START_WITH:    // tokenizer 를 이용해야 한다.
      case NOT_LIKE:{
        if(StringUtils.isEmpty(String.valueOf(value)))
          return null;
        return factory.matchAll().except(factory.wildcard().fields().matching(getWildcardQueryString(value))).toPredicate();
      }
      case LESS_THAN:{
        return factory.range().fields(indexNames).lessThan(value).toPredicate();
      }
      case LESS_THAN_EQUAL:{
        return factory.range().fields(indexNames).atMost(value).toPredicate();
      }
      case GREATER:{
        return factory.range().fields(indexNames).greaterThan(value).toPredicate();
      }
      case GREATER_THAN_EQUAL:{
        return factory.range().fields(indexNames).atLeast(value).toPredicate();
      }
      case BETWEEN:{

        if (value == null)
          return factory.bool().toPredicate();

        List<Object> values = getPluralValues(value);
        if (values.size() == 1) {
          // value 가 하나 뿐이면 between 은 무의미하다.
          return factory.range().fields(indexNames).atLeast(value).toPredicate();
        }

        return factory.range().fields(indexNames).between(values.get(0), values.get(1)).toPredicate();
      }
      case NOT_BETWEEN:{

        if (value == null)
          return factory.bool().toPredicate();

        List<Object> values = getPluralValues(value);
        if (values.size() == 1) {
          // value 가 하나 뿐이면 between 은 무의미하다.
          return factory.range().fields(indexNames).atMost(value).toPredicate();
        }

        return factory.matchAll().except(factory.range().fields(indexNames).between(values.get(0), values.get(1))).toPredicate();
      }

      case ID_EQUAL:{
        return factory.id().matching(value).toPredicate();
      }

    }

    return factory.bool().toPredicate();

  }

  private static List<Object> getPluralValues(Object value) {
    List<Object> values;

    if (value instanceof Object[]) {
      // array ok
      values = Arrays.asList((Object[]) value);
    } else if (value instanceof Collection) {
      values = new ArrayList<>((Collection) value);
    } else {
      // value 가 하나 뿐이면 between 은 무의미하다.
      values = new ArrayList<>();
      values.add(value);
    }
    return values;
  }

  public static String getWildcardQueryString(Object query){
    return getWildcardQueryString(query, true);
  }

  public static String getWildcardQueryString(Object query, boolean bidirectional){
    if(bidirectional){
      return "*"+query+"*";
    }else{
      return query + "*";
    }
  }



}
