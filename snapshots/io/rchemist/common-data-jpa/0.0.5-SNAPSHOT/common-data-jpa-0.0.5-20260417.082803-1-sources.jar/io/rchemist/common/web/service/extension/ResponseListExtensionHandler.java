/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.RevisionEntityWrapper;
import io.rchemist.common.web.service.type.RevisionType;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotNull;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface ResponseListExtensionHandler extends ExtensionHandler {

  /**
   * 특정 ID 의 엔티티 캐시가 삭제되었을 때의 공통 로직
   * @param ids
   */
  default ExtensionResultStatusType clearEntityCache(Object... ids) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 검색 캐시가 삭제되었을 때의 공통 로직
   */
  default ExtensionResultStatusType clearSearchResultCache() {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * Entity 가 Create, Update, Delete 된 이후의 공통 로직
   * 각 ResponseEntityService 에도 PostUpdate 기능이 있지만 모든 ResponseEntityService 에서 공통으로 사용하는 확장 로직이 필요한 경우 이 메소드를 구현한다.
   * 예를 들어 Admin 에서 EntityRevision 을 백업한다든가 하는 기능을 여기서 담당할 수 있다.
   * 단, revisionType 이 DELETE 인 경우 - 삭제되는 시점의 데이터가 딱히 중요하지 않으므로 해당 ID 가 삭제됐다는 것만 확인하면 된다.
   * 따라서 entity 외에 form, view 는 null 이 된다.
   * 실제 Revision 구현 로직에서는 entityClassName 과 ID 를 가지고 삭제되기 전 마지막 저장된 정보를 조회한 후 필요한 처리를 할 수 있다.
   * @param userId 아이디
   * @param userName 이름
   * @param revisionType RevisionType CREATE, UPDATE, DELETE
   * @param revisionEntityName nullable
   * @param entity notnull
   * @param form nullable when delete
   * @param view nullable when delete
   */
  default ExtensionResultStatusType logEntityRevision(String userId, String userName, @NotNull RevisionType revisionType, @Nullable String revisionEntityName, @NotNull HasIdEntity<?> entity, @Nullable RevisionEntityWrapper<?> form, @Nullable HasIdEntity<?> view) {
    // revision 관리 핸들러에서 create, update, delete 시 revision 을 저장한다.
    return ExtensionResultStatusType.NOT_HANDLED;
  }


  /**
   * Batch delete 를 할 때 id list 만 가지고 삭제를 한다. 이때 Entity 를 가질 수 없으므로 별도의 메소드를 구현한다.
   * @param revisionEntityName nullable
   * @param id id
   * @return
   */
  default ExtensionResultStatusType logDeleteEntityRevisionById(String userId, String userName, String revisionEntityName, Object id) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * ResponseEntityService 를 사용하는 각 엔티티 서비스에서
   * 관리자도구에서 CUD 를 실행할 때 해당 엔티티 / 해당 메뉴에 대한 권한이 있는지 추가 체크하기 위해 사용한다.
   * AdminMenu 에 지정된 Permission 을 가지고 처리하면 되는데, 문제는 엔티티 클래스와 AdminMenu 가 1:1 로 매핑되지 않는다는 것이다.
   * 어떻게 해야 api 의 end point url 과 실제 entity class 간의 연결을 할 수 있게 할 것인가?
   * 하드코드로 role, permission 을 체크하면 쉽겠지만, 문제는 CMS 에서 가변적으로 메뉴 별 권한을 지정할 때 하드코드로는 처리할 수 없다.
   * 그렇다고 front 에서 넘겨 오는 revisionEntityName 만 믿고 있다가는 권한 없는 사용자의 조작으로 인한 침투를 막을 수 없다.
   * @param revisionType
   * @param entity
   * @param form
   * @return
   */
  default ExtensionResultStatusType checkAdditionalPermission(RevisionType revisionType, HasIdEntity<?> entity, @Nullable RevisionEntityWrapper<?> form) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
