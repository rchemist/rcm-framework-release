/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Manages JPA join creation and caching for QuerySpecification.
 * This class centralizes join logic and provides efficient caching
 * to prevent duplicate join creation.
 */
@Slf4j
@Getter
public class JoinManager<T extends Serializable> {
    
    private final Map<String, Join<T, ?>> joinCache = new LinkedHashMap<>();
    
    /**
     * Gets or creates a join for the specified path and join type.
     * Supports multi-level join paths (e.g., "user.profile.address").
     * 
     * @param root JPA root entity
     * @param path Join path (can be multi-level with dots)
     * @param joinType Type of join (INNER, LEFT, RIGHT, etc.)
     * @param <J> Target entity type
     * @return Join object for the specified path
     */
    @SuppressWarnings("unchecked")
    public <J> Join<T, J> getOrCreateJoin(Root<T> root, String path, JoinType joinType) {
        if (path == null || path.trim().isEmpty()) {
            throw new IllegalArgumentException("Join path cannot be null or empty");
        }
        
        String cacheKey = generateCacheKey(path, joinType);
        
        // Return cached join if available
        if (joinCache.containsKey(cacheKey)) {
            log.debug("Returning cached join for path: {}, joinType: {}", path, joinType);
            return (Join<T, J>) joinCache.get(cacheKey);
        }
        
        // Create new join
        Join<T, ?> join = createMultiLevelJoin(root, path, joinType);
        joinCache.put(cacheKey, join);
        
        log.debug("Created new join for path: {}, joinType: {}", path, joinType);
        return (Join<T, J>) join;
    }
    
    /**
     * Creates a multi-level join by splitting the path and creating joins iteratively.
     */
    private Join<T, ?> createMultiLevelJoin(Root<T> root, String path, JoinType joinType) {
        String[] pathElements = path.split("\\.");
        
        if (pathElements.length == 0) {
            throw new IllegalArgumentException("Invalid join path: " + path);
        }
        
        // Start with the first level join
        Join<T, ?> currentJoin = root.join(pathElements[0], joinType);
        
        // Create subsequent level joins
        for (int i = 1; i < pathElements.length; i++) {
            currentJoin = currentJoin.join(pathElements[i], joinType);
        }
        
        return currentJoin;
    }
    
    /**
     * Generates a cache key for the join.
     */
    private String generateCacheKey(String path, JoinType joinType) {
        return path + "||" + joinType.name();
    }
    
    /**
     * Checks if a join exists for the given path and join type.
     */
    public boolean hasJoin(String path, JoinType joinType) {
        String cacheKey = generateCacheKey(path, joinType);
        return joinCache.containsKey(cacheKey);
    }
    
    /**
     * Clears all cached joins. This is typically called when resetting context.
     */
    public void clearCache() {
        log.debug("Clearing join cache with {} entries", joinCache.size());
        joinCache.clear();
    }
    
    /**
     * Returns the number of cached joins.
     */
    public int getCacheSize() {
        return joinCache.size();
    }
    
    /**
     * Validates that the join path is properly formed.
     */
    public static boolean isValidJoinPath(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }
        
        // Check for invalid characters or patterns
        if (path.startsWith(".") || path.endsWith(".") || path.contains("..")) {
            return false;
        }
        
        return true;
    }
}