/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import io.rchemist.common.persistence.domain.annotation.IndexKeyValue;
import io.rchemist.common.persistence.jpa.domain.annotation.Unique;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.type.MaskingType;
import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtPrimitiveType;
import javassist.bytecode.ClassFile;
import javassist.bytecode.Descriptor;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.SignatureAttribute;
import javassist.bytecode.SignatureAttribute.MethodSignature;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.EnumMemberValue;
import javassist.bytecode.annotation.MemberValue;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.property.access.internal.PropertyAccessStrategyBasicImpl;
import org.hibernate.property.access.spi.PropertyAccess;
import org.hibernate.property.access.spi.PropertyAccessStrategy;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.reflections.Reflections;
import org.reflections.scanners.Scanners;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public class RegisterEntityBeanDTO extends EntityBean<RegisterEntityBeanDTO> {

  protected PropertyAccessStrategy propertyAccessStrategy = PropertyAccessStrategyBasicImpl.INSTANCE;


  protected void arrangeProperties(){

    boolean supportSoftDelete = false;
    boolean supportHibernateSearch = false;

    try {
      ClassPool classPool = ClassPool.getDefault();

      CtClass ctClazz = BytecodeUtil.getDefrostedCtClass(classPool, entityClass.getName());

      // add classHierarchy to abstract super class and interfaces
      Set<CtClass> classHierarchy = BytecodeUtil.collectClassHierarchy(ctClazz, new HashSet<>());
      
      // Collect subclasses using Reflections
      Set<CtClass> subclassHierarchy = collectSubclassHierarchy(entityClass, classPool);
      
      // Merge super classes and subclasses
      Set<CtClass> allClassHierarchy = new HashSet<>();
      allClassHierarchy.addAll(classHierarchy);
      allClassHierarchy.addAll(subclassHierarchy);

      Map<String, String[]> uniqueConstraintColumns = new HashMap<>();
      Map<String, String> uniqueErrorMessages = new HashMap<>();

      for(CtClass ctClass : allClassHierarchy){
        ClassFile classFile = BytecodeUtil.getClassFileSafety(ctClass);

        if(classFile.getName().equals(SoftDelete.class.getName())){
          supportSoftDelete = true;
        }

        if (BytecodeUtil.getDeclaredAnnotationOnType(classFile, INDEXED_CLASS_NAME) != null) {
          supportHibernateSearch = true;
        }

        List<FieldInfo> fieldInfos = classFile.getFields();
        for(FieldInfo info : CollectionUtils.emptyIfNull(fieldInfos)){
          boolean oneToManyField = false;
          String propertyName = info.getName();

          List<Annotation> list = BytecodeUtil.getDeclaredAnnotationsOnField(info);

          boolean hibernateSearchField = isHibernateSearchField(list);

          boolean indexEmbeddedField = isIndexedEmbeddedField(list);

          for(Annotation annotation : CollectionUtils.emptyIfNull(list)){

            String propertyType = BytecodeUtil.getAnnotationTypeName(info);
            Class propertyClass = BytecodeUtil.getProperClass(info.getDescriptor(), true);

            if(annotation.getTypeName().equals(COLUMN)){
              String columnName = BytecodeUtil.getStringValue(annotation, "name");
              this.columnNames.put(propertyName, columnName);
              this.propertyNames.put(columnName, propertyName);
              this.classMappingProperties.put(propertyName, new RegisterEntityBeanPropertyDTO(propertyName, propertyType, propertyClass, hibernateSearchField));
            }

            if(annotation.getTypeName().equals(EMBEDDED)) {
              mapPropertiesToClass(propertyName, propertyType, propertyClass, null, null, null);
            }

            if(annotation.getTypeName().equals(MANY_TO_ONE)) {
              mapPropertiesToClass(propertyName, propertyType, propertyClass, null, null, null);
            }

            if(annotation.getTypeName().equals(ONE_TO_MANY)){
              oneToManyField = true;

              Class<?> targetEntityClass = null;

              // First try to get targetEntity from annotation
              MemberValue memberValue = annotation.getMemberValue("targetEntity");
              if (memberValue != null && memberValue instanceof ClassMemberValue) {
                ClassMemberValue classMemberValue = (ClassMemberValue) memberValue;
                targetEntityClass = Class.forName(classMemberValue.getValue());
              } else {
                // Infer target entity from generic type of the field
                targetEntityClass = BytecodeUtil.inferTargetEntityFromFieldType(info);
              }

              if (targetEntityClass != null) {
                mapJoinedPropertiesToClass(propertyName, targetEntityClass, entityClass);
                this.classMappingProperties.put(propertyName, new RegisterEntityBeanPropertyDTO(propertyName, propertyType, targetEntityClass, indexEmbeddedField));
              }
            }

            if(annotation.getTypeName().equals(AdminField.class.getName())){
              if(annotation.getMemberNames().contains("masking")){
                // masking option 이 있는 경우

                AnnotationMemberValue annotationValue = (AnnotationMemberValue) annotation.getMemberValue("masking");
                Annotation masking = annotationValue.getValue();
                EnumMemberValue type = (EnumMemberValue) masking.getMemberValue("type");
                MaskingType maskingType = MaskingType.valueOf(type.getValue());
                Integer padding = NumberUtil.getInteger(BytecodeUtil.getIntegerValue(masking, "padding"), 1);

              }
            }

            if(annotation.getTypeName().equals(Unique.class.getName())){

              String columnList = BytecodeUtil.getStringValue(annotation, "columnList");

              if(StringUtils.isEmpty(columnList)){
                columnList = propertyName;
              }

              uniqueConstraintColumns.put(propertyName, StringUtil.splitWithNonEmpty(columnList, ","));
              uniqueErrorMessages.put(propertyName, BytecodeUtil.getStringValue(annotation, "errorMessage"));
            }

          }

          if(oneToManyField){
            addLazyLoadProperty(propertyName);
          }
        }

        List<MethodInfo> methodInfos = classFile.getMethods();

        for (MethodInfo info : CollectionUtils.emptyIfNull(methodInfos)) {

          List<Annotation> list = BytecodeUtil.getDeclaredAnnotationsOnMethod(info);

          for (Annotation annotation : CollectionUtils.emptyIfNull(list)) {
            if (annotation.getTypeName().equals(IndexKeyValue.class.getName())) {

              // boolean useAttributeField = true;
              String dtoFieldName = BytecodeUtil.getStringValue(annotation, "indexName");
              if (StringUtils.isEmpty(dtoFieldName)) {
                dtoFieldName = info.getName();
                dtoFieldName = StringUtil.toLowerCamelCase(StringUtils.removeStart(dtoFieldName, "get"));
              }

              String derivedFrom = BytecodeUtil.getStringValue(annotation, "derivedFrom");

              this.attributeFields.put(derivedFrom, dtoFieldName);

            } else if (annotation.getTypeName().equals(GenericField.class.getName())) {

              // 메소드에 @GenericField 를 설정해 커스텀하게 만든 Hibernate 검색 필드 설정인 경우

              if (supportHibernateSearch) {
                String name = BytecodeUtil.getStringValue(annotation, "name");

                // 현재 메소드의 반환 타입을 확인하고, 반환타입이 primitive 거나 wrapper 면 그냥 컬럼으로 추가한다.
                // 하지만 반환 타입이 다른 Class 라면 별도의 처리를 한다.

                // 메소드 시그니처를 파싱하여 리턴 타입을 추출
                String descriptor = info.getDescriptor();
                SignatureAttribute signatureAttr = (SignatureAttribute) info.getAttribute(SignatureAttribute.tag);
                Class<?> returnType;
                CtClass clazz;

                if (name == null) {
                  String methodName = info.getName();
                  name = StringUtil.toLowerCamelCase(StringUtils.removeStart(methodName, "get"));
                }

                if (signatureAttr != null) {
                  MethodSignature methodSignature = SignatureAttribute.toMethodSignature(signatureAttr.getSignature());

                  String className = methodSignature.getReturnType().jvmTypeName();
                  if (className.contains("<")) {
                    // list, map 등이라면
                    className = className.substring(0, className.indexOf("<"));
                  }

                  clazz = classPool.get(className);
                } else {
                  // 시그니처가 없을 경우 기본 타입 추출
                  clazz = Descriptor.getReturnType(descriptor, classPool);
                }

                String className = (clazz instanceof CtPrimitiveType pt) ? pt.getWrapperName() : clazz.getName();
                if (className.contains("<")) {
                  // list, map 등이라면
                  className = className.substring(0, className.indexOf("<"));
                }

                returnType = BytecodeUtil.getClassByName(className);

                if (returnType == null) {
                  continue;
                }

                this.classMappingProperties.put(name, new RegisterEntityBeanPropertyDTO(name, returnType.getSimpleName(), returnType, true));

              }

            }
          }


        }
      }

      if(MapUtils.isNotEmpty(uniqueConstraintColumns)){

        for(Entry<String, String[]> entry : uniqueConstraintColumns.entrySet()){

          String propertyName = entry.getKey();
          String columnName = columnNames.get(propertyName);
          String[] uniqueColumns = entry.getValue();
          String errorMessage = StringUtil.toString(uniqueErrorMessages.get(propertyName), "error.validation.unique.constraint");

          List<UniqueColumn> uniqueColumnList = new ArrayList<>();
          for(String column : uniqueColumns){

            if(columnNames.containsKey(column)){
              // 컬럼명이 제대로 들어 온 경우
              String uniqueColumnName = columnNames.get(column);
              uniqueColumnList.add(new UniqueColumn(uniqueColumnName, column));
            }else{
              if(propertyNames.containsKey(column)){
                // 컬럼명을 지정하지 않아 property name 이 들어온 경우
                String uniqueColumnName = columnNames.get(column);
                if(uniqueColumnName == null){
                  // 데이터 오류
                  continue;
                }
                uniqueColumnList.add(new UniqueColumn(uniqueColumnName, column));

              }else{
                // 데이터 오류
                continue;
              }
            }
          }

          UniqueConstraint constraint = new UniqueConstraint(propertyName, columnName, errorMessage, uniqueColumnList);
          this.uniqueConstraints.add(constraint);

        }
      }

      this.supportSoftDelete = supportSoftDelete;
      this.supportHibernateSearch = supportHibernateSearch;

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void loadLazyProperties(Object entityValue){
    for(String propertyName : CollectionUtils.emptyIfNull(getLazyLoadProperties())){
      PropertyAccess propertyAccess = propertyAccessStrategy.buildPropertyAccess(entityClass, propertyName, false);
      try {
        Class returnType = propertyAccess.getGetter().getReturnType().getClass();
        Method method = propertyAccess.getGetter().getMethod();

        if(isAssignableFrom(returnType, List.class)){
          List list = (List) method.invoke(entityValue, null);
          list.size();
        }else if(isAssignableFrom(returnType, Set.class)){
          Set set = (Set) method.invoke(entityValue, null);
          set.size();
        }else if(isAssignableFrom(returnType, Map.class)){
          Map map = (Map) method.invoke(entityValue, null);
          map.size();
        }
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      } catch (InvocationTargetException e) {
        e.printStackTrace();
      }
    }
  }


  protected void mapJoinedPropertiesToClass(String propertyName, Class propertyClass, Class entityClass) {
    try {
      CtClass ctClazz = BytecodeUtil.getDefrostedCtClass(ClassPool.getDefault(), propertyClass.getName());
      Set<CtClass> classHierarchy = new HashSet<>();
      BytecodeUtil.getInterfaces(ctClazz, classHierarchy);

      for(CtClass ctClass : classHierarchy) {
        ClassFile classFile = BytecodeUtil.getClassFileSafety(ctClass);

        for (FieldInfo info : CollectionUtils.emptyIfNull(classFile.getFields())) {
          List<Annotation> list = BytecodeUtil.getDeclaredAnnotationsOnField(info);

          if (CollectionUtils.isNotEmpty(list)) {
            String subPropertyName = StringUtil.merge(propertyName, ".", info.getName());
            String subPropertyType = BytecodeUtil.getAnnotationTypeName(info);
            Class subPropertyClass = BytecodeUtil.getProperClass(info.getDescriptor(), true);

            if(StringUtils.equalsAny(subPropertyType, EMBEDDED, MANY_TO_ONE)) {

              mapPropertiesToClass(subPropertyName, subPropertyType, subPropertyClass, propertyName, propertyClass, entityClass);

            } else if (StringUtils.equals(subPropertyType, ONE_TO_MANY)) {

              // OneToMany in OneToMany case is not supported

            } else {

              classMappingProperties.put(subPropertyName, new RegisterEntityBeanPropertyDTO(subPropertyName, subPropertyType, subPropertyClass, propertyName, propertyClass, isHibernateSearchField(list)));

            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }


  /**
   * Embedded, ManyToOne 인 경우 propertyName 에 . 을 붙여서 저장한다.
   *
   */
  public void mapPropertiesToClass(String propertyName, String propertyType, Class propertyClass, String joinAlias, Class joinClass, Class entityClass) {
    try {
      if(StringUtils.equalsAny(propertyType, EMBEDDED, MANY_TO_ONE) && !propertyClass.equals(entityClass)) {

        CtClass ctClazz = BytecodeUtil.getDefrostedCtClass(ClassPool.getDefault(), propertyClass.getName());
        Set<CtClass> classHierarchy = BytecodeUtil.collectClassHierarchy(ctClazz, new HashSet<>());

        for(CtClass ctClass : classHierarchy) {
          ClassFile classFile = BytecodeUtil.getClassFileSafety(ctClass);

          for(FieldInfo info : CollectionUtils.emptyIfNull(classFile.getFields())) {
            List<Annotation> list = BytecodeUtil.getDeclaredAnnotationsOnField(info);

            if (CollectionUtils.isNotEmpty(list)) {
              String nestedPropertyName = StringUtil.merge(propertyName, ".", info.getName());
              String subPropertyType = BytecodeUtil.getAnnotationTypeName(info);
              Class subPropertyClass = BytecodeUtil.getProperClass(info.getDescriptor(), true);

              if(StringUtils.equalsAny(subPropertyType, EMBEDDED, MANY_TO_ONE)) {

                mapPropertiesToClass(nestedPropertyName, subPropertyType, subPropertyClass, joinAlias, joinClass, propertyClass);

              } else {

                classMappingProperties.put(nestedPropertyName, new RegisterEntityBeanPropertyDTO(nestedPropertyName, subPropertyType, subPropertyClass, joinAlias, joinClass, isHibernateSearchField(list)));

              }
            }
          }

        }

      } else if (StringUtils.equals(propertyType, ONE_TO_MANY)) {

        // OneToMany in OneToMany case is not supported

      } else {

        // classMappingProperties.put(propertyName, new RegisterEntityBeanPropertyDTO(propertyName, propertyType, propertyClass, propertyName, joinClass, isHibernateSearchField(propertyClass)));

      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected boolean isIndexedEmbeddedField(List<Annotation> annotations) {
    if (CollectionUtils.isEmpty(annotations)) {
      return false;
    }

    for (Annotation annotation : annotations) {

      String annotationName = annotation.getTypeName();

      if (StringUtil.equalsAny(annotationName, INDEX_EMBEDDED)) {
        return true;
      }

    }

    return false;

  }

  /**
   * Collect all subclasses of the given entity class using Reflections library
   * 
   * @param entityClass The entity class to find subclasses for
   * @param classPool ClassPool for converting to CtClass
   * @return Set of CtClass representing all subclasses
   */
  protected Set<CtClass> collectSubclassHierarchy(Class<?> entityClass, ClassPool classPool) {
    Set<CtClass> subclasses = new HashSet<>();
    
    try {
      // Use Reflections to scan for subclasses
      // Get package name from entity class to limit scanning scope
      String packageName = entityClass.getPackage() != null ? entityClass.getPackage().getName() : "";
      if (StringUtils.isEmpty(packageName)) {
        packageName = "io.rchemist"; // Default package prefix for RCM framework
      }
      
      Reflections reflections = new Reflections(packageName, Scanners.SubTypes);
      @SuppressWarnings("unchecked")
      Set<Class<?>> subTypes = (Set<Class<?>>) (Set<?>) reflections.getSubTypesOf(entityClass);
      
      // Convert each subclass to CtClass
      for (Class<?> subType : subTypes) {
        try {
          CtClass ctSubClass = BytecodeUtil.getDefrostedCtClass(classPool, subType.getName());
          subclasses.add(ctSubClass);
          
          log.debug("Found subclass {} for entity {}", subType.getName(), entityClass.getName());
        } catch (Exception e) {
          log.warn("Failed to process subclass {}: {}", subType.getName(), e.getMessage());
        }
      }
      
    } catch (Exception e) {
      log.warn("Failed to collect subclasses for {}: {}", entityClass.getName(), e.getMessage());
    }
    
    return subclasses;
  }

  protected boolean isHibernateSearchField(List<Annotation> annotations) {
    if (CollectionUtils.isEmpty(annotations)) {
      return false;
    }

    for (Annotation annotation : annotations) {

      String annotationName = annotation.getTypeName();

      if (StringUtil.equalsAny(annotationName,
          GENERIC_FIELD,
          FULL_TEXT_FIELD,
          KEYWORD_FIELD,
          SCALED_NUMBER_FIELD,
          NON_STANDARD_FIELD
      ) ) {
        return true;
      }

    }

    return false;

  }




}
