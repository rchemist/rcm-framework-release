/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import static io.rchemist.common.search.config.SearchAnalyzerSetting.FULLTEXT_ANALYZER;
import static io.rchemist.common.search.config.SearchAnalyzerSetting.SIMPLE_STRING;

import org.hibernate.search.backend.elasticsearch.analysis.ElasticsearchAnalysisConfigurationContext;
import org.hibernate.search.backend.elasticsearch.analysis.ElasticsearchAnalysisConfigurer;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ElasticsearchKoreanAnalyzerConfigurer implements ElasticsearchAnalysisConfigurer {

  private static final String FULLTEXT_ANALYZER_TYPE = "platform.config.common.search.analyzer";
  private static final String BOOTSTRAP_YML = "application*.yml";

  private static final String SIMPLE_STRING2 = "simple_string2";

  private static FullTextAnalyzerType analyzer;

  @Override
  public void configure(
      ElasticsearchAnalysisConfigurationContext context) {

    if(getAnalyzer().equals(FullTextAnalyzerType.SEUNJEON)){
      context.tokenizer("seunjeon_tokenizer")
          .type("seunjeon_tokenizer")
          .param("index_eojeol", false)
          .param("decompound", true)
          .param("pos_tagging", false)
          .param("index_poses", "UNK", "EP", "I", "M", "N", "SL", "SH", "SN", "V", "VCP", "XP", "XS",
              "XR");

      context.analyzer(SIMPLE_STRING).custom()
          .tokenizer("standard")
          .charFilters("html_strip")
          .tokenFilters("lowercase", "asciifolding");

      context.analyzer(FULLTEXT_ANALYZER)
          .type("custom")
          .param("tokenizer", "seunjeon_tokenizer");

    }else{
      context.analyzer(SIMPLE_STRING2).custom()
          .tokenizer("korean_tokenizer")
          .charFilters("html_strip")
          .tokenFilters("lowercase", "nori_part_of_speech", "nori_readingform",
              "korean_posfilter",
              "synonym_filter",
              "edge_ngram_filter_front",
              "edge_ngram_filter_back",
              "asciifolding", "trim");

      context.tokenizer("korean_tokenizer")
          .type("nori_tokenizer")
          .param("decompound_mode", "mixed")
          .param("user_dictionary", SearchAnalyzerSetting.getUserDictPath());

      context.tokenFilter("korean_posfilter")
          .type("nori_part_of_speech")
          .param("stoptags", "E",
              "IC",
              "J",
              "MAG",
              "MM",
              "NA",
              "NR",
              "SC",
              "SE",
              "SF",
              "SP",
              "SSC",
              "SSO",
              "SY",
              "UNA",
              "VA",
              "VCN",
              "VCP",
              "XPN",
              "XR",
              "XSA",
              "XSN",
              "XSV");

      context.tokenFilter("edge_ngram_filter_front")
          .type("edge_ngram")
          .param("min_gram", 1)
          .param("max_gram", 10)
          .param("side", "front");

      context.tokenFilter("edge_ngram_filter_back")
          .type("edge_ngram")
          .param("min_gram", 1)
          .param("max_gram", 10)
          .param("side", "back");


      /*

       */
      context.analyzer(SIMPLE_STRING).custom()
          .tokenizer("standard")
          .charFilters("html_strip")
          .tokenFilters("lowercase", "nori_part_of_speech", "nori_readingform", "synonym_filter", "asciifolding", "trim");

      context.tokenFilter("synonym_filter")
          .type("synonym")
          .param("lenient", true)
          .param("synonyms_path", SearchAnalyzerSetting.getSynonymPath());


      context.analyzer(FULLTEXT_ANALYZER).custom()
          .tokenizer("nori_tokenizer")
          .charFilters("html_strip")
          .tokenFilters("lowercase", "nori_part_of_speech", "nori_readingform", "asciifolding");

    }

  }

  public static FullTextAnalyzerType getAnalyzer() {
    if(analyzer == null){
      analyzer = SearchAnalyzerSetting.getFullTextAnalyzer();
    }
    return analyzer;
  }


}
