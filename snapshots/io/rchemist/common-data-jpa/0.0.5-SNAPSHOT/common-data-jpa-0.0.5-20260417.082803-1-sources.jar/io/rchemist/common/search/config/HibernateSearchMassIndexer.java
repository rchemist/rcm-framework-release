/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.metamodel.EntityType;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.Session;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.common.impl.HibernateOrmUtils;
import org.hibernate.search.mapper.orm.massindexing.MassIndexer;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.hibernate.search.mapper.orm.work.SearchIndexingPlan;
import org.springframework.util.ReflectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HibernateSearchMassIndexer {

  EntityManager getEntityManager();


  default boolean isAssignableEntity(Class<?> entity){

    EntityManager em = getEntityManager();
    Set<EntityType<?>> entityTypes = em.getEntityManagerFactory().getMetamodel().getEntities();

    for(EntityType entityType : entityTypes){
      if(entityType.getJavaType().equals(entity)){
        return true;
      }
    }

    return false;

  }

  default int getRecordCount(Class<?> entity){
    EntityManager em = getEntityManager();

    CriteriaBuilder builder = em.getCriteriaBuilder();
    CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
    Root root = criteria.from(entity);

    criteria.select(builder.count(root));

    Long result = em.createQuery(criteria).getSingleResult();

    return (result == null) ? 0 : result.intValue();
  }

  //@Transactional
  default Object doMassIndexAndGetLastId(Class<?> entity, int pageSize, Object lastId){
    EntityManager em = getEntityManager().getEntityManagerFactory().createEntityManager();
    Session transactionSession = HibernateOrmUtils.toSession(em);
    transactionSession.getTransaction().begin();
    try {

      CriteriaBuilder builder = em.getCriteriaBuilder();

      CriteriaQuery criteria = builder.createQuery(entity);
      Root root = criteria.from(entity);
      criteria.select(root);

      List<Predicate> predicates = new ArrayList<>();
      if(lastId != null){
        if(lastId instanceof String){
          predicates.add(builder.greaterThan(root.get("id"), (String) lastId));
        }else if(lastId instanceof Long){
          predicates.add(builder.greaterThan(root.get("id"), (Long) lastId));
        }
      }

      if(SoftDelete.class.isAssignableFrom(entity)){
        predicates.add(builder.or(builder.isNull(root.get("archived")), builder.equal(root.get("archived"), true)));
      }

      if(CollectionUtils.isNotEmpty(predicates)){
        criteria.where(predicates.toArray(new Predicate[0]));
      }

      criteria.orderBy(builder.asc(root.get("id")));

      TypedQuery query = em.createQuery(criteria);
      query.setMaxResults(pageSize);

      List list = query.getResultList();

      lastId = null;

      int count = list.size();
      int loop = 1;

      if (count > 0) {
        SearchSession searchSession = Search.session( em );
        MassIndexer indexer = searchSession.massIndexer( entity );
        indexer.startAndWait();

        for (Object object : CollectionUtils.emptyIfNull(list)) {
          SearchIndexingPlan indexingPlan = searchSession.indexingPlan();
          // indexingPlan.delete(object);
          indexingPlan.addOrUpdate(object);
          if(loop++ == count){
            lastId = getIdValue(object);
          }
        }

      }

      return lastId;

    }catch (Exception e){
      e.printStackTrace();
      return null;
    }finally {
      transactionSession.getTransaction().rollback();
      transactionSession.close();
      em.close();
    }
  }

  private Object getIdValue(Object entity){
    Field id = ReflectionUtils.findField(entity.getClass(), "id");
    try {
      id.setAccessible(true);
      return id.get(entity);
    } catch (IllegalAccessException e) {
      e.printStackTrace();
      return null;
    }
  }

}
