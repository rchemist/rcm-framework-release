/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.search.config.SearchAnalyzerSetting;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EditorJsUtil;
import io.rchemist.common.util.KoreanUtil;
import jakarta.persistence.Column;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(Contents.class)
@Getter
@Setter
public class ContentsImpl implements Serializable, EnhancedTemplate {

  @Column(name = "TITLE")
  @AdminField(name = "ContentsImpl_Title", order = 100, headerField = @HeaderField(order = 100), fieldType = PresentationFieldType.STRING, required = true)
  @FullTextField(analyzer = SearchAnalyzerSetting.SIMPLE_STRING)
  @Description(name = "제목")
  protected String title;

  @Column(name = "TITLE_CONSONANT")
  @AdminField(name = "ContentsImpl_TitleConsonant", order = 200, headerField = @HeaderField(order = 200), fieldType = PresentationFieldType.STRING, required = true)
  @KeywordField
  @Description(name = "제목 초성", comment = "별도의 검색엔진을 사용하지 않는 경우, 초성 검색 지원을 위해 제목의 초성을 저장한다")
  protected String titleConsonant;

  @Column(name = "TITLE_PHONEME")
  @AdminField(name = "ContentsImpl_TitlePhoneme", order = 300, headerField = @HeaderField(order = 300), fieldType = PresentationFieldType.STRING, required = true)
  @KeywordField
  @Description(name = "제목 음소", comment = "별도의 검색엔진을 사용하지 않는 경우, 음소단위 검색 지원을 위해 제목의 음소를 저장한다")
  protected String titlePhoneme;

  @Column(name = "CONTENT")
  @Text
  @AdminField(name = "ContentsImpl_Contents", order = 1000, fieldType = PresentationFieldType.HTML, required = true)
  @Description(name = "내용")
  protected String content;

  @Column(name = "SEARCHABLE_CONTENT")
  @Text
  @FullTextField(name = "content", analyzer = SearchAnalyzerSetting.FULLTEXT_ANALYZER)
  @Description(name = "검색용 내용", comment = "CONTENT 필드값 중 검색 가능한 글자만 따로 뽑아 검색용 내용으로 저장한다")
  protected String searchableContent;

  public void setTitle(String title) {
    this.title = title;
    setTitleConsonant(KoreanUtil.getConsonants(title));
    setTitlePhoneme(KoreanUtil.getPhonemes(title));
  }

  public void setContent(String content) {
    this.content = content;
    setSearchableContent(content);
  }

  public void setSearchableContent(String content) {
    if(StringUtils.isNotEmpty(content)){
      this.searchableContent = EditorJsUtil.getSearchableContents(content);
    } else {
      this.searchableContent = null;
    }
  }

}
