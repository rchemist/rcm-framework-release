/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.type.RepeatPeriodType;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/

public interface RepeatPeriod<T> extends ClassTransformTarget {

  /**
   * 랭킹 판정을 얼마 주기로 할 것인지
   * autoRank 가 true 인 경우에만 셋팅
   * @return
   */
  default RepeatPeriodType getRepeatPeriodType() {
    throw new ClassTransformException();
  }
  default void setRepeatPeriodType(RepeatPeriodType repeatPeriodType) {
    throw new ClassTransformException();
  }

  /**
   * CustomerRankPeriodType 이 PER_MONTHS 나 PER_DAYS 일 때 X 에 해당하는 값
   * @return
   */
  default Integer getRepeatPeriod() {
    throw new ClassTransformException();
  }
  default void setRepeatPeriod(Integer period) {
    throw new ClassTransformException();
  }

  /**
   * CustomerRankPeriodType 이 YEARLY 일 때 몇월 몇일에 산정하는지
   * @return
   */
  default String getPeriodMonthDay() {
    throw new ClassTransformException();
  }
  default void setPeriodMonthDay(String periodMonthDay) {
    throw new ClassTransformException();
  }

  /**
   * CustomerRankPeriodType 이 PER_MONTH, PER_DAYS 일 때 시작점이 되는 기준일
   * @return
   */
  default LocalDate getPeriodBaseDate() {
    throw new ClassTransformException();
  }
  default void setPeriodBaseDate(LocalDate periodBaseDate) {
    throw new ClassTransformException();
  }

  /**
   * 매월, PER 월 일 때 기준일
   * 1일 ~ 31 일 (29 이상의 날짜가 셋팅되는 경우 해당 월 마지막 날짜가 셋팅된 날짜보다 작으면 해당 월의 마지막 날짜로 자동 인식)
   * @return
   */
  default Integer getDueDay() {
    throw new ClassTransformException();
  }
  default void setDueDay(Integer dueDay) {
    throw new ClassTransformException();
  }

  /**
   * 넘겨 받은 날짜가 autoRank 에 의해 실행되는 날짜인지
   * @param candidateDate
   * @return
   */
  default boolean isSuitableDayToRepeatPeriod(LocalDateTime candidateDate){
    //
    if(getRepeatPeriodType() == null)
      return false;

    RepeatPeriodType type = getRepeatPeriodType();

    if(type != null){
      return type.isSuitable(candidateDate, getPeriodBaseDate(), getRepeatPeriod(), getPeriodMonthDay(), getDueDay());
    }

    return false;
  }

  default T withRepeatPeriodType(RepeatPeriodType repeatPeriodType) {
    setRepeatPeriodType(repeatPeriodType);
    return (T) this;
  }

  default T withRepeatPeriod(Integer period) {
    setRepeatPeriod(period);
    return (T) this;
  }

  default T withPeriodMonthDay(String periodMonthDay) {
    setPeriodMonthDay(periodMonthDay);
    return (T) this;
  }

  default T withPeriodBaseDate(LocalDate periodBaseDate) {
    setPeriodBaseDate(periodBaseDate);
    return (T) this;
  }

  default T withDueDay(Integer dueDay) {
    setDueDay(dueDay);
    return (T) this;
  }
}
