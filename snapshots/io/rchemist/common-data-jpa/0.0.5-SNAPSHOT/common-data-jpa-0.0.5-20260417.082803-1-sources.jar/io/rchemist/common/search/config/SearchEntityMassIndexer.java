/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.config;

import io.rchemist.common.configuration.platform.DataProviderConfig;
import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.search.config.HibernateSearchConfig.HibernateSearchEnabled;
import io.rchemist.common.util.StringUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Conditional(HibernateSearchEnabled.class)
@Component
@Slf4j
public class SearchEntityMassIndexer implements ApplicationListener<ApplicationReadyEvent> {

  private final List<HibernateSearchMassIndexer> massIndexers;

  private int pageSize = 50;

  private static final String DEFAULT_SCHEMA_MANAGEMENT_STRATEGY = "drop-and-create";

  @Value("${hibernate.search.schema_management.strategy:}")
  private String searchIndexMode;

  @Value("${spring.jpa.properties.hibernate.search.schema_management.strategy:}")
  private String jpaSearchIndexMode;

  private static final String[] AVAILABLE_SCHEMA_MANAGEMENT_STRATEGIES = new String[] {
      "drop-and-create", "drop-and-create-and-drop",
      "create-or-update"
  };

  public SearchEntityMassIndexer(
      @Autowired(required = false) List<HibernateSearchMassIndexer> massIndexers) {
    this.massIndexers = massIndexers;
  }

  protected String getSearchIndexMode(){

    String mode = StringUtils.defaultIfBlank(searchIndexMode, jpaSearchIndexMode);

    return StringUtils.defaultIfBlank(mode, DEFAULT_SCHEMA_MANAGEMENT_STRATEGY);

  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {

    // Search Provider 가 Hibernate 가 아니면 실행하지 않는다.
    if(!DataProviderConfig.getSearchProvider().equals(SearchProvider.HIBERNATE))
      return;

    if(!StringUtil.equalsAny(getSearchIndexMode(), AVAILABLE_SCHEMA_MANAGEMENT_STRATEGIES)){
      return;
    }

    StopWatch stopWatch = new StopWatch();
    stopWatch.start();

    log.info("Start massIndexes");

    List<Class<?>> entities = PlatformSessionFactoryBuilderFactory.getHibernateSearchEntities();

    if(CollectionUtils.isNotEmpty(entities) && CollectionUtils.isNotEmpty(massIndexers)){

      ExecutorService indexService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
      List<Future<?>> futures = new ArrayList<>();


      for(Class<?> entity : entities){
        futures.add(indexService.submit(() -> doMassIndex(entity)));
      }

      for (Future<?> future : CollectionUtils.emptyIfNull(futures)) {
        try {
          future.get();
        } catch (Exception e) {
          log.error("Error while mass indexing", e);
        }
      }

      indexService.shutdown();
    }

    stopWatch.stop();

    log.info("Finished massIndexes in " + stopWatch.getTotalTimeSeconds() + " seconds.");

  }

  private void doMassIndex(Class<?> entity) {
    for(HibernateSearchMassIndexer massIndexer : massIndexers){

      if(massIndexer.isAssignableEntity(entity)){

        int allCount = massIndexer.getRecordCount(entity);

        if(allCount > 0){
          // paging 처리

          Object lastId = null;

          while(true){

            lastId = massIndexer.doMassIndexAndGetLastId(entity, pageSize, lastId);
            // get id

            if(lastId == null){
              break;
            }

          }
        }

      }

    }
  }

}
