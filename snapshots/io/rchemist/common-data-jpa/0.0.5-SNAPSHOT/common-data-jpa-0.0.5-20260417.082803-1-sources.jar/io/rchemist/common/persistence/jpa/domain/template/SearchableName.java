/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.search.config.SearchAnalyzerSetting;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexingDependency;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.ObjectPath;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyValue;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
public interface SearchableName {

  String getName();

  @FullTextField(name = "searchableName", analyzer = SearchAnalyzerSetting.SIMPLE_STRING)
  @IndexingDependency(derivedFrom = @ObjectPath(@PropertyValue(propertyName = "name")))
  default String getSearchableName() {
    return getName();
  }

}
