/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.domain.template.presentation.HasFullAddress;
import io.rchemist.common.util.StringUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface FullAddress<T> extends ClassTransformTarget {

  default String getFullAddress() {
    return StringUtil.mergeWithSplitCode(" ", getState(), getCity(), getAddress1(), getAddress2());
  }

  default String getState() {
    throw new ClassTransformException();
  }

  default void setState(String state) {
    throw new ClassTransformException();
  }

  default T withState(String state) {
    setState(state);
    return (T) this;
  }

  default String getCity() {
    throw new ClassTransformException();
  }

  default void setCity(String city) {
    throw new ClassTransformException();
  }

  default T withCity(String city) {
    setCity(city);
    return (T) this;
  }

  default String getAddress1() {
    throw new ClassTransformException();
  }

  default void setAddress1(String address1) {
    throw new ClassTransformException();
  }

  default T withAddress1(String address1) {
    setAddress1(address1);
    return (T) this;
  }

  default String getAddress2() {
    throw new ClassTransformException();
  }

  default void setAddress2(String address2) {
    throw new ClassTransformException();
  }

  default T withAddress2(String address2) {
    setAddress2(address2);
    return (T) this;
  }

  default String getPostalCode() {
    throw new ClassTransformException();
  }

  default void setPostalCode(String postalCode) {
    throw new ClassTransformException();
  }

  default T withPostalCode(String postalCode) {
    setPostalCode(postalCode);
    return (T) this;
  }

  default void setFullAddress(HasFullAddress<?> address) {
    if (address != null) {
      setState(address.getState());
      setCity(address.getCity());
      setAddress1(address.getAddress1());
      setAddress2(address.getAddress2());
      setPostalCode(address.getPostalCode());
    }
  }

  default <A> A convertAddress(HasFullAddress<A> data) {
    data.setState(getState());
    data.setCity(getCity());
    data.setAddress1(getAddress1());
    data.setAddress2(getAddress2());
    data.setPostalCode(getPostalCode());
    return (A) data;
  }

  /**
   * 주소 처리를 위한 필수 정보가 있는지 확인한다.
   * @return
   */
  default boolean isEmptyAddress() {
    return StringUtils.isEmpty(getPostalCode())
        || StringUtils.isEmpty(getAddress1())
        || StringUtils.isEmpty(getAddress2());
  }

  default boolean isSameAddress(HasFullAddress<?> address) {
    return StringUtils.equals(getPostalCode(), address.getPostalCode())
        && StringUtils.equals(getAddress1(), address.getAddress1())
        && StringUtils.equals(getAddress2(), address.getAddress2());
  }

}
