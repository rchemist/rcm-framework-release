/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import java.io.Serializable;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class QuerySpecificationResultHolder implements Serializable {

  public QuerySpecificationResultHolder(Map<ConditionOperatorType, QueryCondition> result) {
    this.result = result;
  }

  protected Map<ConditionOperatorType, QueryCondition> result;

  protected String[] filtered;

  public QuerySpecificationResultHolder addFiltered(String... filtered) {
    if (filtered != null && ArrayUtils.isNotEmpty(filtered)) {
      Set<String> filteredSet = new HashSet<>();
      if (this.filtered != null) {
        for (String filter : this.filtered) {
          filteredSet.add(filter);
        }
      }
      for (String filter : filtered) {
        filteredSet.add(filter);
      }
      this.filtered = filteredSet.toArray(new String[0]);
    }
    return this;
  }

  public boolean isFiltered() {
    return ArrayUtils.isNotEmpty(filtered);
  }

  public QuerySpecificationResultHolder addCondition(ConditionOperatorType type, QueryConditionItem... items) {
    if (result == null) {
      result = new LinkedHashMap<>();
    }

    if (items != null && ArrayUtils.isNotEmpty(items)) {
      if (result.containsKey(type)) {
        QueryCondition wrapper = result.get(type);
        wrapper.addQueryItems(items);
        result.put(type, wrapper);
      } else {
        result.put(type, new QueryCondition().addQueryItems(items));
      }

      for (QueryConditionItem item : items) {
        addFiltered(item.getPropertyNames());
      }

    }

    return this;
  }

  public static QuerySpecificationResultHolder createBlankResult() {
    return new QuerySpecificationResultHolder(new LinkedHashMap<>());
  }

}
