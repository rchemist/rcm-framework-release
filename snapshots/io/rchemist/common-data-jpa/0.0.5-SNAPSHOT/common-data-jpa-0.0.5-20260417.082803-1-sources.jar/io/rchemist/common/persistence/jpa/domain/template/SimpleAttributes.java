/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.persistence.jpa.domain.data.SimpleAttributeParser;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SimpleAttributes<T> extends ClassTransformTarget {

  default String getSimpleAttributeValue(String key){
    throw new ClassTransformException();
  }
  default Map<String, String> getSimpleAttributes(){throw new ClassTransformException();}
  default void setSimpleAttributes(Map<String, String> simpleAttributes) {
    throw new ClassTransformException();
  }
  default void addSimpleAttribute(String key, String value){
    throw new ClassTransformException();
  }

  default T withSimpleAttributes(Map<String, String> simpleAttributes) {
    setSimpleAttributes(simpleAttributes);
    return (T) this;
  }

  default void updateAttributes(Map<String, String> previousAttributes, String attributePrefix, String... modifiedFields) {
    setSimpleAttributes(SimpleAttributeParser.getModifiedSimpleAttributes(this, previousAttributes, attributePrefix, modifiedFields));
  }

}
