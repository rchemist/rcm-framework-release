/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.datasource.provider;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.sql.DataSource;
import org.springframework.core.Ordered;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface DataSourceBuilder extends Ordered, Comparable<DataSourceBuilder> {

  /**
   * Properties 로
   */
  Map<String, Properties> ADDITIONAL_PROPERTIES = new HashMap<>();

  DataSource getDataSource(String dataSourceName, Map<String, Properties> properties);

  Map<String, Properties> translateDataSourceProperties(Properties properties, String... prefixes);

}
