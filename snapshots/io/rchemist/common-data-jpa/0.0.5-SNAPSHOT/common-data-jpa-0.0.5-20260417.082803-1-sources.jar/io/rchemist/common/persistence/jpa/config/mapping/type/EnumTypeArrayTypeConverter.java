/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class EnumTypeArrayTypeConverter extends AbstractUserTypeConverter implements UserType, ParameterizedType {

  public static final EnumTypeArrayTypeConverter INSTANCE = new EnumTypeArrayTypeConverter();
  protected static Logger logger = LoggerFactory.getLogger(EnumTypeArrayTypeConverter.class);

  /*@Override
  public int[] sqlTypes() {
    return new int[] {StringType.INSTANCE.sqlType()};
  }
*/
  @Override
  public int getSqlType() {
    return StandardBasicTypes.STRING.getSqlTypeCode();
  }

  @Override
  public Class returnedClass() {

    try {
      Class clazz = getReturnedClassType();
      if(EnumType.class.isAssignableFrom(clazz)) {
        return Array.newInstance(clazz, 0).getClass();
      }
    } catch (ClassNotFoundException e) {
      ExceptionUtil.printStackTrace(e);
    }

    return EnumType[].class;

  }

  @Override
  public boolean equals(Object x, Object y) throws HibernateException {

    if(x == null && y == null)
      return true;

    if(x == null && y != null)
      return false;

    if(x != null && y == null)
      return false;

    try{
      EnumType[] xArray = (EnumType[]) x;
      EnumType[] yArray = (EnumType[]) y;
      return Arrays.equals(xArray, yArray);
    }catch (Exception e){
      return false;
    }
  }

  @Override
  public int hashCode(Object x) throws HibernateException {
    return Objects.hashCode(x);
  }

  @Override
  public Object nullSafeGet(ResultSet resultSet, int i,
      SharedSessionContractImplementor sharedSessionContractImplementor, Object o)
      throws SQLException {
    String columnValue = (String) resultSet.getObject(i);
    String[] enums = StringUtil.splitArray(columnValue, StringArrayTypeConverter.SPLIT_CODE);

    return getEnumTypesFromString(enums);
  }

  private <T> List<T> getList(String[] enums){
    return new ArrayList<>();
  }

  protected <T> T[] getEnumTypes(Class<T> clazz, String[] enums){
    T[] array = ArrayUtil.makeArray(clazz, enums.length);
    int i = 0;
    for(String enumeration : enums){
      try {
        array[i++] = (T) this.getProperClass().getMethod("getInstance", String.class, String.class).invoke(getProperClass(), clazz.getName(), enumeration);
      } catch (NoSuchMethodException | ClassNotFoundException | IllegalAccessException | InvocationTargetException e) {
        ExceptionUtil.printStackTrace(e);
      }
    }
    return array;
  }

  @Nullable
  public Object getEnumTypesFromString(String[] enums) throws SQLException {
    if(ArrayUtils.isNotEmpty(enums)){
      try {
        return getEnumTypes(getProperClass(), enums);
      } catch (ClassNotFoundException e) {
        ExceptionUtil.printStackTrace(e);
      }
    }
    return null;
  }

  @Override
  public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session) throws HibernateException, SQLException {
    if ( value == null ) {
      logger.debug("Binding null to parameter {0} ",index);
      st.setNull( index, Types.VARCHAR );
    }
    else {
      EnumType[] enumTypes = (EnumType[]) value;
      List<String> toString = new ArrayList<>();
      for(EnumType enumType : enumTypes){
        toString.add(enumType.getType());
      }
      String[] values = toString.toArray(new String[toString.size()]);

      String stringValue = StringUtil.mergeWithSplitCode(StringArrayTypeConverter.SPLIT_CODE, values);
      logger.debug("Binding {0} to parameter {1} ", stringValue, index);
      st.setString( index, stringValue );
    }
  }

  @Override
  public Object deepCopy(Object value) throws HibernateException {

    if(value == null || ((EnumType[]) value).length == 0){
      return null;
    }else{
      return value;
      /*
      EnumType[] origin = (EnumType[]) value;
      List<String> types = new ArrayList<>();
      for(EnumType enumType : origin){
        types.add(enumType.getKey());
      }
      try {
        return getEnumTypesFromString(types.toArray(new String[types.size()]));
      } catch (SQLException e) {
        ExceptionUtil.printStackTrace(e);
      }
      return null;
       */
    }
  }

  @Override
  public boolean isMutable() {
    return true;
  }

  @Override
  public Serializable disassemble(Object value) throws HibernateException {
    return (EnumType[]) deepCopy(value);
  }

  @Override
  public Object assemble(Serializable cached, Object owner) throws HibernateException {
    return deepCopy(cached);
  }

  @Override
  public Object replace(Object original, Object target, Object owner) throws HibernateException {
    return deepCopy(original);
  }

}
