/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template.listener;

import io.rchemist.common.persistence.jpa.domain.template.Version;
import io.rchemist.common.util.TSIDUtil;
import jakarta.persistence.PrePersist;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class VersionListener {

  @PrePersist
  public void preSave(Object entity) {
    if (entity instanceof Version<?> versionEntity) {
      if(StringUtils.isBlank(versionEntity.getVersion())){
        versionEntity.setVersion(TSIDUtil.tsId());
      }
    }
  }

}
