/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.annotation;

import io.rchemist.common.transformer.IndexFieldClassTransformer;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * jpa의 jakarta.persistence.@Index 는 TYPE의 TABLE의 하위 속성으로만 정의할 수 있기 때문에
 * TemplateClass로 weave 된 경우, weave된 필드에는 인덱스를 적용하기 어려운 문제가 있다.
 * @IndexField를 사용하면 weave 된 필드에서 인덱스를 정의할 수 있다.
 *
 * @see {@link IndexFieldClassTransformer}
 *
 **/
@Target({ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface IndexField {

  /**
   * 인덱스가 생성될 때 DB 에 저장되는 이름이다.
   * @return
   */
  String name() default "";

  /**
   * Entity 의 Property name 이 아니라 실제 DB 컬럼명을 나열한다.
   * 필드가 여러개 있을 때 , 로 구분해 입력한다.
   * CREATED_BY, CREATED_AT 과 같은 식으로 입력해야 한다.
   * @return
   */
  String columnList() default "";

  /**
   * Entity 의 Property name 이 아니라 실제 DB 컬럼명을 나열한다.
   * @return
   */
  // 기존 @Index 와 호환을 위해 추가한 필드
  String[] columnNames() default {};

  // 필드가 둘 이상일 때 유니크할 수 있다.
  boolean unique() default false;


}
