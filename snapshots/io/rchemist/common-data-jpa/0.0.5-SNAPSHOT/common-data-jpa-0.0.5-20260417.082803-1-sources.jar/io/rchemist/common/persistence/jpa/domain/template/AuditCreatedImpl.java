/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.template.listener.AuditCreatedListener;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import java.io.Serializable;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Searchable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(AuditCreated.class)
@EntityListeners(AuditCreatedListener.class)
@Getter
@Setter
public class AuditCreatedImpl implements Serializable, EnhancedTemplate, Comparable<AuditCreated<?>> {

  @Column(name = "DATE_CREATED", updatable = false)
  @IndexField
  @Description(name = "생성일", comment = "생성일")
  @GenericField(searchable = Searchable.YES, sortable = Sortable.YES)
  @AdminField(name = "AuditableCreated_CreatedAt", propertyName = "createdAt", order = 200
    , readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS)
    , fieldType = PresentationFieldType.DATETIME, headerField = @HeaderField(order = Integer.MAX_VALUE)
    , modifiableType = ModifiableType.MODIFY_ONLY)
  protected Instant createdAt;

  @Column(name = "CREATED_BY", updatable = false)
  @IndexField
  @GenericField(searchable = Searchable.YES, sortable = Sortable.YES)
  @AdminField(name = "AuditableCreated_CreatedBy", propertyName = "createdBy", order = 200, readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS), fieldType = PresentationFieldType.STRING, modifiableType = ModifiableType.MODIFY_ONLY)
  @Description(name = "생성자", comment = "생성자의 User ID")
  protected String createdBy;

  @Column(name = "CREATED_BY_USER", updatable = false)
  @Description(name = "생성자 유형", comment = "생성자가 관리자인지 Customer 인지")
  protected String createdByUserType;

  @JsonIgnore
  public AuditUserType getCreatedByUserType() {
    return EnumTypeUtil.getEnumType(AuditUserType.class, createdByUserType);
  }

  public void setCreatedByUserType(AuditUserType createdByUserType) {
    if(createdByUserType == null){
      this.createdByUserType = null;
    }else{
      this.createdByUserType = createdByUserType.getType();
    }
  }

  @Override
  public int compareTo(AuditCreated<?> o) {
    if(o.getCreatedAt().isAfter(getCreatedAt())){
      return -1;
    }else if(o.getCreatedAt().equals(getCreatedAt())){
      return 0;
    }else{
      return 1;
    }
  }
}
