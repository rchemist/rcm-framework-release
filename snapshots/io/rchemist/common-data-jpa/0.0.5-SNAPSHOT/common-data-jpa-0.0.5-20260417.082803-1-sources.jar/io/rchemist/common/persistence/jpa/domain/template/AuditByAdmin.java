/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Admin과 Customer 가 동시에 관리할 수 있는 정보인 경우 해당 정보의 조작을 Admin이 했는지, 사용자가 했는지에 대해
 * Audit 이나 AuditCreated 외 추가 정보를 관리한다.
 *
 *
 **/

public interface AuditByAdmin<T> extends ClassTransformTarget {

  default String getAuditDescription() {
    throw new ClassTransformException();
  }

  default void setAuditDescription(String auditDescription) {
    throw new ClassTransformException();
  }

  default T withAuditDescription(String auditDescription) {
    setAuditDescription(auditDescription);
    return (T) this;
  }

}
