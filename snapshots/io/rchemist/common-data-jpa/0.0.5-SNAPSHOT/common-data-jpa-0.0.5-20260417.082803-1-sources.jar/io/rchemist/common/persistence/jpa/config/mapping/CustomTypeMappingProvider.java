/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.config.mapping;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.money.Money;
import io.rchemist.common.persistence.jpa.config.mapping.type.EnumTypeArrayTypeConverter;
import io.rchemist.common.persistence.jpa.config.mapping.type.EnumTypeConverter;
import io.rchemist.common.persistence.jpa.config.mapping.type.MoneyConverter;
import io.rchemist.common.util.ExceptionUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javassist.ClassPool;
import javassist.LoaderClassPath;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.MappingException;
import org.hibernate.boot.spi.MetadataImplementor;
import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.SimpleValue;
import org.hibernate.mapping.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Component
@Slf4j
public class CustomTypeMappingProvider extends AbstractMappingProvider {

  private static final int MAX_CASCADE_LEVEL = 10;

  private int order = 100;

  /**
   * CustomType 으로 정의된 필드에 @Type 어노테이션을 자동으로 붙인다
   *
   * Hibernate의 PersistenceClass 의 모든 필드를 확인하여 해당 필드가 지정된 타입으로 정의된 경우
   * 자동으로 @Type 어노테이션을 붙여 SessionFactory의 metadata에 저장한다.
   * Hibernate가 bootstrap 될 때, Entity 를 DB에 반영하기 전에 처리된다.
   * @param metadata
   * @param defaultBuilder
   * @param clazz
   * @return
   */
  @Override
  public void transformPersistentClass(MetadataImplementor metadata, SessionFactoryBuilderImplementor defaultBuilder, PersistentClass clazz) {
    ClassPool classPool = ClassPool.getDefault();
    Map<String, Class<?>> fields;

    try {
      classPool.appendClassPath(new LoaderClassPath(Class.forName(clazz.getClassName()).getClassLoader()));
      fields = getFieldInformation(0, classPool, clazz.getClassName(), "", new HashMap<String, Class<?>>());

      for (Map.Entry<String, Class<?>> entry : fields.entrySet()) {
        try {
          Property prop = clazz.getProperty(entry.getKey());
          Map<String, Property> props = getComponentProperties(new HashMap<>(), "", prop);
          for (Map.Entry<String, Property> propertyEntry : props.entrySet()) {
            String propertyName = propertyEntry.getKey();
            Property property = propertyEntry.getValue();
            Value value = property.getValue();
            if (fields.containsKey(propertyName)) {
              Class typeClass = fields.get(propertyName);

              if(typeClass.getCanonicalName().endsWith("[]")){
                // 배열이다
                Class arrayType = Class.forName(StringUtils.substringBefore(typeClass.getCanonicalName(), "[]"));

                if(EnumType.class.isAssignableFrom(arrayType)){
                  // enumType 배열이다. 관련 처리를 하자.
                  ((SimpleValue) value).setTypeName(EnumTypeArrayTypeConverter.class.getName());

                  Properties properties = new Properties();
                  properties.put(EnumTypeArrayTypeConverter.PARAMETER_CLASS_NAME +propertyName, typeClass.getName());
                  ((SimpleValue) value).setTypeParameters(properties);

                }else{
                  if (typeClass.equals(String[].class)) {
                    // ((SimpleValue) value).setTypeName(StringArrayTypeConverter.class.getName());
                  }
                }
              } else {
                if (EnumType.class.isAssignableFrom(typeClass)) {
                  // enumType이다. 관련 처리를 하자.
                  ((SimpleValue) value).setTypeName(EnumTypeConverter.class.getName());

                  Properties properties = new Properties();
                  properties.put(EnumTypeConverter.PARAMETER_CLASS_NAME +propertyName, typeClass.getName());
                  ((SimpleValue) value).setTypeParameters(properties);

                } else if(Money.class.isAssignableFrom(typeClass)){
                  ((SimpleValue) value).setTypeName(MoneyConverter.class.getName());

                  Properties properties = new Properties();
                  properties.put(EnumTypeConverter.PARAMETER_CLASS_NAME +propertyName, typeClass.getName());
                  ((SimpleValue) value).setTypeParameters(properties);
                }
              }
            }
          }
        } catch (MappingException mappingException) {
          // nothing
          if(log.isDebugEnabled()){
            ExceptionUtil.printException(mappingException);
          }
        }


      }
    } catch (ClassNotFoundException e) {
      ExceptionUtil.printStackTrace(e);
    }
  }

  @Override
  protected Integer getMaxCascadeLevel() {
    return MAX_CASCADE_LEVEL;
  }

  @Override
  public int getOrder() {
    return order;
  }

  public void setOrder(int order) {
    this.order = order;
  }
}
