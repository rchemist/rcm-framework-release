/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.bridge;

import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import org.hibernate.search.mapper.pojo.bridge.ValueBridge;
import org.hibernate.search.mapper.pojo.bridge.runtime.ValueBridgeFromIndexedValueContext;
import org.hibernate.search.mapper.pojo.bridge.runtime.ValueBridgeToIndexedValueContext;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class SiteTypeValueBridge implements ValueBridge<SiteType, String> {

  @Override
  public String toIndexedValue(SiteType enumType,
      ValueBridgeToIndexedValueContext valueBridgeToIndexedValueContext) {
    return enumType == null ? null : enumType.getType();
  }

  @Override
  public SiteType fromIndexedValue(String value, ValueBridgeFromIndexedValueContext context) {
    return value == null ? null : EnumTypeUtil.getEnumType(SiteType.class, value);
  }
}