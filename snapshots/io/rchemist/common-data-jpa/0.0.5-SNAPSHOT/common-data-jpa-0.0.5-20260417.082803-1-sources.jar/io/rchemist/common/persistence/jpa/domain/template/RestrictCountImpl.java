/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(RestrictCount.class)
@Getter
@Setter
public class RestrictCountImpl implements EnhancedTemplate {

  @Column(name = "MAX_COUNT")
  @Description(name = "최대값", comment = "최대 몇번까지 실행할 수 있는지")
  protected Integer maxCount;

  @Column(name = "MAX_COUNT_PER_DAY")
  @Description(name = "하루 최대값", comment = "하루에 최대 몇번까지 실행할 수 있는지")
  protected Integer maxCountPerDay;

  @Column(name = "MAX_COUNT_PER_CUSTOMER")
  @Description(name = "고객당 최대값", comment = "고객당 최대 몇번까지 실행할 수 있는지")
  protected Integer maxCountPerCustomer;

  @Column(name = "MAX_COUNT_PER_CUSTOMER_PER_DAY")
  @Description(name = "고객당 하루 최대값", comment = "고객당 하루 최대 몇번까지 실행할 수 있는지")
  protected Integer maxCountPerCustomerPerDay;

  public void setMaxCountPerDay(Integer maxCountPerDay) {
    if(maxCountPerDay != null){
      if(maxCount != null && maxCount < maxCountPerDay){
        maxCountPerDay = maxCount;
      }
    }
    this.maxCountPerDay = maxCountPerDay;
  }

  public void setMaxCountPerCustomer(Integer maxCountPerCustomer) {
    if(maxCountPerCustomer != null){
      if(maxCount != null && maxCount < maxCountPerCustomer){
        maxCountPerCustomer = maxCount;
      }
    }

    this.maxCountPerCustomer = maxCountPerCustomer;
  }

  public void setMaxCountPerCustomerPerDay(Integer maxCountPerCustomerPerDay) {
    if(maxCountPerCustomerPerDay != null){
      if(maxCount != null && maxCount < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCount;
      }
      if(maxCountPerDay != null && maxCountPerDay < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCountPerDay;
      }
    }
    this.maxCountPerCustomerPerDay = maxCountPerCustomerPerDay;
  }

  public Integer getMaxCountPerDay() {
    if(maxCountPerDay != null){
      if(maxCount != null && maxCount < maxCountPerDay){
        maxCountPerDay = maxCount;
      }
    }
    return maxCountPerDay;
  }

  public Integer getMaxCountPerCustomer() {
    if(maxCountPerCustomer != null){
      if(maxCount != null && maxCount < maxCountPerCustomer){
        maxCountPerCustomer = maxCount;
      }
    }
    return maxCountPerCustomer;
  }

  public Integer getMaxCountPerCustomerPerDay() {
    if(maxCountPerCustomerPerDay != null){
      if(maxCount != null && maxCount < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCount;
      }
      if(maxCountPerDay != null && maxCountPerDay < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCountPerDay;
      }
    }
    return maxCountPerCustomerPerDay;
  }

}
