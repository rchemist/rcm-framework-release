/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.sync.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
public abstract class AbstractSyncInitializer implements ApplicationListener<ApplicationReadyEvent> {

  protected final SyncStatusService syncStatusService;

  protected AbstractSyncInitializer(SyncStatusService syncStatusService) {
    this.syncStatusService = syncStatusService;
  }

  // 싱크 initializer 를 식별하기 위한 ID 를 반드시 입력해야 한다.
  // DB에서 unique key로 사용되므로 가급적 영문으로 정의한다.
  protected abstract String getSyncStatusId();

  // 싱크 시간을 설정하면 해당 시간이 지나면 다시 싱크한다는 뜻이다. 이 값이 null 이면 한번 싱크하고 나면 그 이후로는 처리하지 않는다는 뜻이다.
  protected Long getSyncInterval() {
    return null;
  }

  // 이 메시지를 설정하면 싱크가 이미 된 상태일 때 메시지를 로그에 출력한다.
  protected String getAlreadySyncedMessage() {
    return null;
  }

  // 싱크 처리를 위해 필요한 로직을 반드시 정의해야 한다.
  protected abstract void initialize() throws Exception;

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    String syncStatusId = getSyncStatusId();
    Long interval = getSyncInterval();

    if (syncStatusService.hasSynced(syncStatusId, interval)) {
      String alreadySyncedMessage = getAlreadySyncedMessage();
      if (StringUtils.isNotEmpty(alreadySyncedMessage)) {
        log.info(alreadySyncedMessage);
      }
      return;
    }

    try {
      initialize();
      syncStatusService.sync(syncStatusId);
    } catch (Exception e) {
      syncStatusService.fail(syncStatusId);
      log.error("Failed to initialize sync for {}", syncStatusId, e);
    }
  }


}