/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.Column;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.engine.backend.types.Searchable;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(AliasGroup.class)
@Getter
@Setter
public class AliasGroupImpl implements EnhancedTemplate {

  @Column(name = "ALIAS_GROUP_KEY")
  @KeywordField(searchable = Searchable.YES, sortable = Sortable.YES)
  @Description(name = "ALIAS GROUP KEY", comment = "중복 가능한 ALIAS 를 지정할 때 사용한다")
  protected String aliasGroup;

  @GenericField(name = "aliasGroup")
  public List<String> getAliases(){
    if(StringUtils.isEmpty(aliasGroup))
      return null;
    // return nonModifiable
    return List.of(StringUtil.splitWithNonEmpty(aliasGroup, ","));
  }

}
