/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 정렬 시 JOIN 방식을 설정하기 위한 설정 클래스
 * 
 * @author rchemist
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SortJoinConfiguration {
    
    /**
     * 정렬 대상 프로퍼티 경로 (예: "subject.major.name")
     */
    private String sortPath;
    
    /**
     * JOIN 타입 (기본값: LEFT)
     */
    @Builder.Default
    private JoinType joinType = JoinType.LEFT;
    
    /**
     * NULL 값 정렬 위치 (true: 처음, false: 마지막)
     */
    @Builder.Default
    private boolean nullsFirst = false;
    
    /**
     * 이 설정을 적용할지 여부
     */
    @Builder.Default
    private boolean enabled = true;
    
    /**
     * 정적 팩토리 메서드 - LEFT JOIN with nulls last
     */
    public static SortJoinConfiguration leftJoinNullsLast(String sortPath) {
        return SortJoinConfiguration.builder()
                .sortPath(sortPath)
                .joinType(JoinType.LEFT)
                .nullsFirst(false)
                .build();
    }
    
    /**
     * 정적 팩토리 메서드 - LEFT JOIN with nulls first
     */
    public static SortJoinConfiguration leftJoinNullsFirst(String sortPath) {
        return SortJoinConfiguration.builder()
                .sortPath(sortPath)
                .joinType(JoinType.LEFT)
                .nullsFirst(true)
                .build();
    }
    
    /**
     * 정적 팩토리 메서드 - INNER JOIN (기존 동작)
     */
    public static SortJoinConfiguration innerJoin(String sortPath) {
        return SortJoinConfiguration.builder()
                .sortPath(sortPath)
                .joinType(JoinType.INNER)
                .build();
    }
}