/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.template.listener.AuditUpdatedListener;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.EnumTypeUtil;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import java.io.Serializable;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Updated by kunner
 **/
@TemplateClass(AuditUpdatedNotIndexable.class)
@EntityListeners(AuditUpdatedListener.class)
@Getter
@Setter
public class AuditUpdatedNotIndexableImpl implements Serializable, EnhancedTemplate {

  @Column(name = "DATE_UPDATED")
  @Description(name = "수정일", comment = "수정일")
  protected Instant updatedAt;

  @Column(name = "UPDATED_BY")
  @Description(name = "수정자", comment = "수정자의 User ID")
  protected String updatedBy;

  @Column(name = "UPDATED_BY_USER", updatable = false)
  @Description(name = "수정자 유형", comment = "수정자가 관리자인지 Customer 인지")
  protected String updatedByUserType;

  public AuditUserType getUpdatedByUserType() {
    if(updatedByUserType == null) {
      return null;
    } else {
      return EnumTypeUtil.getEnumType(AuditUserType.class, updatedByUserType);
    }
  }

  public void setUpdatedByUserType(AuditUserType updatedByUserType) {
    if(updatedByUserType == null){
      this.updatedByUserType = null;
    }else{
      this.updatedByUserType = updatedByUserType.getType();
    }
  }
}
