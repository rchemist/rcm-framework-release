/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.ScaledNumberField;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(Amount.class)
@Getter
@Setter
public class AmountImpl implements EnhancedTemplate {


  @Column(name = "AMOUNT", precision = 19, scale = 5)
  @Description(name = "금액")
  @IndexField
  @ScaledNumberField(decimalScale = 5, sortable = Sortable.YES)
  protected BigDecimal amount;

  @Column(name = "CURRENCY_CODE")
  @Description(name = "통화코드", comment = "통화 코드, KRW/USD/EUR/JPY/...")
  @KeywordField
  protected String currencyCode;

}
