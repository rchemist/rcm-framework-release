/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import org.apache.commons.lang3.BooleanUtils;
import org.hibernate.annotations.Index;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@TemplateClass(SoftDelete.class)
public class HiddenImpl implements EnhancedTemplate {

  @Column(name = "IS_HIDDEN")
  @Description(name = "숨김 여부", comment = "숨김 여부")
  @GenericField(sortable = Sortable.YES)
  @Index(name = "HIDDEN_IS_HIDDEN_INDEX", columnNames = {"IS_HIDDEN"})    // Class Transform 을 이용한 @IndexField 를 사용해서는 안 된다.
  protected Boolean hidden = false;

  public boolean isHidden(){
    return BooleanUtils.toBooleanDefaultIfNull(hidden, false);
  }

  public void setHidden(Boolean hidden){
    this.hidden = BooleanUtils.toBooleanDefaultIfNull(hidden, false);
  }

}
