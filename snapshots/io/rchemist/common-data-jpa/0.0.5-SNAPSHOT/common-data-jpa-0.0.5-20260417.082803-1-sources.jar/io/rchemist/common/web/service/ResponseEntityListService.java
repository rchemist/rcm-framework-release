/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.persistence.domain.data.SortedPriority;
import io.rchemist.common.persistence.jpa.config.persistence.PlatformSessionFactoryBuilderFactory;
import io.rchemist.common.persistence.jpa.domain.template.Priority;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.search.data.query.QuerySpecification;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.common.web.service.data.HasIdEntity;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.common.web.service.extension.ResponseListExtensionManager;
import io.rchemist.common.web.service.type.EntityViewType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.cache.Cache;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.jpa.AvailableHints;
import org.springframework.boot.logging.LogLevel;
import org.springframework.transaction.annotation.Transactional;

/**
 * CRUD, Search 모두를 지원하는 ResponseEntityList 서비스
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ResponseEntityListService<ENTITY extends HasIdEntity<ID>
    , VIEW extends HasIdEntity<ID>
    , CREATE_FORM extends CreateFormWrapper<CREATE_FORM>
    , UPDATE_FORM extends UpdateFormWrapper<UPDATE_FORM, ID>
    , SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>
    , ID extends Serializable
    , SERVICE_EXCEPTION extends ErrorTypeException> extends
    ResponseEntityService<ENTITY, VIEW, CREATE_FORM, UPDATE_FORM, SEARCH_FORM, ID, SERVICE_EXCEPTION>,
    ResponseListWrapperService<ENTITY, SEARCH_FORM, VIEW, ID, SERVICE_EXCEPTION> {

  String CACHE_KEY_SPLITTER = "_";
  String ADMIN_CACHE_KEY = "ADMIN";

  // @PersistenceContext 를 Service 별로 별도로 가져갈 수 있게 한다.
  EntityManager getEntityManager();

  default List<ID> getEntityIds(Class<ENTITY> entityClass, Class<ID> idClass, String idFieldName, SEARCH_FORM searchForm) throws SERVICE_EXCEPTION{

    CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
    CriteriaQuery<ID> query = builder.createQuery(idClass);
    Root<ENTITY> root = query.from(entityClass);

    query.select(root.get(idFieldName)).distinct(true);

    SearchContext<ENTITY, SEARCH_FORM> context = getSearchContext(searchForm);
    if (context instanceof CommonSearchContext<ENTITY,SEARCH_FORM> commonSearchContext) {
      QuerySpecification<ENTITY, SEARCH_FORM> specification = commonSearchContext.getSpecification();

      Predicate predicate = specification.toPredicate(root, query, builder);
      query.where(predicate);
      query.orderBy(builder.desc(root.get(idFieldName)));

      TypedQuery<ID> typedQuery = getEntityManager().createQuery(query);
      typedQuery.setHint(AvailableHints.HINT_CACHEABLE, true);
      typedQuery.setHint(AvailableHints.HINT_CACHE_REGION, "query." + entityClass.getSimpleName() + ".Id." + idFieldName);
      typedQuery.setMaxResults(10000);    // ID field 를 10k 건 이상 fetch 할 일은 없을 것이다.

      List<ID> ids = typedQuery.getResultList();
      return CollectionUtil.getDistinctList(ids);
    }

    throw new RuntimeException("ID 를 조회할 수 없습니다. getSearchContext 에서 반드시 CommonSearchContext 를 구현해야 합니다.");
  }

  /**
   * LocalCacheManager 를 이용한 ENTITY VIEW 캐싱 처리 사용 여부
   * @return
   */
  default boolean useEntityCache() {
    return getEntityCache() != null;
  }

  /**
   * Entity Cache 를 사용하려면 직접 생성한다.
   * @return
   */
  default Cache<String, VIEW> getEntityCache() {
    return null;
  }

  /**
   * LocalCacheManager 를 이용한 Search 결과 캐싱 처리 사용 여부
   * @return
   */
  default boolean useSearchResultCache() {
    return getSearchResultCache() != null;
  }

  /**
   * Search 결과 캐싱을 사용하려면 직접 생성한다.
   * @return
   */
  default Cache<String, ResponseListWrapperCache> getSearchResultCache() {
    return null;
  }

  @Override
  default EntityBean<?> getEntityBean(String entityClassName) {
    return PlatformSessionFactoryBuilderFactory.getRegisterEntityBean(entityClassName);
  }

  @Override
  default PageResult<ENTITY> getSearchResult(SEARCH_FORM searchForm) throws SERVICE_EXCEPTION {
    return ResponseEntityService.super.getSearchResult(searchForm);
  }

  default String getEntityCacheKey(Object id) {
    return getEntityCacheKey(id, EntityViewType.VIEW);
  }

  default String getEntityCacheKey(Object id, EntityViewType viewType) {
    if (WebRequestContext.getWebRequestContext().isAdmin()) {
      return getEntityCacheKey(id, viewType, true);
    } else {
      return getEntityCacheKey(id, viewType, false);
    }
  }

  default String getEntityCacheKey(Object id, EntityViewType viewType, boolean isAdmin) {
    String cacheKey = this.getClass().getSimpleName() + CACHE_KEY_SPLITTER + id + CACHE_KEY_SPLITTER + viewType.name();
    if (isAdmin) {
      return cacheKey + CACHE_KEY_SPLITTER + ADMIN_CACHE_KEY;
    }
    return cacheKey;
  }

  default void clearSearchResultCache() {
    // try 로 각 구문을 나눈 이유는, 하나가 실패해도 나머지가 계속 수행되게 하기 위함이다.

    try {
      if (useSearchResultCache()) {
        getSearchResultCache().clear();
      }
    }catch (Exception e) {
      // silent ignore
    }

    try {
      ResponseListExtensionManager.clearSearchResultCache();
    }catch (Exception e) {
      // silent ignore
    }
  }

  default void clearEntityCache(List<ID> ids) {
    for (ID id : ids) {
      // try 로 각 구문을 나눈 이유는, 하나가 실패해도 나머지가 계속 수행되게 하기 위함이다.
      clearEntityCache(id);
    }
  }

  default void clearEntityCache(ID id) {
    if (useEntityCache()) {
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.VIEW, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.VIEW, false));
      }catch (Exception e) {
        // silent ignore
      }
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.LIST, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.LIST, false));
      }catch (Exception e) {
        // silent ignore
      }
      try {
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.DETAIL, true));
        getEntityCache().remove(getEntityCacheKey(id, EntityViewType.DETAIL, false));
      }catch (Exception e) {
        // silent ignore
      }
    }
    try {
      ResponseListExtensionManager.clearEntityCache(id);
    }catch (Exception e) {
      // silent ignore
    }
  }

  @Override
  default VIEW findViewById(ID id) throws SERVICE_EXCEPTION {
    return findCachedViewById(id, EntityViewType.VIEW);
  }

  @Override
  default VIEW findViewById(ID id, EntityViewType entityViewType) throws SERVICE_EXCEPTION {
    return findCachedViewById(id, entityViewType);
  }

  default VIEW findCachedViewById(ID id, EntityViewType entityViewType) throws SERVICE_EXCEPTION {

    String cacheKey = null;

    if (useEntityCache()) {
      cacheKey = getEntityCacheKey(id, entityViewType);

      if (getEntityCache().containsKey(cacheKey)) {
        VIEW view = getEntityCache().get(cacheKey);
        return overrideView(view, entityViewType);
      }
    }

    // 캐싱된 값이 없으면 새로 조회해 VIEW 를 만든다.
    VIEW view = getView(findEntityById(id), entityViewType == null ? EntityViewType.LIST : entityViewType);

    if (useEntityCache()) {
      getEntityCache().put(cacheKey, view);
    }

    return overrideView(view, entityViewType);
  }



  @Override
  default ENTITY save(ENTITY entity) {
    try {
      return ResponseEntityService.super.save(entity);
    } finally {
      try {
        clearEntityCache(entity.getId());
        clearSearchResultCache();
      } catch (Exception e) {
        // just ignore
        ExceptionUtil.printException(e);
      }
    }
  }

  @Override
  default List<ENTITY> saveAll(List<ENTITY> entities) {
    if (CollectionUtils.isEmpty(entities))
      return new ArrayList<>();
    try {
      return ResponseEntityService.super.saveAll(entities);
    } finally {
      List<ID> list = new ArrayList<>();
      for (ENTITY entity : entities) {
        ID id = entity.getId();
        list.add(id);
      }
      clearEntityCache(list);
      clearSearchResultCache();
    }
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default boolean delete(ENTITY entity) {
    try {
      return ResponseEntityService.super.delete(entity);
    } finally {
      clearEntityCache(entity.getId());
      clearSearchResultCache();
    }
  }

  @Override
  default VIEW create(CREATE_FORM createForm) throws SERVICE_EXCEPTION {
    VIEW view = ResponseEntityService.super.create(createForm);
    if (useSearchResultCache()) {
      getSearchResultCache().clear();
    }
    view = overrideView(view, createForm.getViewType() == null ? EntityViewType.VIEW : createForm.getViewType());
    return view;
  }

  @Override
  default VIEW update(UPDATE_FORM form) throws SERVICE_EXCEPTION {
    VIEW view = ResponseEntityService.super.update(form);
    view = overrideView(view, form.getViewType() == null ? EntityViewType.VIEW : form.getViewType());
    clearEntityCache(view.getId());
    clearSearchResultCache();
    return view;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default List<VIEW> createEntities(List<CREATE_FORM> createForms) throws SERVICE_EXCEPTION {
    List<VIEW> result = new ArrayList<>();
    List<ENTITY> entities = new ArrayList<>();
    for (CREATE_FORM createForm : CollectionUtils.emptyIfNull(createForms)) {
      ENTITY entity = createEntity(createForm);
      entities.add(entity);
    }

    entities = saveAll(entities);

    for (ENTITY entity : entities) {
      result.add(getView(entity, EntityViewType.VIEW));
    }

    // post create
    if (entities.size() == createForms.size()) {
      for (int i = 0; i < entities.size(); i++) {
        ENTITY entity = entities.get(i);
        CREATE_FORM createForm = createForms.get(i);
        postCreate(entity, createForm);
      }
    }

    return result;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default List<VIEW> updateEntities(List<UPDATE_FORM> updateForms) throws SERVICE_EXCEPTION {
    List<VIEW> result = new ArrayList<>();
    List<ENTITY> entities = new ArrayList<>();
    for (UPDATE_FORM updateForm : CollectionUtils.emptyIfNull(updateForms)) {
      ENTITY entity = ResponseEntityService.super.findEntityById(updateForm.getId());
      entity = updateEntity(entity, updateForm);
      entities.add(entity);
    }

    entities = saveAll(entities);

    // post update
    for (ENTITY entity : entities) {
      for (UPDATE_FORM updateForm : CollectionUtils.emptyIfNull(updateForms)) {
        if (updateForm.getId().equals(entity.getId())) {
          postUpdate(entity, updateForm);
          break;
        }
      }
    }

    return result;
  }

  /**
   * createResponseListWrapper 에서 사용할 searchForm 을 override 할 수 있다.
   * 검색폼에 고정적으로 추가할 파라미터가 있거나, 기타 검색폼을 변경할 필요가 있을 때 사용한다.
   *
   * @param searchForm
   * @return
   */
  default SEARCH_FORM overrideSearchForm(SEARCH_FORM searchForm) {
    return searchForm;
  }

  @Override
  default ResponseData<Long> getQuerySearchCount(SEARCH_FORM searchForm) {
    return ResponseHelper.result(() -> ResponseEntityService.super.getSearchCount(searchForm));
  }

  @Override
  default ResponseListWrapper<VIEW, SEARCH_FORM> createResponseListWrapper(SEARCH_FORM searchForm) {

    String cacheKey = null;

    searchForm = overrideSearchForm(searchForm);
    EntityViewType entityViewType = searchForm.getEntityViewType();
    boolean cacheEnabled = useSearchResultCache() && !searchForm.isIgnoreCache();

    if (cacheEnabled) {
      // 캐시를 확인하기 위해 seachForm 을 변조하지 않도록 deepCopy 로 사용한다.
      SearchContext<ENTITY, SEARCH_FORM> context;
      try {
        context = getSearchContext(searchForm.deepCopy(false));
      } catch (ErrorTypeException e) {
        ResponseListWrapper<VIEW, SEARCH_FORM> wrapper = new ResponseListWrapper<>();
        wrapper.setError(new ErrorDTO(e));
        return wrapper;
      }

      // cache enabled 정보를 변경한다.
      cacheKey = context.getCacheKey(this.getClass().getSimpleName());    // Service 클래스 이름을 CacheKey prefix 로 사용한다.

      // 관리자용 list view 와 front 용 list view 를 구분해야 한다.
      if (WebRequestContext.getWebRequestContext().isAdmin()) {
        cacheKey = cacheKey + CACHE_KEY_SPLITTER + ADMIN_CACHE_KEY;
      }

      if (!context.isForceFetchFromDB()) {

        if (getSearchResultCache().containsKey(cacheKey)) {
          //noinspection unchecked
          ResponseListWrapperCache<VIEW, SEARCH_FORM, ID> listCache = (ResponseListWrapperCache<VIEW, SEARCH_FORM, ID>) getSearchResultCache().get(cacheKey);
          try {
            ResponseListWrapper<VIEW, SEARCH_FORM> cloned = listCache.getResponseListWrapper();
            if (CollectionUtils.isNotEmpty(listCache.getIdList())) {
              for (ID id: listCache.getIdList()) {
                // view 를 최신의 cache 로 확인한다.
                VIEW entityView = findCachedViewById(id, entityViewType);
                cloned.addListItem(entityView);
              }
            }
            return cloned;

          }catch (Exception e) {
            // just ignore, 에러가 난 경우 밑에서 다시 제대로 데이터를 만들고 캐시도 재설정 하기 때문에 그냥 skip 하는게 맞다.
            ExceptionUtil.printStackTrace(e);
          }
        }
      }

    }

    ResponseListWrapper<VIEW, SEARCH_FORM> wrapper = ResponseListWrapperService.super.createResponseListWrapper(searchForm);

    // 에러가 발생했다면 혹시 모를 list 를 모두 비운다.
    if (wrapper.isError() && !wrapper.isEmpty()) {
      wrapper = new ResponseListWrapper<VIEW, SEARCH_FORM>().withError(wrapper.getError());
      wrapper.setList(null);
    }

    if (!wrapper.isNull()) {
      // 에러가 아니거나 빈 값이 아닐 때만 캐싱 한다.
      if (cacheEnabled) {
        putSearchResultCache(wrapper, cacheKey);
      }
    }

    return wrapper;
  }

  /**
   * 검색 결과를 캐시로 저장하는 로직을 오버라이드 할 수 있다.
   * @param wrapper
   * @param cacheKey
   */
  default void putSearchResultCache(ResponseListWrapper<VIEW, SEARCH_FORM> wrapper, String cacheKey) {
    ResponseListWrapperCache<VIEW, SEARCH_FORM, ID> cacheItem = new ResponseListWrapperCache<>(
        wrapper);

    getSearchResultCache().put(cacheKey, cacheItem);
  }

  default DeleteForm<ID> preDeleteAllBySearchForm(DeleteForm<ID> idList, SEARCH_FORM searchForm) throws SERVICE_EXCEPTION {

    if (idList == null || idList.isEmpty() || searchForm == null) {
      return idList;
    }

    ResponseListData<VIEW, SEARCH_FORM> result = createResponseListData(searchForm);

    if (result.isEmpty()) {
      throw entityNotFoundException();
    }

    List<ID> ids = result.getData().stream().map(VIEW::getId).collect(Collectors.toList());

    return new DeleteForm<ID>()
        .withIds(ids)
        .withRevisionEntityName(idList.getRevisionEntityName())
        .withCause(idList.getCause());

  }

  default DeleteForm<ID> preDeleteAllBySearchForm(DeleteForm<ID> idList) throws SERVICE_EXCEPTION {
    return preDeleteAllBySearchForm(idList, preDeleteSearchForm(idList));
  }

  default SEARCH_FORM preDeleteSearchForm(DeleteForm<ID> idList) throws SERVICE_EXCEPTION {
    return null;
  }

  @Override
  default Integer deleteAll(DeleteForm<ID> deleteForm, Boolean batch) throws SERVICE_EXCEPTION {

    try {
      deleteForm = preDeleteAllBySearchForm(deleteForm);
    } catch (ErrorTypeException e) {
      throw new RuntimeException(e);
    }

    List<ENTITY> entities = new ArrayList<>();
    for (ID id : deleteForm.getIds()) {
      try {
        ENTITY entity = findEntityById(id);
        preDelete(entity);
        entities.add(entity);
      } catch (ErrorTypeException e) {
        throw new RuntimeException(e);
      }
    }

    int result = ResponseEntityService.super.deleteAll(deleteForm, batch);
    for (ENTITY entity : entities) {
      clearEntityCache(entity.getId());
      logEntityDeleteRevision(deleteForm.getRevisionEntityName(), entity);
      postDelete(entity, true);
    }
    clearSearchResultCache();
    return result;
  }

  @Override
  @Transactional(rollbackFor = ErrorTypeException.class)
  default Integer deleteAll(DeleteForm<ID> list) throws SERVICE_EXCEPTION {
    return deleteAll(list, true);
  }


  @Transactional(rollbackFor = ErrorTypeException.class)
  default ResponseData<Boolean> updateEntityPriorities(SortedPriority<ID> priorities) {
    return ResponseHelper.result(() -> {
      if (priorities == null || priorities.isEmpty()) {
        return false;
      }

      List<ENTITY> entities = new ArrayList<>();
      for (ID id : priorities.getIds()) {
        ENTITY entity = findEntityById(id);
        if (entity instanceof Priority<?> priority) {
          priority.setPriority(priorities.getPriority(id));
        }
        entities.add(entity);
      }

      saveAll(entities);

      return true;
    });
  }

  default Boolean clearCache() {
    try {
      if (useEntityCache()) {
        getEntityCache().clear();
      }
      if (useSearchResultCache()) {
        getSearchResultCache().clear();
      }
      return true;
    }catch (Exception e) {
      ExceptionUtil.printLog(e.getMessage(), LogLevel.ERROR);
      return false;
    }
  }
}
