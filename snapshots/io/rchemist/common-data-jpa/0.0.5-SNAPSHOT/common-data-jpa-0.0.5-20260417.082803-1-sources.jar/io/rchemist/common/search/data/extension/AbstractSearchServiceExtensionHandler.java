/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.HibernateSearchContext;
import io.rchemist.common.search.data.HibernateSearchPredicateHolder;
import io.rchemist.common.search.data.query.CombinedConditionItem;
import io.rchemist.common.search.data.query.QueryConditionItem;
import io.rchemist.common.search.data.query.QuerySpecificationResultHolder;
import io.rchemist.common.search.data.query.SingleConditionItem;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.search.engine.search.predicate.dsl.SearchPredicateFactory;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractSearchServiceExtensionHandler implements SearchServiceExtensionHandler {

  @Override
  public <T, S extends SearchFormWrapper> ExtensionResultStatusType addHibernateSearchPredicates(HibernateSearchContext<T, S> context,
      ExtensionResultHolder<HibernateSearchPredicateHolder> erh) {

    Class<?> entityClass = context.getEntityClass();
    SearchFormWrapper<?> searchForm = context.getSearchForm();
    SearchPredicateFactory factory = context.getFactory();
    String[] explicitFilterNames = context.getExplicitFilterNames();

    HibernateSearchPredicateHolder holder = erh.getResult();

    int previousSize = holder.getTotalPredicateCount();

    try{
      holder = addHibernateSearchPredicates(entityClass, searchForm, explicitFilterNames, factory, holder);
      erh.setResult(holder);
    }catch (Exception e){
      e.printStackTrace();
    }

    int currentSize = holder.getTotalPredicateCount();

    return (previousSize == currentSize) ? ExtensionResultStatusType.NOT_HANDLED : ExtensionResultStatusType.HANDLED_CONTINUE;
  }

  protected abstract HibernateSearchPredicateHolder addHibernateSearchPredicates(Class<?> entityClass,
      SearchFormWrapper<?> searchForm,
      String[] explicitFilterNames,
      SearchPredicateFactory factory, HibernateSearchPredicateHolder predicates);


  @Override
  public <T extends Serializable> ExtensionResultStatusType getPagingSortProperties(
      Class<T> entityClass, ExtensionResultHolder<List<String>> erh, List<String> sortList) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  protected List<String> getAlternateSortProperties(List<String> list, String propertyName, String alternativeName) {
    if(CollectionUtils.isEmpty(list))
      return list;

    List<String> newList = new ArrayList<>();
    for(String name : list){

      boolean checked = name.startsWith(propertyName + " ");    // name ASC 또는 name DESC 형태로 넘어 올 것이다.

      if(checked){
        String sortType = StringUtils.substringAfter(name, " ");
        newList.add(alternativeName + " " + sortType);
      }else{
        newList.add(name);
      }

    }
    return newList;
  }

  @Override
  public ExtensionResultStatusType addQueryPredicates(Class<?> entityClass,
      SearchFormWrapper<?> searchForm,
      ExtensionResultHolder<QuerySpecificationResultHolder> erh) {

    if (ClassTransformTarget.class.isAssignableFrom(entityClass)) {

      if(erh.getResult() == null){
        erh.setResult(QuerySpecificationResultHolder.createBlankResult());
      }

      if (searchForm instanceof AbstractSearchForm<?> form) {

        QueryConditionResult queryConditionResult = createSearchQueryItem(entityClass, form);

        if (queryConditionResult != null && !queryConditionResult.isBlank()) {
          for (ConditionOperatorType operatorType : queryConditionResult.getQueryItemMap().keySet()) {
            List<QueryConditionItem> items = queryConditionResult.getQueryItemMap().get(operatorType);
            if (CollectionUtils.isNotEmpty(items)) {
              erh.getResult().addCondition(operatorType, items.toArray(new QueryConditionItem[0]));
            }
          }
          return ExtensionResultStatusType.HANDLED_CONTINUE;
        }

      }

    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * ConditionOperatorType 을 searchForm 에서 가져오거나 명시적으로 지정할 수도 있다.
   * TenantAlias 와 같이 시스템 속성에 대한 검색은 searchForm 의 속성을 따라가야 한다.
   *
   * @param searchForm
   * @return
   */
  protected ConditionOperatorType getConditionOperatorType(SearchFormWrapper<?> searchForm){
    return searchForm.getOperator();
  }

  /**
   * SearchForm 기반일 때 사용한다.
   * @param entityClass
   * @param searchForm
   * @return
   */
  protected abstract QueryConditionResult createSearchQueryItem(Class<?> entityClass, AbstractSearchForm<?> searchForm);

  protected QueryConditionItem[] createQueryItems(QueryConditionItem... items){
    return items;
  }

  protected QueryConditionItem[] createEqualQueryItems(String propertyName, Object value){
    return createQueryItems(SingleConditionItem.equal(propertyName, value));
  }

  protected QueryConditionItem[] createQueryItems(String propertyName, QueryConditionType conditionType, Object value){
    return createQueryItems(new SingleConditionItem(propertyName, conditionType, value));
  }

  protected String getValidSearchValue(String value){
    return StringUtils.isBlank(value) ? null : value;
  }

  protected QueryConditionResult getQueryConditionResult(SearchForm searchForm, String filterName, QueryConditionType defaultQueryCondition) {
    QueryConditionResult result = new QueryConditionResult();
    return getQueryConditionResult(result, searchForm, filterName, defaultQueryCondition);
  }

  protected QueryConditionResult getQueryConditionResult(QueryConditionResult result, SearchForm searchForm, String filterName, QueryConditionType defaultQueryCondition) {

    if (result == null)
      result = new QueryConditionResult();

    if (searchForm.hasFilter(filterName)) {

      for (Entry<ConditionOperatorType, FilterItem[]> filters : searchForm.getFilters().entrySet()) {

        ConditionOperatorType operator = filters.getKey();

        for (FilterItem filter : filters.getValue()) {

          if (filter.getName().equals(filterName)) {

            if (filter.hasSubFilters()) {

              for (Entry<ConditionOperatorType, FilterItem[]> entry : filter.getSubFilters().entrySet()) {

                ConditionOperatorType subOperator = entry.getKey();
                List<QueryConditionItem> items = new ArrayList<>();

                for(FilterItem item : entry.getValue()) {
                  QueryConditionType condition = item.getQueryConditionType();
                  if (condition == null) {
                    condition = defaultQueryCondition;
                  }
                  items.addAll(Arrays.asList(createQueryItems(item.getName(), condition, item.getValue())));
                }

                CombinedConditionItem item;

                if (subOperator == ConditionOperatorType.OR) {
                  // OR
                  item = CombinedConditionItem.or(items.toArray(new QueryConditionItem[0]));
                } else {
                  // AND
                  item = CombinedConditionItem.and(items.toArray(new QueryConditionItem[0]));
                }

                result.addQueryItems(operator, item);

              }

            } else {
              QueryConditionItem[] queryItems;
              if (searchForm.isExactMatch()) {
                queryItems = createEqualQueryItems(filter.getName(), filter.getValue());
              } else {
                QueryConditionType condition = filter.getQueryConditionType();
                if (condition == null) {
                  condition = defaultQueryCondition;
                }
                queryItems = createQueryItems(filter.getName(), condition, filter.getValue());
              }
              result.addQueryItems(operator, queryItems);
            }

          }

        }
      }

      return result;

    }
    return null;
  }

}
