/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.jpa.domain.template;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.transformer.TemplateClass;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(FullAddress.class)
@Getter
@Setter
public class FullAddressImpl implements EnhancedTemplate {

  @Column(name = "STATE")
  @IndexField
  @GenericField(sortable = Sortable.YES)
  @Description(name = "시/도", comment = "시, 도 이름. 서울특별시/경기도/충청남도/...")
  protected String state;

  @Column(name = "CITY")
  @IndexField
  @GenericField(sortable = Sortable.YES)
  @Description(name = "시/군/구", comment = "시, 군, 구 이름.")
  protected String city;

  @Column(name = "ADDRESS1")
  @IndexField
  @GenericField(sortable = Sortable.YES)
  @Description(name = "도로명 주소", comment = "도로명 주소. 주소 1")
  protected String address1;

  @Column(name = "ADDRESS2")
  @Description(name = "세부 주소", comment = "도로명 주소 이후 세부 주소")
  protected String address2;

  @Column(name = "POSTAL_CODE")
  @IndexField
  @GenericField(sortable = Sortable.YES)
  @Description(name = "우편번호")
  protected String postalCode;

}
