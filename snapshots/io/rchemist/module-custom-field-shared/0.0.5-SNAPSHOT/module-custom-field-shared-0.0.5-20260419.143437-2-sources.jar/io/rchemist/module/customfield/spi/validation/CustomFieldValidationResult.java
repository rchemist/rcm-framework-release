/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.validation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Accumulator passed through the {@link CustomFieldValidator} pipeline.
 * Errors are collected, not thrown, so the caller can report all issues at
 * once.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class CustomFieldValidationResult {

  private final List<Error> errors = new ArrayList<>();

  public void reject(String code, String message) {
    errors.add(new Error(code, message));
  }

  public boolean isValid() {
    return errors.isEmpty();
  }

  public List<Error> getErrors() {
    return Collections.unmodifiableList(errors);
  }

  public int errorCount() {
    return errors.size();
  }

  /** Single error entry. */
  public static final class Error {
    private final String code;
    private final String message;

    public Error(String code, String message) {
      this.code = code;
      this.message = message;
    }

    public String getCode() {
      return code;
    }

    public String getMessage() {
      return message;
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof Error other)) return false;
      return Objects.equals(code, other.code) && Objects.equals(message, other.message);
    }

    @Override
    public int hashCode() {
      return Objects.hash(code, message);
    }

    @Override
    public String toString() {
      return code + ":" + message;
    }
  }
}
