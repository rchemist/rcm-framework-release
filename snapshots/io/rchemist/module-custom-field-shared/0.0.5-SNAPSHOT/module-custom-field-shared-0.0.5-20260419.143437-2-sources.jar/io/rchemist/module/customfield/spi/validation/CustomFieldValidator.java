/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.validation;

import io.rchemist.module.customfield.spi.CustomFieldDescriptor;

/**
 * Pipeline step for validating a raw custom-field value against a descriptor.
 * Steps are executed in {@link #order()} ascending.
 *
 * <p>A step reports failures by calling
 * {@link CustomFieldValidationResult#reject(String, String)}; a step MUST NOT
 * short-circuit on a single failure — let the whole pipeline run so that
 * aggregate error reporting works.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldValidator {

  int DEFAULT_ORDER = 1000;

  /**
   * Validate {@code rawValue} against {@code descriptor} and append any
   * errors to {@code result}.
   */
  void validate(CustomFieldDescriptor descriptor, String rawValue, CustomFieldValidationResult result);

  /** Pipeline position. Lower runs first. */
  default int order() {
    return DEFAULT_ORDER;
  }
}
