/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import io.rchemist.common.persistence.domain.annotation.Auditable;
import io.rchemist.common.persistence.domain.data.AuditDTO;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomOptionValueDTO implements Serializable, Auditable<CustomOptionValueDTO> {

  protected Long id;
  protected String alias;
  protected String name;
  protected String value;
  protected Integer priority;
  protected AuditDTO audit = new AuditDTO();

  public CustomOptionValueDTO withId(Long id) {
    this.id = id;
    return this;
  }

  public CustomOptionValueDTO withName(String name) {
    this.name = name;
    this.value = name;
    return this;
  }

  public CustomOptionValueDTO withValue(String value) {
    this.value = value;
    return this;
  }

  public CustomOptionValueDTO withAlias(String alias) {
    this.alias = alias;
    return this;
  }

  public CustomOptionValueDTO withPriority(Integer priority) {
    this.priority = priority;
    return this;
  }

  public Integer getPriority() {
    return (priority == null) ? 100 : priority;
  }
}
