/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.module.customfield.service.exception.CustomFieldErrorType;
import io.rchemist.module.customfield.service.exception.CustomFieldException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomFieldUpdateForm implements UpdateFormWrapper<CustomFieldUpdateForm, Long>
        , HasTenantAlias<CustomFieldUpdateForm>
        , HasId<CustomFieldUpdateForm>
        , HasNameDescription<CustomFieldUpdateForm>

{

  protected String defaultValue;

  protected String[] enumerationOptions;

  protected String enumerationData;

  protected ModifiableType modifiableType;

  protected String placeHolder;

  protected String helpText;

  protected String viewTab;

  protected String viewGroup;

  protected Integer order;

  protected Boolean headerField;

  protected Integer headerFieldOrder;

  protected Boolean searchable;

  protected Boolean sortable;

  protected Boolean required;

  protected String regexValidation;

  protected String errorMessage;

  protected String minLength;

  protected String maxLength;

  public boolean isChanged(){
    return StringUtil.isNotEmpty(getName(), getDescription(), defaultValue, enumerationData, placeHolder, helpText, viewTab, viewGroup, regexValidation, errorMessage, minLength, maxLength)
        || headerField != null
        || searchable != null
        || sortable != null
        || required != null
        || modifiableType != null
        || order != null
        || ArrayUtils.isNotEmpty(enumerationOptions);
  }

  public CustomFieldUpdateForm withDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  public CustomFieldUpdateForm withEnumerationOptions(String[] enumerationOptions) {
    this.enumerationOptions = enumerationOptions;
    return this;
  }

  public CustomFieldUpdateForm withEnumerationData(String enumerationData) {
    this.enumerationData = enumerationData;
    return this;
  }

  public CustomFieldUpdateForm withPlaceHolder(String placeHolder) {
    this.placeHolder = placeHolder;
    return this;
  }

  public CustomFieldUpdateForm withHelpText(String helpText) {
    this.helpText = helpText;
    return this;
  }

  public CustomFieldUpdateForm withViewTab(String viewTab) {
    this.viewTab = viewTab;
    return this;
  }

  public CustomFieldUpdateForm withViewGroup(String viewGroup) {
    this.viewGroup = viewGroup;
    return this;
  }

  public CustomFieldUpdateForm withHeaderField(Boolean headerField) {
    this.headerField = headerField;
    return this;
  }

  public CustomFieldUpdateForm withHeaderFieldOrder(Integer headerFieldOrder) {
    this.headerFieldOrder = headerFieldOrder;
    return this;
  }

  public CustomFieldUpdateForm withSearchable(Boolean searchable) {
    this.searchable = searchable;
    return this;
  }

  public CustomFieldUpdateForm withSortable(Boolean sortable) {
    this.sortable = sortable;
    return this;
  }

  public CustomFieldUpdateForm withRegexValidation(String regexValidation) {
    this.regexValidation = regexValidation;
    return this;
  }

  public CustomFieldUpdateForm withErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public CustomFieldUpdateForm withRequired(Boolean required) {
    this.required = required;
    return this;
  }

  public CustomFieldUpdateForm withModifiableType(
      ModifiableType modifiableType) {
    this.modifiableType = modifiableType;
    return this;
  }

  public CustomFieldUpdateForm withOrder(Integer order) {
    this.order = order;
    return this;
  }

  public CustomFieldUpdateForm withMinLength(String minLength) {
    this.minLength = minLength;
    return this;
  }

  public CustomFieldUpdateForm withMaxLength(String maxLength) {
    this.maxLength = maxLength;
    return this;
  }

  public void validate() throws CustomFieldException {
    if(getId() == null)
      throw new CustomFieldException(CustomFieldErrorType.ID_NOT_FOUND);

    if(StringUtils.isEmpty(getTenantAlias()))
      throw new CustomFieldException(CustomFieldErrorType.TENANT_NOT_FOUND);

    if(!isChanged())
      throw new CustomFieldException(CustomFieldErrorType.NOT_CHANGED);
  }

}
