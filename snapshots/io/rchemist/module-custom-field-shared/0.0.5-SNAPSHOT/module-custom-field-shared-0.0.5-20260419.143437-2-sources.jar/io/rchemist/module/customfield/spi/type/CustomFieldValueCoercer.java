/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.type;

/**
 * SPI for converting custom field values between the persisted string form
 * and the typed runtime form. Keeps the storage layer string-only so that
 * key-value / document / relational adapters can all share a persistence
 * contract.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldValueCoercer {

  /**
   * Convert the persisted string form into the typed value. Implementations
   * must treat {@code null} and {@code ""} as "absent" and return {@code null}.
   *
   * @param raw the raw stored string
   * @return the coerced typed value, or {@code null} if raw is null/empty
   * @throws CoercionException when raw is non-empty but cannot be coerced
   */
  Object toValue(String raw) throws CoercionException;

  /**
   * Convert a typed value back into its persisted string form. {@code null}
   * input yields {@code null} output.
   */
  String toString(Object value);

  /**
   * Default pass-through coercer: both directions return the input unchanged.
   * Useful for STRING / TEXT / HTML / EMAIL types whose storage form is the
   * same as the runtime form.
   */
  CustomFieldValueCoercer STRING_PASSTHROUGH = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) {
        return null;
      }
      return raw;
    }

    @Override
    public String toString(Object value) {
      return value == null ? null : value.toString();
    }
  };

  /** Thrown when a raw value cannot be coerced into the target type. */
  class CoercionException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public CoercionException(String message) {
      super(message);
    }

    public CoercionException(String message, Throwable cause) {
      super(message, cause);
    }
  }
}
