/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.type;

/**
 * Extension-open SPI representing a custom field value type.
 *
 * <p>Consumers register additional types via a Spring bean implementing this
 * interface. The default set is provided by
 * {@code StandardCustomFieldTypes} in the module implementation.
 *
 * <p>Design notes:
 * <ul>
 *   <li>Storage-agnostic: a type does not know about JPA/Mongo/Map.</li>
 *   <li>Serializable by convention: types are singletons identified by
 *       {@link #id()}; store the id, not the instance.</li>
 *   <li>Value coercion is delegated to {@link CustomFieldValueCoercer} so that
 *       a type definition can stay metadata-only.</li>
 * </ul>
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldValueType {

  /**
   * Stable identifier used for storage. Must be unique across the registry.
   * Conventionally ALL_CAPS_SNAKE_CASE (e.g. {@code "STRING"}, {@code "MONEY"}).
   */
  String id();

  /**
   * Human-readable display name (i18n key safe — ASCII).
   */
  String displayName();

  /**
   * Numeric sort order when listing types. Lower values appear first.
   */
  int order();

  /**
   * Coercer that converts between raw string form (how the value is stored by
   * key-value adapters) and the typed runtime form. A type MAY provide its own
   * specialised coercer; if {@code null} is returned, the default
   * pass-through coercer is used.
   */
  default CustomFieldValueCoercer coercer() {
    return CustomFieldValueCoercer.STRING_PASSTHROUGH;
  }
}
