/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.module.customfield.service.exception.CustomOptionErrorType;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.LinkedHashMap;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomOptionCreateForm implements Serializable, CreateFormWrapper<CustomOptionCreateForm> {

  @NotNull
  protected String tenantAlias;

  @NotNull
  protected String alias;

  @NotNull
  protected String name;

  protected String description;

  protected Boolean systemOption = false;

  protected LinkedHashMap<String, String> values = new LinkedHashMap<>();

  public CustomOptionCreateForm withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public CustomOptionCreateForm withAlias(String alias) {
    this.alias = alias;
    return this;
  }

  public CustomOptionCreateForm withName(String name) {
    this.name = name;
    return this;
  }

  public CustomOptionCreateForm withDescription(String description) {
    this.description = description;
    return this;
  }

  public CustomOptionCreateForm withValues(
      LinkedHashMap<String, String> values) {
    this.values = values;
    return this;
  }

  public void validate(boolean systemOption) throws CustomOptionException {
    if(!systemOption){
      if(StringUtils.isEmpty(tenantAlias))
        throw new CustomOptionException("tenantAlias", CustomOptionErrorType.TENANT_NOT_FOUND);
    }
    if(StringUtils.isEmpty(alias))
      throw new CustomOptionException("alias", CustomOptionErrorType.ALIAS_NOT_FOUND);
    if(StringUtils.isEmpty(name))
      throw new CustomOptionException("name", CustomOptionErrorType.NAME_NOT_FOUND);
    if(MapUtils.isEmpty(values))
      throw new CustomOptionException("values", CustomOptionErrorType.OPTION_NOT_FOUND);
  }
}
