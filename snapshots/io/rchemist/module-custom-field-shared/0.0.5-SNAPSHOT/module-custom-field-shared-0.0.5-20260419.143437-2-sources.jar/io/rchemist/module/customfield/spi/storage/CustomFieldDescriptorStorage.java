/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.storage;

import io.rchemist.module.customfield.spi.CustomFieldDescriptor;
import java.util.Collection;
import java.util.Optional;

/**
 * Storage-agnostic persistence contract for {@link CustomFieldDescriptor}.
 * Adapters may back this with JPA, Mongo, an in-memory map, a remote KV
 * store, or any other implementation.
 *
 * <p>Method semantics:
 * <ul>
 *   <li>{@link #save(CustomFieldDescriptor)} creates or updates. If the
 *       descriptor has no id, the adapter assigns one.</li>
 *   <li>{@link #findById(Object)} returns {@code Optional.empty()} on miss.</li>
 *   <li>{@link #findByNamespace(String)} returns every descriptor for the
 *       given namespace in persistence order.</li>
 *   <li>{@link #deleteById(Object)} returns {@code true} if something was
 *       actually removed.</li>
 * </ul>
 *
 * <p>Implementations must be thread-safe for concurrent reads and writes.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldDescriptorStorage {

  CustomFieldDescriptor save(CustomFieldDescriptor descriptor);

  Optional<CustomFieldDescriptor> findById(Object id);

  Collection<CustomFieldDescriptor> findByNamespace(String namespace);

  Collection<CustomFieldDescriptor> findAll();

  boolean deleteById(Object id);

  /**
   * Opaque id for the adapter backend — used for diagnostics and config
   * selection ({@code platform.custom-field.storage}).
   */
  String adapterId();
}
