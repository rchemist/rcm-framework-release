/**
 * 본 모듈 (module-custom-field-shared) 은 DEC-017 에 따라 0.1.0 에서 범용화 refactor 예정
 * (M1~M5 후속 세션). 현 구현은 범용성이 부족하여 Consumer 에서 사용되지 않지만, 삭제 대신
 * 범용화하여 재도입한다.
 *
 * <p>상세: {@code documents/refactor/14-0.1.0-direction-revision.md}.
 */
package io.rchemist.module.customfield;
