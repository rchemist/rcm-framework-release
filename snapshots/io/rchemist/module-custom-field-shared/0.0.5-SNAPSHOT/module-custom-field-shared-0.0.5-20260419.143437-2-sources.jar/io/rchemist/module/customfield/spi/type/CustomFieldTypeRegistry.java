/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi.type;

import java.util.Collection;
import java.util.Optional;

/**
 * Registry for {@link CustomFieldValueType}. Consumers may add their own types
 * at runtime (programmatic registration) or at startup (by declaring beans;
 * module-custom-field auto-registers every {@link CustomFieldValueType} bean
 * from the Spring context).
 *
 * <p>Implementations must be thread-safe; registration may happen during
 * application start-up on any thread.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldTypeRegistry {

  /**
   * Register a type. Throws {@link IllegalArgumentException} if a type with the
   * same {@link CustomFieldValueType#id()} already exists and {@code overwrite}
   * is false.
   */
  void register(CustomFieldValueType type, boolean overwrite);

  /** Register with overwrite=false (safe default). */
  default void register(CustomFieldValueType type) {
    register(type, false);
  }

  /** Remove a type. No-op if the id is unknown. */
  boolean unregister(String id);

  /** Lookup by id. */
  Optional<CustomFieldValueType> find(String id);

  /** Return all registered types in insertion order. */
  Collection<CustomFieldValueType> all();

  /** Shortcut — returns the type or throws {@link IllegalArgumentException}. */
  default CustomFieldValueType require(String id) {
    return find(id).orElseThrow(() ->
        new IllegalArgumentException("Unknown CustomFieldValueType id: " + id));
  }
}
