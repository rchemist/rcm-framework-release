/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import io.rchemist.module.customfield.service.exception.CustomOptionErrorType;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomOptionUpdateForm implements HasId<CustomOptionUpdateForm>
        , HasNameDescription<CustomOptionUpdateForm>
        , UpdateFormWrapper<CustomOptionUpdateForm, Long> {

  protected List<CustomOptionValueDTO> values = new ArrayList<>();

  public CustomOptionUpdateForm withValues(
      List<CustomOptionValueDTO> values) {
    this.values = values;
    return this;
  }

  public CustomOptionUpdateForm addValues(CustomOptionValueDTO... values){
    if(ArrayUtils.isNotEmpty(values)){
      this.values.addAll(Arrays.asList(values));
    }
    return this;
  }

  public void validate() throws CustomOptionException {
    if(StringUtils.isEmpty(getName()))
      throw new CustomOptionException("name", CustomOptionErrorType.NAME_NOT_FOUND);
    if(CollectionUtils.isEmpty(values))
      throw new CustomOptionException("values", CustomOptionErrorType.OPTION_NOT_FOUND);
  }
}
