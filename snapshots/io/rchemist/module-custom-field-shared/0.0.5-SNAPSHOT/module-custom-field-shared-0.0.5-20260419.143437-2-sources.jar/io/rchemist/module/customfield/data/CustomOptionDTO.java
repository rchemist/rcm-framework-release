/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAlias;
import io.rchemist.common.persistence.domain.template.presentation.HasAudit;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomOptionDTO implements HasId<CustomOptionDTO>, HasAudit<CustomOptionDTO>, HasTenantAlias<CustomOptionDTO>,
    HasNameDescription<CustomOptionDTO>, HasActive<CustomOptionDTO>, HasAlias<CustomOptionDTO> {

  protected List<CustomOptionValueDTO> values = new ArrayList<>();

  @JsonIgnore
  protected Map<String, CustomOptionValueDTO> valueMap;

  // alias , name
  @JsonIgnore
  protected Map<String, String> getOptionValues(){
    Map<String, String> map = new LinkedHashMap<>();
    for(CustomOptionValueDTO dto : CollectionUtils.emptyIfNull(this.values)){
      map.put(dto.getAlias(), dto.getName());
    }
    return map;
  }

  public void setValues(List<CustomOptionValueDTO> values){
    this.values = values;
  }

  public CustomOptionDTO withValues(List<CustomOptionValueDTO> values){
    setValues(values);
    return this;
  }

  public CustomOptionDTO addValues(CustomOptionValueDTO... values){
    if(ArrayUtils.isEmpty(values))
      return this;

    for(CustomOptionValueDTO dto : values){
      if(!this.values.contains(dto)){
        this.values.add(dto);
      }
    }
    Collections.sort(this.values, Comparator.comparing(CustomOptionValueDTO::getPriority));

    return this;
  }

  @JsonIgnore
  public CustomOptionValueDTO getValue(String alias){
    if(StringUtils.isEmpty(alias) || CollectionUtils.isEmpty(this.values))
      return null;
    return getValueMap().get(alias);
  }

  @JsonIgnore
  public int getOptionSize(){
    return values.size();
  }

  @JsonIgnore
  public Map<String, CustomOptionValueDTO> getValueMap() {
    if(this.valueMap == null){
      this.valueMap = new HashMap<>();
      for(CustomOptionValueDTO dto : this.values){
        this.valueMap.put(dto.getAlias(), dto);
      }
    }
    return valueMap;
  }
}
