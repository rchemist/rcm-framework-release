/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi;

import io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage;
import io.rchemist.module.customfield.spi.storage.CustomFieldValueStorage;
import io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidationResult;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

/**
 * High-level, storage-agnostic entry point. Consumers depend on this
 * interface; the concrete wiring (JPA vs Map vs Mongo, cache enabled vs
 * not, validator chain) is assembled by {@code CustomFieldAutoConfiguration}.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public interface CustomFieldFacade {

  CustomFieldTypeRegistry types();

  CustomFieldDescriptorStorage descriptors();

  CustomFieldValueStorage values();

  /**
   * Validate a raw value string against the descriptor. Runs the full
   * validator pipeline and returns the accumulated result.
   */
  CustomFieldValidationResult validate(CustomFieldDescriptor descriptor, String rawValue);

  /** Descriptors bound to {@code namespace}. */
  Collection<CustomFieldDescriptor> describeNamespace(String namespace);

  /**
   * Convenience — returns property -> raw value for the given owner, keyed by
   * {@link CustomFieldDescriptor#getPropertyName()}.
   */
  Map<String, String> snapshot(String namespace, Object ownerId);

  /**
   * Convenience — retrieve typed value. Uses the descriptor's coercer.
   *
   * @return {@link Optional#empty()} if the descriptor, value, or coercion is
   *     absent.
   */
  Optional<Object> readTyped(String namespace, Object ownerId, String propertyName);
}
