/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Storage-agnostic description of a custom field. Pure data — no JPA, no
 * Mongo, no cache coupling.
 *
 * <p>{@code namespace} replaces the JPA-era {@code targetEntityClass}: it can
 * be a class name, a tenant id, a logical section name, or any other string
 * that groups fields together. Storage adapters only read {@code namespace}
 * as an opaque key.
 *
 * <p>{@code constraints} is an extension point — adapters that need extra
 * metadata (e.g. a Mongo-specific index hint) can attach it here without the
 * SPI needing to know about it.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class CustomFieldDescriptor implements Serializable {

  private static final long serialVersionUID = 1L;

  private Object id;
  private String tenantAlias;
  private String namespace;
  private String propertyName;
  private String typeId;
  private String displayName;
  private String description;
  private String defaultValue;
  private boolean required;
  private List<String> enumerationOptions = new ArrayList<>();
  private String enumerationReference;
  private String regexValidation;
  private String errorMessage;
  private String minLength;
  private String maxLength;
  private Integer order;
  private Map<String, Object> constraints = new LinkedHashMap<>();

  public CustomFieldDescriptor() {
    // default
  }

  public Object getId() {
    return id;
  }

  public CustomFieldDescriptor setId(Object id) {
    this.id = id;
    return this;
  }

  public String getTenantAlias() {
    return tenantAlias;
  }

  public CustomFieldDescriptor setTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public String getNamespace() {
    return namespace;
  }

  public CustomFieldDescriptor setNamespace(String namespace) {
    this.namespace = namespace;
    return this;
  }

  public String getPropertyName() {
    return propertyName;
  }

  public CustomFieldDescriptor setPropertyName(String propertyName) {
    this.propertyName = propertyName;
    return this;
  }

  public String getTypeId() {
    return typeId;
  }

  public CustomFieldDescriptor setTypeId(String typeId) {
    this.typeId = typeId;
    return this;
  }

  public String getDisplayName() {
    return displayName;
  }

  public CustomFieldDescriptor setDisplayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  public String getDescription() {
    return description;
  }

  public CustomFieldDescriptor setDescription(String description) {
    this.description = description;
    return this;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public CustomFieldDescriptor setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  public boolean isRequired() {
    return required;
  }

  public CustomFieldDescriptor setRequired(boolean required) {
    this.required = required;
    return this;
  }

  public List<String> getEnumerationOptions() {
    return enumerationOptions;
  }

  public CustomFieldDescriptor setEnumerationOptions(List<String> enumerationOptions) {
    this.enumerationOptions = enumerationOptions == null
        ? new ArrayList<>() : new ArrayList<>(enumerationOptions);
    return this;
  }

  public String getEnumerationReference() {
    return enumerationReference;
  }

  public CustomFieldDescriptor setEnumerationReference(String enumerationReference) {
    this.enumerationReference = enumerationReference;
    return this;
  }

  public String getRegexValidation() {
    return regexValidation;
  }

  public CustomFieldDescriptor setRegexValidation(String regexValidation) {
    this.regexValidation = regexValidation;
    return this;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public CustomFieldDescriptor setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public String getMinLength() {
    return minLength;
  }

  public CustomFieldDescriptor setMinLength(String minLength) {
    this.minLength = minLength;
    return this;
  }

  public String getMaxLength() {
    return maxLength;
  }

  public CustomFieldDescriptor setMaxLength(String maxLength) {
    this.maxLength = maxLength;
    return this;
  }

  public Integer getOrder() {
    return order;
  }

  public CustomFieldDescriptor setOrder(Integer order) {
    this.order = order;
    return this;
  }

  public Map<String, Object> getConstraints() {
    return constraints;
  }

  public CustomFieldDescriptor setConstraints(Map<String, Object> constraints) {
    this.constraints = constraints == null
        ? new LinkedHashMap<>() : new LinkedHashMap<>(constraints);
    return this;
  }

  /** Return an unmodifiable view of constraints. */
  public Map<String, Object> constraintsView() {
    return Collections.unmodifiableMap(constraints);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof CustomFieldDescriptor other)) return false;
    return Objects.equals(id, other.id)
        && Objects.equals(tenantAlias, other.tenantAlias)
        && Objects.equals(namespace, other.namespace)
        && Objects.equals(propertyName, other.propertyName)
        && Objects.equals(typeId, other.typeId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, tenantAlias, namespace, propertyName, typeId);
  }

  @Override
  public String toString() {
    return "CustomFieldDescriptor{"
        + "id=" + id
        + ", tenantAlias='" + tenantAlias + '\''
        + ", namespace='" + namespace + '\''
        + ", propertyName='" + propertyName + '\''
        + ", typeId='" + typeId + '\''
        + '}';
  }
}
