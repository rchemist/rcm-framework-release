/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomOptionErrorType extends EnumType<CustomOptionErrorType> implements ErrorType {

  public static final CustomOptionErrorType ID_NOT_FOUND = new CustomOptionErrorType("ID_NOT_FOUND", "Id not found", "ID 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final CustomOptionErrorType CUSTOMOPTION_NOT_FOUND = new CustomOptionErrorType("CUSTOMOPTION_NOT_FOUND", "CustomOption not found", "커스텀옵션 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final CustomOptionErrorType TENANT_NOT_FOUND = new CustomOptionErrorType("TENANT_NOT_FOUND", "Tenant not found", "테넌트 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final CustomOptionErrorType NAME_NOT_FOUND = new CustomOptionErrorType("NAME_NOT_FOUND", "Name not found", "이름을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final CustomOptionErrorType OPTION_NOT_FOUND = new CustomOptionErrorType("OPTION_NOT_FOUND", "Options not found", "옵션값을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final CustomOptionErrorType ALIAS_NOT_FOUND = new CustomOptionErrorType("ALIAS_NOT_FOUND", "Alias not found", "Key를 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final CustomOptionErrorType NOT_CHANGED = new CustomOptionErrorType("NOT_CHANGED", "No values changed", "변경된 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final CustomOptionErrorType CACHE_NOT_FOUND = new CustomOptionErrorType("CACHE_NOT_FOUND", "No cached data", "저장된 캐시가 없습니다.", HttpStatus.NOT_FOUND);

  public CustomOptionErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  @Getter
  private final int status;

  private CustomOptionErrorType() {
    this.status = 500;
  }
  
}
