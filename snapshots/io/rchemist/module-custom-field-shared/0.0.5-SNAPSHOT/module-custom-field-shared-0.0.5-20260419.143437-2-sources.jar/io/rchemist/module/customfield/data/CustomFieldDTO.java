/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.rchemist.common.persistence.domain.data.AuditDTO;
import io.rchemist.common.persistence.domain.template.presentation.HasActive;
import io.rchemist.common.persistence.domain.template.presentation.HasAudit;
import io.rchemist.common.persistence.domain.template.presentation.HasId;
import io.rchemist.common.persistence.domain.template.presentation.HasNameDescription;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.presentation.type.CustomFieldType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.TabEnumType;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomFieldDTO implements Serializable, HasAudit<CustomFieldDTO>, HasId<CustomFieldDTO>,
    HasTenantAlias<CustomFieldDTO>, HasNameDescription<CustomFieldDTO>, HasActive<CustomFieldDTO> {

  protected Long id;

  protected String targetEntityClass;

  protected String propertyName;

  protected CustomFieldType fieldType;

  protected String defaultValue;

  protected String[] enumerationOptions;

  protected String enumerationData;

  protected String placeHolder;

  protected String helpText;

  protected String viewTab = TabEnumType.GENERAL.name();

  protected String overrideTabId;

  protected String overrideTabName;

  protected Integer overrideTabOrder = 0;

  protected String viewGroup = GroupEnumType.GENERAL.name();

  protected String overrideGroupId;

  protected String overrideGroupName;

  protected Integer overrideGroupOrder = 0;

  protected Integer order;

  protected Boolean headerField;

  protected Integer headerFieldOrder;

  protected Boolean required;

  protected Boolean searchable;

  protected Boolean sortable;

  protected String regexValidation;

  protected String modifiableType = ModifiableType.ALWAYS.name();

  protected String errorMessage;

  protected String minLength;

  protected String maxLength;

  protected AuditDTO audit = new AuditDTO();

  public CustomFieldDTO withId(Long id) {
    this.id = id;
    return this;
  }

  public CustomFieldDTO withTargetEntityClass(String targetEntityClass) {
    this.targetEntityClass = targetEntityClass;
    return this;
  }

  public CustomFieldDTO withPropertyName(String propertyName) {
    this.propertyName = propertyName;
    return this;
  }

  public CustomFieldDTO withFieldType(CustomFieldType fieldType) {
    this.fieldType = fieldType;
    return this;
  }

  public CustomFieldDTO withDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  public CustomFieldDTO withEnumerationOptions(String[] enumerationOptions) {
    this.enumerationOptions = enumerationOptions;
    return this;
  }

  public CustomFieldDTO withEnumerationData(String enumerationData) {
    this.enumerationData = enumerationData;
    return this;
  }

  public CustomFieldDTO withPlaceHolder(String placeHolder) {
    this.placeHolder = placeHolder;
    return this;
  }

  public CustomFieldDTO withHelpText(String helpText) {
    this.helpText = helpText;
    return this;
  }

  public CustomFieldDTO withViewTab(String viewTab) {
    this.viewTab = viewTab;
    return this;
  }

  public CustomFieldDTO withViewGroup(String viewGroup) {
    this.viewGroup = viewGroup;
    return this;
  }

  public CustomFieldDTO withHeaderField(Boolean headerField) {
    this.headerField = headerField;
    return this;
  }

  public CustomFieldDTO withHeaderFieldOrder(Integer headerFieldOrder) {
    this.headerFieldOrder = headerFieldOrder;
    return this;
  }

  public CustomFieldDTO withSearchable(Boolean searchable) {
    this.searchable = searchable;
    return this;
  }

  public CustomFieldDTO withSortable(Boolean sortable) {
    this.sortable = sortable;
    return this;
  }

  public CustomFieldDTO withRegexValidation(String regexValidation) {
    this.regexValidation = regexValidation;
    return this;
  }

  public CustomFieldDTO withErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public CustomFieldDTO withAudit(AuditDTO audit) {
    this.audit = audit;
    return this;
  }

  public CustomFieldDTO withOrder(Integer order) {
    this.order = order;
    return this;
  }

  public CustomFieldDTO withRequired(Boolean required) {
    this.required = required;
    return this;
  }

  public CustomFieldDTO withMinLength(String minLength) {
    this.minLength = minLength;
    return this;
  }

  public CustomFieldDTO withMaxLength(String maxLength) {
    this.maxLength = maxLength;
    return this;
  }

  public CustomFieldDTO withModifiableType(String modifiableType) {
    this.modifiableType = modifiableType;
    return this;
  }

  public CustomFieldDTO withOverrideTabId(String overrideTabId) {
    this.overrideTabId = overrideTabId;
    return this;
  }

  public CustomFieldDTO withOverrideTabName(String overrideTabName) {
    this.overrideTabName = overrideTabName;
    return this;
  }

  public CustomFieldDTO withOverrideTabOrder(Integer overrideTabOrder) {
    this.overrideTabOrder = overrideTabOrder;
    return this;
  }

  public CustomFieldDTO withOverrideGroupName(String overrideGroupName) {
    this.overrideGroupName = overrideGroupName;
    return this;
  }

  public CustomFieldDTO withOverrideGroupOrder(Integer overrideGroupOrder) {
    this.overrideGroupOrder = overrideGroupOrder;
    return this;
  }

  public CustomFieldDTO withOverrideGroupId(String overrideGroupId) {
    this.overrideGroupId = overrideGroupId;
    return this;
  }
}
