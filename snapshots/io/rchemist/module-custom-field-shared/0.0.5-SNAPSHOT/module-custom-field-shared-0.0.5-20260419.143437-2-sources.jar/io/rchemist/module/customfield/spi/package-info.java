/**
 * Storage-agnostic SPI for the custom-field module (0.1.0 M4 generalization).
 *
 * <p>Entry points:
 * <ul>
 *   <li>{@link io.rchemist.module.customfield.spi.CustomFieldFacade} — high
 *       level facade used by consumers.</li>
 *   <li>{@link io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry}
 *       — extend the type set without forking the module.</li>
 *   <li>{@link io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage}
 *       and {@link io.rchemist.module.customfield.spi.storage.CustomFieldValueStorage}
 *       — plug in alternative backends (JPA, Map, Mongo, KV).</li>
 *   <li>{@link io.rchemist.module.customfield.spi.validation.CustomFieldValidator}
 *       — add validation steps to the pipeline.</li>
 * </ul>
 *
 * <p>This package is deliberately dependency-free (no Spring, no JPA, no
 * Hibernate): it can be reused by non-JPA storage adapters.
 */
package io.rchemist.module.customfield.spi;
