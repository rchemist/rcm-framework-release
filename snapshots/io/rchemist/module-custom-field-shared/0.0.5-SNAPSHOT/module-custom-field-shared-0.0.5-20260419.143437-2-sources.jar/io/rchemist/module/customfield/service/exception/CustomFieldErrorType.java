/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomFieldErrorType extends EnumType<CustomFieldErrorType> implements ErrorType {

  public static final String REQUIRED_ERRORMESSAGE = "error.message.field.required";
  public static final String DUPLICATED_ERRORMESSAGE = "error.message.field.value.duplicated";
  public static final String ERROR_OCCURRED = "error.message.occurred";

  public static final CustomFieldErrorType ID_NOT_FOUND = new CustomFieldErrorType("ID_NOT_FOUND", "Id not found", "ID 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final CustomFieldErrorType CUSTOMFIELD_NOT_FOUND = new CustomFieldErrorType("CUSTOMFIELD_NOT_FOUND", "CustomField not found", "커스텀필드 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final CustomFieldErrorType TENANT_NOT_FOUND = new CustomFieldErrorType("TENANT_NOT_FOUND", "Tenant not found", "테넌트 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final CustomFieldErrorType NAME_NOT_FOUND = new CustomFieldErrorType("NAME_NOT_FOUND", "Name not found", "이름을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final CustomFieldErrorType PROPERTY_NOT_FOUND = new CustomFieldErrorType("NAME_NOT_FOUND", "Name not found", "이름을 입력해야 합니다.", HttpStatus.BAD_REQUEST);
  public static final CustomFieldErrorType NOT_CHANGED = new CustomFieldErrorType("NOT_CHANGED", "No values changed", "변경된 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final CustomFieldErrorType CACHE_NOT_FOUND = new CustomFieldErrorType("CACHE_NOT_FOUND", "No cached data", "저장된 캐시가 없습니다.", HttpStatus.NOT_FOUND);

  public CustomFieldErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  @Getter
  private final int status;

  private CustomFieldErrorType() {
    this.status = 500;
  }
}
