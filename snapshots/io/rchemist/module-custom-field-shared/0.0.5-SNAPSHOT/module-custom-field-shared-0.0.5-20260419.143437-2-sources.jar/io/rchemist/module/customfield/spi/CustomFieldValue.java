/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.spi;

import java.io.Serializable;
import java.util.Objects;

/**
 * Storage-agnostic custom field value tuple bound to an owner (e.g. a
 * primary-entity id) and a descriptor. The raw form is always string so that
 * all storage adapters share the same wire contract; typed access is done
 * through the descriptor's {@code CustomFieldValueCoercer}.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class CustomFieldValue implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String namespace;
  private final Object ownerId;
  private final String propertyName;
  private final String rawValue;

  public CustomFieldValue(String namespace, Object ownerId, String propertyName, String rawValue) {
    this.namespace = namespace;
    this.ownerId = ownerId;
    this.propertyName = propertyName;
    this.rawValue = rawValue;
  }

  public String getNamespace() {
    return namespace;
  }

  public Object getOwnerId() {
    return ownerId;
  }

  public String getPropertyName() {
    return propertyName;
  }

  public String getRawValue() {
    return rawValue;
  }

  public CustomFieldValue withRawValue(String newRaw) {
    return new CustomFieldValue(namespace, ownerId, propertyName, newRaw);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof CustomFieldValue other)) return false;
    return Objects.equals(namespace, other.namespace)
        && Objects.equals(ownerId, other.ownerId)
        && Objects.equals(propertyName, other.propertyName)
        && Objects.equals(rawValue, other.rawValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(namespace, ownerId, propertyName, rawValue);
  }

  @Override
  public String toString() {
    return "CustomFieldValue{"
        + "namespace='" + namespace + '\''
        + ", ownerId=" + ownerId
        + ", propertyName='" + propertyName + '\''
        + '}';
  }
}
