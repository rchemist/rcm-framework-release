/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.data;

import io.rchemist.common.presentation.type.CustomFieldType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import io.rchemist.module.customfield.service.exception.CustomFieldErrorType;
import io.rchemist.module.customfield.service.exception.CustomFieldException;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomFieldCreateForm implements Serializable, CreateFormWrapper<CustomFieldCreateForm> {

  protected String tenantAlias;

  protected String name;

  protected String description;

  protected String sectionType;

  protected String targetEntityClass;

  protected String propertyName;

  protected CustomFieldType fieldType;

  protected String defaultValue;

  protected String[] enumerationOptions;

  protected String enumerationData;

  protected ModifiableType modifiableType = ModifiableType.ALWAYS;

  protected String placeHolder;

  protected String helpText;

  protected String viewTab;

  protected String viewGroup;

  protected Integer order;

  protected Boolean headerField;

  protected Integer headerFieldOrder;

  protected Boolean searchable;

  protected Boolean sortable;

  protected Boolean required;

  protected String regexValidation;

  protected String errorMessage;

  protected String minLength;

  protected String maxLength;

  public CustomFieldCreateForm withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public CustomFieldCreateForm withName(String name) {
    this.name = name;
    return this;
  }

  public CustomFieldCreateForm withDescription(String description) {
    this.description = description;
    return this;
  }

  public CustomFieldCreateForm withSectionType(String sectionType) {
    this.sectionType = sectionType;
    return this;
  }

  public CustomFieldCreateForm withTargetEntityClass(String targetEntityClass) {
    this.targetEntityClass = targetEntityClass;
    return this;
  }

  public CustomFieldCreateForm withPropertyName(String propertyName) {
    this.propertyName = propertyName;
    return this;
  }

  public CustomFieldCreateForm withFieldType(
      CustomFieldType fieldType) {
    this.fieldType = fieldType;
    return this;
  }

  public CustomFieldCreateForm withDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  public CustomFieldCreateForm withEnumerationOptions(String[] enumerationOptions) {
    this.enumerationOptions = enumerationOptions;
    return this;
  }

  public CustomFieldCreateForm withEnumerationData(String enumerationData) {
    this.enumerationData = enumerationData;
    return this;
  }

  public CustomFieldCreateForm withPlaceHolder(String placeHolder) {
    this.placeHolder = placeHolder;
    return this;
  }

  public CustomFieldCreateForm withHelpText(String helpText) {
    this.helpText = helpText;
    return this;
  }

  public CustomFieldCreateForm withViewTab(String viewTab) {
    this.viewTab = viewTab;
    return this;
  }

  public CustomFieldCreateForm withViewGroup(String viewGroup) {
    this.viewGroup = viewGroup;
    return this;
  }

  public CustomFieldCreateForm withHeaderField(Boolean headerField) {
    this.headerField = headerField;
    return this;
  }

  public CustomFieldCreateForm withHeaderFieldOrder(Integer headerFieldOrder) {
    this.headerFieldOrder = headerFieldOrder;
    return this;
  }

  public CustomFieldCreateForm withSearchable(Boolean searchable) {
    this.searchable = searchable;
    return this;
  }

  public CustomFieldCreateForm withSortable(Boolean sortable) {
    this.sortable = sortable;
    return this;
  }

  public CustomFieldCreateForm withRegexValidation(String regexValidation) {
    this.regexValidation = regexValidation;
    return this;
  }

  public CustomFieldCreateForm withErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public CustomFieldCreateForm withRequired(Boolean required) {
    this.required = required;
    return this;
  }

  public CustomFieldCreateForm withModifiableType(
      ModifiableType modifiableType) {
    this.modifiableType = modifiableType;
    return this;
  }

  public CustomFieldCreateForm withMinLength(String minLength) {
    this.minLength = minLength;
    return this;
  }

  public CustomFieldCreateForm withMaxLength(String maxLength) {
    this.maxLength = maxLength;
    return this;
  }

  public CustomFieldCreateForm withOrder(Integer order) {
    this.order = order;
    return this;
  }

  public void validate() throws CustomFieldException {

    if(StringUtils.isEmpty(tenantAlias))
      throw new CustomFieldException(CustomFieldErrorType.TENANT_NOT_FOUND);

    if(StringUtils.isEmpty(name))
      throw new CustomFieldException("name", CustomFieldErrorType.REQUIRED_ERRORMESSAGE);

    if(StringUtils.isEmpty(targetEntityClass))
      throw new CustomFieldException("targetEntityClass", CustomFieldErrorType.REQUIRED_ERRORMESSAGE);

    if(StringUtils.isEmpty(propertyName))
      throw new CustomFieldException("propertyName", CustomFieldErrorType.REQUIRED_ERRORMESSAGE);

    if(fieldType == null)
      throw new CustomFieldException("fieldType", CustomFieldErrorType.REQUIRED_ERRORMESSAGE);

  }


}
