/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.configuration;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.FileUtil;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "platform.config.asset")
public class AssetSettings {

  private static AssetSettings assetSettings;

  @Value("${platform.config.asset.file-name.preserve:false}")
  private boolean preserveFileName;

  @Value("${platform.config.asset.file-name.alternative:rchemist}")
  private String alternativeFileName;

  public static AssetSettings getAssetSettings(){
    if(assetSettings == null){
      assetSettings = ApplicationContextHolder.getBean(AssetSettings.class);
    }
    return assetSettings;
  }

  public String getAlternativeFileName() {
    return FileUtil.sanitizeFilename(alternativeFileName, true);
  }
}
