/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;

/**
 *
 * request form 에서 assets[0].name=XXX, assets[0].file=XXX 이런 식으로 전달한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@RestData(name = "파일 업로드 폼", description = "파일을 업로드 할 때 사용되는 정보")
public class AssetUploadForm<T> {

  @RestDataField(name = "파일 업로드 폼", description = "여러 파일을 등록하기 위한 필드. 해당 필드에 AssetUpload 폼 정보를 입력하여 전달한다. 상세 내용은 AssetUpload 에 기술된 설명 확인")
  private List<AssetUpload<T>> files = new ArrayList<>();

  public boolean hasFile(){
    return CollectionUtils.isNotEmpty(files);
  }

  public AssetUploadForm<T> withFiles(List<AssetUpload<T>> files) {
    this.files = files;
    return this;
  }

  public AssetUploadForm<T> addFile(AssetUpload<T> file) {
    this.files.add(file);
    return this;
  }

}
