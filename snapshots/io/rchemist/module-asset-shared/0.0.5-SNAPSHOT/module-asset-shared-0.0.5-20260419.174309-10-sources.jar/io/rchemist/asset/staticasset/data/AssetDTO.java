/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.domain.template.presentation.HasAudit;
import io.rchemist.common.persistence.domain.template.presentation.HasTags;
import io.rchemist.common.persistence.domain.template.presentation.HasTenantAlias;
import io.rchemist.common.persistence.domain.template.presentation.HasUUID;
import io.rchemist.common.persistence.domain.template.presentation.HasUrl;
import io.rchemist.common.persistence.jpa.domain.template.NameDescription;
import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.Enumeration;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.OverrideMetadata;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.util.type.AssetType;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@AdminEntity(name = "Asset", headerProperty = "url"
, overrideFieldMetadata = {@OverrideMetadata(propertyName = "url"
    , name = "Asset_Url"
    , modifiableType = ModifiableType.ADD_ONLY
    , fieldType = PresentationFieldType.UPLOAD)}
)
@RestData(name = "파일 정보", description = "파일 정보를 나타내며 이미지, 동영상, 텍스트 파일 등의 모든 파일을 Asset 이라고 지칭한다.")
public class AssetDTO implements Serializable, HasUUID<AssetDTO>, HasTenantAlias<AssetDTO>,
    HasUrl<AssetDTO>, NameDescription<AssetDTO>, HasTags<AssetDTO>, HasAudit<AssetDTO> {

  @AdminField(order = 200, fieldType = PresentationFieldType.STRING, modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true, name = "Asset_FileExtension"
      , headerField = @HeaderField(order = 400)
  )
  @RestDataField(name = "확장자", description = "파일 확장자", example = "png")
  private String fileExtension;

  @AdminField(order = 300, fieldType = PresentationFieldType.LONG, modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true, name = "Asset_FileSize"
    , headerField = @HeaderField(order = 500, sortable = false, searchable = false)
  )
  @RestDataField(name = "사이즈", description = "파일 사이즈", example = "567")
  private long fileSize;

  @AdminField(order = 400, fieldType = PresentationFieldType.ENUMERATION
      , enumeration = @Enumeration(enumType = "io.rchemist.common.util.type.AssetType")
      , name = "Asset_AssetType", modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED)
      , headerField = @HeaderField(order = 300, sortable = false)
  )
  @RestDataField(name = "타입", description = "파일 타입. 직접 파일을 등록한건지 (FILE) 파일 링크를 통해 등록한건지 (LINK) 에 대한 정보", example = "FILE")
  private AssetType assetType;

  @AdminField(order = 500, fieldType = PresentationFieldType.STRING, name = "Asset_MimeType", modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED)
  )
  @RestDataField(name = "MIME 타입", description = "파일 변환을 위한 포맷", example = "image/png")
  private String mimeType;

  @AdminField(order = 200, fieldType = PresentationFieldType.STRING, maxLength = "200", name = "Asset_AltText"
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED)
  )
  @RestDataField(name = "Alt Text", description = "Alternative Text (대체 문구)로 검색엔진 또는 시각 장애인을 위한 Asset 설명 문구", example = "altText")
  private String altText;

  @AdminField(order = 100, fieldType = PresentationFieldType.STRING, name = "Asset_Width", modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true
    , group = @ViewFieldGroup(type = GroupEnumType.ATTRIBUTE)
  )
  @RestDataField(name = "가로 길이", description = "가로 길이", example = "100")
  private Integer width;

  @AdminField(order = 100, fieldType = PresentationFieldType.STRING, name = "Asset_Height", modifiableType = ModifiableType.MODIFY_ONLY, readOnly = true
      , group = @ViewFieldGroup(type = GroupEnumType.ATTRIBUTE)
  )
  @RestDataField(name = "세로 길이", description = "세로 길이", example = "100")
  private Integer height;

  @RestDataField(name = "서비스 이름", description = "Asset이 연결된 서비스 이름", example = "tenant")
  private String serviceName;

  @RestDataField(name = "서비스 엔티티 ID", description = "Asset을 등록한 서비스의 엔티티 ID", example = "tenant")
  private String serviceId;

  @AdminField(name = "Asset_Properties", order = 10000, group = @ViewFieldGroup(type = GroupEnumType.ADVANCED), fieldType = PresentationFieldType.INLINE_MAP)
  private Map<String, String> properties = new HashMap<>();

  public AssetType getAssetType() {
    return assetType == null ? AssetType.FILE : assetType;
  }

  public AssetDTO withFileExtension(String fileExtension) {
    this.fileExtension = fileExtension;
    return this;
  }

  public AssetDTO withFileSize(long fileSize) {
    this.fileSize = fileSize;
    return this;
  }

  public AssetDTO withAssetType(AssetType assetType) {
    this.assetType = assetType;
    return this;
  }

  public AssetDTO withMimeType(String mimeType) {
    this.mimeType = mimeType;
    return this;
  }

  public AssetDTO withAltText(String altText) {
    this.altText = altText;
    return this;
  }

  public AssetDTO withWidth(Integer width) {
    this.width = width;
    return this;
  }

  public AssetDTO withHeight(Integer height) {
    this.height = height;
    return this;
  }

  public AssetDTO withServiceName(String serviceName) {
    this.serviceName = serviceName;
    return this;
  }

  public AssetDTO withServiceId(String serviceId) {
    this.serviceId = serviceId;
    return this;
  }

  public AssetDTO withProperties(Map<String, String> properties) {
    this.properties = properties;
    return this;
  }
}
