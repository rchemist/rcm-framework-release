/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.util.type.AssetType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@RestData(name = "파일 업로드 결과", description = "파일 업로드 결과 정보")
public class AssetUploadResult implements Serializable {

  @RestDataField(name = "업로드 파일 정보", description = "업로드 된 파일의 정보 요약", example = AssetDataExample.UPLOAD_FILE)
  private List<UploadFile> assets = new ArrayList<>();

  public AssetUploadResult addAsset(UploadFile... uploaded){
    if(ArrayUtils.isNotEmpty(uploaded)){
      this.assets.addAll(Arrays.asList(uploaded));
    }
    return this;
  }

  @Getter
  @Setter
  @NoArgsConstructor
  @RestData(name = "업로드 파일 정보", description = "업로드 된 파일의 정보 요약")
  public static class UploadFile implements Serializable{

    public UploadFile(String id, String name, String url, String mimeType,
        AssetType assetType, long fileSize) {
      this.id = id;
      this.name = name;
      this.url = url;
      this.mimeType = mimeType;
      this.assetType = assetType;
      this.fileSize = fileSize;
    }

    public UploadFile(ErrorDTO error) {
      this.error = error;
    }

    @RestDataField(name = "시퀀스 ID", description = "파일 시퀀스 ID", example = "1L")
    private String id;

    @RestDataField(name = "이름", description = "사용자가 지정한 파일 이름. 파일의 이름이 변경되는 것은 아니며 파일을 확인할 수 있는 용도로 사용", example = "배너")
    private String name;

    @RestDataField(name = "URL", description = "파일 주소", example = "/asset/asset.png")
    private String url;

    @RestDataField(name = "MIME 타입", description = "파일 변환을 위한 포맷", example = "image/png")
    private String mimeType;

    @RestDataField(name = "사이즈", description = "파일 사이즈", example = "567")
    private long fileSize = 0l;

    @RestDataField(name = "타입", description = "파일 타입. 직접 파일을 등록한건지 (FILE) 파일 링크를 통해 등록한건지 (LINK) 에 대한 정보", example = "FILE")
    private AssetType assetType = AssetType.FILE;

    @RestDataField(name = "에러", description = "에러가 발생했을 때 확인할 수 있는 정보. 해당 필드의 isError (true/false 반환) 여부를 확인하고 에러 발생시 메세지를 확인해야한다.")
    private ErrorDTO error = new ErrorDTO();

    @Override
    public String toString() {
      return new ToStringBuilder(this)
          .append("id", id)
          .append("name", name)
          .append("url", url)
          .append("mimeType", mimeType)
          .append("assetType", assetType)
          .append("fileSize", fileSize)
          .append("error", error)
          .toString();
    }

    public UploadFile withId(String id) {
      this.id = id;
      return this;
    }

    public UploadFile withName(String name) {
      this.name = name;
      return this;
    }

    public UploadFile withUrl(String url) {
      this.url = url;
      return this;
    }

    public UploadFile withMimeType(String mimeType) {
      this.mimeType = mimeType;
      return this;
    }

    public UploadFile withAssetType(AssetType assetType) {
      this.assetType = assetType;
      return this;
    }

    public UploadFile withError(ErrorDTO error) {
      this.error = error;
      return this;
    }

    public UploadFile withFileSize(long fileSize) {
      this.fileSize = fileSize;
      return this;
    }
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("assets", assets)
        .toString();
  }
}
