/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.asset.staticasset.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AssetErrorType extends EnumType<AssetErrorType> implements ErrorType {

  public static final AssetErrorType TENANT_NOT_FOUND = new AssetErrorType("TENANT_NOT_FOUND", "Tenant not found.", "Tenant 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final AssetErrorType ID_NOT_FOUND = new AssetErrorType("ID_NOT_FOUND", "ID not found.", "ID 정보가 없습니다.", HttpStatus.BAD_REQUEST);
  public static final AssetErrorType ASSET_NOT_FOUND = new AssetErrorType("ASSET_NOT_FOUND", "Asset not found.", "Asset 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final AssetErrorType FILE_NOT_FOUND = new AssetErrorType("FILE_NOT_FOUND", "File not found.", "Asset에 연결된 File 정보가 없습니다.", HttpStatus.NOT_FOUND);
  public static final AssetErrorType NO_PERMISSION = new AssetErrorType("NO_PERMISSION", "No permission.", "해당 작업을 수행할 권한이 없습니다.", HttpStatus.BAD_REQUEST);
  public static final AssetErrorType FAILED_TO_DELETE = new AssetErrorType("FAILED_TO_DELETE", "Failed to delete.", "Asset 삭제 중 오류가 발생했습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
  public static final AssetErrorType REQUIRED_URL = new AssetErrorType("REQUIRED_URL", "Url is required.", "Asset URL 정보가 필요합니다.", HttpStatus.INTERNAL_SERVER_ERROR);

  @Getter
  private final int status;

  public AssetErrorType(String type, String friendlyType, String description, HttpStatus httpStatus) {
    super(type, friendlyType, description);
    this.status = httpStatus.value();
  }
}
