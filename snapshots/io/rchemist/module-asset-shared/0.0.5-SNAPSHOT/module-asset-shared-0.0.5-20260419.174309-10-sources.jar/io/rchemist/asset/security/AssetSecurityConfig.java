/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.security;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Asset upload security configuration
 * 
 * @author RCM Framework
 */
public class AssetSecurityConfig {
  
  // 완전히 차단할 실행 파일 확장자
  private static final Set<String> BLOCKED_EXECUTABLE_EXTENSIONS = new HashSet<>(Arrays.asList(
    "exe", "com", "bat", "cmd", "sh", "bash", "ps1", "psm1", "msi", 
    "scr", "vbs", "vbe", "js", "jse", "ws", "wsf", "wsc", "wsh",
    "jar", "app", "deb", "rpm", "dmg", "pkg", "run", "out",
    "gadget", "application", "msp", "pif", "reg", "scf", "lnk"
  ));
  
  // 서버에서 실행될 수 있는 위험한 스크립트 파일 - .txt로 변환
  private static final Set<String> SERVER_SCRIPT_EXTENSIONS = new HashSet<>(Arrays.asList(
    "jsp", "jspx", "php", "php3", "php4", "php5", "phtml", "asp", "aspx",
    "asa", "asax", "ascx", "ashx", "asmx", "axd", "cshtml", "vbhtml",
    "cer", "swf", "xap", "pl", "py", "rb", "cgi", "dll", "so"
  ));
  
  // 클라이언트 스크립트 파일 - .txt로 변환
  private static final Set<String> CLIENT_SCRIPT_EXTENSIONS = new HashSet<>(Arrays.asList(
    "html", "htm", "xhtml", "xml", "xsl", "xslt", "svg", "svgz",
    "js", "jsx", "ts", "tsx", "vue", "mjs", "coffee"
  ));
  
  // 안전한 확장자 (화이트리스트)
  private static final Set<String> SAFE_EXTENSIONS = new HashSet<>(Arrays.asList(
    // 이미지
    "jpg", "jpeg", "png", "gif", "bmp", "ico", "webp", "tiff", "tif",
    // 문서
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp",
    "txt", "rtf", "csv", "md", "log",
    // 미디어
    "mp3", "mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "wav", "flac",
    // 압축
    "zip", "rar", "7z", "tar", "gz", "bz2", "xz",
    // 폰트
    "ttf", "otf", "woff", "woff2", "eot",
    // 데이터
    "json", "yaml", "yml", "ini", "conf", "cfg", "properties"
  ));
  
  /**
   * 파일 확장자가 완전히 차단되어야 하는지 확인
   */
  public static boolean isBlockedExtension(String extension) {
    if (extension == null) return false;
    return BLOCKED_EXECUTABLE_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 파일 확장자가 서버 스크립트인지 확인
   */
  public static boolean isServerScriptExtension(String extension) {
    if (extension == null) return false;
    return SERVER_SCRIPT_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 파일 확장자가 클라이언트 스크립트인지 확인
   */
  public static boolean isClientScriptExtension(String extension) {
    if (extension == null) return false;
    return CLIENT_SCRIPT_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 파일 확장자가 안전한지 확인
   */
  public static boolean isSafeExtension(String extension) {
    if (extension == null) return false;
    return SAFE_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 위험한 확장자를 안전한 확장자로 변환
   * 
   * @param originalExtension 원본 확장자
   * @return 변환된 확장자
   */
  public static String getSafeExtension(String originalExtension) {
    if (originalExtension == null) return "txt";
    
    String ext = originalExtension.toLowerCase();
    
    // 차단 대상이면 null 반환 (업로드 거부)
    if (isBlockedExtension(ext)) {
      return null;
    }
    
    // 스크립트 파일들은 .txt로 변환
    if (isServerScriptExtension(ext) || isClientScriptExtension(ext)) {
      return "txt";
    }
    
    // 안전한 확장자는 그대로 사용
    return ext;
  }
  
  /**
   * 업로드 가능한 파일인지 확인
   * 
   * @param fileName 파일명
   * @return 업로드 가능 여부
   */
  public static boolean isUploadAllowed(String fileName) {
    if (fileName == null || fileName.isEmpty()) return false;
    
    int dotIndex = fileName.lastIndexOf('.');
    if (dotIndex == -1) return true; // 확장자가 없으면 허용
    
    String extension = fileName.substring(dotIndex + 1);
    return !isBlockedExtension(extension);
  }
  
  /**
   * 안전한 파일명 생성
   * 
   * @param originalFileName 원본 파일명
   * @return 안전한 파일명
   */
  public static String getSafeFileName(String originalFileName) {
    if (originalFileName == null || originalFileName.isEmpty()) {
      return "file.txt";
    }
    
    int dotIndex = originalFileName.lastIndexOf('.');
    if (dotIndex == -1) {
      return originalFileName; // 확장자가 없으면 그대로
    }
    
    String baseName = originalFileName.substring(0, dotIndex);
    String extension = originalFileName.substring(dotIndex + 1);
    String safeExtension = getSafeExtension(extension);
    
    if (safeExtension == null) {
      return null; // 업로드 차단
    }
    
    // 원본 확장자와 다르면 원본 확장자를 파일명에 포함
    if (!safeExtension.equalsIgnoreCase(extension)) {
      baseName = baseName + "_" + extension;
    }
    
    return baseName + "." + safeExtension;
  }
}