/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@RestData(name = "파일 삭제", description = "파일 삭제 요청")
public class RemoveAssetDTO implements Serializable {

  @RestDataField(name = "테넌트 시스템 키", description = "시스템에서 사용하는 테넌트 키 값", example = "rchemistTenant")
  private String tenantAlias;

  @RestDataField(name = "시퀀스 ID", description = "파일 시퀀스 ID", example = "\"ids\": [\"1L\",\"2L\"]")
  private String[] ids;

  public RemoveAssetDTO withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public RemoveAssetDTO withIds(String[] ids) {
    this.ids = ids;
    return this;
  }

  public boolean isAvailable(){
    return ArrayUtils.isNotEmpty(ids);
  }

}
