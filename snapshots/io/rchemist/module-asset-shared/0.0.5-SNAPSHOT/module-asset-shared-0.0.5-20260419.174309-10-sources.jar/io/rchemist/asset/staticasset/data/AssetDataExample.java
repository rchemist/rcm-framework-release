/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
public class AssetDataExample {

  public static final String ASSET_SEARCH_FORM = ""
      + "{\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"name\": \"fake_data\",\n"
      + "  \"url\": \"fake_data\",\n"
      + "  \"fileExtension\": \"fake_data\",\n"
      + "  \"mimeType\": \"fake_data\",\n"
      + "  \"serviceName\": \"fake_data\",\n"
      + "  \"serviceId\": \"fake_data\",\n"
      + "  \"assetType\": \"fake_data\",\n"
      + "  \"createdAt\": \"2013-06-24 05:44:48\",\n"
      + "  \"createdAtUntil\": \"2017-11-26 11:46:25\",\n"
      + "  \"updatedAt\": \"2018-04-11 17:21:02\",\n"
      + "  \"updatedAtUntil\": \"2032-03-01 04:22:46\",\n"
      + "  \"page\": 83,\n"
      + "  \"pageSize\": 94,\n"
      + "  \"totalCount\": 69,\n"
      + "  \"sort\": [\n"
      + "    \"fake_data\"\n"
      + "  ]\n"
      + "}"
      + "";

  public static final String ASSET_UPLOAD_FORM = ""
      + "{\n"
      + "   \"files\": {\n"
      + "       \"assetType\": \"fake_data\",\n"
      + "       \"name\": \"fake_data\",\n"
      + "       \"description\": \"fake_data\",\n"
      + "       \"altText\": \"fake_data\",\n"
      + "       \"fileName\": \"fake_data\",\n"
      + "       \"serviceName\": \"fake_data\",\n"
      + "       \"serviceId\": \"fake_data\",\n"
      + "       \"tenantAlias\": \"fake_data\",\n"
      + "       \"explicitFileName\": \"fake_data\",\n"
      + "       \"includePropertyUrl\": \"fake_data\",\n"
      + "       \"tags\": [\n"
      + "         \"fake_data\"\n"
      + "       ]\n"
      + "   }\n"
      + "}"
      + "";

  public static final String REMOVE_ASSET_DTO = ""
      + "{\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"ids\": [\n"
      + "    \"1L\", \"2L\"\n"
      + "  ]\n"
      + "}"
      + "";

  public static final String ASSET_MODIFY_FORM = ""
      + "{\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"id\": \"fake_data\",\n"
      + "  \"name\": \"fake_data\",\n"
      + "  \"url\": \"fake_data\",\n"
      + "  \"altText\": \"fake_data\",\n"
      + "  \"description\": \"fake_data\",\n"
      + "  \"tags\": [\n"
      + "    \"fake_data\"\n"
      + "  ]\n"
      + "}"
      + "";

  public static final String UPLOAD_FILE = ""
      + "{\n"
      + "  \"id\": \"fake_data\",\n"
      + "  \"name\": \"fake_data\",\n"
      + "  \"url\": \"fake_data\",\n"
      + "  \"mimeType\": \"fake_data\",\n"
      + "  \"fileSize\": \"fake_data\",\n"
      + "  \"assetType\": \"fake_data\",\n"
      + "  \"tags\": [\n"
      + "    \"fake_data\"\n"
      + "  ]\n"
      + "}"
      + "";


}
