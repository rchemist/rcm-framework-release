/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.domain.template.presentation.HasUUID;
import io.rchemist.common.web.service.data.UpdateFormWrapper;
import jakarta.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@RestData(name = "파일 수정", description = "파일 정보 수정 폼")
public class AssetModifyForm implements HasUUID<AssetModifyForm>, UpdateFormWrapper<AssetModifyForm, String> {

  @NotNull
  @RestDataField(name = "테넌트 시스템 키", description = "시스템에서 사용하는 테넌트 키 값", example = "rchemistTenant")
  private String tenantAlias;

  @NotNull
  @RestDataField(name = "시퀀스 ID", description = "파일 시퀀스 ID", example = "1L")
  private String id;

  @RestDataField(name = "이름", description = "사용자가 지정한 파일 이름", example = "배너")
  private String name;

  @RestDataField(name = "URL", description = "파일 주소", example = "/asset/asset.png")
  private String url;

  @RestDataField(name = "태그", description = "파일에 대한 태그 정보", example = "\"tags\": [\"배너\",\"이미지\"]")
  private String[] tags;

  @RestDataField(name = "Alt Text", description = "Alternative Text (대체 문구)로 검색엔진 또는 시각 장애인을 위한 Asset 설명 문구", example = "altText")
  private String altText;

  @RestDataField(name = "설명", description = "사용자가 지정한 파일 설명", example = "배너 이미지 입니다.")
  private String description;

  @RestDataField(name = "추가 속성", description = "Asset 에 추가 속성을 지정할 때 사용한다.")
  private Map<String, String> properties = new HashMap<>();

  public AssetModifyForm withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public AssetModifyForm withId(String id) {
    this.id = id;
    return this;
  }

  public AssetModifyForm withName(String name) {
    this.name = name;
    return this;
  }

  public AssetModifyForm withUrl(String url) {
    this.url = url;
    return this;
  }

  public AssetModifyForm withTags(String[] tags) {
    this.tags = tags;
    return this;
  }

  public AssetModifyForm withAltText(String altText) {
    this.altText = altText;
    return this;
  }

  public AssetModifyForm withDescription(String description) {
    this.description = description;
    return this;
  }

  public AssetModifyForm withProperties(
      Map<String, String> properties) {
    this.properties = properties;
    return this;
  }
}
