/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.data;

import io.rchemist.asset.security.AssetSecurityConfig;
import io.rchemist.common.documentation.RestData;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.type.AssetType;
import io.rchemist.common.validate.ValidEnum;
import io.rchemist.common.web.service.data.CreateFormWrapper;
import jakarta.validation.constraints.NotNull;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Slf4j
@RestData(name = "파일 업로드 폼", description = "파일을 업로드 할 때 사용되는 정보")
public class AssetUpload<T> implements Serializable, CreateFormWrapper<AssetUpload<?>> {

  private static final String NULL_VALUE = "null";
  private static final String PROTOCOL_CHAR = "://";

  @NotNull
  @ValidEnum(enumClass = AssetType.class)
  @RestDataField(name = "타입", description = "파일 타입. 직접 파일을 등록할건지 (FILE) 파일 링크를 통해 등록할건지 (LINK) 에 대한 정보", example = "FILE")
  private AssetType assetType;

  @RestDataField(name = "이름", description = "사용자가 지정한 파일 이름. 파일의 이름이 변경되는 것은 아니며 파일을 확인할 수 있는 용도록 사용", example = "배너")
  private String name;

  @RestDataField(name = "설명", description = "사용자가 지정한 파일 설명", example = "배너 이미지 입니다.")
  private String description;

  @RestDataField(name = "Alt Text", description = "Alternative Text (대체 문구)로 검색엔진 또는 시각 장애인을 위한 Asset 설명 문구", example = "altText")
  private String altText;

  @RestDataField(name = "이름", description = "사용자가 지정한 파일 이름", example = "배너")
  private String fileName;

  @RestDataField(name = "서비스 이름", description = "Asset이 연결된 서비스 이름", example = "tenant")
  private String serviceName;

  @RestDataField(name = "서비스 엔티티 ID", description = "Asset을 등록한 서비스의 엔티티 ID", example = "tenant")
  private String serviceId;

  @RestDataField(name = "테넌트 시스템 키", description = "시스템에서 사용하는 테넌트 키 값", example = "rchemistTenant")
  private String tenantAlias;

  @RestDataField(name = "파일 이름", description = "시스템에서 만드는 파일 이름을 사용하지 않고 직접 지정하고 싶을 때 사용", example = "explicit")
  private String explicitFileName;

  @RestDataField(name = "태그", description = "파일에 대한 태그 정보", example = "\"tags\": [\"배너\",\"이미지\"]")
  private String[] tags;

  @RestDataField(name = "속성 정보 포함 여부", description = "파일 URL 을 만들때 속성 정보를 포함할지 여부", example = "false")
  private boolean includePropertyUrl = false;

  private T uploadFile;

  @Builder.Default
  @RestDataField(name = "추가 속성 정보", description = "파일 URL 을 만들때 사용되는 속성 정보. /{serviceName}/{serviceId}/{propertyValue}/ 와 같이 URL 을 사용자가 지정할 때 사용")
  private Map<String, String> properties = new HashMap<>();

  /**
   * 입력된 정보를 이용해 asset 의 url 을 만드는 메소드
   * @return
   */
  public String getAssetUrl(){

    StringBuilder sb = new StringBuilder("/");

    appendIfNonNull(sb, serviceName);
    appendIfNonNull(sb, serviceId);

    if(includePropertyUrl){
      if(MapUtils.isNotEmpty(properties)){
        properties.forEach((key, value) -> {
          appendIfNonNull(sb, value);
        });
      }
    }

    appendIfNonNull(sb, getProperFileName());

    return StringUtils.removeEnd(sb.toString(), "/");
  }

  private void appendIfNonNull(StringBuilder sb, String value){
    if(StringUtils.isNotEmpty(value)
        && !StringUtils.equalsIgnoreCase(value, NULL_VALUE)){

      // If there are characters that cannot be used in the file name, remove them.
      // 파일명에 사용할 수 없는 글자가 있다면 제거한다.
      value = FileUtil.getProperFileName(value);

      if(StringUtils.isNotEmpty(value)){
        sb.append(value).append("/");
      }
    }
  }

  private String getProperFileName(){
    String fileName = StringUtil.toString(this.explicitFileName, getFileName());

    // 파일명에 https:// 같은 것이 있으면 제거한 후 전달한다.
    if(StringUtils.contains(fileName, PROTOCOL_CHAR)){
      fileName = StringUtils.substringAfterLast(fileName, PROTOCOL_CHAR);
    }

    // 보안을 위한 파일명 변환
    String safeFileName = AssetSecurityConfig.getSafeFileName(fileName);
    if (safeFileName != null && !safeFileName.equals(fileName)) {
      log.info("File renamed for security in AssetUpload: {} -> {}", fileName, safeFileName);
      // fileName과 explicitFileName도 업데이트
      this.fileName = safeFileName;
      if (StringUtils.isNotEmpty(this.explicitFileName)) {
        this.explicitFileName = safeFileName;
      }
      return safeFileName;
    }

    return fileName;

  }

  public AssetUpload addProperty(String key, String value){
    this.properties.put(key, value);
    return this;
  }

  public AssetUpload removeProperty(String key){
    this.properties.remove(key);
    return this;
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("fileName", fileName)
        .append("serviceName", serviceName)
        .append("serviceId", serviceId)
        .append("explicitFileName", explicitFileName)
        .append("properties", properties)
        .toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof AssetUpload)) {
      return false;
    }
    AssetUpload that = (AssetUpload) o;
    return Objects.equals(fileName, that.fileName) && Objects.equals(serviceName,
        that.serviceName) && Objects.equals(serviceId, that.serviceId)
        && Objects.equals(explicitFileName, that.explicitFileName)
        && Objects.equals(properties, that.properties);
  }

  @Override
  public int hashCode() {
    return Objects.hash(fileName, serviceName, serviceId, explicitFileName, properties);
  }

  public AssetUpload<T> withAssetType(AssetType assetType) {
    this.assetType = assetType;
    return this;
  }

  public AssetUpload<T> withName(String name) {
    this.name = name;
    return this;
  }

  public AssetUpload<T> withDescription(String description) {
    this.description = description;
    return this;
  }

  public AssetUpload<T> withAltText(String altText) {
    this.altText = altText;
    return this;
  }

  public AssetUpload<T> withFileName(String fileName) {
    this.fileName = fileName;
    return this;
  }

  public AssetUpload<T> withServiceName(String serviceName) {
    this.serviceName = serviceName;
    return this;
  }

  public AssetUpload<T> withServiceId(String serviceId) {
    this.serviceId = serviceId;
    return this;
  }

  public AssetUpload<T> withTenantAlias(String tenantAlias) {
    this.tenantAlias = tenantAlias;
    return this;
  }

  public AssetUpload<T> withExplicitFileName(String explicitFileName) {
    this.explicitFileName = explicitFileName;
    return this;
  }

  public AssetUpload<T> withIncludePropertyUrl(boolean includePropertyUrl) {
    this.includePropertyUrl = includePropertyUrl;
    return this;
  }

  public AssetUpload<T> withUploadFile(T uploadFile) {
    this.uploadFile = uploadFile;
    return this;
  }

  public AssetUpload<T> withProperties(Map<String, String> properties) {
    this.properties = properties;
    return this;
  }

  public AssetUpload<T> withTags(String[] tags) {
    this.tags = tags;
    return this;
  }

  public String getFileName() {
    adjustFileName();
    return fileName;
  }

  public AssetUpload<T> adjustFileName(){
    if(uploadFile != null && !(uploadFile instanceof InputStream)){
      if(uploadFile instanceof MultipartFile){
        this.fileName = ((MultipartFile) uploadFile).getOriginalFilename();
        this.assetType = AssetType.FILE;
      }else if(uploadFile instanceof File){
        this.fileName = ((File) uploadFile).getName();
        this.assetType = AssetType.FILE;
      }else if(uploadFile instanceof String){
        this.fileName = (String) uploadFile;
        this.assetType = AssetType.LINK;
      }
    }
    return this;
  }

  public AssetUpload<InputStream> createInputStreamData() throws IOException {
    return new AssetUpload()
        .withDescription(description)
        .withName(name)
        .withServiceName(serviceName)
        .withAssetType(assetType)
        .withAltText(altText)
        .withExplicitFileName(explicitFileName)
        .withFileName(getFileName())
        .withIncludePropertyUrl(includePropertyUrl)
        .withProperties(properties)
        .withServiceId(serviceId)
        .withTenantAlias(tenantAlias)
        .withTags(tags)
        .withUploadFile(
            (uploadFile instanceof MultipartFile) ? ((MultipartFile) uploadFile).getInputStream() :
                (uploadFile instanceof File) ? new FileInputStream((File) uploadFile) :
                    (uploadFile instanceof String) ? new URL((String) uploadFile).openStream() :
                        (uploadFile instanceof InputStream) ? uploadFile : null
        );
  }

}