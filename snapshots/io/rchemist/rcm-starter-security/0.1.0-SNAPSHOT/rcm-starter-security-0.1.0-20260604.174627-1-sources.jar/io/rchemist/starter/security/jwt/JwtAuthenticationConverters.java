/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #2 — {@link JwtProperties#authoritiesClaim()} / {@link
 * JwtProperties#authoritiesPrefix()} yml 위에 Spring Security 의 {@link JwtAuthenticationConverter}
 * 를 합성하는 단일 지점.
 *
 * <p>default = {@code scope} claim → {@code SCOPE_*} prefix (Spring Security 표준 정합).
 * Consumer 가 {@code roles} claim → {@code ROLE_*} prefix 류 사용 시 yml override 한 줄.
 *
 * <p>본 클래스는 Spring 의 두 helper class 합성만 담당 — Records 가 아닌 Stateless utility 라
 * Lombok 영역도 영역 외 (Decision #28 의 영역 분리 정합, mutable POJO 0).
 **/
public final class JwtAuthenticationConverters {

  private JwtAuthenticationConverters() {}

  /**
   * {@link JwtProperties} 위에 {@link JwtAuthenticationConverter} 합성. claim 이름 + prefix 모두
   * yml 로 override.
   */
  public static JwtAuthenticationConverter from(JwtProperties props) {
    JwtGrantedAuthoritiesConverter scopes = new JwtGrantedAuthoritiesConverter();
    scopes.setAuthoritiesClaimName(props.authoritiesClaim());
    scopes.setAuthorityPrefix(props.authoritiesPrefix());

    JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
    converter.setJwtGrantedAuthoritiesConverter(scopes);
    return converter;
  }
}
