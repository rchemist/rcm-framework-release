/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0.
 */
package io.rchemist.security;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;

/**
 * RCM Framework — Security starter 진입점.
 *
 * Phase 0 = 빈 골격. 후속 Phase 5 에서 oauth2-resource-server / JWT issue/refresh /
 * MFA / Remember Me / RateLimit / Idempotency / TrustedProxy / RequestLimits 추가.
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.springframework.security.config.annotation.web.builders.HttpSecurity")
public class RcmStarterSecurityAutoConfiguration {
}
