/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — {@link AccessDeniedException} → 403 ProblemDetail 매핑 advice.
 *
 * <p>web 영역의 {@code ProblemDetailAdvice} 는 security 의존이 없어 본 예외를 직접 매핑하지 않음
 * (catch-all {@code Exception → 500}). 본 advice 가 security 영역에서 별도 등록 → 403 ProblemDetail
 * 정합 매핑 + RFC 9110 §15.5.4 준수.
 *
 * <p>extension fields: {@code code} / {@code resource} / {@code action}.
 **/
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AccessDeniedExceptionAdvice {

  /** PDP 거부 시 ProblemDetail body 의 {@code code} 항목 값. */
  public static final String ACCESS_DENIED_CODE = "SECURITY.ACCESS_DENIED";

  /**
   * {@link AccessDeniedException} → 403 ProblemDetail.
   *
   * @param ex {@link AccessRouteAspect} 가 throw 한 거부 예외
   * @return RFC 7807 ProblemDetail (status 403, code/resource/action property)
   */
  @ExceptionHandler(AccessDeniedException.class)
  public ProblemDetail handleAccessDenied(AccessDeniedException ex) {
    ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, ex.getMessage());
    pd.setTitle(ACCESS_DENIED_CODE);
    pd.setProperty("code", ACCESS_DENIED_CODE);
    if (ex.getResource() != null) {
      pd.setProperty("resource", ex.getResource());
    }
    if (ex.getAction() != null) {
      pd.setProperty("action", ex.getAction());
    }
    return pd;
  }
}
