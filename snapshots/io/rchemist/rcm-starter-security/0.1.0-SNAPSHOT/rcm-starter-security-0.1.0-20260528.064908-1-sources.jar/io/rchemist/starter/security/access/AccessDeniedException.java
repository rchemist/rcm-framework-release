/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — {@link AccessRouteAspect} 가 DENY 결과를 throw 하는 영역. Spring Security 의
 * {@code AccessDeniedException} 과 별개 — 본 예외는 PDP 평가 결과 영역의 도메인 예외.
 *
 * <p>baseline = {@link RuntimeException} 상속 — controller method invocation 중간 throw → Spring 의
 * exception resolver 가 매핑 (Consumer 가 자체 {@code @ControllerAdvice} 로 매핑하거나 framework 의
 * {@code ProblemDetailAdvice} 가 fallback).
 *
 * <p>HTTP 정합 = 403 Forbidden (RFC 9110 §15.5.4 — 인증은 통과했으나 권한 부족 영역).
 **/
public class AccessDeniedException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final String resource;
  private final String action;

  /**
   * 평가 거부 결과 → 예외 생성.
   *
   * @param resource PDP resource (감사 trail)
   * @param action   PDP action (감사 trail)
   * @param reason   거부 사유 ({@link AccessDecision#denyReason()})
   */
  public AccessDeniedException(String resource, String action, String reason) {
    super(formatMessage(resource, action, reason));
    this.resource = resource;
    this.action = action;
  }

  /**
   * 거부된 resource.
   *
   * @return resource
   */
  public String getResource() {
    return resource;
  }

  /**
   * 거부된 action.
   *
   * @return action
   */
  public String getAction() {
    return action;
  }

  private static String formatMessage(String resource, String action, String reason) {
    StringBuilder sb = new StringBuilder("Access denied for ");
    sb.append(resource).append(':').append(action);
    if (reason != null && !reason.isBlank()) {
      sb.append(" — ").append(reason);
    }
    return sb.toString();
  }
}
