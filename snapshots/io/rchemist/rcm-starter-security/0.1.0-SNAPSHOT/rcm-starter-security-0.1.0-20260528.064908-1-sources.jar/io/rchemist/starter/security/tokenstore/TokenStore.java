/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.tokenstore;

import java.time.Duration;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #4 — refresh token / blacklist 보관 SPI. baseline 2 impl 기준
 * (Redis / InMemory) — Consumer 가 자체 backend (Hazelcast / Ignite 등) 적용 시 자체 bean 으로
 * 양보 ({@link org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean}).
 *
 * <p>접근 패턴:
 * <ul>
 *   <li>refresh 발급 시 {@link #saveRefresh(String, String, Duration)} — jti 가 단일 ID</li>
 *   <li>refresh 사용 시 {@link #consumeRefresh(String)} — atomic remove + return userId
 *       ({@code Optional.empty()} = 이미 사용됨 / 없음, family blacklist trigger)</li>
 *   <li>logout / revoke 시 {@link #revoke(String)} — jti 를 blacklist 추가</li>
 *   <li>access token 검증 보강 시 {@link #isBlacklisted(String)}</li>
 * </ul>
 *
 * <p>모든 jti 기반 — TokenIssuer (Phase 5 #3) 가 jti UUID 자동 부착.
 **/
public interface TokenStore {

  /** refresh token 발급 시 jti 와 userId 매핑 보관. ttl 만료 후 자동 제거. */
  void saveRefresh(String jti, String userId, Duration ttl);

  /**
   * refresh token 사용 시 atomic consume — 첫 호출은 userId 반환, 두 번째 호출은 빈 영역.
   * 두 번째 호출 = 재사용 시도 = family blacklist trigger ({@link
   * io.rchemist.starter.security.tokenstore.RefreshRotator} 영역).
   */
  Optional<String> consumeRefresh(String jti);

  /** jti 를 blacklist 추가 — 만료 전까지 재사용 차단. ttl 가 jti 의 남은 valid 시간 권고. */
  void revoke(String jti, Duration ttl);

  /** {@link #revoke(String, Duration)} 의 default ttl baseline (24h). */
  default void revoke(String jti) {
    revoke(jti, Duration.ofHours(24));
  }

  /** blacklist 검사 — 만료된 entry 자연 false. */
  boolean isBlacklisted(String jti);
}
