/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.limits;

import java.util.Objects;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #9 — {@link Pageable} 한도 enforcement utility.
 *
 * <p>{@code page.size > maxSize} → {@link RequestLimitExceededException} (silent 자르기 거부 =
 * 클라이언트가 명시 한도 초과 시 fail loud). {@code size = 0 또는 미명시} 시 defaultSize 적용.
 *
 * <p>Phase 5 #9 의 {@link io.rchemist.starter.security.autoconfig.SecurityAutoConfiguration} 의
 * {@code PageableHandlerMethodArgumentResolverCustomizer} 영역 hook 또는 controller 직접 호출
 * 둘 다 가능 (utility = stateless).
 **/
public final class PageableLimitEnforcer {

  private final RequestLimitsProperties.Page page;

  public PageableLimitEnforcer(RequestLimitsProperties.Page page) {
    this.page = Objects.requireNonNull(page, "page");
  }

  /**
   * 입력 Pageable 의 size 검사 → max 초과 시 throw / 0 또는 미명시 시 defaultSize 적용 Pageable 반환.
   */
  public Pageable enforce(Pageable input) {
    if (input == null) {
      return PageRequest.of(0, page.defaultSize());
    }
    if (input.isUnpaged()) {
      throw new RequestLimitExceededException("page.size", "unpaged", String.valueOf(page.maxSize()));
    }
    int requested = input.getPageSize();
    if (requested > page.maxSize()) {
      throw new RequestLimitExceededException(
          "page.size", String.valueOf(requested), String.valueOf(page.maxSize()));
    }
    if (requested <= 0) {
      return PageRequest.of(input.getPageNumber(), page.defaultSize(), input.getSort());
    }
    return input;
  }
}
