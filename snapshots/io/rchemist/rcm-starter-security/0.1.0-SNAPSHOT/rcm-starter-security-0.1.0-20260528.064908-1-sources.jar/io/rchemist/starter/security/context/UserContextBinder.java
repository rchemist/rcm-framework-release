/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.context;

import io.rchemist.core.context.UserContext;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #10 — Spring Security {@link Authentication} → {@link UserContext} 변환 단일 지점.
 *
 * <p>{@link JwtAuthenticationToken} (Phase 5 #2 의 oauth2-resource-server 결과) 의 경우 JWT
 * principal 의 {@code sub} claim → userId / {@code preferred_username} → username / authorities
 * → roles. 그 외 일반 Authentication 의 경우 {@code getName()} → userId.
 *
 * <p>본 utility 가 Phase 5 task #10 의 {@link UserContextFilter} + Consumer 영역 명시 binding
 * 둘 다 인입.
 **/
public final class UserContextBinder {

  private UserContextBinder() {}

  /** {@link Authentication} → {@link UserContext}. null 또는 anonymous 시 null 반환. */
  public static UserContext from(Authentication authentication) {
    if (authentication == null
        || !authentication.isAuthenticated()
        || isAnonymous(authentication)) {
      return null;
    }

    if (authentication instanceof JwtAuthenticationToken jwtToken) {
      return fromJwt(jwtToken);
    }

    String userId = authentication.getName();
    if (userId == null || userId.isBlank()) {
      return null;
    }
    return new UserContext(userId, null, authoritiesToRoles(authentication.getAuthorities()));
  }

  // -----------------------------------------------------------------
  // helper
  // -----------------------------------------------------------------

  private static UserContext fromJwt(JwtAuthenticationToken token) {
    Jwt jwt = token.getToken();
    String userId = jwt.getClaimAsString(JwtClaimNames.SUB);
    if (userId == null || userId.isBlank()) {
      return null;
    }
    String username = jwt.getClaimAsString("preferred_username");
    return new UserContext(userId, username, authoritiesToRoles(token.getAuthorities()));
  }

  private static boolean isAnonymous(Authentication authentication) {
    String name = authentication.getName();
    return "anonymousUser".equals(name);
  }

  private static Set<String> authoritiesToRoles(Collection<? extends GrantedAuthority> authorities) {
    if (authorities == null || authorities.isEmpty()) {
      return Set.of();
    }
    Set<String> roles = new LinkedHashSet<>();
    for (GrantedAuthority a : authorities) {
      String name = a.getAuthority();
      if (name != null && !name.isBlank()) {
        roles.add(name);
      }
    }
    return Set.copyOf(roles);
  }
}
