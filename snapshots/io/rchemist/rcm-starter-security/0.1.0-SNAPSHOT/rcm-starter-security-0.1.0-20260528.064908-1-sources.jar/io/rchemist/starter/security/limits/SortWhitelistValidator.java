/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.limits;

import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #9 — sort 영역 화이트리스트 검증 utility. SQL injection (column name 직접 SQL 합성)
 * 영역 회피 — Phase 3 SearchRequest 의 SortInfo 와 정합.
 *
 * <p>{@code whitelistOnly = false} 시 모든 검증 통과 (Phase 3 Entity_Metadata APT 가 자체 화이트
 * 리스트 영역 = baseline 충분). {@code true} 시 globalAllowedFields 안의 field 만 통과 — Consumer
 * 가 명시 nominate.
 **/
public final class SortWhitelistValidator {

  private final RequestLimitsProperties.Sort sort;
  private final Set<String> allowedFieldsLower;

  public SortWhitelistValidator(RequestLimitsProperties.Sort sort) {
    this.sort = Objects.requireNonNull(sort, "sort");
    this.allowedFieldsLower = new HashSet<>();
    for (String f : sort.globalAllowedFields()) {
      allowedFieldsLower.add(f.toLowerCase(java.util.Locale.ROOT));
    }
  }

  /** 단일 sort field 검증. {@code whitelistOnly=false} 시 silent pass. */
  public void validate(String field) {
    Objects.requireNonNull(field, "field");
    if (!sort.whitelistOnly()) {
      return;
    }
    if (!allowedFieldsLower.contains(field.toLowerCase(java.util.Locale.ROOT))) {
      throw new RequestLimitExceededException(
          "sort.field", field, allowedFieldsLower.toString());
    }
  }

  /** 다중 sort field 검증 (편의 method). */
  public void validateAll(Collection<String> fields) {
    Objects.requireNonNull(fields, "fields");
    for (String f : fields) {
      validate(f);
    }
  }
}
