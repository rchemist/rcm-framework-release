/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.ratelimit;

import java.time.Duration;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #6 — {@code platform.security.rate-limit.*} prefix 의 yml binding.
 *
 * <p>{@code defaultLimit} / {@code defaultRefresh} = baseline 설정. {@code limiters} =
 * per-name override (annotation 의 {@code name} 별 분리).
 *
 * <p>{@code Limiter} = limiter 단위 yml — {@code limit-for-period} / {@code limit-refresh-period} /
 * {@code timeout-duration} (acquire 대기 시간, 0 = 즉시 fail).
 **/
@ConfigurationProperties(prefix = "platform.security.rate-limit")
public record RateLimitProperties(
    @DefaultValue("100") int defaultLimit,
    @DefaultValue("PT1S") Duration defaultRefresh,
    @DefaultValue("PT0S") Duration defaultTimeout,
    @DefaultValue Map<String, Limiter> limiters) {

  /** {@code name} 별 override 또는 default fallback. */
  public Limiter resolve(String name) {
    Limiter override = limiters.get(name);
    if (override == null) {
      return new Limiter(defaultLimit, defaultRefresh, defaultTimeout);
    }
    return new Limiter(
        override.limit() == 0 ? defaultLimit : override.limit(),
        override.refresh() == null ? defaultRefresh : override.refresh(),
        override.timeout() == null ? defaultTimeout : override.timeout());
  }

  public record Limiter(int limit, Duration refresh, Duration timeout) {}
}
