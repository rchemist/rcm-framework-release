/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.tokenstore;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #4 — {@code platform.security.token-store.*} prefix 의 yml binding 단일 지점.
 *
 * <p>{@code refreshKeyPrefix} / {@code blacklistKeyPrefix} = Redis key 접두사 (collision 회피
 * 단일 namespace). InMemory backend 는 keyPrefix 영역 무시 (Map key).
 *
 * <p>{@code maxEntries} = InMemory backend 의 Caffeine spec — Redis 채택 시 무시.
 **/
@ConfigurationProperties(prefix = "platform.security.token-store")
public record TokenStoreProperties(
    @DefaultValue("rcm:security:refresh:") String refreshKeyPrefix,
    @DefaultValue("rcm:security:blacklist:") String blacklistKeyPrefix,
    @DefaultValue("100000") long maxEntries,
    @DefaultValue("PT24H") Duration defaultBlacklistTtl) {}
