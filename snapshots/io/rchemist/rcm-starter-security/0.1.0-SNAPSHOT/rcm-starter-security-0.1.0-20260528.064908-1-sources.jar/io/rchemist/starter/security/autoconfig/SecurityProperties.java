/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.autoconfig;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #1 — {@code platform.security.*} prefix 의 baseline yml binding 단일 지점.
 *
 * <p>{@code enabled} = {@link SecurityAutoConfiguration} 자체 opt-out flag (default true).
 * 일부 SI 가 자체 SecurityFilterChain 통째 채택 시 framework default 자동 양보가 부족하면 본 flag.
 *
 * <p>{@code defaultPermitAll} = baseline filter chain 의 *모든 path* 를 permitAll 로 둘지.
 * default false (그 외 path 는 {@code authenticated()}). dev/test 환경에서 가끔 활성.
 *
 * <p>{@code permitPaths} = 명시 permitAll 화이트리스트 (Spring path pattern). default = actuator
 * health/info 두 영역. Consumer 가 yml override 또는 자체 SecurityFilterChain bean 으로 자유 확장.
 *
 * <p>JWT / MFA / RateLimit / Idempotency / TrustedProxy / RequestLimits sub-area 는 Phase 5
 * #2 ~ #9 에서 각자 자체 {@code @ConfigurationProperties} Records 로 합류 — 본 baseline 은
 * {@link SecurityFilterChain} default 만 책임.
 **/
@ConfigurationProperties(prefix = "platform.security")
public record SecurityProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("false") boolean defaultPermitAll,
    @DefaultValue({"/actuator/health", "/actuator/info"}) List<String> permitPaths) {}
