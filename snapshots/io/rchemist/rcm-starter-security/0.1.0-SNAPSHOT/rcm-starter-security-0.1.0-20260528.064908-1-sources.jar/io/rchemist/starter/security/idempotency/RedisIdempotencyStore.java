/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.idempotency;

import java.time.Duration;
import java.util.Objects;
import java.util.Optional;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #7 — Redis 기반 idempotency store. binary safe — {@link CachedResponse} Records
 * 직렬화 그대로 보관 (Spring Data Redis 의 default ObjectStreamSerializer 또는 Consumer 명시).
 *
 * <p>{@link RedisTemplate} 위 — Consumer 가 자체 ConnectionFactory + ValueSerializer 적용 후 본
 * store 가 transparent 활용. binary 영역이라 {@code RedisTemplate<String, Object>} 권고.
 **/
public class RedisIdempotencyStore implements IdempotencyStore {

  private final RedisTemplate<String, Object> redis;

  public RedisIdempotencyStore(RedisTemplate<String, Object> redis) {
    this.redis = Objects.requireNonNull(redis, "redis");
  }

  @Override
  public Optional<CachedResponse> get(String key) {
    Object stored = redis.opsForValue().get(key);
    if (stored instanceof CachedResponse cached) {
      return Optional.of(cached);
    }
    return Optional.empty();
  }

  @Override
  public void save(String key, CachedResponse response, Duration ttl) {
    redis.opsForValue().set(key, response, ttl);
  }
}
