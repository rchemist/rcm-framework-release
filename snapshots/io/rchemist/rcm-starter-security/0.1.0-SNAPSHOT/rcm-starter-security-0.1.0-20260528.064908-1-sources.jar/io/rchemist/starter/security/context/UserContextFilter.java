/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.context;

import io.rchemist.core.context.UserContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #10 — Spring Security {@link Authentication} 인증 통과 후 {@link UserContext}
 * ScopedValue binding 단일 진입점 (청사진 §6.2 정합).
 *
 * <p>흐름:
 * <ol>
 *   <li>Spring Security 의 oauth2-resource-server / form login 등 인증 영역 통과 후 본 filter 호출</li>
 *   <li>{@link SecurityContextHolder#getContext()} 의 Authentication → {@link UserContextBinder}
 *       으로 변환</li>
 *   <li>{@link UserContext#runWith(UserContext, Runnable)} 영역 안에서 chain 진행 — 이후 controller /
 *       service / repository 가 {@link UserContext#current()} 호출 가능</li>
 * </ol>
 *
 * <p>인증 미통과 (anonymous) 시 silent skip — {@code permitPaths} 등 anonymous 영역은 UserContext
 * 미바인딩 (의도된 영역 = Phase 1 ScopedValue 의 {@code isBound() == false}).
 *
 * <p>본 filter 는 Spring Security 의 {@code SecurityContextHolderFilter} 다음에 위치 — Spring
 * Security FilterChain 자체는 {@link UserContextFilter} 를 자동 합류 안 함. Consumer 가 자체
 * SecurityFilterChain 안에 명시 추가 또는 framework 의 {@code addFilterAfter} 영역에서 합류.
 **/
public class UserContextFilter extends OncePerRequestFilter {

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    UserContext ctx = UserContextBinder.from(authentication);

    if (ctx == null) {
      chain.doFilter(request, response);
      return;
    }

    try {
      UserContext.callWith(
          ctx,
          () -> {
            try {
              chain.doFilter(request, response);
            } catch (IOException | ServletException e) {
              throw new ScopedRuntimeException(e);
            }
            return null;
          });
    } catch (ScopedRuntimeException wrapped) {
      Throwable cause = wrapped.getCause();
      if (cause instanceof IOException io) {
        throw io;
      }
      if (cause instanceof ServletException se) {
        throw se;
      }
      throw new ServletException(cause);
    }
  }

  /** Internal — checked exception 영역 ScopedValue lambda 통과 위한 wrapper. */
  private static final class ScopedRuntimeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    ScopedRuntimeException(Throwable cause) {
      super(cause);
    }
  }
}
