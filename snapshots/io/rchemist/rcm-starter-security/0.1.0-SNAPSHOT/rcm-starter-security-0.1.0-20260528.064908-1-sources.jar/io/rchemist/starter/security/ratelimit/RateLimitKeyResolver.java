/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.ratelimit;

import io.rchemist.core.context.UserContext;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #6 — RateLimit key 추출 SPI. baseline impl = {@link DefaultRateLimitKeyResolver}.
 * Consumer 가 자체 strategy 적용 시 자체 bean 으로 양보.
 **/
public interface RateLimitKeyResolver {

  /**
   * 현 호출 컨텍스트로부터 limiter key 추출. UserContext (Phase 1 ScopedValue) 가 바인딩되어 있으면
   * 사용자 단위 — 미바인딩 시 anonymous 영역 (request IP 또는 "anonymous" 단일 영역).
   *
   * @return limiter key (e.g., "user:u-1" 또는 "ip:192.0.2.1")
   */
  String resolveKey();

  /** Default impl — UserContext.userId 우선 → "anonymous" fallback. IP 영역은 Phase 5 #8 의
   * TrustedProxy 단일 진입점에서 바인딩. */
  class DefaultRateLimitKeyResolver implements RateLimitKeyResolver {
    @Override
    public String resolveKey() {
      String userId = UserContext.currentUserIdOrNull();
      return userId != null ? "user:" + userId : "anonymous";
    }
  }
}
