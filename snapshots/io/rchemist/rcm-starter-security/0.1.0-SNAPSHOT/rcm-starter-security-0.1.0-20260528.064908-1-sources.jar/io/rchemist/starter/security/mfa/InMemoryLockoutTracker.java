/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Instant;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — Redis 부재 시 graceful fallback. Caffeine cache 위 실패 카운트 + lock 상태.
 *
 * <p>적용:
 * <ul>
 *   <li>실패 카운트 cache: {@code key → AtomicInteger} + TTL = lockoutDuration (자동 reset
 *       = 카운트 자연 expiry)</li>
 *   <li>Lock 상태 cache: {@code key → expireAt Instant} + 명시 expireAfterWrite = lockoutDuration</li>
 *   <li>{@link #recordFailure(String)} = 카운트 increment, 한도 도달 시 lock cache put</li>
 * </ul>
 **/
public class InMemoryLockoutTracker implements LockoutTracker {

  private final LockoutPolicy policy;
  private final Cache<String, AtomicInteger> failures;
  private final Cache<String, Instant> locked;

  public InMemoryLockoutTracker(LockoutPolicy policy) {
    this.policy = Objects.requireNonNull(policy, "policy");
    this.failures =
        Caffeine.newBuilder().expireAfterWrite(policy.lockoutDuration()).maximumSize(100_000).build();
    this.locked =
        Caffeine.newBuilder().expireAfterWrite(policy.lockoutDuration()).maximumSize(100_000).build();
  }

  @Override
  public void recordFailure(String key) {
    AtomicInteger counter = failures.get(key, k -> new AtomicInteger(0));
    int n = counter.incrementAndGet();
    if (n >= policy.maxAttempts()) {
      locked.put(key, Instant.now().plus(policy.lockoutDuration()));
    }
  }

  @Override
  public boolean isLockedOut(String key) {
    Instant expireAt = locked.getIfPresent(key);
    if (expireAt == null) {
      return false;
    }
    if (Instant.now().isAfter(expireAt)) {
      locked.invalidate(key);
      return false;
    }
    return true;
  }

  @Override
  public void reset(String key) {
    failures.invalidate(key);
    locked.invalidate(key);
  }
}
