/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #2 — {@code platform.security.jwt.*} prefix 의 JWT yml binding 단일 지점.
 *
 * <p>{@code secret} 가 비어있는 경우 JWT autoconfig 영역 자체가 비활성 ({@link
 * org.springframework.security.oauth2.jwt.JwtDecoder} bean 미등록). Consumer 가 JWT
 * 영역 미사용 (예: 자체 인증 메커니즘 채택) 시 자연 silent skip.
 *
 * <p>{@code secret} 은 base64 인코딩된 raw bytes. HS512 = ≥64 bytes (512 bits) 권고. 배포 환경
 * vault / secrets manager 위임 (Spring config import / @Value 주입).
 *
 * <p>{@code authoritiesClaim} = JWT claim 이름 (default {@code roles} — framework PDP 정책 시드
 * schema 정합. {@code roleAllowList: ["PLATFORM_ADMIN", ...]} 등 raw 역할명 사용).
 * {@code authoritiesPrefix} = {@code GrantedAuthority} prefix (default 빈 문자열 — raw 역할명을
 * 그대로 {@code GrantedAuthority} 로 매핑). OAuth2 RFC 6749 정합 IdP (Keycloak / Auth0 등) 의
 * {@code scope} claim + {@code SCOPE_} prefix 사용 영역은 yml override
 * ({@code authorities-claim: scope} + {@code authorities-prefix: SCOPE_}).
 *
 * <p>{@code clockSkew} = JWT exp/nbf 허용 오차. 배포 시점 시간 동기 차이 흡수 (default 60s).
 **/
@ConfigurationProperties(prefix = "platform.security.jwt")
public record JwtProperties(
    @DefaultValue("") String secret,
    @DefaultValue("HS512") MacAlgorithm signingAlgorithm,
    @DefaultValue("") String issuer,
    @DefaultValue("") String audience,
    @DefaultValue("60s") Duration clockSkew,
    @DefaultValue("roles") String authoritiesClaim,
    @DefaultValue("") String authoritiesPrefix,
    @DefaultValue List<KeyConfig> keys) {

  /**
   * {@code secret} 또는 {@code keys} 둘 중 하나가 명시 적용된 경우 JWT 영역 활성. 둘 다 빈 영역
   * (default) = 비활성. {@link JwtDecoderFactory} / {@code SecurityAutoConfiguration} 의
   * conditional 분기 단일 지점.
   */
  public boolean isEnabled() {
    return (secret != null && !secret.isBlank()) || (keys != null && !keys.isEmpty());
  }

  /**
   * Phase 5 task #3 — 다중 key rotation 영역 의 단일 yml 표현. {@code keys[]} list 가 본 Records
   * 의 N 개. 미명시 영역은 단일 secret 모드 (Phase 5 #2) backward 호환.
   *
   * <p>{@code notBefore} = null → epoch (영구 활성 시작). {@code notAfter} = null → 영원 (만료
   * 없음 = 단일 키 시나리오 + 점진 rotation 영역). 둘 다 null = 영구 활성 single key.
   */
  public record KeyConfig(String kid, String secret, Instant notBefore, Instant notAfter) {}
}
