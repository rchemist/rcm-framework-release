/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.limits;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #9 — RequestLimits 위반 시 throw. {@link io.rchemist.core.error.ServiceException}
 * 영역과 정합 — Phase 2 ProblemDetailAdvice 가 본 exception → ProblemDetail 자동 매핑.
 *
 * <p>{@code limit} = 위반된 한도 영역 ({@code page.size} / {@code sort.field} / {@code body.bytes}).
 * {@code violatedValue} = 실제 입력값. {@code limitValue} = 한도값 (display 용).
 **/
public class RequestLimitExceededException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final String limit;
  private final String violatedValue;
  private final String limitValue;

  public RequestLimitExceededException(String limit, String violatedValue, String limitValue) {
    super("Request limit exceeded: " + limit + " value=" + violatedValue + " limit=" + limitValue);
    this.limit = limit;
    this.violatedValue = violatedValue;
    this.limitValue = limitValue;
  }

  public String limit() {
    return limit;
  }

  public String violatedValue() {
    return violatedValue;
  }

  public String limitValue() {
    return limitValue;
  }
}
