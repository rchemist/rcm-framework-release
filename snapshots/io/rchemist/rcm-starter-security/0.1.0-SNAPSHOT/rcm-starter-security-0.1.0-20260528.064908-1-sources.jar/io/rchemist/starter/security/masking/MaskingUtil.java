/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.masking;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 0.1.0 GA Gate T1 — 한국 PII 표준 masking utility (Decision #29 Q2 PII 영역 흡수).
 *
 * <p>외부 의존 0. 모든 method = static, null/empty fail-soft, 길이 부족 시 full-mask 안전 default.
 *
 * <p>패턴:
 * <ul>
 *   <li>{@link #maskEmail(String)} — local part 첫 글자 + {@code *} 나머지, {@code @domain} 보존</li>
 *   <li>{@link #maskPhone(String)} — 한국 휴대전화 / 02 / 0NN 지역 구분, 가운데 4 자리 mask</li>
 *   <li>{@link #maskName(String)} — 1 글자 = full / 2 글자 = 끝 / 3+ = 첫·끝 keep + 가운데 mask</li>
 *   <li>{@link #maskRrn(String)} — 주민등록번호 뒤 6 자리 mask (성별 1 자리 유지)</li>
 *   <li>{@link #maskCard(String)} — PCI-DSS 정합 첫 6 + 끝 4 keep, 가운데 mask</li>
 *   <li>{@link #maskAddress(String)} — 마지막 token (번지 / 동 호수) full-mask</li>
 * </ul>
 **/
public final class MaskingUtil {

  private static final char STAR = '*';

  private MaskingUtil() {
    throw new UnsupportedOperationException("static utility");
  }

  /** 이메일 masking — local 첫 글자 + 나머지 {@code *}, {@code @domain} 그대로. */
  public static String maskEmail(String email) {
    if (email == null) {
      return null;
    }
    if (email.isEmpty()) {
      return email;
    }
    int at = email.lastIndexOf('@');
    if (at <= 0) {
      return repeat(STAR, email.length());
    }
    String local = email.substring(0, at);
    String domain = email.substring(at);
    if (local.length() == 1) {
      return STAR + domain;
    }
    return local.charAt(0) + repeat(STAR, local.length() - 1) + domain;
  }

  /** 전화번호 masking — 가운데 그룹 mask. dash / 무 dash 모두 지원. */
  public static String maskPhone(String phone) {
    if (phone == null) {
      return null;
    }
    if (phone.isEmpty()) {
      return phone;
    }
    if (phone.contains("-")) {
      String[] parts = phone.split("-", -1);
      if (parts.length == 3) {
        parts[1] = repeat(STAR, parts[1].length());
        return String.join("-", parts);
      }
      return repeat(STAR, phone.length());
    }
    int len = phone.length();
    if (len < 7) {
      return repeat(STAR, len);
    }
    int prefixLen;
    int suffixLen;
    if (phone.startsWith("02")) {
      prefixLen = 2;
      suffixLen = 4;
    } else if (phone.startsWith("01") || (phone.startsWith("0") && len >= 10)) {
      prefixLen = 3;
      suffixLen = 4;
    } else {
      prefixLen = Math.max(2, len - 8);
      suffixLen = 4;
    }
    int midLen = len - prefixLen - suffixLen;
    if (midLen <= 0) {
      return repeat(STAR, len);
    }
    return phone.substring(0, prefixLen)
        + repeat(STAR, midLen)
        + phone.substring(len - suffixLen);
  }

  /** 이름 masking — 1글자 full / 2글자 끝 / 3+ 첫·끝 keep + 가운데 mask. */
  public static String maskName(String name) {
    if (name == null) {
      return null;
    }
    int len = name.length();
    if (len == 0) {
      return name;
    }
    if (len == 1) {
      return String.valueOf(STAR);
    }
    if (len == 2) {
      return name.charAt(0) + String.valueOf(STAR);
    }
    return name.charAt(0) + repeat(STAR, len - 2) + name.charAt(len - 1);
  }

  /** 주민등록번호 masking — 첫 7 자리 (생년월일 6 + 성별 1) keep, 나머지 6 자리 mask. dash 보존. */
  public static String maskRrn(String rrn) {
    if (rrn == null) {
      return null;
    }
    if (rrn.isEmpty()) {
      return rrn;
    }
    int len = rrn.length();
    if (len < 8) {
      return repeat(STAR, len);
    }
    if (rrn.contains("-")) {
      int dash = rrn.indexOf('-');
      String head = rrn.substring(0, dash);
      String tail = rrn.substring(dash + 1);
      if (tail.length() < 2) {
        return head + "-" + repeat(STAR, tail.length());
      }
      return head + "-" + tail.charAt(0) + repeat(STAR, tail.length() - 1);
    }
    return rrn.substring(0, 7) + repeat(STAR, len - 7);
  }

  /** 카드번호 masking — PCI-DSS 정합 첫 6 + 끝 4 keep. dash 위치 보존. */
  public static String maskCard(String card) {
    if (card == null) {
      return null;
    }
    if (card.isEmpty()) {
      return card;
    }
    String digits = card.replace("-", "");
    if (digits.length() < 11) {
      return repeat(STAR, card.length());
    }
    int dlen = digits.length();
    StringBuilder masked = new StringBuilder(dlen);
    masked.append(digits, 0, 6);
    masked.append(repeat(STAR, dlen - 10));
    masked.append(digits, dlen - 4, dlen);
    if (!card.contains("-")) {
      return masked.toString();
    }
    StringBuilder out = new StringBuilder(card.length());
    int di = 0;
    for (int i = 0; i < card.length(); i++) {
      char c = card.charAt(i);
      if (c == '-') {
        out.append('-');
      } else {
        out.append(masked.charAt(di++));
      }
    }
    return out.toString();
  }

  /** 주소 masking — 마지막 token (번지 / 동·호수) full-mask, 그 앞은 그대로. */
  public static String maskAddress(String address) {
    if (address == null) {
      return null;
    }
    if (address.isEmpty()) {
      return address;
    }
    int lastSpace = address.lastIndexOf(' ');
    if (lastSpace < 0) {
      return repeat(STAR, address.length());
    }
    String tail = address.substring(lastSpace + 1);
    return address.substring(0, lastSpace + 1) + repeat(STAR, tail.length());
  }

  private static String repeat(char c, int n) {
    if (n <= 0) {
      return "";
    }
    char[] arr = new char[n];
    java.util.Arrays.fill(arr, c);
    return new String(arr);
  }
}
