/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.trustedproxy;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Objects;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #8 — TrustedProxy 영역 단일 진입점. 직접 들어온 요청의 remote address 가 CIDR
 * allowlist 안일 때만 {@code X-Forwarded-For} (또는 yml 명시 header) 신뢰.
 *
 * <p>fail-closed=true (default) 시 untrusted source 의 forwarded header 는 chain 진행 전 제거 →
 * 후속 filter / handler 가 spoofed value 보지 못함. fail-closed=false 시 header 그대로 통과 (legacy
 * 호환 영역).
 *
 * <p>{@link RemoteAddressResolver} 가 본 filter 통과 후 신뢰 가능한 client IP 단일 진실 원천.
 **/
public class TrustedProxyFilter extends OncePerRequestFilter {

  private final TrustedProxyProperties properties;
  private final CidrMatcher matcher;

  public TrustedProxyFilter(TrustedProxyProperties properties) {
    this.properties = Objects.requireNonNull(properties, "properties");
    this.matcher = new CidrMatcher(properties.cidrAllowlist());
  }

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    if (!properties.enabled()) {
      chain.doFilter(request, response);
      return;
    }

    String remote = request.getRemoteAddr();
    boolean trusted = remote != null && matcher.matches(remote);
    if (trusted) {
      chain.doFilter(request, response);
      return;
    }

    if (properties.failClosed()) {
      chain.doFilter(new StripForwardedHeaderRequestWrapper(request, properties.headerName()), response);
    } else {
      chain.doFilter(request, response);
    }
  }

  private static final class StripForwardedHeaderRequestWrapper extends HttpServletRequestWrapper {
    private final String stripHeader;

    StripForwardedHeaderRequestWrapper(HttpServletRequest request, String stripHeader) {
      super(request);
      this.stripHeader = stripHeader;
    }

    @Override
    public String getHeader(String name) {
      if (stripHeader.equalsIgnoreCase(name)) {
        return null;
      }
      return super.getHeader(name);
    }

    @Override
    public Enumeration<String> getHeaders(String name) {
      if (stripHeader.equalsIgnoreCase(name)) {
        return Collections.emptyEnumeration();
      }
      return super.getHeaders(name);
    }
  }
}
