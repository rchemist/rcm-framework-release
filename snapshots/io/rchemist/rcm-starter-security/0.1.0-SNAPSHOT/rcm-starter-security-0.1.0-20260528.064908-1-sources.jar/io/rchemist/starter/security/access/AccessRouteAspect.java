/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

import io.rchemist.starter.web.crud.CrudEndpointAction;
import io.rchemist.starter.web.crud.DefaultAccessRoute;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — PDP enforcement {@link HandlerInterceptor}. Spring MVC dispatcher 영역에서 controller
 * method 진입 직전 발화 — AOP proxy 의 상속 메소드 한계 (AspectJ {@code within} 또는 {@code @within}
 * 이 base class 메소드를 누락) 없이 모든 endpoint 정확 cover.
 *
 * <p>3 단계 lookup (preHandle 안):
 * <ol>
 *   <li>method 레벨 {@link AccessRoute} 발견 — 그 {@code (resource, action)} 직접 평가</li>
 *   <li>method 레벨 부재 + class 레벨 {@link AccessRoute} 발견 — 모든 method 단일 (resource, action)</li>
 *   <li>둘 다 부재 + class 레벨 {@link DefaultAccessRoute} 발견 — 8 endpoint matrix
 *       ({@link CrudEndpointAction#resolve(HttpMethod, List)}) 자동 derive → 평가</li>
 *   <li>3 가지 모두 부재 = no-op (pass-through)</li>
 * </ol>
 *
 * <p>DENY 결정 시 {@link AccessDeniedException} throw — {@link AccessDeniedExceptionAdvice} 가 403
 * ProblemDetail 매핑.
 *
 * <p>HandlerInterceptor 선택 이유 — AOP advice (AspectJ {@code @within}) 가 *직접 선언된 메소드*만
 * 매칭하는 한계로 {@link io.rchemist.starter.web.crud.AbstractCrudController} 의 8 endpoint 가
 * Consumer controller (extends) 영역에서 advice 누락. HandlerInterceptor 는 Spring MVC 의 매핑된
 * HandlerMethod 를 직접 받으므로 상속 영역 무관 + 정확 매핑.
 **/
public class AccessRouteAspect implements HandlerInterceptor {

  private final AccessDecisionEvaluator evaluator;

  public AccessRouteAspect(AccessDecisionEvaluator evaluator) {
    this.evaluator = Objects.requireNonNull(evaluator, "evaluator");
  }

  @Override
  public boolean preHandle(
      HttpServletRequest request, HttpServletResponse response, Object handler) {
    if (!(handler instanceof HandlerMethod handlerMethod)) {
      return true;
    }

    Method method = handlerMethod.getMethod();
    Class<?> beanType = handlerMethod.getBeanType();
    Optional<RouteSpec> spec = resolveRouteSpec(method, beanType);
    if (spec.isEmpty()) {
      return true;
    }

    AccessDecision decision = evaluator.evaluate(spec.get().resource(), spec.get().action());
    Objects.requireNonNull(decision, "evaluator returned null AccessDecision");
    if (!decision.permit()) {
      throw new AccessDeniedException(
          spec.get().resource(), spec.get().action(), decision.denyReason());
    }
    return true;
  }

  /**
   * 메소드 + class 영역 → {@link RouteSpec} 결정. lookup 순서:
   *
   * <ol>
   *   <li>메소드 레벨 {@link AccessRoute} (Spring AnnotationUtils — meta-annotation 지원)</li>
   *   <li>class 레벨 {@link AccessRoute} (모든 method 단일 (resource, action))</li>
   *   <li>class 레벨 {@link DefaultAccessRoute} + method 의 HTTP method + path 로 자동 derive</li>
   * </ol>
   *
   * @param method      controller method
   * @param beanType    handler bean 의 실제 class (HandlerMethod.getBeanType())
   * @return RouteSpec 영역 (3 단계 lookup 모두 실패 = empty)
   */
  Optional<RouteSpec> resolveRouteSpec(Method method, Class<?> beanType) {
    AccessRoute methodLevel = AnnotationUtils.findAnnotation(method, AccessRoute.class);
    if (methodLevel != null) {
      return Optional.of(new RouteSpec(methodLevel.resource(), methodLevel.action()));
    }

    AccessRoute classLevel = AnnotationUtils.findAnnotation(beanType, AccessRoute.class);
    if (classLevel != null) {
      return Optional.of(new RouteSpec(classLevel.resource(), classLevel.action()));
    }

    DefaultAccessRoute defaultRoute =
        AnnotationUtils.findAnnotation(beanType, DefaultAccessRoute.class);
    if (defaultRoute != null) {
      Optional<CrudEndpointAction> action = detectCrudAction(method);
      if (action.isPresent()) {
        String resource = defaultRoute.resourcePrefix() + "." + defaultRoute.entityName();
        return Optional.of(new RouteSpec(resource, action.get().actionName()));
      }
    }

    return Optional.empty();
  }

  /**
   * controller method 의 Spring HTTP mapping 어노테이션 → 8 endpoint matrix lookup.
   *
   * <p>{@link AnnotatedElementUtils#findMergedAnnotation} 은 meta-annotation (@PostMapping,
   * @GetMapping 등) 의 attribute alias (value &lt;-&gt; path) 자동 환원. {@link AnnotationUtils#findAnnotation}
   * 은 alias 환원 안 함 → path 가 empty 로 보임 (재발 영구 방지 영역).
   *
   * @param method controller method
   * @return 매트릭스 매칭 시 {@link CrudEndpointAction}, 매칭 없으면 empty
   */
  Optional<CrudEndpointAction> detectCrudAction(Method method) {
    RequestMapping merged =
        AnnotatedElementUtils.findMergedAnnotation(method, RequestMapping.class);
    if (merged == null) {
      return Optional.empty();
    }
    RequestMethod[] methods = merged.method();
    if (methods.length == 0) {
      return Optional.empty();
    }
    HttpMethod httpMethod = HttpMethod.valueOf(methods[0].name());
    List<String> paths = collectPaths(merged);
    return CrudEndpointAction.resolve(httpMethod, paths);
  }

  private List<String> collectPaths(RequestMapping merged) {
    String[] path = merged.path();
    String[] value = merged.value();
    List<String> all = new ArrayList<>();
    all.addAll(Arrays.asList(path));
    for (String v : value) {
      if (!all.contains(v)) {
        all.add(v);
      }
    }
    return all;
  }

  /**
   * (resource, action) pair 내부 표현. record — DTO 영역 (Decision #5 정합).
   *
   * @param resource PDP resource
   * @param action   PDP action
   */
  record RouteSpec(String resource, String action) {}
}
