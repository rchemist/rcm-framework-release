/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.trustedproxy;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #8 — {@code platform.security.trusted-proxy.*} prefix 의 yml binding.
 *
 * <p>{@code cidrAllowlist} 명시 시 그 CIDR 안에서 들어오는 요청만 forwarded header 신뢰. 외부 IP
 * 가 직접 X-Forwarded-For 위조해 들어오는 시나리오 차단 (default fail-closed = X-Forwarded-* 무시).
 *
 * <p>{@code enabled} = false 시 필터 자체 미동작 (= forwarded 검증 안 함, dev 환경 baseline).
 **/
@ConfigurationProperties(prefix = "platform.security.trusted-proxy")
public record TrustedProxyProperties(
    @DefaultValue("false") boolean enabled,
    @DefaultValue List<String> cidrAllowlist,
    @DefaultValue("X-Forwarded-For") String headerName,
    @DefaultValue("true") boolean failClosed) {}
