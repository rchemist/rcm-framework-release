/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.idempotency;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Expiry;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #7 — Redis 부재 시 graceful fallback. Caffeine cache 위 per-entry TTL response.
 **/
public class InMemoryIdempotencyStore implements IdempotencyStore {

  private final Cache<String, EntryWithTtl> cache;

  public InMemoryIdempotencyStore(long maxEntries) {
    this.cache =
        Caffeine.newBuilder()
            .maximumSize(maxEntries)
            .expireAfter(
                new Expiry<String, EntryWithTtl>() {
                  @Override
                  public long expireAfterCreate(String key, EntryWithTtl v, long currentTime) {
                    return TimeUnit.MILLISECONDS.toNanos(v.ttl().toMillis());
                  }

                  @Override
                  public long expireAfterUpdate(
                      String key, EntryWithTtl v, long currentTime, long currentDuration) {
                    return TimeUnit.MILLISECONDS.toNanos(v.ttl().toMillis());
                  }

                  @Override
                  public long expireAfterRead(
                      String key, EntryWithTtl v, long currentTime, long currentDuration) {
                    return currentDuration;
                  }
                })
            .build();
  }

  @Override
  public Optional<CachedResponse> get(String key) {
    EntryWithTtl entry = cache.getIfPresent(key);
    return entry == null ? Optional.empty() : Optional.of(entry.response());
  }

  @Override
  public void save(String key, CachedResponse response, Duration ttl) {
    cache.put(key, new EntryWithTtl(response, ttl));
  }

  record EntryWithTtl(CachedResponse response, Duration ttl) {}
}
