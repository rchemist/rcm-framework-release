/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.tokenstore;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Expiry;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #4 — Redis 부재 시 graceful fallback. Caffeine cache 위 per-entry TTL.
 *
 * <p>적용:
 * <ul>
 *   <li>refresh + blacklist 별 분리 cache (TTL 정책 분리)</li>
 *   <li>{@link #consumeRefresh(String)} = atomic — Caffeine 의 {@link Cache#asMap()} 의
 *       {@link java.util.concurrent.ConcurrentMap#remove(Object)} 위임 (compare-and-remove
 *       표준)</li>
 *   <li>maxEntries 도달 시 LRU evict — 운영 환경 대량 traffic 영역에서는 Redis 권고</li>
 * </ul>
 *
 * <p>본 impl 은 단일 노드 baseline. 다중 노드 = {@link RedisTokenStore} 전환 (Decision #16
 * monolithic baseline + horizontal scale 옵션 정합).
 **/
public class InMemoryTokenStore implements TokenStore {

  private final Cache<String, EntryWithTtl<String>> refreshCache;
  private final Cache<String, EntryWithTtl<Boolean>> blacklistCache;

  public InMemoryTokenStore(long maxEntries) {
    this.refreshCache = buildPerEntryTtlCache(maxEntries);
    this.blacklistCache = buildPerEntryTtlCache(maxEntries);
  }

  @Override
  public void saveRefresh(String jti, String userId, Duration ttl) {
    refreshCache.put(jti, new EntryWithTtl<>(userId, ttl));
  }

  @Override
  public Optional<String> consumeRefresh(String jti) {
    EntryWithTtl<String> entry = refreshCache.asMap().remove(jti);
    return entry == null ? Optional.empty() : Optional.of(entry.value());
  }

  @Override
  public void revoke(String jti, Duration ttl) {
    blacklistCache.put(jti, new EntryWithTtl<>(Boolean.TRUE, ttl));
  }

  @Override
  public boolean isBlacklisted(String jti) {
    return blacklistCache.getIfPresent(jti) != null;
  }

  // -----------------------------------------------------------------
  // Caffeine helper
  // -----------------------------------------------------------------

  private static <V> Cache<String, EntryWithTtl<V>> buildPerEntryTtlCache(long max) {
    return Caffeine.newBuilder()
        .maximumSize(max)
        .expireAfter(
            new Expiry<String, EntryWithTtl<V>>() {
              @Override
              public long expireAfterCreate(String key, EntryWithTtl<V> v, long currentTime) {
                return TimeUnit.MILLISECONDS.toNanos(v.ttl().toMillis());
              }

              @Override
              public long expireAfterUpdate(
                  String key, EntryWithTtl<V> v, long currentTime, long currentDuration) {
                return TimeUnit.MILLISECONDS.toNanos(v.ttl().toMillis());
              }

              @Override
              public long expireAfterRead(
                  String key, EntryWithTtl<V> v, long currentTime, long currentDuration) {
                return currentDuration;
              }
            })
        .build();
  }

  /** Cache value + per-entry TTL — Caffeine {@link Expiry} 가 인입. */
  record EntryWithTtl<V>(V value, Duration ttl) {}
}
