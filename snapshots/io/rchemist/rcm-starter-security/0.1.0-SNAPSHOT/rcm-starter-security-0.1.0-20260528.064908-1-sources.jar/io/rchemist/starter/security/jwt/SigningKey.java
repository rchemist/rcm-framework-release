/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import java.time.Instant;
import java.util.Arrays;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #3 — JWT 서명 / 검증 단일 단위. {@link SigningKeyRegistry} 가 N 개 보유.
 *
 * <p>{@code kid} = JWS header 의 key ID. 토큰 검증 시 어느 key 로 서명했는지 식별.
 * {@code secret} = HMAC raw bytes (HS512 = 64 bytes 권고). {@code notBefore} / {@code notAfter}
 * = 활성 시간 창 (둘 다 nullable — null = 영구 활성).
 *
 * <p>본 Records 는 *immutable + value-based*. {@code secret} 은 byte[] 라 Records 의 default
 * {@link #equals(Object)} / {@link #hashCode()} 가 reference 비교 → custom impl 필요.
 **/
public record SigningKey(String kid, byte[] secret, Instant notBefore, Instant notAfter) {

  public SigningKey {
    if (kid == null || kid.isBlank()) {
      throw new IllegalArgumentException("kid must not be blank");
    }
    if (secret == null || secret.length == 0) {
      throw new IllegalArgumentException("secret must not be empty");
    }
    if (notBefore != null && notAfter != null && !notBefore.isBefore(notAfter)) {
      throw new IllegalArgumentException("notBefore must be before notAfter");
    }
    secret = secret.clone();
  }

  /** 주어진 시점에 본 key 가 valid 한지. {@code notBefore} ≤ when < {@code notAfter}. */
  public boolean isValidAt(Instant when) {
    if (notBefore != null && when.isBefore(notBefore)) {
      return false;
    }
    if (notAfter != null && !when.isBefore(notAfter)) {
      return false;
    }
    return true;
  }

  @Override
  public byte[] secret() {
    return secret.clone();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof SigningKey other)) {
      return false;
    }
    return kid.equals(other.kid)
        && Arrays.equals(secret, other.secret)
        && java.util.Objects.equals(notBefore, other.notBefore)
        && java.util.Objects.equals(notAfter, other.notAfter);
  }

  @Override
  public int hashCode() {
    int result = kid.hashCode();
    result = 31 * result + Arrays.hashCode(secret);
    result = 31 * result + java.util.Objects.hashCode(notBefore);
    result = 31 * result + java.util.Objects.hashCode(notAfter);
    return result;
  }

  @Override
  public String toString() {
    return "SigningKey[kid=" + kid + ", secret=<" + secret.length + " bytes>, notBefore="
        + notBefore + ", notAfter=" + notAfter + "]";
  }
}
