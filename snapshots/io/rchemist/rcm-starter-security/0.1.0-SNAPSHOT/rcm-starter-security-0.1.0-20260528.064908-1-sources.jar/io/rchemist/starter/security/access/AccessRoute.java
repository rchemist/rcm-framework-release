/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — method-level PDP enforcement annotation. controller method 진입 직전 {@link
 * AccessRouteAspect} 의 {@code @Around} advice 가 본 어노테이션의 {@code (resource, action)} pair
 * 를 {@link AccessDecisionEvaluator} 에 전달 → DENY 의 경우 {@link AccessDeniedException} throw.
 *
 * <p>적용:
 * <ul>
 *   <li>method 부착 = 우선 — class-level {@code @DefaultAccessRoute} 가용해도 그 자동 매핑 영역을
 *       덮음 (override 보존)</li>
 *   <li>method 부재 + class-level {@code @DefaultAccessRoute} 보유 = 자동 매핑 fallback (8 endpoint
 *       매트릭스 기반)</li>
 *   <li>둘 다 부재 = no-op (기존 동작 보존)</li>
 * </ul>
 *
 * <p>{@link AccessDecisionEvaluator} bean 미존재 시 = baseline {@code PermitAllAccessDecisionEvaluator}
 * 자동 등록 → 모든 평가 PERMIT (framework 가 PDP 결정 정책 직접 제공 X, consumer 결정). 즉 dev 영역
 * 에서는 본 어노테이션 부착 = no-op 효과 + production 에서 consumer 가 {@link
 * AccessDecisionEvaluator} bean 등록 시 자동 enforce.
 **/
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AccessRoute {

  /**
   * PDP resource 식별자 — 도메인 + entity 정합 (예: {@code Learning.Course} / {@code Showcase.Article}).
   *
   * @return resource (NotBlank 강제 — 빈 문자열 = advice 가 IllegalArgumentException)
   */
  String resource();

  /**
   * PDP action 식별자 — 8 endpoint matrix 의 {@code create / list / search / count / read / update /
   * delete / bulkDelete / searchSchema} 또는 consumer 도메인 action.
   *
   * @return action
   */
  String action();
}
