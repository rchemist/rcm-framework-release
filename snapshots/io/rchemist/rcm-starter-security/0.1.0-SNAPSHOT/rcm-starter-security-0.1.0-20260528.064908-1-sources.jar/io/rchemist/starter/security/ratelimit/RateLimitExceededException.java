/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.ratelimit;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #6 — RateLimit 초과 시 throw. {@link io.rchemist.core.error.ServiceException}
 * 영역 (Phase 2) 과 정합 — Decision #24 의 ProblemDetail 자동 변환에 인입.
 *
 * <p>Phase 2 의 ProblemDetailAdvice 가 본 exception → HTTP 429 + RFC 7807 매핑 (별도 advice 등록
 * 영역, Phase 5 #6 baseline 은 exception 정의 + AOP throw 까지).
 **/
public class RateLimitExceededException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final String limiterName;
  private final String key;

  public RateLimitExceededException(String limiterName, String key) {
    super("Rate limit exceeded: limiter=" + limiterName + " key=" + key);
    this.limiterName = limiterName;
    this.key = key;
  }

  public String limiterName() {
    return limiterName;
  }

  public String key() {
    return key;
  }
}
