/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — RFC 6238 TOTP 표준 구현 (HMAC-SHA1 30s window + 6 digits default).
 *
 * <p>외부 dep 없이 JDK 의 {@link Mac} + {@link SecretKeySpec} 위. SHA-256 / SHA-512 옵션은
 * algorithm 인자로 변경 — RFC 6238 §1.2 정합.
 *
 * <p>본 utility 는 stateless. {@link TotpMfaProvider} 가 상위 SPI 영역.
 **/
public final class Totp {

  /** RFC 6238 default = 30 초 timestep. */
  public static final Duration DEFAULT_PERIOD = Duration.ofSeconds(30);

  /** RFC 6238 default = 6 digits. 8 까지 허용. */
  public static final int DEFAULT_DIGITS = 6;

  /** RFC 6238 default = HmacSHA1. */
  public static final String DEFAULT_ALGORITHM = "HmacSHA1";

  private static final int[] DIGITS_POWER = {
      1, 10, 100, 1_000, 10_000, 100_000, 1_000_000, 10_000_000, 100_000_000
  };

  private Totp() {}

  /** 현 시점 + default 30s/6d/SHA1 + 주어진 secret raw 으로 TOTP 생성. */
  public static String generate(byte[] secret) {
    return generate(secret, Instant.now(), DEFAULT_PERIOD, DEFAULT_DIGITS, DEFAULT_ALGORITHM);
  }

  /** 명시 시점에 TOTP 생성 — RFC 6238 표준 algorithm. */
  public static String generate(
      byte[] secret, Instant when, Duration period, int digits, String algorithm) {
    if (digits < 6 || digits > 8) {
      throw new IllegalArgumentException("digits must be in [6, 8]");
    }
    long timestep = when.getEpochSecond() / period.getSeconds();
    return computeCode(secret, timestep, digits, algorithm);
  }

  /**
   * 검증 시점 ± window (timestep 단위) 안의 모든 timestep 에 대해 매칭 — clock skew + 사용자
   * 지연 허용. window=1 = 현재 + 직전 + 다음 timestep 30s = ±30s 영역 valid.
   */
  public static boolean verify(byte[] secret, String code, int window) {
    return verify(secret, code, window, Instant.now(), DEFAULT_PERIOD, DEFAULT_DIGITS, DEFAULT_ALGORITHM);
  }

  public static boolean verify(
      byte[] secret,
      String code,
      int window,
      Instant when,
      Duration period,
      int digits,
      String algorithm) {
    if (code == null || code.length() != digits) {
      return false;
    }
    long now = when.getEpochSecond() / period.getSeconds();
    for (long ts = now - window; ts <= now + window; ts++) {
      String candidate = computeCode(secret, ts, digits, algorithm);
      if (constantTimeEquals(candidate, code)) {
        return true;
      }
    }
    return false;
  }

  /** Cryptographically random secret — RFC 6238 권고 = 160 bits (HMAC-SHA1) ≥ 20 bytes. */
  public static byte[] randomSecret() {
    return randomSecret(20);
  }

  public static byte[] randomSecret(int bytes) {
    byte[] result = new byte[bytes];
    new SecureRandom().nextBytes(result);
    return result;
  }

  // -----------------------------------------------------------------
  // RFC 6238 algorithm
  // -----------------------------------------------------------------

  private static String computeCode(byte[] secret, long timestep, int digits, String algorithm) {
    try {
      byte[] msg = ByteBuffer.allocate(8).putLong(timestep).array();
      Mac mac = Mac.getInstance(algorithm);
      mac.init(new SecretKeySpec(secret, "RAW"));
      byte[] hash = mac.doFinal(msg);

      int offset = hash[hash.length - 1] & 0x0F;
      int binary =
          ((hash[offset] & 0x7F) << 24)
              | ((hash[offset + 1] & 0xFF) << 16)
              | ((hash[offset + 2] & 0xFF) << 8)
              | (hash[offset + 3] & 0xFF);
      int otp = binary % DIGITS_POWER[digits];
      return String.format("%0" + digits + "d", otp);
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException("TOTP algorithm not available: " + algorithm, e);
    }
  }

  private static boolean constantTimeEquals(String a, String b) {
    if (a.length() != b.length()) {
      return false;
    }
    int result = 0;
    for (int i = 0; i < a.length(); i++) {
      result |= a.charAt(i) ^ b.charAt(i);
    }
    return result == 0;
  }
}
