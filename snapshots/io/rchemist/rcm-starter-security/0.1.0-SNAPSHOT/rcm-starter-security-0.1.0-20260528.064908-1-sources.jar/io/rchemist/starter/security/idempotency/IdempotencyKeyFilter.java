/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.idempotency;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #7 — {@code Idempotency-Key} HTTP header 필터. 같은 key 의 두 번째 요청 시 cached
 * response replay (RFC draft-ietf-httpapi-idempotency-key 정합).
 *
 * <p>흐름:
 * <ol>
 *   <li>요청 메소드가 {@link IdempotencyProperties#methods()} 에 포함 + {@code Idempotency-Key}
 *       header 명시 → store lookup</li>
 *   <li>Hit = cached response replay (status / content-type / headers / body 모두 복원)</li>
 *   <li>Miss = chain 진행 + 응답 capture ({@link ContentCachingResponseWrapper}) + store save</li>
 *   <li>4xx 응답은 cache 안 함 (client error 재시도 시 다시 처리하도록)</li>
 * </ol>
 *
 * <p>{@code OncePerRequestFilter} 표준 패턴 — 동일 request 안 중복 호출 회피. SecurityFilterChain
 * 의 추가 filter (Phase 5 task #1 영역의 default chain 또는 Consumer 명시 합류).
 **/
public class IdempotencyKeyFilter extends OncePerRequestFilter {

  private final IdempotencyStore store;
  private final IdempotencyProperties properties;
  private final Set<String> methodsUpper;

  public IdempotencyKeyFilter(IdempotencyStore store, IdempotencyProperties properties) {
    this.store = Objects.requireNonNull(store, "store");
    this.properties = Objects.requireNonNull(properties, "properties");
    this.methodsUpper = new HashSet<>();
    for (String m : properties.methods()) {
      methodsUpper.add(m.toUpperCase(Locale.ROOT));
    }
  }

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws ServletException, IOException {
    if (!properties.enabled() || !methodsUpper.contains(request.getMethod().toUpperCase(Locale.ROOT))) {
      chain.doFilter(request, response);
      return;
    }

    String key = request.getHeader(properties.headerName());
    if (key == null || key.isBlank()) {
      chain.doFilter(request, response);
      return;
    }

    String storeKey = properties.keyPrefix() + key;
    Optional<IdempotencyStore.CachedResponse> cached = store.get(storeKey);
    if (cached.isPresent()) {
      replay(response, cached.get());
      return;
    }

    ContentCachingResponseWrapper wrapper = new ContentCachingResponseWrapper(response);
    chain.doFilter(request, wrapper);
    int status = wrapper.getStatus();
    if (status < 400) {
      Map<String, List<String>> headers = new HashMap<>();
      for (String name : wrapper.getHeaderNames()) {
        headers.put(name, List.copyOf(wrapper.getHeaders(name)));
      }
      IdempotencyStore.CachedResponse toStore =
          new IdempotencyStore.CachedResponse(
              status, wrapper.getContentType(), wrapper.getContentAsByteArray(), headers);
      store.save(storeKey, toStore, properties.ttl());
    }
    wrapper.copyBodyToResponse();
  }

  private static void replay(HttpServletResponse response, IdempotencyStore.CachedResponse cached)
      throws IOException {
    response.setStatus(cached.status());
    if (cached.contentType() != null) {
      response.setContentType(cached.contentType());
    }
    cached.headers().forEach((name, values) -> values.forEach(v -> response.addHeader(name, v)));
    byte[] body = cached.body();
    if (body.length > 0) {
      response.getOutputStream().write(body);
      response.getOutputStream().flush();
    }
  }
}
