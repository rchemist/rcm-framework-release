/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.tokenstore;

import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import io.rchemist.core.context.UserContext;
import io.rchemist.starter.security.jwt.TokenIssuer;
import java.text.ParseException;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #4 — refresh token rotation 단일 진입점. OWASP 권고 패턴 (재사용 시도 → 전체
 * family blacklist).
 *
 * <p>흐름:
 * <ol>
 *   <li>Login = {@link #issueInitialPair(UserContext)} — access + refresh 페어. refresh 의 jti
 *       를 store 에 보관 (TTL = refresh ttl).</li>
 *   <li>Refresh API 호출 = {@link #rotate(String)} — 받은 refresh 의 jti atomic consume → 빈
 *       영역이면 *재사용 시도* → blacklist + {@link RefreshReuseException}. 정상 consume 이면 새
 *       access + 새 refresh 발급 (이전 refresh 는 store 에서 사라진 상태).</li>
 *   <li>Logout = {@link #revoke(String)} — refresh jti blacklist + store 제거.</li>
 * </ol>
 *
 * <p>{@link TokenIssuer} 위에서 동작 — Phase 5 #3 정합. {@link TokenStore} backend agnostic
 * (Redis / InMemory 둘 다 동일 동작).
 **/
public class RefreshRotator {

  private final TokenIssuer issuer;
  private final TokenStore store;
  private final Duration accessTtl;
  private final Duration refreshTtl;

  public RefreshRotator(
      TokenIssuer issuer, TokenStore store, Duration accessTtl, Duration refreshTtl) {
    this.issuer = Objects.requireNonNull(issuer, "issuer");
    this.store = Objects.requireNonNull(store, "store");
    this.accessTtl = Objects.requireNonNull(accessTtl, "accessTtl");
    this.refreshTtl = Objects.requireNonNull(refreshTtl, "refreshTtl");
  }

  /** Login 시점 호출 — access + refresh pair 발급 + refresh jti store 보관. */
  public TokenPair issueInitialPair(UserContext user) {
    Objects.requireNonNull(user, "user");
    String access = issuer.issueAccess(user, accessTtl);
    String refresh = issuer.issueRefresh(user, refreshTtl);
    String refreshJti = jtiOf(refresh);
    store.saveRefresh(refreshJti, user.userId(), refreshTtl);
    return new TokenPair(access, refresh);
  }

  /**
   * 받은 refresh token 으로 새 access + 새 refresh pair 발급. 재사용 시도 → {@link
   * RefreshReuseException} (Consumer 가 logout / lockout 결정 영역).
   */
  public TokenPair rotate(String refreshToken) {
    Objects.requireNonNull(refreshToken, "refreshToken");
    SignedJWT parsed = parse(refreshToken);
    String jti = jtiOf(parsed);

    if (store.isBlacklisted(jti)) {
      throw new RefreshReuseException("Refresh token is blacklisted: jti=" + jti);
    }

    Optional<String> consumed = store.consumeRefresh(jti);
    if (consumed.isEmpty()) {
      // 재사용 시도 또는 미존재 — 보안 강제 blacklist (이미 실제로는 다른 곳에서 consumed)
      store.revoke(jti, refreshTtl);
      throw new RefreshReuseException("Refresh token reuse detected: jti=" + jti);
    }

    String userId = consumed.get();
    UserContext rebuilt = userContextFrom(parsed, userId);
    String newAccess = issuer.issueAccess(rebuilt, accessTtl);
    String newRefresh = issuer.issueRefresh(rebuilt, refreshTtl);
    store.saveRefresh(jtiOf(newRefresh), userId, refreshTtl);
    return new TokenPair(newAccess, newRefresh);
  }

  /** Logout = refresh jti blacklist + store 제거. */
  public void revoke(String refreshToken) {
    Objects.requireNonNull(refreshToken, "refreshToken");
    String jti = jtiOf(refreshToken);
    store.consumeRefresh(jti);
    store.revoke(jti, refreshTtl);
  }

  // -----------------------------------------------------------------
  // helper
  // -----------------------------------------------------------------

  private static SignedJWT parse(String token) {
    try {
      return SignedJWT.parse(token);
    } catch (ParseException e) {
      throw new RefreshReuseException("Invalid refresh token format", e);
    }
  }

  private static String jtiOf(String token) {
    return jtiOf(parse(token));
  }

  private static String jtiOf(SignedJWT parsed) {
    try {
      JWTClaimsSet claims = parsed.getJWTClaimsSet();
      String jti = claims.getJWTID();
      if (jti == null || jti.isBlank()) {
        throw new RefreshReuseException("Refresh token missing jti claim");
      }
      return jti;
    } catch (ParseException e) {
      throw new RefreshReuseException("Failed to parse refresh claims", e);
    }
  }

  private static UserContext userContextFrom(SignedJWT parsed, String userId) {
    try {
      JWTClaimsSet claims = parsed.getJWTClaimsSet();
      String username = claims.getStringClaim("preferred_username");
      // refresh token 에는 보통 roles 미포함 — 신선한 인증 정보는 access 발급 시 IdP / DB 위임
      return new UserContext(userId, username, Set.of());
    } catch (ParseException e) {
      throw new RefreshReuseException("Failed to parse refresh claims", e);
    }
  }

  /** {@link #issueInitialPair} / {@link #rotate} 의 응답. Records — immutable. */
  public record TokenPair(String accessToken, String refreshToken) {}

  /** Refresh 재사용 또는 잘못된 형식 시 throw. */
  public static class RefreshReuseException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public RefreshReuseException(String message) {
      super(message);
    }

    public RefreshReuseException(String message, Throwable cause) {
      super(message, cause);
    }
  }

  /** Token 의 만료 시점 까지 남은 ttl 계산 — blacklist ttl 동기화 영역에서 사용. */
  static Duration remainingTtl(SignedJWT parsed) {
    try {
      Instant exp = parsed.getJWTClaimsSet().getExpirationTime().toInstant();
      Duration remaining = Duration.between(Instant.now(), exp);
      return remaining.isNegative() ? Duration.ZERO : remaining;
    } catch (ParseException e) {
      return Duration.ZERO;
    }
  }
}
