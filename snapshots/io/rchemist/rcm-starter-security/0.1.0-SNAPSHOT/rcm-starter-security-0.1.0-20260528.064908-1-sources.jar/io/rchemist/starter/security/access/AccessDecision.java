/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — {@link AccessDecisionEvaluator} 평가 결과. PERMIT / DENY 단순 2 분.
 *
 * <p>{@link #denyReason()} 은 DENY 의 경우 ProblemDetail body / 로그에 노출 (감사 trail). PERMIT 의
 * 경우 null 가능.
 *
 * <p>component 이름 {@code permit} = boolean accessor. static factory 는 {@link #permitted()} /
 * {@link #denied(String)} 명명 → record accessor 와 충돌 회피.
 **/
public record AccessDecision(boolean permit, String denyReason) {

  private static final AccessDecision PERMIT = new AccessDecision(true, null);

  /**
   * PERMIT singleton — 이유 없음 (정상).
   *
   * @return 항상 동일 instance (immutable record)
   */
  public static AccessDecision permitted() {
    return PERMIT;
  }

  /**
   * DENY factory — 거부 이유 명시 (감사 trail).
   *
   * @param reason 거부 사유 (예: {@code role missing: ADMIN})
   * @return DENY 결과
   */
  public static AccessDecision denied(String reason) {
    return new AccessDecision(false, reason);
  }
}
