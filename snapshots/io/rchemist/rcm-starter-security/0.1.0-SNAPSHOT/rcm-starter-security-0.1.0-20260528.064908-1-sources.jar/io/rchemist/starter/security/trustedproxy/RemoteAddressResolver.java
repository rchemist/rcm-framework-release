/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.trustedproxy;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #8 — {@link TrustedProxyFilter} 통과 후 client IP 추출 단일 지점.
 *
 * <p>{@code X-Forwarded-For} (또는 yml 명시 header) 가 살아있으면 chain 첫 번째 IP = client.
 * Stripped (untrusted source) 시점이면 {@link HttpServletRequest#getRemoteAddr()} fallback.
 *
 * <p>RateLimit (Phase 5 #6) / Idempotency (Phase 5 #7) 의 key resolver 가 본 utility 인입 영역.
 **/
public final class RemoteAddressResolver {

  private final TrustedProxyProperties properties;

  public RemoteAddressResolver(TrustedProxyProperties properties) {
    this.properties = Objects.requireNonNull(properties, "properties");
  }

  /** 신뢰 가능한 client IP 추출. 표준 X-Forwarded-For 의 chain 첫 번째 = 원래 client. */
  public String resolveClientIp(HttpServletRequest request) {
    Objects.requireNonNull(request, "request");
    String forwarded = request.getHeader(properties.headerName());
    if (forwarded != null && !forwarded.isBlank()) {
      // 첫 번째 IP — chain "client, proxy1, proxy2" 의 client
      int comma = forwarded.indexOf(',');
      String first = (comma < 0 ? forwarded : forwarded.substring(0, comma)).trim();
      if (!first.isEmpty()) {
        return first;
      }
    }
    return request.getRemoteAddr();
  }
}
