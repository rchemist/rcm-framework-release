/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import io.rchemist.core.context.UserContext;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #3 — JWT 발급 단일 진입점. {@link SigningKeyRegistry#activeKey()} 로 서명 + JWS
 * header 의 {@code kid} 부착 → Phase 5 task #4 의 Refresh rotation + 검증 영역에서 key 식별.
 *
 * <p>적용:
 * <ul>
 *   <li>{@link #issueAccess(UserContext, Duration)} — 표준 access token (subject = userId, roles
 *       claim, scope claim, jti UUID, iat / exp)</li>
 *   <li>{@link #issueRefresh(UserContext, Duration)} — refresh token ({@code typ = refresh}
 *       + jti, Phase 5 #4 의 store key)</li>
 *   <li>{@link #issue(UserContext, Duration, Map)} — extra claim 자유 합성 영역</li>
 * </ul>
 *
 * <p>{@code issuer} (constructor 적용) 는 {@code iss} claim 영역. JwtDecoder 의 {@link
 * org.springframework.security.oauth2.jwt.JwtIssuerValidator} 와 짝.
 **/
public class TokenIssuer {

  /** 표준 baseline access TTL — Consumer 가 method 인자로 override. */
  public static final Duration DEFAULT_ACCESS_TTL = Duration.ofMinutes(15);

  /** 표준 baseline refresh TTL — Consumer 가 method 인자로 override. */
  public static final Duration DEFAULT_REFRESH_TTL = Duration.ofDays(30);

  private final SigningKeyRegistry registry;
  private final JWSAlgorithm jwsAlgorithm;
  private final String issuer;

  public TokenIssuer(SigningKeyRegistry registry, MacAlgorithm algorithm, String issuer) {
    this.registry = Objects.requireNonNull(registry, "registry");
    this.jwsAlgorithm =
        JWSAlgorithm.parse(Objects.requireNonNull(algorithm, "algorithm").getName());
    this.issuer = issuer;
  }

  /** Default access TTL 로 token 발급. */
  public String issueAccess(UserContext user) {
    return issueAccess(user, DEFAULT_ACCESS_TTL);
  }

  /** 명시 TTL 로 access token 발급 — roles claim + scope claim 자동 부착. */
  public String issueAccess(UserContext user, Duration ttl) {
    Objects.requireNonNull(user, "user");
    Map<String, Object> extra = new LinkedHashMap<>();
    if (user.username() != null) {
      extra.put("preferred_username", user.username());
    }
    if (!user.roles().isEmpty()) {
      extra.put("roles", user.roles());
      extra.put("scope", String.join(" ", user.roles()));
    }
    return issue(user, ttl, extra);
  }

  /** Default refresh TTL 로 refresh token 발급. */
  public String issueRefresh(UserContext user) {
    return issueRefresh(user, DEFAULT_REFRESH_TTL);
  }

  /** 명시 TTL 로 refresh token 발급 — {@code typ = refresh} claim 자동 부착. */
  public String issueRefresh(UserContext user, Duration ttl) {
    return issue(user, ttl, Map.of("typ", "refresh"));
  }

  /** 임의 claim 합성 영역. {@code subject} = {@link UserContext#userId()} 항상 부착. */
  public String issue(UserContext user, Duration ttl, Map<String, Object> extra) {
    Objects.requireNonNull(user, "user");
    Objects.requireNonNull(ttl, "ttl");
    if (ttl.isNegative() || ttl.isZero()) {
      throw new IllegalArgumentException("ttl must be positive");
    }

    SigningKey active = registry.activeKey();
    Instant now = Instant.now();

    JWTClaimsSet.Builder claims =
        new JWTClaimsSet.Builder()
            .subject(user.userId())
            .jwtID(UUID.randomUUID().toString())
            .issueTime(Date.from(now))
            .expirationTime(Date.from(now.plus(ttl)));
    if (issuer != null && !issuer.isBlank()) {
      claims.issuer(issuer);
    }
    if (extra != null) {
      extra.forEach(claims::claim);
    }

    JWSHeader header = new JWSHeader.Builder(jwsAlgorithm).keyID(active.kid()).build();
    SignedJWT jwt = new SignedJWT(header, claims.build());
    try {
      jwt.sign(new MACSigner(active.secret()));
    } catch (JOSEException e) {
      throw new IllegalStateException("Failed to sign JWT with kid=" + active.kid(), e);
    }
    return jwt.serialize();
  }
}
