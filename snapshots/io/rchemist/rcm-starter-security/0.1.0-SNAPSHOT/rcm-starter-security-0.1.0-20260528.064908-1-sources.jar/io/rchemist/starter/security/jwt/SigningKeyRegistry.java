/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #3 — N 개의 {@link SigningKey} 보관 + active key 자동 추론 + kid 단건 lookup.
 *
 * <p>{@link #activeKey()} = 현재 시점에 valid 한 key 중 가장 최근 {@code notBefore} (= 최근 발급된
 * key). 이전 발급된 토큰은 그 시점의 active key 로 서명되어 있어 본 registry 의 {@link #findByKid}
 * 가 검증 위임 단일 지점.
 *
 * <p>본 클래스는 immutable — 새 key 추가 시 새 registry instance ({@link #with(SigningKey)}).
 * Spring DI 환경에서는 Consumer 가 자체 {@link SigningKeyRegistry} bean 적용 또는 동적 갱신
 * extension 영역.
 **/
public final class SigningKeyRegistry {

  private final List<SigningKey> keys;

  public SigningKeyRegistry(List<SigningKey> keys) {
    if (keys == null || keys.isEmpty()) {
      throw new IllegalArgumentException("keys must not be empty");
    }
    long distinctKids = keys.stream().map(SigningKey::kid).distinct().count();
    if (distinctKids != keys.size()) {
      throw new IllegalArgumentException("duplicate kid in registry");
    }
    this.keys = List.copyOf(keys);
  }

  /** 모든 보관 key (immutable snapshot). 검증용 {@link RotatingJwkSource} 가 인입. */
  public List<SigningKey> keys() {
    return keys;
  }

  /**
   * 현재 시점 valid 한 key (notBefore ≤ now < notAfter). 검증 영역에서 사용.
   * 만료된 key 는 본 list 에서 제외 → 만료 후 일정 기간 보존 정책은 본 registry 외부 (Consumer
   * 운영 영역).
   */
  public List<SigningKey> validKeys(Instant when) {
    return keys.stream().filter(k -> k.isValidAt(when)).toList();
  }

  /**
   * 발급용 active key — valid 한 key 중 {@code notBefore} 가 가장 최근. notBefore 가 null 인 key
   * 는 *제일 오래된* 으로 간주 (영구 활성 = 단일 키 시나리오).
   */
  public SigningKey activeKey() {
    Instant now = Instant.now();
    return keys.stream()
        .filter(k -> k.isValidAt(now))
        .max(Comparator.comparing(SigningKeyRegistry::orderBy))
        .orElseThrow(() -> new IllegalStateException("no active signing key at " + now));
  }

  /** 주어진 kid 의 key 단건 lookup — 검증 시점 사용. */
  public Optional<SigningKey> findByKid(String kid) {
    return keys.stream().filter(k -> k.kid().equals(kid)).findFirst();
  }

  /** immutable — 새 key 추가 시 새 instance 반환. */
  public SigningKeyRegistry with(SigningKey key) {
    return new SigningKeyRegistry(java.util.stream.Stream.concat(keys.stream(),
        java.util.stream.Stream.of(key)).toList());
  }

  /** 본 registry 가 단일 key 만 보유한지 — JWT decoder factory 의 single-key 분기 hook. */
  public boolean isSingleKey() {
    return keys.size() == 1;
  }

  private static Instant orderBy(SigningKey k) {
    return k.notBefore() == null ? Instant.MIN : k.notBefore();
  }

  /**
   * {@link JwtProperties} 위에 registry 합성. {@code keys[]} 명시 시 그 list, 그 외 {@code secret}
   * 단일 키 (kid={@code default}, 영구 활성). 둘 다 빈 영역이면 {@link IllegalStateException}.
   */
  public static SigningKeyRegistry from(JwtProperties props) {
    if (props.keys() != null && !props.keys().isEmpty()) {
      List<SigningKey> mapped = new ArrayList<>(props.keys().size());
      for (JwtProperties.KeyConfig cfg : props.keys()) {
        mapped.add(
            new SigningKey(
                cfg.kid(),
                Base64.getDecoder().decode(cfg.secret()),
                cfg.notBefore(),
                cfg.notAfter()));
      }
      return new SigningKeyRegistry(mapped);
    }
    if (props.secret() != null && !props.secret().isBlank()) {
      SigningKey synthetic =
          new SigningKey("default", Base64.getDecoder().decode(props.secret()), null, null);
      return new SigningKeyRegistry(List.of(synthetic));
    }
    throw new IllegalStateException(
        "JwtProperties has neither secret nor keys configured — registry empty");
  }
}
