/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.autoconfig;

import io.rchemist.starter.security.access.AccessDecisionEvaluator;
import io.rchemist.starter.security.access.AccessDeniedExceptionAdvice;
import io.rchemist.starter.security.access.AccessRouteAspect;
import io.rchemist.starter.security.access.PermitAllAccessDecisionEvaluator;
import io.rchemist.starter.security.jwt.JwtAuthenticationConverters;
import io.rchemist.starter.security.jwt.JwtDecoderFactory;
import io.rchemist.starter.security.jwt.JwtProperties;
import io.rchemist.starter.security.jwt.SigningKeyRegistry;
import io.rchemist.starter.security.jwt.TokenIssuer;
import io.github.resilience4j.ratelimiter.RateLimiterRegistry;
import io.rchemist.starter.security.context.UserContextFilter;
import io.rchemist.starter.security.mfa.InMemoryLockoutTracker;
import io.rchemist.starter.security.mfa.LockoutTracker;
import io.rchemist.starter.security.mfa.MfaProperties;
import io.rchemist.starter.security.mfa.MfaProvider;
import io.rchemist.starter.security.mfa.RedisLockoutTracker;
import io.rchemist.starter.security.mfa.TotpMfaProvider;
import io.rchemist.starter.security.idempotency.IdempotencyKeyFilter;
import io.rchemist.starter.security.idempotency.IdempotencyProperties;
import io.rchemist.starter.security.idempotency.IdempotencyStore;
import io.rchemist.starter.security.idempotency.InMemoryIdempotencyStore;
import io.rchemist.starter.security.limits.PageableLimitEnforcer;
import io.rchemist.starter.security.limits.RequestLimitsProperties;
import io.rchemist.starter.security.limits.SortWhitelistValidator;
import io.rchemist.starter.security.trustedproxy.RemoteAddressResolver;
import io.rchemist.starter.security.trustedproxy.TrustedProxyFilter;
import io.rchemist.starter.security.trustedproxy.TrustedProxyProperties;
import io.rchemist.starter.security.ratelimit.RateLimitInterceptor;
import io.rchemist.starter.security.ratelimit.RateLimitKeyResolver;
import io.rchemist.starter.security.ratelimit.RateLimitProperties;
import io.rchemist.starter.security.tokenstore.InMemoryTokenStore;
import io.rchemist.starter.security.tokenstore.RedisTokenStore;
import io.rchemist.starter.security.tokenstore.RefreshRotator;
import io.rchemist.starter.security.tokenstore.TokenStore;
import io.rchemist.starter.security.tokenstore.TokenStoreProperties;
import java.time.Duration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #1 + #2 — {@code rcm-starter-security} 진입점.
 *
 * <p>baseline 적용 (Decision #1 + Decision #20 + 청사진 §2.2):
 * <ul>
 *   <li>{@link EnableWebSecurity} 활성 — Spring Security 7 의 {@link HttpSecurity} 진입</li>
 *   <li>default {@link SecurityFilterChain} — stateless / CSRF off / actuator health permitAll</li>
 *   <li>Consumer 자체 {@link SecurityFilterChain} bean 적용 시 {@link ConditionalOnMissingBean}
 *       으로 자동 양보</li>
 *   <li>{@link SecurityProperties} 의 {@code platform.security.*} yml 로 baseline 갈음</li>
 *   <li>{@link JwtProperties#isEnabled()} 시 {@link JwtDecoder} bean 자동 등록 + filter chain 의
 *       {@code oauth2ResourceServer().jwt(...)} 합류 (Phase 5 task #2)</li>
 * </ul>
 *
 * <p>Token store (#4) / MFA (#5) / RateLimit (#6) / Idempotency (#7) / TrustedProxy (#8) /
 * RequestLimits (#9) / UserContext binding (#10) 은 후속 task 의 별도 sub-package 에서 합류 —
 * 각자 자체 {@code @AutoConfiguration} 또는 본 클래스의 conditional bean.
 *
 * <p>Decision #20 정합 — 본 클래스 이전 stub {@code RcmStarterSecurityAutoConfiguration} 의
 * {@code Rcm} prefix 영구 거부 + 패키지 {@code io.rchemist.security} → {@code
 * io.rchemist.starter.security.autoconfig} 정정.
 **/
@AutoConfiguration
@ConditionalOnClass(HttpSecurity.class)
@ConditionalOnProperty(name = "platform.security.enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties({
  SecurityProperties.class,
  JwtProperties.class,
  TokenStoreProperties.class,
  MfaProperties.class,
  RateLimitProperties.class,
  IdempotencyProperties.class,
  TrustedProxyProperties.class,
  RequestLimitsProperties.class
})
@EnableWebSecurity
public class SecurityAutoConfiguration {

  /**
   * baseline {@link SecurityFilterChain} — Consumer 미적용 시 framework default.
   *
   * <p>적용:
   * <ul>
   *   <li>CSRF 비활성 — REST API baseline (token-based, session-less)</li>
   *   <li>session = STATELESS — JWT 진입 (Phase 5 #2) 영역 선결</li>
   *   <li>{@link SecurityProperties#permitPaths()} 화이트리스트 + {@link
   *       SecurityProperties#defaultPermitAll()} 분기 — actuator health/info default permit,
   *       그 외 {@code authenticated()}</li>
   *   <li>{@code formLogin} / {@code httpBasic} 비활성 — JWT bearer + oauth2-resource-server (Phase 5 #2)
   *       단일 진입</li>
   *   <li>{@link JwtDecoder} bean 가용 시 {@code oauth2ResourceServer().jwt()} 자동 합류 — JWT
   *       Bearer token 검증 + {@link JwtAuthenticationConverter} 로 authority 변환 (Phase 5 #2)</li>
   * </ul>
   */
  @Bean
  @ConditionalOnMissingBean(SecurityFilterChain.class)
  public SecurityFilterChain rcmDefaultSecurityFilterChain(
      HttpSecurity http,
      SecurityProperties properties,
      ObjectProvider<JwtDecoder> jwtDecoder,
      ObjectProvider<JwtAuthenticationConverter> jwtAuthConverter,
      ObjectProvider<UserContextFilter> userContextFilter)
      throws Exception {
    http.csrf(csrf -> csrf.disable())
        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .formLogin(form -> form.disable())
        .httpBasic(basic -> basic.disable())
        .exceptionHandling(
            ex -> ex.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)));

    if (properties.defaultPermitAll()) {
      http.authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
    } else {
      http.authorizeHttpRequests(
          auth -> {
            if (!properties.permitPaths().isEmpty()) {
              auth.requestMatchers(properties.permitPaths().toArray(String[]::new)).permitAll();
            }
            auth.anyRequest().authenticated();
          });
    }

    JwtDecoder decoder = jwtDecoder.getIfAvailable();
    if (decoder != null) {
      JwtAuthenticationConverter converter = jwtAuthConverter.getIfAvailable();
      http.oauth2ResourceServer(
          oauth2 ->
              oauth2.jwt(
                  jwt -> {
                    jwt.decoder(decoder);
                    if (converter != null) {
                      jwt.jwtAuthenticationConverter(converter);
                    }
                  }));
    }

    UserContextFilter contextFilter = userContextFilter.getIfAvailable();
    if (contextFilter != null) {
      http.addFilterAfter(
          contextFilter,
          org.springframework.security.web.context.SecurityContextHolderFilter.class);
    }

    return http.build();
  }

  /**
   * Phase 5 task #2 + #3 — {@link JwtProperties#isEnabled()} 시 JWT 영역 활성.
   *
   * <p>활성 분기:
   * <ul>
   *   <li>{@code platform.security.jwt.secret} 명시 (Phase 5 #2 backward 호환 single-key)</li>
   *   <li>또는 {@code platform.security.jwt.keys[]} 명시 (Phase 5 #3 multi-key rotation)</li>
   * </ul>
   * 둘 다 빈 영역 = 본 inner config 비활성 → 기본 SecurityFilterChain 의 JWT 분기도 silent skip.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(prefix = "platform.security.jwt", name = "secret")
  static class SingleSecretJwtBeans {

    @Bean
    @ConditionalOnMissingBean(SigningKeyRegistry.class)
    SigningKeyRegistry rcmSigningKeyRegistry(JwtProperties properties) {
      return SigningKeyRegistry.from(properties);
    }

    @Bean
    @ConditionalOnMissingBean(JwtDecoder.class)
    JwtDecoder rcmJwtDecoder(JwtProperties properties) {
      return JwtDecoderFactory.create(properties);
    }

    @Bean
    @ConditionalOnMissingBean(JwtAuthenticationConverter.class)
    JwtAuthenticationConverter rcmJwtAuthenticationConverter(JwtProperties properties) {
      return JwtAuthenticationConverters.from(properties);
    }

    @Bean
    @ConditionalOnMissingBean(TokenIssuer.class)
    TokenIssuer rcmTokenIssuer(SigningKeyRegistry registry, JwtProperties properties) {
      return new TokenIssuer(registry, properties.signingAlgorithm(), properties.issuer());
    }
  }

  /**
   * Phase 5 task #3 — multi-key rotation 영역. {@code platform.security.jwt.keys[0].kid} 명시 시
   * 활성 (가장 첫 key 의 kid 가 명시되면 list 가 채워진 영역).
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(prefix = "platform.security.jwt.keys[0]", name = "kid")
  static class MultiKeyJwtBeans {

    @Bean
    @ConditionalOnMissingBean(SigningKeyRegistry.class)
    SigningKeyRegistry rcmSigningKeyRegistry(JwtProperties properties) {
      return SigningKeyRegistry.from(properties);
    }

    @Bean
    @ConditionalOnMissingBean(JwtDecoder.class)
    JwtDecoder rcmJwtDecoder(JwtProperties properties) {
      return JwtDecoderFactory.create(properties);
    }

    @Bean
    @ConditionalOnMissingBean(JwtAuthenticationConverter.class)
    JwtAuthenticationConverter rcmJwtAuthenticationConverter(JwtProperties properties) {
      return JwtAuthenticationConverters.from(properties);
    }

    @Bean
    @ConditionalOnMissingBean(TokenIssuer.class)
    TokenIssuer rcmTokenIssuer(SigningKeyRegistry registry, JwtProperties properties) {
      return new TokenIssuer(registry, properties.signingAlgorithm(), properties.issuer());
    }
  }

  /**
   * Phase 5 task #4 + Issue #22 — token store (Redis 분기) 영역.
   *
   * <p>본 inner class 는 *클래스 레벨* {@link ConditionalOnClass}({@code StringRedisTemplate.class})
   * 으로 gate. Spring Boot 가 ASM 으로 어노테이션을 읽고 클래스 자체를 미로드 → {@code
   * spring-data-redis} 미포함 consumer 의 introspection 단계 {@code NoClassDefFoundError} 회피.
   *
   * <p>Consumer 가 자체 {@link TokenStore} bean 적용 시 {@link ConditionalOnMissingBean} 자동 양보.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(org.springframework.data.redis.core.StringRedisTemplate.class)
  @AutoConfigureAfter({SingleSecretJwtBeans.class, MultiKeyJwtBeans.class})
  static class RedisTokenStoreBeans {

    @Bean
    @ConditionalOnBean(name = "stringRedisTemplate")
    @ConditionalOnMissingBean(TokenStore.class)
    TokenStore rcmRedisTokenStore(
        org.springframework.data.redis.core.StringRedisTemplate stringRedisTemplate,
        TokenStoreProperties properties) {
      return new RedisTokenStore(
          stringRedisTemplate, properties.refreshKeyPrefix(), properties.blacklistKeyPrefix());
    }
  }

  /**
   * Phase 5 task #4 — token store (InMemory fallback) + refresh rotation 영역.
   *
   * <p>{@link RedisTokenStoreBeans} 가 활성 + {@link
   * org.springframework.data.redis.core.StringRedisTemplate} bean 가용 시 Redis 분기 우선. 그 외 →
   * {@link InMemoryTokenStore} 단일 노드 graceful fallback. Consumer 가 자체 {@link TokenStore} bean
   * 적용 시 {@link ConditionalOnMissingBean} 자동 양보.
   *
   * <p>{@link RefreshRotator} 는 {@link TokenIssuer} 와 {@link TokenStore} 양쪽 bean 모두 가용 시
   * 자동 합성 — 즉 JWT 영역이 활성 (Phase 5 #2 또는 #3) + token store 가용 영역 정합.
   *
   * <p>Issue #22 — {@code StringRedisTemplate} 직접 참조 제거 (Redis 의존 bean 은 {@link
   * RedisTokenStoreBeans} 로 이전). 본 클래스 introspection 시 {@code NoClassDefFoundError} 영구
   * 회피.
   */
  @Configuration(proxyBeanMethods = false)
  @AutoConfigureAfter({
    SingleSecretJwtBeans.class,
    MultiKeyJwtBeans.class,
    RedisTokenStoreBeans.class
  })
  static class TokenStoreBeans {

    @Bean
    @ConditionalOnMissingBean(TokenStore.class)
    TokenStore rcmInMemoryTokenStore(TokenStoreProperties properties) {
      return new InMemoryTokenStore(properties.maxEntries());
    }

    @Bean
    @ConditionalOnBean({TokenIssuer.class, TokenStore.class})
    @ConditionalOnMissingBean(RefreshRotator.class)
    RefreshRotator rcmRefreshRotator(TokenIssuer issuer, TokenStore store) {
      return new RefreshRotator(
          issuer, store, Duration.ofMinutes(15), Duration.ofDays(30));
    }
  }

  /**
   * Phase 5 task #5 + Issue #22 — MFA Redis 분기 영역.
   *
   * <p>본 inner class 는 *클래스 레벨* {@link ConditionalOnClass}({@code StringRedisTemplate.class})
   * 으로 gate. {@code spring-data-redis} 미포함 consumer 의 introspection 단계 {@code
   * NoClassDefFoundError} 회피.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(org.springframework.data.redis.core.StringRedisTemplate.class)
  @ConditionalOnProperty(name = "platform.security.mfa.enabled", havingValue = "true")
  static class RedisMfaBeans {

    @Bean
    @ConditionalOnBean(name = "stringRedisTemplate")
    @ConditionalOnMissingBean(LockoutTracker.class)
    LockoutTracker rcmRedisLockoutTracker(
        org.springframework.data.redis.core.StringRedisTemplate stringRedisTemplate,
        MfaProperties properties) {
      return new RedisLockoutTracker(
          stringRedisTemplate, properties.lockoutPolicy(), "rcm:security:mfa:");
    }
  }

  /**
   * Phase 5 task #5 — MFA 영역 (InMemory fallback + TOTP). {@code platform.security.mfa.enabled=true}
   * 시 활성. baseline = {@link TotpMfaProvider} (RFC 6238) + {@link LockoutTracker} ({@link
   * RedisMfaBeans} 활성 시 Redis 분기 우선, 그 외 InMemory).
   *
   * <p>Issue #22 — {@code StringRedisTemplate} 직접 참조 제거 (Redis 의존 bean 은 {@link
   * RedisMfaBeans} 로 이전). 본 클래스 introspection 시 {@code NoClassDefFoundError} 영구 회피.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(name = "platform.security.mfa.enabled", havingValue = "true")
  @AutoConfigureAfter(RedisMfaBeans.class)
  static class MfaBeans {

    @Bean
    @ConditionalOnMissingBean(LockoutTracker.class)
    LockoutTracker rcmInMemoryLockoutTracker(MfaProperties properties) {
      return new InMemoryLockoutTracker(properties.lockoutPolicy());
    }

    @Bean
    @ConditionalOnMissingBean(MfaProvider.class)
    MfaProvider rcmTotpMfaProvider(LockoutTracker tracker, MfaProperties properties) {
      return new TotpMfaProvider(tracker, properties.window(), properties.issuer());
    }
  }

  /**
   * Phase 5 task #6 — RateLimit AOP 영역. {@link RateLimit} annotation 부착 method 자동 차단.
   * AspectJ proxy 활성 = {@code spring-boot-starter-aop} transitive (build.gradle.kts 영역).
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(name = "io.github.resilience4j.ratelimiter.RateLimiterRegistry")
  static class RateLimitBeans {

    @Bean
    @ConditionalOnMissingBean(RateLimiterRegistry.class)
    RateLimiterRegistry rcmRateLimiterRegistry() {
      return RateLimiterRegistry.ofDefaults();
    }

    @Bean
    @ConditionalOnMissingBean(RateLimitKeyResolver.class)
    RateLimitKeyResolver rcmRateLimitKeyResolver() {
      return new RateLimitKeyResolver.DefaultRateLimitKeyResolver();
    }

    @Bean
    @ConditionalOnMissingBean(RateLimitInterceptor.class)
    RateLimitInterceptor rcmRateLimitInterceptor(
        RateLimitProperties properties,
        RateLimitKeyResolver keyResolver,
        RateLimiterRegistry registry) {
      return new RateLimitInterceptor(properties, keyResolver, registry);
    }
  }

  /**
   * Phase 5 task #7 — Idempotency-Key 영역. opt-in default. {@link IdempotencyKeyFilter} 가
   * SecurityFilterChain 에 자동 합류는 안 함 (Consumer 가 자체 filter chain 영역에서 명시 합류
   * 또는 {@link org.springframework.boot.web.servlet.FilterRegistrationBean} 으로 등록).
   * 본 baseline 은 bean 등록만.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnProperty(
      name = "platform.security.idempotency.enabled",
      havingValue = "true",
      matchIfMissing = true)
  static class IdempotencyBeans {

    @Bean
    @ConditionalOnMissingBean(IdempotencyStore.class)
    IdempotencyStore rcmInMemoryIdempotencyStore(IdempotencyProperties properties) {
      return new InMemoryIdempotencyStore(properties.maxEntries());
    }

    @Bean
    @ConditionalOnMissingBean(IdempotencyKeyFilter.class)
    IdempotencyKeyFilter rcmIdempotencyKeyFilter(
        IdempotencyStore store, IdempotencyProperties properties) {
      return new IdempotencyKeyFilter(store, properties);
    }
  }

  /**
   * Phase 5 task #8 — TrustedProxy 영역. opt-in (default false). Consumer 가 reverse proxy
   * 환경 (nginx / load balancer) 운영 시 yml 활성 + cidr-allowlist 명시.
   */
  @Configuration(proxyBeanMethods = false)
  static class TrustedProxyBeans {

    @Bean
    @ConditionalOnProperty(name = "platform.security.trusted-proxy.enabled", havingValue = "true")
    @ConditionalOnMissingBean(TrustedProxyFilter.class)
    TrustedProxyFilter rcmTrustedProxyFilter(TrustedProxyProperties properties) {
      return new TrustedProxyFilter(properties);
    }

    @Bean
    @ConditionalOnMissingBean(RemoteAddressResolver.class)
    RemoteAddressResolver rcmRemoteAddressResolver(TrustedProxyProperties properties) {
      return new RemoteAddressResolver(properties);
    }
  }

  /**
   * Phase 5 task #9 — RequestLimits 영역 utility bean. controller / service 가 인입하여 enforce.
   */
  @Configuration(proxyBeanMethods = false)
  static class RequestLimitsBeans {

    @Bean
    @ConditionalOnMissingBean(PageableLimitEnforcer.class)
    PageableLimitEnforcer rcmPageableLimitEnforcer(RequestLimitsProperties properties) {
      return new PageableLimitEnforcer(properties.page());
    }

    @Bean
    @ConditionalOnMissingBean(SortWhitelistValidator.class)
    SortWhitelistValidator rcmSortWhitelistValidator(RequestLimitsProperties properties) {
      return new SortWhitelistValidator(properties.sort());
    }
  }

  /**
   * Phase 5 task #10 — UserContext ScopedValue binding 영역 (청사진 §6.2). default
   * SecurityFilterChain 의 oauth2-resource-server 인증 통과 후 본 filter 가 합류 — Consumer 가 자체
   * filter chain 적용 시 명시 합류 또는 framework 의 자동 합류 영역.
   */
  @Configuration(proxyBeanMethods = false)
  static class UserContextBeans {

    @Bean
    @ConditionalOnMissingBean(UserContextFilter.class)
    UserContextFilter rcmUserContextFilter() {
      return new UserContextFilter();
    }
  }

  /**
   * issue #26 — PDP enforcement 영역 (AccessRoute / DefaultAccessRoute / 8 endpoint matrix 자동 매핑).
   *
   * <p>활성 조건:
   * <ul>
   *   <li>{@link ConditionalOnClass}({@code DefaultAccessRoute.class}) — rcm-starter-web (compileOnly)
   *       runtime 가용 시만 활성 (web 미사용 consumer 단독 시 silent skip + advice 비활성)</li>
   *   <li>{@link AccessDecisionEvaluator} bean 미존재 시 baseline {@link
   *       PermitAllAccessDecisionEvaluator} 등록 — consumer 가 자체 evaluator bean 등록 시 자동 양보</li>
   *   <li>{@link AccessRouteAspect} 는 @ConditionalOnMissingBean 으로 consumer override 친화</li>
   * </ul>
   *
   * <p>의도 — consumer 가 {@code @DefaultAccessRoute(resourcePrefix=..., entityName=...)} class-level
   * 1 부착 → {@link io.rchemist.starter.web.crud.AbstractCrudController} 8 endpoint 자동 PDP enforce.
   * 메소드 레벨 {@code @AccessRoute} 명시 시 override 우선 보존.
   */
  @Configuration(proxyBeanMethods = false)
  @ConditionalOnClass(name = "io.rchemist.starter.web.crud.DefaultAccessRoute")
  static class AccessRouteBeans {

    @Bean
    @ConditionalOnMissingBean(AccessDecisionEvaluator.class)
    AccessDecisionEvaluator rcmPermitAllAccessDecisionEvaluator() {
      return new PermitAllAccessDecisionEvaluator();
    }

    @Bean
    @ConditionalOnMissingBean(AccessRouteAspect.class)
    AccessRouteAspect rcmAccessRouteAspect(AccessDecisionEvaluator evaluator) {
      return new AccessRouteAspect(evaluator);
    }

    @Bean
    @ConditionalOnMissingBean(AccessDeniedExceptionAdvice.class)
    AccessDeniedExceptionAdvice rcmAccessDeniedExceptionAdvice() {
      return new AccessDeniedExceptionAdvice();
    }

    /**
     * {@link AccessRouteAspect} interceptor 를 Spring MVC dispatcher 에 등록 — controller method
     * 진입 직전 PDP enforcement.
     */
    @Bean
    @ConditionalOnMissingBean(name = "accessRouteWebMvcConfigurer")
    org.springframework.web.servlet.config.annotation.WebMvcConfigurer
        accessRouteWebMvcConfigurer(AccessRouteAspect interceptor) {
      return new org.springframework.web.servlet.config.annotation.WebMvcConfigurer() {
        @Override
        public void addInterceptors(
            org.springframework.web.servlet.config.annotation.InterceptorRegistry registry) {
          registry.addInterceptor(interceptor);
        }
      };
    }
  }
}
