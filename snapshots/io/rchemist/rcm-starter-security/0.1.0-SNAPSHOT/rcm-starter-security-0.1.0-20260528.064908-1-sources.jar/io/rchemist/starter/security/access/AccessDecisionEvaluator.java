/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — PDP (Policy Decision Point) 평가자 abstraction. consumer 가 도메인 정책 (RBAC / ABAC /
 * tenant-scoped 등) 자체 bean 으로 구현 → framework 의 {@link AccessRouteAspect} 가 본 인터페이스만
 * 의존 (정책 자체는 framework 책임 영역 밖).
 *
 * <p>baseline = {@link PermitAllAccessDecisionEvaluator} — consumer 미제공 시 모든 평가 PERMIT.
 * 즉 framework 가 PDP 결정 정책을 강제하지 않음, framework 는 enforce hook 만 제공. consumer 가
 * 자체 bean 등록 → {@link org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean}
 * 으로 자동 양보.
 **/
@FunctionalInterface
public interface AccessDecisionEvaluator {

  /**
   * (resource, action) pair 의 현재 인증 주체 평가 → {@link AccessDecision} 반환.
   *
   * <p>구현 hint:
   * <ul>
   *   <li>RBAC — {@code SecurityContextHolder.getContext().getAuthentication()} 의 authority +
   *       (resource, action) 매핑 로 PERMIT/DENY</li>
   *   <li>ABAC — tenant 정합 + resource owner 정합 + attribute 평가</li>
   *   <li>Open Policy Agent (OPA) — REST 호출 위임</li>
   * </ul>
   *
   * @param resource PDP resource (예: {@code Learning.Course})
   * @param action   PDP action (예: {@code create} / {@code read})
   * @return PERMIT / DENY 결정 (null 반환 금지 — null = AccessRouteAspect 가 NullPointerException)
   */
  AccessDecision evaluate(String resource, String action);
}
