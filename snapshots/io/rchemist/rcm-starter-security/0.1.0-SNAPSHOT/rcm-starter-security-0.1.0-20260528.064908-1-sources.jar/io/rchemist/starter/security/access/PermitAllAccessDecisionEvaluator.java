/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.access;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * issue #26 — baseline {@link AccessDecisionEvaluator} 구현. 모든 평가 PERMIT.
 *
 * <p>역할:
 * <ul>
 *   <li>consumer 가 자체 evaluator bean 미등록 시 fallback — framework 가 PDP 결정 정책 강제 X</li>
 *   <li>dev / 단위 테스트 영역의 silent permit (PDP 정책 시연 영역 분리)</li>
 *   <li>{@link AccessRouteAspect} 가 *항상 1 개* evaluator bean 을 만나도록 보장 — null check 영역
 *       단순화</li>
 * </ul>
 *
 * <p>production = consumer 가 자체 bean 등록 (예: edustack 의 {@code OpaAccessDecisionEvaluator}
 * 또는 {@code RbacAccessDecisionEvaluator}) → {@link
 * org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean} 으로 본 baseline
 * 자동 양보.
 **/
public class PermitAllAccessDecisionEvaluator implements AccessDecisionEvaluator {

  @Override
  public AccessDecision evaluate(String resource, String action) {
    return AccessDecision.permitted();
  }
}
