/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.ratelimit;

import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterConfig;
import io.github.resilience4j.ratelimiter.RateLimiterRegistry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #6 — {@link RateLimit} annotation AOP. Resilience4j {@link RateLimiter} 위 +
 * key resolver 별 limiter instance 관리.
 *
 * <p>적용:
 * <ul>
 *   <li>각 (annotation.name + key) 조합 = 별도 limiter (예: limiter "search" 의 user "u-1" 과
 *       user "u-2" 가 독립 영역)</li>
 *   <li>{@link RateLimiter#acquirePermission(java.time.Duration)} timeout = 0 → 즉시 fail
 *       = baseline (timeout 영역은 yml override)</li>
 *   <li>거부 시 {@link RateLimitExceededException} → Phase 2 ProblemDetailAdvice 가 429 자동
 *       매핑</li>
 * </ul>
 *
 * <p>Resilience4j {@link RateLimiterRegistry} 는 정합 limit 설정으로 instance 캐싱. 본 interceptor
 * 는 (name + key) 별 entry 단일 limiter 보관 — registry 의 unique limiter name = "name:key".
 **/
@Aspect
public class RateLimitInterceptor {

  private final RateLimitProperties properties;
  private final RateLimitKeyResolver keyResolver;
  private final RateLimiterRegistry registry;
  private final ConcurrentMap<String, RateLimiter> limiterCache = new ConcurrentHashMap<>();

  public RateLimitInterceptor(
      RateLimitProperties properties,
      RateLimitKeyResolver keyResolver,
      RateLimiterRegistry registry) {
    this.properties = Objects.requireNonNull(properties, "properties");
    this.keyResolver = Objects.requireNonNull(keyResolver, "keyResolver");
    this.registry = Objects.requireNonNull(registry, "registry");
  }

  @Around("@annotation(rateLimit)")
  public Object intercept(ProceedingJoinPoint pjp, RateLimit rateLimit) throws Throwable {
    String key = keyResolver.resolveKey();
    String compositeName = rateLimit.name() + ":" + key;
    RateLimiter limiter =
        limiterCache.computeIfAbsent(
            compositeName, k -> registry.rateLimiter(k, configFor(rateLimit.name())));

    if (!limiter.acquirePermission()) {
      throw new RateLimitExceededException(rateLimit.name(), key);
    }
    return pjp.proceed();
  }

  private RateLimiterConfig configFor(String name) {
    RateLimitProperties.Limiter spec = properties.resolve(name);
    return RateLimiterConfig.custom()
        .limitForPeriod(spec.limit())
        .limitRefreshPeriod(spec.refresh())
        .timeoutDuration(spec.timeout())
        .build();
  }
}
