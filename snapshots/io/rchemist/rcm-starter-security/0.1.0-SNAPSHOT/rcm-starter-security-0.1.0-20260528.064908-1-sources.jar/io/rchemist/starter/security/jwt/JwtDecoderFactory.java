/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimNames;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtIssuerValidator;
import org.springframework.security.oauth2.jwt.JwtTimestampValidator;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.util.StringUtils;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #2 + #3 — {@link JwtProperties} 위에 {@link NimbusJwtDecoder} 를 만든다. 두 모드 분기:
 *
 * <ul>
 *   <li><b>Single-key (Phase 5 #2 backward 호환)</b> — {@code keys[]} 빈 영역 + {@code secret}
 *       명시. {@link NimbusJwtDecoder#withSecretKey(javax.crypto.SecretKey)} 위 HS* 검증.</li>
 *   <li><b>Multi-key rotation (Phase 5 #3)</b> — {@code keys[]} 명시. {@link RotatingJwkSource}
 *       + {@link DefaultJWTProcessor} + {@link JWSVerificationKeySelector} → {@code kid}
 *       기반 key 선택. 검증 시점 valid 한 모든 key 가 후보.</li>
 * </ul>
 *
 * <p>{@link JwtTimestampValidator} default + 옵션 {@link JwtIssuerValidator} + 옵션 audience
 * validator (Spring Security 가 base 미제공) 둘 다 두 모드 동일 적용.
 **/
public final class JwtDecoderFactory {

  private JwtDecoderFactory() {}

  public static JwtDecoder create(JwtProperties props) {
    if (!props.isEnabled()) {
      throw new IllegalStateException(
          "JwtProperties is not enabled — secret 또는 keys[] 둘 중 하나 명시 필요");
    }

    SigningKeyRegistry registry = SigningKeyRegistry.from(props);
    NimbusJwtDecoder decoder =
        registry.isSingleKey()
            ? singleKeyDecoder(registry, props)
            : multiKeyDecoder(registry, props);
    decoder.setJwtValidator(buildValidators(props));
    return decoder;
  }

  // -----------------------------------------------------------------
  // Single-key path — Phase 5 #2 backward 호환
  // -----------------------------------------------------------------

  private static NimbusJwtDecoder singleKeyDecoder(SigningKeyRegistry registry, JwtProperties props) {
    SigningKey only = registry.keys().get(0);
    SecretKeySpec key = new SecretKeySpec(only.secret(), props.signingAlgorithm().getName());
    return NimbusJwtDecoder.withSecretKey(key).macAlgorithm(props.signingAlgorithm()).build();
  }

  // -----------------------------------------------------------------
  // Multi-key path — Phase 5 #3 rotation
  // -----------------------------------------------------------------

  private static NimbusJwtDecoder multiKeyDecoder(SigningKeyRegistry registry, JwtProperties props) {
    RotatingJwkSource source = new RotatingJwkSource(registry, props.signingAlgorithm());
    DefaultJWTProcessor<SecurityContext> processor = new DefaultJWTProcessor<>();
    JWSKeySelector<SecurityContext> selector =
        new JWSVerificationKeySelector<>(
            com.nimbusds.jose.JWSAlgorithm.parse(props.signingAlgorithm().getName()), source);
    processor.setJWSKeySelector(selector);
    return new NimbusJwtDecoder(processor);
  }

  // -----------------------------------------------------------------
  // Validators (양 모드 공통)
  // -----------------------------------------------------------------

  private static OAuth2TokenValidator<Jwt> buildValidators(JwtProperties props) {
    List<OAuth2TokenValidator<Jwt>> validators = new ArrayList<>();
    validators.add(new JwtTimestampValidator(props.clockSkew()));
    if (StringUtils.hasText(props.issuer())) {
      validators.add(new JwtIssuerValidator(props.issuer()));
    }
    if (StringUtils.hasText(props.audience())) {
      validators.add(audienceValidator(props.audience()));
    }
    return new DelegatingOAuth2TokenValidator<>(validators);
  }

  private static OAuth2TokenValidator<Jwt> audienceValidator(String expected) {
    return jwt -> {
      List<String> aud = jwt.getClaimAsStringList(JwtClaimNames.AUD);
      if (aud != null && aud.contains(expected)) {
        return OAuth2TokenValidatorResult.success();
      }
      return OAuth2TokenValidatorResult.failure(
          new org.springframework.security.oauth2.core.OAuth2Error(
              "invalid_token", "Required audience '" + expected + "' missing", null));
    };
  }
}
