/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.trustedproxy;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #8 — IPv4 / IPv6 CIDR notation matcher. {@link InetAddress} 위 byte-level
 * compare — 외부 dep 0.
 *
 * <p>{@code 10.0.0.0/8} = IPv4 prefix 8 bits. {@code 2001:db8::/32} = IPv6 prefix 32 bits.
 **/
public final class CidrMatcher {

  private final List<Cidr> cidrs;

  public CidrMatcher(List<String> cidrNotations) {
    Objects.requireNonNull(cidrNotations, "cidrNotations");
    this.cidrs = cidrNotations.stream().map(Cidr::parse).toList();
  }

  /** address 가 등록된 CIDR 중 하나에라도 속하면 true. */
  public boolean matches(InetAddress address) {
    Objects.requireNonNull(address, "address");
    return cidrs.stream().anyMatch(c -> c.contains(address));
  }

  /** {@link InetAddress#getByName(String)} 위에서 자동 변환 — DNS 룩업 회피 위해 numeric IP만 권고. */
  public boolean matches(String ipAddress) {
    try {
      return matches(InetAddress.getByName(ipAddress));
    } catch (UnknownHostException e) {
      return false;
    }
  }

  // -----------------------------------------------------------------
  // CIDR Records
  // -----------------------------------------------------------------

  private record Cidr(byte[] networkBytes, int prefixBits) {

    static Cidr parse(String notation) {
      Objects.requireNonNull(notation, "notation");
      int slash = notation.indexOf('/');
      if (slash < 0) {
        throw new IllegalArgumentException("Invalid CIDR (no /): " + notation);
      }
      String addr = notation.substring(0, slash);
      int prefix;
      try {
        prefix = Integer.parseInt(notation.substring(slash + 1));
      } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Invalid CIDR prefix: " + notation, e);
      }
      InetAddress network;
      try {
        network = InetAddress.getByName(addr);
      } catch (UnknownHostException e) {
        throw new IllegalArgumentException("Invalid CIDR address: " + notation, e);
      }
      byte[] bytes = network.getAddress();
      int maxPrefix = bytes.length * 8;
      if (prefix < 0 || prefix > maxPrefix) {
        throw new IllegalArgumentException("Invalid CIDR prefix range: " + notation);
      }
      return new Cidr(bytes, prefix);
    }

    boolean contains(InetAddress address) {
      byte[] candidate = address.getAddress();
      if (candidate.length != networkBytes.length) {
        return false; // IPv4 vs IPv6 mismatch
      }
      int fullBytes = prefixBits / 8;
      int remainingBits = prefixBits % 8;
      for (int i = 0; i < fullBytes; i++) {
        if (candidate[i] != networkBytes[i]) {
          return false;
        }
      }
      if (remainingBits > 0) {
        int mask = 0xFF << (8 - remainingBits);
        if ((candidate[fullBytes] & mask) != (networkBytes[fullBytes] & mask)) {
          return false;
        }
      }
      return true;
    }

    @Override
    public boolean equals(Object o) {
      return o instanceof Cidr other
          && Arrays.equals(networkBytes, other.networkBytes)
          && prefixBits == other.prefixBits;
    }

    @Override
    public int hashCode() {
      return Arrays.hashCode(networkBytes) * 31 + prefixBits;
    }
  }
}
