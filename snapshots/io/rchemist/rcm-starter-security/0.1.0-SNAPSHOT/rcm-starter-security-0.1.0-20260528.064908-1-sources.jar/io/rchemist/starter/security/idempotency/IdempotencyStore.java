/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.idempotency;

import java.time.Duration;
import java.util.Optional;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #7 — Idempotency response cache SPI. baseline 2 impl (InMemory / Redis) — 같은
 * Idempotency-Key 의 두 번째 요청 시 cached response replay.
 **/
public interface IdempotencyStore {

  /** key 에 대한 cached response 조회. {@link Optional#empty()} = miss. */
  Optional<CachedResponse> get(String key);

  /** key + response 보관. ttl 만료 후 자동 제거. */
  void save(String key, CachedResponse response, Duration ttl);

  /**
   * 캐시된 응답 — Records 로 immutable 보장. Header 영역은 {@code List<String>} 다중값 표준.
   */
  record CachedResponse(int status, String contentType, byte[] body, java.util.Map<String, java.util.List<String>> headers) {

    public CachedResponse {
      headers = headers == null ? java.util.Map.of() : java.util.Map.copyOf(headers);
      body = body == null ? new byte[0] : body.clone();
    }

    @Override
    public byte[] body() {
      return body.clone();
    }
  }
}
