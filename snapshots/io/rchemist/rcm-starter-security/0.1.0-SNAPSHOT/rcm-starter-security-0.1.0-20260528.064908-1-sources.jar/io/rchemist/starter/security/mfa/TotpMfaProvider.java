/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — RFC 6238 TOTP 기반 {@link MfaProvider}. {@link Totp} utility 위 + lockout
 * 통합.
 *
 * <p>적용:
 * <ul>
 *   <li>{@link #enroll(String)} = 20-byte random secret + base32 + {@code otpauth://} URI
 *       (Authy / Google Authenticator 등 호환)</li>
 *   <li>{@link #verify(String, byte[], String)} = lockout 검사 → {@link Totp#verify} → 실패 시
 *       {@link LockoutTracker#recordFailure} → 성공 시 {@link LockoutTracker#reset}</li>
 *   <li>locked 상태 사용자가 verify 시도 → silent false (외부에서는 정상 인증 실패와 동일,
 *       enumeration 회피)</li>
 * </ul>
 **/
public class TotpMfaProvider implements MfaProvider {

  private static final char[] BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".toCharArray();

  private final LockoutTracker lockoutTracker;
  private final int window;
  private final String issuer;

  public TotpMfaProvider(LockoutTracker lockoutTracker, int window, String issuer) {
    this.lockoutTracker = Objects.requireNonNull(lockoutTracker, "lockoutTracker");
    if (window < 0) {
      throw new IllegalArgumentException("window must be >= 0");
    }
    this.window = window;
    this.issuer = Objects.requireNonNull(issuer, "issuer");
  }

  @Override
  public Enrollment enroll(String userId) {
    Objects.requireNonNull(userId, "userId");
    byte[] secret = Totp.randomSecret();
    String base32 = encodeBase32(secret);
    String uri = otpAuthUri(userId, base32);
    return new Enrollment(secret, base32, uri);
  }

  @Override
  public boolean verify(String userId, byte[] secret, String code) {
    Objects.requireNonNull(userId, "userId");
    Objects.requireNonNull(secret, "secret");
    if (lockoutTracker.isLockedOut(userId)) {
      return false;
    }
    boolean ok = Totp.verify(secret, code, window);
    if (ok) {
      lockoutTracker.reset(userId);
    } else {
      lockoutTracker.recordFailure(userId);
    }
    return ok;
  }

  // -----------------------------------------------------------------
  // base32 (RFC 4648 §6) — Authenticator app 호환 표준
  // -----------------------------------------------------------------

  static String encodeBase32(byte[] data) {
    StringBuilder sb = new StringBuilder();
    int buffer = 0;
    int bitsLeft = 0;
    for (byte b : data) {
      buffer = (buffer << 8) | (b & 0xFF);
      bitsLeft += 8;
      while (bitsLeft >= 5) {
        bitsLeft -= 5;
        int idx = (buffer >> bitsLeft) & 0x1F;
        sb.append(BASE32_ALPHABET[idx]);
      }
    }
    if (bitsLeft > 0) {
      int idx = (buffer << (5 - bitsLeft)) & 0x1F;
      sb.append(BASE32_ALPHABET[idx]);
    }
    return sb.toString();
  }

  /**
   * {@code otpauth://totp/<issuer>:<userId>?secret=<base32>&issuer=<issuer>} — Google
   * Authenticator + Authy + 1Password 등 호환 표준 URI. QR code 생성 영역에 그대로 인입.
   */
  private String otpAuthUri(String userId, String secretBase32) {
    String label = encode(issuer + ":" + userId);
    return "otpauth://totp/"
        + label
        + "?secret="
        + secretBase32
        + "&issuer="
        + encode(issuer);
  }

  private static String encode(String s) {
    return URLEncoder.encode(s, StandardCharsets.UTF_8);
  }
}
