/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — brute force lockout 추적 SPI. baseline 2 impl (InMemory / Redis).
 *
 * <p>{@code recordFailure} = 실패 카운트 +1 + 한도 초과 시 lock. {@code isLockedOut} = lock 상태
 * 검사. {@code reset} = 성공 인증 후 카운트 0.
 **/
public interface LockoutTracker {

  /** 실패 1회 기록. 한도 도달 시 자동 lock. */
  void recordFailure(String key);

  /** 현 lock 상태. lock duration 만료 후 자동 false (impl 책임). */
  boolean isLockedOut(String key);

  /** 성공 인증 후 호출 — 카운트 + lock 상태 둘 다 0. */
  void reset(String key);
}
