/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — {@code platform.security.mfa.*} prefix 의 yml binding.
 *
 * <p>{@code enabled} = MFA 영역 활성. default false (opt-in baseline) — Consumer 가 명시 활성.
 * {@code window} = TOTP timestep 허용 범위 (clock skew + 사용자 지연 → 1 = ±30s).
 * {@code maxAttempts} / {@code lockoutDuration} = brute force lockout 정책.
 **/
@ConfigurationProperties(prefix = "platform.security.mfa")
public record MfaProperties(
    @DefaultValue("false") boolean enabled,
    @DefaultValue("1") int window,
    @DefaultValue("5") int maxAttempts,
    @DefaultValue("PT15M") Duration lockoutDuration,
    @DefaultValue("RCM Framework") String issuer) {

  /** {@link LockoutPolicy} Records 합성 — yml 위 {@link LockoutTracker} 인입. */
  public LockoutPolicy lockoutPolicy() {
    return new LockoutPolicy(maxAttempts, lockoutDuration);
  }
}
