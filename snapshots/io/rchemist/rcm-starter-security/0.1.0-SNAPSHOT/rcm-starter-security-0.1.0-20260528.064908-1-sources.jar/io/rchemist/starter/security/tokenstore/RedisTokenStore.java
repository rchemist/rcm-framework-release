/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.tokenstore;

import java.time.Duration;
import java.util.Objects;
import java.util.Optional;
import org.springframework.data.redis.core.StringRedisTemplate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #4 — Redis 기반 token store. 다중 노드 baseline.
 *
 * <p>적용:
 * <ul>
 *   <li>refresh = {@code <prefix>refresh:<jti>} = userId. {@link
 *       org.springframework.data.redis.core.ValueOperations#setIfAbsent} + TTL = atomic 발급</li>
 *   <li>{@link #consumeRefresh(String)} = {@code GETDEL} (Redis 6.2+) — atomic remove + return</li>
 *   <li>blacklist = {@code <prefix>blacklist:<jti>} = "1" + TTL — exists check 만으로 충분</li>
 * </ul>
 *
 * <p>Spring Data Redis 의 {@link StringRedisTemplate} 인입 — Consumer 가 자체 ConnectionFactory
 * 적용 (Redis URI / sentinel / cluster 영역) 후 본 store 가 transparent 활용.
 *
 * <p>본 클래스는 {@code spring-boot-starter-data-redis} 가 classpath 에 있을 때만 활용 가능 —
 * autoconfig 의 {@code @ConditionalOnClass(StringRedisTemplate.class)} 가 silent skip 단일 지점.
 **/
public class RedisTokenStore implements TokenStore {

  private final StringRedisTemplate redis;
  private final String refreshPrefix;
  private final String blacklistPrefix;

  public RedisTokenStore(
      StringRedisTemplate redis, String refreshPrefix, String blacklistPrefix) {
    this.redis = Objects.requireNonNull(redis, "redis");
    this.refreshPrefix = Objects.requireNonNull(refreshPrefix, "refreshPrefix");
    this.blacklistPrefix = Objects.requireNonNull(blacklistPrefix, "blacklistPrefix");
  }

  @Override
  public void saveRefresh(String jti, String userId, Duration ttl) {
    redis.opsForValue().set(refreshKey(jti), userId, ttl);
  }

  @Override
  public Optional<String> consumeRefresh(String jti) {
    String userId = redis.opsForValue().getAndDelete(refreshKey(jti));
    return Optional.ofNullable(userId);
  }

  @Override
  public void revoke(String jti, Duration ttl) {
    redis.opsForValue().set(blacklistKey(jti), "1", ttl);
  }

  @Override
  public boolean isBlacklisted(String jti) {
    Boolean exists = redis.hasKey(blacklistKey(jti));
    return Boolean.TRUE.equals(exists);
  }

  private String refreshKey(String jti) {
    return refreshPrefix + jti;
  }

  private String blacklistKey(String jti) {
    return blacklistPrefix + jti;
  }
}
