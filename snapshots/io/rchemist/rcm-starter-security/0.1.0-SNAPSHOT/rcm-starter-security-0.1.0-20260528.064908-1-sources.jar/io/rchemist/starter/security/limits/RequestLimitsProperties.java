/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.limits;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.util.unit.DataSize;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #9 — {@code platform.limits.*} prefix 의 yml binding (청사진 §8.2 정합).
 *
 * <p>{@code page.maxSize} = 단일 page 의 size 한도 (default 200) — 큰 page 요청 → 응답 시간 +
 * memory 소비 증가 영역 차단. {@code page.defaultSize} = 클라이언트 size 미명시 시 default.
 *
 * <p>{@code sort.whitelistOnly} = true 시 globalAllowedFields 리스트 안의 field 만 sort 허용 →
 * SQL injection 회피 (Decision §5.5.6 정합). 기본 false (Phase 3 Entity_Metadata APT 기반 자동
 * 화이트리스트 영역과 보완).
 *
 * <p>{@code body.maxBytes} = HTTP request body 크기 한도. spring 의 {@code server.tomcat.max-http-form-post-size}
 * 와 보완 영역 (framework abstraction).
 **/
@ConfigurationProperties(prefix = "platform.limits")
public record RequestLimitsProperties(
    @DefaultValue Page page,
    @DefaultValue Sort sort,
    @DefaultValue Body body) {

  public RequestLimitsProperties {
    page = page == null ? new Page(200, 20) : page;
    sort = sort == null ? new Sort(false, List.of()) : sort;
    body = body == null ? new Body(DataSize.ofMegabytes(10)) : body;
  }

  public record Page(@DefaultValue("200") int maxSize, @DefaultValue("20") int defaultSize) {}

  public record Sort(
      @DefaultValue("false") boolean whitelistOnly,
      @DefaultValue List<String> globalAllowedFields) {}

  public record Body(@DefaultValue("10MB") DataSize maxBytes) {}
}
