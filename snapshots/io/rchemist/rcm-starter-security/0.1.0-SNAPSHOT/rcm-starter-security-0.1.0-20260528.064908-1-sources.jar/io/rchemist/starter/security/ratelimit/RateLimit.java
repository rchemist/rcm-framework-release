/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.ratelimit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #6 — method-level rate limit annotation. {@link RateLimitInterceptor} AOP 가
 * Resilience4j RateLimiter 합성.
 *
 * <p>{@code name} = limiter 식별자 + yml override key (`platform.security.rate-limit.<name>.*`).
 * 기본값 {@code "default"} = 모든 annotation 이 같은 limiter 영역 (per-name override 명시 시점만
 * 분리).
 *
 * <p>{@code key} SpEL 옵션 — 미명시 (빈 문자열) 시 {@link RateLimitKeyResolver} 의 default
 * (UserContext.userId 우선 → request IP fallback) 사용. 명시 시 SpEL 영역 평가 결과 = limiter
 * key (예: {@code "#user.id"}).
 **/
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RateLimit {

  /** Limiter 식별자 — yml `platform.security.rate-limit.<name>.*` 와 정합. */
  String name() default "default";

  /** SpEL 옵션 — 빈 영역이면 {@link RateLimitKeyResolver} default 사용. */
  String key() default "";
}
