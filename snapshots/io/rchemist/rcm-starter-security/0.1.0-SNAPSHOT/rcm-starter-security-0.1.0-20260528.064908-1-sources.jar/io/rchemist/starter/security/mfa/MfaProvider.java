/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — Multi-factor 인증 SPI. baseline impl = {@link TotpMfaProvider} (RFC 6238).
 *
 * <p>Consumer 가 자체 SMS / push notification 영역 활용 시 본 SPI 의 다른 impl 적용. {@code enroll}
 * = 신규 사용자에게 secret 생성 + QR 영역. {@code verify} = 사용자 입력 코드 검증 + lockout 트리거.
 **/
public interface MfaProvider {

  /** 사용자 enrollment — secret 생성 + 외부 표시용 base32 + QR provisioning URI. */
  Enrollment enroll(String userId);

  /**
   * 코드 검증 — secret 의 외부 보관 (encrypted 권고) 영역에서 받은 raw bytes + 사용자 입력 코드.
   * 실패 시 {@link LockoutTracker#recordFailure(String)} 트리거 (impl 책임).
   */
  boolean verify(String userId, byte[] secret, String code);

  /** Enrollment 결과 Records — secret + display 형태. */
  record Enrollment(byte[] secret, String secretBase32, String otpAuthUri) {}
}
