/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.idempotency;

import java.time.Duration;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #7 — {@code platform.security.idempotency.*} prefix 의 yml binding.
 *
 * <p>{@code enabled} = filter 활성. {@code headerName} = 클라이언트 발송 header 이름 (default
 * RFC draft 표준 {@code Idempotency-Key}). {@code methods} = 적용 HTTP method (POST / PUT /
 * PATCH / DELETE 영역 권고). {@code ttl} = stored response TTL (default 24h). {@code keyPrefix}
 * = Redis key 접두사.
 **/
@ConfigurationProperties(prefix = "platform.security.idempotency")
public record IdempotencyProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue("Idempotency-Key") String headerName,
    @DefaultValue({"POST", "PUT", "PATCH", "DELETE"}) List<String> methods,
    @DefaultValue("PT24H") Duration ttl,
    @DefaultValue("rcm:security:idempotency:") String keyPrefix,
    @DefaultValue("100000") long maxEntries) {}
