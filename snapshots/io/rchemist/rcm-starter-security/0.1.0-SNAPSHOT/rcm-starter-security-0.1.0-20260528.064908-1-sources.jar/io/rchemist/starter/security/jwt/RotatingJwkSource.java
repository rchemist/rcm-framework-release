/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.jwt;

import com.nimbusds.jose.Algorithm;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSelector;
import com.nimbusds.jose.jwk.OctetSequenceKey;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #3 — {@link SigningKeyRegistry} 를 Nimbus JOSE 의 {@link JWKSource} 로 노출.
 * {@code NimbusJwtDecoder} (다중 key 모드) 가 본 source 를 통해 kid-based key 선택.
 *
 * <p>적용:
 * <ul>
 *   <li>{@link #get(JWKSelector, SecurityContext)} = 현 시점 valid 한 key 만 노출 (registry
 *       의 만료 정책 위임). selector 의 matcher 가 kid 기반 추가 필터.</li>
 *   <li>HMAC 키 = {@link OctetSequenceKey} (RFC 7518 §6.4 의 {@code oct} key type).</li>
 *   <li>algorithm = {@link MacAlgorithm} → {@link JWSAlgorithm} 변환 (이름 1:1 매핑).</li>
 * </ul>
 *
 * <p>Phase 5 task #4 의 Redis token store 와 직교 — 본 source 는 *서명 키* 영역, token store 는
 * *발급된 토큰* 영역.
 **/
public final class RotatingJwkSource implements JWKSource<SecurityContext> {

  private final SigningKeyRegistry registry;
  private final JWSAlgorithm jwsAlgorithm;

  public RotatingJwkSource(SigningKeyRegistry registry, MacAlgorithm algorithm) {
    this.registry = Objects.requireNonNull(registry, "registry");
    this.jwsAlgorithm = JWSAlgorithm.parse(Objects.requireNonNull(algorithm, "algorithm").getName());
  }

  @Override
  public List<JWK> get(JWKSelector jwkSelector, SecurityContext context) {
    List<JWK> all = registry.validKeys(Instant.now()).stream().map(this::toJwk).toList();
    return jwkSelector.select(new com.nimbusds.jose.jwk.JWKSet(all));
  }

  /** 본 source 의 algorithm — {@code NimbusJwtDecoder} 의 key selector 인입 시 일관성 단일 지점. */
  public Algorithm jwsAlgorithm() {
    return jwsAlgorithm;
  }

  private JWK toJwk(SigningKey key) {
    return new OctetSequenceKey.Builder(key.secret())
        .keyID(key.kid())
        .algorithm(jwsAlgorithm)
        .build();
  }
}
