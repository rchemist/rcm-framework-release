/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import java.util.Objects;
import org.springframework.data.redis.core.StringRedisTemplate;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — Redis 기반 lockout tracker. 다중 노드 baseline.
 *
 * <p>적용:
 * <ul>
 *   <li>실패 카운트: {@code <prefix>fail:<key>} INCR + TTL = lockoutDuration</li>
 *   <li>Lock 마커: {@code <prefix>lock:<key>} 가 존재 시 lock — TTL = lockoutDuration</li>
 *   <li>recordFailure → INCR + 한도 도달 시 lock 마커 SET</li>
 * </ul>
 *
 * <p>Spring Data Redis transitive — Consumer 가 자체 ConnectionFactory 적용 후 본 tracker 가
 * transparent 활용.
 **/
public class RedisLockoutTracker implements LockoutTracker {

  private final StringRedisTemplate redis;
  private final LockoutPolicy policy;
  private final String failPrefix;
  private final String lockPrefix;

  public RedisLockoutTracker(
      StringRedisTemplate redis, LockoutPolicy policy, String keyPrefix) {
    this.redis = Objects.requireNonNull(redis, "redis");
    this.policy = Objects.requireNonNull(policy, "policy");
    Objects.requireNonNull(keyPrefix, "keyPrefix");
    this.failPrefix = keyPrefix + "fail:";
    this.lockPrefix = keyPrefix + "lock:";
  }

  @Override
  public void recordFailure(String key) {
    String failKey = failPrefix + key;
    Long count = redis.opsForValue().increment(failKey);
    redis.expire(failKey, policy.lockoutDuration());
    if (count != null && count >= policy.maxAttempts()) {
      redis.opsForValue().set(lockPrefix + key, "1", policy.lockoutDuration());
    }
  }

  @Override
  public boolean isLockedOut(String key) {
    Boolean exists = redis.hasKey(lockPrefix + key);
    return Boolean.TRUE.equals(exists);
  }

  @Override
  public void reset(String key) {
    redis.delete(failPrefix + key);
    redis.delete(lockPrefix + key);
  }
}
