/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.security.mfa;

import java.time.Duration;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Phase 5 task #5 — brute force lockout 정책 Records. {@link MfaProperties#lockoutPolicy()} 가
 * yml 위에 합성.
 *
 * <p>{@code maxAttempts} = 연속 실패 한도 (이상 시 lockout). {@code lockoutDuration} = lockout
 * 보존 시간 (이후 자동 unlock — Consumer 명시 reset 도 가능).
 **/
public record LockoutPolicy(int maxAttempts, Duration lockoutDuration) {

  public LockoutPolicy {
    if (maxAttempts < 1) {
      throw new IllegalArgumentException("maxAttempts must be >= 1");
    }
    if (lockoutDuration == null || lockoutDuration.isNegative() || lockoutDuration.isZero()) {
      throw new IllegalArgumentException("lockoutDuration must be positive");
    }
  }
}
