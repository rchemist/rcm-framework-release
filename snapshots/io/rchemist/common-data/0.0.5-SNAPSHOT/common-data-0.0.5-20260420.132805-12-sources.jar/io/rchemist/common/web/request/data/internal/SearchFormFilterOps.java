/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.internal;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

public final class SearchFormFilterOps {

  private SearchFormFilterOps() {
  }

  public static Object getValue(AbstractSearchForm<?> form, String propertyName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (filters != null && !filters.isEmpty()) {
      for (ConditionOperatorType operator : filters.keySet()) {
        FilterItem[] filterItems = filters.get(operator);
        for (FilterItem filterItem : filterItems) {
          if (filterItem.getName() != null && filterItem.getName().equals(propertyName)) {
            return filterItem.getValue();
          }
        }
      }
    }
    return null;
  }

  @SuppressWarnings("unchecked")
  public static Long[] getSearchIds(AbstractSearchForm<?> form) {
    Object values = getValue(form, "ids");
    if (values == null) {
      return null;
    }
    try {
      if (values.getClass().isArray()) {
        return (Long[]) values;
      }
      if (values instanceof List) {
        return ((List<Long>) values).toArray(new Long[0]);
      }
    } catch (Exception e) {
      return null;
    }
    return null;
  }

  public static Object getValue(AbstractSearchForm<?> form, ConditionOperatorType operatorType,
      QueryConditionType conditionType, String propertyName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (filters != null && !filters.isEmpty()) {
      for (ConditionOperatorType operator : filters.keySet()) {
        if (operator.equals(operatorType)) {
          FilterItem[] filterItems = filters.get(operator);
          for (FilterItem filterItem : filterItems) {
            if (StringUtils.equalsIgnoreCase(filterItem.getName(), propertyName)
                && filterItem.getQueryConditionType().equals(conditionType)) {
              return filterItem.getValue();
            }
          }
        }
      }
    }
    return null;
  }

  public static void removeFilterItem(AbstractSearchForm<?> form, ConditionOperatorType type, String name) {
    FilterItem[] items = form.getFilterItems(type);
    if (items != null) {
      for (FilterItem item : items) {
        if (item.getName().equals(name)) {
          List<FilterItem> itemList = new ArrayList<>();
          for (FilterItem filterItem : items) {
            if (!filterItem.getName().equals(name)) {
              itemList.add(filterItem);
            }
          }
          form.getFilters().put(type, itemList.toArray(new FilterItem[0]));
          break;
        }
      }
    }
  }

  public static LinkedHashMap<ConditionOperatorType, FilterItem[]> getSubConditions(
      AbstractSearchForm<?> form, ConditionOperatorType conditionOperatorType, String propertyName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (filters != null && filters.size() > 0 && filters.containsKey(conditionOperatorType)) {
      FilterItem[] filterItems = filters.get(conditionOperatorType);
      for (FilterItem filterItem : filterItems) {
        if (filterItem.getName() != null && filterItem.getName().equals(propertyName)) {
          if (filterItem.hasSubFilters()) {
            return filterItem.getSubFilters();
          }
        }
      }
    }
    return null;
  }

  public static boolean hasFilters(AbstractSearchForm<?> form) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (MapUtils.isEmpty(filters)) {
      return false;
    }
    for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
      if (entry.getValue() != null && entry.getValue().length > 0) {
        return true;
      }
    }
    return false;
  }

  public static void removeFilters(AbstractSearchForm<?> form, ConditionOperatorType operatorType, String... names) {
    if (names == null || names.length == 0) {
      return;
    }
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (!filters.containsKey(operatorType) || ArrayUtils.isEmpty(filters.get(operatorType))) {
      return;
    }
    List<FilterItem> newFilterItems = new ArrayList<>();
    for (FilterItem filterItem : filters.get(operatorType)) {
      if (!ArrayUtils.contains(names, filterItem.getName())) {
        newFilterItems.add(filterItem);
      }
    }
    filters.put(operatorType, newFilterItems.toArray(new FilterItem[0]));
  }

  public static void removeFiltersExcludeNames(AbstractSearchForm<?> form,
      ConditionOperatorType operatorType, String... names) {
    if (names == null || names.length == 0) {
      return;
    }
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (!filters.containsKey(operatorType) || ArrayUtils.isEmpty(filters.get(operatorType))) {
      return;
    }
    List<FilterItem> newFilterItems = new ArrayList<>();
    for (FilterItem filterItem : filters.get(operatorType)) {
      if (ArrayUtils.contains(names, filterItem.getName())) {
        newFilterItems.add(filterItem);
      }
    }
    filters.put(operatorType, newFilterItems.toArray(new FilterItem[0]));
  }

  public static void removeFilter(AbstractSearchForm<?> form, String fieldName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (MapUtils.isNotEmpty(filters)) {
      for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
        FilterItem[] items = entry.getValue();
        List<FilterItem> itemList = new ArrayList<>();
        for (FilterItem item : items) {
          if (!item.getName().equals(fieldName)) {
            itemList.add(item);
          }
        }
        filters.put(entry.getKey(), itemList.toArray(new FilterItem[0]));
      }
    }
  }

  public static boolean hasFilter(AbstractSearchForm<?> form, String fieldName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();
    if (MapUtils.isNotEmpty(filters)) {
      for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
        FilterItem[] items = entry.getValue();
        for (FilterItem item : items) {
          if (item.getName().equals(fieldName)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  public static void renameFilterItem(
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters, String oldName, String newName) {
    if (MapUtils.isEmpty(filters)) {
      return;
    }
    for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
      for (FilterItem item : entry.getValue()) {
        if (item.getName().equals(oldName)) {
          item.setName(newName);
        }
        renameFilterItem(item.getSubFilters(), oldName, newName);
      }
    }
  }

  public static void renameSortItem(AbstractSearchForm<?> form, String oldName, String newName) {
    if (CollectionUtils.isEmpty(form.getSorts())) {
      return;
    }
    for (SortEntry entry : form.getSorts()) {
      if (entry.getFieldName().equals(oldName)) {
        entry.setFieldName(newName);
      }
    }
  }
}
