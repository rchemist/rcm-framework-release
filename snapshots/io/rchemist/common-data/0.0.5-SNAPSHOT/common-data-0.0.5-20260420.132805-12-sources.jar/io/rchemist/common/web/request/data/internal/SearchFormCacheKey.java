/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.internal;

import io.rchemist.common.util.GsonUtil;
import io.rchemist.common.util.MapUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import java.util.Objects;

public final class SearchFormCacheKey {

  private SearchFormCacheKey() {
  }

  public static String build(AbstractSearchForm<?> form) {
    String cacheKey = "SearchForm{"
        + "filters=" + MapUtil.toString(form.getFilters())
        + ", searchTerm='" + form.getSearchTerm() + '\''
        + ", shouldReturnEmpty=" + form.getShouldReturnEmpty()
        + ", operator=" + form.getOperator()
        + ", exactMatch=" + form.getExactMatch()
        + ", viewDetail=" + form.getViewDetail()
        + ", page=" + form.getPage()
        + ", pageSize=" + form.getPageSize()
        + ", sorts=" + GsonUtil.toJson(form.getSorts())
        + ", ignoreCache=" + form.getIgnoreCache()
        + '}';
    return String.valueOf(Objects.hash(cacheKey));
  }

  public static String toStringRepr(AbstractSearchForm<?> form, Object preservedCriteria) {
    return "SearchForm{"
        + "filters=" + MapUtil.toString(form.getFilters())
        + ", preservedFilterAndSortCriteria=" + preservedCriteria
        + ", filterValidated=" + form.isFilterValidated()
        + ", cacheTTL=" + form.getCacheTTL()
        + ", searchTerm='" + form.getSearchTerm() + '\''
        + ", shouldReturnEmpty=" + form.getShouldReturnEmpty()
        + ", mergedSearchTerms=" + form.getMergedSearchTerms()
        + ", operator=" + form.getOperator()
        + ", exactMatch=" + form.getExactMatch()
        + ", forceFetchFromDB=" + form.getForceFetchFromDB()
        + ", viewDetail=" + form.getViewDetail()
        + ", page=" + form.getPage()
        + ", pageSize=" + form.getPageSize()
        + ", totalCount=" + form.getTotalCount()
        + ", sorts=" + GsonUtil.toJson(form.getSorts())
        + ", totalPage=" + form.getTotalPage()
        + ", ignoreCache=" + form.getIgnoreCache()
        + '}';
  }
}
