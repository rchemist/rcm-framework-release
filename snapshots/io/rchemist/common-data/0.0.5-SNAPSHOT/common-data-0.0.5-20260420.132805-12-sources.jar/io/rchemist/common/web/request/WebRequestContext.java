/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.thread.ThreadLocalManager;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.TenantUtil;
import io.rchemist.common.util.type.DeviceType;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.request.data.RequestDTO;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public class WebRequestContext {

  private static final ThreadLocal<WebRequestContext> REQUEST_CONTEXT = ThreadLocalManager.createThreadLocal(WebRequestContext.class);

  protected HttpRequest request;
  protected Locale locale;
  protected Currency currency;
  protected ZoneId zoneId;
  protected TimeZone timeZone;
  protected MessageSource messageSource;
  protected DeviceType deviceType;

  protected RequestDTO requestDTO;
  protected Map<String, Object> attributes = new HashMap<>();
  protected String adminUserId;

  protected String siteAlias;

  @Setter(AccessLevel.NONE)
  protected SiteType siteType;

  protected String tenantId;
  protected String tenantAlias;

  protected Long siteId;
  protected Long catalogId;

  @Setter(AccessLevel.NONE)
  protected SimpleAuthentication authentication;

  @Setter(AccessLevel.NONE)
  protected List<Long> sharedSiteIds = new ArrayList<>();

  @Setter(AccessLevel.NONE)
  protected List<Long> managedCatalogIds = new ArrayList<>();

  public static WebRequestContext getWebRequestContext(){
    return REQUEST_CONTEXT.get();
  }

  public static void setWebRequestContext(WebRequestContext webRequestContext){
    REQUEST_CONTEXT.set(webRequestContext);
  }

  public static boolean hasLocale() {
    if (getWebRequestContext() != null) {
      return getWebRequestContext().getLocale() != null;
    }
    return false;
  }

  public static boolean hasCurrency() {
    if (getWebRequestContext() != null) {
      return getWebRequestContext().getCurrency() != null;
    }
    return false;
  }

  public void setAuthentication(SimpleAuthentication authentication) {
    this.authentication = authentication;
    if(authentication != null){
      this.tenantAlias = authentication.getTenantAlias();
      this.siteAlias = authentication.getSiteAlias();
      this.tenantId = authentication.getTenantId();
      this.siteId = authentication.getSiteId();
      this.catalogId = authentication.getCatalogId();
      if(tenantAlias != null){
        this.siteType = (siteAlias == null) ? SiteType.ADMIN : SiteType.FRONT;
      }
      if (authentication.getSiteType() != null) {
        this.siteType = authentication.getSiteType();
        if (EnumTypeUtil.equals(this.siteType, SiteType.ADMIN)) {
          this.adminUserId = authentication.getUserId();
        }
      }
    }
  }


  public boolean isAdmin(){
    return siteType != null && EnumTypeUtil.equals(siteType, SiteType.ADMIN);
  }

  // alias 또는 id 어느 한 축이라도 설정되면 tenant context 로 본다 (DEC-017 병존 시맨틱).
  public boolean isTenantContext(){
    return StringUtils.isNotEmpty(tenantAlias) || tenantId != null;
  }

  public boolean isSiteContext(){
    return StringUtils.isNotEmpty(siteAlias) || siteId != null;
  }

  public boolean hasAttribute(String contextToken) {
    return attributes.containsKey(contextToken);
  }

  public <T> T getAttribute(String contextToken) {
    if (hasAttribute(contextToken)) {
      return (T) attributes.get(contextToken);
    }
    return null;
  }

  /*public static SimpleAuthentication getSimpleAuthentication() {
    WebRequestContext context = getWebRequestContext();
    if (context == null)
      return null;
    return context.getAuthentication();
  }*/

  public static SimpleAuthentication getSimpleAuthentication() {
    return Optional.ofNullable(getWebRequestContext())
        .map(WebRequestContext::getAuthentication)
        .orElse(null);
  }


  /*public static boolean isOwnedContextOrAdmin(String userId) {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if (context == null)
      return false;
    if (context.isAdmin())
      return true;
    if (context.getAuthentication() == null)
      return false;
    return StringUtils.equals(context.getAuthentication().getUserId(), userId);
  }*/

  public static boolean isOwnedContextOrAdmin(String userId) {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .filter(context -> context.isAdmin() ||
            (context.getAuthentication() != null &&
                StringUtils.equals(context.getAuthentication().getUserId(), userId)))
        .isPresent();
  }


  public WebRequestContext addAttribute(String key, Object value) {
    attributes.put(key, value);
    return this;
  }

  public static String getCurrentUserId() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getAuthentication)
        .map(SimpleAuthentication::getUserId)
        .orElse(null);
  }


  public static String getCurrentTenantAlias() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getTenantAlias)
        .orElse(TenantUtil.DEFAULT_TENANT_ALIAS);
  }

  public static String getCurrentTenantId() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getTenantId)
        .orElse(null);
  }

  public static Long getCurrentSiteId() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getSiteId)
        .orElse(null);
  }

  public static Long getCurrentCatalogId() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getCatalogId)
        .orElse(null);
  }

  public static void validateAuthenticationHasAnyRole(String... roles) {
    if (roles == null || roles.length == 0)
      return;

    // 정상적인 WebRequest 가 아니면 role 체크를 할 수 없다.
    // 이 경우에는 그냥 아무 오류를 내지 않는다.
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if (context == null)
      return;

    SimpleAuthentication authentication = context.getAuthentication();
    if (authentication == null)
      return;

    if (authentication.hasAnyRole(roles))
      return;

    throw new PlatformSecurityException(PlatformSecurityErrorType.NOT_ALLOWED_TENANT_ALIAS);
  }

  public static boolean isAnonymous() {
    return Optional.ofNullable(WebRequestContext.getWebRequestContext())
        .map(WebRequestContext::getAuthentication)
        .map(SimpleAuthentication::isAnonymous)
        .orElse(true);
  }


}
