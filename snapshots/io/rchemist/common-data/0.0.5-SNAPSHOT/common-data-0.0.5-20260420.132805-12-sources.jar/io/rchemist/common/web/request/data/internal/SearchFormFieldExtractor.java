/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.internal;

import io.rchemist.common.persistence.config.persistence.EntityBeanContext;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

public final class SearchFormFieldExtractor {

  private SearchFormFieldExtractor() {
  }

  public static String[] getSearchFieldNames(AbstractSearchForm<?> form, Class<?> entityClass) {

    Set<String> fieldNames = new LinkedHashSet<>();

    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType operatorType : form.getFilters().keySet()) {
      FilterItem[] filterItems = form.getFilters().get(operatorType);

      for (FilterItem filterItem : filterItems) {
        RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(filterItem.getName());

        if (entityBeanProperty != null) {
          fieldNames.add(entityBeanProperty.getName());
        } else {
          if (StringUtils.contains(filterItem.getName(), ".")) {
            String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");
            if (entityBean.isAttributeField(attributePrefix) || entityBeanProperties.containsKey(attributePrefix)
                || SearchFormValidator.hasPropertyWithPrefix(entityBeanProperties, attributePrefix)) {
              fieldNames.add(filterItem.getName());
            }
          }
        }
      }
    }

    if (CollectionUtils.isNotEmpty(form.getMergedSearchTerms())) {
      for (String mergedSearchTerm : form.getMergedSearchTerms()) {
        if (fieldNames.contains(mergedSearchTerm)) {
          fieldNames.add(mergedSearchTerm);
        }
      }
    }

    return fieldNames.toArray(new String[0]);
  }

  public static String[] getHibernateSearchFieldNames(AbstractSearchForm<?> form, Class<?> entityClass) {

    List<String> fieldNames = new ArrayList<>();

    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType operatorType : form.getFilters().keySet()) {
      FilterItem[] filterItems = form.getFilters().get(operatorType);

      for (FilterItem filterItem : filterItems) {
        RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(filterItem.getName());

        if (entityBeanProperty != null && entityBeanProperty.isIndexField()) {
          fieldNames.add(entityBeanProperty.getName());
        } else {
          if (StringUtils.contains(filterItem.getName(), ".")) {
            String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");
            if (entityBean.isAttributeField(attributePrefix) || entityBeanProperties.containsKey(attributePrefix)) {
              fieldNames.add(filterItem.getName());
            }
          }
        }
      }
    }

    return fieldNames.toArray(new String[0]);
  }
}
