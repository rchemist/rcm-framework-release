/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
@Data
public class FilterItem implements Serializable {

  protected String name;

  @Setter(AccessLevel.PRIVATE)
  protected QueryConditionType queryConditionType = QueryConditionType.EQUAL;

  protected Object value;

  protected Object[] values;

  protected Boolean not = false;

  @Setter(AccessLevel.NONE)
  protected JoinType joinType;

  @JsonIgnore
  protected Class<?> joinClass;

  @JsonIgnore
  protected Class<?> fieldType;

  @JsonIgnore
  protected Class<?> rootEntityClass;

  @JsonIgnore
  protected Boolean applyOnClause = false;

  @JsonIgnore
  protected Boolean jsonFilter = false;

  public Object getValue() {
    if (queryConditionType == null) {
      return value;
    }

    if (queryConditionType.isListCondition() && values != null && values.length > 0) {
      return values;
    }

    Object val = null;
    if (value == null) {
      if (values != null && values.length > 0) {
        val = values[0];
      }
    } else {
      val = value;
    }

    return val;
  }

  protected LinkedHashMap<ConditionOperatorType, FilterItem[]> subFilters = new LinkedHashMap<>();

  public FilterItem withName(String name) {
    this.name = name;
    return this;
  }

  public FilterItem withQueryConditionType(QueryConditionType operator) {
    this.queryConditionType = operator;
    return this;
  }

  public FilterItem withValue(Object value) {
    this.value = value;
    return this;
  }

  public FilterItem withValues(Object[] values) {
    this.values = values;
    return this;
  }

  public FilterItem withNot(Boolean not) {
    this.not = not;
    return this;
  }

  public FilterItem withJoinType(JoinType joinType) {
    this.joinType = joinType;
    return this;
  }

  public FilterItem withJoinClass(Class<?> joinClass) {
    this.joinClass = joinClass;
    return this;
  }

  public void setJoinType(String joinType) {
    if (StringUtils.isEmpty(joinType)) {
      return;
    }
    if(StringUtils.equals(joinType.toUpperCase(), "INNER")) {
      this.joinType = JoinType.INNER;
    } else if(StringUtils.equals(joinType.toUpperCase(), "LEFT")) {
      this.joinType = JoinType.LEFT;
    } else if(StringUtils.equals(joinType.toUpperCase(), "RIGHT")) {
      this.joinType = JoinType.RIGHT;
    }
  }

  public void setJoinType(JoinType joinType) {
    this.joinType = joinType;
  }

  public FilterItem withFieldType(Class<?> fieldType) {
    this.fieldType = fieldType;
    return this;
  }

  public FilterItem withRootEntityClass(Class<?> rootEntityClass) {
    this.rootEntityClass = rootEntityClass;
    return this;
  }

  public FilterItem withSubFilters(LinkedHashMap<ConditionOperatorType, FilterItem[]> subFilters) {
    this.subFilters = subFilters;
    return this;
  }

  public boolean hasSubFilters() {
    return MapUtils.isNotEmpty(subFilters);
  }

  public boolean isOnlySubFilters() {
    return queryConditionType == QueryConditionType.EQUAL && value == null && (values == null || values.length == 0);
  }


  public boolean hasSingleValue() {
    if (!isMultipleFilterValue()) {
      Object value = getValue();
      return value != null && StringUtils.isNotEmpty(value.toString());
    }
    return false;
  }

  public boolean hasMultipleValues() {
    if (isMultipleFilterValue()) {
      Object[] values = getValues();
      return values != null && ArrayUtils.isNotEmpty(values) && values.length > 1;
    }
    return false;
  }


  public static FilterItem or(FilterItem... filters) {
    return new FilterItem().withName(filters[0].getName()).withSubFilters(new LinkedHashMap<>() {{
      put(ConditionOperatorType.OR, filters);
    }});
  }

  public static FilterItem and(FilterItem... filters) {
    return new FilterItem().withName(filters[0].getName()).withSubFilters(new LinkedHashMap<>() {{
      put(ConditionOperatorType.AND, filters);
    }});
  }

  public static FilterItem equals(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.EQUAL);
  }

  public static FilterItem notEquals(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.NOT_EQUAL);
  }

  public static FilterItem greaterThan(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.GREATER);
  }

  public static FilterItem greaterThanOrEqual(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.GREATER_THAN_EQUAL);
  }

  public static FilterItem lessThan(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.LESS_THAN);
  }

  public static FilterItem lessThanOrEqual(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.LESS_THAN_EQUAL);
  }

  public static FilterItem like(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.LIKE);
  }

  public static FilterItem notLike(String name, Object value) {
    return new FilterItem().withName(name).withValue(value).withQueryConditionType(QueryConditionType.NOT_LIKE);
  }

  public static FilterItem in(String name, Object[] values) {
    return new FilterItem().withName(name).withValues(values).withQueryConditionType(QueryConditionType.IN);
  }

  public static FilterItem in(String name, Collection<Object> values) {

    // values to array
    if (values == null || values.isEmpty()) {
      return in(name, new Object[0]);
    }

    Object[] valuesArray = new Object[values.size()];
    values.toArray(valuesArray);

    return new FilterItem().withName(name).withValues(valuesArray).withQueryConditionType(QueryConditionType.IN);
  }


  public static FilterItem notIn(String name, Object[] values) {
    return new FilterItem().withName(name).withValues(values).withQueryConditionType(QueryConditionType.NOT_IN);
  }

  public static FilterItem isNull(String name) {
    return new FilterItem().withName(name).withQueryConditionType(QueryConditionType.NULL);
  }

  public static FilterItem isNullOrEquals(String name, Object value) {
    return FilterItem.or(
        FilterItem.isNull(name)
        , FilterItem.equals(name, value)
    );
  }

  public static FilterItem isNullOrNotEquals(String name, Object value) {
    return FilterItem.or(
        FilterItem.isNull(name)
        , FilterItem.notEquals(name, value)
    );
  }

  public static FilterItem isNotNull(String name) {
    return new FilterItem().withName(name).withQueryConditionType(QueryConditionType.NOT_NULL);
  }

  public static FilterItem between(String name, Object[] values) {
    return new FilterItem().withName(name).withValues(values).withQueryConditionType(QueryConditionType.BETWEEN);
  }

  public static FilterItem notBetween(String name, Object[] values) {
    return new FilterItem().withName(name).withValues(values).withQueryConditionType(QueryConditionType.NOT_BETWEEN);
  }

  public FilterItem deepCopy() {
    FilterItem item = new FilterItem();

    item.setName(name);
    item.setQueryConditionType(queryConditionType);
    item.setValue(value);
    item.setValues(values == null ? null : values.clone());
    item.setNot(not);
    item.setJoinType(joinType);
    item.setJoinClass(joinClass);
    item.setFieldType(fieldType);
    item.setRootEntityClass(rootEntityClass);
    item.setApplyOnClause(applyOnClause);
    item.setJsonFilter(jsonFilter);

    if (MapUtils.isNotEmpty(subFilters)) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> subFilters = new LinkedHashMap<>();
      for (Entry<ConditionOperatorType, FilterItem[]> entry : this.subFilters.entrySet()) {
        FilterItem[] subFilterItems = entry.getValue();
        FilterItem[] subFilterItemsClone = new FilterItem[subFilterItems.length];
        for (int i = 0; i < subFilterItems.length; i++) {
          subFilterItemsClone[i] = subFilterItems[i].deepCopy();
        }
        subFilters.put(entry.getKey(), subFilterItemsClone);
      }
      item.setSubFilters(subFilters);
    }

    return item;
  }

  public FilterItem withApplyOnClause(Boolean applyOnClause) {
    this.applyOnClause = applyOnClause;
    return this;
  }

  public FilterItem withJsonFilter(Boolean jsonFilter) {
    this.jsonFilter = jsonFilter;
    return this;
  }

  public boolean isApplyOnClause() {
    return BooleanUtils.toBoolean(applyOnClause);
  }

  public boolean isJsonFilter() {
    return BooleanUtils.toBoolean(jsonFilter);
  }

  /**
   * 무조건 복수의 값을 사용해야 하는 경우
   * @return
   */
  public boolean isMultipleFilterValue() {
    return getQueryConditionType() != null && (getQueryConditionType().equals(QueryConditionType.BETWEEN)
        || getQueryConditionType().equals(QueryConditionType.NOT_BETWEEN)
        || getQueryConditionType().equals(QueryConditionType.IN)
        || getQueryConditionType().equals(QueryConditionType.NOT_IN))
        ;
  }

  /**
   * values 에 값이 들어 왔다고 해도 무조건 첫번째 값만 사용해야 하는 경우
   * @return
   */
  public boolean isStrictSingleFilterValue() {
    return getQueryConditionType() != null && (getQueryConditionType().equals(QueryConditionType.LESS_THAN)
        || getQueryConditionType().equals(QueryConditionType.LESS_THAN_EQUAL)
        || getQueryConditionType().equals(QueryConditionType.NOT_LESS_THAN)
        || getQueryConditionType().equals(QueryConditionType.NOT_LESS_THAN_EQUAL)
        || getQueryConditionType().equals(QueryConditionType.GREATER)
        || getQueryConditionType().equals(QueryConditionType.GREATER_THAN_EQUAL)
        || getQueryConditionType().equals(QueryConditionType.NOT_GREATER)
        || getQueryConditionType().equals(QueryConditionType.NOT_GREATER_THAN_EQUAL));
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("name", name)
        .add("operator", queryConditionType)
        .add("value", value)
        .add("values", values)
        .add("not", not)
        .add("joinType", joinType)
        .add("joinClass", joinClass)
        .add("fieldType", fieldType)
        .add("subFilters", subFilters)
        .toString();
  }

  public boolean equalsName(String name) {
    return StringUtils.equals(this.name, name);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FilterItem that = (FilterItem) o;
    return Objects.equal(name, that.name)
      && queryConditionType == that.queryConditionType && Objects.equal(value,
      that.value) && Objects.equal(values, that.values)
      && Objects.equal(not, that.not) && joinType == that.joinType
      && Objects.equal(joinClass, that.joinClass)
      && Objects.equal(fieldType, that.fieldType)
      && Objects.equal(rootEntityClass, that.rootEntityClass)
      && Objects.equal(applyOnClause, that.applyOnClause)
      && Objects.equal(jsonFilter, that.jsonFilter)
      && Objects.equal(subFilters, that.subFilters);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(name, queryConditionType, value, values, not, joinType, joinClass,
      fieldType, rootEntityClass, applyOnClause, jsonFilter, subFilters);
  }

}
