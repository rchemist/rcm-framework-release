/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.internal;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import org.apache.commons.collections4.MapUtils;

public final class SearchFormCloner {

  private SearchFormCloner() {
  }

  public static <T> void copyStateExceptPreserved(AbstractSearchForm<T> source,
      AbstractSearchForm<T> target, boolean removeRequestOnlyValue) {

    target.setPage(source.getPage());
    target.setPageSize(source.getPageSize());
    target.setTotalCount(source.getTotalCount());
    target.setTotalPage(source.getTotalPage());
    target.setSorts(new ArrayList<>(source.getSorts()));
    target.setIgnoreCache(source.getIgnoreCache());

    if (MapUtils.isNotEmpty(source.getFilters())) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> clonedFilters = new LinkedHashMap<>();
      for (Entry<ConditionOperatorType, FilterItem[]> entry : source.getFilters().entrySet()) {
        if (entry.getValue() != null) {
          if (entry.getValue().length == 1 && entry.getValue()[0] == null) {
            continue;
          }
          FilterItem[] filterItems = entry.getValue();
          FilterItem[] filterItemsClone = new FilterItem[filterItems.length];
          for (int i = 0; i < filterItems.length; i++) {
            filterItemsClone[i] = filterItems[i].deepCopy();
          }
          clonedFilters.put(entry.getKey(), filterItemsClone);
        }
      }
      target.setFilters(clonedFilters);
    }

    target.setFilterValidated(source.isFilterValidated());
    target.setCacheTTL(source.getCacheTTL());
    target.setSearchTerm(source.getSearchTerm());
    target.setMergedSearchTerms(new HashSet<>(source.getMergedSearchTerms()));
    target.setOperator(source.getOperator());
    target.setExactMatch(source.getExactMatch());
    target.setForceFetchFromDB(source.getForceFetchFromDB());

    if (!removeRequestOnlyValue) {
      target.setShouldReturnEmpty(source.getShouldReturnEmpty());
    }
  }
}
