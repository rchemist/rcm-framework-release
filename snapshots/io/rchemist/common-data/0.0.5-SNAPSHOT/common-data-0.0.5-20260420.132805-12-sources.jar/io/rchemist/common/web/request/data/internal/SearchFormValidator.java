/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.internal;

import io.rchemist.common.persistence.config.persistence.EntityBeanContext;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.search.service.exception.SearchServiceErrorType;
import io.rchemist.common.search.service.exception.SearchServiceException;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.FilterMapSearchForm;
import io.rchemist.common.web.request.data.search.ModifiedResult;
import io.rchemist.common.web.request.data.search.ModifyFilterRequest;
import io.rchemist.common.web.request.data.search.ModifySortRequest;
import io.rchemist.common.web.request.data.search.ValidateSearchForm;
import io.rchemist.common.web.request.data.sort.SortEntry;
import jakarta.persistence.OneToMany;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public final class SearchFormValidator {

  private SearchFormValidator() {
  }

  public static void validateFilters(AbstractSearchForm<?> form, Class<?> entityClass,
      boolean hibernateSearch) throws SearchServiceException {
    if (entityClass == null) {
      throw new SearchServiceException(SearchServiceErrorType.ENTITY_NOT_FOUND);
    }

    if (MapUtils.isEmpty(form.getFilters())) {
      return;
    }

    if (!form.isFilterValidated()) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> source = form.getFilters();
      LinkedHashMap<ConditionOperatorType, FilterItem[]> validatedFilters = new LinkedHashMap<>();
      source.keySet().forEach(operatorType -> {
        FilterItem[] filterItems = source.get(operatorType);
        if (filterItems != null && !(filterItems.length == 1 && filterItems[0] == null)) {
          validatedFilters.put(operatorType, filterItems);
        }
      });
      form.setFilters(validatedFilters);
      form.setFilterValidated(true);
    }

    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = form.getFilters();

    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType key : filters.keySet()) {
      FilterItem[] filterItems = filters.get(key);

      List<FilterItem> mergedFilterItems = new ArrayList<>();

      if (ArrayUtils.isNotEmpty(filterItems)) {

        for (FilterItem filterItem : filterItems) {
          RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(filterItem.getName());

          if (entityBeanProperty == null) {
            filterItem = ValidateSearchForm.transform(
                new ModifyFilterRequest(entityBean, filterItem, hibernateSearch)
                    .withSearchFieldModifiers(form.getSearchFieldModifiers()));
          }

          entityBeanProperty = entityBeanProperties.get(filterItem.getName());

          if (entityBeanProperty == null) {
            if (entityBean.hasAttributeFields() && StringUtils.contains(filterItem.getName(), ".")) {
              String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");

              if (entityBeanProperties.containsKey(attributePrefix)
                  || hasPropertyWithPrefix(entityBeanProperties, attributePrefix)) {
                mergedFilterItems.add(filterItem);
              } else if (hibernateSearch) {

                if (entityBean.isAttributeField(attributePrefix)) {
                  mergedFilterItems.add(filterItem);
                } else {
                  log.warn("Entity Bean Property Not Found : {}", filterItem.getName());
                }
              } else {

                if (entityBean.isAttributeFieldName(attributePrefix)) {
                  filterItem.setJsonFilter(true);
                  mergedFilterItems.add(filterItem);
                } else {
                  log.warn("Entity Bean Property Not Found : {}", filterItem.getName());
                }

              }
            } else {
              mergedFilterItems.add(filterItem);
            }

          } else {
            mergeFilter(form, entityClass, hibernateSearch, entityBean, entityBeanProperties, key,
                mergedFilterItems, filterItem, entityBeanProperty);
          }
        }

        filters.put(key, mergedFilterItems.toArray(new FilterItem[0]));
      }
    }
  }

  private static void mergeFilter(AbstractSearchForm<?> form, Class<?> entityClass,
      boolean hibernateSearch,
      EntityBean<?> entityBean,
      Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties,
      ConditionOperatorType key,
      List<FilterItem> filterItemList, FilterItem filterItem,
      RegisterEntityBeanPropertyDTO entityBeanProperty) {
    filterItem.withFieldType(entityBeanProperty.getPropertyClass()).withRootEntityClass(entityClass);

    filterItem = ValidateSearchForm.validate(
        new ModifyFilterRequest(entityBean, filterItem, hibernateSearch)
            .withEntityBeanProperty(entityBeanProperty));

    if (filterItem != null) {
      filterItemList.add(filterItem);

      if (StringUtils.equals(entityBeanProperty.getPropertyType(), OneToMany.class.getName())) {
        FilterMapSearchForm.mergeFilter(key, filterItem, form.getMappedJoinFilters());
      } else {
        if (StringUtils.contains(filterItem.getName(), ".")) {
          String[] names = StringUtils.split(filterItem.getName(), ".");
          String name = names[0];
          RegisterEntityBeanPropertyDTO property = entityBeanProperties.get(name);

          if (property == null) {
            FilterMapSearchForm.mergeFilter(key, filterItem, form.getColumnFilters());
          } else {
            if (StringUtils.equals(property.getPropertyType(), OneToMany.class.getName())) {
              FilterMapSearchForm.mergeFilter(key, filterItem, form.getMappedJoinFilters());
            } else {
              FilterMapSearchForm.mergeFilter(key, filterItem, form.getColumnFilters());
            }
          }

        } else {
          FilterMapSearchForm.mergeFilter(key, filterItem, form.getColumnFilters());
        }
      }
    }
  }

  public static void validateSorts(AbstractSearchForm<?> form, Class<?> entityClass,
      boolean hibernateSearch) throws SearchServiceException {
    if (entityClass == null) {
      throw new SearchServiceException(SearchServiceErrorType.ENTITY_NOT_FOUND);
    }

    if (CollectionUtils.isEmpty(form.getSorts())) {
      return;
    }

    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());

    ModifiedResult modifiedResult = ValidateSearchForm.validateSorts(
        new ModifySortRequest(entityBean, form.getFilters(), form.getSorts(), hibernateSearch)
            .withSortFieldModifiers(form.getSortFieldModifiers()));

    if (modifiedResult.hasFilters()) {
      form.setFilters(modifiedResult.getFilters());
    }

    if (modifiedResult.hasSorts()) {
      form.setSorts(modifiedResult.getSortEntries());
    }

    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (SortEntry entry : form.getSorts()) {
      String sortKey = entry.getFieldName();
      RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(sortKey);

      if (entityBeanProperty == null) {
        throw new SearchServiceException(sortKey, SearchServiceErrorType.FIELD_NOT_FOUND);
      }
    }
  }

  public static boolean hasPropertyWithPrefix(
      Map<String, RegisterEntityBeanPropertyDTO> properties, String prefix) {
    String prefixWithDot = prefix + ".";
    for (String key : properties.keySet()) {
      if (key.startsWith(prefixWithDot)) {
        return true;
      }
    }
    return false;
  }
}
