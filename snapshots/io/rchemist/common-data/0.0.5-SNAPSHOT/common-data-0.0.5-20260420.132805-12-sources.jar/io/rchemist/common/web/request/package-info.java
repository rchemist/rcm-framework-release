/**
 * <strong>0.1.0 에서 신규 모듈/패키지로 이동 예정.</strong>
 *
 * <p>SearchForm 의존 역전 해소 (DEC-008 후속) 의 일환으로, 본 {@code web/request} 계열
 * (Form/Filter/Sort/Modifier 등 HTTP request 모델) 은 common-framework 또는 신규 검색 도메인
 * 모듈로 재배치된다. 패키지 경로 변경이 발생하므로 Consumer 는 0.1.0 채택 시 import 문을
 * 일괄 갱신해야 한다.
 *
 * <p>이동 사유: common-data-jpa 가 HTTP 개념 패키지를 직접 참조하지 않도록 계층을 정돈하기 위함.
 * 본 단계 (0.0.9) 에서는 이동만 예정하고, 기능적 변화는 없다.
 *
 * <p>마이그레이션 가이드: {@code documents/refactor/CHANGELOG.md} (0.0.9 작성).
 */
package io.rchemist.common.web.request;
