/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.criteria.JoinType;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort.Direction;

/**
 * sorts Map을 역직렬화하는 커스텀 Deserializer
 * 
 * JSON 구조:
 * - 일반 정렬: {"fieldName": "DESC"}
 * - 우선순위 정렬: {"fieldName": {"priorityValue": "ACTIVE", "direction": "ASC"}}
 */
@Slf4j
public class SortInfoMapDeserializer extends JsonDeserializer<LinkedHashMap<String, SortInfo>> {

    @Override
    public LinkedHashMap<String, SortInfo> getNullValue(DeserializationContext ctxt) {
        return new LinkedHashMap<>();
    }

    @Override
    public LinkedHashMap<String, SortInfo> deserialize(JsonParser parser, DeserializationContext context)
            throws IOException, JsonProcessingException {
        
        LinkedHashMap<String, SortInfo> result = new LinkedHashMap<>();
        JsonNode rootNode = parser.getCodec().readTree(parser);
        
        if (rootNode == null || !rootNode.isObject()) {
            log.debug("sorts field is null or not an object, returning empty map");
            return result;
        }
        
        Iterator<Map.Entry<String, JsonNode>> fields = rootNode.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> entry = fields.next();
            String fieldName = entry.getKey();
            JsonNode valueNode = entry.getValue();
            
            try {
                SortInfo sortInfo = parseSortInfo(fieldName, valueNode);
                if (sortInfo != null) {
                    result.put(fieldName, sortInfo);
                }
            } catch (Exception e) {
                log.warn("Failed to parse sort info for field '{}': {}", fieldName, e.getMessage());
                // 파싱 실패시 기본값으로 DESC 일반 정렬 적용
                result.put(fieldName, new NormalSortInfo(Direction.DESC));
            }
        }
        
        log.debug("Deserialized {} sort fields", result.size());
        return result;
    }
    
    /**
     * JSON 노드로부터 SortInfo 객체를 파싱
     */
    private SortInfo parseSortInfo(String fieldName, JsonNode valueNode) {
        if (valueNode.isTextual()) {
            // 일반 정렬: "ASC" 또는 "DESC" 문자열
            return parseNormalSort(valueNode.asText());
            
        } else if (valueNode.isObject()) {
            // 객체인 경우 type이나 priorityValue로 구분
            JsonNode typeNode = valueNode.get("type");
            JsonNode priorityValueNode = valueNode.get("priorityValue");
            
            if (priorityValueNode != null || "priority".equals(typeNode != null ? typeNode.asText() : null)) {
                // 우선순위 정렬
                return parsePrioritySort(fieldName, valueNode);
            } else {
                // 일반 정렬 (joinType, nullsFirst 포함 가능)
                return parseExtendedNormalSort(valueNode);
            }
            
        } else {
            log.warn("Unsupported sort value type for field '{}': {}", fieldName, valueNode.getNodeType());
            return new NormalSortInfo(Direction.DESC); // 기본값
        }
    }
    
    /**
     * 일반 정렬 파싱
     */
    private NormalSortInfo parseNormalSort(String directionString) {
        if (StringUtils.isBlank(directionString)) {
            return new NormalSortInfo(Direction.DESC);
        }
        
        try {
            Direction direction = Direction.valueOf(directionString.toUpperCase().trim());
            return new NormalSortInfo(direction);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid direction string '{}', using DESC as default", directionString);
            return new NormalSortInfo(Direction.DESC);
        }
    }
    
    /**
     * 확장된 일반 정렬 파싱 (joinType, nullsFirst 포함)
     */
    private NormalSortInfo parseExtendedNormalSort(JsonNode objectNode) {
        JsonNode directionNode = objectNode.get("direction");
        JsonNode joinTypeNode = objectNode.get("joinType");
        JsonNode nullsFirstNode = objectNode.get("nullsFirst");
        
        // direction 추출 (필수)
        Direction direction = Direction.DESC;
        if (directionNode != null && directionNode.isTextual()) {
            try {
                direction = Direction.valueOf(directionNode.asText().toUpperCase().trim());
            } catch (IllegalArgumentException e) {
                log.warn("Invalid direction '{}', using DESC", directionNode.asText());
            }
        }
        
        // joinType 추출 (옵션)
        JoinType joinType = null;
        if (joinTypeNode != null && joinTypeNode.isTextual()) {
            try {
                joinType = JoinType.valueOf(joinTypeNode.asText().toUpperCase().trim());
            } catch (IllegalArgumentException e) {
                log.warn("Invalid joinType '{}', ignoring", joinTypeNode.asText());
            }
        }
        
        // nullsFirst 추출 (옵션)
        Boolean nullsFirst = null;
        if (nullsFirstNode != null) {
            nullsFirst = nullsFirstNode.asBoolean();
        }
        
        // 적절한 생성자 호출
        if (joinType != null && nullsFirst != null) {
            return new NormalSortInfo(direction, joinType, nullsFirst);
        } else if (joinType != null) {
            return new NormalSortInfo(direction, joinType);
        } else {
            return new NormalSortInfo(direction);
        }
    }
    
    /**
     * 우선순위 정렬 파싱
     */
    private PrioritySortInfo parsePrioritySort(String fieldName, JsonNode objectNode) {
        JsonNode priorityValueNode = objectNode.get("priorityValue");
        JsonNode directionNode = objectNode.get("direction");
        JsonNode joinTypeNode = objectNode.get("joinType");
        JsonNode nullsFirstNode = objectNode.get("nullsFirst");
        
        if (priorityValueNode == null) {
            throw new IllegalArgumentException("priorityValue is required for priority sort");
        }
        
        // priorityValue 추출
        Object priorityValue = extractPriorityValue(priorityValueNode);
        
        // direction 추출 (기본값: ASC)
        Direction direction = Direction.ASC;
        if (directionNode != null && directionNode.isTextual()) {
            try {
                direction = Direction.valueOf(directionNode.asText().toUpperCase().trim());
            } catch (IllegalArgumentException e) {
                log.warn("Invalid direction '{}' for priority sort on field '{}', using ASC", 
                    directionNode.asText(), fieldName);
            }
        }
        
        // joinType 추출 (옵션)
        JoinType joinType = null;
        if (joinTypeNode != null && joinTypeNode.isTextual()) {
            try {
                joinType = JoinType.valueOf(joinTypeNode.asText().toUpperCase().trim());
            } catch (IllegalArgumentException e) {
                log.warn("Invalid joinType '{}' for priority sort on field '{}', ignoring", 
                    joinTypeNode.asText(), fieldName);
            }
        }
        
        // nullsFirst 추출 (옵션)
        Boolean nullsFirst = null;
        if (nullsFirstNode != null) {
            nullsFirst = nullsFirstNode.asBoolean();
        }
        
        // 적절한 생성자 호출
        if (joinType != null && nullsFirst != null) {
            return new PrioritySortInfo(priorityValue, direction, joinType, nullsFirst);
        } else if (joinType != null) {
            return new PrioritySortInfo(priorityValue, direction, joinType);
        } else {
            return new PrioritySortInfo(priorityValue, direction);
        }
    }
    
    /**
     * priorityValue 추출 (다양한 타입 지원)
     */
    private Object extractPriorityValue(JsonNode priorityValueNode) {
        if (priorityValueNode.isTextual()) {
            return priorityValueNode.asText();
        } else if (priorityValueNode.isNumber()) {
            if (priorityValueNode.isIntegralNumber()) {
                return priorityValueNode.asLong();
            } else {
                return priorityValueNode.asDouble();
            }
        } else if (priorityValueNode.isBoolean()) {
            return priorityValueNode.asBoolean();
        } else if (priorityValueNode.isNull()) {
            return null;
        } else {
            // 기타 복합 타입은 문자열로 변환
            return priorityValueNode.toString();
        }
    }
}