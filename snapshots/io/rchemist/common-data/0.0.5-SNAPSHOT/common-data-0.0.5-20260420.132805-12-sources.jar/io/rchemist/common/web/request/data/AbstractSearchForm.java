/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.configuration.platform.DataProviderConfig;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.query.ExistsFilterItem;
import io.rchemist.common.search.service.exception.SearchServiceException;
import io.rchemist.common.web.request.data.internal.SearchFormCacheKey;
import io.rchemist.common.web.request.data.internal.SearchFormCloner;
import io.rchemist.common.web.request.data.internal.SearchFormFieldExtractor;
import io.rchemist.common.web.request.data.internal.SearchFormFilterOps;
import io.rchemist.common.web.request.data.internal.SearchFormValidator;
import io.rchemist.common.web.request.data.search.PreservedFilterAndSortCriteria;
import io.rchemist.common.web.request.data.search.SearchFieldModifier;
import io.rchemist.common.web.request.data.search.SortFieldModifier;
import io.rchemist.common.web.service.type.EntityViewType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public abstract class AbstractSearchForm<T> extends PagingCriteria<T> implements
    FilterMapSearchForm<T>{

  protected LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = new LinkedHashMap<>();

  @JsonIgnore
  @Getter(AccessLevel.PRIVATE)
  @Setter(AccessLevel.PRIVATE)
  protected PreservedFilterAndSortCriteria preservedFilterAndSortCriteria;

  @JsonIgnore
  private boolean filterValidated = false;

  // Search 시 Cache 정보를 사용할지 여부, True 일 경우 Cache 를 사용하지 않으며, DB 에서 조회한다.
  protected Integer cacheTTL = 60 * 60;

  protected String searchTerm;

  // Front 에서 의도적으로 빈 검색 결과를 리턴 받고 싶을 때, SearchForm 을 리턴할 때는 이 값을 제거해야 한다.
  protected Boolean shouldReturnEmpty;

  // 쿼리 결과에 DISTINCT 를 적용할지 여부. OneToMany join 등으로 인한 중복 결과를 제거할 때 사용한다.
  @JsonIgnore
  protected boolean distinct = false;

  @JsonIgnore
  protected Set<String> mergedSearchTerms = new HashSet<>();

  protected ConditionOperatorType operator = ConditionOperatorType.AND;

  @RestDataField(name = "Equal 비교 여부", description = "Equal 비교 여부", example = "true")
  protected Boolean exactMatch;   // 회원가입 중복확인용으로 사용할 때 이 값을 true 로 해야 한다. 안 그러면 startwith 검색을 하기 때문이다.

  @RestDataField(name = "강제 DB 조회 여부", description = "강제 DB 조회 여부. 이 값이 true 인 경우 Hibernate Search 설정과 관계 없이 무조건 DB 에서 데이터를 조회한다.", example = "false")
  protected Boolean forceFetchFromDB = false;

  @RestDataField(name = "모든 필드의 정보 조회", description = "목록을 리턴할 때 VIEW 의 isDetail 을 true 로 전달")
  protected Boolean viewDetail = false;

  protected EntityViewType entityViewType;

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 columnFilters (@Column, @Embedded 로 정의된 필드)정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> columnFilters = new LinkedHashMap<>();

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 mappedJoinFilters (@OneToMany 로 정의된 필드, FilterItem 에 JoinAlias, JoinClass 정보가 추가로 저장됨) 정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> mappedJoinFilters = new LinkedHashMap<>();

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 unmappedJoinFilters 정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> unmappedJoinFilters = new LinkedHashMap<>();

  // EXISTS 서브쿼리 필터 조건. filterExists() / filterNotExists() 로 추가된다.
  @JsonIgnore
  protected List<ExistsFilterItem> existsFilters = new ArrayList<>();

  // ResponseEntityListService#overrideSearchForm 에서 추가할 수 있다.
  // SearchForm 별로 validateFilters 를 확장하기 위해 사용한다.
  @JsonIgnore
  protected List<SearchFieldModifier> searchFieldModifiers = new ArrayList<>();

  // ResponseEntityListService#overrideSearchForm 에서 추가할 수 있다.
  // SearchForm 별로 validateSorts 를 확장하기 위해 사용한다.
  @JsonIgnore
  protected List<SortFieldModifier> sortFieldModifiers = new ArrayList<>();

  @Override
  public ConditionOperatorType getOperator() {
    return operator;
  }

  @JsonIgnore
  protected Map<String, Object> additionalContext;

  @Override
  public EntityViewType getEntityViewType() {
    if (this.entityViewType != null) {
      return this.entityViewType;
    }
    if (BooleanUtils.toBoolean(this.viewDetail)) {
      return EntityViewType.VIEW;
    }
    return EntityViewType.LIST;
  }

  @Override
  public Object getValue(String propertyName) {
    return SearchFormFilterOps.getValue(this, propertyName);
  }

  @Override
  public Object getValue(ConditionOperatorType operatorType, QueryConditionType conditionType, String propertyName) {
    return SearchFormFilterOps.getValue(this, operatorType, conditionType, propertyName);
  }

  @Override
  public String getSafeSearchValue(String propertyName) {
    Object value = getValue(propertyName);
    return value == null ? null : String.valueOf(value);
  }

  public boolean isDistinct() {
    return distinct;
  }

  public void setDistinct(boolean distinct) {
    this.distinct = distinct;
  }

  @Override
  public boolean isExactMatch() {
    return BooleanUtils.toBoolean(exactMatch);
  }

  @Override
  public Long[] getSearchIds() {
    return SearchFormFilterOps.getSearchIds(this);
  }

  public String[] getSearchFieldNames(Class<?> entityClass) {
    return SearchFormFieldExtractor.getSearchFieldNames(this, entityClass);
  }

  public String[] getHibernateSearchFieldNames(Class<?> entityClass) {
    return SearchFormFieldExtractor.getHibernateSearchFieldNames(this, entityClass);
  }

  public void validateFilters(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException {
    SearchFormValidator.validateFilters(this, entityClass, hibernateSearch);
  }

  @Override
  public boolean createPreservedFilterAndSortCriteria() {
    if (this.preservedFilterAndSortCriteria == null) {
      this.preservedFilterAndSortCriteria = new PreservedFilterAndSortCriteria().withFilters(filters).withSorts(sorts);
      return true;
    }
    return false;
  }

  public void validateSorts(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException {
    SearchFormValidator.validateSorts(this, entityClass, hibernateSearch);
  }

  @Override
  public void revertPreservedFilterAndSortCriteria() {
    if(this.preservedFilterAndSortCriteria != null) {
      this.filters = this.preservedFilterAndSortCriteria.getFilters();
      this.sorts = this.preservedFilterAndSortCriteria.getSorts();
      this.clearPreservedFilterAndSortCriteria();
    }
  }

  @Override
  public T setFilterIfAbsent(ConditionOperatorType operatorType, FilterItem... filterItems) {
    if(MapUtils.isEmpty(this.filters)) {
      this.filters = new LinkedHashMap<>();
    }

    this.filters = addFilters(operatorType, filterItems);

    return (T) this;
  }

  @Override
  public void preparePreservedFilterAndSortCriteria(Class<?> entityClass, boolean hibernateSearch) {
    if(this.preservedFilterAndSortCriteria == null) {
      createPreservedFilterAndSortCriteria();
    }
    try {
      validateFilters(entityClass, hibernateSearch);
      validateSorts(entityClass, hibernateSearch);
    } catch (Exception e) {
      log.debug("preparePreservedFilterAndSortCriteria swallowed: {}", e.toString());
    }
  }

  @Override
  public String getCacheKey() {
    return SearchFormCacheKey.build(this);
  }

  @Override
  public boolean isShouldReturnEmpty() {
    return BooleanUtils.toBoolean(this.shouldReturnEmpty);
  }

  @Override
  public void removeFilterItem(ConditionOperatorType type, String name) {
    SearchFormFilterOps.removeFilterItem(this, type, name);
  }

  public T withForceFetchFromDB(Boolean forceFetchFromDB) {
    this.forceFetchFromDB = forceFetchFromDB;
    return (T) this;
  }

  public boolean isForceFetchFromDB() {
    return BooleanUtils.toBoolean(forceFetchFromDB);
  }

  public T deepCopy(AbstractSearchForm<T> newSearchForm, boolean removeRequestOnlyValue) {
    if (this.preservedFilterAndSortCriteria != null) {
      newSearchForm.preservedFilterAndSortCriteria = this.preservedFilterAndSortCriteria.deepCopy();
    }
    SearchFormCloner.copyStateExceptPreserved(this, newSearchForm, removeRequestOnlyValue);
    return (T) newSearchForm;
  }

  public LinkedHashMap<ConditionOperatorType, FilterItem[]> getSubConditions(
      ConditionOperatorType conditionOperatorType, String propertyName) {
    return SearchFormFilterOps.getSubConditions(this, conditionOperatorType, propertyName);
  }

  private void clearPreservedFilterAndSortCriteria() {
    this.preservedFilterAndSortCriteria = null;
  }

  public T withSearchFieldModifiers(
      List<SearchFieldModifier> searchFieldModifiers) {
    this.searchFieldModifiers = searchFieldModifiers;
    return (T) this;
  }

  public T withSortFieldModifiers(
      List<SortFieldModifier> sortFieldModifiers) {
    this.sortFieldModifiers = sortFieldModifiers;
    return (T) this;
  }

  public T addSearchFieldModifiers(SearchFieldModifier... modifiers) {
    if (modifiers == null || modifiers.length == 0) {
      return (T) this;
    }
    this.searchFieldModifiers.addAll(Arrays.asList(modifiers));
    return (T) this;
  }

  public T addSortFieldModifiers(SortFieldModifier... modifiers) {
    if (modifiers == null || modifiers.length == 0) {
      return (T) this;
    }
    this.sortFieldModifiers.addAll(Arrays.asList(modifiers));
    return (T) this;
  }

  public T withViewDetail(Boolean viewDetail) {
    this.viewDetail = viewDetail;
    return (T) this;
  }

  public boolean hasFilters() {
    return SearchFormFilterOps.hasFilters(this);
  }

  public boolean isViewDetail() {
    return BooleanUtils.toBoolean(viewDetail);
  }

  public boolean shouldUseHibernateSearch() {
    return (DataProviderConfig.useHibernateSearch() && !isForceFetchFromDB() && !isShouldReturnEmpty());
  }

  public void removeFilters(ConditionOperatorType operatorType, String... names) {
    SearchFormFilterOps.removeFilters(this, operatorType, names);
  }

  public void removeFiltersExcludeNames(ConditionOperatorType operatorType, String... names) {
    SearchFormFilterOps.removeFiltersExcludeNames(this, operatorType, names);
  }

  public void removeFilter(String fieldName) {
    SearchFormFilterOps.removeFilter(this, fieldName);
  }

  public boolean hasFilter(String fieldName) {
    return SearchFormFilterOps.hasFilter(this, fieldName);
  }

  @Override
  public String toString() {
    return SearchFormCacheKey.toStringRepr(this, preservedFilterAndSortCriteria);
  }

  public void renameFilterItem(String oldName, String newName) {
    SearchFormFilterOps.renameFilterItem(filters, oldName, newName);
  }

  protected void renameFilterItem(LinkedHashMap<ConditionOperatorType, FilterItem[]> filters, String oldName, String newName) {
    SearchFormFilterOps.renameFilterItem(filters, oldName, newName);
  }

  public void renameSortItem(String oldName, String newName) {
    SearchFormFilterOps.renameSortItem(this, oldName, newName);
  }

}
