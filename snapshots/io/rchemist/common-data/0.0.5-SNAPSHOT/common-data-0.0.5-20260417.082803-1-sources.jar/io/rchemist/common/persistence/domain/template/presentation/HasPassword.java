/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.type.RegexType;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasPassword<T> extends ClassTransformTarget {

  default String getPassword() {
    throw new ClassTransformException();
  }

  default void setPassword(String password) {
    throw new ClassTransformException();
  }

  default T withPassword(String password) {
    setPassword(password);
    return (T) this;
  }

  default boolean validatePassword(boolean required, String passwordRegexPattern) {
    if (StringUtils.isNotEmpty(getPassword())) {
      if (StringUtils.isEmpty(passwordRegexPattern)) {
        return RegexType.PASSWORD.validate(getPassword(), required);
      } else {
        return Pattern.matches(passwordRegexPattern, getPassword());
      }
    }
    return !required;
  }

  default boolean validatePassword(boolean required) {
    return validatePassword(required, null);
  }

  default boolean validatePassword() {
    return validatePassword(true);
  }

}
