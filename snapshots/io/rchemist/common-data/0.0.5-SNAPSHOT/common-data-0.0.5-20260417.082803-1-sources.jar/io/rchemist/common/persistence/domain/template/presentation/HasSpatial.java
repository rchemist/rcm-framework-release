/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.embedded.ICoordinate;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.math.BigDecimal;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface HasSpatial<T> extends ClassTransformTarget {

  default Double getLatitude() {
    throw new ClassTransformException();
  }

  default void setLatitude(Double latitude) {
    throw new ClassTransformException();
  }

  default Double getLongitude() {
    throw new ClassTransformException();
  }

  default void setLongitude(Double longitude) {
    throw new ClassTransformException();
  }

  default void setDecimalLongitude(BigDecimal longitude){
    if(longitude == null){
      setLongitude(null);
    }else{
      setLongitude(longitude.doubleValue());
    }
  }

  default void setDecimalLatitude(BigDecimal latitude){
    if(latitude == null){
      setLatitude(null);
    }else{
      setLatitude(latitude.doubleValue());
    }
  }

  default void setCoordinates(ICoordinate coordinate){
    if(coordinate == null){
      setLatitude(null);
      setLongitude(null);
    }else{
      setLatitude(coordinate.getLatitude());
      setLongitude(coordinate.getLongitude());
    }
  }

  default T withLatitude(Double latitude) {
    setLatitude(latitude);
    return (T) this;
  }

  default T withLongitude(Double longitude) {
    setLongitude(longitude);
    return (T) this;
  }

  default T withCoordinates(ICoordinate coordinate){
    if(coordinate == null){
      setLatitude(null);
      setLongitude(null);
    }else{
      setLatitude(coordinate.getLatitude());
      setLongitude(coordinate.getLongitude());
    }
    return (T) this;

  }

}