/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.util.BooleanUtil;
import io.rchemist.common.util.DateUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.LocalTimeUtil;
import io.rchemist.common.util.NumberUtil;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum JavaFieldType {

  INTEGER(true, true, true, value -> NumberUtil.getInteger(value, null) != null, FieldMatch.NOT_INTEGER_ERRORMESSAGE),
  STRING(true, true, false, value -> true, null),
  BOOLEAN(true, true, false, value -> BooleanUtil.getBooleanValue(value, null) != null, FieldMatch.NOT_BOOLEAN_ERRORMESSAGE),
  LONG(true, true, true, value -> NumberUtil.getLong(value, null) != null, FieldMatch.NOT_LONG_ERRORMESSAGE),
  BIG_DECIMAL(true, true, true, value -> NumberUtil.getBigDecimal(value, null) != null, FieldMatch.NOT_NUMERIC_ERRORMESSAGE),
  DATE(true, true, false, value -> DateUtil.getDate(value, null) != null, FieldMatch.NOT_DATE_ERRORMESSAGE),
  TIME(true, true, false, value -> LocalTimeUtil.parse(value) != null, FieldMatch.NOT_DATE_ERRORMESSAGE),
  LOCAL_DATE_TIME(true, true, false, value -> LocalDateTimeUtil.parse(value) != null, FieldMatch.NOT_DATETIME_ERRORMESSAGE),
  UNKNOWN(true, false, false, value -> true, null),
  OTHER(false, false, false, value -> true, null);

  @Getter
  private boolean searchable;

  @Getter
  private boolean sortable;

  @Getter
  private boolean numeric;

  @Getter
  private FieldMatch fieldMatch;

  private String errorMessage;

  JavaFieldType(boolean searchable, boolean sortable, boolean numeric, FieldMatch fieldMatch, String errorMessage) {
    this.searchable = searchable;
    this.sortable = sortable;
    this.numeric = numeric;
    this.fieldMatch = fieldMatch;
    this.errorMessage = errorMessage;
  }

  public void validate(String value){
    if(!fieldMatch.match(value)){
      throw new RuntimeException(errorMessage);
    }
  }

  public interface FieldMatch {

    String NOT_NUMERIC_ERRORMESSAGE = "error.message.field.not_numeric";
    String NOT_INTEGER_ERRORMESSAGE = "error.message.field.not_integer";
    String NOT_LONG_ERRORMESSAGE = "error.message.field.not_long";
    String NOT_BOOLEAN_ERRORMESSAGE = "error.message.field.not_boolean";
    String NOT_DATE_ERRORMESSAGE = "error.message.field.not_date";
    String NOT_TIME_ERRORMESSAGE = "error.message.field.not_time";
    String NOT_DATETIME_ERRORMESSAGE = "error.message.field.not_datetime";

    boolean match(String value);

  }

}
