/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 *
 * template-admin 의 MultipleAssetForm 에 대응하는 backend 폼
 *
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class MultipleAssetForm implements Serializable {

  protected List<MultipleAssetItem> assets = new ArrayList<>();

  protected String preferred;

  /**
   * 기본 이미지, assets 중 하나가 되어야 한다.
   * 만약 이 값이 비어 있다면 assets 의 첫번째 아이템을 preferred 로 지정한다.
   */
  public String getPreferred() {
    if (StringUtils.isEmpty(preferred) && hasAssets()) {
      preferred = assets.get(0).getName();
    }
    return preferred;
  }

  public MultipleAssetForm addAssets(final MultipleAssetItem... assets) {
    this.assets.addAll(Arrays.asList(assets));
    return this;
  }

  public boolean hasAssets() {
    return CollectionUtils.isNotEmpty(assets);
  }

}
