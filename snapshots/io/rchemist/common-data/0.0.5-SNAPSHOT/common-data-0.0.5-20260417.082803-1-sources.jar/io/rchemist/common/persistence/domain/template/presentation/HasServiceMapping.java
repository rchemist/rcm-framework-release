/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.data.IServiceMapping;
import io.rchemist.common.persistence.domain.data.ServiceIdentifier;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.StringUtil;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasServiceMapping<T> extends ClassTransformTarget, ServiceIdentifier {

  String GENERAL_TYPE = "GENERAL";
  String SPLIT = "||";
  String BLANK = "_";

  default String getServiceId(){
    throw new ClassTransformException();
  }

  default void setServiceId(String serviceId){
    throw new ClassTransformException();
  }

  default String getServiceAlias() {throw new ClassTransformException();}
  default void setServiceAlias(String serviceAlias){
    throw new ClassTransformException();
  }


  default String getServiceEntityId(){
    throw new ClassTransformException();
  }

  default void setServiceEntityId(String serviceEntityId){
    throw new ClassTransformException();
  }

  default String getParentServiceEntityId() { throw new ClassTransformException(); }

  default void setParentServiceEntityId(String parentServiceEntityId){
    throw new ClassTransformException();
  }

  default T withServiceId(String serviceId){
    setServiceId(serviceId);
    return (T) this;
  }

  default T withServiceEntityId(String serviceEntityId){
    setServiceEntityId(serviceEntityId);
    return (T) this;
  }

  default T withParentServiceEntityId(String parentServiceEntityId){
    setParentServiceEntityId(parentServiceEntityId);
    return (T) this;
  }

  default T withServiceAlias(String serviceAlias){
    setServiceAlias(serviceAlias);
    return (T) this;
  }

  @Override
  @JsonIgnore
  default void setServiceMapping(IServiceMapping serviceMapping){
    setServiceIdentifier(serviceMapping.getServiceIdentifier());
  }

  @JsonIgnore
  default void setServiceIdentifier(ServiceIdentifier serviceIdentifier){
    setServiceAlias(serviceIdentifier.getServiceAlias());
    setServiceEntityId(serviceIdentifier.getServiceEntityId());
    setServiceId(serviceIdentifier.getServiceId());
    setParentServiceEntityId(serviceIdentifier.getParentServiceEntityId());
  }

  @JsonIgnore
  default ServiceIdentifier getServiceIdentifier(){
    return ServiceIdentifier.create(getServiceId(), getServiceEntityId(), getServiceAlias(), getParentServiceEntityId());
  }

  @JsonIgnore
  default T withServiceIdentifier(IServiceMapping<?> identifier){
    setServiceAlias(identifier.getServiceAlias());
    setServiceId(identifier.getServiceId());
    setServiceEntityId(identifier.getServiceEntityId());
    setParentServiceEntityId(identifier.getParentServiceEntityId());
    return (T) this;
  }

  @JsonIgnore
  default T withServiceIdentifier(ServiceIdentifier identifier){
    setServiceAlias(identifier.getServiceAlias());
    setServiceId(identifier.getServiceId());
    setServiceEntityId(identifier.getServiceEntityId());
    setParentServiceEntityId(identifier.getParentServiceEntityId());
    return (T) this;
  }

  @JsonIgnore
  static List<String> getMultipleValues(String value){
    if(StringUtils.isEmpty(value))
      return new ArrayList<>();

    List<String> list = new ArrayList<>();

    if(StringUtils.contains(value, ",")){
      list.addAll(StringUtil.split(value, ","));
    }else{
      list.add(value);
    }

    return list;
  }

}
