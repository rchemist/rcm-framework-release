/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.util.StringUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum GroupEnumType {

  GENERAL(
      "GroupGeneralId",
      "GroupGeneral",
      100),


  APPROVE(
      "GroupApproveId",
      "GroupApprove",
      200),


  PROPERTY(
      "GroupPropertyId",
      "GroupProperty",
      300),


  AVAILABILITY(
      "GroupAvailabilityId",
      "GroupAvailability",
      400),


  ADVANCED(
      "GroupAdvancedId",
      "GroupAdvanced",
      500),

  ADDITIONAL(
      "GroupAdditionalId",
      "GroupAdditional",
      550),

  CATALOG(
      "GroupCatalogId",
      "GroupCatalog",
      600),


  CUSTOMER(
      "GroupCustomerId",
      "GroupCustomer",
      700),

  USER(
      "GroupUserId",
      "GroupUser",
      750),

  INQUIRY_MESSAGE(
      "GroupInquiryMessageId",
      "GroupInquiryMessage",
      10),

  INQUIRY_STATUS(
      "GroupInquiryStatusId",
      "GroupInquiryStatus",
      20),

  SUB(
      "GroupSubId",
      "GroupSub",
      780),


  AUTHOR(
      "GroupAuthorId",
      "GroupAuthor",
      800),

  CUSTOMER_CREDIT(
      "GroupCustomerCreditId",
      "GroupCustomerCredit",
      810),
  MILEAGE(
      "GroupMileageId",
      "GroupMileage",
      820),

  INVENTORY(
      "GroupInventoryId",
      "GroupInventory",
      900),


  FULFILLMENT(
      "GroupFulfillmentId",
      "GroupFulfillment",
      1000),


  ADDRESS(
      "GroupAddressId",
      "GroupAddress",
      1100),

  COORDINATE(
      "GroupCoordinateId",
      "GroupCoordinate",
      1110),


  PHONE(
      "GroupPhoneId",
      "GroupPhone",
      1200),


  MEDIA(
      "GroupMediaId",
      "GroupMedia",
      1300),


  VIEW(
      "GroupViewId",
      "GroupView",
      1400),


  DESCRIPTION(
      "GroupDescriptionId",
      "GroupDescription",
      1500),


  ITEM(
      "GroupItemId",
      "GroupItem",
      1510),

  URL("GroupUrlId", "GroupUrl", 1520),
  TEMPLATE("GroupTemplateId", "GroupTemplate", 1530),


  ATTRIBUTE(
      "GroupAttributeId",
      "GroupAttribute",
      1600),


  RESTRICTION(
      "GroupRestrictionId",
      "GroupRestriction",
      1700),

  CUSTOM_FIELD(
      "GroupCustomFieldId",
      "GroupCustomField",
      1800),


  ADMIN_UI(
      "GroupAdminUiId",
      "GroupAdminUi",
      1800),


  BADGES(
      "GroupBadgesId",
      "GroupBadges",
      1900),


  VALIDATION(
      "GroupValidationId",
      "GroupValidation",
      2000),


  RULE(
      "GroupRuleId",
      "GroupRule",
      2100),


  PRICE(
      "GroupPriceId",
      "GroupPrice",
      2200),


  ADJUSTMENT(
      "GroupAdjustmentId",
      "GroupAdjustment",
      2300),


  REWARD(
      "GroupRewardId",
      "GroupReward",
      2400),


  REWARD_CONDITION(
      "GroupRewardConditionId",
      "GroupRewardCondition",
      2500),


  CUSTOMER_RANK(
      "GroupCustomerRankId",
      "GroupCustomerRank",
      2600),


  CUSTOMER_OFFER(
      "GroupCustomerOfferId",
      "GroupCustomerOffer",
      2700),


  RANK(
      "GroupRankId",
      "GroupRank",
      2800),


  ORDER(
      "GroupOrderId",
      "GroupOrder",
      2900),

  PRODUCT(
      "GroupProductId",
      "GroupProduct",
      2910),


  PAYMENT(
      "GroupPaymentId",
      "GroupPayment",
      3000),


  OFFER_ADJUSTMENT(
      "GroupOfferAdjustmentsId",
      "GroupOfferAdjustments",
      3100),


  FORM_TAB(
      "GroupFormTabId",
      "GroupFormTab",
      3200),


  FORM_GROUP(
      "GroupFormGroupId",
      "GroupFormGroup",
      3300),


  FORM_FIELD(
      "GroupFormFieldId",
      "GroupFormField",
      3400),


  REDIRECT(
      "GroupRedirectId",
      "GroupRedirect",
      3500),


  WHISTLE_TARGET(
      "GroupWhistleTargetId",
      "GroupWhistleTarget",
      3510),

  SEO_METADATA(
      "GroupMetadataId",
      "GroupMetadata",
      3600),


  BOARD(
      "GroupBoardId",
      "GroupBoard",
      3650),

  ARTICLE(
      "GroupArticleId",
      "GroupArticle",
      3670),

  COMMENT(
      "GroupCommentId",
      "GroupComment",
      3680),

  PARENT_COMMENT(
      "GroupParentCommentId",
      "GroupParentComment",
      3690),

  CHILD_COMMENT(
      "GroupChildCommentId",
      "GroupChildComment",
      3700),

  FEEDBACK(
      "GroupFeedbackId",
      "GroupFeedback",
      3710),

  GROUP_ROLE("GroupRoleId",
      "GroupRole",
      3720),


  GROUP_GRADE(
      "GroupGradeId",
      "GroupGrade",
      3800),

  PARTICIPANT(
      "GroupParticipantId",
      "GroupParticipant",
      3900),


  EXTRA(
      "GroupExtraId",
      "GroupExtra",
      Integer.MAX_VALUE - 1),


  MODIFY_ON_LIST(
      "GroupModifyOnListId",
      "GroupModifyOnList",
      10000),


  MODIFY_ON_LIST_TARGET(
      "GroupModifyOnListTargetId",
      "GroupModifyOnListTarget",
      10100),

  BLOCKED(
      "GroupBlockedId"
      , "GroupBlocked"
      , 10000000
  ),


  STATUS(
      "GroupStatusId",
      "GroupStatus",
      Integer.MAX_VALUE - 1),

  STATUS_HISTORY(
      "GroupStatusHistoryId",
          "GroupStatusHistory",
      Integer.MAX_VALUE);


  @Getter
  private final int order;
  @Getter
  private final String name;
  @Getter
  private final String id;

  GroupEnumType(String id, String name, int order) {
    this.order = order;
    this.name = name;
    this.id = id;
  }

  public static LinkedHashMap<String, String> getOptionValues(){
    List<GroupEnumType> types = Arrays.asList(GroupEnumType.values());
    Collections.sort(types, Comparator.comparing(GroupEnumType::getOrder));
    LinkedHashMap<String, String> map = new LinkedHashMap<>();
    int loop = 1;
    for(GroupEnumType type : types){
      String value = type.name();
      String count = StringUtil.fill(String.valueOf(loop++), "0", 2);
      String name = "["+ count +"] " + MessageSourceHelper.getMessage(type.getName());
      map.put(value, name);
    }
    return map;
  }

}
