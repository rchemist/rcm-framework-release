/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import com.google.common.base.Objects;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.web.request.data.AbstractSearchForm;
import io.rchemist.common.web.request.data.PageResult;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.service.ResponseListService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.data.domain.Page;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class ResponseListWrapper<T, S extends SearchFormWrapper<S>> {

  public ResponseListWrapper() {
  }

  public ResponseListWrapper(S searchForm) {
    setSearchForm(searchForm.deepCopy(true));
  }

  private List<T> list = new ArrayList<>();

  private Integer totalCount;

  private Integer page;

  private Integer pageSize;

  private Integer totalPage;

  private List<SortEntry> sorts;

  private ErrorDTO error;

  private S searchForm;

  /**
   * page 데이터 인 list 와 달리 추가로 제공하고 싶은 정보가 있다면 attributes 를 사용한다.
   */
  private Map<String, Object> attributes = new HashMap<>();

  public ResponseListWrapper<T, S> addAttribute(String key, Object value){
    this.attributes.put(key, value);
    return this;
  }

  public ResponseListWrapper<T, S> withAttributes(Map<String, Object> attributes) {
    if (attributes == null) {
      attributes = new HashMap<>();
    }
    this.attributes = attributes;
    return this;
  }

  public ResponseListWrapper<T, S> withSorts(List<SortEntry> sorts) {
    this.sorts = sorts;
    return this;
  }

  public ResponseListWrapper<T, S> addSortEntry(SortEntry sortEntry) {
    if (this.sorts == null) {
      this.sorts = new ArrayList<>();
    }
    this.sorts.add(sortEntry);
    return this;
  }

  public ResponseListWrapper<T, S> addListItem(T item){
    if(this.list == null)
      this.list = new ArrayList<>();
    this.list.add(item);
    return this;
  }

  public ResponseListWrapper<T, S> withError(ErrorDTO error) {
    this.error = error;
    return this;
  }

  public ResponseListWrapper<T, S> withList(List<T> list) {
    this.list = list;
    return this;
  }

  public ResponseListWrapper<T, S> withTotalCount(Integer totalCount) {
    this.totalCount = totalCount;
    return this;
  }

  public ResponseListWrapper<T, S> withPage(Integer page) {
    this.page = page;
    return this;
  }

  public ResponseListWrapper<T, S> withPageSize(Integer pageSize) {
    this.pageSize = pageSize;
    return this;
  }

  public ResponseListWrapper<T, S> withTotalPage(Integer totalPage) {
    this.totalPage = totalPage;
    return this;
  }


  public void setSearchForm(S searchForm){
    this.searchForm = searchForm;
    if (searchForm != null) {
      setPage(searchForm.getPage());
      setPageSize(searchForm.getPageSize());
      setSorts(searchForm.getSorts());

      if (searchForm instanceof AbstractSearchForm<?> form) {
        // response 로 넘길 때는 원래 요청된 filter, sort 정보를 그대로 다시 돌려 준다.
        form.revertPreservedFilterAndSortCriteria();
      }
    }
  }

  public ResponseListWrapper<T, S> withSearchForm(S searchForm) {
    setSearchForm(searchForm);
    return this;
  }

  public boolean isError(){
    return (error != null && error.isError());
  }

  public boolean isEmpty() {
    return CollectionUtils.isEmpty(list);
  }

  public boolean isNull() {
    return isEmpty() || isError();
  }

  public void setTotalCount(long totalCount){
    this.totalCount = NumberUtil.getInteger(totalCount);
    if (this.searchForm != null) {
      this.searchForm.setTotalCount(this.totalCount);
    }
  }

  public void setTotalPage(long totalPage){
    this.totalPage = NumberUtil.getInteger(totalPage);
    if (this.searchForm != null) {
      this.searchForm.setTotalPage(this.totalPage);
    }
  }

  public <E> ResponseListWrapper<T, S> createResult(ResponseListService<E, T> listService) {
    try {

      PageResult<E> result = listService.getPage();
      if(result == null || result.getPage() == null)
        throw new Exception("Page Result is null. Please check the listService.getPage()");

      return createResult(result.getPage(), listService);

    }catch (Exception e) {
      withError(new ErrorDTO(e));
    }
    return this;
  }

  public <E> ResponseListWrapper<T, S> createResult(Page<E> page, ResponseListService<E, T> listService) {
    try {
      setTotalCount(page.getTotalElements());
      setTotalPage(page.getTotalPages());

      List<E> list = page.getContent();

      for (E item : CollectionUtils.emptyIfNull(list)) {
        addListItem(listService.createListItem(item));
      }
    }catch (Exception e) {
      withError(new ErrorDTO(e));
    }

    return this;

  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ResponseListWrapper<?, ?> that = (ResponseListWrapper<?, ?>) o;

    return Objects.equal(CollectionUtils.size(list), CollectionUtils.size(that.list))
        && Objects.equal(totalCount, that.totalCount)
        && Objects.equal(page, that.page)
        && Objects.equal(pageSize, that.pageSize)
        && Objects.equal(totalPage, that.totalPage)
        // && Objects.equal(sort, that.sort)
        // && Objects.equal(sorts, that.sorts)
        && Objects.equal(error, that.error);
        // && Objects.equal(searchForm, that.searchForm);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(list, totalCount, page, pageSize, totalPage, sorts, error,
        searchForm);
  }

  public ResponseListWrapper<T, S> clone(boolean includeList) {
    ResponseListWrapper<T, S> clone = new ResponseListWrapper<>();

    if (includeList) {
      clone.setList(new ArrayList<>(this.list));
    }

    clone.setTotalCount(this.totalCount);
    clone.setPage(this.page);
    clone.setPageSize(this.pageSize);
    clone.setTotalPage(this.totalPage);

    if (MapUtils.isNotEmpty(this.attributes)) {
      clone.setAttributes(new HashMap<>(this.attributes));
    }

    if (this.sorts != null) {
      clone.setSorts(new ArrayList<>(this.sorts));
    }

    clone.setError(this.error != null ? this.error.clone() : null);
    clone.setSearchForm(this.searchForm);

    return clone;
  }

}
