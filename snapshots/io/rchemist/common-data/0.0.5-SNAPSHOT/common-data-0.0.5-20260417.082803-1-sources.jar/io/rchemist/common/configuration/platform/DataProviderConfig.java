/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.configuration.platform;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.transformer.PlatformClassTransformHelper;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
@ConfigurationProperties(prefix = "platform.config.provider")
@Data
public class DataProviderConfig {

  private static DataProviderConfig config;

  private SearchProvider search;

  @Value("${platform.config.provider.mongo:true}")
  private boolean useMongoDB;

  private CacheProvider cache;

  @Value("${platform.config.provider.kafka:false}")
  private boolean useKafka;

  public static SearchProvider getSearchProvider(){
    return PlatformClassTransformHelper.getSearchProviderConfiguration(getConfig().getSearch());
  }

  public static CacheProvider getCacheProvider(){
    return getConfig().getCache();
  }

  private static DataProviderConfig getConfig(){
    if(config == null){
      config = ApplicationContextHolder.getBean(DataProviderConfig.class);
    }
    return config;
  }

  public static boolean useKafka(){
    return getConfig().isUseKafka();
  }

  public static boolean useMongoDB() {return getConfig().isUseMongoDB();}

  public static boolean useHibernateSearch(){
    return getSearchProvider().equals(SearchProvider.HIBERNATE);
  }

}
