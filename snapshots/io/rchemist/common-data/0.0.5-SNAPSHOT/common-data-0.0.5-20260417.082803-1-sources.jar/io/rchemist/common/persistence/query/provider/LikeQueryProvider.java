/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.provider;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.BooleanUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.util.List;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class LikeQueryProvider implements QueryParseProvider {

  private static final char WILD_CARD_CHARACTER = '%';

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.LIKE);
  }

  @Override
  public <T> Predicate getPredicate(CriteriaBuilder builder,
      QueryConditionType condition, Path<T> path, Object value, List<?> values) {

    Predicate predicate = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    // like, startwith 와 같은 질의는 null value 를 처리할 수 없다.
    if(value == null){
      // null 로 like 검색을 시도할 때는 isNull 을 처리하게 한다.
      predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.NULL, path, null, null);
    }else{

      if(value instanceof EnumType){
        // value = ((EnumType) value).getType();
        predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.EQUAL, path, value, null);
      }else if(Boolean.class.isAssignableFrom(value.getClass()) || boolean.class.isAssignableFrom(value.getClass())) {
        boolean booleanValue = BooleanUtil.getBooleanValue(value, true);
        predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.EQUAL, path, booleanValue, null);
      }

      if(predicate == null){
        String searchValue = getSearchValue(condition, value);
        predicate = builder.like((Expression<String>) path, searchValue);
      }

    }

    return condition.isNegative() ? predicate.not() : predicate;

  }

  private String getSearchValue(QueryConditionType condition, Object value) {
    String val = StringUtil.getString(value);
    if(condition.equals(QueryConditionType.LIKE) || condition.equals(QueryConditionType.NOT_LIKE)){
      val = WILD_CARD_CHARACTER + val + WILD_CARD_CHARACTER;
    }else if(condition.equals(QueryConditionType.START_WITH) || condition.equals(QueryConditionType.NOT_START_WITH)){
      val = val + WILD_CARD_CHARACTER;
    }else if(condition.equals(QueryConditionType.END_WITH) || condition.equals(QueryConditionType.NOT_END_WITH)){
      val = WILD_CARD_CHARACTER + val;
    }
    return val;
  }

  @Override
  public int getOrder() {
    return 200;
  }
}
