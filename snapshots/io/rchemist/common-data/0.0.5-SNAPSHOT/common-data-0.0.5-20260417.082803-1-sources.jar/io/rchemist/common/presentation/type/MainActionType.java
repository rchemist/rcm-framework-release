/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum MainActionType {
  ADD
  , NONE  // 이 타입이 설정되면 다른 타입을 모두 무시한다. 단, Polymorphic classes 의 구조에 따라 다른 클래스가 오버라이드 하면 해당 설정을 따른다
}
