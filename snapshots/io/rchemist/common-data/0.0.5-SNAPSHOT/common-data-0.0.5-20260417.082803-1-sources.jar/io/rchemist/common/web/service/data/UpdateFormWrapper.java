/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.data;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.web.service.type.EntityViewType;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface UpdateFormWrapper<UPDATE_FORM, ID> extends HasIdEntity<ID>, RevisionEntityWrapper<UPDATE_FORM>, ClassTransformTarget {

  // advanced searchForm 에서 사용 할 수 있도록 추가
  default String[] getModifiedFields() {
    return null;
  }

  // advanced searchForm 에서 사용 할 수 있도록 추가
  default void setModifiedFields(String[] modifiedFields) {
  }

  default UPDATE_FORM withModifiedFields(String[] modifiedFields) {
    setModifiedFields(modifiedFields);
    return (UPDATE_FORM) this;
  }

  default boolean isUpdateTargetField(String fieldName) {
    if (ArrayUtils.isNotEmpty(getModifiedFields())) {
      return ArrayUtils.contains(getModifiedFields(), fieldName);
    }
    return true;
  }

  default UPDATE_FORM addModifiedField(String fieldName) {
    String[] fields = getModifiedFields();
    if (fields == null) {
      fields = new String[]{fieldName};
      return withModifiedFields(fields);
    }
    // 중복 제거
    Set<String> list = new HashSet<>(List.of(fields));
    list.add(fieldName);
    fields = list.toArray(new String[0]);
    setModifiedFields(fields);
    return (UPDATE_FORM) this;
  }

  default UPDATE_FORM removeModifiedField(String fieldName) {
    String[] fields = getModifiedFields();
    if (fields != null) {
      fields = ArrayUtils.removeElement(fields, fieldName);
      setModifiedFields(fields);
    }
    return (UPDATE_FORM) this;
  }

  default EntityViewType getViewType() {
    throw new ClassTransformException();
  }

  default void setViewType(EntityViewType viewType) {
    throw new ClassTransformException();
  }

  default UPDATE_FORM withViewType(EntityViewType viewType) {
    setViewType(viewType);
    return (UPDATE_FORM) this;
  }

}
