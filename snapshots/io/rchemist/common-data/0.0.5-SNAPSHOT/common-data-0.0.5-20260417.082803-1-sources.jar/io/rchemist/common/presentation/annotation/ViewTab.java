/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.TabEnumType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface ViewTab {

  /**
   * 기본적으로 type 으로 처리하고, id, name, order 는 오버라이드 한다.
   */
  TabEnumType type() default TabEnumType.GENERAL;

  /**
   * HTML 에서 사용하는 tab.id
   * 영문,숫자, _ 만 지원
   * @return
   */
  String id() default "";

  /**
   * 폼 이름
   * i18n 지원
   * @return
   */
  String name() default "";

  /**
   * 폼 이름 옆에 표시할 툴팁 메시지
   * i18n 지원
   * @return
   */
  String tooltip() default "";

  /**
   * 폼 노출 순서
   * @return
   */
  int order() default -9999;

  boolean overridden() default false;

}
