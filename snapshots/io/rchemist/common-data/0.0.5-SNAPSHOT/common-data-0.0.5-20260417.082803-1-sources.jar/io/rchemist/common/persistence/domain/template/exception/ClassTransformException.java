/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.exception;

import io.rchemist.common.exception.ErrorTypeRuntimeException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.exception.error.ErrorType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class ClassTransformException extends ErrorTypeRuntimeException {

  public ClassTransformException() {
    super("RCM ClassTransformer didn't work properly. This method is not available.");
  }

  public ClassTransformException(ErrorType errorType) {
    super(errorType);
  }

  public ClassTransformException(Throwable cause) {
    super(cause);
  }

  public ClassTransformException(ErrorType errorType, Throwable cause) {
    super(errorType, cause);
  }

  public ClassTransformException(String message,
      ErrorDTO errorDTO) {
    super(message, errorDTO);
  }

  public ClassTransformException(String message, Throwable cause) {
    super(message, cause);
  }

  public ClassTransformException(String message) {
    super(message);
  }

  public ClassTransformException(String propertyName, String message) {
    super(propertyName, message);
  }

  public ClassTransformException(String propertyName, ErrorType errorType) {
    super(propertyName, errorType);
  }

  public ClassTransformException(ErrorType errorType, String addedMessage) {
    super(errorType, addedMessage);
  }
}
