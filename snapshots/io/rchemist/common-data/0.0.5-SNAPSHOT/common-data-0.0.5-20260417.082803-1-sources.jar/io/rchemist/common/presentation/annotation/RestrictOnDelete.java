/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface RestrictOnDelete {

  /**
   * fully qualified class name
   * ex) io.rchemist.crm.reward.domain.RewardImpl
   * @return
   */
  String entityClassName() default "";

  /**
   * 이 엔티티가 참조된 클래스 내에서 이 엔티티를 지정한 propertyName
   *
   * ex) reward
   * @return
   */
  String property() default "";

  /**
   * 이 값이 true 면 엔티티 삭제는 불가능하고 active = false 만 가능하다.
   * 단, 이 옵션은 SoftDelete 를 구현한 엔티티 클래스에서만 유효하다.
   * @return
   */
  boolean preventDelete() default false;

}
