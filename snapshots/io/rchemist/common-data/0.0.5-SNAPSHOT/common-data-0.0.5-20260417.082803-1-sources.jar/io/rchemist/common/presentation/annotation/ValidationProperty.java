/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface ValidationProperty {

  String ERROR_MESSAGE = "errorMessage";

  String name();

  String[] value() default {};

  /**
   * Configuration 에 여러가지 정보를 한번에 넘겨줘야 한다면 이 값을 사용한다.
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * 등록 시점에만 동작하게 할 것인지(이 값이 true 면 업데이트 때는 해당 필드의 밸리데이션을 하지 않는다)
   * @return
   */
  boolean addOnly() default false;

  /**
   * 이전에 설정된 모든 밸리데이션을 제거할 것인지 여부
   * @return
   */
  boolean forceRemoveAllPreviously() default false;

  /**
   * 같은 이름으로 설정된 Validation 정보가 있을 때(오버라이드 됐을 때) 값을 오버라이드할 것인지, 유지할 것인지 여부
   * @return
   */
  boolean override() default true;

}
