/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.type;

import com.fasterxml.jackson.annotation.JsonCreator;
import io.rchemist.common.util.StringUtil;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum QueryConditionType {
  EQUAL(QueryParserType.EQUAL, true, false),
  NOT_EQUAL(QueryParserType.EQUAL, true, true),
  EQUAL_IGNORECASE(QueryParserType.EQUAL, true, false),
  NOT_EQUAL_IGNORECASE(QueryParserType.EQUAL, true, false),
  IN(QueryParserType.COLLECTION, true, false, true),
  NOT_IN(QueryParserType.COLLECTION, true, true, true),
  NULL(QueryParserType.NULL, false, false, false, true),
  NOT_NULL(QueryParserType.NULL, false, true, false, true),
  LIKE(QueryParserType.LIKE, false, false),
  NOT_LIKE(QueryParserType.LIKE, false, true),
  START_WITH(QueryParserType.LIKE, false, false),
  NOT_START_WITH(QueryParserType.LIKE, false, true),
  END_WITH(QueryParserType.LIKE, false, false),
  NOT_END_WITH(QueryParserType.LIKE, false, true),
  LESS_THAN(QueryParserType.COMPARE, false, false),
  LESS_THAN_EQUAL(QueryParserType.COMPARE, false, false),
  GREATER(QueryParserType.COMPARE, false, false),
  GREATER_THAN_EQUAL(QueryParserType.COMPARE, false, false),
  NOT_LESS_THAN(QueryParserType.COMPARE, false, true),
  NOT_LESS_THAN_EQUAL(QueryParserType.COMPARE, false, true),
  NOT_GREATER(QueryParserType.COMPARE, false, true),
  NOT_GREATER_THAN_EQUAL(QueryParserType.COMPARE, false, true),
  BETWEEN(QueryParserType.COLLECTION, false, false, true),
  NOT_BETWEEN(QueryParserType.COLLECTION, false, true, true),
  ID_EQUAL(QueryParserType.EQUAL, true, false);

  @Getter
  private final boolean mergeable;   // 조건이 하나로 합쳐질 수 있는 경우 - EQUALS, NOT_EQUALS 는 IN, NOT_IN 으로 합쳐질 수 있다.

  @Getter
  private final boolean negative;

  @Getter
  private boolean listCondition;

  @Getter
  private final QueryParserType parserType;

  @Getter
  private final boolean noValue;

  QueryConditionType(QueryParserType queryParserType, boolean mergeable, boolean negative) {
    this(queryParserType, mergeable, negative, false, false);
  }

  QueryConditionType(QueryParserType queryParserType, boolean mergeable, boolean negative, boolean listCondition) {
    this(queryParserType, mergeable, negative, listCondition, false);
  }

  QueryConditionType(QueryParserType queryParserType, boolean mergeable, boolean negative, boolean listCondition, boolean noValue) {
    this.parserType = queryParserType;
    this.mergeable = mergeable;
    this.negative = negative;
    this.listCondition = listCondition;
    this.noValue = noValue;
  }

  public static QueryConditionType getInstance(String condition){
    condition = StringUtil.toString(condition, "equal").toUpperCase();
    return QueryConditionType.valueOf(condition);
  }

  @JsonCreator
  public static QueryConditionType from(String value) {
    try {
      return QueryConditionType.valueOf(value.toUpperCase());
    } catch (IllegalArgumentException e) {
      return QueryConditionType.EQUAL;
    }
  }

}
