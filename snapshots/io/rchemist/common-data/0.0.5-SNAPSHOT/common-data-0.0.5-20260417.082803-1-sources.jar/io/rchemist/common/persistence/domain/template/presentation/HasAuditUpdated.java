/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.time.Instant;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAuditUpdated<T> extends ClassTransformTarget {

  default Instant getUpdatedAt() {
    throw new ClassTransformException();
  }

  default void setUpdatedAt(Instant dateUpdated) {
    throw new ClassTransformException();
  }

  default String getUpdatedBy() {
    throw new ClassTransformException();
  }

  default void setUpdatedBy(String createdBy) {
    throw new ClassTransformException();
  }

  default T withUpdatedAt(Instant updatedAt){
    setUpdatedAt(updatedAt);
    return (T) this;
  }

  default T withUpdatedBy(String updatedBy){
    setUpdatedBy(updatedBy);
    return (T) this;
  }

}
