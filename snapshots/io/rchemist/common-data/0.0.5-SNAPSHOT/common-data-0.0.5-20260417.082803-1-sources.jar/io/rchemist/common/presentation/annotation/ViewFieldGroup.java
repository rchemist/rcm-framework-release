/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.GroupEnumType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface ViewFieldGroup {

  /**
   * 기본적으로 type 으로 처리하고, id, name, order 는 오버라이드 한다.
   */
  GroupEnumType type() default GroupEnumType.GENERAL;

  /**
   * HTML ID
   * 영문/숫자/_ 만 입력 가능
   * @return
   */
  String id() default "";

  /**
   * 필드를 그룹으로 묶어 표시할 때 그룹의 이름
   * @return
   */
  String name() default "";

  /**
   * 필드 그룹의 설명 문구
   * @return
   */
  String helpText() default "";

  /**
   * 필드 그룹의 설명 문구
   * @return
   */
  String tooltip() default "";

  /**
   * 필드 그룹 노출 순서
   * @return
   */
  int order() default -9999;

  /**
   * 필드 그룹 복제 가능 여부
   * @return
   */
  boolean reproduce() default false;

  boolean overridden() default false;

}
