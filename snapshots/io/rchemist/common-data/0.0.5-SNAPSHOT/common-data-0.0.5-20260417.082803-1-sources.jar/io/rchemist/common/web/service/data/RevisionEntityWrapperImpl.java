/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.data;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(RevisionEntityWrapper.class)
@Getter
@Setter
public class RevisionEntityWrapperImpl implements EnhancedTemplate {

  // Front 에서 대상 entityName 을 지정할 수 있다.
  // 동일한 Entity 에도 여러 메뉴에서 수정/삭제를 진행할 수 있다.
  // 따라서 Entity Class 별로 Revision 을 지정하는 것이 아니라, Front 에서 어떤 메뉴를 통해 수정/삭제가 이뤄졌는지 확인하는 것이 필요하다.
  // Admin UI Framework 에서 create 를 할 때 현재의 router path 를 entityName 으로 함께 전달하면 쉽게 해결할 수 있다.
  protected String revisionEntityName;

}
