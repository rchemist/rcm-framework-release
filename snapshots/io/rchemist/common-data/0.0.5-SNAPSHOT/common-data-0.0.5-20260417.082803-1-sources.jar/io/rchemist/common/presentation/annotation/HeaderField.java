/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface HeaderField {

  /**
   * 필드를 리스트그리드의 헤더 필드로 표시할지 여부
   * @return
   */
  boolean showGrid() default true;

  /**
   * 이 필드가 목록에 표시될 때 몇번째 순서에 표시될지 여부
   * 숫자가 낮을 수록 앞에, 숫자가 같으면 order() 값을 따지고 그 값도 같으면 name() 으로 정렬한다.
   * @return
   */
  int order() default 999;

  /**
   * 정렬 가능 여부
   * @return
   */
  boolean sortable() default true;

  /**
   * 검색 가능 여부
   * @return
   */
  boolean searchable() default true;

  /**
   * 툴팁 표시할 메시지
   * @return
   */
  String tooltip() default "";

  boolean useFilterAsString() default false;

  boolean overridden() default false;

}
