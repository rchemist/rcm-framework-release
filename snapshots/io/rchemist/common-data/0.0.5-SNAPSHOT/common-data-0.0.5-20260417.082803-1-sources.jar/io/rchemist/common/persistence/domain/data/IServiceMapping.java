/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface IServiceMapping<T> {

  default String getServiceId(){
    throw new ClassTransformException();
  }

  default void setServiceId(String serviceId){
    throw new ClassTransformException();
  }

  default String getServiceAlias() {throw new ClassTransformException();}
  default void setServiceAlias(String serviceAlias){
    throw new ClassTransformException();
  }

  default String getServiceEntityId(){
    throw new ClassTransformException();
  }

  default void setServiceEntityId(String serviceEntityId){
    throw new ClassTransformException();
  }

  default String getParentServiceEntityId() {
    throw new ClassTransformException();
  }

  default void setParentServiceEntityId(String parentServiceEntityId){
    throw new ClassTransformException();
  }

  default String getServiceEntityKey(){
    return getServiceId() + "_" + getServiceEntityId();
  }

  default T withServiceId(String serviceId){
    setServiceId(serviceId);
    return (T) this;
  }

  default T withServiceEntityId(String serviceEntityId){
    setServiceEntityId(serviceEntityId);
    return (T) this;
  }

  default T withServiceAlias(String serviceAlias){
    setServiceAlias(serviceAlias);
    return (T) this;
  }

  default T withServiceIdentifier(ServiceIdentifier identifier){
    setServiceIdentifier(identifier);
    return (T) this;
  }

  default T withParentServiceEntityId(String parentServiceEntityId){
    setParentServiceEntityId(parentServiceEntityId);
    return (T) this;
  }

  default void setServiceIdentifier(ServiceIdentifier identifier){
    setServiceId(identifier.getServiceId());
    setServiceAlias(identifier.getServiceAlias());
    setServiceEntityId(identifier.getServiceEntityId());
    setParentServiceEntityId(identifier.getParentServiceEntityId());
  }

  default ServiceIdentifier getServiceIdentifier(){
    return ServiceIdentifier.create(getServiceId(), getServiceEntityId(), getServiceAlias(), getParentServiceEntityId());
  }

}
