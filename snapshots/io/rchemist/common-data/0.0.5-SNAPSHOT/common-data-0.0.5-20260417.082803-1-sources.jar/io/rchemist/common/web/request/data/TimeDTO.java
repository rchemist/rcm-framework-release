/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TimeDTO implements Serializable {

  private LocalDateTime localDateTime;

  private Integer hour;

  private Integer dayOfWeek;

  private Integer month;

  private Integer dayOfMonth;

  private Integer minute;

  public TimeDTO() {
    localDateTime = LocalDateTime.now();
  }

  public TimeDTO(LocalDateTime localDateTime) {
    this.localDateTime = localDateTime;
  }

  public TimeDTO(ZoneId zoneId){
    if(zoneId == null){
      this.localDateTime = LocalDateTime.now();
    }else{
      this.localDateTime = ZonedDateTime.of(LocalDateTime.now(), zoneId).toLocalDateTime();
    }
  }

}
