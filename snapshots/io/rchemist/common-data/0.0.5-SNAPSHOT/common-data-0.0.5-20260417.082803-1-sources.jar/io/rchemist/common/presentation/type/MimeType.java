/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum MimeType {

  XLS("application/vnd.ms-excel", "xls"),
  XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"),
  CSV("text/csv", "csv"),
  PDF("application/pdf", "pdf"),
  DOC("application/msword", "doc"),
  DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx"),
  PPT("application/vnd.ms-powerpoint", "ppt"),
  PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx"),
  AVI("video/x-msvideo", "avi"),
  MPEG("video/mpeg", "mpeg"),
  OGV("video/ogg", "ogv"),
  MPEG_4("video/mp4", "mp4"),
  IPHONE_INDEX("application/x-mpegURL", "m3u8"),
  IPHONE_SEGMENT("video/MP2T", "ts"),
  VIDEO_3GP("video/3gpp", "3gp"),
  VIDEO_3G2("video/3gpp2", "3gp"),
  MOV("video/quicktime", "mov"),
  WMV("video/x-ms-wmv", "wmv"),
  WEBM("video/webm", "webm"),
  JPG("image/jpeg", "jpg"),
  JPEG("image/jpeg", "jpeg"),
  GIF("image/gif", "gif"),
  PNG("image/png", "png"),
  BMP("image/bmp", "bmp"),
  WEBP("image/webp", "webp"),
  TIF("image/tiff", "tif"),
  TIFF("image/tiff", "tiff"),
  ICO("image/x-icon", "ico"),
  SVG("image/svg+xml", "svg"),
  CSS("text/css", "css"),
  HTM("text/html", "htm"),
  HTML("text/html", "html"),
  XHTML("application/xhtml+xml", "xhtml"),
  XML("application/xml", "xml"),
  ZIP("application/zip", "zip"),
  TAR("application/x-tar", "tar"),
  RAR("application/x-rar-compressed", "rar"),
  ZIP7("application/x-7z-compressed", "7z"),
  JS("application/js", "js"),
  JSON("application/json", "json"),
  AAC("audio/aac", "aac"),
  MID("audio/midi", "mid"),
  MIDI("audio/midi", "midi"),
  OGA("audio/ogg", "ogg"),
  WAV("audio/x-wav", "wav"),
  WEBA("audio/webm", "weba"),
  ARC("application/octet-stream", "arc"),
  AUDIO_3GP("audio/3gpp", "3gp"),
  AUDIO_3G2("audio/3gpp2", "3g2");

  MimeType(String applicationType, String suffix) {
    this.applicationType = applicationType;
    this.suffix = suffix;
  }
  
  @Getter
  private String applicationType;

  @Getter
  private String suffix;

}