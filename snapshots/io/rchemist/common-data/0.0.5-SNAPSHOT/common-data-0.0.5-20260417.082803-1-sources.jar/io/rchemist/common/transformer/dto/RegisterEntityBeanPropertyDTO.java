/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import lombok.Getter;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
@Getter
public class RegisterEntityBeanPropertyDTO {

  private String name;

  private String propertyType;

  private Class<?> propertyClass;

  private String propertyJoinAlias;   // OneToMany Join Alias

  private Class<?> propertyJoinClass;   // OneToMany Join Class

  private Boolean indexField;   // hibernate Search index field 여부

  public boolean isIndexField() {
    return BooleanUtils.toBoolean(indexField);
  }

  public RegisterEntityBeanPropertyDTO(String name, String propertyType, Class<?> propertyClass, Boolean indexField) {
    this.name = name;
    this.propertyType = propertyType;
    this.propertyClass = propertyClass;
    this.indexField = indexField;
  }

  public RegisterEntityBeanPropertyDTO(String name, String propertyType, Class<?> propertyClass, String propertyJoinAlias, Class<?> propertyJoinClass, Boolean indexField) {
    this.name = name;
    this.propertyType = propertyType;
    this.propertyClass = propertyClass;
    this.propertyJoinAlias = propertyJoinAlias;
    this.propertyJoinClass = propertyJoinClass;
    this.indexField = indexField;
  }

}
