/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.dto;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import java.io.Serializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.ArrayUtils;

/**
 * 
 * @author kunner
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class SearchField implements Serializable{

	public SearchField(String name, QueryConditionType condition, String... values){
		this.name = name;
		this.condition = condition;
		this.values = values;
	}

	public static final String FIELD_PREFIX = "_search";		// 검색 인자로 사용되는 request field name의 접두사
	public static final String VALUE_PREFIX = "_find";		// 검색 인자로 사용되는 request field name의 접두사
	public static final String CONDITION_PREFIX = "_condition";		// 검색 인자로 사용되는 request field name의 접두사
	public static final String VALUE_SEPARATOR = "||";	// 범위값 등의 처리를 위해  

	protected String name;

	protected QueryConditionType condition;

	protected String[] values;		// 복수로 지정된 값은 String[] 로 처리

	public SearchField addValues(String... addedValues){
		if(ArrayUtils.isNotEmpty(values)){
			this.values = ArrayUtils.addAll(values, addedValues);
		}else{
			this.values = addedValues;
		}

		return this;
	}

	public String getValue(){
		if(ArrayUtils.isEmpty(values)){
			return null;
		}
		return values[0];
	}

}
