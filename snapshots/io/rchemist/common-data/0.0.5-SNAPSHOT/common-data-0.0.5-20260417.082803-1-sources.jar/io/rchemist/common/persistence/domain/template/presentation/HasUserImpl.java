/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.ReferenceFieldView;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.type.SiteType;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasUser.class)
@Getter
@Setter
public class HasUserImpl implements EnhancedTemplate {

  @AdminField(name = "UserMappingImpl_UserId", hidden = true
      , fieldType = PresentationFieldType.FOREIGN_KEY
      , referenceField = @ReferenceFieldView(foreignKeyClass = "io.rchemist.common.user.domain.User"
      , displayProperty = "loginName")
      , order = 400, modifiableType = ModifiableType.MODIFY_ONLY)
  protected String userId;

  @AdminField(name = "UserMappingImpl_UserName",
      //headerField = @HeaderField(order = 400),
      order = 400,
      modifiableType = ModifiableType.MODIFY_ONLY,
      fieldType = PresentationFieldType.FOREIGN_KEY,
      referenceField = @ReferenceFieldView(foreignKeyClass = "io.rchemist.common.user.domain.User", valueProperty = "userId"),
      readOnly = true)
  protected String userName;

  @AdminField(name = "User_LoginName", hidden = true
      , fieldType = PresentationFieldType.FOREIGN_KEY
      , referenceField = @ReferenceFieldView(foreignKeyClass = "io.rchemist.common.user.domain.User"
      , displayProperty = "loginName", valueProperty = "userId")
      , order = 400, modifiableType = ModifiableType.MODIFY_ONLY)
  protected String loginName;

  protected SiteType userSiteType;

  public void setUser(UserProfile user){
    if(user != null){
      this.userId = user.getId();
      this.userName = user.getName();
      this.userSiteType = user.getSiteType();
      this.loginName = user.getLoginName();
    }else{
      this.userId = null;
      this.userName = null;
      this.userSiteType = null;
      this.loginName = null;
    }
  }

}
