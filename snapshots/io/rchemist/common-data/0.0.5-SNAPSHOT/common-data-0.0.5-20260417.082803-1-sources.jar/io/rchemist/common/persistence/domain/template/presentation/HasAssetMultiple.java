/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAssetMultiple<T> extends ClassTransformTarget {

  default List<AttachAsset> getAssets(){
    throw new ClassTransformException();
  }

  default void setAssets(List<AttachAsset> assets){
    throw new ClassTransformException();
  }

  default T addAsset(AttachAsset asset){
    getAssets().add(asset);
    return (T) this;
  }

  default T withAssets(List<AttachAsset> assets){
    setAssets(assets);
    return (T) this;
  }

}
