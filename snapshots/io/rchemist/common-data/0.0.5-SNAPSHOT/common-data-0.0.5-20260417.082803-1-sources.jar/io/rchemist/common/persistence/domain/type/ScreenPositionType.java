/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * <p>
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * </p>
 **/
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ScreenPositionType extends EnumType<ScreenPositionType> {
  public static final ScreenPositionType TOP_RIBBON = new ScreenPositionType(100, "TOP_RIBBON", "Top Ribbon", "화면 상단 띠배너", "global.type.screen.position.type.top.ribbon");
  public static final ScreenPositionType TOP_LEFT = new ScreenPositionType(200, "TOP_LEFT", "Top left", "화면 좌측 상단", "global.type.screen.position.type.top.left");
  public static final ScreenPositionType TOP_CENTER = new ScreenPositionType(300, "TOP_CENTER", "Top center", "화면 상단 중앙", "global.type.screen.position.type.top.center");
  public static final ScreenPositionType TOP_RIGHT = new ScreenPositionType(400, "TOP_RIGHT", "Top right", "화면 우측 상단", "global.type.screen.position.type.top.right");
  public static final ScreenPositionType BOTTOM_RIBBON = new ScreenPositionType(500, "BOTTOM_RIBBON", "Bottom Ribbon", "화면 하단 띠배너", "global.type.screen.position.type.bottom.ribbon");
  public static final ScreenPositionType BOTTOM_LEFT = new ScreenPositionType(600, "BOTTOM_LEFT", "Bottom left", "화면 좌측 하단", "global.type.screen.position.type.bottom.left");
  public static final ScreenPositionType BOTTOM_CENTER = new ScreenPositionType(700, "BOTTOM_CENTER", "Bottom center", "화면 하단 중앙", "global.type.screen.position.type.bottom.center");
  public static final ScreenPositionType BOTTOM_RIGHT = new ScreenPositionType(800, "BOTTOM_RIGHT", "Bottom right", "화면 우측 하단", "global.type.screen.position.type.bottom.right");
  public static final ScreenPositionType CENTER = new ScreenPositionType(900, "CENTER", "Center", "화면 정중앙", "global.type.screen.position.type.center");
  public static final ScreenPositionType UNDEFINED = new ScreenPositionType(Integer.MAX_VALUE, "UNDEFINED", "Undefined", "설정 안 함", "global.type.screen.position.type.undefined");

  public ScreenPositionType(int order, String type, String friendlyType, String description,
      String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }
}
