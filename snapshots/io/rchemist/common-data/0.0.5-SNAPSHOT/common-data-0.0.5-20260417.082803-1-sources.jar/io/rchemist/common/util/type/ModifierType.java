/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.money.Money;
import java.math.BigDecimal;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ModifierType extends EnumType<ModifierType> {

  public static final ModifierType PERCENTAGE_SUBTRACTION = new ModifierType(100, "PERCENTAGE_SUBTRACTION", "Percentage subtraction", "비율 할인", "global.type.modifier.type.percentage.subtraction");
  public static final ModifierType PERCENTAGE = new ModifierType(200, "PERCENTAGE", "Percentage", "비율", "global.type.modifier.type.percentage");
  public static final ModifierType ADDITION = new ModifierType(300, "ADDITION", "Addition", "더하기", "global.type.modifier.type.addition");
  public static final ModifierType SUBTRACTION = new ModifierType(400, "SUBTRACTION", "Subtraction", "빼기", "global.type.modifier.type.subtraction");

  public ModifierType(int order, String type, String friendlyType, String description, String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }

  /**
   * ModifierType 을 이용한 금액 계산 - BigDecimal 호환
   * @param price
   * @param modifierValue
   * @return
   */
  public Money calculate(Money price, Number modifierValue){

    if(modifierValue == null)
      return price;

    Money modifier;

    if(modifierValue instanceof BigDecimal){
      modifier = new Money((BigDecimal) modifierValue, price.getCurrency());
    }else if(modifierValue instanceof Double){
      modifier = new Money((Double) modifierValue, price.getCurrency());
    }else if(modifierValue instanceof Integer) {
      modifier = new Money((Integer) modifierValue, price.getCurrency());
    }else if(modifierValue instanceof Long){
      modifier = new Money((Long) modifierValue, price.getCurrency());
    }else{
      modifier = new Money(modifierValue.intValue(), price.getCurrency());
    }

    return calculateResult(price, modifier);

  }

  public Money calculateResult(Money price, Money modifier) {
    /**
     * 비율 할인 0~100 까지 % 를 계산 후 원래 가격에서 차감
     */
    if(getType().equals(ModifierType.PERCENTAGE_SUBTRACTION.getType())){
      if(modifier.lessThan(BigDecimal.ZERO))
        modifier = Money.zero();

      // 원래 가격의 0% 라는 것은 그냥 0 원이라는 것
      if(modifier.isZero())
        return Money.zero();

      return price.subtract(price.multiply(modifier.getAmount()).divide(100));
    }else if(getType().equals(ModifierType.PERCENTAGE.getType())){
      /**
       * 가격에 비례한 결과값
       *
       * 150 이 입력되면 1.5 배
       */
      return price.multiply(modifier.getAmount()).divide(100);
    }else if(getType().equals(ModifierType.ADDITION.getType())){
      /**
       * 정액 더하기
       */
      return price.add(new Money(modifier.getAmount(), price.getCurrency()));
    }else {
      /**
       * 정액 차감. 단, 0 이하이면 0 리턴
       */
      Money amount =  price.subtract(new Money(modifier.getAmount(), price.getCurrency()));
      return (amount.lessThan(Money.ZERO)) ? Money.zero() : amount;
    }
  }

}
