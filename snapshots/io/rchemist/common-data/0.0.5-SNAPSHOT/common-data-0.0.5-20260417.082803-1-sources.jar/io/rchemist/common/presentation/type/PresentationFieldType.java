/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum PresentationFieldType {

  ID(JavaFieldType.LONG, DataManageType.NOT_SUPPORT),
  BOOLEAN(JavaFieldType.BOOLEAN, DataManageType.ALL),
  DATE(JavaFieldType.DATE, DataManageType.ALL),               // html5 input type=date 연월일    2021-01-01  YYYY-MM-DD
  TIME(JavaFieldType.TIME, DataManageType.ALL),               // html5 input type=time 시분 12:00       HH:MM
  DATETIME(JavaFieldType.LOCAL_DATE_TIME, DataManageType.ALL),     // html5 input type=datetime_local LocalDateTime 연월일시분초     yyyy-MM-dd'T'HH:mm:ss

  // TODO 날짜 관련 세부 형식은 추후 지원한다.
  YEAR_MONTH(JavaFieldType.STRING, DataManageType.ALL, false),              // html5 input type=month 연월    2021-01     YYYY-MM
  // MONTH_DAY(JavaFieldType.STRING),              // input type=text 월일    01-01     MM-DD
  // DATE_RANGE(JavaFieldType.STRING),              // yyyy-MM-dd ~ yyyy-MM-dd
  // DATE_TIME_RANGE(JavaFieldType.STRING),              // yyyy-MM-dd'T'HH:mm:ss ~ yyyy-MM-dd'T'HH:mm:ss
  // TIME_RANGE(JavaFieldType.STRING),              // HH:mm ~ HH:mm

  INTEGER(JavaFieldType.INTEGER, DataManageType.ALL),
  LONG(JavaFieldType.LONG, DataManageType.ALL),
  DECIMAL(JavaFieldType.BIG_DECIMAL, DataManageType.ALL),
  STRING(JavaFieldType.STRING, DataManageType.ALL),
  PASSWORD(JavaFieldType.STRING, DataManageType.NOT_SUPPORT),
  PASSWORD_CONFIRM(JavaFieldType.STRING, DataManageType.NOT_SUPPORT),
  EMAIL(JavaFieldType.STRING, DataManageType.ALL),
  FOREIGN_KEY(JavaFieldType.UNKNOWN, DataManageType.EXPORT_ONLY),
  MONEY(JavaFieldType.BIG_DECIMAL, DataManageType.ALL),
  ENUMERATION(JavaFieldType.STRING, DataManageType.ALL, true, false, true),
  ENUMERATION_MULTIPLE(JavaFieldType.STRING, DataManageType.ALL, true, false, true),
  IMAGE(JavaFieldType.STRING, DataManageType.ALL,false),
  UPLOAD(JavaFieldType.STRING, DataManageType.ALL,false),
  UPLOAD_MULTIPLE(JavaFieldType.STRING, DataManageType.NOT_SUPPORT,false),
  TEXT(JavaFieldType.STRING, DataManageType.ALL, true, true),
  HTML(JavaFieldType.STRING, DataManageType.ALL, true, true),
  BLOCK(JavaFieldType.STRING, DataManageType.ALL, true, true),
  SOURCE_CODE(JavaFieldType.STRING, DataManageType.ALL, true, true),
  STRING_LIST(JavaFieldType.STRING, DataManageType.ALL, false, false),
  COLLECTION(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false),
  HTML_BAR_CHART(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false),    // 차트를 보여 주기 위한 전용 타입
  BAR_CHART(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false),    // 차트를 보여 주기 위한 전용 타입
  LINE_CHART(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false),    // line 차트를 보여 주기 위한 전용 타입
  PIE_CHART(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false),    // pie 차트를 보여 주기 위한 전용 타입
  SURVEY_GROUP(JavaFieldType.OTHER, DataManageType.EXPORT_ONLY, false),   // 설문 조사를 처리하기 위한 전용 타입
  SURVEY_RESULT(JavaFieldType.OTHER, DataManageType.EXPORT_ONLY, false),   // 설문 조사를 처리하기 위한 전용 타입
  INLINE_MAP(JavaFieldType.OTHER, DataManageType.ALL, false, false),     // attribute 와 같은 key value 맵이다.
  COMPONENT(JavaFieldType.OTHER, DataManageType.NOT_SUPPORT, false, false), // component 를 직접 제어할 때 사용한다
  NOT_AVAILABLE(JavaFieldType.UNKNOWN, DataManageType.NOT_SUPPORT, false)   // override metadata 에서 null value 를 위해 추가
  ;


  @Getter
  private final boolean basicField;

  @Getter
  private final JavaFieldType javaFieldType;

  @Getter
  private final boolean longtext;

  @Getter
  private final boolean enumeration;

  @Getter
  private DataManageType dataManageType = DataManageType.NOT_SUPPORT;

  public boolean isSearchable(){
    return isBasicField() && javaFieldType.isSearchable();
  }

  public boolean isSortable(){
    return isBasicField() && javaFieldType.isSortable();
  }

  PresentationFieldType(JavaFieldType javaFieldType, DataManageType dataManageType, boolean isBasicField, boolean longtext, boolean enumeration){
    this.basicField = isBasicField;
    this.javaFieldType = javaFieldType;
    this.longtext = longtext;
    this.enumeration = enumeration;
    this.dataManageType = dataManageType;
  }

  PresentationFieldType(JavaFieldType javaFieldType, DataManageType dataManageType, boolean isBasicField, boolean longtext){
    this.basicField = isBasicField;
    this.javaFieldType = javaFieldType;
    this.longtext = longtext;
    this.enumeration = false;
    this.dataManageType = dataManageType;
  }

  PresentationFieldType(JavaFieldType javaFieldType, DataManageType dataManageType, boolean isBasicField){
    this.basicField = isBasicField;
    this.javaFieldType = javaFieldType;
    this.longtext = false;
    this.enumeration = false;
    this.dataManageType = dataManageType;
  }

  PresentationFieldType(JavaFieldType javaFieldType, DataManageType dataManageType){
    this.basicField = true;
    this.javaFieldType = javaFieldType;
    this.longtext = false;
    this.enumeration = false;
    this.dataManageType = dataManageType;
  }

}
