/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.type.ModifierType;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ModifierValueDTO implements Serializable {

  public ModifierValueDTO(ModifierType modifierType, BigDecimal difference) {
    this.modifierType = modifierType;
    this.difference = difference;
  }

  protected ModifierType modifierType;
  protected BigDecimal difference;

  public Money calculateResult(Money amount){
    return modifierType.calculate(amount, difference);
  }

}
