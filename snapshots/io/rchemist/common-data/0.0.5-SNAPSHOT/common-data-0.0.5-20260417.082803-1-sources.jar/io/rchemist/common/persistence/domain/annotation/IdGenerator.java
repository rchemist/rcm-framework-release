/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * IdGeneratorClassTransformer 를 이용해 다음과 같은 코드를 자동 생성한다
 *
 * @GeneratedValue(generator = prefix + "Id", strategy=GenerationType.TABLE)
 * @TableGenerator(name = prefix + "Id",table = "SEQUENCE_GENERATOR")
 * @Column(name = columnName)
 *
 *
 **/
public @interface IdGenerator {

  /**
   * sequence-generator name
   * @return
   */
  String value() default "";

  /**
   * @Column 을 별도로 정의하지 않았을 때 @Column 에 들어갈 name
   * @return
   */
  String columnName() default "";

  /**
   * 별도의 시퀀스 관리 테이블을 만들 것인지, 아니면 hibernate_sequence 에서 통합 관리할 것인지
   * 만약 ID 필드가 String 이라면 uuid 로 처리하며, 이 값은 무조건 false 가 된다.
   * @return
   */
  boolean separate() default true;

  /**
   * 별도의 시퀀스 관리 테이블을 만들겠다고 할 때 테이블 이름을 자동으로 만들 것인지, 정해진 이름을 사용할 것인지
   * 만약 ID 필드가 String 이라면 uuid 로 처리하며, 이 값은 무조건 false 가 된다.
   * @return
   */
  String separateIdTable() default "";

  /**
   * SequenceGenerator 를 사용할 때 기본 increment value
   * ID 필드가 String 일 때는 무시하며, 입력하지 않으면 100 을 기본으로 한다.
   * @return
   */
  int increment() default 100;

}
