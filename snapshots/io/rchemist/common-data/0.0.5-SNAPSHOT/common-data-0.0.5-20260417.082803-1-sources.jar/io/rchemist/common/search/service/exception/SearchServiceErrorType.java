/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
public class SearchServiceErrorType extends EnumType<SearchServiceErrorType> implements ErrorType {

  public static final SearchServiceErrorType ENTITY_NOT_FOUND = new SearchServiceErrorType("ENTITY_NOT_FOUND", "Entity is not founded", "엔티티가 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final SearchServiceErrorType FIELD_NOT_FOUND = new SearchServiceErrorType("FIELD_NOT_FOUND", "Field is not founded", "필드가 존재하지 않습니다.", HttpStatus.BAD_REQUEST);
  public static final SearchServiceErrorType INVALID_CONDITION_OPERATOR_TYPE = new SearchServiceErrorType("INVALID_CONDITION_OPERATOR_TYPE", "ConditionOperatorType is invalid ", "컨디션 유형은 AND, OR, INHERITED 로만 입력할 수 있습니다.", HttpStatus.BAD_REQUEST);

  @Getter
  private final int status;

  public SearchServiceErrorType(String type, String friendlyType, String description, HttpStatus status) {
    super(type, friendlyType, description);
    this.status = status.value();
  }

  private SearchServiceErrorType() {
    this.status = 500;
  }

}
