/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.criteria.JoinType;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Sort.Direction;

/**
 * 정렬 항목을 나타내는 클래스
 * fieldName과 SortInfo의 쌍을 저장하며, 동일 필드에 대한 다중 정렬을 지원한다.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SortEntry {

    /**
     * 정렬 대상 필드 이름 (예: "subject.type", "createdAt")
     */
    private String fieldName;

    /**
     * 정렬 정보 (NormalSortInfo 또는 PrioritySortInfo)
     */
    private SortInfo sortInfo;

    /**
     * SortEntry 생성을 위한 정적 팩토리 메서드
     */
    public static SortEntry of(String fieldName, SortInfo sortInfo) {
        return new SortEntry(fieldName, sortInfo);
    }

    /**
     * 일반 정렬 SortEntry 생성
     */
    public static SortEntry normal(String fieldName, Direction direction) {
        return new SortEntry(fieldName, new NormalSortInfo(direction));
    }

    /**
     * 일반 정렬 SortEntry 생성 (JOIN 타입 포함)
     */
    public static SortEntry normal(String fieldName, Direction direction, JoinType joinType) {
        return new SortEntry(fieldName, new NormalSortInfo(direction, joinType));
    }

    /**
     * 우선순위 정렬 SortEntry 생성
     */
    public static SortEntry priority(String fieldName, Object priorityValue, Direction direction) {
        return new SortEntry(fieldName, new PrioritySortInfo(priorityValue, direction));
    }

    /**
     * 우선순위 정렬 SortEntry 생성 (JOIN 타입 포함)
     */
    public static SortEntry priority(String fieldName, Object priorityValue, Direction direction, JoinType joinType) {
        return new SortEntry(fieldName, new PrioritySortInfo(priorityValue, direction, joinType));
    }

    /**
     * JSON 역직렬화를 위한 팩토리 메서드
     */
    @JsonCreator
    public static SortEntry fromJson(
            @JsonProperty("fieldName") String fieldName,
            @JsonProperty("sortInfo") SortInfo sortInfo) {
        return new SortEntry(fieldName, sortInfo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SortEntry sortEntry = (SortEntry) o;
        return Objects.equals(fieldName, sortEntry.fieldName) &&
               Objects.equals(sortInfo, sortEntry.sortInfo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fieldName, sortInfo);
    }

    @Override
    public String toString() {
        if (sortInfo instanceof PrioritySortInfo) {
            PrioritySortInfo priority = (PrioritySortInfo) sortInfo;
            return String.format("%s[priority=%s, %s]",
                fieldName, priority.getPriorityValue(), sortInfo.getDirection());
        }
        return String.format("%s[%s]", fieldName, sortInfo.getDirection());
    }
}
