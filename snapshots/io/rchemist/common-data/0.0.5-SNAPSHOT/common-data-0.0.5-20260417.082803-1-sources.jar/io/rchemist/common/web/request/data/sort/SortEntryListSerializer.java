/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * List<SortEntry>를 직렬화하는 커스텀 Serializer
 *
 * 출력 형태 (배열):
 * [
 *   {
 *     "fieldName": "createdAt",
 *     "sortInfo": {
 *       "type": "normal",
 *       "direction": "DESC"
 *     }
 *   },
 *   {
 *     "fieldName": "subject.type",
 *     "sortInfo": {
 *       "type": "priority",
 *       "priorityValue": "MAJOR_MANDATORY",
 *       "direction": "DESC",
 *       "joinType": "LEFT"
 *     }
 *   }
 * ]
 */
@Slf4j
public class SortEntryListSerializer extends JsonSerializer<List<SortEntry>> {

    @Override
    public void serialize(List<SortEntry> value, JsonGenerator generator, SerializerProvider serializers)
            throws IOException {

        if (value == null) {
            generator.writeNull();
            return;
        }

        generator.writeStartArray();

        for (SortEntry entry : value) {
            generator.writeStartObject();

            // fieldName 필드 작성
            generator.writeStringField("fieldName", entry.getFieldName());

            // sortInfo 객체 작성
            SortInfo sortInfo = entry.getSortInfo();
            if (sortInfo != null) {
                generator.writeFieldName("sortInfo");
                serializeSortInfo(sortInfo, generator);
            }

            generator.writeEndObject();
        }

        generator.writeEndArray();
        log.debug("Serialized {} sort entries", value.size());
    }

    /**
     * SortInfo를 JSON 객체로 직렬화
     */
    private void serializeSortInfo(SortInfo sortInfo, JsonGenerator generator) throws IOException {
        generator.writeStartObject();

        // type 필드
        generator.writeStringField("type", sortInfo.getType());

        // direction 필드
        generator.writeStringField("direction", sortInfo.getDirection().name());

        if (sortInfo instanceof PrioritySortInfo) {
            // 우선순위 정렬 전용 필드
            PrioritySortInfo prioritySort = (PrioritySortInfo) sortInfo;
            generator.writeObjectField("priorityValue", prioritySort.getPriorityValue());
        }

        // joinType 필드 (옵션)
        if (sortInfo.getJoinType() != null) {
            generator.writeStringField("joinType", sortInfo.getJoinType().name());
        }

        // nullsFirst 필드 (옵션)
        if (sortInfo.getNullsFirst() != null) {
            generator.writeBooleanField("nullsFirst", sortInfo.getNullsFirst());
        }

        generator.writeEndObject();
    }
}
