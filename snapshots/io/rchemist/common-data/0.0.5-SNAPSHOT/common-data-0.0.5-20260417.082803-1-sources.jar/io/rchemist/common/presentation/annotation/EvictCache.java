/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface EvictCache {

  /**
   * 대상 캐시 리전 name
   * @return
   */
  String value();   // cache region name

  /**
   * ContextualCache 인지 여부
   * @return
   */
  boolean contextual() default false;

  /**
   * 해당 리전을 모두 삭제할 지 여부
   * 기본값은 false 로, 이 엔티티와 관련된 캐시만 삭제한다.
   * @return
   */
  boolean evictAll() default false;

  /**
   * 이 엔티티가 XREF 엔티티여서, 이 캐시를 지울 때 XREF 대상 프로퍼티의 캐시도 제거해야 하는 경우
   * @return
   */
  boolean xref() default false;

  /**
   * XREF 대상 엔티티의 property name
   * @return
   */
  boolean xrefParentProperty() default false;

}
