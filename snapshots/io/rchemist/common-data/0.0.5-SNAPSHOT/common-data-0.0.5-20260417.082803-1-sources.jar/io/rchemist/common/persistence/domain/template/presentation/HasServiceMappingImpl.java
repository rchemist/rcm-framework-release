/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasServiceMapping.class)
@Getter
@Setter
public class HasServiceMappingImpl implements EnhancedTemplate {

  @AdminField(name = "ServiceMapping_ServiceId", order = 100, fieldType = PresentationFieldType.STRING, group = @ViewFieldGroup(type = GroupEnumType.PROPERTY), hidden = true)
  protected String serviceId;

  @AdminField(name = "ServiceMapping_ServiceAlias", order = 200, fieldType = PresentationFieldType.STRING, group = @ViewFieldGroup(type = GroupEnumType.PROPERTY), hidden = true)
  protected String serviceAlias;

  @AdminField(name = "ServiceMapping_ServiceEntityId", order = 300, fieldType = PresentationFieldType.STRING, group = @ViewFieldGroup(type = GroupEnumType.PROPERTY), hidden = true)
  protected String serviceEntityId;

  protected String parentServiceEntityId;     // comment 에서만 사용하는 필드, GENERAL 게시판에는 없지만 ,Group.Board.Article.Comment 의 관계에서 특정 Group 의 모든 Comment 를 조회할 때 사용한다.

  public String getServiceId() {
    return StringUtils.defaultIfBlank(serviceId, HasServiceMapping.GENERAL_TYPE);
  }
}
