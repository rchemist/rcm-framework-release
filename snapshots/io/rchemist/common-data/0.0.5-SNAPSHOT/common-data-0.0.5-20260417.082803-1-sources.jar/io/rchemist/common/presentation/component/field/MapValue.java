/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.component.field;

import io.rchemist.common.persistence.domain.data.AttributeDTO;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MapValue implements Serializable {

  protected List<MapValueItem> values = new ArrayList<>();

  // 기존 입력된 값 중 제거된 값이 있다면 해당 정보
  protected Set<Long> deletedIds = new HashSet<>();

  public MapValue withValues(
      List<MapValueItem> values) {
    this.values = values;
    return this;
  }

  public MapValue addValues(MapValueItem... items){
    if(ArrayUtils.isNotEmpty(items)){
      this.values.addAll(Arrays.asList(items));
    }
    return this;
  }

  public MapValue withDeletedIds(Set<Long> deletedIds) {
    this.deletedIds = deletedIds;
    return this;
  }

  public List<MapValueItem> getValues() {
    // 입출력 순서를 보장하기 위함
    if(CollectionUtils.isNotEmpty(values)){
      Collections.sort(values, Comparator.comparing(MapValueItem::getPriority));
    }
    return values;
  }

  public MapValue addValues(AttributeDTO... attributes){
    if(ArrayUtils.isNotEmpty(attributes)){
      // 중복값이 있어도 상관 없다. MapField 에서 Validation 을 폼 서밋 단계에서 처리할 것이기 때문이다.
      for(AttributeDTO dto : attributes){
        MapValueItem item = MapValueItem.createByAttribute(dto);
        values.add(item);
      }
    }
    return this;
  }

  public boolean hasValue() {
    return CollectionUtils.isNotEmpty(values);
  }

  public int getValueCount(){
    return (hasValue()) ? values.size() : 0;
  }

  public Map<String, String> getSimpleAttributes(){
    if(CollectionUtils.isEmpty(values)){
      return new HashMap<>();
    }else{
      Map<String, String> values = new HashMap<>();

      for(MapValueItem item : this.values){
        values.put(item.getName(), item.getValue());
      }

      return values;
    }
  }

}
