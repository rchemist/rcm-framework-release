/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.data;

import io.rchemist.common.util.data.IdList;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class DeleteForm<ID> implements Serializable {

  public DeleteForm() {
  }

  public DeleteForm(ID id, String revisionEntityName) {
    this.id = id;
    this.revisionEntityName = revisionEntityName;
  }

  protected String revisionEntityName;

  protected ID id;

  protected String cause;

  protected List<ID> ids;

  public List<ID> getIds() {
    if (CollectionUtils.isEmpty(ids)) {
      ids = new ArrayList<>();
      if (id != null) {
        ids.add(id);
      }
      return ids;
    } else {
      return ids;
    }
  }

  public boolean isEmpty() {
    return getIds().isEmpty();
  }

  public DeleteForm<ID> withRevisionEntityName(String revisionEntityName) {
    this.revisionEntityName = revisionEntityName;
    return this;
  }

  public DeleteForm<ID> withId(ID id) {
    this.id = id;
    return this;
  }

  public DeleteForm<ID> withCause(String cause) {
    this.cause = cause;
    return this;
  }

  public DeleteForm<ID> withIds(List<ID> ids) {
    this.ids = ids;
    return this;
  }

  public DeleteForm<ID> addIds(ID... ids) {
    if (this.ids == null) {
      this.ids = new ArrayList<>();
    }
    this.ids.addAll(Arrays.asList(ids));
    return this;
  }

  public IdList<ID> getIdList() {
    if (id != null && CollectionUtils.isEmpty(ids)) {
      return new IdList<ID>().withCause(cause).add(id);
    } else if (id == null && CollectionUtils.isEmpty(ids)) {
      return new IdList<ID>().withCause(cause);
    } else {
      return new IdList<>(ids).withCause(cause);
    }
  }
}
