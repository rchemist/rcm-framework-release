/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.service.data.HasIdEntity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
public class ResponseListWrapperCache<VIEW extends HasIdEntity<ID>, SEARCH_FORM extends SearchFormWrapper<SEARCH_FORM>, ID> implements Serializable {

  public ResponseListWrapperCache() {
    this.totalCount = null;
    this.page = null;
    this.pageSize = null;
    this.totalPage = null;
    this.sorts = null;
    this.error = null;
    this.searchForm = null;
  }

  public ResponseListWrapperCache(ResponseListWrapper<VIEW, SEARCH_FORM> listWrapper) {
    this(listWrapper, new ArrayList<>());
    if (!listWrapper.isEmpty()) {
      for (HasIdEntity<ID> entity : listWrapper.getList()) {
        idList.add(entity.getId());
      }
    }
  }

  public ResponseListWrapperCache(ResponseListWrapper<VIEW, SEARCH_FORM> listWrapper, List<ID> cachedIds) {
    this.totalCount = listWrapper.getTotalCount();
    this.page = listWrapper.getPage();
    this.pageSize = listWrapper.getPageSize();
    this.totalPage = listWrapper.getTotalPage();
    this.sorts = listWrapper.getSorts();
    this.error = listWrapper.getError();
    this.searchForm = listWrapper.getSearchForm();
    this.idList = cachedIds == null ? new ArrayList<>() : cachedIds;
  }

  @Setter
  private List<ID> idList = new ArrayList<>();

  private final Integer totalCount;

  private final Integer page;

  private final Integer pageSize;

  private final Integer totalPage;

  private final List<SortEntry> sorts;

  private final ErrorDTO error;

  private final SEARCH_FORM searchForm;

  public ResponseListWrapperCache<VIEW, SEARCH_FORM, ID> withIdList(List<ID> idList) {
    this.idList = idList;
    return this;
  }

  public ResponseListWrapper<VIEW, SEARCH_FORM> getResponseListWrapper() {
    ResponseListWrapper<VIEW, SEARCH_FORM> responseListWrapper = new ResponseListWrapper<>();
    responseListWrapper.setTotalCount(totalCount);
    responseListWrapper.setPage(page);
    responseListWrapper.setPageSize(pageSize);
    responseListWrapper.setTotalPage(totalPage);
    responseListWrapper.setSorts(sorts);
    responseListWrapper.setError(error);
    responseListWrapper.setSearchForm(searchForm);
    return responseListWrapper;
  }

}
