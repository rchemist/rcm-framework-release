/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
@AdminEntity(name = "Attributes", headerProperty = "name")
public class AttributeDTO implements Serializable {

  @AdminField(order = 1, fieldType = PresentationFieldType.ID, headerField = @HeaderField(order = 1))
  protected Object id;

  @AdminField(order = 100, name = "NameValueImpl_Name", fieldType = PresentationFieldType.STRING, headerField = @HeaderField(order = 100), maxLength = "100")
  protected String name;

  @AdminField(name = "NameValueImpl_Value", fieldType = PresentationFieldType.STRING, order = 200, headerField = @HeaderField(order = 200), required = true)
  protected String value;

  protected Boolean customField;    // 커스텀필드 여부

  @AdminField(name = "AuditableCreated_CreatedAt", propertyName = "createdAt", order = 200
      , readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS)
      , fieldType = PresentationFieldType.DATETIME, headerField = @HeaderField(order = Integer.MAX_VALUE)
      , modifiableType = ModifiableType.MODIFY_ONLY)
  protected LocalDateTime createdAt;

  @AdminField(name = "AuditableUpdated_UpdatedAt", propertyName = "updatedAt", order = 300, readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS), fieldType = PresentationFieldType.DATETIME, modifiableType = ModifiableType.MODIFY_ONLY)
  protected LocalDateTime updatedAt;

  public AttributeDTO withId(Object id) {
    this.id = id;
    return this;
  }

  public AttributeDTO withName(String name) {
    this.name = name;
    return this;
  }

  public AttributeDTO withValue(String value) {
    this.value = value;
    return this;
  }

  public AttributeDTO withCustomField(Boolean customField) {
    this.customField = customField;
    return this;
  }

  public AttributeDTO withCreatedAt(LocalDateTime createdAt) {
    this.createdAt = createdAt;
    return this;
  }

  public AttributeDTO withUpdatedAt(LocalDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }


  public AttributeDTO clone(){
    return new AttributeDTO()
        .withId(getId())
        .withName(getName())
        .withValue(getValue())
        .withCustomField(getCustomField())
        .withCreatedAt(getCreatedAt())
        .withUpdatedAt(getUpdatedAt());
  }

}
