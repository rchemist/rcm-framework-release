/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.GroupEnumType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface AdminReproduceField {

  /**
   * 복제할 필드의 propertyName 앞에 붙을 prefix
   * 이 값이 "group" 이면 propertyName 은 group_"propertyName" 이 될 것이다.
   * @return
   */
  String prefix();

  /**
   * 복제할 EntityForm 이 있는 AdminEntity Class 의 fully classpath
   * @return
   */
  String targetClass();

  /**
   * 폼에서 어떤 탭에 보여줄지
   * @return
   */
  ViewTab tab() default @ViewTab(order = 1);

  /**
   * 폼 > 탭에서 어떤 필드그룹에 보여줄지
   * @return
   */
  ViewFieldGroup group() default @ViewFieldGroup(type = GroupEnumType.ITEM);

  /**
   * 복제 대상에서 제외할 필드 이름
   * @return
   */
  String[] excludes() default {};

}
