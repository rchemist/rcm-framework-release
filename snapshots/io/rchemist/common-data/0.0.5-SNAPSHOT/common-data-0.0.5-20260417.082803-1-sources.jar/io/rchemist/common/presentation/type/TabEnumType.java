/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.util.StringUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum TabEnumType {

  GENERAL(
      "TabGeneralId",
      "TabGeneral",
      100),


  PRICE(
      "TabPriceId",
      "TabPrice",
      200),

  SURVEY_ITEM(
      "TabSurveyItemId",
      "TabSurveyItem",
      210),

  SURVEY_RESULT(
      "TabSurveyResultId",
      "TabSurveyResult",
      220),

  PROPERTY(
      "TabPropertyId",
      "TabProperty",
      300),


  DESCRIPTION(
      "TabDescriptionId",
      "TabDescription",
      500),


  ADDRESS(
      "TabAddressId",
      "TabAddress",
      600),

  PRODUCT(
      "TabProductId",
      "TabProduct",
      700),


  FULFILLMENT(
      "TabFulfillmentId",
      "TabFulfillment",
      800),


  PAYMENT(
      "TabPaymentId",
      "TabPayment",
      900),

  CREDIT(
      "TabCreditId",
      "TabCredit",
      900),


  MARKETING(
      "TabMarketingId",
      "TabMarketing",
      1000),

  CONFIGURATION(
      "TabConfigurationId",
      "TabConfiguration",
      1050),

  MEDIA(
      "TabMediaId",
      "TabMedia",
      1100),

  RESTRICTION(
      "TabRestrictionId",
      "TabRestriction",
      1150),

  AUTHORITY(
      "TabAuthorityId",
      "TabAuthority",
      1200),

  GROUP_JOIN_FIELD(
      "TabGroupJoinFieldId",
      "TabGroupJoinField",
      1300),

  MEMBER(
      "TabMemberId",
      "TabMember",
      1400),

  GROUP_BOARD(
      "TabGroupBoardId",
      "TabGroupBoard",
      1450),

  ARTICLE(
      "TabArticleId",
      "TabArticle",
      1500),

  PROFILE("TabProfileId",
      "TabProfile",
      1600),

  FOLLOWING("TabFollowingId",
      "TabFollowing",
      1700),

  FOLLOWER("TabFollowerId",
      "TabFollower" ,
      1800),

  RECOMMEND_FOLLOWING("TabRecommendFollowerId",
      "TabRecommendFollower",
      1900),

  FEEDBACK("TabFeedbackId",
      "TabFeedback",
      2000),

  COMMENT(
      "TabCommentId",
      "TabComment",
      2100),

  REPORT(
      "TabReportId",
      "TabReport",
      2200),

  NOTIFICATION_HISTORY(
      "TabNotificationHistoryId",
      "TabNotificationHistory",
      2300),

  REWARD(
      "TabRewardId",
      "TabReward",
      2400),

  REWARD_HISTORY(
      "TabRewardHistoryId",
      "TabRewardHistory",
      2500),


  SEO_METADATA(
      "TabSeoMetadataId",
      "TabSeoMetadata",
      2600),

  ATTRIBUTE(
      "TabAttributeId",
      "TabAttribute",
      2700),

  ADMIN_UI(
      "TabAdminUIId",
      "TabAdminUI",
      2800),

  VALIDATION(
      "TabValidationId",
      "TabValidation",
      2900),

  SEARCH(
      "TabSearchId",
      "TabSearch",
      3000),

  ADVANCED(
      "TabAdvancedId",
      "TabAdvanced",
      3100),


  REVISION(
      "TabRevisionId",
      "TabRevision",
      10000000),


  HISTORY(
      "TabHistoryId",
      "TabHistory",
      3200),


  MODIFY_ON_LIST(
      "TabModifyOnListId",
      "TabModifyOnList",
      100),


  SECTION_CUSTOM_ENTITY(
      "TabSectionCustomEntityId",
      "TabSectionCustomEntity",
      10000),

  BLOCKED(
      "TabBlockedId"
      , "TabBlocked"
      , 10000000
  ),

  STATUS(
      "TabStatusId",
      "TabStatus",
      Integer.MAX_VALUE);


  @Getter
  private final int order;
  @Getter
  private final String name;
  @Getter
  private final String id;

  TabEnumType(String id, String name, int order) {
    this.order = order;
    this.name = name;
    this.id = id;
  }

  public static LinkedHashMap<String, String> getOptionValues(){
    List<TabEnumType> types = Arrays.asList(TabEnumType.values());
    Collections.sort(types, Comparator.comparing(TabEnumType::getOrder));
    LinkedHashMap<String, String> map = new LinkedHashMap<>();
    int loop = 1;
    for(TabEnumType type : types){
      String value = type.name();
      String count = StringUtil.fill(String.valueOf(loop++), "0", 2);
      String name = "["+ count +"] " + MessageSourceHelper.getMessage(type.getName());
      map.put(value, name);
    }
    return map;
  }

}
