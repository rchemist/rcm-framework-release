/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.data.CurrencyCodeIdentifiable;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface HasCurrencyCode<T> extends ClassTransformTarget, CurrencyCodeIdentifiable {

  default String getCurrencyCode() {
    throw new ClassTransformException();
  }
  
  default void setCurrencyCode(String currencyCode) {
    throw new ClassTransformException();
  }
  
  default T withCurrencyCode(String currencyCode) {
    setCurrencyCode(currencyCode);
    return (T) this;
  }  
  
}
