/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class PhoneType extends EnumType<PhoneType> {

  public static final PhoneType MOBILE = new PhoneType(10, "MOBILE", "Mobile", "휴대 전화", "global.phone.type.mobile");
  public static final PhoneType TEL = new PhoneType(20, "TEL", "Telephone", "일반 전화", "global.phone.type.tel");
  public static final PhoneType FAX = new PhoneType(30, "FAX", "Fax", "팩스", "global.phone.type.fax");

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public PhoneType(int order, String key, String value, String description, String messageKey) {
    super(order, key, value, description, messageKey);
  }

  private PhoneType(){

  }
}
