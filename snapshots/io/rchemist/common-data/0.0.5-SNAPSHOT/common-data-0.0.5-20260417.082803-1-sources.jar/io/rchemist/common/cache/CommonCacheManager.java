/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import java.util.Map;
import java.util.Set;
import javax.cache.Cache;
import javax.cache.CacheManager;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface CommonCacheManager {

  String BEAN_NAME = "rcmLocalCacheManager";

  <V> Cache<String, V> getCache(String region);

  CacheManager getCacheManager();

  void put(String region, String key, Object value);
  void put(String region, Object value, Class<?> clazz, String... cacheKey);
  void putAll(String region, Map<String, Object> cacheMap);

  boolean contains(String region, String cacheKey);
  boolean contains(String region, String... cacheKey);
  boolean contains(String region, Class<?> clazz, String... cacheKey);

  <V> V get(String region, String cacheKey);
  <V> V get(String region, String... cacheKey);
  <V> V get(String region, Class<?> clazz, String... cacheKey);

  Set<String> getAllRegionNames();
  void evictAll(String... regionNames);
  CacheConfiguration getCacheConfig(String region);
  Map<String, CacheConfiguration> getCacheConfig();
  
  void removeAll(String region);
  void remove(String region, String cacheKey);
  void remove(String region, String... cacheKey);
  void remove(String region, Class<?> clazz, String... cacheKey);

  String buildKey(String... cacheKey);
  String buildKey(Class<?> clazz, String... cacheKey);
  String buildKeyIgnoreSite(Class<?> clazz, String... params);

  <V> Cache<String, V>  createCache(String cacheName, int ttlSeconds, int maxElementsInMemory, Class<V> value);
  <V> Cache<String, V>  getOrCreateCache(String cacheName, int ttlSeconds, int maxElementsInMemory, Class<V> value);

  <V> Cache<String, V>  getOrCreateCache(CacheConfiguration config);

  <V> Cache<String, V>  getOrCreateCache(CacheConfiguration config, Class<V> value);

  void clear();

}
