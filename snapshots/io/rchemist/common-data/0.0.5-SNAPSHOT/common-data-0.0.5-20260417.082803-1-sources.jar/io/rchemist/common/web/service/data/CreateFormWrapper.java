/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.data;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.web.service.type.EntityViewType;
import java.util.Map;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface CreateFormWrapper<CREATE_FORM> extends RevisionEntityWrapper<CREATE_FORM>, ClassTransformTarget {

  /**
   * CreateForm 에 대한 확장 로직을 처리할 수 있게 추가 필드를 제공한다.
   * Service 에서 CreateForm 의 상태에 따라 다른 처리를 해야 하는 경우 등에서 사용한다.
   * @return
   */
  default Map<String, Object> getContext() {
    return null;
  }

  default void setContext(Map<String, Object> context) {
    throw new ClassTransformException();
  }

  default CREATE_FORM withContext(Map<String, Object> context) {
    setContext(context);
    return (CREATE_FORM) this;
  }

  default CREATE_FORM addContext(String key, Object value) {
    getContext().put(key, value);
    return (CREATE_FORM) this;
  }

  default EntityViewType getViewType() {
    throw new ClassTransformException();
  }

  default void setViewType(EntityViewType viewType) {
    throw new ClassTransformException();
  }

  default CREATE_FORM withViewType(EntityViewType viewType) {
    setViewType(viewType);
    return (CREATE_FORM) this;
  }

}
