/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.presentation.component.field.MapValue;
import io.rchemist.common.util.StringUtil;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAttributes<T> extends ClassTransformTarget {

  default String getAttributePrefix() {
    throw new ClassTransformException();
  }

  default void setAttributePrefix(String attributePrefix) {
    throw new ClassTransformException();
  }

  default String getAttributePrefix(String defaultPrefix) {
    return StringUtil.toString(getAttributePrefix(), defaultPrefix);
  }

  default Map<String, String> getAttributes(){
    throw new ClassTransformException();
  }

  default void setAttributes(Map<String, String> attributes){
    throw new ClassTransformException();
  }

  default T withAttributes(Map<String, String> attributes){
    setAttributes(attributes);
    return (T) this;
  }

  @JsonIgnore
  default void setAttributes(MapValue mapValue){
    setAttributes(mapValue.getSimpleAttributes());
  }

  default T withAttributes(MapValue mapValue){
    setAttributes(mapValue);
    return (T) this;
  }

}
