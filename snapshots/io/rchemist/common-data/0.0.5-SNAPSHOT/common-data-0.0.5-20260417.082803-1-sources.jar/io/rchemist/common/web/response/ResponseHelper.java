/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ResponseHelper {

  private static HttpStatus getStatus(ErrorDTO error){
    return (error == null) ? HttpStatus.OK : HttpStatus.valueOf(error.getStatus());
  }

  public interface ResponseResult<T> {
    T getResult() throws Exception;
  }

  public static <T> ResponseData<T> result(ResponseResult<T> result) {
    try {
      return ResponseHelper.result(result.getResult());
    }catch (Exception e) {
      return ResponseHelper.result(e);
    }
  }

  public static <T> ResponseEntity<ResponseData<T>> response(ResponseData<T> result){
    ResponseEntity<ResponseData<T>> entity = new ResponseEntity<>(result,
        getStatus(result.getError()));
    return entity;
  }

  public static <T> ResponseData<T> result(Throwable e){
    if (e.getCause() != null && e.getCause() instanceof Exception) {
      return result(null, new ErrorDTO(e.getCause()));
    }

    return result(null, new ErrorDTO(e));
  }

  public static ResponseData<Void> returnVoid(){
    ResponseWrapper<Void> wrapper = new ResponseWrapper<>();
    ResponseData<Void> result = new ResponseData<>(wrapper, HttpStatus.OK);
    return result;
  }

  public static <T> ResponseData<T> result(T data, ErrorDTO error){

    ResponseWrapper<T> wrapper = new ResponseWrapper<>();
    wrapper.setData(data);
    wrapper.setError(error);

    ResponseData<T> result = new ResponseData<>(wrapper, getStatus(error));

    return result;
  }

  public static <T> ResponseData<T> result(T data){
    return result(data, null);
  }

  public static <T, S extends SearchFormWrapper<S>> ResponseListData<T, S> resultList(ResponseListWrapper<T, S> wrapper){
    if(wrapper.getError() != null && wrapper.getError().isError()){
      return new ResponseListData<>(wrapper, getStatus(wrapper.getError()));
    }else{
      return new ResponseListData<>(wrapper, getStatus(wrapper.getError()));
    }
  }

  public static <T, S extends SearchFormWrapper<S>> ResponseListData<T, S> resultList(List<T> data, ErrorDTO error){

    ResponseListWrapper<T, S> wrapper = new ResponseListWrapper<>();
    wrapper.setList(data);
    wrapper.setError(error);

    ResponseListData<T, S> result = new ResponseListData<>(wrapper, getStatus(error));
    return result;
  }

  public static <T, S extends SearchFormWrapper<S>> ResponseListData<T, S> resultList(Page page, List<T> data, S searchForm, ErrorDTO error){

    ResponseListWrapper<T, S> wrapper = new ResponseListWrapper<>();
    wrapper.setList(data);

    searchForm.setTotalCount((int) page.getTotalElements());
    searchForm.setPage(page.getNumber());
    searchForm.setPageSize(page.getSize());

    wrapper.setSearchForm(searchForm);
    wrapper.setTotalCount((int) page.getTotalElements());
    wrapper.setError(error);

    ResponseListData<T, S> result = new ResponseListData<>(wrapper, getStatus(error));
    return result;
  }

  public static <T, S extends SearchFormWrapper<S>> ResponseListData<T, S> resultList(Page<T> data, S searchForm, ErrorDTO error){

    ResponseListWrapper<T, S> wrapper = new ResponseListWrapper<>();
    wrapper.setList(data.getContent());
    wrapper.setSearchForm(searchForm);
    wrapper.setTotalCount((int) data.getTotalElements());
    wrapper.setError(error);

    ResponseListData<T, S> result = new ResponseListData<>(wrapper, getStatus(error));
    return result;
  }

  public static <T, S extends SearchFormWrapper<S>> ResponseListData<T, S> resultListWithNoPaging(List<T> data){

    ResponseListWrapper<T, S> wrapper = new ResponseListWrapper<>();
    wrapper.setList(data);
    wrapper.setPage(0);
    wrapper.setTotalPage(1);
    wrapper.setTotalCount(CollectionUtils.isNotEmpty(data) ? data.size() : 0);

    ResponseListData<T, S> result = new ResponseListData<>(wrapper, getStatus(null));

    return result;
  }

  public static boolean isError(HttpStatusCode status) {
    /*HttpStatus.Series series = status.series();
    return (HttpStatus.Series.CLIENT_ERROR.equals(series)
        || HttpStatus.Series.SERVER_ERROR.equals(series));*/
    return status.isError();
  }

  private static String read(InputStream input) throws IOException {
    try (var buffer = new BufferedReader(new InputStreamReader(input))) {
      return buffer.lines().collect(Collectors.joining("\n"));
    }
  }

  public static <T> T result(ResponseWrapper<T> result) throws ErrorTypeException {
    if (result.isError()) {
      throw new ErrorTypeException(result.getError().getServiceErrorType());
    }
    return result.getData();
  }



}
