/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasSeoMetadata<T> extends ClassTransformTarget, ISeoMetadata<T> {

  @Override
  default String getMetaHeader(){throw new ClassTransformException();}                // 헤더에 들어갈 내용을 ; 로 구분해 문자열로 입력

  @Override
  default void setMetaHeader(String metaHeader){throw new ClassTransformException();}

  // varchar(255)
  @Override
  default String getMetaTitle(){throw new ClassTransformException();}

  @Override
  default void setMetaTitle(String metaTitle){throw new ClassTransformException();}

  // varchar(4000)
  @Override
  default String getMetaDescription(){throw new ClassTransformException();}
  @Override
  default void setMetaDescription(String metaDescription){throw new ClassTransformException();}

  @Override
  default T withMetaHeader(String metaHeader){
    setMetaHeader(metaHeader);
    return (T) this;
  }

  @Override
  default T withMetaTitle(String metaTitle){
    setMetaTitle(metaTitle);
    return (T) this;
  }

  @Override
  default T withMetaDescription(String metaDescription){
    setMetaDescription(metaDescription);
    return (T) this;
  }

  @Override
  default T withSeoMetadata(ISeoMetadata<?> seoMetadata) {
    setMetaHeader(seoMetadata.getMetaHeader());
    setMetaTitle(seoMetadata.getMetaTitle());
    setMetaDescription(seoMetadata.getMetaDescription());
    return (T) this;
  }
}
