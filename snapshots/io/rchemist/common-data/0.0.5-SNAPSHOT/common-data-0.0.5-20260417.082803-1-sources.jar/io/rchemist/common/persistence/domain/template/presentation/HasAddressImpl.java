/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.Enumeration;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(HasAddress.class)
public class HasAddressImpl implements EnhancedTemplate {

  @Description(name = "국가 코드", comment = "ISO 3166-1 국가 코드, ALPHA-3 코드")
  @AdminField(name = "Address_Country", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=1000, fieldType = PresentationFieldType.ENUMERATION
      , enumeration = @Enumeration(values = "KOR"))
  protected String country;         // ISO country code

  @Description(name = "주 코드", comment = "ISO 주 코드. 한국은 특별/광역시/도 등의 정보가 들어간다. ")
  @AdminField(name = "Address_State", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=2000, fieldType = PresentationFieldType.STRING)
  protected String state;           // ISO state code. 특별/광역시/도

  @Description(name = "시", comment = "도시")
  @AdminField(name = "Address_City", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=3000, fieldType = PresentationFieldType.STRING)
  protected String city;            // 도시

  @Description(name = "주소 1", comment = "주소 1")
  @AdminField(name = "Address_Address1", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=4000, fieldType = PresentationFieldType.STRING)
  protected String address1;        // 주소1

  @Description(name = "주소 2", comment = "주소 2")
  @AdminField(name = "Address_Address2", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=5000, fieldType = PresentationFieldType.STRING)
  protected String address2;        // 주소 2

  @Description(name = "상세 주소", comment = "상세 주소, 사용자 입력 추가 주소. 111동 111호와 같은 정보가 들어감")
  @AdminField(name = "Address_AddressDetail", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=7000, fieldType = PresentationFieldType.STRING)
  protected String addressDetail;   // 사용자 입력 추가 주소

  @Description(name = "우편 번호", comment = "우편 번호")
  @AdminField(name = "Address_PostalCode", tab=@ViewTab(type = TabEnumType.ADDRESS), group=@ViewFieldGroup(type = GroupEnumType.ADDRESS)
      , createForm = @CreateForm(type = CreateFormType.ADDRESS)
      , order=8000, fieldType = PresentationFieldType.STRING)
  protected String postalCode;

}
