/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class FileInfo implements Serializable {
  protected String id;    // asset id
  protected String url;   // asset url
  protected Boolean primary;    // whether file is primary in file list
  protected Long fileSize;  // fileSize 제공이 가능하다면

  public FileInfo withFileSize(Long fileSize) {
    this.fileSize = fileSize;
    return this;
  }

  public FileInfo withPrimary(Boolean primary) {
    this.primary = primary;
    return this;
  }

  public FileInfo withId(String id) {
    this.id = id;
    return this;
  }

  public FileInfo withUrl(String url) {
    this.url = url;
    return this;
  }

  public static List<FileInfo> createFileInfoList(String... urls) {
    List<FileInfo> list = new ArrayList<>();

    for (String url : urls) {
      list.add(new FileInfo().withId(url).withUrl(url));
    }

    return list;
  }

  public boolean isPrimary() {
    return BooleanUtils.toBoolean(this.primary);
  }

}