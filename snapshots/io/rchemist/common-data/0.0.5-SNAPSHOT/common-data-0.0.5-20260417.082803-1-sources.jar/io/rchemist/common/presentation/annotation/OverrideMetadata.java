/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.MaskingType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.util.type.BooleanType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface OverrideMetadata {

  String propertyName();

  String name() default "";

  String helpText() default "";

  String defaultValue() default "";

  PresentationFieldType fieldType() default PresentationFieldType.NOT_AVAILABLE;

  ModifiableType modifiableType() default ModifiableType.NONE;

  Enumeration enumeration() default @Enumeration();

  boolean removeHelpText() default false;

  boolean removeDefaultValue() default false;

  int order() default 0;    // 0 일 때 변경 안 함

  BooleanType readOnly() default BooleanType.NULL;

  BooleanType required() default BooleanType.NULL;

  BooleanType hidden() default BooleanType.NULL;

  CreateForm createForm() default @CreateForm();      // 이 값을 변경할 때 반드시 overridden = true 를 설정해야 한다.

  HeaderField headerField() default @HeaderField(showGrid = false);   // 이 값을 변경할 때 반드시 overridden = true 를 설정해야 한다.

  boolean exclude() default false;

  MaskingOption masking() default @MaskingOption(type = MaskingType.NOT_SET);

  BooleanType supportModifyAll() default BooleanType.NULL;

  ReferenceFieldView referenceField() default @ReferenceFieldView();    // 이 값을 변경할 때 반드시 fieldType 이 FOREIGN_KEY 여야 하며, overridden = true 를 설정해야 한다.

  UploadFile uploadFile() default @UploadFile();    // 이 값을 변경할 때 반드시 fieldType 이 UPLOAD 또는 UPLOAD_MULTIPLE 이어야 하며, overridden = true 를 설정해야 한다.

  ViewTab tab() default @ViewTab();

  ViewFieldGroup group() default @ViewFieldGroup();

}
