/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.component.field;

import io.rchemist.common.persistence.domain.data.AttributeDTO;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.math.BigInteger;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MapValueItem implements Serializable {

  protected String rowId;   // 필드에서 사용하는 임시 row 값

  protected Long id;    // attribute.id

  protected String name;

  protected String value;

  public void setName(String name){
    this.name = StringUtil.cleanXss(name);
  }

  public void setValue(String value){
    this.value = StringUtil.cleanXss(value);
  }

  public MapValueItem withRowId(String rowId) {
    this.rowId = rowId;
    return this;
  }

  public MapValueItem withName(String name) {
    setName(name);
    return this;
  }

  public MapValueItem withValue(String value) {
    setValue(value);
    return this;
  }

  public MapValueItem withId(Long id) {
    this.id = id;
    return this;
  }

  public MapValueItem clone(){
    return new MapValueItem()
        .withId(id)
        .withName(name)
        .withRowId(rowId)
        .withValue(value);
  }

  public BigInteger getPriority(){
    if(id == null){
      return new BigInteger(String.valueOf(Integer.MAX_VALUE));
    }else{
      return new BigInteger(String.valueOf(id));
    }
  }

  public boolean equalItem(String rowId){
    return StringUtils.equals(rowId, this.rowId);
  }

  public boolean isDuplicate(String rowId, String name){
    return !equalItem(rowId) && StringUtils.equals(name, this.name);
  }

  public static MapValueItem createByAttribute(AttributeDTO dto){
    return new MapValueItem()
        .withId(NumberUtil.getLong(String.valueOf(dto.getId())))
        .withName(dto.getName())
        .withValue(dto.getValue());

  }

}
