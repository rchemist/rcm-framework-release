/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * 한 도메인 엔티티에 다른 도메인 엔티티가 매핑될 때, Polymophic mapping 을 금지하도록 하는 어노테이션이다.
 * Admin Panel 의 UI 표시나, entityManager.merge 시점에서 dedicated 에 지정된 엔티티만 참조할 수 있도록 강제한다.
 * 성능을 위해 프레임워크에서 Dedicated로 표시된 엔티티 필드들을 캐싱하고, 해당 필드가 dedicated 된 엔티티가 어떤 클래스인지 저장해 두어야 한다.
 *
 **/
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PolymorphicForbidden {

  Class dedicate();

}
