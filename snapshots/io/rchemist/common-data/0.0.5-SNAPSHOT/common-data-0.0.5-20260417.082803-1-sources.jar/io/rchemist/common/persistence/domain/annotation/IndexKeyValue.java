/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 *
 * 1. EAV 패턴을 적용할 때 Attribute-Value 에 해당하는 Map<String, String> 을 자동으로 HibernateSearch 의 index 로 적용한다.
 *
 * 2. PlatformSessionFactoryBuilderFactory 에서 RegisterEntityBeanDTO 를 만들 때 어떤 필드가 AttributeField 에 해당하는지에 대한 정보를 제공한다.
 *    실제 엔티티의 @OneToMany 로 매핑된 필드명은 userAttributes 인데 SearchForm 이나 DTO 에는 attributes 로 정의되어 있다고 예를 들어 보자.
 *    attributes.color=red 와 같이 검색 조건이 넘어 왔을 때 HibernateSearch 에는 아무 문제가 없지만
 *    JPA 검색일 때는 attributes.color 가 무엇을 의미하는지에 대한 정의가 필요하다.
 *    attributes 를 userAttributes 로 변경하고, color 는 name=color 라는 점을 재정의해야 하는데
 *    이때 사용되는 정보가 RegisterEntityBeanDTO.attributeFields 값이다.
 *
 *    HibernateSearch 를 사용할 때는 User DTO 에 attributes 가 정의되어 있는 경우 document 에서 자동으로 attr 에 해당하는 값을 모두 가져와 Map<String, String> 값에 넣어 준다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Target({ElementType.METHOD})
@Retention(RUNTIME)
public @interface IndexKeyValue {

  /**
   * DTO 로 변환될 때 사용할 이름, 생략하면 필드명으로 적용
   * @return
   */
  String indexName() default "";

  String derivedFrom();

  /**
   * 이 값이 false 일 때 IndexKeyValueMapClassTransformer 가 적용되지 않는다.
   * @return
   */
  boolean excluded() default false;

}