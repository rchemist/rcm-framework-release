/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface DerivedVisibleValue {

  /**
   * 필드의 입력값이 여기서 지정한 값일 때 derivedPropertyName 에 지정한 필드들의 visible = true 가 된다.
   * @return
   */
  String[] value();

  /**
   * 필드의 입력값에 따라 어떤 필드들의 visibility 를 변경해야 하는지, 대상 필드의 이름을 지정한다.
   * 이때 이름이란, FieldView.name() 과는 다르다. 실제 class file 에 정의된 property name 을 의미한다.
   * @return
   */
  String[] derivedPropertyName();

}
