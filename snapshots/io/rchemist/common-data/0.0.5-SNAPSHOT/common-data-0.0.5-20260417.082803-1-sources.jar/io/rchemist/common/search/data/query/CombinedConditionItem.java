/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class CombinedConditionItem implements QueryConditionItem {

  public CombinedConditionItem(List<QueryConditionItem> subConditions) {
    this(ConditionOperatorType.AND, subConditions);
  }

  public CombinedConditionItem(QueryConditionItem... subConditions) {
    this(Arrays.asList(subConditions));
  }

  public CombinedConditionItem(ConditionOperatorType operatorType, List<QueryConditionItem> subConditionItems){
    this.operatorType = operatorType == null ? ConditionOperatorType.AND : operatorType;
    this.subConditions = subConditionItems;
  }

  public CombinedConditionItem(ConditionOperatorType operatorType, QueryConditionItem... subConditionItems){
    this(operatorType, Arrays.asList(subConditionItems));
  }

  public static CombinedConditionItem or(QueryConditionItem... items){
    return new CombinedConditionItem(ConditionOperatorType.OR, Arrays.asList(items));
  }

  public static CombinedConditionItem and(QueryConditionItem... items){
    return new CombinedConditionItem(ConditionOperatorType.AND, Arrays.asList(items));
  }


  private List<QueryConditionItem> subConditions;

  private ConditionOperatorType operatorType;

  @Setter
  private boolean applyOnClause = false;

  @Setter
  private boolean jsonFilter = false;

  @Override
  public Predicate getPredicate(CriteriaBuilder criteriaBuilder, Path path) {
    return null;
  }

  @Override
  public String[] getPropertyNames() {
    Set<String> propertyNames = new HashSet<>();
    if(CollectionUtils.isNotEmpty(subConditions)){
      for(QueryConditionItem item : subConditions){
        propertyNames.addAll(Arrays.asList(item.getPropertyNames()));
      }
    }
    return propertyNames.toArray(new String[0]);
  }

  public static QueryConditionItem anyOfSplitValues(String propertyName, String value) {
    return getQueryConditionItem(ConditionOperatorType.OR, propertyName, value);
  }

  public static QueryConditionItem allOfSplitValues(String propertyName, String value) {
    return getQueryConditionItem(ConditionOperatorType.AND, propertyName, value);
  }

  private static QueryConditionItem getQueryConditionItem(ConditionOperatorType operatorType, String propertyName, String value) {
    QueryConditionItem item;
    if(StringUtils.contains(value, ",")){
      String[] aliases = StringUtil.splitArray(value, ",");

      List<SingleConditionItem> predicates = new ArrayList<>();
      for(String alias : aliases){
        predicates.add(SingleConditionItem.equal(propertyName, alias));
      }

      if(operatorType.isMust()){
        item = CombinedConditionItem.and(predicates.toArray(new SingleConditionItem[0]));
      }else{
        item = CombinedConditionItem.or(predicates.toArray(new SingleConditionItem[0]));
      }

    }else{
      item = SingleConditionItem.equal(propertyName, value);
    }
    return item;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CombinedConditionItem that = (CombinedConditionItem) o;

    if(!operatorType.equals(that.operatorType))
      return false;

    if(CollectionUtils.isEmpty(subConditions) && CollectionUtils.isNotEmpty(that.subConditions))
      return false;

    if(CollectionUtils.isNotEmpty(subConditions) && CollectionUtils.isEmpty(that.subConditions))
      return false;

    if(subConditions.size() != that.subConditions.size())
      return false;

    int loopCount = 0;
    for(QueryConditionItem item : subConditions){
      QueryConditionItem other = that.subConditions.get(loopCount++);
      if(item.equals(other)){
        return false;
      }
    }

    return true;

  }

  @Override
  public int hashCode() {
    return Objects.hash(subConditions, operatorType);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("subConditions", subConditions)
        .append("operatorType", operatorType)
        .append("applyOnClause", applyOnClause)
        .append("jsonFilter", jsonFilter)
        .toString();
  }
}
