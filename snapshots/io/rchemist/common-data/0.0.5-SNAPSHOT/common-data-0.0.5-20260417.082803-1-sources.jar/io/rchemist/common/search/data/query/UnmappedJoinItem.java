/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import java.util.Objects;
import lombok.Getter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class UnmappedJoinItem implements Serializable {

  public UnmappedJoinItem(Class<?> targetEntityClass, String joinAlias, String targetPath,
      String rootJoinPath, QueryConditionItem additionalCondition, JoinType joinType) {
    this.targetEntityClass = targetEntityClass;
    this.joinAlias = joinAlias;
    this.targetPath = targetPath;
    this.rootJoinPath = rootJoinPath;
    this.additionalCondition = additionalCondition;
    this.joinType = joinType;
  }

  private final Class<?> targetEntityClass;

  private final String joinAlias;

  private final String targetPath;

  private final String rootJoinPath;

  private final QueryConditionItem additionalCondition;

  private JoinType joinType;

  public JoinType getJoinType() {
    return joinType == null ? JoinType.INNER : joinType;
  }

  @Override
  public boolean equals(Object obj) {
    if(obj == null || !(obj instanceof UnmappedJoinItem))
      return false;

    UnmappedJoinItem other = (UnmappedJoinItem) obj;

    if(!this.targetPath.equals(other.targetPath))
      return false;

    if(!this.rootJoinPath.equals(other.rootJoinPath))
      return false;

    if(!this.additionalCondition.equals(other.additionalCondition))
      return false;

    if(!Objects.deepEquals(this.joinType, other.joinType))
      return false;

    return (additionalCondition.equals(other.additionalCondition));

  }

  public boolean isOuterJoin() {
    return getJoinType() != null && !getJoinType().equals(JoinType.INNER);
  }
}
