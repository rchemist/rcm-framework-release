/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.web.request.data.sort.NormalSortInfo;
import io.rchemist.common.web.request.data.sort.PrioritySortInfo;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortEntryListDeserializer;
import io.rchemist.common.web.request.data.sort.SortEntryListSerializer;
import io.rchemist.common.web.request.data.sort.SortInfo;
import jakarta.persistence.criteria.JoinType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@com.fasterxml.jackson.annotation.JsonIgnoreProperties({"sortArray", "sortDirections"})
public abstract class PagingCriteria<S> implements SearchFormWrapper<S> {

  protected Integer page;

  protected Integer pageSize;

  protected Integer totalCount;

  protected Integer totalPage;

  /**
   * 정렬 항목 목록
   * 동일 필드에 대해 여러 개의 정렬 조건을 저장할 수 있다.
   */
  @JsonDeserialize(using = SortEntryListDeserializer.class)
  @JsonSerialize(using = SortEntryListSerializer.class)
  protected List<SortEntry> sorts = new ArrayList<>();

  protected Boolean ignoreCache;

  public Integer getPage() {
    return NumberUtil.getInteger(page, 0);
  }

  public Integer getPageSize() {
    return NumberUtil.getInteger(pageSize, 10);
  }

  public Integer getTotalCount() {return NumberUtil.getInteger(totalCount, 0);}
  public Integer getTotalPage() {return NumberUtil.getInteger(totalPage, 0);}

  public boolean isEmptySort() {
    return CollectionUtils.isEmpty(this.sorts);
  }

  public S withPage(Integer page) {
    this.page = page;
    return (S) this;
  }

  public S withPageSize(Integer pageSize) {
    this.pageSize = pageSize;
    return (S) this;
  }

  public S withTotalCount(Integer totalCount) {
    this.totalCount = totalCount;
    return (S) this;
  }

  public S withTotalPage(Integer totalPage) {
    this.totalPage = totalPage;
    return (S) this;
  }

  public S withIgnoreCache(Boolean ignoreCache) {
    this.ignoreCache = ignoreCache;
    return (S) this;
  }

  public S withSort(String field, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.normal(field, direction));
    return (S) this;
  }

  public S withPrioritySort(String field, Object priorityValue, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.priority(field, priorityValue, direction));
    return (S) this;
  }

  public S withSorts(List<SortEntry> sorts) {
    this.sorts = sorts != null ? new ArrayList<>(sorts) : new ArrayList<>();
    return (S) this;
  }

  /**
   * 일반 정렬 추가
   * @param fieldName 필드 이름
   * @param direction 정렬 방향
   * @return this
   */
  public S addSort(String fieldName, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.normal(fieldName, direction));
    return (S) this;
  }

  /**
   * SortInfo를 직접 지정하여 정렬 추가
   * @param fieldName 필드 이름
   * @param sortInfo 정렬 정보
   * @return this
   */
  public S addSort(String fieldName, SortInfo sortInfo) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.of(fieldName, sortInfo));
    return (S) this;
  }

  /**
   * 우선순위 정렬 추가
   * 같은 필드에 대해 여러 번 호출하면 기존 PrioritySortInfo에 값이 추가된다.
   * @param fieldName 필드 이름
   * @param priorityValue 우선순위 값
   * @param direction 정렬 방향
   * @return this
   */
  public S addSort(String fieldName, Object priorityValue, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }

    // 같은 필드의 PrioritySortInfo가 이미 있는지 확인
    for (SortEntry entry : sorts) {
      if (entry.getFieldName().equals(fieldName)
          && entry.getSortInfo() instanceof PrioritySortInfo) {
        // 기존 entry에 우선순위 값 추가
        ((PrioritySortInfo) entry.getSortInfo()).addPriorityValue(priorityValue);
        return (S) this;
      }
    }

    // 없으면 새로 생성
    sorts.add(SortEntry.priority(fieldName, priorityValue, direction));
    return (S) this;
  }

  /**
   * 다중 우선순위 정렬 추가 (리스트로 한 번에 지정)
   * @param fieldName 필드 이름
   * @param priorityValues 우선순위 값 목록
   * @param direction 정렬 방향
   * @return this
   */
  public S addSort(String fieldName, java.util.Collection<?> priorityValues, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.of(fieldName, new PrioritySortInfo(priorityValues, direction)));
    return (S) this;
  }

  /**
   * LEFT JOIN을 사용하는 정렬 추가
   * @param fieldName 정렬 필드 경로 (예: "subject.major.name")
   * @param direction 정렬 방향
   * @return this
   */
  public S addLeftJoinSort(String fieldName, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.normal(fieldName, direction, JoinType.LEFT));
    return (S) this;
  }

  /**
   * JOIN 타입을 지정하는 정렬 추가
   * @param fieldName 정렬 필드 경로
   * @param direction 정렬 방향
   * @param joinType JOIN 타입 (LEFT, INNER, RIGHT)
   * @return this
   */
  public S addSort(String fieldName, Direction direction, JoinType joinType) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.normal(fieldName, direction, joinType));
    return (S) this;
  }

  /**
   * JOIN 타입과 NULL 위치를 지정하는 정렬 추가
   * @param fieldName 정렬 필드 경로
   * @param direction 정렬 방향
   * @param joinType JOIN 타입
   * @param nullsFirst NULL 값을 처음에 배치할지 여부
   * @return this
   */
  public S addSort(String fieldName, Direction direction, JoinType joinType, Boolean nullsFirst) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(SortEntry.of(fieldName, new NormalSortInfo(direction, joinType, nullsFirst)));
    return (S) this;
  }

  /**
   * LEFT JOIN을 사용하는 우선순위 정렬 추가
   * 동일 필드에 대해 여러 번 호출하여 다중 우선순위 정렬을 추가할 수 있다.
   * @param fieldName 정렬 필드 경로
   * @param priorityValue 우선 정렬할 값
   * @param direction 정렬 방향
   * @return this
   */
  public S addLeftJoinPrioritySort(String fieldName, Object priorityValue, Direction direction) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }

    // 같은 필드의 PrioritySortInfo가 이미 있는지 확인
    for (SortEntry entry : sorts) {
      if (entry.getFieldName().equals(fieldName)
          && entry.getSortInfo() instanceof PrioritySortInfo) {
        ((PrioritySortInfo) entry.getSortInfo()).addPriorityValue(priorityValue);
        return (S) this;
      }
    }

    sorts.add(SortEntry.priority(fieldName, priorityValue, direction, JoinType.LEFT));
    return (S) this;
  }

  /**
   * JOIN 타입을 지정하는 우선순위 정렬 추가
   * 동일 필드에 대해 여러 번 호출하여 다중 우선순위 정렬을 추가할 수 있다.
   * @param fieldName 정렬 필드 경로
   * @param priorityValue 우선 정렬할 값
   * @param direction 정렬 방향
   * @param joinType JOIN 타입
   * @param nullsFirst NULL 값 위치
   * @return this
   */
  public S addPrioritySort(String fieldName, Object priorityValue, Direction direction,
                          JoinType joinType, Boolean nullsFirst) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }

    // 같은 필드의 PrioritySortInfo가 이미 있는지 확인
    for (SortEntry entry : sorts) {
      if (entry.getFieldName().equals(fieldName)
          && entry.getSortInfo() instanceof PrioritySortInfo) {
        ((PrioritySortInfo) entry.getSortInfo()).addPriorityValue(priorityValue);
        return (S) this;
      }
    }

    sorts.add(SortEntry.of(fieldName, new PrioritySortInfo(priorityValue, direction, joinType, nullsFirst)));
    return (S) this;
  }

  /**
   * 우선순위 정렬 추가 (JOIN 타입 지정)
   * @param fieldName 정렬 필드 경로
   * @param priorityValue 우선 정렬할 값
   * @param direction 정렬 방향
   * @param joinType JOIN 타입
   * @return this
   */
  public S addPrioritySort(String fieldName, Object priorityValue, Direction direction,
                          JoinType joinType) {
    return addPrioritySort(fieldName, priorityValue, direction, joinType, null);
  }

  /**
   * 우선순위 정렬 추가 (간단 버전)
   * @param fieldName 정렬 필드 경로
   * @param priorityValue 우선 정렬할 값
   * @param direction 정렬 방향
   * @return this
   */
  public S addPrioritySort(String fieldName, Object priorityValue, Direction direction) {
    return addPrioritySort(fieldName, priorityValue, direction, null, null);
  }

  /**
   * 정렬 항목 목록을 반환
   * @return 정렬 항목 목록
   */
  public List<SortEntry> getSorts() {
    if (sorts == null) {
      sorts = new ArrayList<>();
    }
    return sorts;
  }

  public SortEntry getSort(String fieldName) {
    return sorts.stream().filter(entry -> entry.getFieldName().equals(fieldName)).findFirst().orElse(null);
  }

  /**
   * 정렬 항목 목록을 설정
   * @param sortEntries 정렬 항목 목록
   */
  public void setSorts(List<SortEntry> sortEntries) {
    this.sorts = sortEntries != null ? new ArrayList<>(sortEntries) : new ArrayList<>();
  }

  /**
   * 정렬 설정 (하위 호환성 - Map에서 List로 변환)
   * @param sortMap 정렬 맵 (필드명 -> SortInfo)
   * @deprecated setSorts(List&lt;SortEntry&gt;) 사용 권장
   */
  @Deprecated
  public void setSort(java.util.Map<String, SortInfo> sortMap) {
    if (sortMap == null) {
      this.sorts = new ArrayList<>();
    } else {
      this.sorts = new ArrayList<>();
      sortMap.forEach((fieldName, sortInfo) ->
        this.sorts.add(SortEntry.of(fieldName, sortInfo))
      );
    }
  }

  /**
   * 정렬 항목을 추가하는 유틸리티 메서드
   * @param sortEntry 추가할 정렬 항목
   * @return this
   */
  public S addSortEntry(SortEntry sortEntry) {
    if(sorts == null) {
      sorts = new ArrayList<>();
    }
    sorts.add(sortEntry);
    return (S) this;
  }

  /**
   * 특정 필드의 모든 정렬 항목을 제거
   * @param fieldName 제거할 필드 이름
   * @return this
   */
  public S removeSortByField(String fieldName) {
    if (sorts != null) {
      sorts.removeIf(entry -> entry.getFieldName().equals(fieldName));
    }
    return (S) this;
  }

  /**
   * 모든 정렬 항목을 제거
   * @return this
   */
  public S clearSorts() {
    if (sorts != null) {
      sorts.clear();
    }
    return (S) this;
  }

  /**
   * 특정 필드로 시작하는 정렬 항목을 제거 (하위 호환성)
   * @param propertyPrefix 제거할 필드 접두사
   */
  public void removeSortStartWith(String propertyPrefix) {
    if (CollectionUtils.isNotEmpty(sorts)) {
      sorts.removeIf(entry -> entry.getFieldName().startsWith(propertyPrefix));
    }
  }

  public boolean isIgnoreCache() {
    return BooleanUtils.toBoolean(ignoreCache);
  }

  /**
   * Spring Data Sort 생성 (기본 정렬 조건 포함)
   * Hibernate Search 등에서 사용
   */
  @JsonIgnore
  public Sort getSort(String defaultSortProperty, Direction defaultDirection) {
    return getOrders(defaultSortProperty, defaultDirection);
  }

  /**
   * 정렬 정보를 String 배열로 반환
   * @return String[] - 정렬 정보 배열
   */
  public String[] getSortArray() {
    return getSortToString();
  }

  protected Sort getOrders(String defaultSortProperty, Direction defaultDirection) {
    List<Order> orders = new ArrayList<>();

    if(CollectionUtils.isNotEmpty(this.sorts)) {
      for(SortEntry entry : this.sorts) {
        String fieldName = entry.getFieldName();
        SortInfo sortInfo = entry.getSortInfo();

        if(sortInfo != null) {
          Direction direction = sortInfo.getDirection();
          orders.add(new Order(direction, fieldName));
        } else {
          orders.add(new Order(Direction.DESC, fieldName));
        }
      }
    }

    if(CollectionUtils.isEmpty(orders)) {
      if(defaultSortProperty == null || defaultSortProperty.isEmpty()) {
        return Sort.unsorted();
      } else {
        return Sort.by(new Order(defaultDirection, defaultSortProperty));
      }
    } else {
      return Sort.by(orders);
    }
  }

  protected String[] getSortToString() {
    if(CollectionUtils.isNotEmpty(this.sorts)){
      List<String> sortStrings = new ArrayList<>();
      for(SortEntry entry : this.sorts){
        String propertyName = entry.getFieldName();
        SortInfo sortInfo = entry.getSortInfo();

        StringBuilder sb = new StringBuilder();

        if(sortInfo instanceof PrioritySortInfo) {
          PrioritySortInfo priority = (PrioritySortInfo) sortInfo;
          sb.append(propertyName).append("=").append(priority.getPriorityValues())
            .append(" ").append(priority.getDirection().name());
        } else {
          sb.append(propertyName).append(" ").append(sortInfo.getDirection().name());
        }

        // JOIN 타입 추가
        if (sortInfo.getJoinType() != null) {
          sb.append(" JOIN:").append(sortInfo.getJoinType().name());
        }

        // NULL 위치 추가
        if (sortInfo.getNullsFirst() != null) {
          sb.append(" NULLS:").append(sortInfo.getNullsFirst() ? "FIRST" : "LAST");
        }

        sortStrings.add(sb.toString());
      }
      if(sortStrings.size() > 1){
        // 나중에 클릭한게 먼저 적용되도록한다.
        Collections.reverse(sortStrings);
      }
      return sortStrings.toArray(new String[0]);
    }else{
      // list가 비었으면 초기화
      return new String[]{};
    }
  }

}
