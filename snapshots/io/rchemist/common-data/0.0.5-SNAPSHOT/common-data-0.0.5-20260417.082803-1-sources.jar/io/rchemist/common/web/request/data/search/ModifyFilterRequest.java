/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ModifyFilterRequest {

  private final EntityBean<?> entityBean;
  private final FilterItem filterItem;
  private final boolean hibernateSearch;
  private final boolean subFilter;

  @Setter
  private RegisterEntityBeanPropertyDTO entityBeanProperty;

  private List<SearchFieldModifier> searchFieldModifiers = new ArrayList<>();

  public ModifyFilterRequest(EntityBean<?> entityBean, FilterItem filterItem,
      boolean hibernateSearch) {
    this(entityBean, filterItem, hibernateSearch, false);
  }

  public ModifyFilterRequest(EntityBean<?> entityBean, FilterItem filterItem,
      boolean hibernateSearch, boolean subFilter) {
    this.entityBean = entityBean;
    this.filterItem = filterItem;
    this.hibernateSearch = hibernateSearch;
    this.subFilter = subFilter;
  }

  public ModifyFilterRequest withEntityBeanProperty(
      RegisterEntityBeanPropertyDTO entityBeanProperty) {
    this.entityBeanProperty = entityBeanProperty;
    return this;
  }

  public ModifyFilterRequest withSearchFieldModifiers(
      List<SearchFieldModifier> searchFieldModifiers) {
    this.searchFieldModifiers = searchFieldModifiers;
    return this;
  }
}
