/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CreditType extends EnumType<CreditType> {

  private static final List<CreditType> USER_ASSIGNABLE_TYPES = new ArrayList<>();

  public static final CreditType MILEAGE = new CreditType(10, "MILEAGE", "Mileage", "마일리지", "global.type.credit.type.mileage", true, PaymentType.MILEAGE);
  public static final CreditType CUSTOMER_CREDIT = new CreditType(20, "CUSTOMER_CREDIT", "CustomerCredit", "고객 적립금", "global.type.credit.type.customer.credit", true, PaymentType.CUSTOMER_CREDIT);
  public static final CreditType GIFT_CARD = new CreditType(30, "GIFT_CARD", "GiftCard", "기프트카드", "global.type.credit.type.gift.card", false, PaymentType.GIFT_CARD);

  @Getter
  protected boolean assignCustomer;

  @Getter
  protected PaymentType paymentType;

  public CreditType(int order, String type, String friendlyType, String description, String messageKey, boolean assignCustomer, PaymentType paymentType) {
    super(order, type, friendlyType, description, messageKey);
    this.assignCustomer = assignCustomer;
    this.paymentType = paymentType;
    if(assignCustomer){
      USER_ASSIGNABLE_TYPES.add(this);
    }
  }

  private CreditType() {
  }

  public static final List<CreditType> getUserAssignableCreditTypes(){
    return USER_ASSIGNABLE_TYPES;
  }

  public static final List<String> getUserAssignableCreditTypeNames() {
    List<String> typeNames = USER_ASSIGNABLE_TYPES.stream().map(EnumType::getType)
        .collect(Collectors.toList());
    return typeNames;
  }
}

