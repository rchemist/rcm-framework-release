/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.web.request.data.SearchFormWrapper;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ResponseListData<T, S extends SearchFormWrapper<S>> extends ResponseEntity<ResponseListWrapper<T, S>> implements Serializable, ResponseHolder {

  public ResponseListData(
      @Nullable ResponseListWrapper<T, S> body,
      HttpStatus status) {
    super(body, status);
  }

  @Override
  public ErrorDTO getError() {
    return Objects.requireNonNull(getBody()).getError();
  }

  public List<T> getData(){
    return (isError()) ? null : Objects.requireNonNull(getBody()).getList();
  }

  public boolean isEmpty(){
    return CollectionUtils.isEmpty(getData());
  }

  public S getSearchForm() {

    if(super.hasBody() && Objects.requireNonNull(super.getBody()).getSearchForm() != null){
      return super.getBody().getSearchForm();
    }

    return null;

  }

  public boolean equals(Object other) {
    if (other == null) return false;
    if (other == this) return true;
    if (!(other instanceof ResponseListData))return false;

    ResponseListData<T, S> otherList = (ResponseListData<T, S>) other;

    if (hasBody() != otherList.hasBody()) return false;
    if (isError() != otherList.isError()) return false;

    return Objects.equals(getBody(), otherList.getBody());

  }

}
