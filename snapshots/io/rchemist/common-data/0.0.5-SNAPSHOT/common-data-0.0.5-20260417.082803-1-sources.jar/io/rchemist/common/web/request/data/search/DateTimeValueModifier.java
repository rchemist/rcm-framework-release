/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.web.request.data.FilterItem;
import java.time.Instant;
import java.time.LocalDateTime;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class DateTimeValueModifier implements SearchFieldModifier {

  public static final int ORDER = 300;

  @Override
  public FilterItem validate(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    boolean multipleTarget = filterItem.isMultipleFilterValue();

    boolean singleTarget = filterItem.isStrictSingleFilterValue();

    boolean target = (multipleTarget || singleTarget) &&
        filterItem.getFieldType() != null &&
        (filterItem.getValue() != null || ArrayUtils.isNotEmpty(filterItem.getValues()));

    if (target) {
      Class<?> fieldType = filterItem.getFieldType();

      // fieldType이 String 이 아닌 경우 filterItem의 value를 fieldType으로 변환한다.
      if(Instant.class.equals(fieldType)) {

        if (multipleTarget) {

          String value1 = String.valueOf(filterItem.getValues()[0]);
          String value2 = String.valueOf(filterItem.getValues()[1]);

          Instant startDate = InstantUtil.parseStartOfDayIfAbsentTime(value1);
          Instant endDate = InstantUtil.parseEndOfDayIfAbsentTime(value2);

          filterItem.setValues(new Object[]{startDate, endDate});

        } else {

          Instant instant = InstantUtil.parseStartOfDayIfAbsentTime(filterItem.getValue());
          filterItem.setValue(instant);

        }


      }else if (LocalDateTime.class.equals(fieldType)) {

        if (multipleTarget) {
          LocalDateTime startDate = LocalDateTimeUtil.parseStartOfDayIfAbsentTime(filterItem.getValues()[0]);
          LocalDateTime endDate = LocalDateTimeUtil.parseEndOfDayIfAbsentTime(filterItem.getValues()[1]);

          filterItem.setValues(new Object[]{startDate, endDate});

        } else {

          LocalDateTime localDateTime = LocalDateTimeUtil.parseStartOfDayIfAbsentTime(filterItem.getValue());
          filterItem.setValue(localDateTime);

        }

      }
    }

    return filterItem;
  }

  @Override
  public int getOrder() {
    return ORDER;
  }

}
