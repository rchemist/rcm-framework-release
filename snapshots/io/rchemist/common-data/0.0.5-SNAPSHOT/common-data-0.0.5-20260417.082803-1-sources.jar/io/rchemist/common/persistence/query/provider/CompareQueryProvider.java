/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.provider;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.BooleanUtil;
import io.rchemist.common.util.DateUtil;
import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CompareQueryProvider implements QueryParseProvider {

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.COMPARE);
  }

  @Override
  public <T> Predicate getPredicate(CriteriaBuilder builder, QueryConditionType condition,
      Path<T> path, Object value, List<?> values) {

    Predicate predicate = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    Class<?> javaType = path.getJavaType();

    if(value == null || shouldComputeEqual(value)){
      // COMPARE 대상 값이 없거나 ENUM_TYPE, Boolean 에 대해 Compare 타입의 질의를 한다면 equals 로 처리한다.
      predicate = QueryHelper.getConditionPredicate(builder,
          condition.isNegative() ?
          QueryConditionType.EQUAL : QueryConditionType.NOT_EQUAL, path, value, null);
    }else{

      if(isCondition(condition, QueryConditionType.LESS_THAN, QueryConditionType.NOT_LESS_THAN)){

        predicate = getLessThanPredicate(builder, path, javaType, value);
        
      }else if(isCondition(condition, QueryConditionType.LESS_THAN_EQUAL, QueryConditionType.NOT_LESS_THAN_EQUAL)){

        predicate = getLessThanEqualsPredicate(builder, path, javaType, value);

      }else if(isCondition(condition, QueryConditionType.GREATER, QueryConditionType.NOT_GREATER)){

        predicate = getGreaterThanPredicate(builder, path, javaType, value);

      }else if(isCondition(condition, QueryConditionType.GREATER_THAN_EQUAL, QueryConditionType.NOT_GREATER_THAN_EQUAL)){

        predicate = getGreaterThanEqualsPredicate(builder, path, javaType, value);

      }

    }

    return (predicate == null) ? null : (condition.isNegative()) ? predicate.not() : predicate;
  }

  private <T> Predicate getLessThanPredicate(CriteriaBuilder builder, Path<T> path, Class<?> javaType, Object value) {
    Predicate predicate = null;
    if(String.class.isAssignableFrom(javaType) || String.class.isAssignableFrom(value.getClass())){
      // 공통 로직 적용
    }else {
      if(Long.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value.getClass())){
        predicate = builder.lessThan(path.as(Long.class), NumberUtil.getLong(value));
      }else if(Integer.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.lessThan(path.as(Integer.class), NumberUtil.getInteger(String.valueOf(value)));
      }else if(Double.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.lessThan(path.as(Double.class), NumberUtil.getDouble(value));
      }else if(java.util.Date.class.isAssignableFrom(javaType)){
        java.util.Date dateValue1 = DateUtil.getDate(value);
        if(dateValue1 != null){
          predicate = builder.lessThan(path.as(Date.class), dateValue1);
        }
      }else if(LocalDateTime.class.isAssignableFrom(javaType)){
        LocalDateTime localDateTime1 = LocalDateTimeUtil.getLocalDateTime(value);
        if(localDateTime1 != null){
          predicate = builder.lessThan(path.as(LocalDateTime.class), localDateTime1);
        }
      }else if (Instant.class.isAssignableFrom(javaType)) {
        Instant instant1 = InstantUtil.getInstant(value);
        if(instant1 != null){
          predicate = builder.lessThan(path.as(Instant.class), instant1);
        }
      }
    }

    if(predicate == null){
      predicate = builder.lessThan(path.as(String.class), StringUtil.getString(value));
    }
    return predicate;
  }

  private <T> Predicate getLessThanEqualsPredicate(CriteriaBuilder builder, Path<T> path, Class<?> javaType, Object value) {
    Predicate predicate = null;
    if(String.class.isAssignableFrom(javaType) || String.class.isAssignableFrom(value.getClass())){
      // 공통 로직 적용
    }else {
      if(Long.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value.getClass())){
        predicate = builder.lessThanOrEqualTo((Expression<Long>) path, NumberUtil.getLong(value));
      }else if(Integer.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.lessThanOrEqualTo((Expression<Integer>) path, NumberUtil.getInteger(String.valueOf(value)));
      }else if(Double.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.lessThanOrEqualTo((Expression<Double>) path, NumberUtil.getDouble(value));
      }else if(java.util.Date.class.isAssignableFrom(javaType)){
        java.util.Date dateValue1 = DateUtil.getDate(value);
        if(dateValue1 != null){
          predicate = builder.lessThanOrEqualTo((Expression<Date>) path, dateValue1);
        }
      }else if(LocalDateTime.class.isAssignableFrom(javaType)){
        LocalDateTime localDateTime1 = LocalDateTimeUtil.getLocalDateTime(value);
        if(localDateTime1 != null){
          predicate = builder.lessThanOrEqualTo((Expression<LocalDateTime>) path, localDateTime1);
        }
      } else if (Instant.class.isAssignableFrom(javaType)) {
        Instant instant1 = InstantUtil.getInstant(value);
        if(instant1 != null){
          predicate = builder.lessThanOrEqualTo((Expression<Instant>) path, instant1);
        }
      }
    }

    if(predicate == null){
      predicate = builder.lessThanOrEqualTo((Expression<String>) path, StringUtil.getString(value));
    }
    return predicate;
  }

  private <T> Predicate getGreaterThanPredicate(CriteriaBuilder builder, Path<T> path, Class<?> javaType, Object value) {
    Predicate predicate = null;
    if(String.class.isAssignableFrom(javaType) || String.class.isAssignableFrom(value.getClass())){
      // 공통 로직 적용
    }else {
      if(Long.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value.getClass())){
        predicate = builder.greaterThan((Expression<Long>) path, NumberUtil.getLong(value));
      }else if(Integer.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.greaterThan((Expression<Integer>) path, NumberUtil.getInteger(String.valueOf(value)));
      }else if(Double.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.greaterThan((Expression<Double>) path, NumberUtil.getDouble(value));
      }else if(java.util.Date.class.isAssignableFrom(javaType)){
        java.util.Date dateValue1 = DateUtil.getDate(value);
        if(dateValue1 != null){
          predicate = builder.greaterThan((Expression<Date>) path, dateValue1);
        }
      }else if(LocalDateTime.class.isAssignableFrom(javaType)){
        LocalDateTime localDateTime1 = LocalDateTimeUtil.getLocalDateTime(value);
        if(localDateTime1 != null){
          predicate = builder.greaterThan((Expression<LocalDateTime>) path, localDateTime1);
        }
      }else if(Instant.class.isAssignableFrom(javaType)) {
        Instant instant1 = InstantUtil.getInstant(value);
        if(instant1 != null){
          predicate = builder.greaterThan((Expression<Instant>) path, instant1);
        }
      }
    }

    if(predicate == null){
      predicate = builder.greaterThan((Expression<String>) path, StringUtil.getString(value));
    }
    return predicate;
  }

  private <T> Predicate getGreaterThanEqualsPredicate(CriteriaBuilder builder, Path<T> path, Class<?> javaType, Object value) {
    Predicate predicate = null;
    if(String.class.isAssignableFrom(javaType) || String.class.isAssignableFrom(value.getClass())){
      // 공통 로직 적용
    }else {
      if(Long.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value.getClass())){
        predicate = builder.greaterThanOrEqualTo((Expression<Long>) path, NumberUtil.getLong(value));
      }else if(Integer.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.greaterThanOrEqualTo((Expression<Integer>) path, NumberUtil.getInteger(String.valueOf(value)));
      }else if(Double.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value)){
        predicate = builder.greaterThanOrEqualTo((Expression<Double>) path, NumberUtil.getDouble(value));
      }else if(java.util.Date.class.isAssignableFrom(javaType)){
        java.util.Date dateValue1 = DateUtil.getDate(value);
        if(dateValue1 != null){
          predicate = builder.greaterThanOrEqualTo((Expression<Date>) path, dateValue1);
        }
      }else if(LocalDateTime.class.isAssignableFrom(javaType)){
        LocalDateTime localDateTime1 = LocalDateTimeUtil.getLocalDateTime(value);
        if(localDateTime1 != null){
          predicate = builder.greaterThanOrEqualTo((Expression<LocalDateTime>) path, localDateTime1);
        }
      }else if(Instant.class.isAssignableFrom(javaType)) {
        Instant instant1 = InstantUtil.getInstant(value);
        if(instant1 != null){
          predicate = builder.greaterThanOrEqualTo((Expression<Instant>) path, instant1);
        }
      }
    }

    if(predicate == null){
      predicate = builder.greaterThanOrEqualTo((Expression<String>) path, StringUtil.getString(value));
    }
    return predicate;
  }

  private boolean isCondition(QueryConditionType condition, QueryConditionType... types) {
    return (ArrayUtils.contains(types, condition));
  }

  private boolean shouldComputeEqual(Object value) {
    return value instanceof EnumType
        || (BooleanUtil.isBoolean(value));
  }

  @Override
  public int getOrder() {
    return 300;
  }

  
}
