/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ChannelType extends EnumType<ChannelType> {

  public static final ChannelType PC = new ChannelType(10, "PC", "PC", "PC", "global.type.channel.type.pc");
  public static final ChannelType MOBILE_WEB = new ChannelType(20, "MOBILE_WEB", "Mobile Web", "Mobile web", "global.type.channel.type.mobile.web");
  public static final ChannelType MOBILE_APP = new ChannelType(30, "MOBILE_APP", "Mobile App", "Mobile Application", "global.type.channel.type.mobile.app");
  public static final ChannelType ADMIN = new ChannelType(40, "ADMIN", "ADMIN Panel", "Admin Console Panel", "global.type.channel.type.admin");
  public static final ChannelType API = new ChannelType(50, "API", "API", "API(Application Program Interface)", "global.type.channel.type.api");
  public static final ChannelType OTHERS = new ChannelType(60, "OTHERS", "OTHERS", "Other channels", "global.type.channel.type.others");

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public ChannelType(int order, String key, String value, String description, String messageKey) {
    super(order, key, value, description, messageKey);
  }
}
