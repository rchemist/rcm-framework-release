/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.ArrayUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 *
 * TODO
 * 현재 between 이나 subQuery 등의 조건 처리가 안 되고 있다.
 * <p>
 * Created by kunner
 **/
public class SqlQueryParser {

  private static final Pattern NOT_BETWEEN_PATTERN = Pattern.compile("([\\w.]+)\\s+not between\\s+'([^']+)'\\s+and\\s+'([^']+)'", Pattern.CASE_INSENSITIVE);
//private static final Pattern BETWEEN_PATTERN = Pattern.compile("([\\w.]+)\\s+between\\s+'([^']+)'\\s+and\\s+'([^']+)'", Pattern.CASE_INSENSITIVE);
private static final Pattern BETWEEN_PATTERN = Pattern.compile(
    "(\\w+|[\\w.]+)\\s+between\\s+'([^']+)'\\s+and\\s+'([^']+)'",
    Pattern.CASE_INSENSITIVE
);


  private static final Pattern NOT_IN_PATTERN = Pattern.compile("([\\w.]+)\\s+not in\\s+\\(([^)]+)\\)", Pattern.CASE_INSENSITIVE);
  private static final Pattern IN_PATTERN = Pattern.compile("([\\w.]+)\\s+in\\s+\\(([^)]+)\\)", Pattern.CASE_INSENSITIVE);
  private static final Pattern CONDITION_PATTERN = Pattern.compile("([\\w.]+)\\s*(=|!=|<>|>=|>|<=|<|like|not like|starts with|not starts with|ends with|not ends with|between|not between)\\s*('?[^\\s'()]+)?\\s*('([^']*)'|[0-9]+)?", Pattern.CASE_INSENSITIVE);


  public static SearchForm parseQuery(String query) {
    SearchForm searchForm = new SearchForm();
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = new LinkedHashMap<>();

    // Tokenize the query into AND and OR conditions
    List<String> tokens = tokenize(query);

    // Parse tokens into FilterItems
    ConditionOperatorType currentOperator = ConditionOperatorType.AND;

    for (String token : tokens) {
      if (token.equalsIgnoreCase("and")) {
        currentOperator = ConditionOperatorType.AND;
      } else if (token.equalsIgnoreCase("or")) {
        currentOperator = ConditionOperatorType.OR;
      } else {
        FilterItem filterItem = createFilterItem(token);

        if (filters.containsKey(currentOperator)) {
          filters.put(currentOperator, ArrayUtil.addArray(filters.get(currentOperator), filterItem));
        } else {
          filters.put(currentOperator, new FilterItem[]{filterItem});
        }
      }
    }

    searchForm.setFilters(filters);
    return searchForm;
  }

  private static List<String> tokenize(String query) {
    List<String> tokens = new ArrayList<>();
    Matcher matcher = Pattern.compile("(\\S+\\s*(=|!=|>=|<=|>|<| in | not in | between | not between )\\s*'[^']+'|\\S+\\s*(=|!=|>=|<=|>|<| in | not in | between | not between )\\s*\\S+|and|or)", Pattern.CASE_INSENSITIVE).matcher(query);
    while (matcher.find()) {
      tokens.add(matcher.group().trim());
    }
    return tokens;
  }

  private static FilterItem createFilterItem(String condition) {
    Matcher notBetweenMatcher = NOT_BETWEEN_PATTERN.matcher(condition);
    if (notBetweenMatcher.find()) {
      String name = notBetweenMatcher.group(1).trim();
      List<String> values = List.of(notBetweenMatcher.group(2).trim(), notBetweenMatcher.group(3).trim());
      return new FilterItem().withName(name).withValues(values.toArray()).withQueryConditionType(QueryConditionType.BETWEEN);
    }

    Matcher notInMatcher = NOT_IN_PATTERN.matcher(condition);
    if (notInMatcher.find()) {
      String name = notInMatcher.group(1);
      List<String> values = Arrays.asList(notInMatcher.group(2).split("\\s*,\\s*"));
      return new FilterItem().withName(name).withValues(values.toArray()).withQueryConditionType(QueryConditionType.IN);
    }

    Matcher betweenMatcher = BETWEEN_PATTERN.matcher(condition);
    if (betweenMatcher.find()) {
      String name = betweenMatcher.group(1);
      List<String> values = List.of(betweenMatcher.group(2).trim(), betweenMatcher.group(3).trim());
      return new FilterItem().withName(name).withValues(values.toArray()).withQueryConditionType(QueryConditionType.BETWEEN);
    }

    Matcher inMatcher = IN_PATTERN.matcher(condition);
    if (inMatcher.find()) {
      String name = inMatcher.group(1);
      List<String> values = Arrays.asList(inMatcher.group(2).split("\\s*,\\s*"));
      return new FilterItem().withName(name).withValues(values.toArray()).withQueryConditionType(QueryConditionType.IN);
    }

    Matcher matcher = CONDITION_PATTERN.matcher(condition);
    if (matcher.find()) {
      String name = matcher.group(1);
      String operator = matcher.group(2);
      String value = matcher.group(3);
      if (value != null) {
        value = StringUtils.remove(value, "'");
      }

      QueryConditionType queryConditionType = switch (operator.toLowerCase()) {
        case "!=", "<>" -> QueryConditionType.NOT_EQUAL;
        case "like" -> QueryConditionType.LIKE;
        case "not like" -> QueryConditionType.NOT_LIKE;
        case "starts with" -> QueryConditionType.START_WITH;
        case "not starts with" -> QueryConditionType.NOT_START_WITH;
        case "ends with" -> QueryConditionType.END_WITH;
        case "not ends with" -> QueryConditionType.NOT_END_WITH;
        case ">=" -> QueryConditionType.GREATER_THAN_EQUAL;
        case ">" -> QueryConditionType.GREATER;
        case "<=" -> QueryConditionType.LESS_THAN_EQUAL;
        case "<" -> QueryConditionType.LESS_THAN;
        case "not <" -> QueryConditionType.NOT_LESS_THAN;
        case "not <=" -> QueryConditionType.NOT_LESS_THAN_EQUAL;
        case "not >" -> QueryConditionType.NOT_GREATER;
        case "not >=" -> QueryConditionType.NOT_GREATER_THAN_EQUAL;
        case "null" -> QueryConditionType.NULL;
        case "not null" -> QueryConditionType.NOT_NULL;
        default -> QueryConditionType.EQUAL;
      };

      return new FilterItem().withName(name).withValue(value).withQueryConditionType(queryConditionType);
    }
    return null;
  }

  public static void main(String[] args) {
    String query = "userId = 'aaa' or userId = 'bbb' and status >= 'active' and age > 25 and createdAt between '2023-01-01' and '2023-02-01'";
    SearchForm searchForm = parseQuery(query);

    // Print the parsed SearchForm to verify the output
    for (Map.Entry<ConditionOperatorType, FilterItem[]> entry : searchForm.getFilters().entrySet()) {
      System.out.println("Operator: " + entry.getKey());
      for (FilterItem item : entry.getValue()) {
        printFilterItem(item, 1);
      }
    }
  }

  private static void printFilterItem(FilterItem item, int indent) {
    String indentStr = "  ".repeat(indent);
    System.out.println(indentStr + "FilterItem: name=" + item.getName() + ""
        + ", value=" + item.getValue()
        + ", values=" + Arrays.toString(item.getValues()) + ", queryConditionType=" + item.getQueryConditionType());
    if (item.getSubFilters() != null && !item.getSubFilters().isEmpty()) {
      for (Map.Entry<ConditionOperatorType, FilterItem[]> subEntry : item.getSubFilters().entrySet()) {
        System.out.println(indentStr + "  Sub-Operator: " + subEntry.getKey());
        for (FilterItem subItem : subEntry.getValue()) {
          printFilterItem(subItem, indent + 2);
        }
      }
    }
  }
}
