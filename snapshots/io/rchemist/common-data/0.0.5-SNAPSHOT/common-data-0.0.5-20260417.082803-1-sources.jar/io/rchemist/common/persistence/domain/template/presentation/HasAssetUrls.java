/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAssetUrls<T> extends ClassTransformTarget {

  default List<String> getAssetUrls() {
    throw new ClassTransformException();
  }

  default void setAssetUrls(List<String> assetUrls) {
    throw new ClassTransformException();
  }

  default void setAssetUrls(String[] assetUrls) {
    try {
      setAssetUrls(List.of(assetUrls));
    }catch (Exception e) {
      // nothing to do
    }
  }

  default T removeAssetUrl(String... assetUrls) {
    if (assetUrls == null || assetUrls.length == 0) {
      return (T) this;
    }
    getAssetUrls().removeAll(List.of(assetUrls));
    return (T) this;
  }

  default T addAssetUrl(String... assetUrls) {
    if (assetUrls == null || assetUrls.length == 0) {
      return (T) this;
    }
    getAssetUrls().addAll(List.of(assetUrls));
    return (T) this;
  }

  default boolean hasAssetUrls() {
    return getAssetUrls() != null && !getAssetUrls().isEmpty();
  }

  default T withAssetUrls(List<String> assetUrls) {
    setAssetUrls(assetUrls);
    return (T) this;
  }

  default T  withAssetUrls(String... assetUrls) {
    setAssetUrls(assetUrls);
    return (T) this;
  }

}
