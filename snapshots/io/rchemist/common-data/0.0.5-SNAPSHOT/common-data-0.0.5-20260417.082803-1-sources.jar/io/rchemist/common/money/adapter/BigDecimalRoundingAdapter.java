/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.money.adapter;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class BigDecimalRoundingAdapter extends XmlAdapter<String, BigDecimal> {

  @Override
  public BigDecimal unmarshal(String s) throws Exception {
    return new BigDecimal(s);
  }

  @Override
  public String marshal(BigDecimal bigDecimal) throws Exception {
    return bigDecimal.setScale(2, RoundingMode.UP).toString();
  }
}