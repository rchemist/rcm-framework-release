/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.type.RegexType;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAliasGroup<T> extends ClassTransformTarget {

  default String getAliasGroup(){throw new ClassTransformException();}
  default void setAliasGroup(String aliasGroup){
    throw new ClassTransformException();
  }

  default T withAliasGroup(String aliasGroup){
    setAliasGroup(aliasGroup);
    return (T) this;
  }

  default boolean validateAliasGroup(boolean required) {
    if (StringUtils.isNotEmpty(getAliasGroup())) {
      return RegexType.NUMBER_ENGLISH_EXT.validate(getAliasGroup(), required);
    }
    return !required;
  }

  default boolean validateAliasGroup() {
    return validateAliasGroup(true);
  }

}
