/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.DateSearchPreset;
import io.rchemist.common.presentation.type.MaskingType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.RoundingMode;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface AdminField {

  /**
   * 화면에 표시될 이름
   * i18n 을 지원한다.
   * @return
   */
  String name() default "";

  /**
   * 이 값을 입력하지 않아도 자동으로 클래스의 필드명을 propertyName 으로 사용한다.
   * @AdminCollectionField 에서 하위 필드를 직접 지정할 때 사용한다.
   * @return
   */
  String propertyName() default "";

  /**
   * 폼에서 탭 > 그룹 > 필드 표시 순서
   * @return
   */
  int order();

  /**
   * 기본값.
   * 신규 입력 시 기본값을 정의할 수 있다.
   * @return
   */
  String defaultValue() default "";

  /**
   * 이 필드를 목록에 표시할지 여부
   * 엔티티에서 headerField() 값이 true 로 지정된 필드가 하나도 없는 경우
   * fieldType.javaFieldType 에 해당하는 필드 중 첫번째 필드가 자동으로 headerField 로 처리된다.
   * @return
   */
  HeaderField headerField() default @HeaderField(showGrid = false);

  /**
   * 폼에서 어떤 탭에 보여줄지
   * @return
   */
  ViewTab tab() default @ViewTab(order = 1);

  /**
   * 폼 > 탭에서 어떤 필드그룹에 보여줄지
   * @return
   */
  ViewFieldGroup group() default @ViewFieldGroup(order = 1);

  /**
   * 이 필드의 필드 타입 - 실제 클래스의 java type 과 PresentationFieldType.javaFieldType 이 일치해야 한다.
   * 자동 추론 방식은 메타데이터를 추출하는 문제로 성능 이슈가 발생할 수 있으므로 지원하지 않는다.
   * 반드시 설정하도록 제한한다.
   * @return
   */
  PresentationFieldType fieldType();

  /**
   * 이 필드의 PresentationFieldType 이 FOREIGN_KEY 일 때 대상이 되는 class 를 fully qualified class name 으로 입력한다.
   * 입력하지 않아도 추론이 가능하지만,
   * 해당 엔티티가 확장된 경우 가장 마지막에 확장된 엔티티를 기본으로 추론하게 될 것이다.
   * 정확한 엔티티 클래스를 지정해야 할 필요가 있을 때 이 값을 입력하면 된다.
   * @return
   */
  ReferenceFieldView referenceField() default @ReferenceFieldView();

  /**
   * PresentationFieldType 이 ENUMERATION 이거나 ENUMERATION_MULTIPLE 일 때 관련 설정이 필요하다.
   * @return
   */
  Enumeration enumeration() default @Enumeration();

  /**
   * 이 필드의 type 이 PresentationFieldType.CHECKBOX 일 때 체크박스를 가로로 표시할 것인지 세로로 표시할 것인지 설정할 수 있다.
   * 나머지 필드에서는 이 값을 무시한다.
   * @return
   */
  boolean horizontal() default false;

  /**
   * 읽기 전용 필드 여부
   * @return
   */
  boolean readOnly() default false;

  /**
   * 필수값 여부
   * @return
   */
  boolean required() default false;

  /**
   * 필드 숨김 여부 - 실제 필드폼에는 존재하지만 display 만 하지 않는다.
   * @return
   */
  boolean hidden() default false;

  /**
   * 입력폼이 빈값일 때 표시하는 안내 메시지
   * @return
   */
  String placeHolder() default "";

  /**
   * 입력폼에 오류가 발생하면 기본적으로 사용할 안내 메시지
   * 전화번호: 10~11 자 이내의 숫자만 입력하세요. 등과 같은 메시지를 입력한다.
   * @return
   */
  String errorMessage() default "";

  /**
   * 입력폼 하단에 기본 노출하는 설명문구
   * @return
   */
  String helpText() default "";

  /**
   * 필드 번역을 지원하는지 여부
   *
   * - fieldType.javaFieldType 이 STRING 일 때만 지원한다.
   *
   * @return
   */
  boolean translate() default false;

  /**
   * 필드에 마스킹으로 필드값을 감춰야 하는 경우
   * @return
   */
  MaskingOption masking() default @MaskingOption(type = MaskingType.NO_MASK);

  /**
   * 이 필드가 특정값일 때 다른 필드를 display 하거나 hidden 할 수 있다
   * 하지만 대상 필드를 동적으로 변경하고자 할 때는 반드시 같은 탭에 있어야만 한다.
   * 만약 대상 필드가 다른 탭에 있는 경우에는 처음 화면에 진입할 때 hidden 된 채로 변경되지 않을 것이다.
   * @return
   */
  DerivedVisibleValue[] derivedVisible() default {};

  /**
   * 이 필드가 다른 필드에 의해 display 되거나 hidden 될 수 있는지 여부
   *
   * 다른 필드에서 이 필드를 derivedVisible 로 지정한 경우,
   * 이 필드에 dependentVisible = true 가 되어야 한다.
   * 만약 이 값이 false 면 다른 필드에서 derivedVisible 를 지정해도 반영되지 않는다.
   *
   * @return
   */
  boolean dependentVisible() default false;

  /**
   * 필드값을 validation 할 때 사용한다.
   * Admin Controller -> save 할 때 기본적으로 각 엔티티에 정의된 서비스를 이용하지만
   * validation 설정이 되어 있다면 해당 validation provider 를 먼저 실행하고 문제가 없을 때만 실제 save 를 실행한다.
   * @return
   */
  ValidationConfig[] validation() default {};

  /**
   * 입력폼에 입력할 때 정규식 validation 을 적용할 때 사용.
   * ValidationConfig 을 사용하지 않고 쉽게 접근하기 위해 별도로 속성을 추가함
   * @return
   */
  String regexValidation() default "";

  /**
   * 필드가 최초 입력 할 때만 보여지게 하거나, 입력할 때는 보이지 않고 수정할 때만 보여지거나 하게 할 수 있다.
   *
   * 단, hidden() 이 true 일 때는 이 설정과 관계 없이 무조건 hidden 처리된다.
   * ModifiableType.MODIFY_ONLY 인 경우에는 최초 입력 시에는 필드가 hidden 이 된다.
   * ModifiableType.ADD_ONLY 인 경우에는 최초 입력 시에만 입력 가능하고, 수정 때는 READ_ONLY 상태가 된다.
   *
   * @return
   */
  ModifiableType modifiableType() default ModifiableType.ALWAYS;

  /**
   * (optional) 필요에 따라 key/value 형태로 추가 정보를 admin 서비스로 전달할 수 있다.
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * 최소 길이
   * @return
   */
  String minLength() default "";

  /**
   * 최대 길이
   * @return
   */
  String maxLength() default "";

  UploadFile uploadFile() default @UploadFile;

  /**
   * Text 필드인 경우 TextArea 의 높이를 지정할 수 있다.
   * @return
   */
  String height() default "300px";

  /**
   * 이 필드가 숫자를 다루는 경우 +, - 버튼을 표시할 것인지 여부
   * @return
   */
  boolean useStep() default false;

  /**
   * 이 필드가 숫자를 다루는 경우 +, - 버튼을 눌렀을 때 한번에 몇 씩 증감시킬 것인지
   * @return
   */
  String stepValue() default "1";

  /**
   * 이 필드가 decimal 인 경우 scale 을 몇으로 지정할 것인지
   * @return
   */
  int scale() default 2;

  /**
   * 이 필드가 decimal 인 경우 라운딩 처리를 어떻게 할 것인지
   * Money 의 경우에는 io.rchemist.common.money.Money 에 설정된 기본값을 사용하므로 이 값을 무시한다.
   * @return
   */
  RoundingMode rounding() default RoundingMode.HALF_UP;

  /**
   * 이 필드를 표시할 때 필드에 추가할 css class
   * @return
   */
  String[] cssClass() default {};

  CreateForm createForm() default @CreateForm();

  /**
   * 이 필드의 타입이 INLINE_MAP 이면 이 어노테이션 정보를 참조한다.
   * @return
   */
  InlineMap inlineMap() default @InlineMap();

  /**
   * 이 필드가 DateField 이고, HeaderField 인 경우 검색 필터 레이어에서 1일, 3일, 1주일 등의 버튼을 표시할 수 있다.
   */
  DateSearchPreset[] dateSearchPreset() default {
    DateSearchPreset.DAY_1, DateSearchPreset.DAY_3, DateSearchPreset.WEEK_1, DateSearchPreset.MONTH_1
  };

  /**
   * 일괄변경을 지원하는 필드인지 여부 - 필요한 경우에만 false 로 셋팅한다.
   *
   * 이 값이 true 여도,
   *
   * view 화면 기준으로 hidden, readonly 거나 fieldType 이 basicField 가 아니거나, ID 필드인 경우는 supportModifyAll 값을 false 로 인식한다.
   *
   *
   * @return
   */
  boolean supportModifyAll() default true;

  /**
   * TODO 현재 field provider 구현 안 됨
   * 필드가 접힌 채 표시될지 여부
   *
   * 텍스트에어리어나 HTML 에디터와 같이 공간을 많이 차지하는 필드의 경우 처음에는 접혀 있다가 필요할 때만 펼쳐지도록 처리할 수 있다.
   * @return
   */
  boolean collapsed() default false;

}
