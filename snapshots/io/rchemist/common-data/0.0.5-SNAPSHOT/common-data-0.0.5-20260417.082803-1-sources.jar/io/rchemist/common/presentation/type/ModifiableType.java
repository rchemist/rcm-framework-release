/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.i18n.service.MessageSourceHelper;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum ModifiableType {

  ALWAYS(true, false, 1, "ModifiableType_Always"),     // 언제나 입력 가능
  ADD_ONLY(true, true, 2, "ModifiableType_AddOnly"),    // 최초 등록 시에만 입력 가능, 이후 수정 불가
  VIEW_HIDDEN(true, true, 3, "ModifiableType_ViewHidden"),    // 최초 등록 시에만 입력 가능, 이후 숨김처리
  HIDDEN(false, true, 4, "ModifiableType_Hidden"),    // 쓰기 보기 화면에는 안 나오고 목록에만 표시
  MODIFY_ONLY(false, false, 5, "ModifiableType_ModifyOnly"),    // 최초 등록 시에는 보이지 않고 수정 화면에서부터 확인 가능
  VIEW_ONLY(false, true, 6, "ModifiableType_ViewOnly"),  // 항상 조회만 가능
  NONE(true, false, 6, "ModifiableType_None")   // overrideFieldMetadata 에서만 사용
  ;

  @Getter
  private final boolean createForm;

  @Getter
  private final int order;

  @Getter
  private final String description;

  @Getter
  private final boolean readOnlyOnView;

  ModifiableType(boolean createForm, boolean readOnlyOnView, int order, String description) {
    this.createForm = createForm;
    this.order = order;
    this.description = description;
    this.readOnlyOnView = readOnlyOnView;
  }

  public static LinkedHashMap<String, String> getOptionValues(){
    List<ModifiableType> types = Arrays.asList(ModifiableType.values());
    Collections.sort(types, Comparator.comparing(ModifiableType::getOrder));
    LinkedHashMap<String, String> map = new LinkedHashMap<>();
    for(ModifiableType type : types){
      String id = type.name();
      String name = MessageSourceHelper.getMessage(type.getDescription());
      map.put(id, name);
    }
    return map;
  }

}
