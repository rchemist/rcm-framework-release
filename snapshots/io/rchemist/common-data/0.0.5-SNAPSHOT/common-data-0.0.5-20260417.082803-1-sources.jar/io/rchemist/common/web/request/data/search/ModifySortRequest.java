/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class ModifySortRequest {

  private final EntityBean<?> entityBean;
  @Setter
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> filters;
  @Setter
  private List<SortEntry> sortEntries;
  private final boolean hibernateSearch;

  private List<SortFieldModifier> sortFieldModifiers = new ArrayList<>();

  public ModifySortRequest(EntityBean<?> entityBean,
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters,
      List<SortEntry> sortEntries, boolean hibernateSearch) {
    this.entityBean = entityBean;
    this.filters = filters;
    this.sortEntries = sortEntries;
    this.hibernateSearch = hibernateSearch;
  }

  public ModifySortRequest withFilters(
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters) {
    this.filters = filters;
    return this;
  }

  public ModifySortRequest withSortEntries(
      List<SortEntry> sortEntries) {
    this.sortEntries = sortEntries;
    return this;
  }

  public ModifySortRequest withSortFieldModifiers(
      List<SortFieldModifier> sortFieldModifiers) {
    this.sortFieldModifiers = sortFieldModifiers;
    return this;
  }
}
