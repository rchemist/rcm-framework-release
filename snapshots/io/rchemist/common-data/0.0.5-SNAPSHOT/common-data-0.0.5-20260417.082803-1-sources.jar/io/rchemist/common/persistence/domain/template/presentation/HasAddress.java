/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.embedded.IAddress;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAddress<T> extends ClassTransformTarget {

  default String getCountry() {
    throw new ClassTransformException();
  }

  default void setCountry(String country) {
    throw new ClassTransformException();
  }

  default String getState() {
    throw new ClassTransformException();
  }

  default void setState(String state) {
    throw new ClassTransformException();
  }

  default String getCity() {
    throw new ClassTransformException();
  }

  default void setCity(String city) {
    throw new ClassTransformException();
  }

  default String getAddress1() {
    throw new ClassTransformException();
  }

  default void setAddress1(String address1) {
    throw new ClassTransformException();
  }

  default String getAddress2() {
    throw new ClassTransformException();
  }

  default void setAddress2(String address2) {
    throw new ClassTransformException();
  }

  default String getAddressDetail() {
    throw new ClassTransformException();
  }

  default void setAddressDetail(String addressDetail) {
    throw new ClassTransformException();
  }

  default String getPostalCode() {
    throw new ClassTransformException();
  }

  default void setPostalCode(String postalCode) {
    throw new ClassTransformException();
  }

  default void setAddress(IAddress address){
    if(address == null){
      setAddress1(null);
      setAddress2(null);
      setAddressDetail(null);
      setCity(null);
      setCountry(null);
      setPostalCode(null);
      setState(null);
    }else{
      setAddress1(address.getAddress1());
      setAddress2(address.getAddress2());
      setAddressDetail(address.getAddressDetail());
      setCity(address.getCity());
      setCountry(address.getCountry());
      setPostalCode(address.getPostalCode());
      setState(address.getState());
    }
  }
  
  default T withAddress1(String address1){
    setAddress1(address1);
    return (T) this;
  }

  default T withCountry(String country) {
    setCountry(country);
    return (T) this;
  }

  default T withState(String state) {
    setState(state);
    return (T) this;
  }

  default T withCity(String city) {
    setCity(city);
    return (T) this;
  }

  default T withAddress2(String address2) {
    setAddress2(address2);
    return (T) this;
  }

  default T withAddressDetail(String addressDetail) {
    setAddressDetail(addressDetail);
    return (T) this;
  }

  default T withPostalCode(String postalCode) {
    setPostalCode(postalCode);
    return (T) this;
  }

  default T withAddress(IAddress address){
    setAddress(address);
    return (T) this;
  }
  
}
