/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation.type;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum EntityStatusEnumType {

  ALL("ALL", "Create, Update, Remove", ""),     // 실제 WebhookType 으로 인식하지는 않고, Bootstrap 시점에 CREATE, UPDATE, REMOVE 로 변경한다
  CREATE("CREATE", "When ::ENTITY_NAME:: is created", "global.type.webhook.type.::ENTITY_NAME::.created"),
  UPDATE("UPDATE", "When ::ENTITY_NAME:: is updated", "global.type.webhook.type.::ENTITY_NAME::.updated"),
  REMOVE("REMOVE", "When ::ENTITY_NAME:: is removed", "global.type.webhook.type.::ENTITY_NAME::.removed"),
  NONE("CUSTOM", "Custom", "Custom Type");

  EntityStatusEnumType(String type, String description, String messageKey){
    this.type = type;
    this.description = description;
  }

  // class transformer에서 이 key를 replace 처리 한다
  public static final String ENTITY_SPLIT_CODE = "::ENTITY_NAME::";

  protected String type;
  protected String description;
  protected String messageKey;

  public String getType() {
    return type;
  }

  public String getDescription() {
    return description;
  }

  public String getMessageKey(){ return messageKey; }

}
