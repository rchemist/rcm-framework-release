/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.FormActionType;
import io.rchemist.common.presentation.type.MainActionType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface AdminEntity {

  String name();

  /**
   * Detail View 에서 SectionHeader 에 표시될 이름
   * @return
   */
  String headerProperty() default "id";

  /**
   * 이 엔티티가 목록에서 표시될 때 어떤 버튼을 기본적으로 보여 줄 것인지
   * @return
   */
  MainActionType[] overrideMainActions() default {MainActionType.ADD};

  /**
   * 이 엔티티가 EntityForm 에 표시될 때 어떤 버튼을 기본적으로 보여 줄 것인지
   * @return
   */
  FormActionType[] overrideEntityFormActions() default {FormActionType.SAVE, FormActionType.DELETE};

  /**
   * 추가 정보
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * 이 엔티티를 삭제할 때 다른 엔티티의 참조 관계를 확인해야 한다면 해당 클래스의 full name 과 이 엔티티가 참조된 propertyName 을 입력한다.
   * @return
   */
  RestrictOnDelete[] restrictOnDelete() default {};

  /**
   * 이 엔티티가 수정되거나 삭제될 때 캐시를 control 해야 하는 경우 해당 정보를 설정한다.
   * @return
   */
  EvictCache[] evictCaches() default {};

  /**
   * 이 엔티티를 EXPORT / IMPORT 할 수 있는지 설정
   * @return
   */
  DataTransfer dataTransfer() default @DataTransfer();

  /**
   * 목록에서 전체 삭제를 지원하는지 여부
   * @return
   */
  boolean supportDeleteAll() default true;

  /**
   * 커스텀필드를 활성화 하려면 반드시 Attribute 를 가지고 있어야 하며,
   * SearchForm 에 이 정보를 넣어야 한다.
   *
   * @return
   */
  CustomFieldSupport customField() default @CustomFieldSupport(value = "", parentId = "");


  /**
   * 이 엔티티가 HibernateSearch 를 지원하는 경우
   * Search 정보를 갱신할 때 사용하는 Mass Indexer beanname 을 적어 준다.
   * @return
   */
  MassIndexer massIndexer() default @MassIndexer();

  /**
   * 읽기 전용인지 여부
   * @return
   */
  boolean readOnly() default false;

  /**
   * 헤더필드를 AdminEntity 수준에서 재정의할 수 있다
   * {propertyName1, propertyName2, propertyName3, ...}
   * @return
   */
  String[] overrideHeaderFields() default {};

  /**
   * entityClass 가 activeHistory 를 이력으로 관리할 지 여부 - SoftDelete 나 HasActive 를 상속한 경우 이 값이 false 여도 항상 true 가 된다.
   * @return
   */
  boolean activeHistory() default false;

  /**
   * revisionHistory 를 이력으로 관리할 지 여부
   * @return
   */
  boolean revisionHistory() default true;

  /**
   * HiddenHistory 를 이력으로 관리할 지 여부
   * @return
   */
  boolean hiddenHistory() default false;

  /**
   * Has** 인터페이스로 만들어진 Entity Class 에서 특정 필드의 속성을 변경하고 싶을 때 사용한다.
   * @return
   */
  OverrideMetadata[] overrideFieldMetadata() default {};

  /**
   * ServiceMapping, SERVICE_ID 를 @AdminEntity 단위로 관리할 수 있다.
   * @return
   */
  String serviceId() default "";

  /**
   * 댓글을 지원하는 모듈인지 여부
   * @return
   */
  boolean supportComment() default false;

  /**
   * 일괄 변경 관련
   * @return
   */
  ModifyAll modifyAll() default @ModifyAll();

}
