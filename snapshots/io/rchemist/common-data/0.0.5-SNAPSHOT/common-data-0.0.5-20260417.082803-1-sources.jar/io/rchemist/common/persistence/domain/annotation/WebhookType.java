/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import io.rchemist.common.persistence.domain.annotation.type.EntityStatusEnumType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Target({ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface WebhookType {

  /**
   * CustomType 에 대한 key
   * @return
   */
  String alias();

  /**
   * 엔티티의 어떤 시점에 대한 커스텀 타입인지
   * @return
   */
  EntityStatusEnumType type();

  /**
   * 관리도구에 표시될 FriendlyName
   * @return
   */
  String friendlyName();

  /**
   * i18n 번역을 위한 messageKey
   * @return
   */
  String messageKey() default "";

  /**
   * 만약 이 타입이 엔티티의 특정 필드에 따라 선택적으로 처리되기를 원한다면 mvelExpression 을 입력하면 된다.
   * 이에 대한 자세한 설명은 WebhookEnabled 의 주석을 참고하라.
   * @return
   */
  String mvelExpression() default "";

}
