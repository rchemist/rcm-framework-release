/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasSiteMapping.class)
@Getter
@Setter
public class HasSiteMappingImpl {

  // Admin 에서 Site 를 매핑시킬 때 사용하는 siteId
  // CreateForm/UpdateForm 에는 siteAlias 가 아니라 siteId 가 넘어 오는 것이 자연스럽기 때문이다.
  protected String siteId;

}
