/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.dto;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.util.EnumTypeUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@AllArgsConstructor
@Builder
public class RestrictSearchField implements Serializable {

  private String name;

  private Class<? extends EnumType<?>> enumTypeClass;

  @Builder.Default
  private Map<String, String> alternates = new HashMap<>();

  public boolean isEnumType(){
    return enumTypeClass != null;
  }

  public RestrictSearchField addAlternates(String key, String value){
    if(this.alternates == null)
      this.alternates = new HashMap<>();
    this.alternates.put(key, value);
    return this;
  }

  public RestrictSearchField removeAlternates(String key){
    if(this.alternates == null)
      return this;

    this.alternates.remove(key);
    return this;
  }

  private String[] getAlternativeValues(String[] originValues){
    if(MapUtils.isEmpty(this.alternates))
      return originValues;

    List<String> newValues = new ArrayList<>();
    for(String val : originValues){
      if(alternates.containsKey(val)){
        String newValue = getProperValue(val);
        if(StringUtils.isNotBlank(newValue)){
          newValues.add(newValue);
        }
      }
    }
    return newValues.toArray(new String[newValues.size()]);
  }

  private String getProperValue(String value){
    if(MapUtils.isEmpty(this.alternates))
      return value;

    String type = this.alternates.get(value);

    if(type == null)
      return null;

    if(isEnumType()){
      return EnumTypeUtil.getType(EnumTypeUtil.getEnumType(enumTypeClass, type));
    }else{
      return type;
    }
  }

  public SearchField getAlternativeSearchField(SearchField searchField){
    if(!searchField.getName().equals(name))
      return null;

    boolean add = false;

    if(searchField.getName().equals(name)){
      if(ArrayUtils.isNotEmpty(searchField.getValues())){
        String[] originValues = searchField.getValues();
        String[] newValues = getAlternativeValues(originValues);
        if(ArrayUtils.isNotEmpty(newValues)){
          searchField.setValues(newValues);
          add = true;
        }
      }else{
        String originValue = searchField.getValue();
        String newValue = getProperValue(originValue);

        if(newValue != null){
          searchField.addValues(newValue);
          add = true;
        }
      }
    }

    if(add){
      return searchField;
    }else{
      return null;
    }
  }

}
