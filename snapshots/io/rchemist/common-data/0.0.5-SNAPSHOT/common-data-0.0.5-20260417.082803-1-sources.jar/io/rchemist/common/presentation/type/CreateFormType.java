/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum CreateFormType {

  PRE_VALIDATE(-100, "PreValidateCreateForm", "PreValidateCreateForm_Subtitle", true)
  , REQUIRED(1, "RequiredCreateForm", "RequiredCreateForm_Subtitle", true)
  , USER(5, "UserCreateForm", "UserCreateForm_Subtitle", true)
  , REWARD(10, "RewardCreateForm", "RewardCreateForm_Subtitle", false)
  , RESTRICTION(15, "RestrictionCreateForm", "RestrictionCreateForm_Subtitle", true)
  , OPTIONAL(20, "OptionalCreateForm", "OptionalCreateForm_Subtitle", false)
  , ADDRESS(30, "AddressCreateForm", "AddressCreateForm_Subtitle", true)
  , ADMIN_UI(100, "AdminUICreateForm", "AdminUICreateForm_Subtitle", false)
  , LIST_GRID(100, "ListGridCreateForm", "ListGridCreateForm_Subtitle", false)
  , VALIDATION(200, "ValidationCreateForm", "ValidationCreateForm_Subtitle", false)
  , CUSTOM_FIELD(300, "CustomFieldCreateForm", "CustomFieldCreateForm_Subtitle", false)
  , AUTHORITY(400, "AuthorityCreateForm", "AuthorityCreateForm_Subtitle", false)
  , DEFAULT(Integer.MAX_VALUE, "Default", "Default", false)
  , NOT_SET(Integer.MAX_VALUE, "NOT_SET", "NOT_SET", false)   // override field metadata 때문에 빈 값으로 사용하기 위해 추가

  ;

  CreateFormType(int order, String title, String subTitle, boolean required) {
    this.order = order;
    this.title = title;
    this.subTitle = subTitle;
    this.required = required;
  }

  @Getter
  private final int order;

  @Getter
  private final String title;

  @Getter
  private final String subTitle;

  @Getter
  private final boolean required;

}
