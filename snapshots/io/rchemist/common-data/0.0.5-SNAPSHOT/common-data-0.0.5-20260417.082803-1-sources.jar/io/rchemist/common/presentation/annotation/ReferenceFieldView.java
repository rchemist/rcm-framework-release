/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface ReferenceFieldView {

  /**
   * 이 필드의 PresentationFieldType 이 FOREIGN_KEY 일 때 대상이 되는 class 를 fully qualified class name 으로 입력한다.
   * 입력하지 않아도 추론이 가능하지만,
   * 해당 엔티티가 확장된 경우 가장 마지막에 확장된 엔티티를 기본으로 추론하게 될 것이다.
   * 정확한 엔티티 클래스를 지정해야 할 필요가 있을 때 이 값을 입력하면 된다.
   * @return
   */
  String foreignKeyClass() default "";

  /**
   * 엔티티에서 이 참조 엔티티를 표시할 때 어떤 필드값을 기본으로 사용할 것인지
   * @return
   */
  String displayProperty() default "name";

  /**
   * 엔티티에서 이 참조 엔티티를 표시할 때 어떤 필드값을 기본으로 사용할 것인지
   * @return
   */
  String idProperty() default "id";

  /**
   * ID 가 어떤 타입으로 지정되어 있는지 - 기본은 STRING
   * @return
   */
  Class<?> idClass() default String.class;

  /**
   * 현재 버전에서는 어차피 매핑을 AdminEntityService 에서 수동으로 해 줄 것이므로
   * XREF 에까지 굳이 관심을 둘 필요가 없다.
   * 서비스 구현 단계에서 property 를 가지고 구분하면 된다.
   *
   * Xref 매핑일 경우 true
   * @return
   *
   *
   *//*
  boolean xrefMapping() default false;

  *//**
   * Xref 매핑 테이블
   * @return
   *//*
  String xrefClass() default "";*/

  /**
   * TODO 해당 로직이 구현되어 있지 않음(2022-07-23)
   * 대상 엔티티를 조회할 때 함께 넘겨야 하는 파라미터가 있다면 해당 값을 참조할 프로퍼티를 지정한다.
   * @return
   */
  String requiredParameters() default "";

  /**
   * (Optional) 참조 Entity 를 lookup 할 때 attribute 를 추가로 정의해 줄 수 있다.
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * target class 가 adminEntityService 에 지정된 entityClass 가 아닌 경우 이 Reference 를 처리할 entityService 를 직접 지정한다.
   * adminEntityService 에 지정한 entityClass 의 fully classpath 를 지정한다.
   * @return
   */
  String serviceEntityClass() default "";

  /**
   * HasUserImpl 에서처럼 userName 에 @AdminField 가 걸려 있는데,
   * 실제 User 의 id value 는 userId 인 경우
   * @AdminField 가 걸려 있는 필드값은 displayValue 로 쓰고 value 는 valueProperty 가 가리키는 필드값이 되도록 설정한다.
   * @return
   */
  String valueProperty() default "";

  /**
   * @AdminField 가 붙어 있는 필드값은 value 로 쓰고
   * 이 어노테이션이 가리키는 필드값을 displayValue 로 사용할 수 있다.
   * @return
   */
  String displayValueProperty() default "";

  /**
   * 오버라이드 됐는지 여부
   * @return
   */
  boolean overridden() default false;

}
