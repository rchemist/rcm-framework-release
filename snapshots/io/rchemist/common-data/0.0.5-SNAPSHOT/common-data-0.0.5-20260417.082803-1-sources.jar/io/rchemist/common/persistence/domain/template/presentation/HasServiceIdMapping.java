/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.data.IServiceMapping;
import io.rchemist.common.persistence.domain.data.ServiceIdentifier;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.StringUtil;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasServiceIdMapping<T> extends ClassTransformTarget, ServiceIdentifier {

  String GENERAL_TYPE = "GENERAL";
  String SPLIT = "||";
  String BLANK = "_";

  default String getServiceId(){
    throw new ClassTransformException();
  }

  default void setServiceId(String serviceId){
    throw new ClassTransformException();
  }
  default T withServiceId(String serviceId){
    setServiceId(serviceId);
    return (T) this;
  }

  default void setServiceIdentifier(ServiceIdentifier serviceIdentifier){
    setServiceId(serviceIdentifier.getServiceId());
  }

  default ServiceIdentifier getServiceIdentifier(){
    return ServiceIdentifier.create(getServiceId(), null, null, null);
  }

  default T withServiceIdentifier(ServiceIdentifier identifier){
    setServiceId(identifier.getServiceId());
    return (T) this;
  }

  @Override
  default String getServiceEntityId() {
    return null;
  }

  @Override
  default String getServiceAlias() {
    return null;
  }

  @Override
  default void setServiceEntityId(String serviceEntityId) {

  }

  @Override
  default void setServiceAlias(String serviceAlias) {
  }

  @Override
  default void setServiceMapping(IServiceMapping serviceMapping){
    setServiceId(serviceMapping.getServiceId());
  }

  @Override
  default boolean validateServiceMapping() {
    return StringUtil.isNotEmpty(getServiceId());
  }

  @Override
  default String getParentServiceEntityId(){
    return null;
  }

  @Override
  default void setParentServiceEntityId(String parentServiceEntityId){

  }
}
