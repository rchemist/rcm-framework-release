/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaBuilder.Case;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import lombok.EqualsAndHashCode;
import org.springframework.data.domain.Sort.Direction;

/**
 * 우선순위 정렬 정보를 나타내는 클래스
 * 특정 값을 가진 레코드를 우선적으로 정렬한 후, 나머지를 일반 정렬하는 방식
 */
@EqualsAndHashCode(callSuper = true)
public class PrioritySortInfo extends SortInfo {

    private final List<Object> priorityValues;

    /**
     * 기본 생성자 - priorityValue와 direction만 지정 (하위 호환성)
     */
    @JsonCreator
    public PrioritySortInfo(
            @JsonProperty("priorityValue") Object priorityValue,
            @JsonProperty("direction") Direction direction) {
        super(direction);
        this.priorityValues = new ArrayList<>();
        if (priorityValue instanceof Collection) {
            this.priorityValues.addAll((Collection<?>) priorityValue);
        } else {
            this.priorityValues.add(priorityValue);
        }
    }

    /**
     * 다중 우선순위 값을 받는 생성자
     */
    public PrioritySortInfo(Collection<?> priorityValues, Direction direction) {
        super(direction);
        this.priorityValues = new ArrayList<>(priorityValues);
    }

    /**
     * JOIN 타입을 함께 지정하는 생성자
     */
    public PrioritySortInfo(Object priorityValue, Direction direction, JoinType joinType) {
        super(direction);
        this.priorityValues = new ArrayList<>();
        if (priorityValue instanceof Collection) {
            this.priorityValues.addAll((Collection<?>) priorityValue);
        } else {
            this.priorityValues.add(priorityValue);
        }
        this.joinType = joinType;
    }

    /**
     * 모든 옵션을 지정하는 생성자
     */
    public PrioritySortInfo(Object priorityValue, Direction direction, JoinType joinType, Boolean nullsFirst) {
        super(direction);
        this.priorityValues = new ArrayList<>();
        if (priorityValue instanceof Collection) {
            this.priorityValues.addAll((Collection<?>) priorityValue);
        } else {
            this.priorityValues.add(priorityValue);
        }
        this.joinType = joinType;
        this.nullsFirst = nullsFirst;
    }

    /**
     * 우선순위 값 추가 (같은 필드에 대해 여러 번 호출 시 병합용)
     */
    public void addPriorityValue(Object value) {
        if (!this.priorityValues.contains(value)) {
            this.priorityValues.add(value);
        }
    }

    /**
     * 첫 번째 우선순위 값 반환 (하위 호환성)
     */
    public Object getPriorityValue() {
        return priorityValues.isEmpty() ? null : priorityValues.get(0);
    }

    /**
     * 전체 우선순위 값 목록 반환
     */
    public List<Object> getPriorityValues() {
        return Collections.unmodifiableList(priorityValues);
    }
    
    @Override
    public boolean isPriority() {
        return true;
    }
    
    @Override
    public List<Order> createJpaOrders(CriteriaBuilder criteriaBuilder, Path<?> path) {
        // 다중 우선순위 CASE WHEN 생성
        Case<Integer> caseBuilder = criteriaBuilder.selectCase();
        int priority = 0;
        for (Object value : priorityValues) {
            caseBuilder = caseBuilder.when(criteriaBuilder.equal(path, value), priority++);
        }
        Expression<Integer> priorityExpr = caseBuilder.otherwise(priority);

        // NULL 값 처리를 위한 CASE WHEN 구문
        Expression<Integer> nullHandlingExpr = criteriaBuilder.<Integer>selectCase()
            .when(criteriaBuilder.isNull(path), priority + 1)
            .otherwise(0);

        // 세 개의 Order 반환:
        // 1. 우선순위 Expression (priorityValues 순서대로)
        // 2. NULL 처리 Expression (null이 마지막에)
        // 3. 실제 값 정렬 (동일 우선순위 내에서의 정렬)
        return Arrays.asList(
            criteriaBuilder.asc(priorityExpr),
            criteriaBuilder.asc(nullHandlingExpr),
            direction.equals(Direction.DESC) ?
                criteriaBuilder.desc(path) :
                criteriaBuilder.asc(path)
        );
    }
    
    @Override
    public String getType() {
        return "priority";
    }
    
    @Override
    public String toString() {
        return String.format("Priority[values=%s, %s]",
            priorityValues, direction.name());
    }
}