/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.dto;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author kunner
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SortField implements Serializable{

	public static final String FIELD_PREFIX = "_sort";
	public static final String TYPE_PREFIX = "_type_sort";
	public static final String SORT_ASC = "asc";
	public static final String SORT_DESC = "desc";

	protected String name;			// field name

	protected String type;			// asc, desc

	protected Integer order;		// sort 순서

	public void setType(String type) {
		this.type = StringUtil.toString(type, SORT_ASC);
	}

}
