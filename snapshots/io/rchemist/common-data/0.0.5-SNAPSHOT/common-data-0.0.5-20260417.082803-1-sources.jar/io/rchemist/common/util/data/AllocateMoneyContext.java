/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util.data;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.MoneyUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AllocateMoneyContext {

  public AllocateMoneyContext(Map<String, Money> origin, Map<String, Money> allocate){
    this.origin = origin;
    this.allocate = allocate;
    this.force = false;
  }

  public AllocateMoneyContext(Map<String, Money> origin, Map<String, Money> allocate, boolean force) {
    this.origin = origin;
    this.allocate = allocate;
    this.force = force;
  }

  protected final boolean force;

  protected final Map<String, Money> origin;

  protected final Map<String, Money> allocate;

  protected Money getOriginAmount(String type){
    return getMappedMoney(origin, type);
  }

  protected Money getAllocateAmount(String type){
    return getMappedMoney(allocate, type);
  }

  protected Money getMappedMoney(Map<String, Money> map, String key){
    if(map.containsKey(key)){
      return map.get(key);
    }else{
      return new Money();
    }
  }


  // allocate 에 있는 값을 origin 과 비교하고 allocate 에 있는 값이 origin 의 값보다 크면 조정한다.
  public Map<String, Money> allocate(){
    int originSize = origin.size();
    int allocateSize = allocate.size();

    if(MapUtils.isNotEmpty(allocate)){
      if(allocateSize == 1){
        for(Entry<String, Money> entry : allocate.entrySet()){
          Money value = entry.getValue();
          Money originAmount = getOriginAmount(entry.getKey());
          if(value.greaterThan(originAmount)){
            allocate.put(entry.getKey(), originAmount);
          }
        }
      }else{
        Set<String> keySet = allocate.keySet();
        if(allocateSize == 2){
          // allocate Size 가 2 라면 여기서 빼서 저기에 주는 개념이다.
          for(String key : keySet){
            Money value = allocate.get(key);
            Money originAmount = getOriginAmount(key);
            if(value.greaterThan(originAmount)){
              Money subtracted = value.subtract(originAmount);
              for(String k : keySet){
                if(!key.equals(k)){
                  Money remainAmount = getOriginAmount(k).subtract(getAllocateAmount(k));
                  if(remainAmount.greaterThanOrEqual(subtracted)){
                    allocate.put(k, allocate.get(k).add(subtracted));
                  }else{
                    allocate.put(k, allocate.get(k).add(remainAmount));
                    // throw new RuntimeException(k + "의 잔액이 차감할 금액보다 작습니다. \n Remain Amount is " + remainAmount.getAmount() + "\n Requested Amount is " + subtracted.getAmount());
                  }
                }
              }
              allocate.put(key, originAmount);
            }
          }
        }else{
          // allocate Size 가 3 이상이면 차액을 따져서 가장 크기가 작은 것을 먼저 빼고 그 다음 순으로 조정해 나간다.
          Map<String, Money> differences = new HashMap<>();
          Map<String, Money> remains = new HashMap<>();
          Money minimumRemain = null;
          Money remainTotal = new Money();
          Money differencesTotal = new Money();
          for(String key : keySet){
            Money allocateAmount = getAllocateAmount(key);
            Money originAmount = getOriginAmount(key);
            if(allocateAmount.greaterThan(originAmount)){
              //  조정 대상
              Money difference = allocateAmount.subtract(originAmount);
              differences.put(key, difference);
              differencesTotal = differencesTotal.add(difference);
            }

            // 차액을 조정하기 위해 origin 에서 차액을 뺀만큼
            Money remain = getOriginAmount(key)
                .subtract(getAllocateAmount(key))
                .subtract(getMappedMoney(differences, key));

            if(remain.lessThan(Money.ZERO)){
              remain = new Money();
            }

            // 최소 배분 금액
            if(minimumRemain == null || minimumRemain.greaterThan(remain)){
              minimumRemain = remain;
            }

            remains.put(key, remain);
            remainTotal = remainTotal.add(remain);
          }

          // 차액이 없을 때
          if(MapUtils.isEmpty(differences)){
            return allocate;
          }

          // 차액의 총액이 잔액을 넘을 때
          if(remainTotal.lessThan(differencesTotal)){
            return origin;
          }

          while(!differences.isEmpty()){
            List<String> differenceKeys = new ArrayList<>(differences.keySet());

            for(String key : differenceKeys) {

              Money difference = getMappedMoney(differences, key);

              List<String> targetKeys = new ArrayList<>(allocate.keySet());
              targetKeys.remove(key);

              // 금액 차이가 있는 케이스
              Money otherTotal = new Money();
              List<String> otherKeys = new ArrayList<>(remains.keySet());
              otherKeys.remove(key);    // 자기 자신은 제외

              for(String type : otherKeys){
                otherTotal = otherTotal.add(getMappedMoney(remains, type));
              }

              if(otherTotal.equals(difference)){
                // 합이 같다. 이쪽에서 빼서 저쪽으로 넣자.
                for(String type : otherKeys){
                  allocate.put(type, getAllocateAmount(type).add(getMappedMoney(remains, type)));
                }
                allocate.put(key, getAllocateAmount(key).subtract(difference));
                return allocate;
              }else{
                // 합이 더 크다 - minimum 을 이용해 한번 돌리고 남은 잔액이 있으면 계속 깎아 나간다.
                for(String type : otherKeys){
                  if(getMappedMoney(remains, type).greaterThan(minimumRemain)){
                    minimumRemain = (difference.lessThan(minimumRemain)) ? difference : minimumRemain;
                    allocate.put(type, getAllocateAmount(type).add(minimumRemain));
                    remains.put(type, getMappedMoney(remains, type).subtract(minimumRemain));
                    difference = difference.subtract(minimumRemain);
                  }
                }

                int bigger = 0;
                for(String type : otherKeys){
                  if(getMappedMoney(remains, type).greaterThan(difference)){
                    bigger++;
                  }
                }

                if(bigger > 0){
                  List<RoundMoneyDTO> rounds = MoneyUtil.rounding(difference, bigger);

                  for(RoundMoneyDTO round : rounds){
                    for(int i = 0; i < round.getQuantity(); i++){

                      Money subtracted = round.getUnitPrice();

                      for(String type : otherKeys) {
                        if (getMappedMoney(remains, type).greaterThan(subtracted)) {
                          allocate.put(type, getAllocateAmount(type).add(subtracted));
                          remains.put(type, getMappedMoney(remains, type).subtract(subtracted));
                        }
                      }

                    }
                  }
                }

              }

              allocate.put(key, getAllocateAmount(key).subtract(difference));
              differences.remove(key);

            }

          }





        }
      }

    }

    return allocate;

  }


}
