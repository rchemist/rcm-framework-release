/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class ScriptPositionType extends EnumType<ScriptPositionType> {

  public static final ScriptPositionType HEAD = new ScriptPositionType(10, "HEAD", "in head tag", "head 태그 내에 삽입", "global.type.script.position.type.head");
  public static final ScriptPositionType ABOVE_BODY = new ScriptPositionType(20, "ABOVE_BODY", "Above body tag", "태그가 호출된 부분에 인라인으로 삽입", "global.type.script.position.type.above.body");
  public static final ScriptPositionType INLINE = new ScriptPositionType(30, "INLINE", "inline", "태그가 호출된 부분에 인라인으로 삽입", "global.type.script.position.type.inline");

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public ScriptPositionType(int order, String key, String value, String description, String messageKey) {
    super(order, key, value, description, messageKey);
  }
}
