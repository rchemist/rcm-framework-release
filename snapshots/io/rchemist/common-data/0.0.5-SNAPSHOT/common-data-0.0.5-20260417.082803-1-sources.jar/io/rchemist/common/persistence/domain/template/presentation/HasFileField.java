/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.data.FileField;
import io.rchemist.common.persistence.domain.data.FileInfo;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasFileField<T> extends ClassTransformTarget {

  default FileField getFileField() {
    throw new ClassTransformException();
  }

  default FileField getClonedFileField() {
    FileField field = getFileField();
    if (field == null || field.isEmpty()) {
      return new FileField();
    }
    return new FileField()
        .withNewFiles(field.getNewFiles())
        .withDeleteFiles(field.getDeleteFiles())
        .withExistFiles(field.getExistFiles());
  }

  default boolean hasFileField() {
    return getFileField() != null && !getFileField().isEmpty();
  }

  default void setFileField(FileField fileField) {
    throw new ClassTransformException();
  }

  default T withFileField(FileField fileField) {
    setFileField(fileField);
    return (T) this;
  }

  default T addNewFile(FileInfo... fileInfo) {
    FileField fileField = getFileField();
    if (fileField == null) {
      fileField = new FileField();
    }
    for (FileInfo info : fileInfo) {
      fileField.addNewFile(info);
    }
    setFileField(fileField);
    return (T) this;
  }

  default T addExistFile(FileInfo... fileInfo) {
    FileField fileField = getFileField();
    if (fileField == null) {
      fileField = new FileField();
    }
    for (FileInfo info : fileInfo) {
      fileField.addExistFile(info);
    }
    setFileField(fileField);
    return (T) this;
  }

  default T addDeleteFile(FileInfo... fileInfo) {
    FileField fileField = getFileField();
    if (fileField == null) {
      fileField = new FileField();
    }
    for (FileInfo info : fileInfo) {
      fileField.addDeleteFile(info);
    }
    setFileField(fileField);
    return (T) this;
  }

  default List<FileInfo> getExistFiles() {
    FileField fileField = getFileField();
    if (fileField == null) {
      return null;
    }
    return fileField.getExistFiles();
  }

  default List<FileInfo> getNewFiles() {
    FileField fileField = getFileField();
    if (fileField == null) {
      return null;
    }
    return fileField.getNewFiles();
  }

  default List<FileInfo> getDeleteFiles() {
    FileField fileField = getFileField();
    if (fileField == null) {
      return null;
    }
    return fileField.getDeleteFiles();
  }

  default boolean hasNewFiles() {
    return CollectionUtils.isNotEmpty(getNewFiles());
  }

  default boolean hasExistFiles() {
    return CollectionUtils.isNotEmpty(getExistFiles());
  }

  default boolean hasDeleteFiles() {
    return CollectionUtils.isNotEmpty(getDeleteFiles());
  }

}
