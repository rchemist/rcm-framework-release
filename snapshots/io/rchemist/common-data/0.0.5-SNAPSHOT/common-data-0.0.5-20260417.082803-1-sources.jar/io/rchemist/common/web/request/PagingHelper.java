/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PagingHelper {

  private static final String DESC = "DESC";
  private static final String ASC = "ASC";

  public static LinkedHashMap<String, Direction> getSortMap(final String[] sort){
    LinkedHashMap<String, Direction> sortMap = new LinkedHashMap<>();

    if(ArrayUtils.isNotEmpty(sort)){
      for(int loop = 0; loop < sort.length; loop++){
        String sortProperty = sort[loop];
        if(StringUtils.isEmpty(sortProperty)){
          continue;
        }

        String direction = null;

        if(StringUtils.contains(sortProperty, " ")){
          String[] props = StringUtils.split(sortProperty, " ");
          sortProperty = props[0];
          direction = props[1];
        }

        if(loop + 1 <= sort.length -1){
          if(StringUtils.equalsAnyIgnoreCase(sort[loop+1], DESC, ASC)){
            direction = sort[loop+1];
            loop = loop + 2;
          }else{
            loop = loop + 1;

            if(!StringUtils.equalsAnyIgnoreCase(direction, DESC, ASC)){
              direction = "desc";
            }

          }
        }
        sortMap.put(sortProperty, getSortDirection(direction));
      }
    }

    return sortMap;
  }

  public static Sort getSort(final String[] sort, String defaultSortProperty, Direction defaultDirection){
    List<Sort.Order> orders = new ArrayList<>();

    if(ArrayUtils.isNotEmpty(sort)) {
      for(int loop = 0; loop < sort.length; loop++){
        String sortProperty = sort[loop];
        if(StringUtils.isEmpty(sortProperty)){
          continue;
        }

        String direction = null;

        if(StringUtils.contains(sortProperty, " ")){
          String[] props = StringUtils.split(sortProperty, " ");
          sortProperty = props[0];
          direction = props[1];
        }

        if(loop + 1 <= sort.length -1){
          if(StringUtils.equalsAnyIgnoreCase(sort[loop+1], DESC, ASC)){
            direction = sort[loop+1];
            loop = loop + 1;
          }else{
            if(!StringUtils.equalsAnyIgnoreCase(direction, DESC, ASC)){
              direction = "desc";
            }

          }
        }
        orders.add(new Sort.Order(getSortDirection(direction), sortProperty));
      }
    }


    if(CollectionUtils.isEmpty(orders)){
      // 기본 정렬
      if(StringUtils.isEmpty(defaultSortProperty)){
        return Sort.unsorted();
      }else{
        return Sort.by(new Sort.Order(defaultDirection, defaultSortProperty));
      }
    }else{
      return Sort.by(orders);
    }
  }

  private static Direction getSortDirection(String direction){
    return StringUtils.equalsAnyIgnoreCase(direction, DESC) ?
        Direction.DESC : Direction.ASC;
  }

}
