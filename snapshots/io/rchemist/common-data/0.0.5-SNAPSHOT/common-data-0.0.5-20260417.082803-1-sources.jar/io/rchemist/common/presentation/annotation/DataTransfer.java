/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.DataManageType;
import io.rchemist.common.presentation.type.MimeType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface DataTransfer {

  /**
   * import / export 둘 다 가능하게 할지, 하나만 가능하게 할지
   * @return
   */
  DataManageType type() default DataManageType.NOT_SUPPORT;

  /**
   * 엔티티를 export 할 때 별도의 provider 를 사용한다면 대상 provider 의 이름을 입력한다.
   * @return
   */
  String provider() default "";

  /**
   * 기본적으로 이 값을 설정하지 않아도 @AdminField 로 정의된 필드가 대상 필드로 지정된다.
   * 단, AdminField 로 지정된 모든 필드가 아니라 특정 필드만 따로 뽑아내고 싶다면 해당 필드의 이름 목록을 지정하면 된다.
   * import 는 createForm 에 있는 모든 필드를 제공하므로 따로 설정하지 않는다.
   * @return
   */
  String[] exportableFields() default {};

  /**
   * 기본적으로 이 값을 설정하지 않아도 @AdminField 로 정의된 필드가 대상 필드로 지정된다.
   * 단, import 할 때 필요한 필드를 별도로 지정하고 싶을 때
   * NAME1:PROPERTY_NAME1, NAME2:PROPERTY_NAME2 형식으로 지정한다.
   * NAME1, NAME2 는 MessageSourceHelper 를 통해 i18n 처리된다.
   *
   * 기존 엔티티에 있는 필드를 사용하려면 : 없이 그냥 propertyName 만 지정하면 된다.
   *
   * @return
   */
  String[] importableFields() default {};

  /**
   * 이 엔티티를 export 할 때 provider 에게 넘겨 줄 key  / value attribute 를 설정한다.
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * 데이터 업로드 가 정상적으로 완료 됐을 때 알림 링크를 현재 화면 업데이트로 할 것인지, DATA TRANSFER RESULT 화면으로 이동시킬 것인지 여부
   * @return
   */
  boolean refreshViewOnFinishImport() default false;

  /**
   * Export 할 때 어떤 타입의 파일로 내보낼지
   *
   * MimeType.CSV
   * MimeType.XLSX 중 선택
   *
   * 그 외 값이면 XLSX 로 지정된다.
   * @return
   */
  MimeType exportMimeType() default MimeType.XLSX;

  /**
   * 데이터 업로드할 때 파일의 mimetype 을 지정한다.
   * 이 값이 CSV 가 아니면 DataTransferConfig.csvUpload 값은 false 가 되며, 미리보기가 지원되지 않는다.
   * @return
   */
  MimeType[] importMimeType() default {MimeType.XLSX};

}
