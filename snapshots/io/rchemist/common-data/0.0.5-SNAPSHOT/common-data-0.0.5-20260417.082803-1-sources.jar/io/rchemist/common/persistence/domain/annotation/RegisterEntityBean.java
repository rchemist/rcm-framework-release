/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * PlatformSessionFactoryBuilderFactory 에서 PersistentClass 정보를 저장할 때,
 * 각 PersistentClass의 mappedClass에 이 어노테이션이 붙어 있으면 해당 어노테이션 정보를 읽어
 * PersistentBeanClassMap 에 저장하고 추후 EntityConfiguration 에서 해당 정보를 사용해 서비스를 처리한다.
 *
 * xml 방식에서 어노테이션 방식으로 변경한 이유는 크게 다음과 같다.
 *
 * 1. 클래스 트랜스폼을 처리하기 위해 클래스 로딩 시점을 통일하기 위함
 * 2. 엔티티 클래스가 추가 될 때 마다 XML 을 설정하지 않기 위함
 *
 * @See PersistentInfo, EntityConfiguration
 *
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RegisterEntityBean {

  /**
   * 등록될 bean 이름
   * @return
   */
  String value() default "";

  /**
   * 같은 이름으로 정의된 엔티티가 있을 때 order 가 낮은 순으로 먼저 priority 를 가진다
   * @return
   */
  int order() default 10000;

  /**
   * Property 로 넘겨 받을 property name and referenced bean
   * @return
   */
  RegisterEntityBeanProperty[] properties() default {};


}
