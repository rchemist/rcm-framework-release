/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface InlineMap {

  /**
   * 최소 몇개 이상 입력되어야 하는지 제약이 있다면 해당 숫자
   * @return
   */
  int minimumSize() default  0;    // 0 이면 제한 없음

  /**
   * 최대 몇개까지 입력할 수 있는지 제약이 있다면 해당 숫자
   * @return
   */
  int maximumSize() default 0;    // 0 이면 제한 없음

  /**
   * 제한된 KEY 값을 사용해야 하는 경우 -> 이 경우 해당 KEY 는 수정이 불가능하다.
   * 입력할 수 있는 KEY 에 제약이 있다면 구분해 입력한다.
   * 같은 KEY 가 중복되어도 상관 없다.
   * @return
   */
  String[] restrictKeys() default {};

  /**
   * 모든 ROW 에 공백값을 인정하지 않는 경우
   * 값을 입력하지 않았을 때 에러를 낼 것인지
   * @return
   */
  boolean requiredValue() default false;

  /**
   * KEY 입력폼의 라벨, 공백이면 아예 표시 안 함
   * @return
   */
  String nameLabel() default "";

  /**
   * VALUE 입력폼의 라벨, 공백이면 아예 표시 안 함
   * @return
   */
  String valueLabel() default "";

  /**
   * KEY 입력폼의 placeholder, 공백이면 아예 표시 안 함
   * @return
   */
  String namePlaceHolder() default "";

  /**
   * VALUE 입력폼의 placeholder, 공백이면 아예 표시 안 함
   * @return
   */
  String valuePlaceHolder() default "";

  /**
   * VALUE 입력폼을 TEXTAREA 로 표시할지
   * @return
   */
  boolean textMode() default false;

}
