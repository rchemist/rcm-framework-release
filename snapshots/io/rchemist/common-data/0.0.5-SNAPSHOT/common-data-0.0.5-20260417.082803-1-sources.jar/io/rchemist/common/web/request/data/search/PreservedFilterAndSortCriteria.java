/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.util.GsonUtil;
import io.rchemist.common.util.MapUtil;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter(AccessLevel.PRIVATE)
public class PreservedFilterAndSortCriteria implements Serializable {

  protected LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = new LinkedHashMap<>();

  protected List<SortEntry> sorts = new ArrayList<>();


  public PreservedFilterAndSortCriteria withFilters(
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters) {
    if (MapUtils.isNotEmpty(filters)) {
      this.filters = new LinkedHashMap<>();

      // deep copy from filters
      copyFilters(filters);

    }
    return this;
  }

  public PreservedFilterAndSortCriteria withSorts(List<SortEntry> sorts) {
    if (sorts != null && !sorts.isEmpty()) {
      this.sorts = new ArrayList<>(sorts);
    }
    return this;
  }

  public void addModifiers(LinkedHashMap<ConditionOperatorType, FilterItem[]> filters, List<SortEntry> sorts) {
    if (MapUtils.isNotEmpty(filters)) {
      // deep copy from filters
      copyFilters(filters);
    }

    if (sorts != null && !sorts.isEmpty()) {
      this.sorts.addAll(sorts);
    }
  }

  private void copyFilters(LinkedHashMap<ConditionOperatorType, FilterItem[]> filters) {
    filters.forEach((key, value) -> {
      if (value != null && !(value.length == 1 && value[0] == null)) {
        FilterItem[] items = new FilterItem[value.length];
        for (int i = 0; i < value.length; i++) {
          items[i] = value[i].deepCopy();
        }
        this.filters.put(key, items);
      }
    });
  }

  public PreservedFilterAndSortCriteria deepCopy() {
    PreservedFilterAndSortCriteria copy = new PreservedFilterAndSortCriteria();
    copy.copyFilters(this.filters);
    copy.withSorts(this.sorts);
    return copy;
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("filters", MapUtil.toString(filters))
        .append("sorts", GsonUtil.toJson(sorts))
        .toString();
  }
}
