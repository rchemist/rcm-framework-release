/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

public class CacheRegion {

  public static class System {
    public static final String CONFIGURATION = "system-configuration";
    public static final String SECURE_PERMISSION = "secure-permission";
    public static final int MAX_ENTRIES = 1000;
    public static final int MAX_ENTRIES_LARGE = 10000;
    public static final int TTL = 60 * 60 * 24 * 30;
    public static final int TTL_HOUR = 60 * 60;
  }

  public static class SiteAware {
    public static final String CONFIGURATION = "site-aware";
    public static final int MAX_ENTRIES = 1000;
    public static final int TTL = 60 * 60 * 24 * 30;
  }

  public static class ThymeleafTemplate {
    public static final String CACHE = "thymeleaf-cache";
    public static final int MAX_ENTRIES = 1000;
    public static final int TTL = 60 * 60 * 24 * 30;
  }

}
