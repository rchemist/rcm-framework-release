/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class CreditAddType extends EnumType<CreditAddType> {

  public static final CreditAddType CUSTOM = new CreditAddType(1, "CUSTOM", "Custom", "직접 입력", "global.type.credit.add.type.custom", true);
  public static final CreditAddType ISSUE = new CreditAddType(10, "ISSUE", "Issue", "최초 발행", "global.type.credit.add.type.issue", false);
  public static final CreditAddType REDEEM = new CreditAddType(30, "REDEEM", "Redeem", "기프트카드 -> 적립금 전환", "global.type.credit.add.type.redeem", false);
  public static final CreditAddType REFUND = new CreditAddType(40, "REFUND", "Refund", "환불로 인한 재적립", "global.type.credit.add.type.refund", false);
  public static final CreditAddType ROLLBACK = new CreditAddType(50, "ROLLBACK", "Rollback", "오류로 인한 롤백", "global.type.credit.add.type.rollback", false);
  public static final CreditAddType TRANSFER = new CreditAddType(60, "TRANSFER", "Transfer", "적립금 간 이체", "global.type.credit.add.type.transfer", false);
  public static final CreditAddType VOUCHER = new CreditAddType(70, "VOUCHER", "Voucher", "리워드 목적으로의 적립, 이벤트 등", "global.type.credit.add.type.voucher", true);
  public static final CreditAddType SYNC = new CreditAddType(80, "SYNC", "Sync", "외부 연동 포인트의 보정", "global.type.credit.add.type.sync", false);

  @Getter
  @Setter
  private boolean customizable;   // admin 이 수동으로 부여할 수 있는지 여부

  public CreditAddType(int order, String type, String friendlyType, String description, String messageKey, boolean customizable) {
    super(order, type, friendlyType, description, messageKey);
    this.customizable = customizable;
  }

  private CreditAddType(){
    this.customizable = false;
  }

  public static Map<String, String> getAllTypes(){
    Map<String, String> allTypes = new HashMap<>();
    for(EnumType creditAddType : getTypes(CreditAddType.class)){
      if(((CreditAddType) creditAddType).isCustomizable()){
        allTypes.put(creditAddType.getType(), creditAddType.getTranslatedType());
      }
    }
    return allTypes;
  }

}
