/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasAttributes.class)
@Getter
@Setter
public class HasAttributesImpl implements EnhancedTemplate {

  protected String attributePrefix;

  @AdminField(order = 600
      , name = "Attribute_Attributes"
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 600)
      , group = @ViewFieldGroup(type = GroupEnumType.ATTRIBUTE)
      , fieldType = PresentationFieldType.INLINE_MAP)
  @JsonProperty
  protected Map<String, String> attributes = new LinkedHashMap<>();

}
