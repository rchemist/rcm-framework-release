/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import jakarta.annotation.Nullable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class ModifiedResult {

  /**
   * 필터가 변경됐을 때만 값이 존재한다.
   */
  @Nullable
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> filters;

  /**
   * Sort 관련 처리를 할 때는 이 값이 반드시 존재한다.
   */
  private List<SortEntry> sortEntries = new ArrayList<>();

  public ModifiedResult withFilters(
      LinkedHashMap<ConditionOperatorType, FilterItem[]> filters) {
    this.filters = filters;
    return this;
  }

  public ModifiedResult withSortEntries(
      List<SortEntry> sortEntries) {
    this.sortEntries = sortEntries;
    return this;
  }

  public boolean hasSorts(){
    return sortEntries != null && !sortEntries.isEmpty();
  }

  public boolean hasFilters(){
    return MapUtils.isNotEmpty(filters);
  }

}
