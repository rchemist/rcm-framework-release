/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.provider;

import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.DateUtil;
import io.rchemist.common.util.InstantUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.LocalDateUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 *
 * IN/NOT_IN, BETWEEN, NOT_BETWEEN
 **/
@Slf4j
public class CollectionQueryProvider implements QueryParseProvider {

  public static final String SPLIT_CODE = "|||";

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.COLLECTION);
  }

  @Override
  public <T> Predicate getPredicate(CriteriaBuilder builder, QueryConditionType condition,
      Path<T> path, Object value, List<?> values) {

    if(CollectionUtils.isEmpty(values)){
      if(value != null){
        values = CollectionUtil.list(value);
      }
    }

    if(CollectionUtils.isEmpty(values))
      return null;

    Predicate predicate = null;

    Class<?> javaType = path.getJavaType();

    if(condition.equals(QueryConditionType.IN) || condition.equals(QueryConditionType.NOT_IN)){

      // 이 필드가 String[] 인지 확인해야 한다.

      if (String[].class.isAssignableFrom(javaType)) {

        List<Predicate> predicates = new ArrayList<>();

        for (Object itemValue : values) {
          String v = "%" + SPLIT_CODE + itemValue + SPLIT_CODE + "%";
          predicates.add(builder.like((Expression<String>) path, v));
        }

        predicate = builder.or(predicates.toArray(new Predicate[0]));

      } else {
        predicate = path.in(values);

      }

    }else{

      if (String[].class.isAssignableFrom(javaType)) {
        log.warn("String[] 타입에 대한 Collection 검색은 in / not in 만 가능합니다.");
        return null;
      }

      // between 은 시작점 ~ 끝점의 두 값을 가지고 있다.
      // 만약 끝점이 null 이면 시작점으로 greater than equals 가 되고,
      // 만약 시작점이 null 이면 끝점으로 less than equals 가 된다.
      // 둘 다 값이 없다면 이 로직을 아예 타지 않는다.

      if(values.size() < 2 || values.get(1) == null){
        predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.EQUAL, path, values.get(0), values);
      }else{

        Object value1 = values.get(0);
        Object value2 = values.get(1);

        if (value1 == null && value2 == null) {
          return null; // 아무 값도 없다면 아예 타지 않는다.
        } else if (value1 == null && value2 != null) {
          predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.LESS_THAN_EQUAL, path, value2, values);
        } else if (value1 != null && value2 == null) {
          predicate = QueryHelper.getConditionPredicate(builder, QueryConditionType.GREATER_THAN_EQUAL, path, value1, values);
        } else {
          if(String.class.isAssignableFrom(javaType) || String.class.isAssignableFrom(value1.getClass())){
            // 공통 로직 적용
          }else {
            if(java.math.BigDecimal.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value1)){
              java.math.BigDecimal bigDecimal1, bigDecimal2;
              if (value1 instanceof java.math.BigDecimal) {
                bigDecimal1 = (java.math.BigDecimal) value1;
              } else {
                bigDecimal1 = NumberUtil.getBigDecimal(String.valueOf(value1));
              }
              if (value2 instanceof java.math.BigDecimal) {
                bigDecimal2 = (java.math.BigDecimal) value2;
              } else {
                bigDecimal2 = NumberUtil.getBigDecimal(String.valueOf(value2));
              }
              if (bigDecimal1 != null && bigDecimal2 != null) {
                predicate = builder.between((Expression<java.math.BigDecimal>) path, bigDecimal1, bigDecimal2);
              }
            }else if(Long.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value1.getClass())){
              predicate = builder.between((Expression<Long>) path, NumberUtil.getLong(value1), NumberUtil.getLong(value2));
            }else if(Integer.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value1)){
              predicate = builder.between((Expression<Integer>) path, NumberUtil.getInteger(String.valueOf(value1)), NumberUtil.getInteger(String.valueOf(value2)));
            }else if(Double.class.isAssignableFrom(javaType) && NumberUtil.isNumeric(value1)){
              predicate = builder.between((Expression<Double>) path, NumberUtil.getDouble(value1), NumberUtil.getDouble(value2));
            }else if(java.util.Date.class.isAssignableFrom(javaType)){
              java.util.Date dateValue1 = DateUtil.getDate(value1);
              java.util.Date dateValue2 = DateUtil.getDate(value2);
              if(dateValue1 != null && dateValue2 != null){
                predicate = builder.between((Expression<Date>) path, dateValue1, dateValue2);
              }
            }else if(LocalDateTime.class.isAssignableFrom(javaType)){
              LocalDateTime localDateTime1 = LocalDateTimeUtil.getLocalDateTime(value1);
              LocalDateTime localDateTime2 = LocalDateTimeUtil.getLocalDateTime(value2);
              if(localDateTime1 != null && localDateTime2 != null){
                predicate = builder.between((Expression<LocalDateTime>) path, localDateTime1, localDateTime2);
              }
            }else if(LocalDate.class.isAssignableFrom(javaType)){
              LocalDate localDate1 = LocalDateUtil.getLocalDate(value1);
              LocalDate localDate2 = LocalDateUtil.getLocalDate(value2);
              if(localDate1 != null && localDate2 != null){
                predicate = builder.between((Expression<LocalDate>) path, localDate1, localDate2);
              }
            } else if (Instant.class.isAssignableFrom(javaType)) {
              Instant instant1;
              Instant instant2;

              try {
                instant1 = (Instant) value1;
                instant2 = (Instant) value2;
              } catch (Exception e) {
                try {
                  instant1 = InstantUtil.getInstant(value1);
                  instant2 = InstantUtil.getInstant(value2);
                }catch (Exception e2) {
                  log.error("Instant 타입으로 변환할 수 없습니다.", e2);
                  throw e2;
                }
              }

              if(instant1 != null && instant2 != null){
                predicate = builder.between((Expression<Instant>) path, instant1, instant2);
              }

            }
          }
        }

        if(predicate == null){
          predicate = builder.between((Expression<String>) path, StringUtil.getString(value1), StringUtil.getString(value2));
        }
      }
    }

    return (predicate == null) ? null : (condition.isNegative()) ? predicate.not() : predicate;
  }


  @Override
  public int getOrder() {
    return 400;
  }
}
