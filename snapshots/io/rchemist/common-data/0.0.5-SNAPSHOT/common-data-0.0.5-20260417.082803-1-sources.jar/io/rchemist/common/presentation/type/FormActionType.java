/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public enum FormActionType {

  CREATE(100, "fa-plus", false),
  MODIFY(200, "fa-pen", false),
  SAVE(300, "fa-check", false),
  DELETE(40, "fa-trash-can", false),
  PREVIEW(50, "fa-magnifying-glass", true),
  MODIFY_ON_LIST(20, "fa-pen-to-square", false),
  STATUS(40, "fa-ban", false),
  LIST(50, "fa-reply", true),
  FILTER(60, "fa-filter", true),
  DATA_TRANSFER(70, "fa-download", true),
  REFRESH(80, "fa-rotate-right", true),
  NONE(1, "", true);    // 이 타입을 설정하면 다른 타입이 모두 무시된다. 단, Polymorphic classes 의 구조에 따라 다른 클래스가 오버라이드 하면 해당 설정을 따른다

  @Getter final int order;

  @Getter
  private final boolean showOnReadonly;

  @Getter
  private final String icon;    // fontawesome icon

  FormActionType(int order, String icon, boolean showOnReadonly) {
    this.order = order;
    this.icon = icon;
    this.showOnReadonly = showOnReadonly;
  }

}
