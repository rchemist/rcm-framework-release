/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.data;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface RevisionEntityWrapper<FORM> extends ClassTransformTarget {

  default String getRevisionEntityName() {
    return null;
  }

  default void setRevisionEntityName(String revisionEntityName) {
    throw new ClassTransformException();
  }

  default FORM withRevisionEntityName(String revisionEntityName) {
    setRevisionEntityName(revisionEntityName);
    return (FORM) this;
  }

}
