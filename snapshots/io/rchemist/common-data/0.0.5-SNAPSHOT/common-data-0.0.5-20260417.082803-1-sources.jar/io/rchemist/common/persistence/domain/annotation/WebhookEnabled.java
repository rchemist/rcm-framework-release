/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Webhook 을 지원하는 엔티티에 @WebhookEnabled 를 붙이면 Webhook 의 TargetType이 된다.
 * @WebhookEnabled(name ="Customer", types="WebhookType.CREATE") 인 경우
 * "When Customer entity is created" 시점의 WebhookType 이 활성화된다
 *
 * 실제 웹훅 서비스는 다음과 같이 처리될 것이다.
 *
 *    1. 서버 부트스트랩 중에 엔티티 클래스에 붙은 @WebhookEnabled 해석
 *    2. 1. 에서 해석한 내용을 WebhookConfig 엔티티에 저장(각 ROW 가 각 WebhookType 에 대응한다. 한 CeilingEntityClass 가 여러 WebhookType 을 가지고 있으므로 WebhookConfig ROW도 여러 개를 가지게 될 것이다.)
 *    3. Admin > 웹훅 관리에서 WebhookConfig 엔티티를 참조하는 각 Webhook 엔티티를 생성한다. - 여기에서 각 웹훅이 발생할 때 어떤 일을 하게 할 것인지 설정한다.
 *    4. 3. 에서 설정한 내용은 CustomerSegment 와 마찬가지로 관리자의 설정이 변경되지 않는 이상 변하지 않는 정보이므로 적절히 캐싱 처리한다. - 캐시 동기화가 어렵다면 Solr 이벤트와 동기화 하는 것이 현실적이다.
 *    5. PlatformEntityManager 의 merge, persist, remove 시점에 4. 의 캐싱 내용을 확인해 대상 엔티티라면 WebhookQueue 에 저장한다.
 *       이때는 CustomType 의 mvelExpression 이나 이런 정보를 확인하지 않는다. 웹훅이 설정되어 있으면 무조건 저장한다. - 주문 워크플로우와 같이 중요한 작업 중에 지연이 발생하면 안 되기 때문이다.
 *    6. 적절한 스케쥴 처리 엔진(큐, 배치, 기타 등등)을 통해 5. 에 저장된 내용을 처리한다.
 *    7. 처리 결과에 따라 WebhookQueue 정보를 갱신하고(정상이면 레코드 삭제, 실패한 경우 retry 설정 등), WebhookLog 에 처리 결과를 저장한다.
 *    8. PurgeWebhookLog 배치를 통해 주기적으로 로그 데이터를 제거한다.
 *
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface WebhookEnabled {

  // 값을 입력하지 않으면 ClassTransformer가 자동으로 해당 Class의 SimpleName을 name 으로 대체한다
  String name() default "::ENTITY_NAME::";

  WebhookType[] types();

}
