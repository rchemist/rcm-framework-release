/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.data.AuditDTO;
import java.io.Serializable;
import java.time.Instant;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface Auditable<DTO> extends Serializable {

  AuditDTO getAudit();

  void setAudit(AuditDTO audit);

  @JsonIgnore
  default Instant getCreatedAt() {
    return getAudit() == null ? null : getAudit().getCreatedAt();
  }

  @JsonIgnore
  default Instant getUpdatedAt() {
    return getAudit() == null ? null : getAudit().getUpdatedAt();
  }

  default void setCreatedAt(Instant createdAt){
    if(getAudit() != null){
      this.getAudit().setCreatedAt(createdAt);
    }
  }

  default void setUpdatedAt(Instant updatedAt){
    if(this.getAudit() != null){
      this.getAudit().setUpdatedAt(updatedAt);
    }
  }

  default DTO withAudit(AuditDTO audit){
    setAudit(audit);
    return (DTO) this;
  }

  default DTO withCreatedAt(Instant createdAt){
    setCreatedAt(createdAt);
    return (DTO) this;
  }

  default DTO withUpdatedAt(Instant updatedAt){
    setUpdatedAt(updatedAt);
    return (DTO) this;
  }

}
