/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class XrefAvailableMappingForm<ID_TYPE> implements Serializable {

  private List<AvailableMapping<ID_TYPE>> mapped;

  public XrefAvailableMappingForm<ID_TYPE> withMapped(
      List<AvailableMapping<ID_TYPE>> mapped) {
    this.mapped = mapped;
    return this;
  }

  @SafeVarargs
  public final XrefAvailableMappingForm<ID_TYPE> addMapped(AvailableMapping<ID_TYPE>... mappings) {
    if (CollectionUtils.isEmpty(this.mapped)) {
      this.mapped = new ArrayList<>(List.of(mappings));
    } else {
      this.mapped.addAll(List.of(mappings));
    }
    return this;
  }

  // <editor-fold desc="validation">

  public boolean hasMapped() {
    return CollectionUtils.isNotEmpty(mapped);
  }

  public XrefAvailableMappingForm<ID_TYPE> deepCopy() {

    if (CollectionUtils.isNotEmpty(mapped)) {
      List<AvailableMapping<ID_TYPE>> mappedCopy = mapped.stream()
          .map(AvailableMapping::deepCopy)
          .toList();
      return new XrefAvailableMappingForm<ID_TYPE>()
          .withMapped(mappedCopy);
    }

    return new XrefAvailableMappingForm<>();
  }

  @Getter
  @Setter
  public static class AvailableMapping<ID_TYPE> implements Serializable {

    private ID_TYPE id;
    private Integer priority;
    private Instant availableAt;
    private Instant availableUntil;


    public AvailableMapping<ID_TYPE> withId(ID_TYPE id) {
      this.id = id;
      return this;
    }

    public AvailableMapping<ID_TYPE> withPriority(Integer priority) {
      this.priority = priority;
      return this;
    }

    public AvailableMapping<ID_TYPE> withAvailableAt(Instant availableAt) {
      this.availableAt = availableAt;
      return this;
    }

    public AvailableMapping<ID_TYPE> withAvailableUntil(Instant availableUntil) {
      this.availableUntil = availableUntil;
      return this;
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }

      if (object == null || getClass() != object.getClass()) {
        return false;
      }

      AvailableMapping<?> that = (AvailableMapping<?>) object;

      return new EqualsBuilder().append(id, that.id)
          .append(availableAt, that.availableAt)
          .append(availableUntil, that.availableUntil)
          .append(priority, that.priority).isEquals();
    }

    @Override
    public int hashCode() {
      return new HashCodeBuilder(17, 37).append(id).append(priority)
          .append(availableAt)
          .append(availableUntil).toHashCode();
    }

    public AvailableMapping<ID_TYPE> deepCopy() {
      return new AvailableMapping<ID_TYPE>()
          .withId(id)
          .withAvailableAt(availableAt)
          .withAvailableUntil(availableUntil)
          .withPriority(priority);
    }
  }
  
  
  
}
