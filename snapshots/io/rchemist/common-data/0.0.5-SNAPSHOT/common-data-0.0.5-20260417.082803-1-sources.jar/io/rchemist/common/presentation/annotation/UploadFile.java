/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.UploadFileType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface UploadFile {

  /**
   * Asset 으로 매핑된 경우 업로드할 수 있는 파일의 종류
   * @return
   */
  UploadFileType fileType() default UploadFileType.ALL;

  boolean showTag() default true;

  /**
   * Asset 으로 매핑된 경우 업로드할 수 있는 최대 개수 - AssetMapping 이 Map 으로 매핑되었을 때만 유효하다.
   * @return
   */
  String maxUploadCount() default "";

  /**
   * Asset 으로 매핑된 경우 업로드할 수 있는 최대 파일 크기 : MB 단위
   * @return
   */
  String maxUploadSize() default "";

  /**
   * 이 어노테이션이 오버라이드 됐을 때는 이 값이 true 여야 한다.
   * @return
   */
  boolean overridden() default false;

}
