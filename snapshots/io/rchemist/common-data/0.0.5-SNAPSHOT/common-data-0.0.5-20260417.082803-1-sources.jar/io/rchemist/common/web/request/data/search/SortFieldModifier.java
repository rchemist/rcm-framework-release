/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import org.springframework.core.Ordered;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SortFieldModifier extends Ordered {

  /**
   * sort 로 지정된 필드에 대해 추가적인 처리를 수행한다.
   *
   * 예를 들어 sort 로 지정된 필드가 main entity class 의 필드가 아닌 경우 - 즉, JOIN 이 필요한 경우 filters 에 대한 변경도 함께 이뤄져야 한다.
   * 이 때 FilterItem 에 JOIN 을 명시해야 한다.
   *
   *
   * @param request
   * @return
   */
  default ModifySortRequest modifySorts(
      ModifySortRequest request) {
    // do nothing
    return request;
  }

}
