/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.springframework.data.domain.Page;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class PageResult<T> {

  protected final Page<T> page;

  protected final Class<T> entityClass;

  // ID, Attributes map
  protected Map<String, Map<String, Map<String, String>>> attributeValues = new HashMap<>();

  public PageResult(Page<T> page, Class<T> entityClass) {
    this.page = page;
    this.entityClass = entityClass;
  }

  public static <T> PageResult<T> create(Class<T> entityClass, Page<T> page) {
    PageResult<T> result = new PageResult<>(page, entityClass);
    return result;
  }

  public boolean isBlankAttributes() {
    if (MapUtils.isEmpty(attributeValues))
      return true;
    return attributeValues.values().stream().allMatch(MapUtils::isEmpty);
  }

  public PageResult<T> setAttributes(Serializable id, String propertyName, Map<String, String> attributes) {
    if (MapUtils.isEmpty(attributes))
      return this;

    String key = String.valueOf(id);

    if (attributeValues.containsKey(key)) {
      Map<String, Map<String, String>> existing = attributeValues.get(key);

      if (existing.containsKey(propertyName)) {
        Map<String, String> existingAttributes = existing.get(propertyName);
        existingAttributes.putAll(attributes);
      } else {
        existing.put(propertyName, attributes);
      }

    } else {
      Map<String, Map<String, String>> values = new HashMap<>();
      values.put(propertyName, attributes);
      attributeValues.put(key, values);
    }

    return this;
  }

}
