/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.data.RoundMoneyDTO;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class MoneyUtil {

  public static Money getRateMoney(Money money, Double percentage){
    return (money == null) ? null : money.rate(percentage);
  }

  public static Money safeSubtract(Money one, Money... subtracts){
    if(one == null || ArrayUtils.isEmpty(subtracts))
      return (one == null) ? Money.ZERO : one;

    List<BigDecimal> subtractAmounts = new ArrayList<>();
    for(Money amount : subtracts){
      if(amount == null) amount = Money.ZERO;
      subtractAmounts.add(amount.getAmount());
    }

    return new Money(subtract(one.getAmount(), subtractAmounts.toArray(new BigDecimal[0])), one.getCurrency());

  }

  public static BigDecimal subtract(BigDecimal one, BigDecimal... subtractAmounts){

    if(one == null)
      return BigDecimal.ZERO;

    if(ArrayUtils.isEmpty(subtractAmounts)){
      return one;
    }

    for(BigDecimal amount : subtractAmounts){
      if(amount == null)
        return one;
      one = one.subtract(amount);
      if(one.compareTo(BigDecimal.ZERO) < 0)
        return BigDecimal.ZERO;
    }

    return one;

  }
  
  public static Money getMoneyWithJavaCurrency(BigDecimal amount, Currency currency){
    if (amount == null)
      amount = BigDecimal.ZERO;

    return new Money(amount, currency);
  }

  public static Money getMoney(BigDecimal amount) {
    return (amount == null) ? Money.ZERO : new Money(amount);
  }

  public static BigDecimal getAmount(Money rate) {
    return (rate == null) ? null : rate.getAmount();
  }

  public static Money getTruncatedMoney(Money money, int trunc) {
    return (money == null) ? null : money.truncate(trunc);
  }

  public static List<RoundMoneyDTO> rounding(Money totalAmount, int quantity){

    if(quantity == 1)
      return CollectionUtil.list(new RoundMoneyDTO().withUnitPrice(totalAmount).withQuantity(1));

    Money unitPrice = totalAmount.divide(quantity).getTruncatedAmount();
    Money sumAmount = unitPrice.multiply(quantity);

    if(totalAmount.equals(sumAmount)){
      return CollectionUtil.list(new RoundMoneyDTO().withUnitPrice(unitPrice).withQuantity(quantity));
    }

    boolean plusOperation = sumAmount.lessThan(totalAmount);

    Money difference;
    if(plusOperation){
      // 나눴다가 다시 곱한 금액이 원금보다 적은 경우. 차액을 따져서 아이템마다 더해준다.
      difference = totalAmount.subtract(sumAmount);
    }else{
      // divide 할 때 rounding 이 HALF_EVEN 이라 과다하게 계산될 때도 있다.
      // 이 경우에는 loop 하면서 금액을 빼 줘야 한다.
      difference = sumAmount.subtract(totalAmount);
    }

    if(difference.lessThan(new BigDecimal(1))){
      // 원화의 경우는 이런 일이 없지만 소수점을 사용하는 통화도 있으므로 그에 대해 고려한다.
      return getSingularRoundingResult(quantity, unitPrice, plusOperation, difference);

    } else {

      int fractionDigits = totalAmount.getCurrency().getDefaultFractionDigits();

      if(fractionDigits == 0 && difference.lessThan(new BigDecimal(100))){
        // 원화와 같이 통화에 소수점이 없는 경우는 100 원 이하의 차액은 그냥 아이템 하나에 담아 주자. 1원씩 남아 담아 줄 것 까지야 없지 않을까?
        return getSingularRoundingResult(quantity, unitPrice, plusOperation, difference);
      }else{

        Money singularity = getSingularityAmount(difference);

        int count = Math.toIntExact(countNumberOfUnits(difference));

        if(quantity > count){
          // singularity 를 하나씩 곱해도 전체 quantity 에 배분하지 못하는 상황
          // 전체 두개의 list 아이템이 나온다. 하나는 count 수 만큼 singularity 를 더한 그룹, 또 하나는 quantity - count 수 만큼 원래의 unitPrice 를 가진 그룹
          return CollectionUtil.list(
              new RoundMoneyDTO().withUnitPrice(unitPrice.add(singularity)).withQuantity(count)
              , new RoundMoneyDTO().withUnitPrice(unitPrice).withQuantity(quantity - count)
          );
        } else {

          int floor = Math.floorDiv(quantity, count);
          int mod = Math.floorMod(quantity, count);

          Money added = singularity.multiply(new BigDecimal(floor));
          unitPrice = unitPrice.add(added);

          return CollectionUtil.list(
            new RoundMoneyDTO().withUnitPrice(unitPrice).withQuantity(mod)
            , new RoundMoneyDTO().withUnitPrice(unitPrice).withQuantity(quantity - mod)
          );
        }
      }
    }
  }

  /**
   * 차액의 소수점 지원 여부에 따라 Rounding 보정 연산을 위한 최소 단위가 얼마인지 확인한다.
   * 달러면 0.01 원화면 1원이 될 것이다.
   *
   * @param difference
   * @return
   */
  public static Money getSingularityAmount(Money difference) {
    return getSingularityAmount(difference, true);
  }

  public static Money getSingularityAmount(Money difference, boolean useTruncate) {
    Currency currency = difference.getCurrency();
    BigDecimal divisor = new BigDecimal(Math.pow(10, currency.getDefaultFractionDigits()));
    BigDecimal unitAmount = new BigDecimal("1").divide(divisor);

    if (difference.lessThan(BigDecimal.ZERO)) {
      unitAmount = unitAmount.negate();
    }
    Money singular = new Money(unitAmount, currency);

    if(useTruncate){
      singular = singular.multiply(Money.getDefaultTruncationMultiplier());
    }

    return singular;
  }


  private static long countNumberOfUnits(Money difference) {
    double numUnits = difference.multiply(Math.pow(10, difference.getCurrency().getDefaultFractionDigits())).doubleValue();
    return Math.round(Math.abs(numUnits));
  }

  /**
   * 차액(subtracted) 을 그대로 첫번째 아이템에 추가하고 2개의 아이템을 리턴한다.
   * @param quantity
   * @param unitPrice
   * @param plusOperation
   * @param subtracted
   * @return
   */
  private static List<RoundMoneyDTO> getSingularRoundingResult(int quantity, Money unitPrice, boolean plusOperation, Money subtracted) {
    Money singularity = plusOperation ? unitPrice.add(subtracted) : unitPrice.subtract(subtracted);
    int othersCount = quantity - 1;

    return CollectionUtil.list(
        new RoundMoneyDTO().withUnitPrice(singularity).withQuantity(1)
        , new RoundMoneyDTO().withUnitPrice(unitPrice).withQuantity(othersCount)
    );
  }


  /**
   * NullSafe money equals
   * @param money
   * @param other
   * @return
   */
  public static boolean equals(Money money, Money other) {
    if(money == null){
      return other == null;
    }else{

      if(other == null){
        return false;
      }
      return money.equals(other);
    }
  }

  /**
   * Object to Money
   * @param money
   * @return
   */
  public static Money getMoneyObject(Object money) {
    if(money == null)
      return new Money();

    Money price;

    if (money instanceof Money) {
      price = (Money) money;
    } else if (money instanceof Number) {
      price = new Money(((Number) money).doubleValue());
    } else {
      try{
        price = new Money(String.valueOf(money));
      }catch (Exception e){
        ExceptionUtil.printStackTrace(e);
        return null;
      }
    }
    return price;
  }

}
