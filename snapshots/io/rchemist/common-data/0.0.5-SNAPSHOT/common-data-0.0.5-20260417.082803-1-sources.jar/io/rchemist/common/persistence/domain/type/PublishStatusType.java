/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class PublishStatusType extends EnumType<PublishStatusType> {

  public static final PublishStatusType PUBLISHED = new PublishStatusType("PUBLISHED", "Published", "출판 완료. 정상 사용 가능.");
  public static final PublishStatusType DRAFT = new PublishStatusType("DRAFT", "Draft", "정보 작성 중");
  public static final PublishStatusType OUT_DATED = new PublishStatusType("OUT_DATED", "Out dated", "예전 버전 데이터. 새로 버전업된 데이터가 존재한다.");
  public static final PublishStatusType DISCARDED = new PublishStatusType("DISCARDED", "Discarded", "폐기된 데이터. 롤백 등으로 인해 PUBLISHED 였던 데이터가 폐기된 경우.");

  public PublishStatusType(String type, String friendlyType, String description) {
    super(type, friendlyType, description);
  }
}
