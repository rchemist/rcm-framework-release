/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.service.type;

import lombok.Getter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public enum EntityViewType {

  // 목록에 표시될 때
  LIST(false),
  // 일반적인 View 화면에서
  VIEW(true),
  // View 보다 좀 더 detail 한 처리가 필요할 때
  DETAIL(true),
  // 외부 참조용 View 를 만들 때 = 외부 참조용일 때 updatedAt 같은 정보는 필요 없다.
  REFERENCE(false)
  ;

  @Getter
  private final boolean detailView;

  EntityViewType(boolean detailView) {
    this.detailView = detailView;
  }
}
