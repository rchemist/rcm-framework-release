/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.type.PublishStatusType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasPublishStatus.class)
@Getter
@Setter
public class HasPublishStatusImpl implements EnhancedTemplate {

  protected String publishStatus;

  public PublishStatusType getPublishStatus() {
    PublishStatusType status = PublishStatusType.getInstance(PublishStatusType.class, publishStatus);
    if (status == null) {
      return PublishStatusType.DRAFT;
    }
    return status;
  }

  public void setPublishStatus(PublishStatusType publishStatusType) {
    if (publishStatusType == null) {
      this.publishStatus = null;
    } else {
      this.publishStatus = publishStatusType.getType();
    }
  }

}
