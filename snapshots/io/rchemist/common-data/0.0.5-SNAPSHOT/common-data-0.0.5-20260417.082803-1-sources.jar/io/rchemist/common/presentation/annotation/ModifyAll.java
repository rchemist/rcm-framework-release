/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public @interface ModifyAll {

  /**
   * 지원 여부
   *
   * 해당 기능의 모든 개발이 끝날 때 까지 default false 를 유지한다.
   * @return
   */
  boolean support() default false;

  /**
   * 엔티티폼 필드 중 지정된 이름의 필드를 가져온다.
   *
   * support() 가 true 일 때,
   * propertyNames() 와 fields() 의 값이 모두 존재하지 않으면
   * 엔티티폼 필드 중 unique 가 아니면서 수정 가능한(modifiable) 필드를 모두 표시한다.
   * @return
   */
  String[] propertyNames() default {};

  /**
   * 일괄 변경 폼에 표시할 필드를 직접 지정한다.
   *
   * support() 가 true 일 때,
   * propertyNames() 와 fields() 의 값이 모두 존재하지 않으면
   * 엔티티폼 필드 중 unique 가 아니면서 수정 가능한(modifiable) 필드를 모두 표시한다.
   * @return
   */
  AdminField[] fields() default {};

  /**
   * 제외할 필드 - propertyNames, fields 에 지정됐거나 자동으로 선별된 필드에 대해 제거한다.
   * @return
   */
  String[] excludePropertyNames() default {};

}
