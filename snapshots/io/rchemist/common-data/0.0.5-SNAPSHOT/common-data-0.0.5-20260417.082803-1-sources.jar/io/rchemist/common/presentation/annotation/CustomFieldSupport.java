/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface CustomFieldSupport {

  /**
   * 커스텀필드로 사용할 Map<String, Entity> 프로퍼티 이름
   * 이 값이 없으면 비활성화 된다.
   * ex) adminUserAttributes
   * @return
   */
  String value();

  /**
   * Attribute 엔티티에서 부모 엔티티로 매핑되는 프로퍼티
   * ex) adminUserId
   * @return
   */
  String parentId();

  /**
   * Customer -> CustomerAttribute 처럼
   * attribute 정보가 별도의 entity 에 저장되어 있다면
   * 이 값은 false 이다.
   *
   * 하지만 Campaign 처럼 별도의 엔티티가 아니라 같은 테이블에 SimpleAttributes 로
   * attributes 가 처리된 경우 이 값은 true 여야 한다.
   *
   * 이 값이 true 인 경우, 커스텀필드 목록에 표시할 수 있지만 검색/정렬은 지원하지 않는다.
   *
   * @return
   */
  boolean simpleAttribute() default false;

}
