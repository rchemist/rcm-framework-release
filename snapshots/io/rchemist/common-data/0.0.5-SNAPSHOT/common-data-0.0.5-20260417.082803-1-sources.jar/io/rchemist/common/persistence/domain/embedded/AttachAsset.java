/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.embedded;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.rchemist.common.persistence.domain.data.UploadFile;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.RequestParameterUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.data.ParameterDTO;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AttachAsset implements Serializable {

  @Column(name = "ASSET_KEY")
  private String assetKey;

  @Column(name = "ASSET_FILESIZE")
  private Long fileSize;

  @Column(name = "ASSET_URL")
  private String assetUrl;

  @Column(name = "ASSET_TAGS")
  private String[] assetTags;

  @Column(name = "ASSET_LINK")
  private String assetLink;

  public AttachAsset withAssetKey(String assetKey) {
    this.assetKey = assetKey;
    return this;
  }

  public AttachAsset withFileSize(Long fileSize) {
    this.fileSize = fileSize;
    return this;
  }

  public AttachAsset withAssetUrl(String assetUrl) {
    this.assetUrl = assetUrl;
    return this;
  }

  public AttachAsset withAssetTags(String[] assetTags) {
    this.assetTags = assetTags;
    return this;
  }

  public boolean validateAsset(){
    return StringUtils.isNotEmpty(assetKey) && StringUtils.isNotEmpty(assetUrl);
  }

  public AttachAsset withAssetLink(String assetLink) {
    this.assetLink = assetLink;
    return this;
  }

  @JsonIgnore
  public UploadFile getUploadFile(){
    Integer fileSize = this.fileSize == null ? null : NumberUtil.getInteger(this.fileSize);
    return new UploadFile()
        .withAssetKey(getAssetKey())
        .withAssetUrl(getAssetUrl())
        .withAssetTags(getAssetTags())
        .withAssetLink(getAssetLink())
        .withSize(fileSize == null ? 0 : fileSize);
  }

  /**
   * Asset 도메인을 제외한 URI 정보가 반드시 들어와야한다.
   *  - asset 정보 : https://static.rchemist.io/static-resource/banner.jpg?fileSize=100&assetKey=banner
   *  - platform.config.asset.view.domain = https://static.rchemist.io/static-resource 로 설정되어 있다면
   *  - 위에서 설정한 도메인을 제거한 /banner.jpg?fileSize=100&assetKey=banner 를 파라미터로 넣어주어야 한다.
   *
   * @param uri
   * @return
   */
  public static AttachAsset create(String uri){
    if(StringUtils.isNotBlank(uri)) {
      ParameterDTO params = RequestParameterUtil.parseParameters(uri);
      String url = StringUtil.subStringBeforeLast(uri, "?");
      String size = params.getParameter("fileSize");
      String key = params.getParameter("assetKey");
      String[] tag = params.getParameters("assetTag");
      String link = params.getParameter("assetLink");

      return new AttachAsset()
          .withAssetKey(key)
          .withAssetUrl(url)
          .withAssetLink(link)
          .withAssetTags(tag)
          .withFileSize(NumberUtil.getLong(size, null));
    }
    return null;
  }

  public String getUri() {
    Integer fileSize = this.fileSize == null ? null : NumberUtil.getInteger(this.fileSize);
    String uri = getAssetUrl() + "?assetKey="+getAssetKey();
    if(fileSize != null){
      uri = uri + "&fileSize="+fileSize;
    }

    if(ArrayUtils.isNotEmpty(assetTags)){
      for(String tag : assetTags){
        uri = uri + "&assetTag="+tag;
      }
    }

    if(StringUtils.isNotEmpty(assetLink)){
      uri = uri + "&assetLink=" + StringEscapeUtils.escapeJava(assetLink);
    }

    return uri;
  }

}
