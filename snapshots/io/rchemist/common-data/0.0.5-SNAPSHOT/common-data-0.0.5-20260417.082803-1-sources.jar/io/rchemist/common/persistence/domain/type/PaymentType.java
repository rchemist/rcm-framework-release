/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PaymentType extends EnumType<PaymentType> {

  private static final List<PaymentType> INTERNAL_PAYMENT_TYPES = new ArrayList<>();
  private static final List<PaymentType> FINAL_PAYMENT_TYPES = new ArrayList<>();

  public static final PaymentType CREDIT_CARD = new PaymentType(10, "CREDIT_CARD", "Credit Card"
      , "신용카드 결제", "global.type.payment.type.credit.card", true, false, false);
  public static final PaymentType NAVER_PAY = new PaymentType(10, "NAVER_PAY", "Naver Pay"
      , "네이버페이", "global.type.payment.type.naver.pay", true, false, false);
  public static final PaymentType KAKAO_PAY = new PaymentType(10, "KAKAO_PAY", "Kakao Pay"
      , "카카오페이", "global.type.payment.type.kakao.pay", true, false, false);
  public static final PaymentType TRANSFER_BANK= new PaymentType(20, "TRANSFER_BANK", "Transfer - Bank"
      , "실시간 계좌이체. 고객이 별도의 입금 절차 없이 PG에서 자동화된 방식으로 송금 처리하는 모든 방식", "global.type.payment.type.transfer.bank", true, false, false);
  public static final PaymentType COD = new PaymentType(40, "COD", "Cash on Delivery"
      , "배달 시점에 결제하고 상품이나 서비스를 인도하는 결제 유형. COD 결제는 배달 시점에 다른 PaymentType 의 OrderPaymentTransaction 정보를 야기할 수 있다", "global.type.payment.type.cod", false, false, false);
  public static final PaymentType DIGITAL_WALLET = new PaymentType(50, "DIGITAL_WALLET", "Digital wallet(e-Wallet)"
      , "간편결제 서비스", "global.type.payment.type.digital.wallet", true, false, false);
  public static final PaymentType CUSTOMER_CREDIT = new PaymentType(60, "CUSTOMER_CREDIT", "Customer Credit"
      , "고객 적립금", "global.type.payment.type.customer.credit", false, false, true);
  public static final PaymentType GIFT_CARD = new PaymentType(70, "GIFT_CARD", "GiftCard"
      , "기프트카드(무기명 적립금)", "global.type.payment.type.gift.card", false, false, true);
  public static final PaymentType MILEAGE = new PaymentType(80, "MILEAGE", "Mileage"
      , "마일리지", "global.type.payment.type.mileage", false, false, true);
  public static final PaymentType CUSTOMER_PAYMENT = new PaymentType(90, "CUSTOMER_PAYMENT", "Customer Payment"
      , "고객이 저장된 결제수단", "global.type.payment.type.customer.payment", true, false, false);
  public static final PaymentType PASS_THROUGH = new PaymentType(Integer.MAX_VALUE, "PASS_THROUGH", "PassThrough(TEST_MODE)"
      , "테스트모드에서 사용하는 결제수단(Production 에서는 사용하지 않는다)", "global.type.payment.type.pass.through", false, false, false);

  /**
   * 주문서에서 결제 정보를 입력할 때, 결제 정보를 입력함과 동시에 결제 금액에 대한 트랜잭션 처리를 해야 하는지
   *
   * 기프트카드나 적립금처럼 플랫폼 자체에서 제공하는 결제수단의 경우는 CHECKOUT 워크플로우의 맨 마지막에서 한번에 트랜잭션 처리하면 되지만
   * 외부 시스템에 정보를 전송하고 검증 및 트랜잭션 처리를 해야 하는 신용카드나 간편결제 등은 CHECKOUT WORKFLOW에서 PaymentType이 확인될 때 마다 바로 OrderPayment에 트랜잭션 처리를 해야 한다.
   */
  @Getter
  protected boolean finalPayment;

  @Getter
  protected boolean creditRefundable;

  @Getter
  protected boolean internalCredit;

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public PaymentType(int order, String key, String value, String description, String messageKey, boolean transactionImmediately, boolean creditRefundable, boolean internalCredit) {
    super(order, key, value, description, messageKey);
    this.finalPayment = transactionImmediately;
    this.creditRefundable = creditRefundable;
    this.internalCredit = internalCredit;

    if(finalPayment){
      if(!FINAL_PAYMENT_TYPES.contains(this)){
        FINAL_PAYMENT_TYPES.add(this);
      }
    }

    if(internalCredit){
      if(!INTERNAL_PAYMENT_TYPES.contains(this)){
        INTERNAL_PAYMENT_TYPES.add(this);
      }
    }
  }

  public static final List<PaymentType> getFinalPaymentTypes(){
    return FINAL_PAYMENT_TYPES;
  }

  public static final List<PaymentType> getInternalPaymentTypes(){
    return INTERNAL_PAYMENT_TYPES;
  }
}
