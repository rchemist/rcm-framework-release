/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import com.google.common.net.InetAddresses;
import inet.ipaddr.HostName;
import io.rchemist.common.web.request.WebRequestContext;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import org.springframework.http.HttpRequest;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class IpAddressUtil {

  public static String getHostAddress() {
    try{
      return getLocalAddress().getHostAddress();
    } catch (NullPointerException e){
      return "";
    }
  }

  public static String getMacAddress() {
    StringBuilder sb = new StringBuilder();
    try {
      InetAddress ip = getLocalAddress();
      if(ip != null){
        NetworkInterface network = NetworkInterface.getByInetAddress(ip);
        byte[] mac = network.getHardwareAddress();
        if(mac != null) {
          for (int i = 0; i < mac.length; i++) {
            sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
          }
        }
      }
    } catch (SocketException e){
      ExceptionUtil.printStackTrace(e);
    }
    return sb.toString();
  }

  private static InetAddress getLocalAddress() {
    try {
      Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();

      while (networkInterfaces.hasMoreElements()) {
        List<InterfaceAddress> interfaceAddresses = networkInterfaces.nextElement().getInterfaceAddresses();
        for (InterfaceAddress interfaceAddress : interfaceAddresses) {
          InetAddress address =interfaceAddress.getAddress();
          if (address.isSiteLocalAddress()) {
            return address;
          }
        }
      }
    } catch (SocketException e) {
      ExceptionUtil.printStackTrace(e);
    }
    return null;
  }

  private static final String[] CLIENT_IP_HEADERS = {
      "X-Forwarded-For",
      "X-FORWARDED-FOR",
      "Proxy-Client-IP",
      "WL-Proxy-Client-IP",
      "HTTP_X_FORWARDED_FOR",
      "HTTP_X_FORWARDED",
      "HTTP_X_CLUSTER_CLIENT_IP",
      "HTTP_CLIENT_IP",
      "HTTP_FORWARDED_FOR",
      "HTTP_FORWARDED",
      "HTTP_VIA",
      "REMOTE_ADDR"
  };

  public static String getClientIp() {
    HttpRequest request = WebRequestContext.getWebRequestContext().getRequest();
    for (String headerName : CLIENT_IP_HEADERS) {
      if (request.getHeaders().get(headerName) != null) {
        return Objects.requireNonNull(request.getHeaders().get(headerName)).iterator().next();
      }
    }
    return null;
  }



  public static String getLocalHostAddress() {
    String ip;
    try {
      ip = InetAddress.getLocalHost().getHostAddress();
      return ip;
    } catch(UnknownHostException e) {
      ExceptionUtil.printStackTrace(e);
    }
    return null;
  }


  /**
   * 관리자도구 로그인 등에서 IP 주소를
   * @param ipAddress 사용자의 현재 문자열
   * @param allowedIpAddresses 접근 제한된 IP 주소 목록
   * @return
   */
  public static boolean isAllowedIpAddress(String ipAddress, String... allowedIpAddresses) {
    if (allowedIpAddresses == null || allowedIpAddresses.length == 0) {
      return true;
    }
    for (String allowedIp : allowedIpAddresses) {
      if (matchesIpAddress(ipAddress, allowedIp)) {
        return true;
      }
    }
    return false;
  }

  /**
   *
   * @param ipAddress 사용자의 현재 IP 주소
   * @param allowedIpAddresses 접근 제한된 IP 주소 목록
   * @return
   */
  public static boolean isAllowedIpAddress(String ipAddress, List<String> allowedIpAddresses) {
    if (allowedIpAddresses == null || allowedIpAddresses.isEmpty()) {
      return true;
    }
    for (String allowedIp : allowedIpAddresses) {
      if (matchesIpAddress(ipAddress, allowedIp)) {
        return true;
      }
    }
    return false;
  }

  private static boolean matchesIpAddress(String ipAddress, String allowedIp) {
    // 점(.)으로 구분된 IP 주소 부분 처리
    String[] ipParts = ipAddress.split("\\.");
    String[] allowedParts = allowedIp.split("\\.");

    // 각 부분이 동일한지 확인하며 와일드카드(*) 처리
    for (int i = 0; i < 4; i++) {
      if (allowedParts.length <= i) {
        if (i > 0 && allowedParts[i-1].equals("*")) {
          return true;
        }
        return false; // allowedIp가 ipAddress보다 부분이 적으면 매칭 실패
      }
      String allowedPart = allowedParts[i];
      if (allowedPart.equals("*")) {
        continue; // *는 어떤 값도 허용
      }
      if (allowedPart.contains("*")) {
        // 와일드카드(*)가 포함된 부분 처리
        String regex = allowedPart.replace("*", ".*");
        if (!ipParts[i].matches(regex)) {
          return false; // 현재 부분이 매칭되지 않으면 실패
        }
      } else if (!allowedPart.equals(ipParts[i])) {
        return false; // 현재 부분이 매칭되지 않으면 실패
      }
    }

    // 추가적으로 allowedIp가 더 길 경우 처리
    return allowedParts.length == 4;
  }



  public static boolean validate(String ipAddress){
    if(ipAddress == null)
      return false;

    if(InetAddresses.isInetAddress(ipAddress)){
      HostName host = new HostName(ipAddress);
      try{
        host.validate();
        return true;
      }catch (Exception e){
        return false;
      }
    }

    return false;

  }

  public static boolean isValidRestrictIpAddress(String ipAddress){
    // 1. XXX.XXX.XXX.XXX 와 같이 . 으로 구분된 숫자 IP 4 주소
    // 2. *
    // 3. *.*
    // 4. *.*.*.*
    // 5. XXX.*.*.XXX 일부 IP 숫자 대역이 *로 되어 있는 경우
    // 6. XX*.*.*.*
    // 7. XXX.*
    // 8. XXX.XXX.*
    // 9. XXX.XXX.*.*   8, 9번은 모두 동일
    // 유효한 IP 패턴 정의
    // 유효한 형식인지 확인 (숫자 또는 * 조합)
    String ipPattern =
        "^(\\d{1,3}\\*?|\\*)(\\.(\\d{1,3}\\*?|\\*)){0,3}$" + // 숫자+* 조합
            "|^(\\*\\.){0,3}\\*$";                             // 전체가 * 형식
    if (!Pattern.matches(ipPattern, ipAddress)) {
      return false; // 기본 형식에 맞지 않으면 false
    }

    // 숫자 범위(0~255)를 확인
    String[] parts = ipAddress.split("\\.");
    for (String part : parts) {
      if (part.equals("*") || part.contains("*")) {
        continue; // '*' 또는 숫자+* 조합은 범위 체크 제외
      }
      try {
        int value = Integer.parseInt(part);
        if (value < 0 || value > 255) {
          return false; // 숫자가 0~255 범위를 벗어나면 false
        }
      } catch (NumberFormatException e) {
        return false; // 숫자로 변환할 수 없으면 false
      }
    }

    return true; // 모든 조건을 만족하면 true
  }

  /**
   * ADMIN 의 IP 제한 정책을 입력할 때 열거된 IP 주소가 제한 문자열이 맞는지 확인하고, 조건에 맞지 않는 IP 제한 문자열이 있다면 해당 문자열을 반환한다.
   * @param ipAddresses
   * @return
   */
  public static String getInvalidRestrictIpAddress(String... ipAddresses){
    if (ipAddresses != null && ipAddresses.length > 0) {
      return getInvalidRestrictIpAddress(List.of(ipAddresses));
    }
    return null;
  }

  /**
   * ADMIN 의 IP 제한 정책을 입력할 때 열거된 IP 주소가 제한 문자열이 맞는지 확인하고, 조건에 맞지 않는 IP 제한 문자열이 있다면 해당 문자열을 반환한다.
   * @param ipAddresses
   * @return
   */
  public static String getInvalidRestrictIpAddress(List<String> ipAddresses){
    if (ipAddresses != null && !ipAddresses.isEmpty()) {
      for (String ipAddress : ipAddresses) {
        boolean result = isValidRestrictIpAddress(ipAddress);
        if (!result) {
          return ipAddress;
        }
      }
    }
    return null;
  }




}
