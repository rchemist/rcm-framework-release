/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.config.persistence;

import io.rchemist.common.transformer.dto.EntityBean;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EntityBeanContext {

  private static final Map<String, EntityBean<?>> REGISTERED_ENTITY_BEANS = new ConcurrentHashMap<>();
  private static final Map<String, Class<?>> HIBERNATE_SEARCH_ENTITIES = new ConcurrentHashMap<>();

  /**
   * 실제 implClass 와 인터페이스 를 매핑한 테이블
   * io.rchemist.rchemist.event.webhook.domain.WebhookImpl -> io.rchemist.rchemist.event.webhook.domain.Webhook
   */
  private static final Map<String, String> CEILING_ENTITY_CLASS_NAMES = new ConcurrentHashMap<>();

  public static void addRegisteredEntityBean(String entityName, EntityBean<?> entityBean) {
    REGISTERED_ENTITY_BEANS.put(entityName, entityBean);
  }

  public static Map<String, EntityBean<?>> getRegisteredEntityBeans() {
    return REGISTERED_ENTITY_BEANS;
  }

  public static void addHibernateSearchEntity(String entityName, Class<?> entityClass) {
    HIBERNATE_SEARCH_ENTITIES.put(entityName, entityClass);
  }

  public static Map<String, Class<?>> getHibernateSearchEntities() {
    return HIBERNATE_SEARCH_ENTITIES;
  }

  public static void addCeilingEntityClassName(String implClassName, String ceilingClassName) {
    CEILING_ENTITY_CLASS_NAMES.put(implClassName, ceilingClassName);
  }

  public static Map<String, String> getCeilingEntityClassNames() {
    return CEILING_ENTITY_CLASS_NAMES;
  }

  public static void clear() {
    REGISTERED_ENTITY_BEANS.clear();
    HIBERNATE_SEARCH_ENTITIES.clear();
    CEILING_ENTITY_CLASS_NAMES.clear();
  }

  public static EntityBean<?> getRegisterEntityBean(String className) {
    if(!REGISTERED_ENTITY_BEANS.containsKey(className)){
      className = getCeilingEntityClassName(className);
    }

    return REGISTERED_ENTITY_BEANS.getOrDefault(className, null);
  }

  public static String getCeilingEntityClassName(String className){
    String ceilingClassName = CEILING_ENTITY_CLASS_NAMES.get(className);

    ceilingClassName = (ceilingClassName == null) ? className : ceilingClassName;

    if(REGISTERED_ENTITY_BEANS.containsKey(ceilingClassName)){
      return ceilingClassName;
    } else {
      return className;
    }
  }

  public static Set<String> getRegisteredEntityBeanNames(){
    return (MapUtils.isEmpty(REGISTERED_ENTITY_BEANS)) ? null : REGISTERED_ENTITY_BEANS.keySet();
  }

  public static List<Class<?>> getHibernateSearchEntityList(){
    return new ArrayList<>(HIBERNATE_SEARCH_ENTITIES.values());
  }

  public static boolean isRegisteredEntityBean(String name) {
    return REGISTERED_ENTITY_BEANS.containsKey(name);
  }

  public static void putHibernateSearchEntity(String name, Class<?> entityClass) {
    HIBERNATE_SEARCH_ENTITIES.put(name, entityClass);
  }
}
