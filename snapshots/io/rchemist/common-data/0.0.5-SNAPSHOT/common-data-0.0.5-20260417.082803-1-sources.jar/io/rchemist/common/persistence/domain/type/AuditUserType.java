/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Audit 에서 사용하는 User 종류
 *
 **/
public class AuditUserType extends EnumType<AuditUserType> {

  public static final AuditUserType CUSTOMER = new AuditUserType(10, "CUSTOMER","Customer"
      ,"고객","global.type.audit.user.type.customer");
  public static final AuditUserType ADMIN = new AuditUserType(20, "ADMIN","Admin"
      ,"관리자","global.type.audit.user.type.admin");

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public AuditUserType(int order, String key, String value, String description, String messageKey) {
    super(order, key, value, description, messageKey);
  }

  // for jackson deserialize. 굳이 복잡하게 갈 것 없이 그냥 SpringCache 를 사용하는 대상인 경우 private NoArgsConstructor 를 넣어 주자.
  private AuditUserType(){
  }

}
