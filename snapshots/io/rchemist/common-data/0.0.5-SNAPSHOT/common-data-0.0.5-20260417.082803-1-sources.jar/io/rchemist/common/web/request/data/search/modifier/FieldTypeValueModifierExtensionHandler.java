/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search.modifier;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.request.data.FilterItem;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface FieldTypeValueModifierExtensionHandler extends ExtensionHandler {

  Class<?> getAssignableClass();

  /**
   * value 를 변환한다.
   * @param filterItem 에 대해 DB 에 저장된 값으로 검색할 수 있게 검색 정보를 변환한다.
   * @return
   */
  void modifyValue(FilterItem filterItem);

  default ExtensionResultStatusType modifyValue(ExtensionResultHolder<FilterItem> resultHolder) {
    FilterItem filterItem = resultHolder.getResult();
    Class<?> typeClass = filterItem.getFieldType();

    // type이 맞아야 한다.
    if (!isAssignableType(typeClass)) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }

    modifyValue(filterItem);

    resultHolder.setResult(filterItem);
    return ExtensionResultStatusType.HANDLED;
  }

  default boolean isAssignableType(Class<?> typeClass) {
    return typeClass.equals(getAssignableClass()) || getAssignableClass().isAssignableFrom(typeClass);
  }

}
