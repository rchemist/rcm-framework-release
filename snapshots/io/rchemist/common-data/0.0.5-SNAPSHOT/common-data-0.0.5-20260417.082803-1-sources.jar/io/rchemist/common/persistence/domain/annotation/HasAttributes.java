/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 * <p>
 * Bytecode assist를 이용해 getAdditionalAttributeValues 메소드를 자동으로 구현한다
 *
 * @OneToMany(mappedBy = "site", targetEntity = SiteAttribute.class, cascade = { CascadeType.ALL }, orphanRemoval = true)
 * @MapKey(name = "attrName")
 * @BatchSize(size = 50)
 * protected Map<String, SiteAttribute> siteAttributes = new HashMap<>();
 * <p>
 * default Map<String, SiteAttribute> getAdditionalAttributes(){return null;}
 * default void setAdditionalAttributes(Map<String, SiteAttribute> additionalAttributes){};
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface HasAttributes {

  /**
   * Root Entity에 붙을 getter 메소드 자동 생성을 위한 attribute
   * @return
   */
  AttributeMember[] attributes() default {};

  /**
   * AdminUI 에서 Attribute 바깥으로 표시할 필드
   * 커스텀필드로 정의하지 않아도 자동으로 커스텀필드처럼 사용할 수 있다.
   * @return
   */
  ReservedAttribute[] reserved() default {};

  /*
  String name() default "additionalAttributes";              // Map<String, SiteAttribute> 필드의 이름을 지정한다

  Class entityClass() default Attribute.class;      // Map<String, AttributeValue> 의 실제 필드 클래스를 지정한다
*/
    /*
        public Map<String, String> getAdditionalAttributeValues(){
            Map<String, String> siteAttributeValues = siteAttributes.entrySet().stream().collect(Collectors.toMap(entry -> entry.getValue().getAttrName(), entry -> entry.getValue().getAttrValue(), (a, b) -> b));
            return siteAttributeValues;
        }
     */

}
