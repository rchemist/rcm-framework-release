/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.money.Money;
import io.rchemist.common.util.MoneyUtil;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class AdjustmentCalculator implements Serializable {

  public AdjustmentCalculator(Money retailPrice, Money salePrice) {
    if (retailPrice == null || retailPrice.lessThanOrEqual(Money.ZERO)) {
      throw new IllegalArgumentException("retailPrice must not be null or less than zero");
    }
    this.retailPrice = retailPrice;
    this.salePrice = salePrice;
    this.finalPrice = Objects.requireNonNullElse(this.salePrice, this.retailPrice);
  }

  public AdjustmentCalculator(BigDecimal retailPrice, BigDecimal salePrice) {
    this(new Money(retailPrice), salePrice == null ? null : new Money(salePrice));
  }

  public AdjustmentCalculator apply(AdjustmentItem adjustmentItem) {
    adjustmentItem.validate();
    this.adjustmentItems.add(adjustmentItem);
    this.calculate();
    return this;
  }

  @NotNull
  private final Money retailPrice;

  private final Money salePrice;

  private final List<AdjustmentItem> adjustmentItems = new ArrayList<>();

  private Money finalPrice;

  private Money discounted = Money.ZERO;

  @Setter(AccessLevel.PRIVATE)
  private boolean adjusted = false;

  /**
   * 적용된 adjustmentItems 를 모두 처리하고 최종 결과를 리턴한다.
   * @return
   */
  private void calculate() {
    if (salePrice != null && salePrice.lessThan(Money.ZERO)) {
      throw new IllegalArgumentException("salePrice cannot be negative");
    }

    if (adjustmentItems.isEmpty()) {
      return;
    }

    Money finalPrice = this.finalPrice == null ? new Money(salePrice == null ? retailPrice.getAmount() : salePrice.getAmount()) : this.finalPrice;

    for (AdjustmentItem item : adjustmentItems) {
      // 이미 수행된 적이 있으면 skip
      if (item.isDiscounted()) {
        continue;
      }
      Money adjusted = item.applyAndGetResult(retailPrice, finalPrice);
      if (adjusted.lessThan(finalPrice)) {
        finalPrice = adjusted;
        this.adjusted = true;
      }
      if (finalPrice.lessThanOrEqual(Money.ZERO)) {
        break;
      }
    }

    if (!this.finalPrice.equals(finalPrice)) {
      Money discounted = MoneyUtil.safeSubtract(this.finalPrice, finalPrice);
      this.discounted = this.discounted.add(discounted);
    }

    this.finalPrice = finalPrice;
  }


}
