/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.provider;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.util.List;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class EqualQueryProvider implements QueryParseProvider {

  public static final String SPLIT_CODE = "|||";

  @Override
  public boolean isMatched(QueryConditionType conditionType) {
    return conditionType.getParserType().equals(QueryParserType.EQUAL);
  }

  @Override
  public <T> Predicate getPredicate(CriteriaBuilder builder,
      QueryConditionType condition, Path<T> path, Object value, List<?> values) {

    Predicate predicate = null;
    if(value == null && values != null && values.size() > 0){
      value = values.get(0);
    }

    Class<?> javaType = path.getJavaType();

    if (EnumType.class.isAssignableFrom(javaType)) {
      // enumType 인 경우
      if (value instanceof EnumType<?>) {
        // nothing to do
      } else {
        value = EnumTypeUtil.getEnumType((Class<? extends EnumType>) javaType, String.valueOf(value));
      }

    } else {

      String compareValue = StringUtil.getString(value);
      if (condition.equals(QueryConditionType.EQUAL_IGNORECASE) || condition.equals(QueryConditionType.NOT_EQUAL_IGNORECASE)) {
        compareValue = StringUtils.lowerCase(compareValue);
      }

      if (String[].class.isAssignableFrom(javaType)) {
        // String[] 타입에 대한 EQUAL 검색인 경우
        compareValue = SPLIT_CODE + compareValue + SPLIT_CODE;

      }

      if(condition.equals(QueryConditionType.EQUAL_IGNORECASE)){
        if(javaType.equals(String.class) && String.class.isAssignableFrom(value.getClass())){
          predicate = builder.equal(builder.lower((Expression<String>) path), compareValue);
        }
      } else if(condition.equals(QueryConditionType.NOT_EQUAL_IGNORECASE)){
        if(javaType.equals(String.class) && String.class.isAssignableFrom(value.getClass())){
          predicate = builder.notEqual(builder.lower((Expression<String>) path), compareValue);
        }
      }

    }



    if(predicate == null){
      predicate = builder.equal(path, value);
    }

    return (condition.isNegative()) ? predicate.not() : predicate;
  }

  @Override
  public int getOrder() {
    return 100;
  }
}
