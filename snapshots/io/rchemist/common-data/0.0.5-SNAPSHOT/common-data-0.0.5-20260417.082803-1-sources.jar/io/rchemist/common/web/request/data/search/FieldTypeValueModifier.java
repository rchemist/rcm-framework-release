/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.extension.ExtensionManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.search.modifier.FieldTypeValueModifierExtensionManager;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class FieldTypeValueModifier implements SearchFieldModifier {

  protected final FieldTypeValueModifierExtensionManager extensionManager;

  public FieldTypeValueModifier(FieldTypeValueModifierExtensionManager extensionManager) {
    this.extensionManager = extensionManager;
  }

  @Override
  public FilterItem validate(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    if (filterItem.getQueryConditionType() == null || filterItem.getQueryConditionType().isNoValue()) {
      // NULL,NOT_NULL 과 같이 값이 없는 경우 처리하지 않는다.
      return filterItem;
    }

    if (filterItem.getFieldType() != null) {
      Class<?> fieldType = filterItem.getFieldType();

      // fieldType이 String 이 아닌 경우 filterItem의 value를 fieldType으로 변환한다.
      if(!String.class.equals(fieldType) && filterItem.getValue() != null) {

        ExtensionResultHolder<FilterItem> resultHolder = new ExtensionResultHolder<FilterItem>().withResult(filterItem);
        ExtensionResultStatusType status = extensionManager.getProxy().modifyValue(resultHolder);

        if (ExtensionManager.hasExtensionResult(status, resultHolder)) {
          return resultHolder.getResult();
        }

      }
    }

    return filterItem;
  }

  @Override
  public int getOrder() {
    // 가장 먼저 실행되어야 한다.
    return Integer.MIN_VALUE;
  }
}
