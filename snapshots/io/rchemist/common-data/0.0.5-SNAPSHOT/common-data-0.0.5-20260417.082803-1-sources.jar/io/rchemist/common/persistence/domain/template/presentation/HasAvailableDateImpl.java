/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(value = HasAvailableDate.class)
public class HasAvailableDateImpl implements EnhancedTemplate {

  protected String[] availableDate;

  @AdminField(name = "Available_AvailableDateAt", order = 400, required = true
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 400)
      , headerField = @HeaderField(order = 900)
      , defaultValue = "now"
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED), fieldType = PresentationFieldType.DATETIME)
  protected String availableDateAt;

  @AdminField(name = "Available_AvailableDateUntil", order = 500
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 500)
      , headerField = @HeaderField(order = 910)
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED), fieldType = PresentationFieldType.DATETIME)
  protected String availableDateUntil;

  public void setAvailableDate(String[] availableDate) {
    if (availableDate != null && availableDate.length == 2) {
      this.availableDate = availableDate;
      this.availableDateAt = availableDate[0];
      this.availableDateUntil = availableDate[1];
    } else {
      this.availableDate = null;
      this.availableDateAt = null;
      this.availableDateUntil = null;
    }
  }

}
