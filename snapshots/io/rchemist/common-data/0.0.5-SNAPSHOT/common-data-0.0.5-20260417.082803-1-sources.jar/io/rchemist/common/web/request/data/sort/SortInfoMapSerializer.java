/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * sorts Map을 직렬화하는 커스텀 Serializer
 * 
 * 출력 형태:
 * - 일반 정렬: {"fieldName": "DESC"}
 * - 우선순위 정렬: {"fieldName": {"priorityValue": "ACTIVE", "direction": "ASC"}}
 */
@Slf4j
public class SortInfoMapSerializer extends JsonSerializer<LinkedHashMap<String, SortInfo>> {

    @Override
    public void serialize(LinkedHashMap<String, SortInfo> value, JsonGenerator generator, SerializerProvider serializers) 
            throws IOException {
        
        if (value == null) {
            generator.writeNull();
            return;
        }
        
        generator.writeStartObject();
        
        for (Map.Entry<String, SortInfo> entry : value.entrySet()) {
            String fieldName = entry.getKey();
            SortInfo sortInfo = entry.getValue();
            
            generator.writeFieldName(fieldName);
            
            if (sortInfo instanceof PrioritySortInfo) {
                // 우선순위 정렬: 항상 객체로 직렬화
                PrioritySortInfo prioritySort = (PrioritySortInfo) sortInfo;
                generator.writeStartObject();
                generator.writeStringField("type", "priority");
                generator.writeObjectField("priorityValue", prioritySort.getPriorityValue());
                generator.writeStringField("direction", prioritySort.getDirection().name());
                if (prioritySort.getJoinType() != null) {
                    generator.writeStringField("joinType", prioritySort.getJoinType().name());
                }
                if (prioritySort.getNullsFirst() != null) {
                    generator.writeBooleanField("nullsFirst", prioritySort.getNullsFirst());
                }
                generator.writeEndObject();
                
            } else if (sortInfo instanceof NormalSortInfo) {
                NormalSortInfo normalSort = (NormalSortInfo) sortInfo;
                // joinType이나 nullsFirst가 설정된 경우 객체로 직렬화
                if (normalSort.getJoinType() != null || normalSort.getNullsFirst() != null) {
                    generator.writeStartObject();
                    generator.writeStringField("type", "normal");
                    generator.writeStringField("direction", normalSort.getDirection().name());
                    if (normalSort.getJoinType() != null) {
                        generator.writeStringField("joinType", normalSort.getJoinType().name());
                    }
                    if (normalSort.getNullsFirst() != null) {
                        generator.writeBooleanField("nullsFirst", normalSort.getNullsFirst());
                    }
                    generator.writeEndObject();
                } else {
                    // 기본 정렬: 단순 문자열로 직렬화
                    generator.writeString(normalSort.getDirection().name());
                }
                
            } else {
                // 기타 SortInfo 구현체가 있을 경우 기본값으로 처리
                log.warn("Unknown SortInfo type: {}, serializing as normal sort", 
                    sortInfo.getClass().getSimpleName());
                generator.writeString(sortInfo.getDirection().name());
            }
        }
        
        generator.writeEndObject();
        log.debug("Serialized {} sort fields", value.size());
    }
}