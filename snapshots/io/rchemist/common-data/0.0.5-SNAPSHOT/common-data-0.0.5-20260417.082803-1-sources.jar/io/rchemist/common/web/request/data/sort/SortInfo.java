/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort.Direction;

/**
 * 정렬 정보를 나타내는 추상 클래스
 * 일반 정렬(NormalSortInfo)과 우선순위 정렬(PrioritySortInfo)의 기본 클래스
 */
@Getter
@Setter
public abstract class SortInfo {
    
    protected Direction direction;
    
    /**
     * JOIN 타입 (LEFT, INNER, RIGHT)
     * 기본값: null (기존 동작 유지 - QuerySpecification에서 결정)
     * 명시적으로 설정 시 해당 JOIN 타입 사용
     */
    @JsonProperty("joinType")
    protected JoinType joinType;
    
    /**
     * NULL 값 정렬 위치
     * null: 기본 동작 (ASC는 nullsFirst, DESC는 nullsLast)
     * true: NULL을 처음에 위치
     * false: NULL을 마지막에 위치
     */
    @JsonProperty("nullsFirst")
    protected Boolean nullsFirst;
    
    protected SortInfo(Direction direction) {
        this.direction = direction != null ? direction : Direction.ASC;
    }
    
    /**
     * 우선순위 정렬인지 여부
     * @return true if this is priority sort, false for normal sort
     */
    public abstract boolean isPriority();
    
    /**
     * JPA Criteria API Order 객체들을 생성
     * 
     * @param criteriaBuilder JPA CriteriaBuilder
     * @param path 정렬 대상 필드의 Path
     * @return JPA Order 객체들의 리스트 (우선순위 정렬의 경우 여러 Order가 반환될 수 있음)
     */
    public abstract List<Order> createJpaOrders(CriteriaBuilder criteriaBuilder, Path<?> path);
    
    /**
     * 정렬 타입을 문자열로 반환 (JSON 직렬화용)
     * @return "normal" 또는 "priority"
     */
    public abstract String getType();
}