/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search.modifier;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.Arrays;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = FieldTypeValueModifierExtensionManager.BEAN_NAME, priority = 1)
public class JavaEnumTypeValueExtensionHandler implements FieldTypeValueModifierExtensionHandler {

  @Override
  public ExtensionResultStatusType modifyValue(ExtensionResultHolder<FilterItem> resultHolder) {
    FilterItem filterItem = resultHolder.getResult();
    Class<?> typeClass = filterItem.getFieldType();

    // typeClass 가 java enum 이어야 한다.
    if (!typeClass.isEnum()) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }

    if (filterItem.hasSingleValue()) {
      Object value = getEnumValue(filterItem.getValue(), typeClass);

      filterItem.setValue(value);

    } else if (filterItem.hasMultipleValues()) {

      filterItem.setValues(
          Arrays.stream(filterItem.getValues()).map(value -> getEnumValue(value, typeClass)).toArray());

    }

    resultHolder.setResult(filterItem);
    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public boolean isAssignableType(Class<?> typeClass) {
    // typeClass 가 java 의 enum 인지 확인한다.
    return typeClass.isEnum();
  }

  @Override
  public Class<?> getAssignableClass() {
    return null;
  }

  @Override
  public void modifyValue(FilterItem filterItem) {

  }

  private Object getEnumValue(Object value, Class<?> typeClass) {
    try {
      // 문자열을 해당 Enum 값으로 변환
      Enum<?> enumValue = Enum.valueOf((Class<Enum>)typeClass, String.valueOf(value));
      // filterItem의 값을 변환된 Enum 값으로 설정
      return enumValue;
    } catch (IllegalArgumentException e) {
      // 주어진 문자열이 해당 Enum 클래스에 정의된 상수와 일치하지 않을 때 예외 처리
      e.printStackTrace(); // 또는 다른 예외 처리 로직을 추가하세요.
    }
    return value;
  }

}
