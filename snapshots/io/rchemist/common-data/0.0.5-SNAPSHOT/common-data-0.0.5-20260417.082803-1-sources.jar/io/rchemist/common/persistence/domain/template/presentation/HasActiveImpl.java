/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(value = HasActive.class)
public class HasActiveImpl implements EnhancedTemplate {

  @AdminField(name = "SoftDeleteImpl_Active"
      , modifiableType = ModifiableType.MODIFY_ONLY
      , fieldType = PresentationFieldType.BOOLEAN, order = 1000, tab = @ViewTab(type = TabEnumType.STATUS), headerField = @HeaderField(order = 10000))
  protected Boolean active;

  public boolean isActive(){
    return (BooleanUtils.toBooleanDefaultIfNull(active, true));
  }

  public void setActive(Boolean active){
    this.active = BooleanUtils.toBooleanDefaultIfNull(active, true);
  }

}
