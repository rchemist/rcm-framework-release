/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.rchemist.common.configuration.ApplicationContextHolder;
import javax.cache.Cache;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CommonCacheHelper {

  private static CommonCacheManager cacheManager;
  
  public static CommonCacheManager getCacheManager() {
    if (cacheManager == null) {
      cacheManager = ApplicationContextHolder.getBean(CommonCacheManager.BEAN_NAME,
          CommonCacheManager.class);
    }
    return cacheManager;
  }

  private static CommonCacheManager getCacheManager(CommonCacheManager manager) {
    return manager == null ? getCacheManager() : manager;
  }

  public static <V> Cache<String, V> getCache(String alias) {
    return getCacheManager().getCache(alias);
  }

  public static <V> Cache<String, V> getCache(Class<?> keyClass, Class<?> typeClass, String regionName,
      int maxTtl, int maxEntries) {
    return getCacheInternal(null, keyClass, typeClass, regionName, maxTtl, maxEntries);
  }
  
  public static <V> Cache<String, V> getCache(CommonCacheManager cacheManager, Class<?> keyClass,
      Class<?> typeClass, String regionName, int maxTtl, int maxEntries) {

    if (cacheManager == null) {
      cacheManager = getCacheManager();
    }

    return getCacheInternal(cacheManager, keyClass, typeClass, regionName, maxTtl, maxEntries);
  }

  private static <V> Cache<String, V> getCacheInternal(CommonCacheManager cacheManager, Class<?> keyClass, Class<?> typeClass, String regionName,
      int maxTtl, int maxEntries) {
    return getCacheManager(cacheManager).getOrCreateCache(new CacheConfiguration()
        .withValueClass(typeClass)
        .withRegion(regionName)
        .withTtl(maxTtl)
        .withMaxEntries(maxEntries));
  }

}
