/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class CacheConfiguration implements Serializable {

  public static final int DEFAULT_MAX_ENTRIES = 1000;

  public static final int DEFAULT_TTL = 60 * 60 * 24 * 30;

  private String region;

  private Integer maxEntries;

  private Integer ttl;    // 무제한으로 하려면 0

  private Class<?> valueClass;

  public CacheConfiguration(String region, Integer maxEntries, Integer ttl) {
    this.region = region;
    this.maxEntries = maxEntries;
    this.ttl = ttl;
  }

  public CacheConfiguration(String region, Integer maxEntries, Integer ttl, Class<?> valueClass) {
    this.region = region;
    this.maxEntries = maxEntries;
    this.ttl = ttl;
    this.valueClass = valueClass;
  }

  public CacheConfiguration() {
  }

  public boolean isEternal() {
    return getTtl() <= 0;
  }

  public int getMaxEntries() {
    return maxEntries == null ? DEFAULT_MAX_ENTRIES : maxEntries;
  }

  public int getTtl() {
    return ttl == null ? DEFAULT_TTL : ttl;
  }

  public CacheConfiguration withRegion(String region) {
    this.region = region;
    return this;
  }

  public CacheConfiguration withMaxEntries(int maxEntries) {
    this.maxEntries = maxEntries;
    return this;
  }

  public CacheConfiguration withTtl(int ttl) {
    this.ttl = ttl;
    return this;
  }

  public CacheConfiguration withValueClass(Class<?> valueClass) {
    this.valueClass = valueClass;
    return this;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    CacheConfiguration that = (CacheConfiguration) object;

    return new EqualsBuilder().append(region, that.region)
        .append(maxEntries, that.maxEntries).append(ttl, that.ttl)
        .append(valueClass, that.valueClass).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(region).append(maxEntries).append(ttl)
        .append(valueClass).toHashCode();
  }

  @Override
  public String toString() {
    return "CacheConfiguration{" +
        "region='" + region + '\'' +
        ", maxEntries=" + maxEntries +
        ", ttl=" + ttl +
        ", valueClass=" + valueClass +
        '}';
  }

  public boolean validate() {
    return StringUtils.isNotEmpty(region) && valueClass != null;
  }

  public boolean hasRegion() {
    return StringUtils.isNotEmpty(region);
  }

  public CacheConfiguration cloned() {
    return new CacheConfiguration(region, maxEntries, ttl, valueClass);
  }
}
