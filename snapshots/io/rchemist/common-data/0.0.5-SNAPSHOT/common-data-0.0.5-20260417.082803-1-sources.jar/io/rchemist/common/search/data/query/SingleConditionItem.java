/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.QueryHelper;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.persistence.query.type.QueryParserType;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class SingleConditionItem implements QueryConditionItem {

  protected SingleConditionItem(String propertyName, Object value) {
    this(propertyName, QueryConditionType.EQUAL, value);
  }

  public SingleConditionItem(String propertyName, QueryConditionType conditionType, Object value) {
    this.propertyName = propertyName;
    this.conditionType = conditionType;
    this.value = value;
  }

  @Setter
  private boolean applyOnClause = false;

  @Setter
  private boolean jsonFilter = false;

  private final String propertyName;

  private final QueryConditionType conditionType;

  private final Object value;

  @Setter
  private JoinType joinType;

  public static SingleConditionItem like(String propertyName, Object value) {
    return new SingleConditionItem(propertyName, QueryConditionType.LIKE, value);
  }

  public static SingleConditionItem isNull(String propertyName){
    return new SingleConditionItem(propertyName, QueryConditionType.NULL, null);
  }

  public static SingleConditionItem notNull(String propertyName){
    return new SingleConditionItem(propertyName, QueryConditionType.NOT_NULL, null);
  }

  public static SingleConditionItem notIn(String propertyName, Object value){
    return new SingleConditionItem(propertyName, QueryConditionType.NOT_IN, value);
  }

  public static SingleConditionItem equal(String propertyName, Object value){
    return new SingleConditionItem(propertyName, value);
  }

  public static SingleConditionItem startWith(String propertyName, Object value){
    return new SingleConditionItem(propertyName, QueryConditionType.START_WITH, value);
  }

  public static SingleConditionItem notEqual(String propertyName, Object value){
    return new SingleConditionItem(propertyName, QueryConditionType.NOT_EQUAL, value);
  }

  public SingleConditionItem withJoinType(JoinType joinType){
    this.joinType = joinType;
    return this;
  }

  public SingleConditionItem withJsonFilter(boolean jsonFilter) {
    this.jsonFilter = jsonFilter;
    return this;
  }

  @Override
  public boolean equals(Object obj) {
    if(obj == null || !(obj instanceof SingleConditionItem))
      return false;

    SingleConditionItem other = (SingleConditionItem) obj;

    if(!this.propertyName.equals(other.propertyName))
      return false;

    if(!this.conditionType.equals(other.conditionType))
      return false;

    if (!Objects.equals(this.value, other.value))
      return false;

    return (Objects.deepEquals(this.joinType, other.joinType));

  }

  @Override
  public Predicate getPredicate(CriteriaBuilder criteriaBuilder, Path path) {
    Path queryPath;
    if (isJsonFilter()) {
      String propertyName = StringUtils.substringBefore(getPropertyName(), ".");
      String jsonPath = StringUtils.substringAfter(getPropertyName(), ".");

      if (conditionType.equals(QueryConditionType.EQUAL) || conditionType.equals(QueryConditionType.LIKE)) {
        return criteriaBuilder.like(path, "%\""+jsonPath+"\":\""+value+"\"%");
      } else {
        if (conditionType.equals(QueryConditionType.NOT_EQUAL) || conditionType.equals(QueryConditionType.NOT_LIKE)) {
          return criteriaBuilder.notLike(path, "%\""+jsonPath+"\":\""+value+"\"%");
        }
        if (conditionType.equals(QueryConditionType.NULL)) {
          return criteriaBuilder.notLike(path, "%\""+jsonPath+"\":");
        } else if (conditionType.equals(QueryConditionType.NOT_NULL)) {
          return criteriaBuilder.like(path, "%\""+jsonPath+"\":");
        }
      }

      throw new RuntimeException("Json filter not supported for condition type: " + conditionType);

    } else {
      queryPath = path;
    }

    if(conditionType.getParserType().equals(QueryParserType.COLLECTION)){
      // if values if not a collection but array, then we will convert it into a collection
      return getArrayValuePredicate(criteriaBuilder, queryPath);
    }else{
      if(conditionType.equals(QueryConditionType.BETWEEN) || conditionType.equals(QueryConditionType.NOT_BETWEEN)){
        return getArrayValuePredicate(criteriaBuilder, queryPath);
      }else{
        return QueryHelper.getConditionPredicate(criteriaBuilder, conditionType, queryPath, value, null);
      }
    }

  }

  @Override
  public String[] getPropertyNames() {
    return new String[]{getPropertyName()};
  }

  protected Predicate getArrayValuePredicate(CriteriaBuilder criteriaBuilder, Path path) {
    if(value != null){
      List values = getArrayValues();

      return QueryHelper.getConditionPredicate(criteriaBuilder, conditionType, path, null, values);
    }

    return QueryHelper.getConditionPredicate(criteriaBuilder, conditionType, path, null, (List<?>) value);
  }

  public final List getArrayValues() {
    List values = new ArrayList<>();

    if (value.getClass().isArray()) {
      for(Object item : (Object[]) value){
        values.add(item);
      }
    } else {
      if (value instanceof Collection) {
        values.addAll((Collection) value);
      } else {
        values.add(value);
      }
    }
    return values;
  }

  public boolean isSameProperty(SingleConditionItem singleItem) {
    return StringUtils.equals(propertyName, singleItem.getPropertyName());
  }

  public boolean isOuterJoin() {
    return getJoinType() != null && !getJoinType().equals(JoinType.INNER);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("applyOnClause", applyOnClause)
        .append("jsonFilter", jsonFilter)
        .append("propertyName", propertyName)
        .append("conditionType", conditionType)
        .append("value", value)
        .append("joinType", joinType)
        .toString();
  }
}
