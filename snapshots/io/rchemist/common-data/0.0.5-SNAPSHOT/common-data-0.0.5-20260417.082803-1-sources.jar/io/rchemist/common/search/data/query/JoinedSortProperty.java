/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import lombok.Getter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.domain.Sort.Direction;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class JoinedSortProperty implements Serializable {

  public JoinedSortProperty(String path, JoinType joinType, Direction direction, QueryConditionItem joinCondition) {
    this.path = path;
    this.joinType = joinType;
    this.joinCondition = joinCondition;
    this.direction = (direction == null) ? Direction.ASC : direction;
  }

  private final String path;

  private final JoinType joinType;

  private final QueryConditionItem joinCondition;

  private final Direction direction;

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("path", path)
        .append("joinType", joinType)
        .append("joinCondition", joinCondition)
        .append("direction", direction)
        .toString();
  }
}
