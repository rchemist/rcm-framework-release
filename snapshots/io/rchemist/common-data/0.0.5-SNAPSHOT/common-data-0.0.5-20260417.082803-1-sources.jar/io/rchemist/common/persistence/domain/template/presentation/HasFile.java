/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.data.FileInfo;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasFile<T> extends ClassTransformTarget {

  default List<FileInfo> getExistFiles() {
    throw new ClassTransformException();
  }

  default void setExistFiles(List<FileInfo> existFiles) {
    throw new ClassTransformException();
  }

  default List<FileInfo> getNewFiles() {
    throw new ClassTransformException();
  }

  default void setNewFiles(List<FileInfo> newFiles) {
    throw new ClassTransformException();
  }

  default List<FileInfo> getDeleteFiles() {
    throw new ClassTransformException();
  }

  default void setDeleteFiles(List<FileInfo> deleteFiles) {
    throw new ClassTransformException();
  }

  default T addNewFile(FileInfo fileInfo) {
    List<FileInfo> newFiles = getNewFiles();
    if (newFiles == null) {
      newFiles = new ArrayList<>();
    }
    newFiles.add(fileInfo);
    setNewFiles(newFiles);
    return (T) this;
  }

  default T addDeleteFile(FileInfo fileInfo) {
    List<FileInfo> deleteFiles = getDeleteFiles();
    if (deleteFiles == null) {
      deleteFiles = new ArrayList<>();
    }
    deleteFiles.add(fileInfo);
    setDeleteFiles(deleteFiles);
    return (T) this;
  }

  default T addExistFile(FileInfo fileInfo) {
    List<FileInfo> existFiles = getExistFiles();
    if (existFiles == null) {
      existFiles = new ArrayList<>();
    }
    existFiles.add(fileInfo);
    setExistFiles(existFiles);
    return (T) this;
  }

  default T withExistFiles(List<FileInfo> existFiles) {
    setExistFiles(existFiles);
    return (T) this;
  }

  default T withNewFiles(List<FileInfo> newFiles) {
    setNewFiles(newFiles);
    return (T) this;
  }

  default T withDeleteFiles(List<FileInfo> deleteFiles) {
    setDeleteFiles(deleteFiles);
    return (T) this;
  }



}
