/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.util.StringUtil;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by kunner
 **/
public enum MaskingType {
  NO_MASK,    // 마스킹 하지 않음, 기본값
  HIDDEN_ALL,       // 전체 값을 모두 마스킹 처리
  AFTER_LEFT,       // 왼쪽부터 x 자 이후 마스킹 처리
  BEFORE_RIGHT,    // 오른쪽에서 x 자만 마스킹
  AFTER_RIGHT,      // 오른쪽부터 x 자 이후 마스킹 처리
  AFTER_LAST_SPACE    // 마지막 공백 이후 마스킹 처리 (address 와 같은 정보)
  , MIDDLE_4
  , LOGIN_NAME   // 원문의 길이가 padding 값 이하면 왼쪽에서 (padding - 2 또는 1) 만큼 보여주고 나머지 마스킹, 왼쪽에서 (padding) 만큼 빼고 (padding) 길이만큼 마스킹,
  , FULL_NAME   // padding 값 만큼 이름을 보여주고 나머지는 마스킹 - 한국 이름의 경우 외자 처리 등의 문제가 있으므로
  , EMAIL   // padding 값 만큼 아이디를 보여 주고 ***@rchemist.io    @ 뒤의 도메인은 모두 보여준다.
  , EXCLUDE_NUMBER    // 숫자만 마스킹 : 한국형 주소 처리할 때 사용 *** 동 *** 호
  ,NOT_SET;   // 오버라이드 되지 않음, NO_MASK 와 동작은 같으나 오버라이드 유무를 판단하기 위해 사용함


  private static final String MASKING_CHARACTER = "*";

  public static String getMaskingResult(String origin, MaskingType maskingType, int padding) {
    if (StringUtils.isBlank(origin) || maskingType.equals(MaskingType.NO_MASK) || maskingType.equals(NOT_SET)) {
      return origin;
    }

    if (maskingType.equals(MaskingType.HIDDEN_ALL)) {
      return StringUtil.fill(MASKING_CHARACTER, origin.length());
    } else if (maskingType.equals(MaskingType.AFTER_LEFT)) {
      String left = StringUtils.left(origin, padding);
      String masking = StringUtil.fill(MASKING_CHARACTER, origin.length() - padding);
      return left + masking;
    } else if(maskingType.equals(MaskingType.BEFORE_RIGHT)){
      String left = StringUtils.substring(origin, 0, origin.length() - (padding));
      return left + StringUtil.fill(MASKING_CHARACTER, padding);

    } else if (maskingType.equals(MaskingType.AFTER_RIGHT)) {
      String right = StringUtils.right(origin, padding);
      String masking = StringUtil.fill(MASKING_CHARACTER, origin.length() - padding);
      return masking + right;
    } else if (maskingType.equals(MaskingType.AFTER_LAST_SPACE)) {
      String left = StringUtils.substringBeforeLast(origin, " ");
      return (StringUtils.isEmpty(left)) ? origin : left;
    } else if (maskingType.equals(MaskingType.MIDDLE_4)) {
      // 가운데 4 자리만 ****

      int length = origin.length();

      if(length <= padding)
        return origin;

      String left = StringUtils.left(origin, padding);

      if(length < (padding + 4)){
        return left + StringUtil.fill(MASKING_CHARACTER, (length - padding));
      }

      String right = StringUtils.right(origin, length - (padding + 4));
      return left + StringUtil.fill(MASKING_CHARACTER, 4) + right;

    } else if (maskingType.equals(MaskingType.EMAIL)) {

      if(!StringUtils.contains(origin, "@"))
        return getMaskingResult(origin, MaskingType.AFTER_LEFT, padding);

      String emailId = StringUtils.substringBefore(origin, "@");
      String emailDomain = "@"+StringUtils.substringAfter(origin, "@");
      emailId = getMaskingResult(emailId, AFTER_LEFT, padding);
      return emailId + emailDomain;
    } else if (maskingType.equals(MaskingType.FULL_NAME)) {
      // 한글만 (영어, 숫자 포함 이름은 제외)
      String regex = "(^[가-힣]+)$";
      int maskingNameLength = padding + 1;
      Matcher matcher = Pattern.compile(regex).matcher(origin);
      if (matcher.find()) {
        int length = origin.length();
        String middleMask;
        if (length > maskingNameLength) {
          middleMask = origin.substring(1, length - padding);
        } else { // 이름이 외자
          middleMask = origin.substring(1, length);
        }

        String dot = StringUtil.fill(MASKING_CHARACTER, middleMask.length());

        if (length > maskingNameLength) {
          return origin.charAt(0) + middleMask.replace(middleMask, dot) + origin.charAt(length - padding);
        } else { // 이름이 외자 마스킹 리턴
          return origin.charAt(0) + middleMask.replace(middleMask, dot);
        }
      }
      return origin;
    }else if(maskingType.equals(MaskingType.EXCLUDE_NUMBER)){
      return origin.replaceAll("[0-9]", MASKING_CHARACTER);
    } else if(maskingType.equals(MaskingType.LOGIN_NAME)){
      if(origin.length() <= padding){
        return getMaskingResult(origin, MaskingType.AFTER_LEFT, 1);
      }else{
        int length = origin.length();
        padding = (padding > 1) ? padding - 1 : padding;
        String left = StringUtils.left(origin, padding);
        if(length > (padding * 2) ){
          String right = StringUtils.right(origin, length - padding);
          right = getMaskingResult(right, MaskingType.AFTER_RIGHT, right.length() - padding - 1);
          return left + right;
        }else{
          return left + StringUtil.fill(MASKING_CHARACTER, length - padding);
        }
      }
    }

    return null;
  }

  public static MaskingType getType(String value) {
    MaskingType maskingType = MaskingType.valueOf(value);
    return maskingType == null ? MaskingType.NO_MASK : maskingType;
  }
}
