/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query;

import io.rchemist.common.persistence.query.dto.RestrictSearchField;
import io.rchemist.common.persistence.query.dto.SearchField;
import io.rchemist.common.persistence.query.dto.SortField;
import io.rchemist.common.persistence.query.provider.CollectionQueryProvider;
import io.rchemist.common.persistence.query.provider.CompareQueryProvider;
import io.rchemist.common.persistence.query.provider.EqualQueryProvider;
import io.rchemist.common.persistence.query.provider.LikeQueryProvider;
import io.rchemist.common.persistence.query.provider.NullQueryProvider;
import io.rchemist.common.persistence.query.provider.QueryParseProvider;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.CollectionUtil;
import jakarta.persistence.Query;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.From;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class QueryHelper {

  private static final List<QueryParseProvider> providers;

  static {

    List<QueryParseProvider> list = CollectionUtil.list(
        new CompareQueryProvider(), new CollectionQueryProvider(), new EqualQueryProvider(), new LikeQueryProvider(), new NullQueryProvider()
    );

    list.sort(Comparator.comparing(QueryParseProvider::getOrder));
    providers = list;
  }

  public static List<Predicate> addSubQueryCondition(CriteriaBuilder builder, Root root, Set<SearchField> searchFields) {
    return addSubQueryCondition(builder, root, searchFields, null, null, null, null);
  }



  public static List<Predicate> addSubQueryCondition(CriteriaBuilder builder, Root root, Set<SearchField> searchFields,
                                                     List<RestrictSearchField> restrictSearchFields){
    if(CollectionUtils.isEmpty(restrictSearchFields))
      return addSubQueryCondition(builder, root, searchFields);

    Set<SearchField> filteredSearchFields = new HashSet<>();
    for(RestrictSearchField restrictSearchField: restrictSearchFields){
      for(SearchField searchField : searchFields){
        SearchField newSearchField = restrictSearchField.getAlternativeSearchField(searchField);
        if(newSearchField != null){
          filteredSearchFields.add(newSearchField);
        }
      }
    }

    return addSubQueryCondition(builder, root, filteredSearchFields);
  }

  /**
   * SearchCondition 에 들어가는 필드가 CustomField (어드민에서 만들어 사용하는 필드) 라 한다면 CustomField 의 이름, 값과 CustomField 를 저장하는 Entity 를 지정해줘야 한다.
   * 예를 들어, CustomEntity 에서 생성한 CustomField 는 CustomEntity.fieldValues 에 저장되고, * 생성된 CustomField 의 Name 은 name, Value 는 value 에 저장된다.
   *
   * @param builder
   * @param root
   * @param searchFields
   * @param customFieldEntityName   커스텀 필드 이름과 값이 저장된 엔티티 이름 (커스텀 필드 저장소)
   * @param customFieldNameField    커스텀 필드 저장소에 이름이 저장되는 필드 이름
   * @param customFieldValueField   커스텀 필드 저장소에 값이 저장되는 필드 이름
   * @param identifier              커스텀 필드를 구분하기 위해 사용되는 구분자
   * @return
   */
  public static List<Predicate> addSubQueryCondition(CriteriaBuilder builder, Root root, Set<SearchField> searchFields
      , String customFieldEntityName, String customFieldNameField, String customFieldValueField, String identifier) {

    List<Predicate> predicates = new ArrayList<>();

    for(SearchField searchField : CollectionUtils.emptyIfNull(searchFields)) {

      // searchField 가 관리자도구를 통해 만들어진 필드인지 판단 (예를 들어 CustomEntity 에서 만들어진 필드)
      boolean isCustomField = BooleanUtils.toBooleanDefaultIfNull(StringUtils.startsWith(searchField.getName(), identifier), false);

      String name = searchField.getName();
      String value = searchField.getValue();
      String[] values = searchField.getValues();		// 복수로 지정된 값은 String[] 로 처리
      QueryConditionType condition = searchField.getCondition();

      Predicate pred;

      List directValues = (values == null) ? CollectionUtil.list(value) : CollectionUtil.list(values);

      if(!isCustomField) {
        pred = getConditionPredicate(builder, condition, root.get(name), value, directValues);

      } else {
        /*
         * custom 한 필드라 한다면, 생성된 필드의 이름과 값을 저장하는 테이블이 있다.
         * custom 한 필드를 생성하는 시점에는 이름에 구분자를 함께 저장하지 않지만, 해당 필드가 custom 하게 만들어졌다는 것을 알리기 위해 Identifier 를 붙인다.
         * 따라서 데이터 베이스에서 값을 꺼낼때는 구분자를 제거해줘야 한다.
         */
        name = StringUtils.removeStart(name, identifier);

        /*
         * 또한, custom 한 필드를 꺼낼때도, custom 필드를 저장하는 테이블에 따라 이름을 저장하는 필드 이름, 값을 저장하는 필드 이름이 달라질 수 있다.
         * Predicate 를 만들 때 변경해줘야 한다.
         */
        Join join = root.join(customFieldEntityName, JoinType.LEFT);

        Predicate namePred = builder.equal(join.get(customFieldNameField), name);
        Predicate valuePred = QueryHelper.getConditionPredicate(builder, condition, join.get(customFieldValueField), value, directValues);

        pred = builder.and(namePred, valuePred);
      }

      if(pred != null) predicates.add(pred);
    }

    return predicates;
  }

  public static <T> Predicate getConditionPredicate(CriteriaBuilder builder, QueryConditionType condition, Path<T> path, Object value, List<?> values){
    if(value == null && CollectionUtils.isNotEmpty(values)) value = values.get(0);

    for(QueryParseProvider provider : providers){
      if(provider.isMatched(condition)){
        return provider.getPredicate(builder, condition, path, value, values);
      }
    }
    return null;
  }

  /**
   * Use inside only, List<Object> to List<Long>
   * @param values
   * @return
   */
  private static List<Long> getLongValues(List<?> values){
    List<Long> list = new ArrayList<>();
    for(Object value : values){
      try{
        if(value != null){
          list.add(Long.parseLong(String.valueOf(value)));
        }
      }catch(Exception e){
        // nothing to do
      }
    }

    return list;
  }

  /**
   * Use inside Only, List<Object> to List<Integer>
   * @param values
   * @return
   */
  private static List<Integer> getIntValues(List<?> values){
    List<Integer> list = new ArrayList<>();
    for(Object value : values){
      try{
        list.add(Integer.valueOf(String.valueOf(value)));
      }catch(Exception e){
        // nothing to do
      }
    }
    return list;
  }

  /**
   * Use inside only, List<String> to List<Date>
   * @param values
   * @return
   */
  private static List<java.util.Date> getDateValues(List<?> values){
    List<java.util.Date> list = new ArrayList<>();
    for(Object value : values){
      try{
        list.add((java.util.Date) value);
      }catch(Exception e){
        // nothing to do
      }
    }
    return list;
  }

  /**
   * Use inside only, List<String> to List<Date>
   * @param values
   * @return
   */
  private static List<LocalDateTime> getLocalDateTimeValues(List<?> values){
    List<LocalDateTime> list = new ArrayList<>();
    for(Object value : values){
      try{
        list.add((LocalDateTime) value);
      }catch(Exception e){
        // nothing to do
      }
    }
    return list;
  }

  private static List<String> getConditionalString(String str, String condition){
    if(StringUtils.equals(condition, "in")){
      return Arrays.asList(StringUtils.split(str, ","));
    }else{
      return Arrays.asList(str);
    }
  }

  public static List<Predicate> addAvailableDateTimePredicate(CriteriaBuilder builder, Root<?> root, LocalDateTime currentDate, List<Predicate> predicates) {
    predicates.add(builder.and(
        builder.or(builder.isNull(root.get("availableAt")), builder.lessThan(root.get("availableAt").as(LocalDateTime.class), currentDate))
        , builder.or(
            builder.isNull(root.get("availableUntil")),
            builder.greaterThan(root.get("availableUntil").as(LocalDateTime.class), currentDate))
    ));
    return predicates;
  }

  /**
   * Paging SortField 를 사용해 Sort 처리
   * @param builder
   * @param criteria
   * @param root
   * @param idFieldName
   * @param sortFields
   * @param useSortPriority
   * @return
   */
  public static CriteriaQuery setOrderStatement(CriteriaBuilder builder, CriteriaQuery criteria, Root root, String idFieldName, Collection<SortField> sortFields, boolean useSortPriority){
    List<Order> orders = new ArrayList<>();

    if(CollectionUtils.isNotEmpty(sortFields)){

      for(SortField sortField : sortFields){

        Path path = null;

        String name = sortField.getName();
        String type = StringUtils.defaultIfBlank(sortField.getType(), "asc");

        // join 구문 처리
        if(StringUtils.contains(name, ".")){
          String[] names = StringUtils.split(name, ".");
          String joinField = names[0];
          String remainField = StringUtils.substringAfter(name, joinField+".");
          path = root.join(joinField).get(remainField);
        }else{
          path = root.get(name);
        }

        if(StringUtils.isNotBlank(name)){
          if(StringUtils.equals(type, "asc")){
            orders.add(builder.asc(path));
          }else{
            orders.add(builder.desc(path));
          }
        }
      }

    }else{
      if(useSortPriority){
        orders.add(builder.asc(root.get("priority")));
      }else{
        idFieldName = StringUtils.defaultIfBlank(idFieldName, "id");
        orders.add(builder.desc(root.get(idFieldName)));
      }
    }

    if(CollectionUtils.isNotEmpty(orders)){
      criteria.orderBy(orders);
    }

    return criteria;
  }

  public static Collection<SortField> getSortFieldFromPaging(Paging paging) {
    return (paging.getSearchCondition() != null && paging.getSearchCondition().getSortFields() != null) ? paging.getSearchCondition().getSortFields().values() : null;
  }

  /**
   * 쿼리에 페이징 추가
   * @param query
   * @param paging
   * @return
   */
  public static Query addPaging(Query query, Paging paging){
    if(paging != null && paging.getPageSize() > 0) {
      query.setFirstResult((paging.getPage() - 1) * paging.getPageSize());
      query.setMaxResults(paging.getPageSize());
    }
    return query;
  }


  public static Path getPath(From root, String fullPropertyName) {
    Path path;

    if(fullPropertyName.contains(".")){
      path = root;
      while(true){
        String field;
        if(!fullPropertyName.contains(".")){
          field = fullPropertyName;
        }else{
          field = StringUtils.substringBefore(fullPropertyName, ".");
        }
        path = path.get(field);
        if(fullPropertyName.contains(".")){
          fullPropertyName = StringUtils.substringAfter(fullPropertyName, ".");
        }else{
          break;
        }
      }
    }else{
      path = root.get(fullPropertyName);
    }
    return path;
  }


}
