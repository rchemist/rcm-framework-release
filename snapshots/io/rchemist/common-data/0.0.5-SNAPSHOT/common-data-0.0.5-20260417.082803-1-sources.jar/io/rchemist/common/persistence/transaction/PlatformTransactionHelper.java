/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.transaction;

import io.rchemist.common.configuration.ApplicationContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class PlatformTransactionHelper {

  public static final String DEFAULT_TRANSACTION_MANAGER = "transactionManager";

  public static PlatformTransactionManager getDefaultTransactionManager(){
    return (PlatformTransactionManager) ApplicationContextHolder.getApplicationContext().getBean(DEFAULT_TRANSACTION_MANAGER);
  }

  public static PlatformTransactionManager getTransactionManager(String transactionManagerName) {
    return getTransactionManager(transactionManagerName, false);
  }

  public static PlatformTransactionManager getTransactionManager(String transactionManagerName, boolean nullable) {
    PlatformTransactionManager transactionManager = (PlatformTransactionManager) ApplicationContextHolder.getApplicationContext().getBean(transactionManagerName);

    if (transactionManager == null && !nullable) {
      transactionManager = getDefaultTransactionManager();
    }
    return transactionManager;
  }

  public static TransactionStatus createTransaction(String name, int propagationBehavior){
    return createTransaction(name, propagationBehavior, DEFAULT_TRANSACTION_MANAGER);
  }

  public static TransactionStatus createTransaction(String name, int propagationBehavior, String transactionManagerName){
    PlatformTransactionManager transactionManager = getTransactionManager(transactionManagerName);
    return createTransaction(name, propagationBehavior, transactionManager);
  }

  public static TransactionStatus createTransaction(String name, int propagationBehavior, PlatformTransactionManager transactionManager) {
    return createTransaction(name, propagationBehavior, transactionManager, false);
  }

  public static TransactionStatus createTransaction(String name, int propagationBehavior, PlatformTransactionManager transactionManager, boolean isReadOnly) {
    return createTransaction(name, propagationBehavior, TransactionDefinition.ISOLATION_DEFAULT, transactionManager, isReadOnly);
  }

  public static TransactionStatus createTransaction(String name, int propagationBehavior, int isolationLevel, PlatformTransactionManager transactionManager, boolean isReadOnly) {
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setName(name);
    def.setReadOnly(isReadOnly);
    def.setPropagationBehavior(propagationBehavior);
    def.setIsolationLevel(isolationLevel);
    return transactionManager.getTransaction(def);
  }

  public static TransactionStatus createTransaction(int propagationBehavior, PlatformTransactionManager transactionManager, boolean isReadOnly) {
    return createTransaction(propagationBehavior, TransactionDefinition.ISOLATION_DEFAULT, transactionManager, isReadOnly);
  }

  public static TransactionStatus createTransaction(int propagationBehavior, int isolationLevel, PlatformTransactionManager transactionManager, boolean isReadOnly) {
    DefaultTransactionDefinition def = new DefaultTransactionDefinition();
    def.setReadOnly(isReadOnly);
    def.setPropagationBehavior(propagationBehavior);
    def.setIsolationLevel(isolationLevel);
    return transactionManager.getTransaction(def);
  }

  public static void finalizeTransaction(TransactionStatus status, boolean isError) {
    PlatformTransactionManager transactionManager = getDefaultTransactionManager();
    finalizeTransaction(status, transactionManager, isError);
  }


  public static void finalizeTransaction(TransactionStatus status, String transactionManagerName, boolean isError) {
    PlatformTransactionManager transactionManager = getTransactionManager(transactionManagerName);

    finalizeTransaction(status, transactionManager, isError);
  }

  public static void finalizeTransaction(TransactionStatus status, PlatformTransactionManager transactionManager, boolean isError) {
    boolean isActive = false;
    try {
      if (!status.isRollbackOnly()) {
        isActive = true;
      }
    } catch (Exception e) {
      //do nothing
    }
    if (isError || !isActive) {
      try {
        transactionManager.rollback(status);
      } catch (Exception e) {
        log.error("Rolling back caused exception. Logging and continuing.", e);
      }
    } else {
      transactionManager.commit(status);
    }
  }


}
