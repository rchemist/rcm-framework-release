/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.configuration.platform.DataProviderConfig;
import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.config.persistence.EntityBeanContext;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.search.data.query.ExistsFilterItem;
import io.rchemist.common.search.service.exception.SearchServiceErrorType;
import io.rchemist.common.search.service.exception.SearchServiceException;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.util.GsonUtil;
import io.rchemist.common.util.MapUtil;
import io.rchemist.common.web.request.data.search.ModifiedResult;
import io.rchemist.common.web.request.data.search.ModifyFilterRequest;
import io.rchemist.common.web.request.data.search.ModifySortRequest;
import io.rchemist.common.web.request.data.search.PreservedFilterAndSortCriteria;
import io.rchemist.common.web.request.data.search.SearchFieldModifier;
import io.rchemist.common.web.request.data.search.SortFieldModifier;
import io.rchemist.common.web.request.data.search.ValidateSearchForm;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.service.type.EntityViewType;
import jakarta.persistence.OneToMany;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public abstract class AbstractSearchForm<T> extends PagingCriteria<T> implements
    FilterMapSearchForm<T>{

  protected LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = new LinkedHashMap<>();

  @JsonIgnore
  @Getter(AccessLevel.PRIVATE)
  @Setter(AccessLevel.PRIVATE)
  protected PreservedFilterAndSortCriteria preservedFilterAndSortCriteria;

  @JsonIgnore
  private boolean filterValidated = false;

  // Search 시 Cache 정보를 사용할지 여부, True 일 경우 Cache 를 사용하지 않으며, DB 에서 조회한다.
  protected Integer cacheTTL = 60 * 60;

  protected String searchTerm;

  // Front 에서 의도적으로 빈 검색 결과를 리턴 받고 싶을 때, SearchForm 을 리턴할 때는 이 값을 제거해야 한다.
  protected Boolean shouldReturnEmpty;

  // 쿼리 결과에 DISTINCT 를 적용할지 여부. OneToMany join 등으로 인한 중복 결과를 제거할 때 사용한다.
  @JsonIgnore
  protected boolean distinct = false;

  @JsonIgnore
  protected Set<String> mergedSearchTerms = new HashSet<>();

  protected ConditionOperatorType operator = ConditionOperatorType.AND;

  @RestDataField(name = "Equal 비교 여부", description = "Equal 비교 여부", example = "true")
  protected Boolean exactMatch;   // 회원가입 중복확인용으로 사용할 때 이 값을 true 로 해야 한다. 안 그러면 startwith 검색을 하기 때문이다.

  @RestDataField(name = "강제 DB 조회 여부", description = "강제 DB 조회 여부. 이 값이 true 인 경우 Hibernate Search 설정과 관계 없이 무조건 DB 에서 데이터를 조회한다.", example = "false")
  protected Boolean forceFetchFromDB = false;

  @RestDataField(name = "모든 필드의 정보 조회", description = "목록을 리턴할 때 VIEW 의 isDetail 을 true 로 전달")
  protected Boolean viewDetail = false;

  protected EntityViewType entityViewType;

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 columnFilters (@Column, @Embedded 로 정의된 필드)정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> columnFilters = new LinkedHashMap<>();

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 mappedJoinFilters (@OneToMany 로 정의된 필드, FilterItem 에 JoinAlias, JoinClass 정보가 추가로 저장됨) 정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> mappedJoinFilters = new LinkedHashMap<>();

  // searchForm 생성 후 validate 시 filter 에 입력된 정보를 바탕으로 unmappedJoinFilters 정보를 분리하여 저장
  @JsonIgnore
  private LinkedHashMap<ConditionOperatorType, FilterItem[]> unmappedJoinFilters = new LinkedHashMap<>();

  // EXISTS 서브쿼리 필터 조건. filterExists() / filterNotExists() 로 추가된다.
  @JsonIgnore
  protected List<ExistsFilterItem> existsFilters = new ArrayList<>();

  // ResponseEntityListService#overrideSearchForm 에서 추가할 수 있다.
  // SearchForm 별로 validateFilters 를 확장하기 위해 사용한다.
  @JsonIgnore
  protected List<SearchFieldModifier> searchFieldModifiers = new ArrayList<>();

  // ResponseEntityListService#overrideSearchForm 에서 추가할 수 있다.
  // SearchForm 별로 validateSorts 를 확장하기 위해 사용한다.
  @JsonIgnore
  protected List<SortFieldModifier> sortFieldModifiers = new ArrayList<>();

  @Override
  public ConditionOperatorType getOperator() {
    return operator;
  }

  @JsonIgnore
  protected Map<String, Object> additionalContext;

  @Override
  public EntityViewType getEntityViewType() {
    if (this.entityViewType != null) {
      return this.entityViewType;
    }
    if (BooleanUtils.toBoolean(this.viewDetail)) {
      return EntityViewType.VIEW;
    }
    return EntityViewType.LIST;
  }

  @Override
  public Object getValue(String propertyName) {

    if (filters != null && !filters.isEmpty()) {
      for (ConditionOperatorType operator : filters.keySet()) {
        FilterItem[] filterItems = filters.get(operator);
        for (FilterItem filterItem : filterItems) {
          if (filterItem.getName() != null) {
            if (filterItem.getName().equals(propertyName)) {
              return filterItem.getValue();
            }
          }
        }
      }
    }

    return null;
  }

  @Override
  public Object getValue(ConditionOperatorType operatorType, QueryConditionType conditionType, String propertyName) {

    if (filters != null && !filters.isEmpty()) {
      for (ConditionOperatorType operator : filters.keySet()) {
        if (operator.equals(operatorType)) {
          FilterItem[] filterItems = filters.get(operator);
          for (FilterItem filterItem : filterItems) {
            if (StringUtils.equalsIgnoreCase(filterItem.getName(), propertyName)) {
              if (filterItem.getQueryConditionType().equals(conditionType)) {
                return filterItem.getValue();
              }
            }
          }
        }
      }
    }

    return null;
  }

  @Override
  public String getSafeSearchValue(String propertyName) {
    Object value = getValue(propertyName);
    return value == null ? null : String.valueOf(value);
  }

  public boolean isDistinct() {
    return distinct;
  }

  public void setDistinct(boolean distinct) {
    this.distinct = distinct;
  }

  @Override
  public boolean isExactMatch() {
    return BooleanUtils.toBoolean(exactMatch);
  }

  @Override
  public Long[] getSearchIds() {

    Object values = getValue("ids");

    if (values != null) {
      try {
        // 배열인지 아닌지 확인
        if (values.getClass().isArray()) {
          return (Long[]) values;
        } else {
          // Collection 인지 확인
          if (values instanceof List) {
            return ((List<Long>) values).toArray(new Long[0]);
          }
        }
      }catch (Exception e) {
        return null;
      }
    }

    return null;
  }

  public String[] getSearchFieldNames(Class<?> entityClass) {

    Set<String> fieldNames = new LinkedHashSet<>();

    // ClassTransformer 로 만들어진 Entity Bean 을 가져온다.
    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());

    // Entity Bean 의 Property 정보를 가져온다.
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType operatorType : filters.keySet()) {

      FilterItem[] filterItems = filters.get(operatorType);

      for (FilterItem filterItem : filterItems) {
        // Entity Bean 의 Property 정보를 가져온다.
        RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(
            filterItem.getName());

        if (entityBeanProperty != null) {
          fieldNames.add(entityBeanProperty.getName());
        } else {
          if (StringUtils.contains(filterItem.getName(), ".")) {
            // json field 일 수 있다.
            String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");
            if (entityBean.isAttributeField(attributePrefix) || entityBeanProperties.containsKey(attributePrefix)
                || hasPropertyWithPrefix(entityBeanProperties, attributePrefix)) {
              fieldNames.add(filterItem.getName());
            }
          }
        }

      }
    }

    if (CollectionUtils.isNotEmpty(mergedSearchTerms)) {
      for (String mergedSearchTerm : mergedSearchTerms) {
        if (fieldNames.contains(mergedSearchTerm)) {
          fieldNames.add(mergedSearchTerm);
        }
      }
    }


    return fieldNames.toArray(new String[0]);

  }

  public String[] getHibernateSearchFieldNames(Class<?> entityClass) {

    List<String> fieldNames = new ArrayList<>();

    // ClassTransformer 로 만들어진 Entity Bean 을 가져온다.
    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());

    // Entity Bean 의 Property 정보를 가져온다.
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType operatorType : filters.keySet()) {

      FilterItem[] filterItems = filters.get(operatorType);

      for (FilterItem filterItem : filterItems) {
        // Entity Bean 의 Property 정보를 가져온다.
        RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(
            filterItem.getName());

        if (entityBeanProperty != null && entityBeanProperty.isIndexField()) {
          fieldNames.add(entityBeanProperty.getName());
        } else {

          if (StringUtils.contains(filterItem.getName(), ".")) {
            String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");
            if (entityBean.isAttributeField(attributePrefix) || entityBeanProperties.containsKey(attributePrefix)) {
              fieldNames.add(filterItem.getName());
            }
          }

        }

      }
    }

    return fieldNames.toArray(new String[0]);

  }

  public void validateFilters(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException {
    if(entityClass == null) {
      throw new SearchServiceException(SearchServiceErrorType.ENTITY_NOT_FOUND);
    }

    if(MapUtils.isEmpty(this.filters)) {
      return;
    }

    // filter
    if (!this.filterValidated) {
      LinkedHashMap<ConditionOperatorType, FilterItem[]> validatedFilters = new LinkedHashMap<>();
      filters.keySet().forEach(operatorType -> {
        FilterItem[] filterItems = filters.get(operatorType);
        if (filterItems != null && !(filterItems.length == 1 && filterItems[0] == null)) {
          validatedFilters.put(operatorType, filterItems);
        }
      });
      this.filters = validatedFilters;
      this.filterValidated = true;
    }


    // ClassTransformer 로 만들어진 Entity Bean 을 가져온다.
    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());
    // Entity Bean 의 Property 정보를 가져온다.
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    for (ConditionOperatorType key : filters.keySet()) {
      FilterItem[] filterItems = filters.get(key);

      List<FilterItem> mergedFilterItems = new ArrayList<>();

      if(ArrayUtils.isNotEmpty(filterItems)) {

        for (FilterItem filterItem : filterItems) {
          // Entity Bean 의 Property 정보를 가져온다.
          RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(filterItem.getName());

          if (entityBeanProperty == null) {
            filterItem = ValidateSearchForm.transform(new ModifyFilterRequest(entityBean, filterItem, hibernateSearch).withSearchFieldModifiers(this.searchFieldModifiers));
          }

          // try again
          entityBeanProperty = entityBeanProperties.get(filterItem.getName());

          if(entityBeanProperty == null) {
            if (entityBean.hasAttributeFields() && StringUtils.contains(filterItem.getName(), ".")) {
              String attributePrefix = StringUtils.substringBefore(filterItem.getName(), ".");

              if (entityBeanProperties.containsKey(attributePrefix)
                  || hasPropertyWithPrefix(entityBeanProperties, attributePrefix)) {
                // JPA relationship traversal path (e.g. student.majors.majorCurriculum.major.id)
                mergedFilterItems.add(filterItem);
              } else if (hibernateSearch) {

                if (entityBean.isAttributeField(attributePrefix)) {
                  mergedFilterItems.add(filterItem);
                } else {
                  log.warn("Entity Bean Property Not Found : {}", filterItem.getName());
                  // throw new AdvancedSearchServiceException(filterItem.getName(), AdvancedSearchServiceErrorType.FIELD_NOT_FOUND);
                }
              } else {
                // JSON field 인 경우일 수 있다.

                if (entityBean.isAttributeFieldName(attributePrefix)) {
                  filterItem.setJsonFilter(true);
                  mergedFilterItems.add(filterItem);
                } else {
                  log.warn("Entity Bean Property Not Found : {}", filterItem.getName());
                  // throw new AdvancedSearchServiceException(filterItem.getName(), AdvancedSearchServiceErrorType.FIELD_NOT_FOUND);
                }

              }
            } else {
              // 기타 oneToMany 일 수 있다. 일단 내버려 두자.
              mergedFilterItems.add(filterItem);
            }

          } else {
            // filterItem 필드 타입을 설정한다.

            mergeFilter(entityClass, hibernateSearch, entityBean, entityBeanProperties, key,
                mergedFilterItems,
                filterItem, entityBeanProperty);

          }
        }

        // TODO jsonField 인 경우 attributes.name, value 형태로 된 걸 합쳐서 처리해야 한다.

        filters.put(key, mergedFilterItems.toArray(new FilterItem[0]));
      }
    }
  }

  private void mergeFilter(Class<?> entityClass, boolean hibernateSearch,
      EntityBean<?> entityBean,
      Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties, ConditionOperatorType key,
      List<FilterItem> filterItemList, FilterItem filterItem,
      RegisterEntityBeanPropertyDTO entityBeanProperty) {
    filterItem.withFieldType(entityBeanProperty.getPropertyClass()).withRootEntityClass(entityClass);

    filterItem = ValidateSearchForm.validate(new ModifyFilterRequest(entityBean, filterItem,
        hibernateSearch).withEntityBeanProperty(entityBeanProperty));

    if (filterItem != null) {

      filterItemList.add(filterItem);

      if (StringUtils.equals(entityBeanProperty.getPropertyType(), OneToMany.class.getName())) {
        FilterMapSearchForm.mergeFilter(key, filterItem, mappedJoinFilters);
      } else {
        if (StringUtils.contains(filterItem.getName(), ".")) {
          String[] names = StringUtils.split(filterItem.getName(), ".");
          String name = names[0];
          RegisterEntityBeanPropertyDTO property = entityBeanProperties.get(name);

          if (property == null) {
            // embedded 필드라는 뜻
            FilterMapSearchForm.mergeFilter(key, filterItem, columnFilters);
          } else {
            if (StringUtils.equals(property.getPropertyType(), OneToMany.class.getName())) {
              FilterMapSearchForm.mergeFilter(key, filterItem, mappedJoinFilters);
            } else {
              FilterMapSearchForm.mergeFilter(key, filterItem, columnFilters);
            }
          }

        } else {
          FilterMapSearchForm.mergeFilter(key, filterItem, columnFilters);
        }
      }
    }
  }

  @Override
  public boolean createPreservedFilterAndSortCriteria() {
    if (this.preservedFilterAndSortCriteria == null) {
      this.preservedFilterAndSortCriteria = new PreservedFilterAndSortCriteria().withFilters(filters).withSorts(sorts);
      return true;
    }
    return false;
  }

  private void removeFilter(ConditionOperatorType operatorType, FilterItem filterItem) {
    if(filters.containsKey(operatorType)) {
      FilterItem[] items = filters.get(operatorType);
      List<FilterItem> itemList = new ArrayList<>();
      for(FilterItem item : items) {
        if(!item.equals(filterItem)) {
          itemList.add(item);
        }
      }
      filters.put(operatorType, itemList.toArray(new FilterItem[0]));
    }
  }

  public void validateSorts(Class<?> entityClass, boolean hibernateSearch) throws SearchServiceException {
    if(entityClass == null) {
      throw new SearchServiceException(SearchServiceErrorType.ENTITY_NOT_FOUND);
    }

    if(CollectionUtils.isEmpty(this.sorts)) {
      return;
    }

    // ClassTransformer 로 만들어진 Entity Bean 을 가져온다.
    EntityBean<?> entityBean = EntityBeanContext.getRegisterEntityBean(entityClass.getName());

    ModifiedResult modifiedResult = ValidateSearchForm.validateSorts(new ModifySortRequest(entityBean, this.filters, this.sorts, hibernateSearch).withSortFieldModifiers(this.sortFieldModifiers));

    if (modifiedResult.hasFilters()) {
      this.filters = modifiedResult.getFilters();
    }

    if (modifiedResult.hasSorts()) {
      this.sorts = modifiedResult.getSortEntries();
    }

    // Entity Bean 의 Property 정보를 가져온다.
    Map<String, RegisterEntityBeanPropertyDTO> entityBeanProperties = entityBean.getClassMappingProperties();

    // 정렬 필드 검증
    for(SortEntry entry : this.sorts) {
      String sortKey = entry.getFieldName();
      RegisterEntityBeanPropertyDTO entityBeanProperty = entityBeanProperties.get(sortKey);

      if(entityBeanProperty == null) {
        throw new SearchServiceException(sortKey, SearchServiceErrorType.FIELD_NOT_FOUND);
      }
    }
  }

  @Override
  public void revertPreservedFilterAndSortCriteria() {
    if(this.preservedFilterAndSortCriteria != null) {
      this.filters = this.preservedFilterAndSortCriteria.getFilters();
      this.sorts = this.preservedFilterAndSortCriteria.getSorts();
      this.clearPreservedFilterAndSortCriteria();
    }
  }

  @Override
  public T setFilterIfAbsent(ConditionOperatorType operatorType, FilterItem... filterItems) {
    if(MapUtils.isEmpty(this.filters)) {
      this.filters = new LinkedHashMap<>();
    }

    this.filters = addFilters(operatorType, filterItems);

    return (T) this;
  }

  @Override
  public void preparePreservedFilterAndSortCriteria(Class<?> entityClass, boolean hibernateSearch) {
    if(this.preservedFilterAndSortCriteria == null) {
      createPreservedFilterAndSortCriteria();
    }
    try {
      validateFilters(entityClass, hibernateSearch);
      validateSorts(entityClass, hibernateSearch);
    }catch (Exception e) {
      // nothing to do
      e.printStackTrace();
    }
  }


  @Override
  public String getCacheKey() {
    String cacheKey = "SearchForm{" +
        "filters=" + MapUtil.toString(filters) +
        ", searchTerm='" + searchTerm + '\'' +
        ", shouldReturnEmpty=" + shouldReturnEmpty +
        ", operator=" + operator +
        ", exactMatch=" + exactMatch +
        ", viewDetail=" + viewDetail +
        ", page=" + page +
        ", pageSize=" + pageSize +
        ", sorts=" + GsonUtil.toJson(sorts) +
        ", ignoreCache=" + ignoreCache +
        '}';
    return String.valueOf(Objects.hash(cacheKey));
  }

  @Override
  public boolean isShouldReturnEmpty() {
    return BooleanUtils.toBoolean(this.shouldReturnEmpty);
  }


  @Override
  public void removeFilterItem(ConditionOperatorType type, String name) {
    FilterItem[] items = getFilterItems(type);
    if(items != null) {
      for(FilterItem item : items) {
        if(item.getName().equals(name)) {
          List<FilterItem> itemList = new ArrayList<>();
          for(FilterItem filterItem : items) {
            if(!filterItem.getName().equals(name)) {
              itemList.add(filterItem);
            }
          }
          filters.put(type, itemList.toArray(new FilterItem[0]));
          break;
        }
      }
    }
  }

  public T withForceFetchFromDB(Boolean forceFetchFromDB) {
    this.forceFetchFromDB = forceFetchFromDB;
    return (T) this;
  }

  public boolean isForceFetchFromDB() {
    return BooleanUtils.toBoolean(forceFetchFromDB);
  }

  public T deepCopy(AbstractSearchForm<T> newSearchForm, boolean removeRequestOnlyValue) {
    if (this.preservedFilterAndSortCriteria != null) {
      newSearchForm.preservedFilterAndSortCriteria = this.preservedFilterAndSortCriteria.deepCopy();
    }

    newSearchForm.page = this.page;
    newSearchForm.pageSize = this.pageSize;
    newSearchForm.totalCount = this.totalCount;
    newSearchForm.totalPage = this.totalPage;
    newSearchForm.sorts = new ArrayList<>(this.sorts);
    newSearchForm.ignoreCache = this.ignoreCache;

    if (MapUtils.isNotEmpty(this.filters)) {
      newSearchForm.filters = new LinkedHashMap<>();
      for (Entry<ConditionOperatorType, FilterItem[]> entry : this.filters.entrySet()) {
        if (entry.getValue() != null) {

          if (entry.getValue().length == 1 &&  entry.getValue()[0] == null)
            continue;


          FilterItem[] filterItems = entry.getValue();
          FilterItem[] filterItemsClone = new FilterItem[filterItems.length];
          for (int i = 0; i < filterItems.length; i++) {
            filterItemsClone[i] = filterItems[i].deepCopy();
          }
          newSearchForm.filters.put(entry.getKey(), filterItemsClone);
        }
      }
    }

    newSearchForm.filterValidated = this.filterValidated;
    newSearchForm.cacheTTL = this.cacheTTL;
    newSearchForm.searchTerm = this.searchTerm;
    newSearchForm.mergedSearchTerms = new HashSet<>(this.mergedSearchTerms);
    newSearchForm.operator = this.operator;
    newSearchForm.exactMatch = this.exactMatch;
    newSearchForm.forceFetchFromDB = this.forceFetchFromDB;

    // Front 에 리턴할 때는 이 값을 제거해야 한다.
    if (!removeRequestOnlyValue) {
      newSearchForm.shouldReturnEmpty = this.shouldReturnEmpty;
    }

    return (T) newSearchForm;
  }


  public LinkedHashMap<ConditionOperatorType, FilterItem[]> getSubConditions(
      ConditionOperatorType conditionOperatorType, String propertyName) {
    if (filters != null && filters.size() > 0 && filters.containsKey(conditionOperatorType)) {
      FilterItem[] filterItems = filters.get(conditionOperatorType);
      for (FilterItem filterItem : filterItems) {
        if (filterItem.getName() != null && filterItem.getName().equals(propertyName)) {
          if (filterItem.hasSubFilters()) {
            return filterItem.getSubFilters();
          }
        }
      }
    }
    return null;
  }

  private void clearPreservedFilterAndSortCriteria() {
    this.preservedFilterAndSortCriteria = null;
  }

  public T withSearchFieldModifiers(
      List<SearchFieldModifier> searchFieldModifiers) {
    this.searchFieldModifiers = searchFieldModifiers;
    return (T) this;
  }

  public T withSortFieldModifiers(
      List<SortFieldModifier> sortFieldModifiers) {
    this.sortFieldModifiers = sortFieldModifiers;
    return (T) this;
  }

  public T addSearchFieldModifiers(SearchFieldModifier... modifiers) {
    if (modifiers == null || modifiers.length == 0) {
      return (T) this;
    }
    this.searchFieldModifiers.addAll(Arrays.asList(modifiers));
    return (T) this;
  }

  public T addSortFieldModifiers(SortFieldModifier... modifiers) {
    if (modifiers == null || modifiers.length == 0) {
      return (T) this;
    }
    this.sortFieldModifiers.addAll(Arrays.asList(modifiers));
    return (T) this;
  }

  public T withViewDetail(Boolean viewDetail) {
    this.viewDetail = viewDetail;
    return (T) this;
  }

  // 검색 필터가 존재하는지 여부
  public boolean hasFilters() {
    if (MapUtils.isEmpty(filters)) {
      return false;
    }
    for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
      if (entry.getValue() != null && entry.getValue().length > 0) {
        return true;
      }
    }
    return true;
  }

  public boolean isViewDetail() {
    return BooleanUtils.toBoolean(viewDetail);
  }

  public boolean shouldUseHibernateSearch() {
    return (DataProviderConfig.useHibernateSearch() && !isForceFetchFromDB() && !isShouldReturnEmpty());
  }

  /**
   * 지정된 필터를 제거한다.
   * @param operatorType
   * @param names
   */
  public void removeFilters(ConditionOperatorType operatorType, String... names) {
    if (names == null || names.length == 0) {
      return;
    }
    if (!filters.containsKey(operatorType) || ArrayUtils.isEmpty(filters.get(operatorType))) {
      return;
    }
    List<FilterItem> newFilterItems = new ArrayList<>();
    for (FilterItem filterItem : filters.get(operatorType)) {
      if (!ArrayUtils.contains(names, filterItem.getName())) {
        newFilterItems.add(filterItem);
      }
    }
    filters.put(operatorType, newFilterItems.toArray(new FilterItem[0]));
  }

  /**
   * 지정된 필터를 제외한 나머지를 제거한다.
   * @param operatorType
   * @param names
   */
  public void removeFiltersExcludeNames(ConditionOperatorType operatorType, String... names) {
    if (names == null || names.length == 0) {
      return;
    }
    if (!filters.containsKey(operatorType) || ArrayUtils.isEmpty(filters.get(operatorType))) {
      return;
    }
    List<FilterItem> newFilterItems = new ArrayList<>();
    for (FilterItem filterItem : filters.get(operatorType)) {
      if (ArrayUtils.contains(names, filterItem.getName())) {
        newFilterItems.add(filterItem);
      }
    }
    filters.put(operatorType, newFilterItems.toArray(new FilterItem[0]));
  }

  public void removeFilter(String fieldName) {
    if (MapUtils.isNotEmpty(this.filters)) {

      for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
        FilterItem[] items = entry.getValue();
        List<FilterItem> itemList = new ArrayList<>();
        for (FilterItem item : items) {
          if (!item.getName().equals(fieldName)) {
            itemList.add(item);
          }
        }
        filters.put(entry.getKey(), itemList.toArray(new FilterItem[0]));
      }

    }

  }

  public boolean hasFilter(String fieldName) {
    LinkedHashMap<ConditionOperatorType, FilterItem[]> filters = getFilters();

    if (MapUtils.isNotEmpty(filters)) {

      for (Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
        FilterItem[] items = entry.getValue();
        for (FilterItem item : items) {
          if (item.getName().equals(fieldName)) {
            return true;
          }
        }
      }

    }

    return false;
  }

  @Override
  public String toString() {
    return "SearchForm{" +
        "filters=" + MapUtil.toString(filters) +
        ", preservedFilterAndSortCriteria=" + preservedFilterAndSortCriteria +
        ", filterValidated=" + filterValidated +
        ", cacheTTL=" + cacheTTL +
        ", searchTerm='" + searchTerm + '\'' +
        ", shouldReturnEmpty=" + shouldReturnEmpty +
        ", mergedSearchTerms=" + mergedSearchTerms +
        ", operator=" + operator +
        ", exactMatch=" + exactMatch +
        ", forceFetchFromDB=" + forceFetchFromDB +
        ", viewDetail=" + viewDetail +
        ", page=" + page +
        ", pageSize=" + pageSize +
        ", totalCount=" + totalCount +
        ", sorts=" + GsonUtil.toJson(sorts) +
        ", totalPage=" + totalPage +
        ", ignoreCache=" + ignoreCache +
        '}';
  }

  public void renameFilterItem(String oldName, String newName) {
    renameFilterItem(filters, oldName, newName);
  }

  protected void renameFilterItem(LinkedHashMap<ConditionOperatorType, FilterItem[]> filters, String oldName, String newName) {
    if (MapUtils.isEmpty(filters)) {
      return;
    }
    for(Entry<ConditionOperatorType, FilterItem[]> entry : filters.entrySet()) {
      for(FilterItem item : entry.getValue()) {
        if(item.getName().equals(oldName)) {
          item.setName(newName);
        }
        renameFilterItem(item.getSubFilters(), oldName, newName);
      }
    }
  }

  public void renameSortItem(String oldName, String newName) {
    if (CollectionUtils.isEmpty(sorts)) {
      return;
    }
    for (SortEntry entry : sorts) {
      if (entry.getFieldName().equals(oldName)) {
        entry.setFieldName(newName);
      }
    }
  }

  /**
   * Check if any property key in the map starts with the given prefix followed by ".".
   * This handles cases where a @ManyToOne field (e.g. "student") is not registered as a direct key,
   * but its expanded sub-properties (e.g. "student.name", "student.id") exist in the map.
   */
  private static boolean hasPropertyWithPrefix(Map<String, RegisterEntityBeanPropertyDTO> properties, String prefix) {
    String prefixWithDot = prefix + ".";
    for (String key : properties.keySet()) {
      if (key.startsWith(prefixWithDot)) {
        return true;
      }
    }
    return false;
  }

}
