/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

/**
 * <p>
 * Project : Rchemist Commerce Platform Created by hongin
 **/
public class AttributeDataExample {

  public static final String ATTRIBUTE_SEARCH_FORM = ""
      + "{\n"
      + "  \"customerId\": \"fake_data\",\n"
      + "  \"firstName\": \"fake_data\",\n"
      + "  \"lastName\": \"fake_data\",\n"
      + "  \"fullName\": \"fake_data\",\n"
      + "  \"loginName\": \"fake_data\",\n"
      + "  \"emailAddress\": \"fake_data\",\n"
      + "  \"phoneNumber\": \"fake_data\",\n"
      + "  \"searchTerm\": \"fake_data\",\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"siteAlias\": \"fake_data\",\n"
      + "  \"externalId\": \"fake_data\",\n"
      + "  \"alias\": \"fake_data\",\n"
      + "  \"createdBy\": \"fake_data\",\n"
      + "  \"name\": \"fake_data\",\n"
      + "  \"description\": \"fake_data\",\n"
      + "  \"tags\": [\n"
      + "    \"fake_data\"\n"
      + "  ],\n"
      + "  \"url\": \"fake_data\",\n"
      + "  \"createdAt\": \"2013-06-24 05:44:48\",\n"
      + "  \"createdAtUntil\": \"2017-11-26 11:46:25\",\n"
      + "  \"updatedAt\": \"2018-04-11 17:21:02\",\n"
      + "  \"updatedAtUntil\": \"2032-03-01 04:22:46\",\n"
      + "  \"exactMatch\": true,\n"
      + "  \"active\": true,\n"
      + "  \"restrictId\": \"fake_data\",\n"
      + "  \"customFieldProperty\": \"fake_data\",\n"
      + "  \"customFieldParentId\": \"fake_data\",\n"
      + "  \"defaultSortProperty\": \"fake_data\",\n"
      + "  \"customFieldSearch\": {},\n"
      + "  \"page\": 83,\n"
      + "  \"pageSize\": 94,\n"
      + "  \"totalCount\": 69,\n"
      + "  \"sort\": [\n"
      + "    \"fake_data\"\n"
      + "  ]\n"
      + "}"
      + "";

  public static final String ATTRIBUTE_CREATE_FORM = ""
      + "{\n"
      + "  \"id\": \"fake_data\",\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"phoneNumber\": \"fake_data\",\n"
      + "  \"profile\": {\n"
      + "    \"assetKey\": \"fake_data\",\n"
      + "    \"fileSize\": 25,\n"
      + "    \"assetUrl\": \"fake_data\"\n"
      + "  },\n"
      + "  \"active\": false,\n"
      + "  \"attributes\": {}\n"
      + "}";

  public static final String ATTRIBUTE_UPDATE_FORM = ""
      + "{\n"
      + "  \"id\": \"fake_data\",\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"phoneNumber\": \"fake_data\",\n"
      + "  \"profile\": {\n"
      + "    \"assetKey\": \"fake_data\",\n"
      + "    \"fileSize\": 25,\n"
      + "    \"assetUrl\": \"fake_data\"\n"
      + "  },\n"
      + "  \"active\": false,\n"
      + "  \"attributes\": {}\n"
      + "}";

  public static final String ATTRIBUTE_DELETE_FORM = ""
      + "{\n"
      + "  \"id\": \"fake_data\",\n"
      + "  \"tenantAlias\": \"fake_data\",\n"
      + "  \"phoneNumber\": \"fake_data\",\n"
      + "  \"profile\": {\n"
      + "    \"assetKey\": \"fake_data\",\n"
      + "    \"fileSize\": 25,\n"
      + "    \"assetUrl\": \"fake_data\"\n"
      + "  },\n"
      + "  \"active\": false,\n"
      + "  \"attributes\": {}\n"
      + "}";

  public static final String ATTRIBUTE_DTO_MAP = ""
      + "{\n"
      + "  \"attributes\": {\n"
      + "    \"key\": {\n"
      + "       \"id\": \"fake_data\",\n"
      + "       \"name\": \"fake_data\",\n"
      + "       \"value\": \"fake_data\",\n"
      + "       \"customerField\": \"fake_data\",\n"
      + "       \"createdAt\": false,\n"
      + "       \"updatedAt\": {}\n"
      + "      },\n"
      + "    \"key\": {\n"
      + "       \"id\": \"fake_data\",\n"
      + "       \"name\": \"fake_data\",\n"
      + "       \"value\": \"fake_data\",\n"
      + "       \"customerField\": \"fake_data\",\n"
      + "       \"createdAt\": false,\n"
      + "       \"updatedAt\": {}\n"
      + "      },\n"
      + "    }\n"
      + "}";
}
