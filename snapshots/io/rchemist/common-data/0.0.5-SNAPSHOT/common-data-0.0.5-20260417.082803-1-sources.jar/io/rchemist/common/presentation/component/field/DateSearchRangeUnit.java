/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.component.field;

import io.rchemist.common.presentation.type.DateSearchPreset;
import io.rchemist.common.presentation.type.DateSearchUnitType;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter(AccessLevel.PRIVATE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateSearchRangeUnit implements Serializable{

  private static final String NAME_PREFIX = "DateSearchRangeUnit_";

  public DateSearchRangeUnit(DateSearchPreset preset){
    this(preset.getUnit().getType(), preset.getUnit().getValue(), preset.getUnit().getFriendlyName());
  }

  public DateSearchRangeUnit(DateSearchUnitType type, Integer value) {
    this.type = type;
    this.value = value;
    this.friendlyName = NAME_PREFIX + type.name() + "_" + value;
  }

  public DateSearchRangeUnit(DateSearchUnitType type, Integer value, String friendlyName) {
    this.type = type;
    this.value = value;
    this.friendlyName = friendlyName;
  }

  protected DateSearchUnitType type;

  protected Integer value;

  protected String friendlyName;

  public DateSearchRange getDateSearchRange(){

    LocalDate startDate = LocalDate.now();
    LocalDate endDate = LocalDate.now();

    switch (type){
      case DAY:{
        if(value == 1){
          startDate = LocalDate.now();
        }else if(value == -1) {
          // 어제
          startDate = startDate.minusDays(Long.valueOf(1));
          endDate = endDate.minusDays(Long.valueOf(1));
        }else{
          startDate = startDate.minusDays(Long.valueOf(value));
        }
        break;
      }
      case WEEK:{
        startDate = startDate.minusWeeks(Long.valueOf(value));
        break;
      }
      case MONTH:{
        startDate = startDate.minusMonths(Long.valueOf(value));
        break;
      }
    }

    return new DateSearchRange(startDate, endDate);
  }

  @Getter
  public static class DateSearchRange implements Serializable {

    public DateSearchRange(LocalDate startDate, LocalDate endDate) {
      this.startDate = startDate;
      this.endDate = endDate;
    }

    private LocalDate startDate;

    private LocalDate endDate;

  }



}
