/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.util.type.SiteType;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter(AccessLevel.PRIVATE)
public class AnonymousUser implements UserProfile {

  public static final String USER_ID = "ANONYMOUS_USER";
  public static final String USER_NAME = "Anonymous";

  public AnonymousUser() {
    this.loginName = USER_ID;
    this.name = USER_NAME;
    this.nickname = USER_NAME;
    this.id = USER_ID;
    this.siteType = SiteType.FRONT;
  }

  protected String loginName;

  protected String name;

  protected String nickname;

  protected String id;

  protected SiteType siteType;
  
}
