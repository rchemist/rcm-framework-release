/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import io.rchemist.common.util.LocalDateUtil;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasAvailableDate<T> extends ClassTransformTarget {

  default void setAvailableDate(String[] availalbleDate) {
    throw new ClassTransformException();
  }

  default String[] getAvailableDate() {
    throw new ClassTransformException();
  }

  default T withAvailableDate(String[] availableDate) {
    setAvailableDate(availableDate);
    return (T) this;
  }

  default T withAvailableDateAt(String availableDateAt){
    setAvailableDateAt(availableDateAt);
    return (T) this;
  }

  default T withAvailableDateUntil(String availableUntilDateAt){
    setAvailableDateUntil(availableUntilDateAt);
    return (T) this;
  }

  default void setAvailableDateAt(String availableDateAt){
    throw new ClassTransformException();
  }
  default void setAvailableDateUntil(String availableUntilDateAt){
    throw new ClassTransformException();
  }

  default String getAvailableDateAt(){
    throw new ClassTransformException();
  }

  default String getAvailableDateUntil(){
    throw new ClassTransformException();
  }


  @JsonIgnore
  default boolean isAvailableNow(){

    LocalDate availableAt;
    LocalDate availableUntil;
    if (getAvailableDate() != null) {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDate()[0]);
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDate()[1]);
    } else {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDateAt());
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDateUntil());
    }

    if (availableAt == null && availableUntil == null) {
      return true;
    } else if (availableAt == null) {
      return availableUntil.isAfter(LocalDate.now());
    } else if (availableUntil == null) {
      return availableAt.isBefore(LocalDate.now());
    }

    return false;

  }

  @JsonIgnore
  default boolean isStartedNow(){

    LocalDate availableAt;
    if (getAvailableDate() != null) {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDate()[0]);
    } else {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDateAt());
    }

    if (availableAt == null) {
      return true;
    }
    return availableAt.isBefore(LocalDate.now());
  }

  @JsonIgnore
  default boolean isEndedNow(){
    if (!isStartedNow()) {
      return false;
    }

    LocalDate availableUntil;
    if (getAvailableDate() != null) {
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDate()[1]);
    } else {
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDateUntil());
    }
    if (availableUntil == null) {
      return true;
    }
    return availableUntil.isAfter(LocalDate.now());
  }

  @JsonIgnore
  default boolean isAvailable(Instant compareDate) {
    // compareDate 시각이 AvailableDateAt 과 AvailableDateUntil 사이에 있는지 확인
    LocalDate availableAt;
    LocalDate availableUntil;

    if (getAvailableDate() != null) {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDate()[0]);
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDate()[1]);
    } else {
      availableAt = LocalDateUtil.getLocalDate(getAvailableDateAt());
      availableUntil = LocalDateUtil.getLocalDate(getAvailableDateUntil());
    }

    if (availableAt == null) {
      availableAt = LocalDate.now();
    }
    if (availableUntil == null) {
      availableUntil = LocalDate.now();
    }
    // compareDate 가 availableAt 보다 크거나 같고 availableUntil 보다 작거나 같은지 확인
    LocalDateTime startTime = availableAt.atStartOfDay();
    LocalDateTime endTime = availableUntil.atTime(23, 59, 59);

    // compareDate 를 LocalDateTime 으로 변환
    LocalDateTime compareDateTime = LocalDateTime.ofInstant(compareDate, ZoneId.systemDefault());

    // compareDate 가 startTime 이상이고 endTime 이하인지 확인
    return !compareDateTime.isBefore(startTime) && !compareDateTime.isAfter(endTime);
  }


}
