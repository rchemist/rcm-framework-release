/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.sort;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Order;
import jakarta.persistence.criteria.Path;
import java.util.Arrays;
import java.util.List;
import lombok.EqualsAndHashCode;
import org.springframework.data.domain.Sort.Direction;

/**
 * 일반 정렬 정보를 나타내는 클래스
 * 단순히 필드를 ASC 또는 DESC로 정렬하는 일반적인 정렬
 */
@EqualsAndHashCode(callSuper = true)
public class NormalSortInfo extends SortInfo {
    
    /**
     * Direction만 지정하는 기본 생성자
     */
    @JsonCreator
    public NormalSortInfo(@JsonProperty("direction") Direction direction) {
        super(direction);
    }
    
    /**
     * Direction과 JoinType을 함께 지정하는 생성자
     */
    public NormalSortInfo(Direction direction, JoinType joinType) {
        super(direction);
        this.joinType = joinType;
    }
    
    /**
     * 모든 옵션을 지정하는 생성자
     */
    public NormalSortInfo(Direction direction, JoinType joinType, Boolean nullsFirst) {
        super(direction);
        this.joinType = joinType;
        this.nullsFirst = nullsFirst;
    }
    
    /**
     * 문자열로부터 NormalSortInfo 생성 (JSON deserialize용)
     * @param directionString "ASC" 또는 "DESC"
     * @return NormalSortInfo 인스턴스
     */
    public static NormalSortInfo fromString(String directionString) {
        Direction direction = Direction.valueOf(directionString.toUpperCase());
        return new NormalSortInfo(direction);
    }
    
    @Override
    public boolean isPriority() {
        return false;
    }
    
    @Override
    public List<Order> createJpaOrders(CriteriaBuilder criteriaBuilder, Path<?> path) {
        // nullsFirst 설정이 명시적으로 지정된 경우 - CASE WHEN 사용
        if (nullsFirst != null) {
            // NULL 값 처리를 위한 CASE WHEN 구문
            Expression<Integer> nullHandlingExpr = criteriaBuilder.<Integer>selectCase()
                .when(criteriaBuilder.isNull(path), nullsFirst ? 0 : 2)  // nullsFirst true면 0(처음), false면 2(마지막)
                .otherwise(1);  // 실제 값은 중간
            
            // 두 개의 Order: NULL 처리 + 실제 값 정렬
            return Arrays.asList(
                criteriaBuilder.asc(nullHandlingExpr),  // NULL 위치 정렬
                direction.equals(Direction.DESC) ? 
                    criteriaBuilder.desc(path) : 
                    criteriaBuilder.asc(path)
            );
        }
        
        // 기존 동작 (nullsFirst가 null인 경우)
        // NULL 값 처리를 위한 CASE WHEN 구문
        // hibernate 6.1에서 coalesce를 하면 자동 형변환이 되지 않아 case when을 사용
        Expression<Integer> nullHandlingExpr = criteriaBuilder.<Integer>selectCase()
            .when(criteriaBuilder.isNull(path), 0)
            .otherwise(1);
        
        // JPA에서 nullslast를 지원하지 않아 별도 Expression으로 처리
        return Arrays.asList(
            direction.equals(Direction.DESC) ? 
                criteriaBuilder.desc(nullHandlingExpr) : 
                criteriaBuilder.asc(nullHandlingExpr),
            direction.equals(Direction.DESC) ? 
                criteriaBuilder.desc(path) : 
                criteriaBuilder.asc(path)
        );
    }
    
    @Override
    public String getType() {
        return "normal";
    }
    
    /**
     * JSON 직렬화시 단순 문자열로 직렬화
     * @return "ASC" 또는 "DESC"
     */
    @JsonValue
    public String toJsonValue() {
        return direction.name();
    }
    
    @Override
    public String toString() {
        return direction.name();
    }
}