/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public class CreditSubtractType extends EnumType<CreditSubtractType> {

  public static final CreditSubtractType CUSTOM = new CreditSubtractType(1, "CUSTOM", "Custom", "직접 입력", "global.type.credit.subtract.type.accumulate", true);
  public static final CreditSubtractType PURCHASE = new CreditSubtractType(10, "PURCHASE", "Purchase", "주문 결제에 사용", "global.type.credit.subtract.type.purchase", false);
  public static final CreditSubtractType EXPIRE = new CreditSubtractType(30, "EXPIRE", "Expire", "적립금 기한 만료", "global.type.credit.subtract.type.expire", false);
  public static final CreditSubtractType REFUND = new CreditSubtractType(40, "REFUND", "Refund", "환불로 인한 적립 취소", "global.type.credit.subtract.type.refund", true);
  public static final CreditSubtractType ROLLBACK = new CreditSubtractType(50, "ROLLBACK", "Rollback", "오류로 인한 롤백", "global.type.credit.subtract.type.rollback", false);
  public static final CreditSubtractType TRANSFER = new CreditSubtractType(60, "TRANSFER", "Transfer", "적립금 계좌 간 이체", "global.type.credit.subtract.type.transfer", false);
  public static final CreditSubtractType REDEEM = new CreditSubtractType(70, "REDEEM", "Transfer", "기프트 카드 리딤", "global.type.credit.subtract.type.redeem", false);
  public static final CreditSubtractType SYNC = new CreditSubtractType(80, "SYNC", "Sync", "외부 연동 포인트의 보정", "global.type.credit.subtract.type.sync", false);

  @Getter
  private final boolean customizable;

  public CreditSubtractType(int order, String type, String friendlyType, String description, String messageKey, boolean customizable) {
    super(order, type, friendlyType, description, messageKey);
    this.customizable = customizable;
  }

  private CreditSubtractType(){
    this.customizable = false;
  }


  public static Map<String, String> getAllTypes(){
    Map<String, String> allTypes = new HashMap<>();
    for(EnumType<?> creditSubtractType : getTypes(CreditSubtractType.class)){
      if(((CreditSubtractType) creditSubtractType).isCustomizable()){
        allTypes.put(creditSubtractType.getType(), creditSubtractType.getFriendlyType());
      }
    }
    return allTypes;
  }
}
