/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class UploadFile implements Serializable {

  private String assetKey;
  private String assetUrl;
  private String description;
  private String altText;
  private String suffix;
  private String assetLink;
  private String[] assetTags;
  private int size;
  private Boolean delete;   // 업로드 폼에서 파일을 삭제할 때 식별하기 위함
  private Map<String, String> attributes = new HashMap<>();

  public UploadFile withAssetLink(String assetLink) {
    this.assetLink = assetLink;
    return this;
  }

  public UploadFile withAssetTags(String[] assetTags) {
    this.assetTags = assetTags;
    return this;
  }

  public UploadFile withAssetKey(String assetKey) {
    this.assetKey = assetKey;
    return this;
  }

  public UploadFile withAssetUrl(String assetUrl) {
    this.assetUrl = assetUrl;
    return this;
  }

  public UploadFile withDescription(String description) {
    this.description = description;
    return this;
  }

  public UploadFile withSuffix(String suffix) {
    this.suffix = suffix;
    return this;
  }

  public UploadFile withSize(int size) {
    this.size = size;
    return this;
  }

  public UploadFile withAttributes(Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public UploadFile withAltText(String altText) {
    this.altText = altText;
    return this;
  }

  public UploadFile withDelete(Boolean delete) {
    this.delete = delete;
    return this;
  }

  public UploadFile clone(){
    return new UploadFile()
        .withAssetKey(getAssetKey())
        .withAssetUrl(getAssetUrl())
        .withAssetTags(getAssetTags())
        .withDescription(getDescription())
        .withSuffix(getSuffix())
        .withSize(getSize())
        .withAssetLink(getAssetLink())
        .withAltText(getAltText())
        .withDelete(getDelete())
        .withAttributes(new HashMap<>(getAttributes()));
  }

  public AttachAsset getAttachAsset(){
    return new AttachAsset()
        .withAssetKey(getAssetKey())
        .withAssetUrl(getAssetUrl())
        .withAssetLink(getAssetLink())
        .withAssetTags(getAssetTags())
        .withFileSize(Long.valueOf(getSize()));
  }

}
