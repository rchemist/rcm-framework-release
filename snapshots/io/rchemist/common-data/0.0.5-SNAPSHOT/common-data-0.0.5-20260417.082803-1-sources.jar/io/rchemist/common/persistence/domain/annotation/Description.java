/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Project : rchemist
 * Created by kunner
 * <p>
 * JPA/Hibernate로 정의한 엔티티의 테이블이나 필드에 @Description 을 붙여 field comment 를 작성한다.
 * 필드 수준의 comment 는 ORM 의 관심사가 아니지만, 테이블 정의서를 자동으로 생성한다든가 하는 기능을 위해서 추가했다.
 * 원래는 도메인 정의서와 JavaDoc 만으로 충분해야 하지만, 도메인 보다 테이블이 더 친숙한 사람들을 위한 사족 같은 기능이다.
 * 각 엔티티의 @Table 이나, @Column, @ManyToOne, @OneToOne 과 함께 같은 레벨로 @Description 이 있는 경우 해당 필드의 comment 로 간주한다.
 **/
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Description {

  String name();

  /**
   * Table, Field 의 comment 항목이 들어간다
   *
   * @return
   */
  String comment() default "";

  /**
   * Documentation 에서 제외할 지 여부 - 테이블 단위 또는 필드 단위로 문서화 대상에서 제외할 수 있다
   * @return
   */
  boolean excluded() default false;

  /**
   * 샘플값
   * @return
   */
  String example() default "";

}
