/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class AuditDTO<T> implements Serializable {

  private String createdBy;
  private String updatedBy;
  private AuditUserType createUserType;
  private Instant createdAt;
  private Instant updatedAt;
  private AuditUserType updateUserType;

  public T withCreatedBy(String createdBy) {
    this.createdBy = createdBy;
    return (T) this;
  }

  public T withUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
    return (T) this;
  }

  public T withCreateUserType(
    AuditUserType createUserType) {
    this.createUserType = createUserType;
    return (T) this;
  }

  public T withCreatedAt(Instant createdAt) {
    this.createdAt = createdAt;
    return (T) this;
  }

  public T withUpdatedAt(Instant updatedAt) {
    this.updatedAt = updatedAt;
    return (T) this;
  }

  public T withUpdateUserType(
    AuditUserType updateUserType) {
    this.updateUserType = updateUserType;
    return (T) this;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuditDTO auditDTO = (AuditDTO) o;
    return Objects.equals(createdBy, auditDTO.createdBy) && Objects.equals(
        updatedBy, auditDTO.updatedBy) && Objects.equals(createUserType,
        auditDTO.createUserType) && Objects.equals(createdAt, auditDTO.createdAt)
        && Objects.equals(updatedAt, auditDTO.updatedAt) && Objects.equals(
        updateUserType, auditDTO.updateUserType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(createdBy, updatedBy, createUserType, createdAt, updatedAt, updateUserType);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("createdBy", createdBy)
        .append("updatedBy", updatedBy)
        .append("createUserType", createUserType)
        .append("createdAt", createdAt)
        .append("updatedAt", updatedAt)
        .append("updateUserType", updateUserType)
        .toString();
  }

  public T withAudit(AuditDTO<?> audit) {
    this.createdBy = audit.getCreatedBy();
    this.updatedBy = audit.getUpdatedBy();
    this.createUserType = audit.getCreateUserType();
    this.createdAt = audit.getCreatedAt();
    this.updatedAt = audit.getUpdatedAt();
    this.updateUserType = audit.getUpdateUserType();
    return (T) this;
  }
}
