/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.ReferenceFieldView;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(value = HasAudit.class)
public class HasAuditImpl implements EnhancedTemplate {

  @AdminField(name = "AuditableUpdated_UpdatedAt", propertyName = "updatedAt", order = 300, readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS), fieldType = PresentationFieldType.DATETIME, modifiableType = ModifiableType.MODIFY_ONLY)
  protected Instant updatedAt;

  @AdminField(name = "AuditableUpdated_UpdatedBy", order = 400
      , readOnly = true, tab = @ViewTab(type = TabEnumType.STATUS)
      , fieldType = PresentationFieldType.FOREIGN_KEY
      , referenceField = @ReferenceFieldView(foreignKeyClass = "io.rchemist.common.user.domain.User")
      , modifiableType = ModifiableType.MODIFY_ONLY)
  protected String updatedBy;

}
