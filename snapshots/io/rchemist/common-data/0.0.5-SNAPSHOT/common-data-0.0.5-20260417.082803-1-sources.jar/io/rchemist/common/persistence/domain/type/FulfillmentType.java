/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.domain.annotation.Description;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class FulfillmentType extends EnumType<FulfillmentType> {

  // (택배, 퀵 등)
  public static final FulfillmentType SHIPPING = new FulfillmentType(10, "SHIPPING","Shipping"
      ,"원격배송","global.type.fulfillment.type.shipping", false, true, true);

  public static final FulfillmentType SHIPPING_PICKUP = new FulfillmentType(20, "SHIPPING_PICKUP","Shipping and Pickup"
      ,"원격 배송 + 픽업","global.type.fulfillment.type.shiping_pickup", true, true, false);

  // 교환권 발행
  public static final FulfillmentType PICKUP = new FulfillmentType(30, "PICKUP","Pickup"
      ,"매장 픽업","global.type.fulfillment.type.pickup", true, true, false);

  // 영화 예매, 펜션 예매 등 스케쥴과 관련있는 형태. 단, 전시회 예매 처럼 보통 특정 시각에만 갈 수 있는게 아니라 특정 기간 내 어떤 시각에도 갈 수 있는 경우는 PICKUP 을 이용하면 더 쉽게 처리가 가능하다.
  public static final FulfillmentType BOOKING = new FulfillmentType(40, "BOOKING","Booking"
      ,"예약","global.type.fulfillment.type.booking", true, false, false);

  // 무기명 적립금 - 기프트카드 발행
  public static final FulfillmentType GIFTCARD = new FulfillmentType(50, "GIFTCARD","GiftCard"
      ,"기프트카드","global.type.fulfillment.type.giftcard", false, false, false);

  // 다운로드 URL 제공
  public static final FulfillmentType DOWNLOAD = new FulfillmentType(60, "DOWNLOAD", "Download", "다운로드", "global.type.fulfillment.type.download", false, false, false);


  @Description(name = "위치 지정 필요 여부", comment = "이 값이 true 면 FG 에 반드시 location 이 특정되어야 한다.")
  private final boolean shouldSpecifyLocation;

  @Description(name = "물리 배송 여부", comment = "이 값이 true 면 물리적 배송이 일어남을 의미한다")
  private final boolean physicalShipping;

  @Description(name = "주소 특정 필요 여부", comment = "이 값이 true 면 반드시 주소를 특정해야 한다.")
  private final boolean shouldSpecifyAddress;

  public FulfillmentType(int order, String type, String friendlyType, String description,
      String messageKey, boolean shouldSpecifyLocation, boolean physicalShipping, boolean shouldSpecifyAddress) {
    super(order, type, friendlyType, description, messageKey);
    this.shouldSpecifyLocation = shouldSpecifyLocation;
    this.physicalShipping = physicalShipping;
    this.shouldSpecifyAddress = shouldSpecifyAddress;
  }
}
