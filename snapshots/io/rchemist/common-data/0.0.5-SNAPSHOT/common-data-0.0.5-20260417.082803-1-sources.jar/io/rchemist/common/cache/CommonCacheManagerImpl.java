/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.rchemist.common.util.ExceptionUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.cache.configuration.Factory;
import javax.cache.configuration.MutableConfiguration;
import javax.cache.expiry.CreatedExpiryPolicy;
import javax.cache.expiry.Duration;
import javax.cache.expiry.EternalExpiryPolicy;
import javax.cache.expiry.ExpiryPolicy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component(CommonCacheManager.BEAN_NAME)
public class CommonCacheManagerImpl implements CommonCacheManager {

  protected final CacheManager cacheManager;

  private static final Map<String, CacheConfiguration> CACHE_CONFIGS = new ConcurrentHashMap<>(
      1000);

  public CommonCacheManagerImpl(@Qualifier("rcmCacheManager") CacheManager cacheManager) {
    this.cacheManager = cacheManager;
  }

  @Override
  public <V> Cache<String, V> getCache(String region) {
    return getCacheManager().getCache(region);
  }

  @Override
  public CacheManager getCacheManager() {
    return cacheManager;
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  public void put(String region, String key, Object value) {
    try {
      Cache cache = getCache(region);
      cache.put(key, value);
    } catch (Exception e) {
      log.warn(e + " - " + e.getMessage());
    }
  }

  @Override
  public void put(String region, Object value, Class<?> clazz, String... cacheKey) {
    put(region, buildKey(clazz, cacheKey), value);
  }

  @Override
  public void putAll(String region, Map<String, Object> cacheMap) {

    if (MapUtils.isNotEmpty(cacheMap)) {
      for (Map.Entry<String, Object> entry : cacheMap.entrySet()) {
        try {
          put(region, entry.getKey(), entry.getValue());
        } catch (Exception e) {
          log.warn(
              "Error occurred when put " + region + " - key is " + entry.getKey() + ", value is "
                  + entry.getValue());
          ExceptionUtil.printStackTrace(e);
        }
      }
    }

  }

  @Override
  public boolean contains(String region, String cacheKey) {
    try {
      Cache<String, ?> cache = getCache(region);
      if (cache != null) {
        return cache.get(cacheKey) != null;
      }
    } catch (Exception e) {
      ExceptionUtil.printStackTrace(e);
    }
    return false;
  }

  @Override
  public boolean contains(String region, String... cacheKey) {
    String key = buildKey(cacheKey);
    return contains(region, key);
  }

  @Override
  public boolean contains(String region, Class<?> clazz, String... cacheKey) {
    return contains(region, buildKey(clazz, cacheKey));
  }

  @Override
  public <V> V get(String region, String cacheKey) {
    if (contains(region, cacheKey)) {
      try {
        Cache<String, V> cache = getCache(region);
        if (cache != null && cache.get(cacheKey) != null) {
          return cache.get(cacheKey);
        }
      } catch (Exception e) {
        ExceptionUtil.printStackTrace(e);
      }
    }
    return null;
  }

  @Override
  public <V> V get(String region, String... cacheKey) {
    String key = buildKey(cacheKey);
    return get(region, key);
  }

  @Override
  public <V> V get(String region, Class<?> clazz, String... cacheKey) {
    return get(region, buildKey(clazz, cacheKey));
  }

  @Override
  public Set<String> getAllRegionNames() {
    return CACHE_CONFIGS.keySet();
  }

  @Override
  public void evictAll(String... regionNames) {
    Set<String> regions;

    if (regionNames == null || ArrayUtils.isEmpty(regionNames)) {
      regions = getAllRegionNames();
    } else {
      regions = Set.of(regionNames);
    }

    for (String region : CollectionUtils.emptyIfNull(regions)) {
      try {
        removeAll(region);
      } catch (Exception e) {
        log.warn("Error has occurred when Evict cache - " + region + ".");
      }
    }
  }

  @Override
  public CacheConfiguration getCacheConfig(String region) {
    CacheConfiguration configuration = CACHE_CONFIGS.get(region);

    if (configuration != null) {
      return configuration.cloned();
    }

    return null;
  }

  @Override
  public Map<String, CacheConfiguration> getCacheConfig() {
    return new HashMap<>(CACHE_CONFIGS);
  }

  @Override
  public void removeAll(String region) {
    try {
      // cacheManager.getCache(region, String.class, Object.class).clear();

      Cache<String, ?> cache = cacheManager.getCache(region, String.class, Object.class);
      if (cache != null) {
        cache.clear();
        cache.removeAll();
      } else {
        throw new Exception("There is no cache - region Name is " + region);
      }
    } catch (Exception e) {
      log.warn("Error has occurred when Evict cache - " + region + ".");
      ExceptionUtil.printStackTrace(e);
    }
  }

  @Override
  public void remove(String region, String cacheKey) {
    try {
      cacheManager.getCache(region, String.class, Object.class).remove(cacheKey);
    } catch (Exception e) {
      log.warn("Error has occurred when Evict cache - " + region + ", key: " + cacheKey + ".");
      ExceptionUtil.printStackTrace(e);
    }
  }

  @Override
  public void remove(String region, String... cacheKey) {
    remove(region, buildKey(cacheKey));
  }

  @Override
  public void remove(String region, Class<?> clazz, String... cacheKey) {
    String key = buildKey(clazz, cacheKey);
    remove(region, key);
  }

  @Override
  public String buildKey(String... cacheKey) {
    return buildKey(null, cacheKey);
  }

  @Override
  public String buildKey(Class<?> clazz, String... cacheKey) {
    return buildKey(false, clazz, cacheKey);
  }

  @Override
  public String buildKeyIgnoreSite(Class<?> clazz, String... cacheKey) {
    return buildKey(true, clazz, cacheKey);
  }

  protected String buildKey(boolean ignoreSite, Class<?> clazz, String... cacheKey) {
    StringBuilder sb = new StringBuilder();

    // LocalCacheManager로 생성된 캐시는 대상 entity className의 접두어를 가진다 - 나중에 캐시 동기화 처리를 위해 사용한다(evict)
    if (clazz != null) {
      sb.append(clazz.getSimpleName());
      sb.append("_");
    }

    sb.append(StringUtils.join(cacheKey, '_'));

    // TODO
    /*if(!ignoreSite){
      WebRequestContext context = WebRequestContext.getWebRequestContext();
      Long siteId = context.getCurrentSiteId();

      if(siteId != null){
        sb.append("_");
        sb.append(siteId);
      }

    }*/

    return sb.toString();
  }

  @Override
  public synchronized <V> Cache<String, V> createCache(String cacheName, int ttlSeconds,
      int maxElementsInMemory, Class<V> value) {
    return createCache(new CacheConfiguration(cacheName, ttlSeconds, maxElementsInMemory, value));
  }

  /**
   * 실제 Cache 를 생성하는 메소드
   *
   * @param configuration
   * @param <V>           value class 의 타입
   * @return
   */
  private synchronized <V> Cache<String, V> createCache(CacheConfiguration configuration) {
    try {

      if (!configuration.validate()) {
        throw new RuntimeException("Invalid Cache Configuration - " + configuration);
      }

      final Factory<ExpiryPolicy> expiryPolicy;
      if (configuration.isEternal()) {
        //Eternal
        expiryPolicy = EternalExpiryPolicy.factoryOf();
      } else {
        //Number of seconds since created in cache
        expiryPolicy = CreatedExpiryPolicy.factoryOf(
            new Duration(TimeUnit.SECONDS, configuration.getTtl()));
      }

      final MutableConfiguration config = new MutableConfiguration<>();
      config.setTypes(String.class, Object.class);
      config.setExpiryPolicyFactory(expiryPolicy);
      Cache<String, V> cache = getCacheManager().createCache(configuration.getRegion(), config);
      getCacheManager().enableManagement(cache.getName(), false);
      getCacheManager().enableStatistics(cache.getName(), true);

      // cache 가 생성된 후 해당 캐시 생성 설정을 메모리에 저장한다.
      CACHE_CONFIGS.put(configuration.getRegion(), configuration);

      return cache;
    } catch (Exception e) {
      log.warn("Error occurred when create cache - " + configuration + ".");
      ExceptionUtil.printStackTrace(e);
      throw new RuntimeException(e);
    }
  }


  @Override
  public synchronized <V> Cache<String, V> getOrCreateCache(String cacheName, int ttlSeconds,
      int maxElementsInMemory, Class<V> value) {
    return getOrCreateCache(new CacheConfiguration()
        .withRegion(cacheName)
        .withTtl(ttlSeconds)
        .withMaxEntries(maxElementsInMemory)
        .withValueClass(value));
  }

  @Override
  public synchronized <V> Cache<String, V> getOrCreateCache(CacheConfiguration config) {
    if (config.hasRegion()) {
      Cache<String, V> cache = getCache(config.getRegion());

      if (cache == null) {
        try {
          return createCache(config);
        } catch (Exception e) {
          log.warn("Error occurred when create cache - " + config + ".");
          ExceptionUtil.printStackTrace(e);
        }
      }
    }
    throw new RuntimeException("There is no configured cache region name - " + config);
  }

  @Override
  public <V> Cache<String, V> getOrCreateCache(CacheConfiguration config,
      Class<V> value) {
    return getOrCreateCache(config.withValueClass(value));
  }

  @Override
  public void clear() {
    evictAll();
  }

}
