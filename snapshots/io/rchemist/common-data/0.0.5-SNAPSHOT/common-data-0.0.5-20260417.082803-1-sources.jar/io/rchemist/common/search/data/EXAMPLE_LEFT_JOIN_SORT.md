# RCM Framework - LEFT JOIN 정렬 사용 예시

## 문제 상황
Lecture가 Subject를 ManyToOne으로 참조하고, Subject이 Major를 ManyToOne으로 참조하는 경우:
- `subject.major.id`로 정렬 시 INNER JOIN이 기본 적용됨
- subject가 없거나 subject.major가 없는 Lecture는 검색 결과에서 제외됨

## 해결 방법

### 1. SearchForm에서 직접 설정 (권장)

```java
// SearchForm 생성 시 LEFT JOIN 정렬 설정
SearchForm searchForm = new SearchForm();

// 방법 1: NormalSortInfo에 JoinType 지정
LinkedHashMap<String, SortInfo> sorts = new LinkedHashMap<>();
sorts.put("subject.major.name", new NormalSortInfo(Direction.ASC, JoinType.LEFT));
searchForm.setSorts(sorts);

// 방법 2: PrioritySortInfo에 JoinType 지정 (특정 값 우선 정렬 + LEFT JOIN)
sorts.put("subject.major.id", new PrioritySortInfo(
    1L,                    // majorId = 1을 우선
    Direction.ASC,         // 나머지는 오름차순
    JoinType.LEFT         // LEFT JOIN 사용
));
searchForm.setSorts(sorts);

// 방법 3: null 위치도 함께 지정
sorts.put("subject.major.name", new NormalSortInfo(
    Direction.ASC,         // 오름차순
    JoinType.LEFT,        // LEFT JOIN
    false                 // nulls last
));
searchForm.setSorts(sorts);
```

### 2. CommonSearchContext에서 설정

```java
// SearchContext 생성 후 JOIN 타입 설정
CommonSearchContext<Lecture, SearchForm> context = 
    new CommonSearchContext<>(Lecture.class, searchForm)
        .useSortLeftJoin("subject.major.id")  // 간편 설정
        .addSearchPredicates("name");

// 또는 명시적 설정
context.configureSortJoin("subject.major.id", JoinType.LEFT);
```

### 3. JSON 요청에서 설정

```json
{
  "page": 0,
  "pageSize": 20,
  "sorts": {
    "subject.major.name": {
      "direction": "ASC",
      "joinType": "LEFT",
      "nullsFirst": false
    }
  }
}
```

### 4. 우선순위 정렬과 함께 사용

```json
{
  "sorts": {
    "subject.major.id": {
      "type": "priority",
      "priorityValue": 1,
      "direction": "ASC",
      "joinType": "LEFT"
    }
  }
}
```

## 동작 방식

1. **기본 동작 (joinType 미지정)**
   - QuerySpecification에서 기본값 LEFT JOIN 적용
   - null 값이 있는 엔티티도 결과에 포함

2. **명시적 INNER JOIN**
   - 기존과 같이 관계가 있는 엔티티만 조회
   ```java
   sorts.put("subject.major.name", new NormalSortInfo(Direction.ASC, JoinType.INNER));
   ```

3. **NULL 값 정렬 위치**
   - `nullsFirst = true`: NULL 값을 처음에 배치
   - `nullsFirst = false`: NULL 값을 마지막에 배치
   - `nullsFirst = null`: 기본 동작 (ASC는 first, DESC는 last)

## 주의사항

1. **성능 고려사항**
   - LEFT JOIN은 INNER JOIN보다 더 많은 데이터를 처리
   - 인덱스 최적화 필요

2. **하위 호환성**
   - joinType 미지정 시 기본값이 LEFT로 변경됨
   - 기존 코드에서 INNER JOIN이 필요한 경우 명시적 설정 필요

3. **복잡한 JOIN 경로**
   - 다중 레벨 JOIN 경로도 지원 (예: "subject.major.department.name")
   - 각 레벨에서 동일한 JOIN 타입 적용