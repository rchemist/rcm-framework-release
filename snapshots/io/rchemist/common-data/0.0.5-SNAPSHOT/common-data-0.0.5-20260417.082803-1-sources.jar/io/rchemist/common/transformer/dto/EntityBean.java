/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public abstract class EntityBean<T> {

  protected String name;
  protected String tableName;
  protected Class<?> entityClass;
  protected int order;
  protected boolean supportHibernateSearch = false;
  protected Map<String, String> properties;
  protected List<RestrictOnDeleteDTO> restrictOnDeletes = new ArrayList<>();
  protected Map<String, EvictCacheDTO> evictCacheRegionOnMerge = new HashMap<>();

  // 커스텀필드로 사용할 필드의 이름과 DTO 로 변환될 필드의 이름
  protected Map<String, String> attributeFields = new HashMap<>();
  protected List<String> lazyLoadProperties = new ArrayList<>();     // lazy load 되어야 하는 프로퍼티에 대한 접근 메소드(getter)

  protected boolean supportSoftDelete;

  // propertyName, Column name
  protected Map<String, String> columnNames = new HashMap<>();    // propertyName 과 매핑되는 column name
  // columnName, property name
  protected Map<String, String> propertyNames = new HashMap<>();    // column_name 과 매핑되는 property name

  protected List<UniqueConstraint> uniqueConstraints = new ArrayList<>();    // 각 컬럼에 적용된 @Unique 어노테이션 정보

  // property name : string, property class : RegisterEntityBeanPropertyDTO
  protected Map<String, RegisterEntityBeanPropertyDTO> classMappingProperties = new HashMap<>();    // propertyName 과 매핑되는 Class 정보
  
  
  protected static final String INDEXED_CLASS_NAME = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed";
  protected static final String GENERIC_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField";
  protected static final String FULL_TEXT_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField";
  protected static final String KEYWORD_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField";
  protected static final String SCALED_NUMBER_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.ScaledNumberField";
  protected static final String NON_STANDARD_FIELD = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.NonStandardField";
  protected static final String INDEX_EMBEDDED = "org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexedEmbedded";

  /*
  import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
   */
  protected static final String COLUMN = "jakarta.persistence.Column";
  protected static final String EMBEDDED = "jakarta.persistence.Embedded";
  protected static final String MANY_TO_ONE = "jakarta.persistence.ManyToOne";
  protected static final String ONE_TO_MANY = "jakarta.persistence.OneToMany";
  

  public void setEntityClass(String tableName, Class<?> entityClass){
    this.entityClass = entityClass;
    this.tableName = tableName;
    arrangeProperties();
  }

  public boolean priorThan(int compare){
    // 기존 등록된 bean 이 현재 비교하는 것보다 우선순위가 높다면(숫자값이 작을 수록 우선순위가 높다)
    return order <= compare;
  }

  public boolean isEmpty(){
    return StringUtils.isBlank(name);
  }


  public T addRestrictOnDelete(String entityClassName, String property){
    if(this.restrictOnDeletes == null)
      this.restrictOnDeletes = new ArrayList<>();
    RestrictOnDeleteDTO dto = new RestrictOnDeleteDTO(entityClassName, property);
    if(!this.restrictOnDeletes.contains(dto)){
      this.restrictOnDeletes.add(dto);
    }
    return (T) this;
  }

  public T addEvictCacheRegionOnMerge(String cacheRegion, EvictCacheDTO contextual) {
    if(this.evictCacheRegionOnMerge == null)
      this.evictCacheRegionOnMerge = new HashMap<>();
    this.evictCacheRegionOnMerge.put(cacheRegion, contextual);
    return (T) this;
  }

  public T addLazyLoadProperty(String propertyName){
    if(this.lazyLoadProperties == null)
      this.lazyLoadProperties = new ArrayList<>();
    this.lazyLoadProperties.add(propertyName);
    return (T) this;
  }

  public T addUniqueProperty(UniqueConstraint uniqueConstraint){
    if(this.uniqueConstraints == null)
      this.uniqueConstraints = new ArrayList<>();
    boolean duplicated = false;
    for(UniqueConstraint constraint : uniqueConstraints){
      if(constraint.equals(uniqueConstraint)){
        duplicated = true;
        break;
      }
    }
    if(!duplicated){
      this.uniqueConstraints.add(uniqueConstraint);
    }
    return (T) this;
  }

  protected void arrangeProperties(){
    // override here if needed
  }

  public void loadLazyProperties(Object entityValue){
    // override here if needed
  }


  protected void mapJoinedPropertiesToClass(String propertyName, Class propertyClass, Class entityClass) {
    // override here if needed
  }


  /**
   * Embedded, ManyToOne 인 경우 propertyName 에 . 을 붙여서 저장한다.
   *
   */
  public void mapPropertiesToClass(String propertyName, String propertyType, Class propertyClass, String joinAlias, Class joinClass, Class entityClass) {
    // override here if needed
  }

  protected boolean isAssignableFrom(Class returnType, Class compareType) {
    return compareType.isAssignableFrom(returnType);
  }

  public boolean hasUniqueConstraint(){
    return CollectionUtils.isNotEmpty(uniqueConstraints);
  }

  public boolean hasAttributeFields() {
    return MapUtils.isNotEmpty(attributeFields);
  }

  public String getOriginAttributeFieldName(String originName) {
    if (hasAttributeFields()) {

      for (Entry<String, String> entry : attributeFields.entrySet()) {
        String key = entry.getKey();
        String value = entry.getValue();

        if (StringUtils.equals(value, originName)) {
          return key;
        }
      }

    }
    return originName;
  }

  public String getAttributeFieldName(String propertyName) {
    return attributeFields.get(propertyName);
  }

  public boolean isAttributeField(String fieldName) {
    if (hasAttributeFields()) {
      for (String value : attributeFields.values()) {
        if (StringUtils.equals(value, fieldName)) {
          return true;
        }
      }
    }
    return false;
  }

  public boolean isAttributeFieldName(String fieldName) {
    if (hasAttributeFields()) {
      for (String key : attributeFields.keySet()) {
        if (StringUtils.equals(key, fieldName)) {
          return true;
        }
      }
    }
    return false;
  }


}
