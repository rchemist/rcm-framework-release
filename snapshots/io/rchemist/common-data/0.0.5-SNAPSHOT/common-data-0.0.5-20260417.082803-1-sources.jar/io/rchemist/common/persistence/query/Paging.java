/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query;

import io.rchemist.common.persistence.query.dto.SearchCondition;
import io.rchemist.common.util.ExceptionUtil;
import java.io.Serializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@NoArgsConstructor
public class Paging implements Serializable {

  @Setter
  protected int page = 1;

  @Setter
  protected int pageSize = 20;

  @Setter
  protected int totalCount;

  @Setter
  protected int pageListSize = 10;

  @Setter
  protected SearchCondition searchCondition = new SearchCondition();

  /**
   * 자동 계산 정보 - Don't allow setter, only getter()
   */
  protected int firstPage = 1;

  protected int lastPage;

  protected int prevPage;

  protected int nextPage;

  protected int listFirstPage;

  protected int listLastPage;

  public Paging(Integer page, Integer pageSize, Integer pageListSize) {
    this.page = page;
    this.pageSize = pageSize;
    this.pageListSize = pageListSize;
  }

  public Paging init(int totalCount){
    setTotalCount(totalCount);
    return init();
  }


  /**
   * Paging 관련 정보 init() 반드시 init 후 사용해야 함
   * Paging 생성 시 withProperties() 를 사용하지 않은 경우 반드시 init() 을 호출해야 함
   * @return
   */
  public Paging init(){
    try{
      if(page>0 && pageSize > 0 && totalCount > -1 && pageListSize > 0){
        // lastPage
        this.lastPage = (int) Math.ceil((double) this.totalCount / this.pageSize);

        // 이전 페이지번호 찾기 : 현재 페이지를 계산해 현재 페이지가 1보다 크면 page - 1 리턴
        if(page>1){
          this.prevPage = page - 1;
        }else{
          this.prevPage = page;
        }

        // 다음 페이지 번호 찾기 : 현재 페이지 번호가 전체 페이지 번호와 같다
        if(page<getLastPage()){
          this.nextPage = page+1;
        }else{
          this.nextPage = page;
        }

        // listFirstPage, listLastPage
        if(page<getPageListSize()){
          this.listFirstPage = 1;
          this.listLastPage = this.pageListSize;
        }else{
          int compareValue = (this.page / this.pageListSize - ((this.page % this.pageListSize == 0) ? 1 : 0));
          this.listFirstPage = (compareValue * this.pageListSize) + 1;
          this.listLastPage = (compareValue + 1) * this.pageListSize;
        }
      }
    }catch(Exception e){
      // nothing to do
      ExceptionUtil.printStackTrace(e);
    }
    return this;
  }

  public Paging withPage(int page) {
    this.page = page;
    return this;
  }

  public Paging withPageSize(int pageSize) {
    this.pageSize = pageSize;
    return this;
  }

  public Paging withTotalCount(int totalCount) {
    this.totalCount = totalCount;
    return this;
  }

  public Paging withPageListSize(int pageListSize) {
    this.pageListSize = pageListSize;
    return this;
  }

  public Paging withSearchCondition(SearchCondition searchCondition) {
    this.searchCondition = searchCondition;
    return this;
  }
}
