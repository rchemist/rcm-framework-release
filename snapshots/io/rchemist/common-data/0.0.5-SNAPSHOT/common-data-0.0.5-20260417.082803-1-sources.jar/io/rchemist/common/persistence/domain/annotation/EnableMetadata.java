/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import io.rchemist.common.util.StringUtil;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface EnableMetadata {

  String getMetaTitle();

  String getMetaDescription();

  void setMetaHeaders(Map<String, String> metaHeaders);

  Map<String, String> getMetaHeaders();

  default String getMetaHeader(){
    if(MapUtils.isEmpty(getMetaHeaders()))
      return null;
    StringBuilder sb = new StringBuilder();
    for(Entry<String, String> entry : getMetaHeaders().entrySet()){
      try {
        sb.append(entry.getKey());
        if(StringUtils.isNotEmpty(entry.getValue())){
          sb.append("=")
              .append(entry.getValue());
        }
        sb.append(";");
      }catch (Exception e){
        e.printStackTrace();
      }
    }
    return sb.toString();
  }

  default void setMetaHeader(String metaHeader){
    if(StringUtils.isNotEmpty(metaHeader)){
      Map<String, String> headers = StringUtil.splitMap(metaHeader, ";", "=");
      setMetaHeaders(headers);
    }
  }


}
