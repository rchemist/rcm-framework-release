/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.embedded;

import io.rchemist.common.util.StringUtil;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public interface IAddress {

  String getCountry();

  String getState();

  String getCity();

  String getAddress1();

  String getAddress2();

  String getAddressDetail();

  String getPostalCode();

  void setCountry(String country);
  void setState(String state);
  void setCity(String city);
  void setAddress1(String address1);
  void setAddress2(String address2);
  void setAddressDetail(String addressDetail);
  void setPostalCode(String postalCode);

  default String getFullAddress() {
    return StringUtil.mergeWithSplitCode(" ", getCountry(), getState(), getCity(), getAddress1(), getAddress2(), getAddressDetail(), getPostalCode());
  }

  default boolean isValidAddress() {
    return !StringUtils.isAnyBlank(getAddress1(), getAddressDetail());
  }

}
