/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.transformer.dto.RegisterEntityBeanPropertyDTO;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import jakarta.persistence.Column;
import jakarta.persistence.criteria.JoinType;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 *
 * 커스텀필드 - Entity Attribute Value 형태의 필드에 대해 sort 하는 경우 DB 구조에 맞게 필드명을 변경하고 추가로 JOIN 이 필요하다면 FilterItem 으로 JOIN 을 명시한다.
 *
 * 예를 들어, User 에 대해 검색할 때 userAttributes.color 로 검색한다고 할 때
 * 이 검색은 다음과 같이 이뤄져야 한다.
 *
 * select U.*, A.ATTR_NAME, A.ATTR_VALUE from T_USER U LEFT OUTER JOIN T_USER_ATTRIBUTE A ON U.USER_ID = A.USER_ID
 * AND A.`ATTR_NAME` = 'color'
 * order by A.ATTR_VALUE desc;
 *
 *
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component
public class EntityAttributeFieldModifier implements SearchFieldModifier, SortFieldModifier {

  @Override
  public FilterItem transform(ModifyFilterRequest request) {

    EntityBean<?> entityBean = request.getEntityBean();
    FilterItem filterItem = request.getFilterItem();
    String propertyName = filterItem.getName();

    if (entityBean.hasAttributeFields() && StringUtils.contains(propertyName, ".")) {

      String joinProperty = StringUtils.substringBefore(propertyName, ".");
      String filterProperty = StringUtils.substringAfter(propertyName, ".");

      boolean isAttributeFieldName = entityBean.isAttributeFieldName(joinProperty);

      // 만약 지정된 attribute 필드명이 아니라 Entity 의 실제 필드명이 propertyName 에 사용됐다면 지정된 attribute name 으로 교체한다.

      if (isAttributeFieldName) {
        joinProperty = entityBean.getAttributeFieldName(joinProperty);
      }

      if (request.isHibernateSearch()) {

        filterItem.setName(joinProperty + "." + filterProperty);

        return filterItem;

      } else {

        boolean isAttributeField = entityBean.isAttributeField(joinProperty);

        if (isAttributeField) {

          joinProperty = entityBean.getOriginAttributeFieldName(joinProperty);

          propertyName = joinProperty + "." + filterProperty;

          if (StringUtils.equals(filterProperty, "value")) {
            return filterItem.withName(propertyName)
                .withJoinType(JoinType.LEFT)
                .withJoinClass(entityBean.getClassMappingProperties().get(joinProperty).getPropertyJoinClass());
          } else {

            // value 가 아니라면 커스텀 필드로 처리된다.

            // 예를 들어 attributes.color=red 로 검색이 들어 왔다면 LEFT OUTER JOIN 으로 attributes.name = 'color' 조건과 attributes.value = 'red' 를 추가한다.

            RegisterEntityBeanPropertyDTO property = entityBean.getClassMappingProperties().get(joinProperty);

            if (property != null) {

              boolean jsonFilter = false;

              if (property.getPropertyType().equals(Column.class.getName())) {
                // JSON 필드인 경우

                return filterItem.withName(propertyName)
                    // .withJoinType(JoinType.LEFT)
                    .withJsonFilter(true);

              } else {

                JoinType joinType = JoinType.LEFT;

                LinkedHashMap<ConditionOperatorType, FilterItem[]> subFilters = new LinkedHashMap<>();
                subFilters.put(ConditionOperatorType.AND, new FilterItem[]{
                    new FilterItem().withName(joinProperty + ".name")
                        .withJoinType(joinType)
                        .withApplyOnClause(true)
                        .withJsonFilter(jsonFilter)
                        .withJoinClass(entityBean.getClassMappingProperties().get(joinProperty).getPropertyJoinClass())
                        .withValue(filterProperty),
                    new FilterItem().withName(joinProperty + ".value")
                        .withJoinType(joinType)
                        .withApplyOnClause(true)
                        .withJsonFilter(jsonFilter)
                        .withJoinClass(entityBean.getClassMappingProperties().get(joinProperty).getPropertyJoinClass())
                        .withValue(filterItem.getValue())
                });

                return new FilterItem()
                    .withName(joinProperty + ".name")
                    .withSubFilters(subFilters);
              }


            }



          }

        }

      }
    }

    return filterItem;
  }

  @Override
  public ModifySortRequest modifySorts(ModifySortRequest request) {

    EntityBean<?> entityBean = request.getEntityBean();

    if (entityBean.hasAttributeFields()) {

      LinkedHashMap<ConditionOperatorType, FilterItem[]> newFilters = new LinkedHashMap<>();
      if (MapUtils.isNotEmpty(request.getFilters())) {
        newFilters.putAll(request.getFilters());
      }

      List<SortEntry> sortEntries = request.getSortEntries();
      if (sortEntries == null || sortEntries.isEmpty()) {
        return request;
      }

      List<SortEntry> newSortEntries = new ArrayList<>();
      List<SortEntry> entriesToRemove = new ArrayList<>();

      for (SortEntry entry : sortEntries) {
        String sortKey = entry.getFieldName();

        if (StringUtils.contains(sortKey, ".")) {
          String joinProperty = StringUtils.substringBefore(sortKey, ".");
          String sortProperty = StringUtils.substringAfter(sortKey, ".");

          boolean isAttributeFieldName = entityBean.isAttributeFieldName(joinProperty);

          if (isAttributeFieldName) {
            joinProperty = entityBean.getAttributeFieldName(joinProperty);
          }

          boolean isAttributeField = entityBean.isAttributeField(joinProperty);

          if (isAttributeField) {
            // 커스텀 필드에 대한 정렬이라면 JOIN 도 함께 처리해야 한다.

            if (request.isHibernateSearch()) {

              newSortEntries.add(new SortEntry(joinProperty + "." + sortProperty, entry.getSortInfo()));
              entriesToRemove.add(entry);

            } else {
              joinProperty = entityBean.getOriginAttributeFieldName(joinProperty);

              RegisterEntityBeanPropertyDTO property = entityBean.getClassMappingProperties().get(joinProperty);

              if (property != null) {

                if (property.getPropertyType().equals(Column.class.getName())) {

                  // json field 에 대한 JPA sort 는 불가능
                  log.warn("json field 에 대한 JPA sort 는 불가능합니다. JSON 필드에 대한 정렬은 Hibernate Search 를 이용해야 합니다.");
                  entriesToRemove.add(entry);

                } else {
                  Class<?> joinClass = entityBean.getClassMappingProperties().get(joinProperty + ".name").getPropertyJoinClass();

                  FilterItem joinFilterItem = new FilterItem().withName(joinProperty + ".name")
                      .withJoinType(JoinType.LEFT)
                      .withApplyOnClause(true)
                      .withJoinClass(joinClass);

                  if (StringUtils.equals(sortProperty, "value")) {

                    // value 로 값이 들어오면 정상
                    newSortEntries.add(new SortEntry(joinProperty + ".value", entry.getSortInfo()));
                    entriesToRemove.add(entry);

                  } else {
                    // value 가 아니라면 커스텀 필드로 처리된다.
                    joinFilterItem.withValue(sortProperty);

                    newSortEntries.add(new SortEntry(joinProperty + ".value", entry.getSortInfo()));
                    entriesToRemove.add(entry);

                  }

                  if (newFilters.isEmpty()) {
                    newFilters.put(ConditionOperatorType.AND, new FilterItem[] {
                        joinFilterItem
                    });
                  } else {

                    boolean addJoinFilter = true;

                    for (Entry<ConditionOperatorType, FilterItem[]> filterEntry : request.getFilters().entrySet()) {
                      FilterItem[] filterItems = filterEntry.getValue();
                      List<FilterItem> filterItemList = new ArrayList<>();
                      if (ArrayUtils.isNotEmpty(filterItems)) {
                        for (FilterItem filterItem : filterItems) {
                          if (filterItem.getName().equals(joinFilterItem.getName())) {
                            addJoinFilter = false;
                          }
                          filterItemList.add(filterItem);
                        }
                      }
                      if (addJoinFilter) {
                        filterItemList.add(joinFilterItem);
                      }
                      newFilters.put(filterEntry.getKey(), filterItemList.toArray(new FilterItem[0]));
                    }

                  }
                }
              }
            }
          } else {
            // Not an attribute field, keep as is
            newSortEntries.add(entry);
          }
        } else {
          // No dot in field name, keep as is
          newSortEntries.add(entry);
        }
      }

      // Add entries that weren't modified (avoiding duplicates)
      for (SortEntry entry : sortEntries) {
        if (!entriesToRemove.contains(entry) && !newSortEntries.contains(entry)) {
          newSortEntries.add(entry);
        }
      }

      request.withFilters(newFilters).withSortEntries(newSortEntries);

    }

    return request;

  }

  @Override
  public int getOrder() {
    return 1000;
  }
}
