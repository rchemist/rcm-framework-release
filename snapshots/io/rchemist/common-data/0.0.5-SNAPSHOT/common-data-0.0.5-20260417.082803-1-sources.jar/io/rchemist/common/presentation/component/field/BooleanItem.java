/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.component.field;

import io.rchemist.common.util.CollectionUtil;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class BooleanItem implements Serializable {

  public static final BooleanItem TRUE_VALUE = new BooleanItem("BooleanItem_True", true);
  public static final BooleanItem FALSE_VALUE = new BooleanItem("BooleanItem_False", false);
  public static final BooleanItem NULL_VALUE = new BooleanItem("BooleanItem_Null", null);

  public static final List<BooleanItem> REQUIRED_LIST = CollectionUtil.list(TRUE_VALUE, FALSE_VALUE);
  public static final List<BooleanItem> NON_REQUIRED_LIST = CollectionUtil.list(TRUE_VALUE, FALSE_VALUE, NULL_VALUE);

  public BooleanItem(String label, Boolean value) {
    this.label = label;
    this.value = value;
  }

  private String label;
  private Boolean value;

}