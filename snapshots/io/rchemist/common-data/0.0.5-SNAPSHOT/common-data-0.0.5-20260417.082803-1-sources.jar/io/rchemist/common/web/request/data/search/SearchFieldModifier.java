/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.web.request.data.FilterItem;
import org.springframework.core.Ordered;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SearchFieldModifier extends Ordered {

  /**
   * 검색 필터에 대한 변경이 필요한 경우 처리한다.
   * @param request
   * @return
   */
  default FilterItem transform(ModifyFilterRequest request){
    return request.getFilterItem();
  }

  default FilterItem validate(ModifyFilterRequest request){
    return request.getFilterItem();
  }

  /**
   * 사용 여부를 선택적으로 적용하려면 이 메소드를 구현하면 된다.
   * @return
   */
  default boolean isAvailable() {
    return true;
  }

}
