/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import io.rchemist.common.presentation.type.CollectionFieldAddType;
import io.rchemist.common.presentation.type.CollectionFieldOperationType;
import io.rchemist.common.presentation.type.CollectionFieldViewType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.SortDirectionType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface AdminCollectionField {

  /**
   * Collection field 의 표시 이름
   * @return
   */
  String name();

  /**
   * 이 Collection field 의 그룹 내 표시 순서
   * @return
   */
  int order();

  /**
   * SubCollection 을 ADD / UPDATE 할 때
   *
   * XREF -> 목록 선택
   * ENTITY_FORM -> 신규 생성
   *
   * @return
   */
  CollectionFieldAddType addType() default CollectionFieldAddType.XREF;

  /**
   * SubCollection 을 표시하는 방법
   * 게시판 댓글에서만 BOARD_COMMENT 를 사용하고 나머지는 모두 LIST_GRID 를 쓴다.
   * @return
   */
  CollectionFieldViewType viewType() default CollectionFieldViewType.LIST_GRID;

  /**
   * 폼에서 어떤 탭에 보여줄지
   * @return
   */
  ViewTab tab() default @ViewTab(order = 1);

  /**
   * 폼 > 탭에서 어떤 필드그룹에 보여줄지
   * @return
   */
  ViewFieldGroup group() default @ViewFieldGroup(order = 1);

  /**
   * 그리드 하단에 기본 노출하는 설명문구
   * @return
   */
  String helpText() default "";

  /**
   * Collection field 의 대상 클래스
   * @OneToMany 로 타입 추론이 가능하지만 엔티티가 확장된 경우 정확한 대상 엔티티를 지정할 때 사용함
   * @return
   */
  String targetEntity() default "";

  /**
   * Collection field 가 XREF 로 매핑된 경우 XREF 가 바라보는 실제 대상 엔티티
   * @return
   */
  String xrefTargetEntity() default "";

  /**
   * @OneToMany 에서 지정한 mappedBy 따로 지정하지 않으면 parent entity 를 이용해 추론한다.
   * @return
   */
  String mappedBy() default "";

  /**
   * Collection 을 grid 로 표시할 때 Collection entity 의 헤더 필드를 재정의할 수 있다.
   * 지정하지 않으면 대상 엔티티에 정의된 headerField 설정을 따른다.
   * 대상 엔티티에 @FieldView 설정이 되어 있지 않다면 자동으로 첫번째 필드를 headerFields 로 설정한다.
   *
   * @return
   */
  String[] headerFields() default {};

  /**
   * Collection values 를 정렬할 때 어떤 property 를 대상으로 할지
   * @return
   */
  String sortBy() default "id";

  /**
   * Collection values 를 정렬할 때 내림차순(DESC) 으로 할 지 오름차순(ASC)로 할 지
   * @return
   */
  SortDirectionType sortDirection() default SortDirectionType.DESC;

  /**
   * 이 Collection 이 map (key / value 형태) 의 데이터 인지
   * @return
   */
  boolean mapView() default false;

  /**
   * 이 Collection 이 map 인 경우 map 의 key property name
   * @return
   */
  String mapKey() default "name";

  /**
   * 숨김 처리 할 지 여부
   * @return
   */
  boolean hidden() default false;

  /**
   * 이 Collection 을 제어하는 방법
   * ALL - CRUD 모두 가능
   * ADD_ONLY - CR 만 가능
   * MODIFY_ONLY - RUD 만 가능
   * READ_ONLY - R 만 가능
   * @return
   */
  CollectionFieldOperationType operationType() default CollectionFieldOperationType.ALL;

  /**
   * (Optional) admin 서비스에서 Collection 을 제어할 때(CRUD) 추가 정보를 제공할 수 있다.
   * @return
   */
  AdditionalAttribute[] attributes() default {};

  /**
   * 컬렉션 필드의 하위 필드를 직접 지정할 수 있다.
   * targetEntity 가 설정되지 않았을 때 사용한다.
   * @return
   */
  AdminField[] fields() default {};

  /**
   * 인라인 콜렉션 필드를 표시할 때 세부 내용 보기 기능을 지원할 것인지 여부
   * @return
   */
  boolean showView() default false;

  /**
   * 이 엔티티를 EXPORT 할 수 있는지 설정
   * @return
   */
  DataTransfer exportable() default @DataTransfer();

  /**
   * 하위 필드의 metadata 를 탐색할 때 횟수 제한
   *
   * CollectionField 의 하위 필드가 부모 필드와 같은 경우 Metadata Analyze 를 수행하다 순환오류에 빠질 수 있다.
   * 이를 방지하기 위해 최대 몇회까지 순환할지 제한할 수 있다.
   * ex) CommentDTO 가 하위에 다시 List<CommentDTO> 를 가지고 있는 경우
   * 주의) 1보다 낮은 값은 무조건 1로 변경된다.
   *
   * @return
   */
  int metadataAnalyzeRestrictDepth() default 1;

  ModifiableType modifiableType() default ModifiableType.MODIFY_ONLY;

  OverrideMetadata[] overrideFieldMetadata() default {};

  boolean searchable() default true;

}
