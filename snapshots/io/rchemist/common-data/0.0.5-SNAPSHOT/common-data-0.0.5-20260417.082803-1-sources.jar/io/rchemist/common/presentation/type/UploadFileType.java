/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.i18n.service.MessageSourceHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum UploadFileType {
  EXCEL("error.message.field.asset.excel", MimeType.XLS, MimeType.XLSX),
  PPT("error.message.field.asset.ppt", MimeType.PPT, MimeType.PPTX),
  DOC("error.message.field.asset.doc", MimeType.DOC, MimeType.DOCX),
  CSV("error.message.field.asset.csv", MimeType.CSV),
  IMAGE("error.message.field.asset.image", MimeType.GIF, MimeType.PNG, MimeType.JPEG, MimeType.JPG, MimeType.ICO, MimeType.SVG, MimeType.TIF, MimeType.TIFF, MimeType.BMP, MimeType.WEBP),
  MS_OFFICE(true, "error.message.field.asset.office", EXCEL.getMimeTypes(), PPT.getMimeTypes(), DOC.getMimeTypes()),
  HTML("error.message.field.asset.html", MimeType.HTM, MimeType.HTML, MimeType.XHTML),
  JS("error.message.field.asset.js", MimeType.JS, MimeType.JSON),
  JSON("error.message.field.asset.json", MimeType.JSON),
  CSS("error.message.field.asset.css", MimeType.CSS),
  XML("error.message.field.asset.xml", MimeType.XML),
  WEB_FILE(true, "error.message.field.asset.web_file", HTML.getMimeTypes(), JS.getMimeTypes(), JSON.getMimeTypes(), CSS.getMimeTypes()),
  VIDEO("error.message.field.asset.video", MimeType.AVI, MimeType.IPHONE_INDEX, MimeType.IPHONE_SEGMENT, MimeType.MOV, MimeType.MPEG, MimeType.MPEG_4, MimeType.OGV, MimeType.WEBM, MimeType.WMV),
  AUDIO("error.message.field.asset.audio", MimeType.AAC, MimeType.AUDIO_3G2, MimeType.AUDIO_3GP, MimeType.MID, MimeType.MIDI, MimeType.OGA, MimeType.WAV, MimeType.WEBA),
  ARCHIVE("error.message.field.asset.archive", MimeType.ZIP, MimeType.RAR, MimeType.TAR, MimeType.ZIP7, MimeType.ARC)
  ,ALL(null);

  @Getter
  private MimeType[] mimeTypes;

  @Getter
  private String errorMessage;

  public String getTranslatedErrorMessage(){
    return MessageSourceHelper.getMessage(errorMessage);
  }

  public String[] getAcceptableApplicationTypes(){
    if(this.mimeTypes == null)
      return null;
    List<String> types = new ArrayList<>();
    for(MimeType mimeType : mimeTypes){
      types.add(mimeType.getApplicationType());
      types.add("."+mimeType.getSuffix());
    }
    return types.toArray(new String[0]);
  }

  UploadFileType(String errorMessage, MimeType... mimeTypes){
    this.errorMessage = errorMessage;
    this.mimeTypes = mimeTypes;
  }

  UploadFileType(boolean aggregate, String errorMessage, MimeType[]... applicationMimeTypes) {
    this.errorMessage = errorMessage;
    List<MimeType> types = new ArrayList<>();
    for(MimeType[] mimeTypes : applicationMimeTypes){
      types.addAll(Arrays.stream(mimeTypes).collect(Collectors.toList()));
    }
    this.mimeTypes = types.toArray(new MimeType[0]);
  }
}
