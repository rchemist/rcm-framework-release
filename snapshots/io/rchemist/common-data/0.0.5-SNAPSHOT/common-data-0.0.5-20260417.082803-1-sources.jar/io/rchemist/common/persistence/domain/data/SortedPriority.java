/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * project : rcm-framework
 * front 의 listGrid 에서 list 의 priority 를 변경하면 이 값을 전달한다.
 * 서버에서 이 값을 받아 각 row 의 id 로 entity 를 찾아 priority 를 변경한다.
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class SortedPriority<ID> implements Serializable {

  // id, priority
  private Map<ID, Integer> priorities = new LinkedHashMap<>();

  public SortedPriority<ID> withPriorities(Map<ID, Integer> priorities) {
    this.priorities = priorities;
    return this;
  }

  public boolean isEmpty() {
    return MapUtils.isEmpty(priorities);
  }

  public List<ID> getIds() {
    return isEmpty() ? new ArrayList<>() : new ArrayList<>(priorities.keySet());
  }

  public Integer getPriority(ID id) {
    return priorities.get(id);
  }

}
