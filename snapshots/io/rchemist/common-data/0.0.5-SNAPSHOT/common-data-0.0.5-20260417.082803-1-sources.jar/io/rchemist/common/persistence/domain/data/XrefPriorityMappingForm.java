/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class XrefPriorityMappingForm<ID_TYPE> implements Serializable {

  private List<PriorityMapping<ID_TYPE>> mapped;

  public boolean isEmpty() {
    return mapped == null || mapped.isEmpty();
  }

  public List<ID_TYPE> getMappedIds() {
    List<ID_TYPE> ids = new ArrayList<>();
    if (mapped != null) {
      for (PriorityMapping<ID_TYPE> preferMapping : mapped) {
        ids.add(preferMapping.getId());
      }
    }
    return ids;
  }

  public XrefPriorityMappingForm<ID_TYPE> withMapped(
      List<PriorityMapping<ID_TYPE>> mapped) {
    this.mapped = mapped;
    return this;
  }

  @SafeVarargs
  public final XrefPriorityMappingForm<ID_TYPE> addMapped(PriorityMapping<ID_TYPE>... mapped) {
    if (CollectionUtils.isEmpty(this.mapped)) {
      this.mapped = new ArrayList<>(List.of(mapped));
    } else {
      this.mapped.addAll(List.of(mapped));
    }
    return this;
  }

  public boolean hasMapped() {
    return CollectionUtils.isNotEmpty(mapped);
  }

  public XrefPriorityMappingForm<ID_TYPE> deepCopy() {

    if (CollectionUtils.isNotEmpty(mapped)) {
      List<PriorityMapping<ID_TYPE>> mappedCopy = mapped.stream()
          .map(PriorityMapping::deepCopy)
          .toList();
      return new XrefPriorityMappingForm<ID_TYPE>()
          .withMapped(mappedCopy);
    }

    return new XrefPriorityMappingForm<>();
  }

  @Getter
  @Setter
  public static class PriorityMapping<ID_TYPE> implements Serializable {

    private ID_TYPE id;
    private Integer priority;
    private Boolean required;

    public PriorityMapping<ID_TYPE> withId(ID_TYPE id) {
      this.id = id;
      return this;
    }

    public PriorityMapping<ID_TYPE> withPriority(Integer priority) {
      this.priority = priority;
      return this;
    }

    public PriorityMapping<ID_TYPE> withRequired(Boolean required) {
      this.required = required;
      return this;
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }

      if (object == null || getClass() != object.getClass()) {
        return false;
      }

      PriorityMapping<?> that = (PriorityMapping<?>) object;

      return new EqualsBuilder().append(id, that.id)
          .append(required, that.required)
          .append(priority, that.priority).isEquals();
    }

    @Override
    public int hashCode() {
      return new HashCodeBuilder(17, 37).append(id).append(priority).append(required).toHashCode();
    }

    public PriorityMapping<ID_TYPE> deepCopy() {
      return new PriorityMapping<ID_TYPE>()
          .withId(id)
          .withRequired(required)
          .withPriority(priority);
    }
  }
  
  
  
}
