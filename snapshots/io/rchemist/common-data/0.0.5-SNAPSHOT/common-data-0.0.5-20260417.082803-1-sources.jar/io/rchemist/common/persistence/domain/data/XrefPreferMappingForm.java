/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class XrefPreferMappingForm<ID_TYPE> implements Serializable {

  private List<PreferMapping<ID_TYPE>> mapped;

  public boolean isEmpty() {
    return mapped == null || mapped.isEmpty();
  }

  public List<ID_TYPE> getMappedIds() {
    List<ID_TYPE> ids = new ArrayList<>();
    if (mapped != null) {
      for (PreferMapping<ID_TYPE> preferMapping : mapped) {
        ids.add(preferMapping.getId());
      }
    }
    return ids;
  }

  public XrefPreferMappingForm<ID_TYPE> withMapped(
      List<PreferMapping<ID_TYPE>> mapped) {
    this.mapped = mapped;
    return this;
  }

  @SafeVarargs
  public final XrefPreferMappingForm<ID_TYPE> addMapped(PreferMapping<ID_TYPE>... mappings) {
    if (CollectionUtils.isEmpty(this.mapped)) {
      this.mapped = new ArrayList<>(List.of(mappings));
    } else {
      this.mapped.addAll(List.of(mappings));
    }
    return this;
  }

  // <editor-fold desc="validation">

  public boolean hasMapped() {
    return CollectionUtils.isNotEmpty(mapped);
  }

  public XrefPreferMappingForm<ID_TYPE> deepCopy() {

    if (CollectionUtils.isNotEmpty(mapped)) {
      List<PreferMapping<ID_TYPE>> mappedCopy = mapped.stream()
          .map(PreferMapping::deepCopy)
          .toList();
      return new XrefPreferMappingForm<ID_TYPE>()
          .withMapped(mappedCopy);
    }

    return new XrefPreferMappingForm<>();
  }

  @Getter
  @Setter
  public static class PreferMapping<ID_TYPE> implements Serializable {

    private ID_TYPE id;
    private Integer priority;
    private Boolean preferred;


    public PreferMapping<ID_TYPE> withId(ID_TYPE id) {
      this.id = id;
      return this;
    }

    public PreferMapping<ID_TYPE> withPriority(Integer priority) {
      this.priority = priority;
      return this;
    }

    public PreferMapping<ID_TYPE> withPreferred(Boolean preferred) {
      this.preferred = preferred;
      return this;
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }

      if (object == null || getClass() != object.getClass()) {
        return false;
      }

      PreferMapping<?> that = (PreferMapping<?>) object;

      return new EqualsBuilder().append(id, that.id)
          .append(preferred, that.preferred)
          .append(priority, that.priority).isEquals();
    }

    @Override
    public int hashCode() {
      return new HashCodeBuilder(17, 37).append(id).append(priority)
          .append(preferred).toHashCode();
    }

    public PreferMapping<ID_TYPE> deepCopy() {
      return new PreferMapping<ID_TYPE>()
          .withId(id)
          .withPreferred(preferred)
          .withPriority(priority);
    }
  }
  
  
  
}
