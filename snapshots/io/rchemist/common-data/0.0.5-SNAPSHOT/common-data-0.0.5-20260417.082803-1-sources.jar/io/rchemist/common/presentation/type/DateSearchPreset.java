/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.presentation.component.field.DateSearchRangeUnit;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum DateSearchPreset {

  DAY_1(new DateSearchRangeUnit(DateSearchUnitType.DAY, 1))
  , DAY_2(new DateSearchRangeUnit(DateSearchUnitType.DAY, 2))
  , DAY_3(new DateSearchRangeUnit(DateSearchUnitType.DAY, 3))
  , DAY_4(new DateSearchRangeUnit(DateSearchUnitType.DAY, 4))
  , DAY_5(new DateSearchRangeUnit(DateSearchUnitType.DAY, 5))
  , DAY_6(new DateSearchRangeUnit(DateSearchUnitType.DAY, 6))
  , DAY_7(new DateSearchRangeUnit(DateSearchUnitType.DAY, 7))
  , DAY_8(new DateSearchRangeUnit(DateSearchUnitType.DAY, 8))
  , DAY_9(new DateSearchRangeUnit(DateSearchUnitType.DAY, 9))
  , DAY_10(new DateSearchRangeUnit(DateSearchUnitType.DAY, 10))
  , DAY_11(new DateSearchRangeUnit(DateSearchUnitType.DAY, 11))
  , DAY_12(new DateSearchRangeUnit(DateSearchUnitType.DAY, 12))
  , DAY_13(new DateSearchRangeUnit(DateSearchUnitType.DAY, 13))
  , DAY_14(new DateSearchRangeUnit(DateSearchUnitType.DAY, 14))
  , DAY_15(new DateSearchRangeUnit(DateSearchUnitType.DAY, 15))
  , DAY_16(new DateSearchRangeUnit(DateSearchUnitType.DAY, 16))
  , DAY_17(new DateSearchRangeUnit(DateSearchUnitType.DAY, 17))
  , DAY_18(new DateSearchRangeUnit(DateSearchUnitType.DAY, 18))
  , DAY_19(new DateSearchRangeUnit(DateSearchUnitType.DAY, 19))
  , DAY_20(new DateSearchRangeUnit(DateSearchUnitType.DAY, 20))
  , WEEK_1(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 1))
  , WEEK_2(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 2))
  , WEEK_3(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 3))
  , WEEK_4(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 4))
  , WEEK_5(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 5))
  , WEEK_6(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 6))
  , WEEK_7(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 7))
  , WEEK_8(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 8))
  , WEEK_9(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 9))
  , WEEK_10(new DateSearchRangeUnit(DateSearchUnitType.WEEK, 10))
  , MONTH_1(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 1))
  , MONTH_2(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 2))
  , MONTH_3(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 3))
  , MONTH_4(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 4))
  , MONTH_5(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 5))
  , MONTH_6(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 6))
  , MONTH_7(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 7))
  , MONTH_8(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 8))
  , MONTH_9(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 9))
  , MONTH_10(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 10))
  , MONTH_11(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 11))
  , MONTH_12(new DateSearchRangeUnit(DateSearchUnitType.MONTH, 12))
  , YESTERDAY(new DateSearchRangeUnit(DateSearchUnitType.DAY, -1, "DateSearchRangeUnit_Yesterday"))
  ;


  DateSearchPreset(DateSearchRangeUnit unit) {
    this.unit = unit;
  }

  @Getter
  private final DateSearchRangeUnit unit;





}
