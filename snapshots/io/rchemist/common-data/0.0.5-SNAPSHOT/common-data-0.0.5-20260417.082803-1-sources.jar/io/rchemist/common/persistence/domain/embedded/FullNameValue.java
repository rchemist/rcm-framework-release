/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.embedded;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class FullNameValue implements IFullName{

  private String fullName;

  private String firstName;

  private String lastName;

  private String middleName;

  public FullNameValue withFullName(String fullName) {
    this.fullName = fullName;
    return this;
  }

  public FullNameValue withFirstName(String firstName) {
    this.firstName = firstName;
    return this;
  }

  public FullNameValue withLastName(String lastName) {
    this.lastName = lastName;
    return this;
  }

  public FullNameValue withMiddleName(String middleName) {
    this.middleName = middleName;
    return this;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    FullNameValue that = (FullNameValue) object;

    return new EqualsBuilder().append(fullName, that.fullName)
        .append(firstName, that.firstName).append(lastName, that.lastName)
        .append(middleName, that.middleName).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(fullName).append(firstName).append(lastName)
        .append(middleName).toHashCode();
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("fullName", fullName)
        .append("firstName", firstName)
        .append("lastName", lastName)
        .append("middleName", middleName)
        .toString();
  }
}
