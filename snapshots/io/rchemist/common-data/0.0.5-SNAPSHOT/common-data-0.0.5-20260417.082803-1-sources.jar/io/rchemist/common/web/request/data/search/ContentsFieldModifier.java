/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.web.request.data.FilterItem;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class ContentsFieldModifier implements SearchFieldModifier, SortFieldModifier {

  @Override
  public FilterItem transform(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    if (hasTitleFields(request.getEntityBean()) && filterItem.equalsName("title")) {
      if (filterItem.hasSubFilters()) {
        // subFilter 가 존재한다면 skipping
      } else {

        Object searchValue = filterItem.getValue();

        return FilterItem
            .or(
                new FilterItem().withQueryConditionType(filterItem.getQueryConditionType()).withName("title").withValue(searchValue),
                new FilterItem().withQueryConditionType(filterItem.getQueryConditionType()).withName("titleConsonant").withValue(searchValue),
                new FilterItem().withQueryConditionType(filterItem.getQueryConditionType()).withName("titlePhoneme").withValue(searchValue)
            );
      }
    } else if (hasContentsFields(request.getEntityBean()) && filterItem.equalsName("content") && !request.isHibernateSearch()) {
      filterItem.setName("searchableContent");
    }

    return filterItem;
  }

  // Contents title 필드가 맞는 경우
  private boolean hasTitleFields(EntityBean<?> entityBean) {
    return (entityBean.getClassMappingProperties().containsKey("title")
        && entityBean.getClassMappingProperties().containsKey("titleConsonant")
        && entityBean.getClassMappingProperties().containsKey("titlePhoneme")
    );
  }

  private boolean hasContentsFields(EntityBean<?> entityBean) {
    return (entityBean.getClassMappingProperties().containsKey("content")
        && entityBean.getClassMappingProperties().containsKey("searchableContent")
    );
  }

  @Override
  public int getOrder() {
    return 200;
  }
}
