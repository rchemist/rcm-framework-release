/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class PaymentProcessType extends EnumType<PaymentProcessType> {

  public static final PaymentProcessType ADD = new PaymentProcessType(1, "ADD", "Add", "적립", "add");
  public static final PaymentProcessType SUBTRACT = new PaymentProcessType(100, "SUBTRACT", "Subtract", "차감", "subtract");

  public PaymentProcessType(int order, String type, String friendlyType, String description,
      String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }

  private PaymentProcessType() {
  }
}
