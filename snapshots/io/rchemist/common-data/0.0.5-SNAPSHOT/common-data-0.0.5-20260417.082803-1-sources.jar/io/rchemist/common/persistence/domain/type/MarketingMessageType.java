/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class MarketingMessageType extends EnumType<MarketingMessageType> {

  public static final MarketingMessageType EMAIL = new MarketingMessageType(100, "EMAIL", "Email", "이메일", "email");
  public static final MarketingMessageType PHONE = new MarketingMessageType(200, "PHONE", "Phone", "전화", "phone");
  public static final MarketingMessageType SMS = new MarketingMessageType(300, "SMS", "Sms", "문자(SMS)", "sms");
  public static final MarketingMessageType POST = new MarketingMessageType(400, "POST", "Post", "우편", "post");
  public static final MarketingMessageType APP_PUSH = new MarketingMessageType(500, "APP_PUSH", "App push", "앱 푸시", "app.push");

  @Override
  protected String getPrefix() {
    return "global.type.receive.marketing.message.type.";
  }

  public MarketingMessageType(int order, String type, String friendlyType,
      String description,
      String messageKey) {
    super(order, type, friendlyType, description, messageKey);
  }
}
