/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.dto;

import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@NoArgsConstructor
public class SearchCondition implements Serializable {

  protected Set<SearchField> searchFields;			// 검색어, 검색 대상, 검색 조건

  protected Map<Integer, SortField> sortFields; 		// 정렬 대상, 정렬 조건(asc, desc)

  public boolean hasSearchFields(){
    return CollectionUtils.isNotEmpty(searchFields);
  }

  public boolean hasSortFields(){
    return MapUtils.isNotEmpty(sortFields);
  }

  public SearchCondition addSearchField(SearchField searchField){
    if(searchFields == null)
      searchFields = new HashSet<>();

    Iterator<SearchField> iterators = searchFields.iterator();
    while(iterators.hasNext()){
      SearchField sf = iterators.next();
      if(sf.getName().equals(searchField.getName())){
        // remove old search field
        iterators.remove();
      }
    }

    searchFields.add(searchField);
    return this;
  }

  public SearchCondition addSortField(SortField sortField){
    if(sortFields == null)
      sortFields = new HashMap<>();
    sortFields.put(sortField.getOrder(), sortField);
    return this;
  }

  public SearchCondition(Map<String, String[]> requestParameterMap) {
    if(MapUtils.isNotEmpty(requestParameterMap)) {
      RequestData requestData = new RequestData(requestParameterMap);
      setSearchData(requestData);
      setSortData(requestData);
    }
  }

  private void setSortData(RequestData requestData) {
    if(ArrayUtil.isSameLength(requestData.getSortField(), requestData.getSortType())){
      Map<Integer, SortField> sortFields = new HashMap<>();
      int idx = 0;
      for(String name : requestData.getSortField()){
        SortField sf = SortField.builder()
            .name(name)
            .type(requestData.getSortType()[idx])
            .order(idx)
            .build();
        sortFields.put(idx, sf);
        idx++;
      }
      setSortFields(sortFields);
    }
  }

  private void setSearchData(RequestData requestData) {
    if(ArrayUtil.isSameLength(requestData.getSearch(), requestData.getFind(), requestData.getCondition())){
      Set<SearchField> searchFields = new HashSet<>();
      int i = 0;
      for(String name : requestData.getSearch()){

        String value = StringUtil.toString(requestData.getFind()[i]);
        String[] values;

        if(StringUtils.contains(value, SearchField.VALUE_SEPARATOR)){
          values = StringUtils.split(value, SearchField.VALUE_SEPARATOR);
        }else{
          values = new String[]{value};
        }

        QueryConditionType conditionType = QueryConditionType.getInstance(requestData.getCondition()[i]);

        SearchField sf = new SearchField(name, conditionType, values);

        searchFields.add(sf);
        i++;
      }
      setSearchFields(searchFields);
    }
  }

  @Getter
  @Setter
  public class RequestData {
    String[] search = new String[]{};
    String[] find = new String[]{};
    String[] condition = new String[]{};
    String[] sortField = new String[]{};
    String[] sortType = new String[]{};

    public RequestData(Map<String, String[]> requestParameterMap){
      for(Map.Entry<String, String[]> entry : requestParameterMap.entrySet()){
        String key = entry.getKey();
        String[] values = entry.getValue();

        if(ArrayUtils.isNotEmpty(values)){
          if(StringUtils.startsWith(key, SearchField.FIELD_PREFIX)) 			this.search = values;
          if(StringUtils.startsWith(key, SearchField.VALUE_PREFIX)) 			this.find = values;
          if(StringUtils.startsWith(key, SearchField.CONDITION_PREFIX)) 		this.condition = values;
          if(StringUtils.startsWith(key, SortField.FIELD_PREFIX)) 			this.sortField = values;
          if(StringUtils.startsWith(key, SortField.TYPE_PREFIX)) 				this.sortType = values;
        }
      }
    }


  }

}
