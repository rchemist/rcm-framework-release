/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.DerivedVisibleValue;
import io.rchemist.common.presentation.annotation.Enumeration;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.type.LimitTimePeriodType;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasRewardCondition.class)
@Getter
@Setter
public class HasRewardConditionImpl implements EnhancedTemplate {

  @AdminField(name = "RewardCondition_LimitTimePeriodType", order = 10000, group = @ViewFieldGroup(type = GroupEnumType.REWARD_CONDITION)
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , enumeration = @Enumeration(enumType = "io.rchemist.common.util.type.LimitTimePeriodType")
      , fieldType = PresentationFieldType.ENUMERATION
      , helpText = "RewardCondition_LimitTimePeriodType_HelpText"
      , derivedVisible = {
      @DerivedVisibleValue(value = "SPECIFIC_DAYS", derivedPropertyName = {"specificLimitDate"})
      , @DerivedVisibleValue(value = {"DAYS", "MONTHS", "YEARS", "HOURS"}, derivedPropertyName = {"limitDifference"})
      , @DerivedVisibleValue(value = {"THIS_YEAR", "THIS_MONTH"}, derivedPropertyName = {"resetPeriodically"})
  }
  )
  protected LimitTimePeriodType limitTimePeriodType;

  @AdminField(name = "RewardCondition_LimitDifference", order = 10100
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.REWARD_CONDITION)
      , helpText = "RewardCondition_LimitDifference_HelpText"
      , fieldType = PresentationFieldType.INTEGER
      , minLength = "1"
      , dependentVisible = true)
  protected Integer limitDifference;

  @AdminField(name = "RewardCondition_SpecificLimitDate", order = 10200
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.REWARD_CONDITION)
      , helpText = "RewardCondition_SpecificLimitDate_HelpText"
      , fieldType = PresentationFieldType.DATETIME
      , dependentVisible = true
  )
  protected LocalDateTime specificLimitDate;

  @AdminField(name = "RewardCondition_Repeatable"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , helpText = "RewardCondition_Repeatable_HelpText", order = 10300, group = @ViewFieldGroup(type = GroupEnumType.REWARD_CONDITION)
      , fieldType = PresentationFieldType.BOOLEAN, defaultValue = "false", required = true)
  protected Boolean repeatable = false;

  @AdminField(name = "RewardCondition_ResetPeriodically"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , helpText = "RewardCondition_ResetPeriodically_HelpText", order = 10400, group = @ViewFieldGroup(type = GroupEnumType.REWARD_CONDITION)
      , fieldType = PresentationFieldType.BOOLEAN, defaultValue = "true")
  protected Boolean resetPeriodically = true;

  /**
   * 오늘 날짜를 이용해 설정된 제한 기간 내에 있는지
   * @return
   */
  public LocalDateTime getLimitedAvailableUntil(){
    return getLimitedAvailableUntil(LocalDateTime.now());
  }

  /**
   * 지정한 날짜에 설정된 날짜 제한을 더한 날짜. reward 종료일이 된다.
   * @return
   */
  public LocalDateTime getLimitedAvailableUntil(LocalDateTime availableAt){

    // 시간 제약이 없다면 null 반환
    if(!isTimeLimited())
      return null;

    LimitTimePeriodType type = getLimitTimePeriodType();

    if(type.equals(LimitTimePeriodType.SPECIFIC_DAYS)){
      return type.getAvailableUntil(getSpecificLimitDate(), null);
    }

    Long difference = NumberUtil.getLong(limitDifference, null);
    return type.getAvailableUntil(availableAt, difference);

  }

  /**
   * repeatable 이 false 이고, resetPeriodically 가 true 라면 반복 횟수를 집계하기 위한 기간의 시작일
   *
   * rewardQueue 의 기록을 뒤져 해당 고객이 시작일 ~ 현재 시각 사이에 보상 받은 기록이 없으면 보상이 가능하다는 뜻이 된다.
   *
   * @return
   */
  public LocalDateTime getPreviousPeriodStartedAt(){
    LimitTimePeriodType type = getLimitTimePeriodType();

    if(getRepeatable())   // 반복이 true 면 최근 집계일을 구할 필요가 없다.
      return null;

    if(!getResetPeriodically() || !isTimeLimited() || (type != null && type.equals(LimitTimePeriodType.SPECIFIC_DAYS)))   // 주기적 반복이 아니라면 시스템 최초 일시로 - 이 값을 받는 쪽에서 LocalDateTime.MIN 에 대한 조건 처리를 해야 한다.
      return LocalDateTime.MIN;

    Long difference = NumberUtil.getLong(limitDifference, null);
    return type.getPreviousPeriodStartedAt(difference);
  }

  public boolean isTimeLimited() {
    return getLimitTimePeriodType() != null && !getLimitTimePeriodType().equals(
        LimitTimePeriodType.UNLIMITED);
  }


  public Boolean getRepeatable() {
    return BooleanUtils.toBooleanDefaultIfNull(repeatable, false);
  }

  public Boolean getResetPeriodically() {
    return BooleanUtils.toBooleanDefaultIfNull(resetPeriodically, true);
  }

}
