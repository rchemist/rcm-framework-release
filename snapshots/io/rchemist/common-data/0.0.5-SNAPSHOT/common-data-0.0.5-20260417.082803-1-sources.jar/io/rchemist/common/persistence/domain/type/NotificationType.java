/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationType extends EnumType<NotificationType> {

  public static final NotificationType EMAIL = new NotificationType(10, "EMAIL", "이메일", "email", true, false);
  public static final NotificationType SMS = new NotificationType(20, "SMS", "문자메시지", "sms", true, true);
  public static final NotificationType KAKAO = new NotificationType(30, "KAKAO", "카카오톡", "kakao", false, true, true);
  public static final NotificationType PUSH = new NotificationType(40, "PUSH", "푸시", "push", true, false);
  public static final NotificationType SLACK = new NotificationType(50, "SLACK", "슬랙", "slack", true, false);
  public static final NotificationType INTERNAL = new NotificationType(60, "INTERNAL", "내부 메시지 서비스", "internal", true, false);
  public static final NotificationType ETC = new NotificationType(100, "ETC", "기타", "etc", true, false);

  @Getter
  private final boolean shouldParseTemplate;

  @Getter
  private final boolean messageKeyRequired;

  @Getter
  private final boolean usePhoneNumber;

  public NotificationType(int order, String type, String description, String messageKey, boolean shouldParseTemplate, boolean usePhoneNumber) {
    super(order, type, type, description, messageKey);
    this.shouldParseTemplate = shouldParseTemplate;
    this.messageKeyRequired = false;
    this.usePhoneNumber = usePhoneNumber;
  }

  public NotificationType(int order, String type, String description, String messageKey, boolean shouldParseTemplate, boolean messageKeyRequired, boolean usePhoneNumber) {
    super(order, type, type, description, messageKey);
    this.shouldParseTemplate = shouldParseTemplate;
    this.messageKeyRequired = messageKeyRequired;
    this.usePhoneNumber = usePhoneNumber;
  }

  private NotificationType(){
    this.shouldParseTemplate = false;
    this.messageKeyRequired = false;
    this.usePhoneNumber = false;
  }

}
