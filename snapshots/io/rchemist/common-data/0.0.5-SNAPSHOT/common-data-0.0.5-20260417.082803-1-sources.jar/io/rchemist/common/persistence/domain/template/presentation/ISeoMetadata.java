/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ISeoMetadata<T> {

  String getMetaHeader();
  void setMetaHeader(String metaHeader);

  // varchar(255)
  String getMetaTitle();
  void setMetaTitle(String metaTitle);

  // varchar(4000)
  String getMetaDescription();
  void setMetaDescription(String metaDescription);
  
  T withMetaHeader(String metaHeader);
  
  T withMetaTitle(String metaTitle);
  
  T withMetaDescription(String metaDescription);

  T withSeoMetadata(ISeoMetadata<?> seoMetadata);

}
