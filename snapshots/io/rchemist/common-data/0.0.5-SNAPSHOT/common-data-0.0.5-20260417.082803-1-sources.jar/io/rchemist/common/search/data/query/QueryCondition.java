/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.web.request.data.FilterItem;
import jakarta.persistence.criteria.JoinType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class QueryCondition implements Serializable {

  private Map<String, List<SingleConditionItem>> singleConditionItems = new LinkedHashMap<>();
  private List<CombinedConditionItem> combinedConditionItems = new ArrayList<>();

  public QueryCondition(){

  }

  public QueryCondition addQueryItems(List<QueryConditionItem> items){
    if(CollectionUtils.isNotEmpty(items)){
      return addQueryItems(items.toArray(new QueryConditionItem[0]));
    }

    return this;
  }

  public QueryCondition addQueryItems(QueryConditionItem... items){
    if(items != null && ArrayUtils.isNotEmpty(items)){

      // 병합이 필요하다면 병합한다.
      for(QueryConditionItem queryConditionItem : items){

        if(queryConditionItem instanceof CombinedConditionItem){
          this.combinedConditionItems.add((CombinedConditionItem) queryConditionItem);
          continue;
        }

        SingleConditionItem item = (SingleConditionItem) queryConditionItem;

        if(MapUtils.isEmpty(singleConditionItems)){
          singleConditionItems.put(item.getPropertyName(), CollectionUtil.list(item));
        }else{

          if(singleConditionItems.containsKey(item.getPropertyName())){
            List<SingleConditionItem> specList = singleConditionItems.get(item.getPropertyName());
            if(!specList.contains(item)){
              SingleConditionItem merged = null;
              SingleConditionItem removed = null;

              for(SingleConditionItem s : specList){

                // 하나로 합쳐질 수 있는 경우에는 합치고 merged 와 removed 를 셋팅한다.

                if(s.getConditionType().isMergeable() && item.getConditionType().isMergeable()){

                  QueryConditionType conditionType = s.getConditionType();
                  QueryConditionType compareType = item.getConditionType();

                  // s 의 조건이 equals 이거나 not_equals 인 경우

                  CHECK_MERGE:
                  switch (conditionType) {
                    case IN:
                    case EQUAL_IGNORECASE:
                    case EQUAL: {
                      switch (compareType) {
                        case EQUAL_IGNORECASE:
                        case EQUAL: {
                          List values = (conditionType.equals(QueryConditionType.IN)) ?
                              (List) s.getValue() : CollectionUtil.list(s.getValue());
                          if (CollectionUtils.isEmpty(values)) {
                            values.add(item.getValue());
                          } else {
                            if (!values.contains(item.getValue())) {
                              values.add(item.getValue());
                            }
                          }

                          merged = new SingleConditionItem(s.getPropertyName(), QueryConditionType.IN, values);
                          removed = s;
                          break CHECK_MERGE;
                        }
                        case IN: {
                          List values = (List) item.getValue();
                          values.add(s.getValue());
                          merged = new SingleConditionItem(s.getPropertyName(), QueryConditionType.IN, values);
                          removed = s;
                          break CHECK_MERGE;
                        }
                        default: {
                          break CHECK_MERGE;
                        }
                      }

                    }
                    case NOT_IN:
                    case NOT_EQUAL: {

                      switch (compareType) {
                        case NOT_EQUAL: {
                          List values = (conditionType.equals(QueryConditionType.NOT_IN)) ?
                              (List) s.getValue() : CollectionUtil.list(s.getValue());
                          values.add(item.getValue());
                          merged = new SingleConditionItem(s.getPropertyName(), QueryConditionType.NOT_IN,
                              values);
                          removed = s;
                          break CHECK_MERGE;
                        }
                        case NOT_IN: {
                          List values = (List) item.getValue();
                          values.add(s.getValue());
                          merged = new SingleConditionItem(s.getPropertyName(), QueryConditionType.NOT_IN,
                              values);
                          removed = s;
                          break CHECK_MERGE;
                        }
                        default: {
                          break CHECK_MERGE;
                        }
                      }

                    }
                  }
                }
              }

              if(merged == null){
                specList.add(item);
              }else{
                specList.remove(removed);
                specList.add(merged);
              }
              singleConditionItems.put(item.getPropertyName(), specList);
            }
          }else{
            singleConditionItems.put(item.getPropertyName(), CollectionUtil.list(item));
          }

        }

      }
    }
    return this;
  }

  public QueryCondition addConditions(FilterItem... filterItem) {
    if (filterItem != null && ArrayUtils.isNotEmpty(filterItem)) {
      for (FilterItem item : filterItem) {
        if (!item.isOnlySubFilters()) {
          QueryConditionType conditionType = item.getQueryConditionType();
          QueryConditionItem queryConditionItem = new SingleConditionItem(item.getName(), conditionType, item.getValue())
              .withJoinType(item.getJoinType())
              .withJsonFilter(item.isJsonFilter());
          queryConditionItem.setApplyOnClause(item.isApplyOnClause());
          addQueryItems(queryConditionItem);
        }

        if (item.hasSubFilters()) {
          // sub filter 가 있는 item 의 경우는 서브 조건에 대해 처리해야 한다.
          for (Map.Entry<ConditionOperatorType, FilterItem[]> entry : item.getSubFilters().entrySet()) {
            ConditionOperatorType operator = entry.getKey();
            List<QueryConditionItem> subItems = new ArrayList<>();
            FilterItem[] subFilters = entry.getValue();
            for (FilterItem subFilter : subFilters) {
              QueryConditionType subConditionType = subFilter.getQueryConditionType();
              QueryConditionItem subQueryItem = new SingleConditionItem(subFilter.getName(), subConditionType, subFilter.getValue())
                  .withJoinType(subFilter.getJoinType())
                  .withJsonFilter(subFilter.isJsonFilter());
              subQueryItem.setApplyOnClause(subFilter.isApplyOnClause());
              subItems.add(subQueryItem);
            }

            CombinedConditionItem combinedItem = new CombinedConditionItem(operator, subItems.toArray(new QueryConditionItem[0]));
            addCombinedConditionItem(combinedItem);

          }

        }
      }
    }
    return this;
  }

  public QueryCondition addConditions(QueryConditionType conditionType, String propertyName, Object value){
    QueryConditionItem queryConditionItem = new SingleConditionItem(propertyName, conditionType, value);
    return addQueryItems(queryConditionItem);
  }

  public QueryCondition addConditions(JoinType joinType, QueryConditionType conditionType, String propertyName, Object value) {
    QueryConditionItem queryConditionItem = new SingleConditionItem(propertyName, conditionType, value).withJoinType(joinType);
    return addQueryItems(queryConditionItem);
  }

  public boolean isEmpty() {
    return CollectionUtils.isEmpty(combinedConditionItems) && MapUtils.isEmpty(singleConditionItems);
  }

  public QueryCondition merge(QueryCondition queryCondition) {

    if(queryCondition == null || (queryCondition.isEmpty()))
      return this;

    if(isEmpty())
      return queryCondition;


    List<QueryConditionItem> items = queryCondition.getAllQueryConditionItems();
    addQueryItems(items);

    return this;
  }

  public QueryCondition addCombinedConditionItem(CombinedConditionItem... combinedConditionItems){
    if (combinedConditionItems != null) {
      for (CombinedConditionItem combinedConditionItem : combinedConditionItems) {
        this.combinedConditionItems.add(combinedConditionItem);
      }
    }
    return this;
  }


  public List<QueryConditionItem> getAllQueryConditionItems(){
    List<QueryConditionItem> list = new ArrayList<>();

    if(MapUtils.isNotEmpty(singleConditionItems)){
      singleConditionItems.values().forEach(
          v -> list.addAll(v)
      );
    }

    if(CollectionUtils.isNotEmpty(combinedConditionItems)){
      list.addAll(combinedConditionItems);
    }

    return list;
  }


}
