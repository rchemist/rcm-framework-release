/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdditionalAttribute;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.ValidationConfig;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasRestrictCount.class)
@Getter
@Setter
public class HasRestrictCountImpl implements EnhancedTemplate {

  @AdminField(name = "RestrictCount_MaxCount", helpText = "RestrictCount_MaxCount_HelpText"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.RESTRICTION), order = 100
      , fieldType = PresentationFieldType.INTEGER)
  protected Integer maxCount;

  @AdminField(name = "RestrictCount_MaxCountPerDay", helpText = "RestrictCount_MaxCountPerDay_HelpText"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.RESTRICTION), order = 200
      , fieldType = PresentationFieldType.INTEGER
      , validation = {@ValidationConfig(provider = "rcmCompareNumberValidator", attributes = {@AdditionalAttribute(key = "MAX_VALUE", value = "maxCount"), @AdditionalAttribute(key = "MAX_VALUE_IS_PROPERTY", value = "true")})}
  )
  protected Integer maxCountPerDay;

  @AdminField(name = "RestrictCount_MaxCountPerCustomer", helpText = "RestrictCount_MaxCountPerCustomer_HelpText"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.RESTRICTION), order = 300
      , fieldType = PresentationFieldType.INTEGER
      , validation = {
          @ValidationConfig(provider = "rcmCompareNumberValidator"
              , attributes = {
              @AdditionalAttribute(key = "MIN_VALUE", value = "maxCountPerCustomerPerDay"), @AdditionalAttribute(key = "MIN_VALUE_IS_PROPERTY", value = "true")
              , @AdditionalAttribute(key = "MAX_VALUE", value = "maxCount"), @AdditionalAttribute(key = "MAX_VALUE_IS_PROPERTY", value = "true")

          }
          )}
  )
  protected Integer maxCountPerCustomer;

  @AdminField(name = "RestrictCount_MaxCountPerCustomerPerDay", helpText = "RestrictCount_MaxCountPerCustomerPerDay_HelpText"
      , createForm = @CreateForm(type = CreateFormType.RESTRICTION)
      , group = @ViewFieldGroup(type = GroupEnumType.RESTRICTION), order = 400
      , fieldType = PresentationFieldType.INTEGER
      , validation = {@ValidationConfig(provider = "rcmCompareNumberValidator", attributes = {@AdditionalAttribute(key = "MAX_VALUE", value = "maxCountPerCustomer"), @AdditionalAttribute(key = "MAX_VALUE_IS_PROPERTY", value = "true")})}
  )
  protected Integer maxCountPerCustomerPerDay;

  public void setMaxCountPerDay(Integer maxCountPerDay) {
    if(maxCountPerDay != null){
      if(maxCount != null && maxCount < maxCountPerDay){
        maxCountPerDay = maxCount;
      }
    }
    this.maxCountPerDay = maxCountPerDay;
  }

  public void setMaxCountPerCustomer(Integer maxCountPerCustomer) {
    if(maxCountPerCustomer != null){
      if(maxCount != null && maxCount < maxCountPerCustomer){
        maxCountPerCustomer = maxCount;
      }
    }

    this.maxCountPerCustomer = maxCountPerCustomer;
  }

  public void setMaxCountPerCustomerPerDay(Integer maxCountPerCustomerPerDay) {
    if(maxCountPerCustomerPerDay != null){
      if(maxCount != null && maxCount < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCount;
      }
      if(maxCountPerDay != null && maxCountPerDay < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCountPerDay;
      }
    }
    this.maxCountPerCustomerPerDay = maxCountPerCustomerPerDay;
  }

  public Integer getMaxCountPerDay() {
    if(maxCountPerDay != null){
      if(maxCount != null && maxCount < maxCountPerDay){
        maxCountPerDay = maxCount;
      }
    }
    return maxCountPerDay;
  }

  public Integer getMaxCountPerCustomer() {
    if(maxCountPerCustomer != null){
      if(maxCount != null && maxCount < maxCountPerCustomer){
        maxCountPerCustomer = maxCount;
      }
    }
    return maxCountPerCustomer;
  }

  public Integer getMaxCountPerCustomerPerDay() {
    if(maxCountPerCustomerPerDay != null){
      if(maxCount != null && maxCount < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCount;
      }
      if(maxCountPerDay != null && maxCountPerDay < maxCountPerCustomerPerDay){
        maxCountPerCustomerPerDay = maxCountPerDay;
      }
    }
    return maxCountPerCustomerPerDay;
  }
}
