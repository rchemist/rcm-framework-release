/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.transformer.dto.EntityBean;
import io.rchemist.common.web.request.data.FilterItem;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.request.data.sort.SortInfo;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class EmbeddedNameFieldModifier implements SearchFieldModifier, SortFieldModifier {

  @Override
  public FilterItem transform(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    if (hasEmbeddedNameField(request.getEntityBean())) {
      String filterName = filterItem.getName();

      switch (filterName) {
        case "firstName":
          filterItem.setName("name.firstName");
          break;
        case "middleName":
          filterItem.setName("name.middleName");
          break;
        case "lastName":
          filterItem.setName("name.lastName");
          break;
        case "fullName", "name":
          filterItem.setName("name.fullName");
          break;
        default:
          return filterItem;
      }
    }

    return filterItem;
  }

  // name 이 embedded field 로 존재하는 경우
  private boolean hasEmbeddedNameField(EntityBean<?> entityBean) {
    return (entityBean.getClassMappingProperties().containsKey("name.firstName")
        && entityBean.getClassMappingProperties().containsKey("name.middleName")
        && entityBean.getClassMappingProperties().containsKey("name.lastName")
        && entityBean.getClassMappingProperties().containsKey("name.fullName")
    );
  }

  @Override
  public ModifySortRequest modifySorts(ModifySortRequest request) {

    if (hasEmbeddedNameField(request.getEntityBean())) {
      // name 이 embedded field 로 존재하는 경우
      List<SortEntry> sortEntries = request.getSortEntries();
      if (sortEntries == null || sortEntries.isEmpty()) {
        return request;
      }

      List<SortEntry> newSortEntries = new ArrayList<>();
      for (SortEntry entry : sortEntries) {
        String fieldName = entry.getFieldName();
        switch (fieldName) {
          case "name":
          case "fullName":
            newSortEntries.add(new SortEntry("name.fullName", entry.getSortInfo()));
            break;
          case "firstName":
            newSortEntries.add(new SortEntry("name.firstName", entry.getSortInfo()));
            break;
          case "lastName":
            newSortEntries.add(new SortEntry("name.lastName", entry.getSortInfo()));
            break;
          case "middleName":
            newSortEntries.add(new SortEntry("name.middleName", entry.getSortInfo()));
            break;
          default:
            newSortEntries.add(entry);
        }
      }

      request.withSortEntries(newSortEntries);
    }

    return request;
  }

  @Override
  public int getOrder() {
    return 100;
  }
}
