/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache;

import io.rchemist.common.util.StringUtil;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;
import javax.cache.CacheException;
import javax.cache.CacheManager;
import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

/**
 *
 * Spring cache 와 jcache 를 통합한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmCacheManager")
@Slf4j
public class JCacheManagerFactoryBean implements FactoryBean<CacheManager>, BeanClassLoaderAware, InitializingBean, DisposableBean, ApplicationContextAware {

  protected final Environment environment;

  protected final RedisConnectionFactory redisConnectionFactory;

  private Properties cacheManagerProperties;

  private ClassLoader beanClassLoader;

  private CacheManager cacheManager;

  private ApplicationContext applicationContext;

  public JCacheManagerFactoryBean(Environment environment,
      RedisConnectionFactory redisConnectionFactory) {
    this.environment = environment;
    this.redisConnectionFactory = redisConnectionFactory;
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

  @Override
  public void afterPropertiesSet() {
    if (getObject() != null && !getObject().isClosed()) {
      return;
    }

    // spring.jpa.properties.hibernate.cache.redisson.config
    String redissonConfigUri = getConfigUri();
    try {
      URI configUri = getClass().getClassLoader().getResource(redissonConfigUri).toURI();

      Caching.setDefaultClassLoader(getDefaultClassLoaderForProvider());
      CachingProvider provider = Caching.getCachingProvider();

      this.cacheManager = provider.getCacheManager(configUri, getDefaultClassLoaderForProvider());

    } catch (URISyntaxException | CacheException e) {
      log.error("Failed to initialize Redisson CacheManager", e);
    }

  }

  private String getConfigUri() {
    String value =
        StringUtil.toString(
        environment.getProperty("spring.datasource.rcm-common.hibernate.cache.redisson.config")
            , environment.getProperty("spring.jpa.properties.hibernate.cache.redisson.config"));
    if(StringUtils.isEmpty(value)){
      value = StringUtil.toString(environment.getProperty("hibernate.cache.redisson.config"), "redisson.yml");
    }

    return value;
  }

  @Override
  public CacheManager getObject() {
    return this.cacheManager;
  }

  @Override
  public Class<?> getObjectType() {
    return (this.cacheManager != null ? this.cacheManager.getClass() : CacheManager.class);
  }

  @Override
  public boolean isSingleton() {
    return true;
  }

  @Override
  public void destroy() {
    if (this.cacheManager != null) {
      this.cacheManager.close();
    }
  }

  @Override
  public void setBeanClassLoader(ClassLoader classLoader) {
    this.beanClassLoader = classLoader;
  }

  public void setCacheManagerProperties(@Nullable Properties cacheManagerProperties) {
    this.cacheManagerProperties = cacheManagerProperties;
  }

  protected ClassLoader getDefaultClassLoaderForProvider() {
    if (beanClassLoader != null) {
      return beanClassLoader;
    }
    return getClass().getClassLoader();
  }

}
