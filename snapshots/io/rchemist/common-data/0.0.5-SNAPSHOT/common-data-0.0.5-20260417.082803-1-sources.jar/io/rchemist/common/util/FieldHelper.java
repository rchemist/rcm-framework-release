/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.util;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.i18n.service.MessageSourceHelper;
import io.rchemist.common.money.Money;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.presentation.component.field.BooleanItem;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public abstract class FieldHelper {

  public static String getStringValue(Object value){
    return getStringValue(value, false);
  }

  public static String getStringValue(Object value, boolean showList) {
    if(value == null)
      return "";

    Class<?> clazz = value.getClass();
    String strValue;


    if(String.class.isAssignableFrom(clazz)){
      strValue = (String) value;
    }else if(Date.class.isAssignableFrom(clazz)){
      strValue = LocalDateTimeUtil.format(LocalDateTimeUtil.asLocalDateTime((Date) value));
    }else if(LocalDateTime.class.isAssignableFrom(clazz)){
      strValue = LocalDateTimeUtil.format((LocalDateTime) value);
      /*if(showList){
        //strValue = LocalDateTimeUtil.format((LocalDateTime) value, FormatUtil.LOCAL_DATE_ISO);
        strValue = LocalDateTimeUtil.format((LocalDateTime) value);
      }else{
        strValue = LocalDateTimeUtil.format((LocalDateTime) value);
      }*/
    }else if(LocalDate.class.isAssignableFrom(clazz)){
      strValue = LocalDateUtil.format((LocalDate) value);
    }else if(Boolean.class.isAssignableFrom(clazz) || boolean.class.isAssignableFrom(clazz)){

      if(showList){
        if(BooleanUtils.toBoolean((Boolean) value)){
          strValue = MessageSourceHelper.getMessage(BooleanItem.TRUE_VALUE.getLabel());
        }else{
          if(value == null){
            strValue = "";
          }else{
            strValue = MessageSourceHelper.getMessage(BooleanItem.FALSE_VALUE.getLabel());
          }
        }
      }else{
        strValue = BooleanUtils.toStringTrueFalse((Boolean) value);
      }
    }else if(Integer.class.isAssignableFrom(clazz) || int.class.isAssignableFrom(clazz)){
      strValue = String.valueOf(value);
    }else if(BigDecimal.class.isAssignableFrom(clazz)){
      if(showList){
        strValue = String.valueOf(((BigDecimal) value).intValue());
      }else{
        strValue = value.toString();
      }

    }else if(Money.class.isAssignableFrom(clazz)){
      strValue = ((Money) value).toString();
    }else if(Double.class.isAssignableFrom(clazz)){
      strValue = String.valueOf(value);
    }else if(short.class.isAssignableFrom(clazz)){
      strValue = String.valueOf((short) value);
    }else if(byte.class.isAssignableFrom(clazz)){
      strValue = String.valueOf((byte) value);
    }else if(long.class.isAssignableFrom(clazz) || Long.class.isAssignableFrom(clazz)){
      strValue = String.valueOf(value);
    }else if(EnumType.class.isAssignableFrom(clazz)){
      if(showList){
        strValue = EnumTypeUtil.getTranslatedType((EnumType) value);
      }else{
        strValue = EnumTypeUtil.getType((EnumType) value);
      }
    }else if(clazz.isEnum()){
      strValue = String.valueOf(value);
    }else if(AttachAsset.class.isAssignableFrom(clazz)){
      strValue = ((AttachAsset) value).getUri();
    }else{
      try{
        strValue = String.valueOf(value);
      }catch (Exception e){
        strValue = value.toString();
      }
    }

    if(showList){
      strValue = HtmlUtil.removeTag(strValue);
      if(StringUtils.length(strValue) > 30){
        strValue = StringUtils.left(strValue, 25);
      }
    }

    return StringUtil.toString(strValue);
  }

  public static String getFieldValue(Object dto, String field){
    try {
      Method get = dto.getClass().getMethod("get"+ StringUtil.startWithUpperCase(field));
      Object value = get.invoke(dto);

      if(value != null){
        String strValue = getStringValue(value);

        if(StringUtils.isNotBlank(strValue)){
          return strValue;
        }else{
          return "";
        }

      }else{
        return "";
      }

    } catch (Exception e){
      log.debug("Could not get field "+ field + "'s value.");
      return "";
    }
  }



  public static void setValue(Object dto, String property, Object value) {
    Class<?> dtoClass = dto.getClass();
    java.lang.reflect.Field field = BytecodeUtil.getSingleField(dtoClass, property);

    if(field != null){
      try {
        field.setAccessible(true);
        field.set(dto, value);
      } catch (IllegalAccessException e) {
        log.debug("Failed set field value - '" + property + "' " );
      }
    }
  }

  public static <ENTITY, VIEW> ENTITY updateEntityWithSelectedFields(ENTITY entity, VIEW view, String... fieldNames) {

    Class<?> entityClass = entity.getClass();
    Class<?> dtoClass = view.getClass();

    boolean selectedFields = ArrayUtils.isNotEmpty(fieldNames);

    java.lang.reflect.Field[] fields = BytecodeUtil.getAllFields(entityClass, false);
    if(ArrayUtils.isNotEmpty(fields)){
      for(java.lang.reflect.Field field : fields){

        if(Iterable.class.isAssignableFrom(field.getType()) || Map.class.isAssignableFrom(field.getType())){
          // prevent lazy load exception
          continue;
        }

        String name = field.getName();

        if (StringUtils.equalsIgnoreCase(name, "id")) {
          // id 는 업데이트 하지 않는다.
          continue;
        }

        // skip not selected fields
        if(selectedFields && !ArrayUtils.contains(fieldNames, name)){
          continue;
        }

        field.setAccessible(true);

        java.lang.reflect.Field entityField = BytecodeUtil.getSingleField(dtoClass, name);
        if(entityField != null && field.getType().equals(entityField.getType())){
          try {

            entityField.setAccessible(true);

            Object value = null;
            String getterName = "get" + StringUtil.toUpperCamelCase(name);

            try {
              Method getter = dtoClass.getMethod(getterName);
              value = getter.invoke(view);
            }catch (Exception e){
              log.debug("Failed get field value - '" + name + "' " );
            }

            field.set(entity, value);
          } catch (IllegalAccessException e) {
            log.debug("Failed set field value - '" + name + "' " );
          }
        }
      }
    }

    return entity;

  }

  protected <T, V> T parseInternal(T dto, V entity, Map<String, Object> additionalValues){

    Class entityClass = entity.getClass();
    Class dtoClass = dto.getClass();

    Set<String> parsedFields = new HashSet<>();

    parseInternal(dto, entity, entityClass, dtoClass, parsedFields);

    java.lang.reflect.Field[] fields = BytecodeUtil.getAllFields(dtoClass, false);
    if(ArrayUtils.isNotEmpty(fields)){
      for(java.lang.reflect.Field field : fields){

        if(Iterable.class.isAssignableFrom(field.getType()) || Map.class.isAssignableFrom(field.getType())){
          // prevent lazy load exception
          continue;
        }

        String name = field.getName();
        field.setAccessible(true);

        if(!parsedFields.contains(name)){

          if(MapUtils.isNotEmpty(additionalValues) && additionalValues.containsKey(name)){
            try {
              Object value = additionalValues.get(name);
              field.set(dto, value);
              parsedFields.add(name);
              continue;
            } catch (IllegalAccessException e) {
              log.debug("Failed set field value - '" + name + "' from additionalValues" );
            }
          }

          java.lang.reflect.Field entityField = BytecodeUtil.getSingleField(entityClass, name);
          if(entityField != null && field.getType().equals(entityField.getType())){
            try {

              entityField.setAccessible(true);

              Object value = null;
              String getterName = "get" + StringUtil.toUpperCamelCase(name);

              try {
                Method getter = entityClass.getMethod(getterName);
                value = getter.invoke(entity);
              }catch (Exception e){
                log.debug("Failed get field value - '" + name + "' " );
              }

              field.set(dto, value);
            } catch (IllegalAccessException e) {
              log.debug("Failed set field value - '" + name + "' " );
            }
          }
        }
      }
    }

    return dto;

  }

  protected <T, V> void parseInternal(T dto, V entity, Class entityClass, Class dtoClass, Set<String> parsedFields) {
    // override if needed
  }


  protected <T, V> T reverseInternal(T entity, V dto, Map<String, Object> additionalValues) {
    Class entityClass = entity.getClass();
    Class dtoClass = dto.getClass();

    Set<String> parsedFields = new HashSet<>();

    reverseTemplateFields(entity, dto, entityClass, dtoClass, parsedFields);

    java.lang.reflect.Field[] fields = BytecodeUtil.getAllFields(entityClass, false);
    if(ArrayUtils.isNotEmpty(fields)){
      for(java.lang.reflect.Field field : fields){

        if(Iterable.class.isAssignableFrom(field.getType()) || Map.class.isAssignableFrom(field.getType())){
          // prevent lazy load exception
          continue;
        }

        String name = field.getName();
        field.setAccessible(true);

        if(!parsedFields.contains(name)){

          if(MapUtils.isNotEmpty(additionalValues) && additionalValues.containsKey(name)){
            try {
              Object value = additionalValues.get(name);
              field.set(entity, value);
              parsedFields.add(name);
              continue;
            } catch (IllegalAccessException e) {
              log.debug("Failed set field value - '" + name + "' from additionalValues" );
            }
          }

          java.lang.reflect.Field entityField = BytecodeUtil.getSingleField(dtoClass, name);
          if(entityField != null && field.getType().equals(entityField.getType())){
            try {

              entityField.setAccessible(true);

              Object value = null;
              String getterName = "get" + StringUtil.toUpperCamelCase(name);

              try {
                Method getter = dtoClass.getMethod(getterName);
                value = getter.invoke(entity);
              }catch (Exception e){
                log.debug("Failed get field value - '" + name + "' " );
              }

              field.set(entity, value);
            } catch (IllegalAccessException e) {
              log.debug("Failed set field value - '" + name + "' " );
            }
          }
        }
      }
    }

    return entity;
  }

  protected <T, V> void reverseTemplateFields(T entity, V dto, Class entityClass, Class dtoClass, Set<String> parsedFields){
    // override it
  }
}
