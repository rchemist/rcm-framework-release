/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class RuleFieldValue implements Serializable {

  protected String ruleKey;

  protected String rule;

  public RuleFieldValue() {
  }

  public RuleFieldValue(String ruleKey, String rule) {
    this.ruleKey = ruleKey;
    this.rule = rule;
  }

  public RuleFieldValue withRuleKey(String ruleKey) {
    this.ruleKey = ruleKey;
    return this;
  }

  public RuleFieldValue withRule(String rule) {
    this.rule = rule;
    return this;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    RuleFieldValue ruleFieldValue = (RuleFieldValue) object;

    return new EqualsBuilder().append(ruleKey, ruleFieldValue.ruleKey)
        .append(rule, ruleFieldValue.rule).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(ruleKey).append(rule).toHashCode();
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("ruleKey", ruleKey)
        .append("rule", rule)
        .toString();
  }
}
