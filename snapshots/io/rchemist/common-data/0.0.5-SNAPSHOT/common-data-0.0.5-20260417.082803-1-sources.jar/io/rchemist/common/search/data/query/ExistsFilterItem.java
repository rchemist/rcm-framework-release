/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import io.rchemist.common.web.request.data.FilterItem;
import java.io.Serializable;
import lombok.Getter;

/**
 * EXISTS 서브쿼리 메타데이터를 담는 데이터 클래스.
 *
 * <p>매핑 관계가 없는 엔티티 간에도 단일 쿼리로 존재 여부 필터링이 가능하게 한다.</p>
 *
 * <p>사용 예시:</p>
 * <pre>
 * searchForm.filterExists(
 *     SyllabusSelection.class, "selection.id", "id",
 *     FilterItem.equals("syllabus.id", syllabusId)
 * );
 * </pre>
 *
 * <p>생성 SQL:</p>
 * <pre>
 * WHERE EXISTS (SELECT 1 FROM T_SYLLABUS_SELECTION ss
 *              WHERE ss.SELECTION_ID = s.ID AND ss.SYLLABUS_ID = :val)
 * </pre>
 *
 * <p>Created by kunner</p>
 */
@Getter
public class ExistsFilterItem implements Serializable {

  /** 서브쿼리 대상 엔티티 클래스 (e.g. SyllabusSelection.class) */
  private final Class<?> targetEntityClass;

  /** 대상 엔티티에서 루트 엔티티를 참조하는 경로 (e.g. "selection.id") */
  private final String targetJoinPath;

  /** 루트 엔티티의 매칭 필드 (e.g. "id") */
  private final String rootJoinPath;

  /** 서브쿼리 내 추가 필터 조건 */
  private final FilterItem[] conditions;

  /** true 이면 NOT EXISTS */
  private final boolean negated;

  public ExistsFilterItem(Class<?> targetEntityClass, String targetJoinPath, String rootJoinPath,
      boolean negated, FilterItem... conditions) {
    this.targetEntityClass = targetEntityClass;
    this.targetJoinPath = targetJoinPath;
    this.rootJoinPath = rootJoinPath;
    this.negated = negated;
    this.conditions = conditions;
  }

}
