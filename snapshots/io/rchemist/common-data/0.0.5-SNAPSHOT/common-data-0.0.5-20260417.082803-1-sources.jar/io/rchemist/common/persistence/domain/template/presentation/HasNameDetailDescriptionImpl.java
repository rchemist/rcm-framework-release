/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.HeaderField;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasNameDetailDescription.class)
@Getter
@Setter
public class HasNameDetailDescriptionImpl implements EnhancedTemplate {

  @AdminField(name = "NameDescriptionImpl_Name", order = 300, fieldType = PresentationFieldType.STRING, headerField = @HeaderField(order = 300), required = true
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 300)
  )
  protected String name;

  @AdminField(order = 400, fieldType = PresentationFieldType.TEXT
      , name = "NameDescriptionImpl_Description"
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 400)
  )
  protected String description;

  @AdminField(order = 400, fieldType = PresentationFieldType.HTML
      , name = "NameDescriptionImpl_LongDescription"
      , createForm = @CreateForm(type = CreateFormType.OPTIONAL, order = 410)
  )
  protected String longDescription;

}
