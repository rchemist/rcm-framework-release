/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.response;

import io.rchemist.common.exception.error.ErrorDTO;
import java.io.Serializable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class ResponseData<T> extends ResponseEntity<ResponseWrapper<T>> implements Serializable, ResponseHolder {

  public ResponseData(ResponseWrapper<T> data, HttpStatus status) {
    super(data, status);
  }

  @Override
  public ErrorDTO getError() {
    return super.getBody().getError();
  }

  public ResponseData<T> withError(ErrorDTO error) {
    ResponseWrapper<T> wrapper = super.getBody();
    return ResponseHelper.result(wrapper == null ? null : wrapper.getData(), error);
  }

  public T getData(){
    return (isError()) ? null : super.getBody() == null ? null : super.getBody().getData();
  }

  public static final <T> ResponseEntity<ResponseData> getResponseToJson(
      ResponseData<T> result){
    if(result == null)
      new ResponseEntity<>(null, HttpStatus.NOT_FOUND);

    return (result.isError()) ?
        new ResponseEntity<>((ResponseData) result, HttpStatus.valueOf(result.getError().getStatus()))
        : new ResponseEntity<>((ResponseData) result, HttpStatus.OK);
  }

}
