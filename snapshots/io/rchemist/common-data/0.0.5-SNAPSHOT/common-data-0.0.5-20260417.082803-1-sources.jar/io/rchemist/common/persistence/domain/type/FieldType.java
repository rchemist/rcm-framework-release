/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
public class FieldType extends EnumType<FieldType> {

  public static final FieldType STRING = new FieldType(10, "STRING", "String", "문자열(255자 이내)", "global.type.custom.field.type.string", PresentationFieldType.STRING);
  public static final FieldType BOOLEAN = new FieldType(20, "BOOLEAN", "Boolean", "Boolean", "global.type.custom.field.type.boolean", PresentationFieldType.BOOLEAN);
  public static final FieldType NUMBER = new FieldType(30, "NUMBER", "Number", "숫자(정수)", "global.type.custom.field.type.number", PresentationFieldType.INTEGER);
  public static final FieldType DOUBLE = new FieldType(40, "DOUBLE", "Double", "숫자(소수점)", "global.type.custom.field.type.double", PresentationFieldType.DECIMAL);
  public static final FieldType MONEY = new FieldType(50, "MONEY", "Money", "금액", "global.type.custom.field.type.money", PresentationFieldType.MONEY);
  public static final FieldType SELECT = new FieldType(60, "SELECT", "Select", "선택옵션", "global.type.custom.field.type.select", PresentationFieldType.ENUMERATION);
  public static final FieldType SELECT_MULTIPLE = new FieldType(70, "SELECT_MULTIPLE", "Select Multiple", "복수 선택옵션", "global.type.custom.field.type.money", PresentationFieldType.ENUMERATION_MULTIPLE);
  public static final FieldType TEXT = new FieldType(80, "TEXT", "Text", "문자열(Lob, Text)", "global.type.custom.field.type.lob", PresentationFieldType.TEXT);
  public static final FieldType HTML = new FieldType(90, "HTML", "Html", "문자열(Lob, Html)", "global.type.custom.field.type.html", PresentationFieldType.HTML);
  public static final FieldType FILE = new FieldType(100, "FILE", "File", "파일 업로드", "global.type.custom.field.type.file", PresentationFieldType.UPLOAD);
  public static final FieldType FILE_MULTIPLE = new FieldType(110, "FILE_MULTIPLE", "Multiple File", "파일 업로드", "global.type.custom.field.type.file.multiple", PresentationFieldType.UPLOAD_MULTIPLE);
  public static final FieldType IMAGE = new FieldType(120, "IMAGE", "Image", "파일 업로드", "global.type.custom.field.type.image", PresentationFieldType.UPLOAD);
  public static final FieldType IMAGE_MULTIPLE = new FieldType(130, "IMAGE_MULTIPLE", "Multiple Image", "파일 업로드", "global.type.custom.field.type.image.multiple", PresentationFieldType.UPLOAD_MULTIPLE);
  public static final FieldType MODULE = new FieldType(140, "MODULE", "Module", "모듈", "global.type.custom.field.type.module", PresentationFieldType.COMPONENT);

  private final PresentationFieldType presentationFieldType;

  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public FieldType(int order, String key, String value, String description, String messageKey, PresentationFieldType presentationFieldType) {
    super(order, key, value, description, messageKey);
    this.presentationFieldType = presentationFieldType;
  }
}
