/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 *
 * Xref 매핑 정보를 담고 있는 DTO
 * 삭제된 XREF 매핑
 * 추가된 XREF 매핑 정보를 가지고 있다.
 * 이 정보는 CreateForm, UpdateForm 에서 사용한다.
 *
 **/
@Getter
@Setter
public class XrefMappingForm<ID_TYPE> implements Serializable {

  protected List<ID_TYPE> mapped;

  protected List<ID_TYPE> deleted;

  @JsonIgnore
  private boolean validated;

  public boolean isEmpty() {
    return mapped == null || mapped.isEmpty();
  }

  /**
   * 데이터 정제
   * 실제 서비스에서 이 폼을 사용할 때 데이터를 정제하기 위해 한번 호출해 주면 된다.
   */
  public void validate() {
    if (!validated) {
      if (CollectionUtils.isNotEmpty(mapped)) {
        if (CollectionUtils.isNotEmpty(deleted)) {
          // 삭제됐다고 처리된 것을 다시 매핑하지 못하게 한다.
          // 예를 들어 deleted 에 1L 이 있는데 mapped 에도 1L 이 있다면, 이건 오류다. deleted 값을 우선 적용한다.
          mapped.removeAll(deleted);
        }

      }
      this.validated = true;
    }
  }

  public boolean hasMapped() {
    this.validate();
    return CollectionUtils.isNotEmpty(mapped);
  }

  public boolean hasDeleted() {
    this.validate();
    return CollectionUtils.isNotEmpty(deleted);
  }

  public XrefMappingForm<ID_TYPE> withMapped(List<ID_TYPE> mapped) {
    this.mapped = mapped;
    return this;
  }

  public XrefMappingForm<ID_TYPE> withDeleted(List<ID_TYPE> deleted) {
    this.deleted = deleted;
    return this;
  }

  public XrefMappingForm<ID_TYPE> addDeleted(ID_TYPE... ids) {
    this.deleted = addIds(deleted, ids);
    return this;
  }

  public XrefMappingForm<ID_TYPE> addMapped(ID_TYPE... ids) {
    this.mapped = addIds(mapped, ids);
    return this;
  }

  private List<ID_TYPE> addIds(List<ID_TYPE> targetList, ID_TYPE... ids) {
    if (ids == null || ArrayUtils.isEmpty(ids))
      return targetList;
    if (targetList == null) {
      targetList = new ArrayList<>();
    }
    List<ID_TYPE> list = getNonDuplicated(targetList, ids);
    if (CollectionUtils.isNotEmpty(list)) {
      targetList.addAll(list);
    }
    return targetList;
  }

  private List<ID_TYPE> getNonDuplicated(List<ID_TYPE> targetList, ID_TYPE[] ids) {
    List<ID_TYPE> list = new ArrayList<>();
    for (ID_TYPE id : ids) {
      if (targetList == null || !targetList.contains(id)) {
        list.add(id);
      }
    }
    return list;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }

    if (object == null || getClass() != object.getClass()) {
      return false;
    }

    XrefMappingForm<?> that = (XrefMappingForm<?>) object;

    return new EqualsBuilder()
        .append(mapped, that.mapped).append(deleted, that.deleted).isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37).append(mapped).append(deleted).toHashCode();
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("mapped", mapped)
        .append("deleted", deleted)
        .toString();
  }

  public XrefMappingForm<ID_TYPE> deepCopy() {
    return new XrefMappingForm<ID_TYPE>()
        .withMapped(new ArrayList<>(mapped))
        .withDeleted(new ArrayList<>(deleted));
  }
}
