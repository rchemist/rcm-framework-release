/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.type;

import io.rchemist.common.enumeration.EnumType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomFieldType extends EnumType<CustomFieldType> {

  public static final CustomFieldType STRING = new CustomFieldType(1, "STRING", "String", "문자열", "string", PresentationFieldType.STRING);
  public static final CustomFieldType NUMBER = new CustomFieldType(100, "NUMBER", "Number", "정수", "number", PresentationFieldType.INTEGER);
  public static final CustomFieldType BOOLEAN = new CustomFieldType(200, "BOOLEAN", "Boolean", "예/아니오", "boolean", PresentationFieldType.BOOLEAN);
  public static final CustomFieldType STRING_LIST = new CustomFieldType(300, "STRING_LIST", "StringList", "복수 문자열", "string_list", PresentationFieldType.STRING_LIST);
  public static final CustomFieldType TEXT = new CustomFieldType(400, "TEXT", "Text", "텍스트", "text", PresentationFieldType.TEXT);
  public static final CustomFieldType HTML = new CustomFieldType(500, "HTML", "Html", "HTML 에디터", "html", PresentationFieldType.HTML);
  public static final CustomFieldType EMAIL = new CustomFieldType(600, "EMAIL", "Email", "이메일", "email", PresentationFieldType.EMAIL);
  public static final CustomFieldType DATE = new CustomFieldType(700, "DATE", "Date", "날짜", "date", PresentationFieldType.DATE);
  public static final CustomFieldType DATETIME = new CustomFieldType(800, "DATETIME", "DateTime", "날짜/시각", "date_time", PresentationFieldType.DATETIME);
  public static final CustomFieldType DECIMAL = new CustomFieldType(900, "DECIMAL", "Decimal", "실수(소수점포함)", "decimal", PresentationFieldType.DECIMAL);
  public static final CustomFieldType ENUMERATION = new CustomFieldType(1000, "ENUMERATION", "Enumeration", "옵션 선택", "enumeration", PresentationFieldType.ENUMERATION);
  public static final CustomFieldType ENUMERATION_DB = new CustomFieldType(1100, "ENUMERATION_DB", "ENUMERATION_DB", "사용자정의 옵션 선택", "enumeration_db", PresentationFieldType.ENUMERATION);
  public static final CustomFieldType MONEY = new CustomFieldType(1000, "MONEY", "Money", "통화", "money", PresentationFieldType.MONEY);
  public static final CustomFieldType IMAGE = new CustomFieldType(1100, "IMAGE", "Image", "이미지", "image", PresentationFieldType.IMAGE);
  public static final CustomFieldType UPLOAD = new CustomFieldType(1200, "UPLOAD", "Upload", "파일", "upload", PresentationFieldType.UPLOAD);

  public CustomFieldType(int order, String type, String friendlyType, String description,
      String messageKey,
      PresentationFieldType presentationFieldType) {
    super(order, type, friendlyType, description, messageKey);
    this.presentationFieldType = presentationFieldType;
  }

  private CustomFieldType() {
    this.presentationFieldType = PresentationFieldType.NOT_AVAILABLE;
  }

  @Getter
  private final PresentationFieldType presentationFieldType;

}
