/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.presentation.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 적용 우선순위
 * 1. options
 * 2. enumerationClass
 * 3. enumerationKey
 * 4. enumerationValues
 *
 * options 이 설정되어 있지 않다면 enumerationClass 를 조회한다.
 * enumerationClass 값이 설정되어 있지 않다면
 * enumerationKey 를 확인하고 해당 값이 있으면 CustomOption 을 조회한다.
 * 만약 enumerationKey 에도 값이 없으면 enumerationValues() 를 조회하고, 해당 값이 있으면 이 값을 옵션으로 사용한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.ANNOTATION_TYPE})
public @interface Enumeration {

  /**
   * EnumType class field 인 경우 이 값에 fully qualified class path 를 입력해야 한다.
   *
   * @return
   */
  String enumType() default "";

  /**
   * DB 에 저장된 EnumType 값을 불러올 경우 key 값을 입력해야 한다.
   * @return
   */
  String customOptionKey() default "";

  /**
   * 허용된 값만 입력하게 할 수 있다.
   *
   * 이 필드가 Enumeration 필드일 때 지정된 값만 옵션으로 선택할 수 있게 한다.
   * enumerationClass 가 있을 때는 EnumType.key 가 availableEnumTypes 에 포함된 값만 선택 가능
   * enumerationKey 에 값이 있을 때는 해당 정보에서  key 가 availableEnumTypes 에 포함된 값만 선택 가능
   * enumerationClass 와 enumerationKey 가 모두 정의되어 있지 않을 때는 availableEnumTypes 에 정의된 값 중 하나를 선택 가능
   *
   * 이 필드가 String 일 때 지정된 값만 입력할 수 있다.
   * Select 형태의 필드를 제공할 수 있을 것이다.
   * @return
   */
  String[] values() default {};

  /**
   * 이 필드가 Checkbox 나 Combo 같은 필드인 경우
   * 이 옵션을 사용하면 enumeration 을 따로 지정하지 않고 바로 선택값을 설정할 수 있다.
   * 이 값이 설정되어 있다면 enumerationClass, enumerationKey, enumerationValues 는 모두 무시한다.
   *
   * @return
   */
  AdditionalAttribute[] options() default {};

  /**
   * overrideMetadata 에서 사용할 때 이 값을 true 로 셋팅해야 오버라이드 된다.
   * @return
   */
  boolean overridden() default false;

}
