/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.util.StringUtil;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ServiceMappingSearchForm<T> extends HasServiceMapping<T> {

  default T withServiceEntityIds(String... serviceEntityIds){
    setServiceEntityIds(serviceEntityIds);
    return (T) this;
  }

  default void setServiceEntityIds(String... serviceEntityIds){
    if(ArrayUtils.isEmpty(serviceEntityIds)){
      setServiceEntityId(null);
    }else{
      if(serviceEntityIds.length == 1){
        setServiceEntityId(serviceEntityIds[0]);
      }else{
        String serviceEntityId = StringUtil.mergeWithSplitCode(",", serviceEntityIds);
        setServiceEntityId(serviceEntityId);
      }
    }
  }


  default T withParentServiceEntityIds(String... parentServiceEntityIds){
    setParentServiceEntityIds(parentServiceEntityIds);
    return (T) this;
  }

  default void setParentServiceEntityIds(String... parentServiceEntityIds){
    if(ArrayUtils.isEmpty(parentServiceEntityIds)){
      setParentServiceEntityId(null);
    }else{
      if(parentServiceEntityIds.length == 1){
        setParentServiceEntityId(parentServiceEntityIds[0]);
      }else{
        String serviceEntityId = StringUtil.mergeWithSplitCode(",", parentServiceEntityIds);
        setParentServiceEntityId(serviceEntityId);
      }
    }
  }

}
