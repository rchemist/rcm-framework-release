/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.type;

import io.rchemist.common.enumeration.EnumType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
public class AdjustmentType extends EnumType<AdjustmentType> {

  public static final AdjustmentType ADD_AMOUNT = new AdjustmentType(10, "ADD_AMOUNT","Add Amount"
      ,"일정 가격 할증","global.type.adjust.type.add.amount", false);

  public static final AdjustmentType ADD_PERCENT = new AdjustmentType(20, "ADD_PERCENT","Add Percent"
      ,"일정 비욜 할증","global.type.adjust.type.add.percent", false);

  public static final AdjustmentType OFF_AMOUNT = new AdjustmentType(30, "OFF_AMOUNT","Amount Off"
      ,"일정 가격 할인","global.type.adjust.type.off.amount", false);

  public static final AdjustmentType OFF_PERCENT = new AdjustmentType(40, "OFF_PERCENT","Percent Off"
      ,"일정 비율 할인","global.type.adjust.type.off.percent", true);

  public static final AdjustmentType FIXED_PRICE = new AdjustmentType(50, "FIXED_PRICE","Fixed Price"
      ,"고정 가격","global.type.adjust.type.fixed.price", false);


  private final boolean shouldAmountLess100;


  /**
   * 기본 생성자. 필수로 이 생성자를 override 해야 한다.
   *
   * @param key
   * @param value
   * @param description
   * @param messageKey
   */
  public AdjustmentType(int order, String key, String value, String description, String messageKey, boolean shouldAmountLess100) {
    super(order, key, value, description, messageKey);
    this.shouldAmountLess100 = shouldAmountLess100;
  }

}
