/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.listener;

import io.rchemist.common.persistence.domain.template.listener.type.AuditFieldType;
import io.rchemist.common.persistence.domain.template.listener.type.AuditType;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.request.WebRequestContext;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Instant;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
public interface AuditListener {

  default void setAuditBy(Object auditableObject, AuditType auditType) throws IllegalArgumentException{
    try {
      WebRequestContext context = WebRequestContext.getWebRequestContext();

      if (context != null && context.getAuthentication() != null) {

        Method byMethod = auditableObject.getClass().getMethod(getMethodName(AuditFieldType.BY, auditType), String.class);
        Method typeMethod = auditableObject.getClass().getMethod(getMethodName(AuditFieldType.TYPE, auditType), AuditUserType.class);

        SimpleAuthentication authentication = context.getAuthentication();

        if(authentication != null && StringUtils.isNotEmpty(authentication.getUserId())){

          SiteType siteType = authentication.getSiteType();
          AuditUserType auditUserType = (siteType.equals(SiteType.FRONT)) ? AuditUserType.CUSTOMER : AuditUserType.ADMIN;

          byMethod.invoke(auditableObject, authentication.getUserId());
          typeMethod.invoke(auditableObject, auditUserType);

        }

      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  default void audit(Object entity, AuditType auditType) {
    try {
      setAuditAt(entity, auditType);
      // audit by, type setting
      setAuditBy(entity, auditType);
    }catch (Exception e) {
      // silent exception skip audit
    }
  }


  /**
   * Used to set the timestamp for dateCreated and dateUpdated.
   *
   * @param auditableObject
   * @param auditType
   * @return
   */
  default void setAuditAt(Object auditableObject, AuditType auditType) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException{

    Method method = auditableObject.getClass().getMethod(getMethodName(AuditFieldType.AT, auditType), Instant.class);
    method.invoke(auditableObject, Instant.now());

  }

  default String getMethodName(AuditFieldType auditFieldType, AuditType auditType) {
    String methodName;
    if(auditType.equals(AuditType.CREATE)){
      if(auditFieldType.equals(AuditFieldType.AT)){
        methodName = "setCreatedAt";
      }else if(auditFieldType.equals(AuditFieldType.BY)){
        methodName = "setCreatedBy";
      } else {
        methodName = "setCreatedByUserType";
      }
    }else {
      if(auditFieldType.equals(AuditFieldType.AT)){
        methodName = "setUpdatedAt";
      }else if(auditFieldType.equals(AuditFieldType.BY)){
        methodName = "setUpdatedBy";
      } else {
        methodName = "setUpdatedByUserType";
      }
    }

    return methodName;

  }

}
