/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasPriority<T> extends ClassTransformTarget {

  default Integer getPriority() {
    throw new ClassTransformException();
  }

  default void setPriority(Integer priority) {
    throw new ClassTransformException();
  }

  /**
   * 리턴되는 int값이 음수이면 현재 인스턴스가 비교대상인 인스턴스보다 작고, 양수이면 크고, 0 이면 같다
   * @param p
   * @return
   */
  default int compareTo(HasPriority<?> p){
    return Integer.compare(getPriority(), p.getPriority());
  }

  default int getPriorityNumber(){
    return getPriority() != null ? getPriority() : 0;
  }

  default T withPriority(Integer priority){
    setPriority(priority);
    return (T) this;
  }

}
