/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.money;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.rchemist.common.money.adapter.BigDecimalRoundingAdapter;
import io.rchemist.common.money.adapter.CurrencyAdapter;
import io.rchemist.common.util.MoneyUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.Locale;
import java.util.Objects;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Configuration
@XmlAccessorType(XmlAccessType.FIELD)
@JsonIgnoreProperties({
    "zero", "truncatedMoney", "truncatedAmount"
})
@Slf4j
public class Money implements Serializable, Cloneable, Comparable<Money>, Externalizable {

  public static final Money ZERO = new Money(BigDecimal.ZERO);

  @Serial
  private static final long serialVersionUID = 1L;

  private static RoundingMode DEFAULT_ROUNDING_MODE;

  private static int DEFAULT_TRUNCATION_MULTIPLIER = 10;

  @Value("${platform.config.common.money.default.rounding.mode:HALF_UP}")
  public void setDefaultRoundingMode(String defaultRoundingMode){
    String mode = StringUtils.isNotEmpty(defaultRoundingMode) ? defaultRoundingMode : "HALF_UP";
    try{
      Money.DEFAULT_ROUNDING_MODE = RoundingMode.valueOf(mode);
    }catch (Exception e){
      Money.DEFAULT_ROUNDING_MODE = RoundingMode.HALF_UP;
    }
  }

  public static RoundingMode getDefaultRoundingMode(){
    return (DEFAULT_ROUNDING_MODE != null) ? DEFAULT_ROUNDING_MODE : RoundingMode.HALF_UP;
  }

  @Value("${platform.config.common.money.default.truncation.multiplier:10}")
  public void setDefaultTruncationMode(int defaultTruncationMultiplier){
    Money.DEFAULT_TRUNCATION_MULTIPLIER = defaultTruncationMultiplier;
  }

  /**
   * 기본 절사 단위
   * @return
   */
  public static int getDefaultTruncationMultiplier(){
    return DEFAULT_TRUNCATION_MULTIPLIER;
  }


  @XmlElement
  @XmlJavaTypeAdapter(CurrencyAdapter.class)
  private final Currency currency;
  @XmlElement
  @XmlJavaTypeAdapter(value = BigDecimalRoundingAdapter.class)
  private BigDecimal amount;

  public Money(Currency currency) {
    this(MoneyRounding.zeroAmount(), currency);
  }

  public Money() {
    this(MoneyRounding.zeroAmount(), defaultCurrency());
  }

  public Money(BigDecimal amount) {
    this(amount, defaultCurrency());
  }

  public Money(double amount) {
    this(valueOf(amount), defaultCurrency());
  }

  public Money(int amount) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(defaultCurrency()),
        getDefaultRoundingMode()), defaultCurrency());
  }

  public Money(long amount) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(defaultCurrency()),
        getDefaultRoundingMode()), defaultCurrency());
  }

  public Money(String amount) {
    this(valueOf(amount), defaultCurrency());
  }

  public Money(BigDecimal amount, String currencyCode) {
    this(amount, getCurrency(currencyCode));
  }

  public Money(double amount, Currency currency) {
    this(valueOf(amount), currency);
  }

  public Money(double amount, String currencyCode) {
    this(valueOf(amount), Currency.getInstance(currencyCode));
  }

  public Money(int amount, Currency currency) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(currency), getDefaultRoundingMode()), currency);
  }

  public Money(int amount, String currencyCode) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(Currency.getInstance(currencyCode)), getDefaultRoundingMode()), Currency.getInstance(currencyCode));
  }

  public Money(long amount, Currency currency) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(currency), getDefaultRoundingMode()), currency);
  }

  public Money(long amount, String currencyCode) {
    this(BigDecimal.valueOf(amount).setScale(MoneyRounding.getScaleForCurrency(Currency.getInstance(currencyCode)), getDefaultRoundingMode()), Currency.getInstance(currencyCode));
  }

  public Money(String amount, Currency currency) {
    this(valueOf(amount), currency);
  }

  public Money(String amount, String currencyCode) {
    this(valueOf(amount), Currency.getInstance(currencyCode));
  }

  public Money(BigDecimal amount, Currency currency) {
    if (currency == null) {
      throw new IllegalArgumentException("currency cannot be null");
    }
    this.currency = currency;
    this.amount = MoneyRounding.setScale(MoneyRounding.getScaleForCurrency(currency), amount);
  }

  public Money(Money money){
    this.amount = money.getAmount();
    this.currency = money.getCurrency();
  }

  public Money(BigDecimal amount, Currency currency, int scale) {
    if (currency == null) {
      throw new IllegalArgumentException("currency cannot be null");
    }
    this.currency = currency;
    this.amount = MoneyRounding.setScale(amount, scale);
  }

  protected static String getCurrencyCode(Currency currency) {
    if (currency != null) {
      return currency.getCurrencyCode();
    } else {
      return defaultCurrency().getCurrencyCode();
    }
  }

  public static Money zero(String currencyCode) {
    return zero(Currency.getInstance(currencyCode));
  }

  public static Money zero(Currency currency) {
    return new Money(MoneyRounding.zeroAmount(), currency);
  }

  public static Money zero(){
    return zero(defaultCurrency());
  }

  public static Money abs(Money money) {
    return new Money(money.amount.abs(), money.currency);
  }

  public static Money min(Money left, Money right) {
    return left.min(right);
  }

  public static Money max(Money left, Money right) {
    return left.max(right);
  }

  public static BigDecimal toAmount(Money money) {
    return ((money == null) ? BigDecimal.ZERO : money.amount);
  }

  public static Currency toCurrency(Money money) {
    return ((money == null) ? defaultCurrency() : money.currency);
  }

  /**
   * Ensures predictable results by converting the double into a string then calling the BigDecimal string constructor.
   *
   * @param amount The amount
   * @return BigDecimal a big decimal with a predictable value
   */
  private static BigDecimal valueOf(double amount) {
    return valueOf(String.valueOf(amount));
  }

  private static BigDecimal valueOf(String amount) {
    if(StringUtil.isBlank(amount)) return Money.toAmount(ZERO);
    BigDecimal value = new BigDecimal(amount);
    if (value.scale() < 2) {
      value = value.setScale(MoneyRounding.getScaleForCurrency(defaultCurrency()), getDefaultRoundingMode());
    }

    return value;
  }

  /**
   * Attempts to load a default currency by using the default locale. {@link Currency#getInstance(Locale)} uses the country component of the locale to resolve the currency. In some instances, the locale may not have a country component, in which case the default currency can be controlled with a
   * system property.
   *
   * @return The default currency to use when none is specified
   */
  public static Currency defaultCurrency() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    if(context != null && context.getCurrency() != null){
      return context.getCurrency();
    }

    if (System.getProperty("currency.default") != null) {
      return Currency.getInstance(System.getProperty("currency.default"));
    }
    Locale locale = Locale.getDefault();
    if (locale.getCountry() != null && locale.getCountry().length() == 2) {
      return Currency.getInstance(locale);
    }
    return Currency.getInstance("KRW");
  }

  public static Currency getCurrency(String currencyCode){
    try{
      Currency currency = Currency.getInstance(currencyCode);
      if(currency != null)
        return currency;
    }catch (Exception e){
      log.debug("Failed to get currency", e);
    }
    return defaultCurrency();
  }

  public Money add(BigDecimal other) {
    return add(new Money(other));
  }

  public Money add(Money other) {
    if(other == null) other = Money.ZERO;

    if (!other.getCurrency().equals(getCurrency())) {
      if (this == Money.ZERO) {
        return new Money(amount.add(other.amount), other.currency, amount.scale() == 0
            ? MoneyRounding.getScaleForCurrency(other.currency) : amount.scale());
      } else if (other == Money.ZERO) {
        return this;
      }
      throw new UnsupportedOperationException("No currency conversion service is registered, cannot add different currency " +
          "types together (" + getCurrency().getCurrencyCode() + " " + other.getCurrency().getCurrencyCode() + ")");
    }

    return new Money(amount.add(other.amount), currency, amount.scale() == 0 ? MoneyRounding.getScaleForCurrency(currency) : amount.scale());
  }

  public Money subtract(BigDecimal other) {
    return subtract(new Money(other));
  }

  public Money subtract(Money other) {
    if(other == null)
      return this;

    if(other.getAmount() == null)
      return this;

    if(this.amount == null || this.amount.equals(BigDecimal.ZERO))
      return other.multiply(-1);    // 부호를 바꾼다.

    if (!other.getCurrency().equals(getCurrency())) {
      if (other.isZero()) {
        return this;
      } else if (this.isZero()) {
        return new Money(amount.subtract(other.amount), other.currency, amount.scale() == 0
            ? MoneyRounding.getScaleForCurrency(other.currency) : amount.scale());
      }
      throw new UnsupportedOperationException("No currency conversion service is registered, cannot subtract different currency " +
          "types (" + getCurrency().getCurrencyCode() + ", " + other.getCurrency().getCurrencyCode() + ")");
    }

    return new Money(amount.subtract(other.amount), currency, amount.scale() == 0 ? MoneyRounding.getScaleForCurrency(currency) : amount.scale());
  }

  public Money multiply(double amount) {
    return multiply(valueOf(amount));
  }

  public Money multiply(int amount) {
    BigDecimal value = BigDecimal.valueOf(amount);
    value = value.setScale(MoneyRounding.getScaleForCurrency(currency), getDefaultRoundingMode());
    return multiply(value);
  }

  public Money multiply(BigDecimal multiplier) {
    return new Money(amount.multiply(multiplier), currency, amount.scale() == 0 ? MoneyRounding.getScaleForCurrency(currency) : amount.scale());
  }

  public Money divide(double amount) {
    return this.divide(amount, getDefaultRoundingMode());
  }

  public Money divide(double amount, RoundingMode roundingMode) {
    return divide(valueOf(amount), roundingMode);
  }

  public Money divide(int amount) {
    // use getDefaultRoundingMode()
    // aka Banker's Rounding - 3.5 -> 4, 4.5 -> 4, 5.5 -> 6
    return this.divide(amount, getDefaultRoundingMode());
  }

  public Money divide(int amount, RoundingMode roundingMode) {
    BigDecimal value = BigDecimal.valueOf(amount);
    value = value.setScale(MoneyRounding.getScaleForCurrency(currency), getDefaultRoundingMode());
    return divide(value, roundingMode);
  }

  public Money divide(BigDecimal divisor) {
    return this.divide(divisor, getDefaultRoundingMode());
  }

  public Money divide(BigDecimal divisor, RoundingMode roundingMode) {
    return new Money(amount.divide(divisor, amount.scale(), roundingMode), currency, amount.scale() == 0 ? MoneyRounding.getScaleForCurrency(currency) : amount.scale());
  }

  public Money abs() {
    return new Money(amount.abs(), currency);
  }

  public Money min(Money other) {
    if (other == null) {
      return this;
    }
    return lessThan(other) ? this : other;
  }

  public Money max(Money other) {
    if (other == null) {
      return this;
    }
    return greaterThan(other) ? this : other;
  }

  public Money negate() {
    return new Money(amount.negate(), currency);
  }

  public boolean isZero() {
    return amount.compareTo(MoneyRounding.zeroAmount()) == 0;
  }

  public Money getZero() {
    return Money.zero(currency);
  }

  public boolean lessThan(Money other) {
    return compareTo(other) < 0;
  }

  public boolean lessThan(BigDecimal value) {
    return amount.compareTo(value) < 0;
  }

  public boolean lessThanOrEqual(Money other) {
    return compareTo(other) <= 0;
  }

  public boolean lessThanOrEqual(BigDecimal value) {
    return amount.compareTo(value) <= 0;
  }

  public boolean greaterThan(Money other) {
    return compareTo(other) > 0;
  }

  public boolean greaterThan(BigDecimal value) {
    return amount.compareTo(value) > 0;
  }

  public boolean greaterThanOrEqual(Money other) {
    return compareTo(other) >= 0;
  }

  public boolean greaterThanOrEqual(BigDecimal value) {
    return amount.compareTo(value) >= 0;
  }

  @Override
  public int compareTo(Money other) {
    return amount.compareTo(other.amount);
  }

  public int compareTo(BigDecimal value) {
    return amount.compareTo(value);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null) return false;
    if (!getClass().isAssignableFrom(o.getClass())) {
      return false;
    }

    Money money = (Money) o;

    if (!Objects.equals(amount, money.amount)) {
      return false;
    }

    if (isZero()) {
      return true;
    }

    return Objects.equals(currency, money.currency);
  }

  @Override
  public int hashCode() {
    int result = amount != null ? amount.hashCode() : 0;
    result = 31 * result + (currency != null ? currency.hashCode() : 0);
    return result;
  }

  @Override
  public Object clone() {
    return new Money(amount, currency);
  }

  @Override
  public String toString() {

    String value = amount.toString();

    String pointValue = StringUtil.subStringAfter(value, ".");

    // toString 의 결과가 XXX.00000 일 때 - 즉, 소수점 이하가 모두 .00000 일 때 XXX 만 반환한다.
    if(NumberUtil.getInteger(pointValue, 0) == 0){
      return StringUtil.subStringBefore(value, ".");
    }

    return value;
  }

  public double doubleValue() {
    try {
      return amount.doubleValue();
    } catch (NumberFormatException e) {
      // HotSpot bug in JVM < 1.4.2_06.
      if (e.getMessage().equals("For input string: \"0.00null\"")) {
        return amount.doubleValue();
      } else {
        throw e;
      }
    }
  }

  public String stringValue() {
    return amount.toString() + " " + currency.getCurrencyCode();
  }

  @Override
  public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
    // Read in the server properties from the client representation.
    amount = BigDecimal.valueOf(in.readFloat());

  }

  @Override
  public void writeExternal(ObjectOutput out) throws IOException {
    // Write out the client properties from the server representation.
    out.writeFloat(amount.floatValue());
    // out.writeObject(currency);
  }

  /**
   * 지정된 단위 절사
   * @param trunc
   * @return
   */
  public Money truncate(int trunc) {

    if(trunc == 0)
      return this;

    int len = String.valueOf(getAmount().intValue()).length();
    if(len <= trunc)
      return zero(getCurrency());

    double truncUnit = Math.pow(10, trunc);      // 만약 이 값이 1 이라면 10 단위에서 절사되어야 하기 때문에 1 을 추가한다

    BigDecimal amount = new BigDecimal(getAmount().divide(new BigDecimal(truncUnit)).intValue());
    amount = amount.multiply(new BigDecimal(truncUnit));

    return new Money(amount, getCurrency());
  }

  /**
   * 현재 금액의 X% 에 해당하는 금액을 반환한다
   * @param percentage
   * @return
   */
  public Money rate(Double percentage){
    return rate(percentage, null);
  }

  public Money rate(Double percentage, RoundingMode roundingMode){
    if(amount == null)
      return Money.ZERO;

    if(percentage == null || percentage.intValue() == 100)
      return this;

    if (roundingMode == null)
      roundingMode = getDefaultRoundingMode();

    return new Money(amount.multiply(new BigDecimal(percentage)).divide(new BigDecimal(100), roundingMode), getCurrency());
  }


  public Double getPercentage(Money compare, int precision) {
    return getPercentage(compare, precision, Money.getDefaultRoundingMode());
  }

  /**
   * 다른 금액과의 비율
   * @param compare   분모에 해당하는 금액이다
   * @param precision
   * @param roundingMode
   * @return
   */
  public Double getPercentage(Money compare, int precision, RoundingMode roundingMode){
    return getPercentage(compare.getAmount(), precision, roundingMode);
  }

  public Double getPercentage(BigDecimal compare, int precision, RoundingMode roundingMode){

    if (amount == null)
      return 0.0;

    if(compare == null || compare.intValue() == 0)
      return 100.0;

    BigDecimal proportion = amount.divide(compare, precision + 2, RoundingMode.HALF_UP) // 임시로 더 높은 precision 사용
        .multiply(BigDecimal.valueOf(100));

    if(roundingMode == null)
      roundingMode = RoundingMode.HALF_UP;

    // 원하는 precision으로 소수점 반올림 처리
    proportion = proportion.setScale(precision, roundingMode);

    return proportion.doubleValue();
  }


  public Money average(int quantity){
    return average(quantity, null);
  }

  public Money average(int quantity, RoundingMode roundingMode){
    if(amount == null)
      return null;

    if(amount.compareTo(BigDecimal.ZERO) == 0)
      return new Money();

    if(roundingMode == null)
      roundingMode = getDefaultRoundingMode();

    return new Money(amount.divide(new BigDecimal(quantity), roundingMode));
  }

  /**
   * 수량으로 나눴을 때 딱 떨어지는 금액인지 여부
   * @param quantity
   * @return
   */
  public boolean totallyDivided(int quantity){
    Money singular = MoneyUtil.getSingularityAmount(this);
    if(this.greaterThan(singular)){
      Money average = average(quantity);
      return this.equals(average.multiply(quantity));
    }else{
      return (quantity == 1);
    }
  }

  public Money difference(Money other) {
    if(amount == null)
      return null;
    if(other == null)
      return new Money(this);

    // 같으면 차액은 0
    if(this.equals(other))
      return Money.zero();

    return this.subtract(other).abs();
  }

  public Money getTruncatedAmount(){
    return getTruncatedAmount(Money.getDefaultTruncationMultiplier());
  }

  /**
   * 시스템에 지정된 truncationMultiplier 로 절사
   * @param truncationMultiplier 절사 단위. 소수점 몇째 자리에서 절사할 것인지
   * @return
   */
  public Money getTruncatedAmount(int truncationMultiplier){
    if(amount == null || amount.equals(new BigDecimal(0)) || truncationMultiplier <= 1){
      return this;
    }
    BigDecimal multiplier = new BigDecimal(truncationMultiplier);

    BigDecimal truncated = new BigDecimal(amount.toString());
    truncated = truncated.setScale(truncated.scale(), getDefaultRoundingMode());
    return new Money(truncated.divide(multiplier, Money.getDefaultRoundingMode()), getCurrency()).multiply(multiplier);
  }

  public boolean validateTruncated(){
    Money truncated = getTruncatedAmount();
    return this.equals(truncated);
  }

}
