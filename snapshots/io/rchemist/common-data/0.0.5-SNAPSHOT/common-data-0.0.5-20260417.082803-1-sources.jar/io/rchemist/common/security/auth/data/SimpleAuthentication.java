/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */package io.rchemist.common.security.auth.data;

import io.rchemist.common.util.type.SiteType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class SimpleAuthentication implements Serializable {

  public SimpleAuthentication(boolean anonymous, String loginName, SiteType siteType, String userId,
    String userName,
    String tenantAlias, String siteAlias,
    Collection<String> authorities) {
    this.anonymous = anonymous;
    this.loginName = loginName;
    this.siteType = siteType;
    this.userId = userId;
    this.userName = userName;
    this.tenantAlias = tenantAlias;
    this.siteAlias = siteAlias;
    this.authorities = authorities;
  }

  private final boolean anonymous;
  private final String loginName;   // 로그인 아이디
  private final SiteType siteType;
  private final String userId;    // 내부 관리용 userId
  private final String tenantAlias;
  private final String siteAlias;
  private final String userName;    // name
  private final Collection<String> authorities;

  public List<String> getRoles(){
    return new ArrayList<>(CollectionUtils.emptyIfNull(authorities));
  }

  public boolean isAnonymous(){
    return userId == null;
  }

  public boolean validateTenant(String tenantAlias, String siteAlias){
    return StringUtils.equals(this.tenantAlias, tenantAlias)
      && StringUtils.equals(this.siteAlias, siteAlias);
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
      .append("loginName", loginName)
      .append("siteType", siteType)
      .append("userId", userId)
      .append("tenantAlias", tenantAlias)
      .append("siteAlias", siteAlias)
      .append("authorities", authorities)
      .toString();
  }

  /**
   * 열거한 role 중 하나라도 없으면 false
   * @param roles
   * @return
   */
  public boolean hasRole(String... roles){
    if(roles == null || ArrayUtils.isEmpty(roles)){
      return true;
    }else{
      // 조건을 만족하는 role 이 하나라도 없으면 false
      for(String role : roles){
        if (!getRoles().contains(role)) {
          return false;
        }
      }
      return true;
    }
  }

  /**
   * 열거한 role 중 하나라도 있으면 true
   * @param roles
   * @return
   */
  public boolean hasAnyRole(String... roles){
    if(roles == null || ArrayUtils.isEmpty(roles)){
      return true;
    }else{
      for(String role : roles){
        if (getRoles().contains(role)) {
          return true;
        }
      }
      return false;
    }
  }

  public boolean hasAuthorities(String ...authorities) {
    if (CollectionUtils.isEmpty(this.authorities)) {
      return false;
    }
    return (CollectionUtils.containsAny(this.authorities, authorities));
  }

}
