/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation.dto;

import java.io.Serializable;
import javassist.bytecode.annotation.AnnotationMemberValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
public class AttributeMemberValue implements Serializable {

  protected String name;

  protected Class<?> typeClass;

  protected String typeName;

  protected String key;

  protected String cacheName;

  protected String getter;

  protected String setter;

  public AttributeMemberValue(AnnotationMemberValue value){
    try {
      this.name = getAnnotationStringValue(value, "name", null);
      this.typeClass = Class.forName(StringUtils.substringBeforeLast(value.getValue().getMemberValue("typeClass").toString(), ".class"));
      this.typeName = typeClass.getTypeName();
      this.cacheName = getAnnotationStringValue(value, "cacheName", "rcmStandardElements");
      this.key = getAnnotationStringValue(value, "key", "key");
      this.getter = "get" + StringUtils.capitalize(name);
      this.setter = "set" + StringUtils.capitalize(name);

    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }

  /**
   * annotation 에서 String 값 꺼내기
   * @param value
   * @param name
   * @param defaultString
   * @return
   */
  protected static String getAnnotationStringValue(AnnotationMemberValue value, String name, String defaultString){
    if(value.getValue().getMemberValue(name) != null){
      return value.getValue().getMemberValue(name).toString();
    }
    return defaultString;
  }

}
