/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.annotation.ViewTab;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.presentation.type.TabEnumType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasTenantAlias.class)
@Getter
@Setter
public class HasTenantAliasImpl implements EnhancedTemplate {

  @AdminField(name = "TenantAliasImpl_TenantAlias", order = 1
      , hidden = true
      , fieldType = PresentationFieldType.STRING
      , modifiableType = ModifiableType.MODIFY_ONLY
      , tab = @ViewTab(type = TabEnumType.STATUS)
      , group = @ViewFieldGroup(type = GroupEnumType.STATUS)
  )
  protected String tenantAlias;

}
