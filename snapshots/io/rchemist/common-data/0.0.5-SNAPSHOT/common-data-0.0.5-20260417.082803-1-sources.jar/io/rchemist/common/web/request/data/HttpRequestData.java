/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Data;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Data
public class HttpRequestData implements Serializable {
  private final Map<String, String> headers = new LinkedHashMap<>();
  private final Map<String, String[]> parameters = new LinkedHashMap<>();
  protected boolean secure;
  private String body;
  private String method;
  private String requestURL;
  private String queryString;

  public HttpRequestData withHeaders(Map<String, String> headers) {
    if (MapUtils.isNotEmpty(headers)) {
      this.headers.putAll(headers);
    }
    return this;
  }

  public HttpRequestData withParameters(
      Map<String, String[]> parameters) {
    if (MapUtils.isNotEmpty(parameters)) {
      this.parameters.putAll(parameters);
    }
    return this;
  }

  public HttpRequestData withBody(String body) {
    this.body = body;
    return this;
  }

  public HttpRequestData addParameter(String key, String value) {
    this.parameters.put(key, new String[]{value});
    return this;
  }

  public HttpRequestData addParameter(String key, String[] values) {
    this.parameters.put(key, values);
    return this;
  }

  public HttpRequestData addHeader(String key, String value) {
    this.headers.put(key, value);
    return this;
  }

  public HttpRequestData withMethod(String method) {
    this.method = method;
    return this;
  }

  public HttpRequestData withRequestURL(String requestURL) {
    this.requestURL = requestURL;
    return this;
  }

  public HttpRequestData withQueryString(String queryString) {
    this.queryString = queryString;
    return this;
  }

  public HttpRequestData withSecure(boolean secure) {
    this.secure = secure;
    return this;
  }
}
