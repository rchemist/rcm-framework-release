/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.money.Money;
import io.rchemist.common.persistence.domain.template.presentation.HasMarketingMessage;
import io.rchemist.common.persistence.domain.type.AdjustmentType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class AdjustmentItem implements HasMarketingMessage<AdjustmentItem> {

  public AdjustmentItem(AdjustmentType adjustmentType, BigDecimal amount) {
    this(adjustmentType, amount, Money.getDefaultRoundingMode());
  }

  public AdjustmentItem(AdjustmentType adjustmentType, BigDecimal amount, RoundingMode roundingMode) {
    this(adjustmentType, amount, roundingMode, true);
  }

  public AdjustmentItem(AdjustmentType adjustmentType, BigDecimal amount, RoundingMode roundingMode, boolean applyToSalePrice) {
    this(adjustmentType, amount, roundingMode, applyToSalePrice, null, null, null, null);
  }

  public AdjustmentItem(AdjustmentType adjustmentType, BigDecimal amount, RoundingMode roundingMode, boolean applyToSalePrice, String referencedId, String version, String marketingMessage, String marketingLink) {
    this.adjustmentType = adjustmentType;
    this.amount = amount;
    this.roundingMode = roundingMode;
    this.applyToSalePrice = applyToSalePrice;
    this.referencedId = referencedId;
    this.version = version;
    setMarketingMessage(marketingMessage);
    setMarketingLink(marketingLink);
  }

  private final AdjustmentType adjustmentType;

  private final BigDecimal amount;

  private final RoundingMode roundingMode;

  private final boolean applyToSalePrice;

  @Setter(AccessLevel.PRIVATE)
  private BigDecimal discountedAmount = BigDecimal.ZERO;

  @Setter(AccessLevel.PRIVATE)
  private boolean discounted = false;

  // 할인 설정의 entity id - Discount, Offer, ...
  private String referencedId;

  // 할인 설정에 대한 버전 정보
  private String version;

  public AdjustmentItem withVersion(String version) {
    this.version = version;
    return this;
  }

  public AdjustmentItem withReferencedId(String referencedId) {
    this.referencedId = referencedId;
    return this;
  }

  public void validate() {
    if (adjustmentType == null || amount == null) {
      throw new IllegalArgumentException("adjustmentType and amount cannot be null");
    }

    if (adjustmentType.isShouldAmountLess100() && new Money(amount).greaterThanOrEqual(new Money(100))) {
      throw new IllegalArgumentException("amount should be less than 100");
    }
  }

  public Money applyAndGetResult(Money retailPrice, Money salePrice) {
    boolean alreadyDiscounted = salePrice != null && !salePrice.isZero() && salePrice.lessThan(retailPrice);

    if (alreadyDiscounted && !applyToSalePrice) {
      this.discountedAmount = BigDecimal.ZERO;
      return salePrice;
    }

    Money finalPrice = alreadyDiscounted ? salePrice : retailPrice;

    if (finalPrice.lessThanOrEqual(Money.ZERO)) {
      return finalPrice;
    }

    Money appliedAmount = new Money();

    if (adjustmentType.equals(AdjustmentType.ADD_PERCENT)) {
      appliedAmount = finalPrice.rate(amount.doubleValue(), roundingMode);
      finalPrice = finalPrice.add(appliedAmount);
    } else if (adjustmentType.equals(AdjustmentType.OFF_PERCENT)) {
      appliedAmount = finalPrice.rate(amount.doubleValue(), roundingMode);
      finalPrice = finalPrice.subtract(appliedAmount);
    } else if (adjustmentType.equals(AdjustmentType.ADD_AMOUNT)) {
      appliedAmount = new Money(amount);
      finalPrice = finalPrice.add(appliedAmount);
    } else if (adjustmentType.equals(AdjustmentType.OFF_AMOUNT)) {
      appliedAmount = new Money(amount);
      finalPrice = finalPrice.subtract(appliedAmount);
    } else if (adjustmentType.equals(AdjustmentType.FIXED_PRICE)) {
      appliedAmount = new Money(amount);
      finalPrice = new Money(appliedAmount);
    }

    if (finalPrice.lessThan(Money.ZERO)) {
      // finalPrice 가 음수가 나온다면 finalPrice 는 ZERO 로 맞추고 차액을 appliedAmount 로 보정한다.
      Money subtracted = Money.ZERO.subtract(finalPrice.abs());
      finalPrice = finalPrice.add(subtracted);
      appliedAmount = appliedAmount.subtract(subtracted);
    }

    this.discountedAmount = appliedAmount.getAmount();
    this.discounted = true;

    return finalPrice;
  }

}