/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.web.request.data.sort.SortEntry;
import io.rchemist.common.web.service.type.EntityViewType;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface SearchFormWrapper<S> extends Serializable {

  String NULL_VALUE = "NULL";
  String CUSTOM_FIELD_SEARCH_PREFIX = "CUSTOM_FIELD||";

  Integer getPage();
  void setPage(Integer page);

  Integer getPageSize();
  void setPageSize(Integer pageSize);

  Integer getTotalPage();
  void setTotalPage(Integer totalPage);

  Integer getTotalCount();
  void setTotalCount(Integer totalCount);

  /**
   * 정렬 정보 반환
   * 동일 필드에 대해 여러 개의 정렬 조건을 저장할 수 있다.
   * @return List<SortEntry> - 정렬 항목 목록
   */
  List<SortEntry> getSorts();

  /**
   * 정렬 정보 설정
   * @param sortEntries 설정할 정렬 항목 목록
   */
  void setSorts(List<SortEntry> sortEntries);

  /**
   * 정렬 정보를 String 배열로 반환
   * @return String[] - 정렬 정보 배열
   */
  String[] getSortArray();

  /**
   * Spring Data Sort 생성 (기본 정렬 조건 포함)
   * Hibernate Search 등에서 사용
   * @param defaultSortProperty 기본 정렬 필드
   * @param defaultDirection 기본 정렬 방향
   * @return Sort 객체
   */
  Sort getSort(String defaultSortProperty, Direction defaultDirection);

  boolean isIgnoreCache();

  boolean isShouldReturnEmpty();

  /**
   * 이 검색이 AND 인지 OR 인지
   * @return
   */
  ConditionOperatorType getOperator();

  /**
   * 특정 프로퍼티의 검색값을 리턴
   * @param propertyName
   * @return
   */
  Object getValue(String propertyName);

  /**
   * 동일한 property에 대해 여러 filter 가 있을 수 있다. 대상을 좁혀야 할 경우에는 이 메소드를 사용한다.
   * @param operatorType
   * @param conditionType
   * @param propertyName
   * @return
   */
  Object getValue(ConditionOperatorType operatorType, QueryConditionType conditionType, String propertyName);

  /**
   * 특정 프로퍼티의 검색값을 String 으로 변환해 리턴, EnumType 이 value 로 저장된 경우에도 해당 값을 type 으로 변환해 String 만 리턴한다.
   * @param propertyName
   * @return
   */
  default String getSearchValue(String propertyName) {
    try {

      String realPropertyName = propertyName;

      if (StringUtils.startsWith(propertyName, CUSTOM_FIELD_SEARCH_PREFIX)) {
        realPropertyName = StringUtils.substringAfter(propertyName, CUSTOM_FIELD_SEARCH_PREFIX);
      }

      Object value = getValue(realPropertyName);

      if (value instanceof EnumType<?>) {
        Class<?> typeClass = value.getClass();
        Method method = typeClass.getMethod("getType");
        return (String) method.invoke(value);
      }

      if (value == null)
        return "";

      return String.valueOf(value);

    } catch (Exception e) {
      e.printStackTrace();
      return "";
    }
  }

  /**
   * 특정 프로퍼티의 검색값을 String 으로 변환해 리턴
   * @param propertyName
   * @return
   */
  String getSafeSearchValue(String propertyName);

  /**
   * like 검색을 할지 equal 검색을 할지 여부
   * @return
   */
  boolean isExactMatch();

  /**
   * 통합 검색용 문자열
   * @return
   */
  String getSearchTerm();

  /**
   * 특정 ID 만 검색하려는 경우
   * @return
   */
  Long[] getSearchIds();

  default boolean isForceFetchFromDB() {
    return false;
  }

  S deepCopy(boolean removeRequestOnlyValue);

  /**
   * SearchContext 에서 cacheKey 를 생성할 때 사용하는 값
   * @return
   */
  String getCacheKey();

  EntityViewType getEntityViewType();

  /**
   * SearchForm 에 대한 선택적 확장 로직을 처리하기 위해 Map 필드를 제공한다.
   * 이 값에 필요한 정보를 임의로 넣고 확장 로직을 처리할 수 있다.
   * 단, 이 값은 Server Side 에서만 존재하며, @JsonIgnore 처리해야 한다.
   * @return
   */
  @JsonIgnore
  Map<String, Object> getAdditionalContext();

  void setAdditionalContext(Map<String, Object> additionalContext);

  @JsonIgnore
  default S withAdditionalContext(Map<String, Object> additionalContext) {
    setAdditionalContext(additionalContext);
    return (S) this;
  }

  @JsonIgnore
  default S addAdditionalContext(String key, Object value) {
    Map<String, Object> additionalContext = getAdditionalContext();
    if (additionalContext == null) {
      additionalContext = new LinkedHashMap<>();
    }
    additionalContext.put(key, value);
    setAdditionalContext(additionalContext);
    return (S) this;
  }

}
