/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface HasRestrictCount<T> extends ClassTransformTarget {

  /**
   * 이 리워드를 누적으로 최대 몇번까지 실행할 수 있는지
   */
  default Integer getMaxCount(){
    throw new ClassTransformException();
  }
  default void setMaxCount(Integer maxCount){throw new ClassTransformException();}

  /**
   * 매일 최대 몇번까지 실행할 수 있는지
   * MaxCount 는 전체 기간의 누적이고, maxCountPerDay 는 매일 갱신되는 숫자값이다
   * 만약 이 값이 maxCount 보다 크다면, 이 설정을 무시하고 maxCount 가 리턴된다.
   * @return
   */
  default Integer getMaxCountPerDay() {
    throw new ClassTransformException();
  }
  default void setMaxCountPerDay(Integer maxCountPerDay) {
    throw new ClassTransformException();
  }

  /**
   * 고객 별로 최대 몇번까지 누적해 적용할 수 있는지
   * 만약 이 값이 maxCount 보다 크다면, 이 설정을 무시하고 maxCount 가 리턴된다.
   * 만약 이 값이 비어 있다면 null 을 리턴하고, 관련 서비스 에서 고객 당 적용 횟수 체크 부분을 skip 한다
   * @return
   */
  default Integer getMaxCountPerCustomer() {
    throw new ClassTransformException();
  }
  default void setMaxCountPerCustomer(Integer maxCountPerCustomer) {
    throw new ClassTransformException();
  }

  /**
   * 고객 별로 하루 최대 몇번까지 누적해 적용할 수 있는지
   * 만약 이 값이 maxCountPerDay 보다 크다면 이 설정을 무시하고 maxCountPerDay 가 리턴된다.
   * 만약 이 값이 maxCountPerCustomer 보다 크다면, 이 설정을 무시하고 maxCountPerCustomer 와 maxCountPerDay 중 더 작은 값이 리턴된다.
   * 만약 이 값이 비어 있다면 null 을 리턴하고, 관련 서비스 에서 고객 당 하루 적용 횟수 체크 부분을 skip 한다
   * @return
   */
  default Integer getMaxCountPerCustomerPerDay() {
    throw new ClassTransformException();
  }
  default void setMaxCountPerCustomerPerDay(Integer maxCountPerCustomerPerDay) {
    throw new ClassTransformException();
  }

  default T withMaxCount(Integer maxCount) {
    setMaxCount(maxCount);
    return (T) this;
  }

  default T withMaxCountPerDay(Integer maxCountPerDay) {
    setMaxCountPerDay(maxCountPerDay);
    return (T) this;
  }

  default T withMaxCountPerCustomer(Integer maxCountPerCustomer) {
    setMaxCountPerCustomer(maxCountPerCustomer);
    return (T) this;
  }

  default T withMaxCountPerCustomerPerDay(
      Integer maxCountPerCustomerPerDay) {
    setMaxCountPerCustomerPerDay(maxCountPerCustomerPerDay);
    return (T) this;
  }

}
