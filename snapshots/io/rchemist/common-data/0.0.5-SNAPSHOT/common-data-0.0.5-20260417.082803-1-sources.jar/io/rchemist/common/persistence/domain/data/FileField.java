/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.data;

import io.rchemist.common.util.ArrayUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class FileField implements Serializable {

  protected List<FileInfo> existFiles = new ArrayList<>();
  protected List<FileInfo> newFiles = new ArrayList<>();
  protected List<FileInfo> deleteFiles = new ArrayList<>();

  public boolean isEmpty() {
    return CollectionUtils.isEmpty(existFiles)
        && CollectionUtils.isEmpty(newFiles)
        && CollectionUtils.isEmpty(deleteFiles);
  }

  public FileField addNewFile(FileInfo fileInfo) {
    List<FileInfo> newFiles = getNewFiles();
    if (newFiles == null) {
      newFiles = new ArrayList<>();
    }
    newFiles.add(fileInfo);
    setNewFiles(newFiles);
    return this;
  }

  public FileField addDeleteFile(FileInfo fileInfo) {
    List<FileInfo> deleteFiles = getDeleteFiles();
    if (deleteFiles == null) {
      deleteFiles = new ArrayList<>();
    }
    deleteFiles.add(fileInfo);
    setDeleteFiles(deleteFiles);
    return this;
  }

  public FileField addExistFile(FileInfo fileInfo) {
    List<FileInfo> existFiles = getExistFiles();
    if (existFiles == null) {
      existFiles = new ArrayList<>();
    }
    existFiles.add(fileInfo);
    setExistFiles(existFiles);
    return this;
  }

  public FileField withExistFiles(List<FileInfo> existFiles) {
    setExistFiles(existFiles);
    return this;
  }

  public FileField withNewFiles(List<FileInfo> newFiles) {
    setNewFiles(newFiles);
    return this;
  }

  public FileField withDeleteFiles(List<FileInfo> deleteFiles) {
    setDeleteFiles(deleteFiles);
    return this;
  }

  public static FileField fromExistFile(String... fileUrls) {
	  FileField fileField = new FileField();
    List<FileInfo> existFiles = FileInfo.createFileInfoList(fileUrls);
    fileField.setExistFiles(existFiles);
	  return fileField;
  }

  public String getFirstNewAssetUrl() {
    return ArrayUtil.getFirstElement(getNewAssetUrls());
  }

  public String getFirstDeleteAssetUrl() {
    return ArrayUtil.getFirstElement(getDeletedAssetUrls());
  }

  public String getFirstExistAssetUrl() {
    return ArrayUtil.getFirstElement(getExistAssetUrls());
  }

  public String[] getNewAssetUrls() {
    return getAssetUrlInFileInfo(newFiles);
  }

  public String[] getExistAssetUrls() {
    return getAssetUrlInFileInfo(existFiles);
  }

  public String[] getDeletedAssetUrls() {
    return getAssetUrlInFileInfo(deleteFiles);
  }

  private static String[] getAssetUrlInFileInfo(List<FileInfo> fileInfos) {
    List<String> assetUrl = new ArrayList<>();
    for (FileInfo fileInfo : CollectionUtils.emptyIfNull(fileInfos)) {
      assetUrl.add(fileInfo.getUrl());
    }
    return assetUrl.toArray(new String[0]);
  }


}
