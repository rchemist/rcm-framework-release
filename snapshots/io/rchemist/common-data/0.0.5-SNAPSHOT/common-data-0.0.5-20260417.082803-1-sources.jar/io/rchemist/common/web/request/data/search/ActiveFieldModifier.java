/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.persistence.query.type.QueryConditionType;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.LinkedHashMap;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class ActiveFieldModifier implements SearchFieldModifier {

  @Override
  public FilterItem validate(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    if (request.isSubFilter()) {
      return filterItem;
    }

    if (filterItem.getFieldType() != null) {

      Class<?> fieldType = filterItem.getFieldType();

      if (StringUtils.equals(filterItem.getName(), "active") && fieldType.equals(Boolean.class)) {

        boolean active;

        if (filterItem.getValue() != null) {
          active = BooleanUtils.toBoolean(filterItem.getValue().toString());
        } else {
          active = true;
        }

        if (active) {
          // active === true 로 검색할 때는 false 가 아닌 것만 찾으면 된다.
          filterItem.withQueryConditionType(QueryConditionType.EQUAL);
          filterItem.setValue(null);

          LinkedHashMap<ConditionOperatorType, FilterItem[]> subFilters = new LinkedHashMap<>();

          subFilters.put(ConditionOperatorType.AND,
              new FilterItem[]{FilterItem.isNullOrEquals("active", true)});

          filterItem.setSubFilters(subFilters);

        }
      }

    }

    return filterItem;
  }

  @Override
  public int getOrder() {
    return 100;
  }
}
