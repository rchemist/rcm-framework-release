/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.Serializable;
import java.util.Objects;
import lombok.Getter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class UniqueColumn implements Serializable {

  private final String columnName;

  private final String propertyName;

  public UniqueColumn(String columnName, String propertyName) {
    this.columnName = columnName;
    this.propertyName = propertyName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof UniqueColumn)) {
      return false;
    }
    UniqueColumn that = (UniqueColumn) o;
    return Objects.equals(getColumnName(), that.getColumnName())
        && Objects.equals(getPropertyName(), that.getPropertyName());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getColumnName(), getPropertyName());
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this)
        .append("columnName", columnName)
        .append("propertyName", propertyName)
        .toString();
  }
}
