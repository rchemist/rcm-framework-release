/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.query.type.ConditionOperatorType;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class ValidateSearchForm {

  /*private ValidateSearchForm() {
    this.searchFieldModifiers = new ArrayList<>();
    this.searchFieldModifiers.add(new FieldTypeValueModifier());
    this.searchFieldModifiers.add(new AuditFieldModifier());
    this.searchFieldModifiers.add(new EntityAttributeFieldModifier());
    this.searchFieldModifiers.add(new ActiveFieldModifier());

    // sort this.action by order
    Collections.sort(this.searchFieldModifiers, Comparator.comparing(SearchFieldModifier::getOrder));

    this.sortFieldModifiers = new ArrayList<>();
    this.sortFieldModifiers.add(new AuditFieldModifier());
    this.sortFieldModifiers.add(new EntityAttributeFieldModifier());
  }*/

  private static ValidateSearchForm validateSearchForm;

  public ValidateSearchForm(List<SearchFieldModifier> searchFieldModifiers,
      List<SortFieldModifier> sortFieldModifiers) {
    this.searchFieldModifiers = searchFieldModifiers;
    this.sortFieldModifiers = sortFieldModifiers;
  }

  private static ValidateSearchForm getInstance(){
    if(validateSearchForm == null){
      validateSearchForm = ApplicationContextHolder.getBean(ValidateSearchForm.class);
    }

    return validateSearchForm;
  }

  public static FilterItem validate(ModifyFilterRequest request){
    return getInstance().validateItem(request);
  }

  protected final List<SearchFieldModifier> searchFieldModifiers;


  protected final List<SortFieldModifier> sortFieldModifiers;

  public static FilterItem transform(ModifyFilterRequest request) {
    return getInstance().transformItem(request);
  }

  public static ModifiedResult validateSorts(ModifySortRequest request) {
    return getInstance().validateSortItem(request);
  }

  private FilterItem transformItem(ModifyFilterRequest request) {
    FilterItem filterItem = request.getFilterItem();
    for (SearchFieldModifier action : CollectionUtils.emptyIfNull(searchFieldModifiers)) {
      if (action.isAvailable()) {
        filterItem = action.transform(request);
      }
    }

    for (SearchFieldModifier action : CollectionUtils.emptyIfNull(request.getSearchFieldModifiers())) {
      if (action.isAvailable()) {
        filterItem = action.transform(request);
      }
    }

    if (filterItem.hasSubFilters()) {
      for (ConditionOperatorType operatorType : filterItem.getSubFilters().keySet()) {
        List<FilterItem> subFilterItems = new ArrayList<>();
        Iterator<FilterItem> items = Arrays.stream(filterItem.getSubFilters().get(operatorType)).iterator();
        while (items.hasNext()) {
          FilterItem subFilterItem = items.next();
          ModifyFilterRequest subRequest = new ModifyFilterRequest(request.getEntityBean(), subFilterItem, request.isHibernateSearch());
          subFilterItems.add(transformItem(subRequest));
        }
        filterItem.getSubFilters().put(operatorType, subFilterItems.toArray(new FilterItem[0]));
      }
    }

    return filterItem;
  }

  private FilterItem validateItem(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    for (SearchFieldModifier action : CollectionUtils.emptyIfNull(searchFieldModifiers)) {
      filterItem = action.validate(request);
    }

    for (SearchFieldModifier action : CollectionUtils.emptyIfNull(request.getSearchFieldModifiers())) {
      filterItem = action.validate(request);
    }

    for (ConditionOperatorType operatorType : filterItem.getSubFilters().keySet()) {
      List<FilterItem> subFilterItems = new ArrayList<>();
      Iterator<FilterItem> items = Arrays.stream(filterItem.getSubFilters().get(operatorType)).iterator();
      while (items.hasNext()) {
        FilterItem subFilterItem = items.next();
        ModifyFilterRequest subRequest = new ModifyFilterRequest(request.getEntityBean(), subFilterItem, request.isHibernateSearch(), true);
        subFilterItems.add(validateItem(subRequest));
      }
      filterItem.getSubFilters().put(operatorType, subFilterItems.toArray(new FilterItem[0]));
    }

    return filterItem;

  }

  private ModifiedResult validateSortItem(ModifySortRequest request) {

    for (SortFieldModifier action : CollectionUtils.emptyIfNull(sortFieldModifiers)) {
      request = action.modifySorts(request);
    }

    for (SortFieldModifier action : CollectionUtils.emptyIfNull(request.getSortFieldModifiers())) {
      request = action.modifySorts(request);
    }

    ModifiedResult result = new ModifiedResult()
        .withFilters(request.getFilters())
        .withSortEntries(request.getSortEntries());

    return result;
  }

}
