/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.search.data.query;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort.Direction;

/**
 * TODO SortProperty 적용 필요
 * 기존 spring 의 Pageable 을 지원하기 위해 searchForm.sort 를 String 으로 관리했다.
 * 하지만 지금은 QuerySpecification 을 사용하기 때문에 sort 정보를 string 으로 저장하고 이를 parsing 하느라 자원을 허비할 필요가 없다.
 * searchForm 이 셋팅될 때 SortProperty 를 생성하도록 코드를 변경해야 한다.
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class SortProperty implements Serializable {

  public SortProperty(String property) {
    this.property = property;
    this.fullPath = property;
    this.direction = Direction.DESC;
  }

  public SortProperty(String property, Direction direction) {
    this.property = property;
    this.fullPath = property;
    this.direction = direction;
  }

  public SortProperty(String property, String fullPath, Direction direction) {
    this.property = property;
    this.fullPath = fullPath;
    this.direction = direction;
  }

  private final String property;

  @Setter
  private String fullPath;

  private final Direction direction;

}
