/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search;

import io.rchemist.common.web.request.data.FilterItem;
import java.time.Instant;
import java.time.ZoneId;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component
public class ApplyTimeZoneModifier implements SearchFieldModifier {

  @Value("${platform.config.search.timezone.use: true}")
  private boolean useTimeZone = true;

  @Value("${platform.config.search.timezone.default:Asia/Seoul}")
  private String defaultTimeZone = "Asia/Seoul";

  @Override
  public boolean isAvailable() {
    return useTimeZone;
  }

  @Override
  public FilterItem validate(ModifyFilterRequest request) {

    FilterItem filterItem = request.getFilterItem();

    if (filterItem.getQueryConditionType() == null || filterItem.getQueryConditionType().isNoValue()) {
      // NULL,NOT_NULL 과 같이 값이 없는 경우 처리하지 않는다.
      return filterItem;
    }

    if (filterItem.getFieldType() != null) {
      Class<?> fieldType = filterItem.getFieldType();

      if (fieldType.equals(Instant.class)) {

        boolean multipleTarget = filterItem.isMultipleFilterValue();

        boolean singleTarget = filterItem.isStrictSingleFilterValue();

        boolean target = (multipleTarget || singleTarget) &&
            filterItem.getFieldType() != null &&
            (filterItem.getValue() != null || ArrayUtils.isNotEmpty(filterItem.getValues()));

        if (target) {

          if (multipleTarget) {
            // values 의 값을 변환해야 한다.

            Instant value1 = (Instant) filterItem.getValues()[0];
            Instant value2 = (Instant) filterItem.getValues()[1];

            filterItem.setValues(new Object[]{applyTimeZone(value1), applyTimeZone(value2)});

          } else {
            // value 의 값을 변환해야 한다.

            Instant value = (Instant) filterItem.getValue();
            filterItem.setValue(applyTimeZone(value));

          }

        }

      } else {
        return filterItem;
      }

    }

    return filterItem;
  }

  private Instant applyTimeZone(Instant value) {
    if (value == null)
      return null;
    // 타임존을 적용한 새로운 Instant 값을 찾아야 한다.
    // 예를 들어 현재 넘어 온 요청값이 2024-01-28T23:59:59.999Z 라면
    // defaultTimeZone 의 타임존을 적용해 +9 시간을 추가해야 한다.
    // defaultTimeZone의 타임존을 적용한 Instant
    ZoneId timeZone = ZoneId.of(defaultTimeZone);
    return value.atZone(timeZone).toInstant();
  }

  @Override
  public int getOrder() {
    // DateTimeValueModifier 바로 뒤에 동작해야 한다.
    return DateTimeValueModifier.ORDER + 1;
  }
}
