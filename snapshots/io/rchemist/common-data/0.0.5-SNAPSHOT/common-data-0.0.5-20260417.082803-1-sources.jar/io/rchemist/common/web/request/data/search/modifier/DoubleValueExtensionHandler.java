/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.web.request.data.search.modifier;

import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.web.request.data.FilterItem;
import java.util.Arrays;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = FieldTypeValueModifierExtensionManager.BEAN_NAME, priority = 300)
public class DoubleValueExtensionHandler implements FieldTypeValueModifierExtensionHandler{

  @Override
  public Class<?> getAssignableClass() {
    return Double.class;
  }

  @Override
  public void modifyValue(FilterItem item) {
    if (item.hasSingleValue()) {
      item.setValue(Double.parseDouble(String.valueOf(item.getValue())));
    } else if (item.hasMultipleValues()) {
      item.setValues(Arrays.stream(item.getValues()).map(v -> Double.parseDouble(String.valueOf(v))).toArray());
    }
  }
}
