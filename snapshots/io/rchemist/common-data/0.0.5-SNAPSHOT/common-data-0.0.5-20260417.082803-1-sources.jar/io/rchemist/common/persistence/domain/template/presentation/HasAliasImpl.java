/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.ModifiableType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import io.rchemist.common.util.type.RegexType.Regex;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@TemplateClass(value = HasAlias.class)
public class HasAliasImpl implements EnhancedTemplate {

  @AdminField(name = "AliasImpl_Alias", order = 110, fieldType = PresentationFieldType.STRING, required = true, helpText = "AliasImpl_Alias_HelpText"
      , regexValidation = Regex.NUMBER_ENGLISH_EXT, errorMessage = "AliasImpl_Alias_ErrorMessage", modifiableType = ModifiableType.ADD_ONLY
      , createForm = @CreateForm(type = CreateFormType.REQUIRED, order = 110))
  protected String alias;

}
