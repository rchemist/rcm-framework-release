/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.template.ClassTransformTarget;
import io.rchemist.common.persistence.domain.template.exception.ClassTransformException;
import java.time.Instant;

/**
 * <p>
 * project : rcm-framework
 * Xref 매핑을 할 때 target entity 의 view 를 override 하게 될 때 원본 데이터의 id 와 createdAt 을 유지하기 위해 사용한다.
 * <p>
 * Created by kunner
 **/
public interface HasXrefMappingView<T> extends ClassTransformTarget {

  default String getOriginId() {
    throw new ClassTransformException();
  }

  default void setOriginId(String originId) {
    throw new ClassTransformException();
  }

  default T withOriginId(String originId) {
    setOriginId(originId);
    return (T) this;
  }

  default Instant getXrefAt() {
    throw new ClassTransformException();
  }

  default void setXrefAt(Instant xrefAt) {
    throw new ClassTransformException();
  }

  default T withXrefAt(Instant xrefAt){
    setXrefAt(xrefAt);
    return (T) this;
  }

}
