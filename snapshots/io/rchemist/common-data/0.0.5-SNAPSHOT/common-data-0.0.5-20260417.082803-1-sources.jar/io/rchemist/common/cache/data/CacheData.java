/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.cache.data;

import io.rchemist.common.persistence.domain.annotation.TimeLimited;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class CacheData implements Serializable, TimeLimited {

  private CacheData(){
    this.limitMinutes = 60;
  }

  public CacheData(Integer limitMinutes) {
    this.limitMinutes = limitMinutes;
    this.versionId = createVersionId();
  }

  @Setter(AccessLevel.PRIVATE)
  protected String versionId;

  protected final Integer limitMinutes;

  protected final LocalDateTime cachedAt = LocalDateTime.now();

  private static String createVersionId(){
    return Timestamp
        .valueOf(LocalDateTime.now()).toString();
  }

}
