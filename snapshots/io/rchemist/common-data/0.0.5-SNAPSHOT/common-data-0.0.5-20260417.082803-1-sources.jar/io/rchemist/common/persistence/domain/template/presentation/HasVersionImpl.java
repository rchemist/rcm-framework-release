/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.documentation.RestDataField;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.persistence.domain.type.PublishStatusType;
import io.rchemist.common.transformer.TemplateClass;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@TemplateClass(HasVersion.class)
@Getter
@Setter
public class HasVersionImpl implements Serializable, EnhancedTemplate {

  @RestDataField(name = "VERSION", description = "현재 데이터의 버전 정보를 저장한다", example = "f01409d7-de6d")
  protected String version;

  @RestDataField(name = "출판 상태", description = "현재 데이터의 출판 상태를 저장한다", example = "PublishStatusType, PUBLISHED|DRAFT|OUT_DATED|DISCARDED")
  protected PublishStatusType publishStatus;

  public PublishStatusType getPublishStatus() {
    return this.publishStatus == null ? PublishStatusType.DRAFT : this.publishStatus;
  }

  public void setPublishStatus(PublishStatusType publishStatus) {
    this.publishStatus = publishStatus == null ? PublishStatusType.DRAFT : publishStatus;
  }

}
