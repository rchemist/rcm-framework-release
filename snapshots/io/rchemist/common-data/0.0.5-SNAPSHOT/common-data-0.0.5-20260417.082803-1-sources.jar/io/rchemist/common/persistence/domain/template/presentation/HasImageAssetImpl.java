/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.template.presentation;

import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.EnhancedTemplate;
import io.rchemist.common.presentation.annotation.AdminField;
import io.rchemist.common.presentation.annotation.CreateForm;
import io.rchemist.common.presentation.annotation.ViewFieldGroup;
import io.rchemist.common.presentation.type.CreateFormType;
import io.rchemist.common.presentation.type.GroupEnumType;
import io.rchemist.common.presentation.type.PresentationFieldType;
import io.rchemist.common.transformer.TemplateClass;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@TemplateClass(value = HasImageAsset.class)
@Getter
@Setter
public class HasImageAssetImpl implements EnhancedTemplate {

  @AdminField(name = "Asset_Url", order = 300
      , fieldType = PresentationFieldType.IMAGE
      , createForm = @CreateForm(type = CreateFormType.REQUIRED)
      , group = @ViewFieldGroup(type = GroupEnumType.ADVANCED))
  private AttachAsset asset = new AttachAsset();

  public String getAssetKey(){return (asset != null) ? asset.getAssetKey() : null;}

  public void setAssetKey(String assetKey){
    initialize();
    asset.setAssetKey(assetKey);
  }

  public String getAssetUrl(){return (asset != null) ? asset.getAssetUrl() : null;}

  public void setAssetUrl(String assetUrl){
    initialize();
    asset.setAssetUrl(assetUrl);
  }

  public Long getFileSize(){return (asset != null) ? asset.getFileSize() : null;}

  public void setFileSize(Long fileSize){
    initialize();
    asset.setFileSize(fileSize);
  }

  public String[] getAssetTags(){
    return (asset != null) ? asset.getAssetTags() : null;
  }

  public void setAssetTags(String[] assetTag){
    initialize();
    asset.setAssetTags(assetTag);
  }

  private void initialize(){
    if(this.asset == null){
      this.asset = new AttachAsset();
    }
  }

}
