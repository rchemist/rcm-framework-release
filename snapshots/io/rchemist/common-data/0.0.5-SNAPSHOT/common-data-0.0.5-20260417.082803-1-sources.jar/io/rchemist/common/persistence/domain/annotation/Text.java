/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.domain.annotation;

import io.rchemist.common.transformer.TextFieldClassTransformer;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 *
 * Longtext 필드 설정이 필요한 경우 프로퍼티에 @Text 를 붙이면 된다.
 * @see {@link TextFieldClassTransformer}
 *
 * :: AS-IS
 * @Column(name = "LONG_TEXT", length = Integer.MAX_VALUE - 1)
 * @Lob
 * @Type(type = "org.hibernate.type.MaterializedClobType")
 * protected String longText;
 *
 * :: TO-BE
 * @Column(name = "LONG_TEXT")
 * @Text
 * protected String longText;
 *
 **/
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Text {
}
