/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@ToString
public class UniqueConstraint implements Serializable {

  private UniqueConstraint(){

  }

  public UniqueConstraint(String propertyName, String columnName, String errorMessage,
      List<UniqueColumn> uniqueColumns) {
    this.propertyName = propertyName;
    this.columnName = columnName;
    this.errorMessage = errorMessage;
    this.uniqueColumns = uniqueColumns;
  }

  private String propertyName;

  private String columnName;

  private String errorMessage;

  // columne name, property name
  private List<UniqueColumn> uniqueColumns = new ArrayList<>();

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof UniqueConstraint)) {
      return false;
    }
    UniqueConstraint that = (UniqueConstraint) o;
    return Objects.equals(getPropertyName(), that.getPropertyName())
        && Objects.equals(getColumnName(), that.getColumnName())
        && Objects.equals(getUniqueColumns(), that.getUniqueColumns());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getPropertyName(), getColumnName(), getUniqueColumns());
  }
}
