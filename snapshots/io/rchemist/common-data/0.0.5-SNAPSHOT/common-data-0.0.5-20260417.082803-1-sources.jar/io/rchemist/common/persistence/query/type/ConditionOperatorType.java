/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.persistence.query.type;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public enum ConditionOperatorType {

  AND(true),
  OR(false),
  INHERITED(false);

  @Getter
  private final boolean must;

  ConditionOperatorType(boolean must) {
    this.must = must;
  }

  @JsonCreator
  public static ConditionOperatorType getInstance(String value) {
    try {
      return ConditionOperatorType.valueOf(value.toUpperCase());
    } catch (IllegalArgumentException e) {
      return ConditionOperatorType.AND;
    }
  }
}

