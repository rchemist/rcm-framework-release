/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.maven;

import java.io.File;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.project.MavenProject;

/**
 * 빌드 시점에 rcm-framework 의 템플릿 기반 바이트코드 변환을 수행한다.
 *
 * <p>0.0.5 에서는 <b>스켈레톤 상태</b>이다. 실제 변환 로직 이식은 후속 단계(같은 0.0.5 내
 * 작업) 범위이며, 현재는 런타임 Javassist 변환이 그대로 동작한다. 이 Mojo 는 파이프라인에
 * 안전하게 합류하도록 빌드 등록과 관측(로그) 수준만 제공한다.</p>
 *
 * <p>이식이 완료되면 execute() 는 다음을 수행한다:</p>
 * <ol>
 *   <li>{@code ${project.build.outputDirectory}} 의 클래스 스캔</li>
 *   <li>{@code ClassTransformTarget} 및 {@code @TemplateClass} 해석</li>
 *   <li>런타임과 동일 규칙의 {@code PlatformClassTransformer} 체인 적용</li>
 *   <li>변환 결과를 디스크에 덮어쓰고 {@code @ClassEnhanced} 마커 부착</li>
 * </ol>
 *
 * @since 0.0.5
 */
@Mojo(
    name = "enhance",
    defaultPhase = LifecyclePhase.PROCESS_CLASSES,
    requiresDependencyResolution = ResolutionScope.COMPILE,
    threadSafe = true
)
public class EnhanceMojo extends AbstractMojo {

  @Parameter(defaultValue = "${project}", readonly = true, required = true)
  private MavenProject project;

  @Parameter(defaultValue = "${project.build.outputDirectory}", readonly = true)
  private File classesDirectory;

  @Parameter(property = "rcm.enhance.skip", defaultValue = "false")
  private boolean skip;

  @Override
  public void execute() throws MojoExecutionException {
    if (skip) {
      getLog().info("rcm-framework class enhancement skipped (rcm.enhance.skip=true).");
      return;
    }

    if (classesDirectory == null || !classesDirectory.isDirectory()) {
      getLog().info("No compiled classes directory found; nothing to enhance.");
      return;
    }

    getLog().info("rcm-framework class enhancement: skeleton only (0.0.5 WIP).");
    getLog().info("  project: " + project.getArtifactId());
    getLog().info("  classes: " + classesDirectory.getAbsolutePath());

    // TODO(0.0.5): Port runtime weaving logic into a Spring-free, static callable
    //              entry point inside common-class-transformer and invoke it here.
    //   1. Build a Javassist ClassPool from project.getCompileClasspathElements()
    //      plus classesDirectory.
    //   2. Scan classesDirectory for ClassTransformTarget implementations and for
    //      classes carrying relevant annotations (@Entity, @Embedded, @Document,
    //      @AdminEntity, @MappedSuperclass, etc.).
    //   3. Resolve TransformCondition map by discovering @TemplateClass markers on
    //      the dependency classpath.
    //   4. Run the PlatformClassTransformer chain in deterministic order.
    //   5. Write each transformed class back to classesDirectory and attach a
    //      @ClassEnhanced annotation (via Javassist's AnnotationsAttribute).
    //   6. Emit a summary line: "enhanced N classes, skipped M, failed 0".
  }
}
