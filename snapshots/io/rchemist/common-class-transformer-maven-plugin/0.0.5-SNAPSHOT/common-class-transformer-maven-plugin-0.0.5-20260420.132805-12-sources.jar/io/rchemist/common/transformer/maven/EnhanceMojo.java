/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.transformer.maven;

import io.rchemist.common.configuration.platform.SearchProvider;
import io.rchemist.common.transformer.BuildTimeClassEnhancer;
import java.io.File;
import java.util.List;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.project.MavenProject;

/**
 * 빌드 시점에 rcm-framework 의 템플릿 기반 바이트코드 변환을 수행한다.
 *
 * <p>{@code ${project.build.outputDirectory}} 의 클래스를 스캔해 {@code ClassTransformTarget}
 * 과 {@code @TemplateClass} 템플릿 해석, 런타임과 동일 규칙의 {@code PlatformClassTransformer}
 * 체인 적용, {@code @ClassEnhanced} 마커 부착까지 한 번에 수행한다.</p>
 *
 * <p>0.0.x 시리즈 동안은 런타임 Javassist 경로가 병존한다. 마커가 부착된 클래스는 런타임에서
 * 즉시 skip 되므로 이중 변환은 발생하지 않는다. 0.1.0 에서 런타임 경로가 완전히 제거된다.</p>
 *
 * @since 0.0.5
 */
@Mojo(
    name = "enhance",
    defaultPhase = LifecyclePhase.PROCESS_CLASSES,
    requiresDependencyResolution = ResolutionScope.TEST,
    threadSafe = true
)
public class EnhanceMojo extends AbstractMojo {

  @Parameter(defaultValue = "${project}", readonly = true, required = true)
  private MavenProject project;

  /**
   * 스캔 대상 클래스 디렉토리. 기본값은 {@code ${project.build.outputDirectory}}
   * (즉 {@code target/classes}). test 전용 엔티티를 변환하려면 두 번째 execution
   * 에서 {@code ${project.build.testOutputDirectory}} 로 override 한다.
   */
  @Parameter(defaultValue = "${project.build.outputDirectory}")
  private File classesDirectory;

  @Parameter(property = "rcm.enhance.skip", defaultValue = "false")
  private boolean skip;

  /**
   * 변환 대상 패키지. 비어 있으면 {@code io.rchemist} 가 기본값.
   */
  @Parameter(property = "rcm.enhance.packages")
  private String[] packages;

  /**
   * {@code HibernateSearchClassTransformer} 에 주입할 provider.
   * {@code HIBERNATE} 또는 {@code QUERY}. 기본값은 {@code QUERY}.
   */
  @Parameter(property = "rcm.enhance.searchProvider", defaultValue = "QUERY")
  private String searchProvider;

  @Override
  public void execute() throws MojoExecutionException {
    if (skip) {
      getLog().info("rcm-framework class enhancement skipped (rcm.enhance.skip=true).");
      return;
    }

    if (classesDirectory == null || !classesDirectory.isDirectory()) {
      getLog().info("No compiled classes directory; nothing to enhance.");
      return;
    }

    // test classpath 는 compile classpath 의 superset 이므로 항상 test 를 쓴다.
    // test-전용 의존이 compile 단계 enhance 결과에 포함되는 것은 해롭지 않다
    // (TemplateClass 스캔과 ClassPool 해석 범위가 넓어질 뿐).
    List<String> classpath;
    try {
      classpath = project.getTestClasspathElements();
    } catch (Exception e) {
      throw new MojoExecutionException("Failed to resolve classpath", e);
    }

    SearchProvider provider;
    try {
      provider = SearchProvider.valueOf(searchProvider.toUpperCase());
    } catch (Exception e) {
      getLog().warn("Unknown searchProvider '" + searchProvider + "', falling back to QUERY");
      provider = SearchProvider.QUERY;
    }

    String[] pkgs = (packages == null || packages.length == 0)
        ? new String[]{"io.rchemist"} : packages;

    getLog().info("rcm-framework enhance: project=" + project.getArtifactId()
        + ", classes=" + classesDirectory.getAbsolutePath()
        + ", packages=" + String.join(",", pkgs)
        + ", searchProvider=" + provider);

    BuildTimeClassEnhancer.Listener listener = new BuildTimeClassEnhancer.Listener() {
      @Override
      public void info(String msg) {
        getLog().info(msg);
      }

      @Override
      public void warn(String msg, Throwable t) {
        if (t == null) {
          getLog().warn(msg);
        } else {
          getLog().warn(msg, t);
        }
      }
    };

    BuildTimeClassEnhancer.Result result = BuildTimeClassEnhancer.enhance(
        classesDirectory, classpath, pkgs, provider, project.getVersion(), listener);

    getLog().info("rcm-framework enhance done: enhanced=" + result.getEnhanced()
        + ", skippedNoTransform=" + result.getSkippedNoTransform()
        + ", skippedAlreadyMarked=" + result.getSkippedAlreadyMarked()
        + ", failed=" + result.getFailed());

    if (result.getFailed() > 0) {
      getLog().warn("Some classes failed to enhance; check preceding WARN messages.");
    }
  }
}
