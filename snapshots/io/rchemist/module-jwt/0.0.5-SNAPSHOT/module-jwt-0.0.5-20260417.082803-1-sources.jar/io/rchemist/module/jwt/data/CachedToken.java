/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.data;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultClaimsBuilder;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class CachedToken extends Token<CachedToken> {

  private static final String[] EXCEPTED_CLAIMS = {"iss", "sub", "aud", "exp", "nbf", "iat", "jti"};

  private String tokenPrefix;

  private String userId;

  private boolean rememberMe;

  private Claims claims = new DefaultClaimsBuilder().build();

  public CachedToken withTokenPrefix(String tokenPrefix) {
    this.tokenPrefix = tokenPrefix;
    return this;
  }

  public CachedToken withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public CachedToken withRememberMe(boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

  public CachedToken withClaims(Map<String, Object> claims) {
    if (this.claims == null) {
      this.claims = new DefaultClaimsBuilder().build();
    }
    if (MapUtils.isNotEmpty(claims)) {
      for (Entry<String, Object> entry : claims.entrySet()) {
        if (isSupportedClaim(entry.getKey())) {
          this.claims.put(entry.getKey(), entry.getValue());
        }
      }
    }
    return this;
  }

  public CachedToken addClaim(String key, Object value) {
    if (isSupportedClaim(key)) {
      this.claims.put(key, value);
    }
    return this;
  }

  public <T> T getClaim(String key, Class<T> type) {
    if (!isSupportedClaim(key)) {
      return null;
    }
    return this.claims.get(key, type);
  }

  public <T> T getClaimValue(String key) {
    if (!isSupportedClaim(key)) {
      return null;
    }
    return (T) this.claims.get(key);
  }

  private boolean isSupportedClaim(String key) {
    return !ArrayUtils.contains(EXCEPTED_CLAIMS, key);
  }

  public String getTokenName() {
    return tokenPrefix + TokenRequest.TOKEN_NAME_SPLITTER + userId;
  }

}
