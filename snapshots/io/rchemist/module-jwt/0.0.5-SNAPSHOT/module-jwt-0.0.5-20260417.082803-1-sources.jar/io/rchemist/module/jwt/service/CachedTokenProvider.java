/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.rchemist.common.cache.CacheConfiguration;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.data.RefreshTokenRequest;
import io.rchemist.module.jwt.data.Token;
import io.rchemist.module.jwt.data.TokenProviderConfig;
import io.rchemist.module.jwt.data.TokenRequest;
import io.rchemist.module.jwt.service.exception.TokenErrorType;
import io.rchemist.module.jwt.service.exception.TokenException;
import io.rchemist.module.jwt.service.extension.TokenProviderExtensionManager;
import io.rchemist.module.jwt.service.type.TokenType;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.cache.Cache;
import javax.crypto.SecretKey;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CachedTokenProvider implements TokenProvider {

  @Getter
  private final Cache<String, CachedToken> tokenCache;

  public static final CacheConfiguration TOKEN_CACHE = new CacheConfiguration("security-cached-token", 100000, 60 * 60 * 24);

  // @Value("${platform.config.security.token.secret:QU0tbzBqYGIraiM=Qy5WW303ajZyJmlPZ2lzSUM2NDppS31pSFwqXGBEcCpkU3o=aU04dkIxW1slKV5cb0hmUms=UlV7QHpY}")
  private final String tokenSecret;

  // @Value("${platform.config.security.access-token.validity:3600000}")
  private final long accessTokenValidity;              // 1시간

  // @Value("${platform.config.security.refresh-token.validity:604800000}")
  private final long refreshTokenValidity;    // 7일

  // @Value("${platform.config.security.remember-me.validity:31536000000}")
  private final long rememberMeValidity;    // 365일

  // @Value("${platform.config.security.prohibit.multi-login:false}")
  private final boolean prohibitMultipleLogin;

  private final TokenProviderExtensionManager extensionManager;

  protected final Key key;

  private static final String AUTHORITIES_KEY = "auth";

  public static final String USER_ID = "USER_ID";
  public static final String PROVIDER = "PROVIDER";
  public static final String PROVIDER_USER_ID = "PROVIDER_USER_ID";

  public CachedTokenProvider(TokenProviderConfig config,
    TokenProviderExtensionManager extensionManager) {
    this.tokenCache = config.getCache();
    this.tokenSecret = config.getTokenSecret();
    this.accessTokenValidity = config.getAccessTokenValidity();
    this.refreshTokenValidity = config.getRefreshTokenValidity();
    this.rememberMeValidity = config.getRememberMeValidity();
    this.prohibitMultipleLogin = config.isProhibitMultipleLogin();
    this.extensionManager = extensionManager;
    byte[] bytes = Decoders.BASE64.decode(tokenSecret);
    this.key = Keys.hmacShaKeyFor(bytes);
  }

  private boolean isCacheEnabled() {
    return tokenCache != null;
  }

  protected void put(String key, CachedToken token) {
    if (isCacheEnabled()) {
      tokenCache.put(key, token);
    }
  }

  protected CachedToken get(String key) {
    if (isCacheEnabled()) {
      return tokenCache.get(key);
    }
    return null;
  }

  protected void remove(String key) {
    if (isCacheEnabled()) {
      tokenCache.remove(key);
    }
  }

  protected void clear() {
    if (isCacheEnabled()) {
      tokenCache.clear();
    }
  }

  public void validate(Claims claims) throws TokenException {

    ExtensionResultHolder<Claims> holder = new ExtensionResultHolder<Claims>().withResult(claims);

    // validate override
    extensionManager.getProxy().postValidate(holder);

  }

  @Override
  public Authentication getAuthentication(TokenType tokenType, String token) throws TokenException {

    ExtensionResultHolder<Authentication> holder = new ExtensionResultHolder<>();
    CachedToken cachedToken = parse(tokenType, token);

    ExtensionResultStatusType status = extensionManager.getProxy().getAuthentication(holder, cachedToken);

    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && holder.getResult() != null) {
      return holder.getResult();
    }

    return null;
  }

  @Override
  public CachedToken parse(TokenType tokenType, String token) throws TokenException {
    try {
      if (StringUtils.isEmpty(token)) {
        throw new TokenException(TokenErrorType.EMPTY_TOKEN);
      }
      Claims claims = parseInternal(token);

      if (tokenType.equals(TokenType.ACCESS_TOKEN)) {
        prohibitMultiLoginIfRequired(token, claims);
      }

      validate(claims);

      String tokenName = claims.getSubject();

      String[] tokenNames = TokenRequest.splitTokenName(tokenName);

      // 캐시 사용 여부에 따라 추가 클레임을 조회해 캐시에 저장한다.

      if (isCacheEnabled()) {

        CachedToken cached = get(tokenName);

        if (cached != null) {
          if (tokenType.equals(TokenType.ACCESS_TOKEN)) {

            if (StringUtils.equals(token, cached.getAccessToken())) {
              // access Token 이 일치하는 경우
              return cached;
            } else {
              // access Token 이 일치하지 않는 경우
              throw new TokenException(TokenErrorType.INVALID_TOKEN);
            }

          } else {
            // refresh Token 인 경우
            if (StringUtils.equals(token, cached.getRefreshToken())) {
              // refresh Token 이 일치하는 경우
              return cached;
            } else {
              // refresh Token 이 일치하지 않는 경우
              throw new TokenException(TokenErrorType.INVALID_TOKEN);
            }
          }
        }

      }

      CachedToken cachedToken = new CachedToken()
          .withTokenPrefix(tokenNames[0])
          .withUserId(tokenNames[1])
          .withRememberMe(isRememberMeClaim(claims))
          .withClaims(claims);

      cachedToken = getOverridedCachedToken(cachedToken);

      if (isCacheEnabled()) {
        put(tokenName, cachedToken);
      }

      return cachedToken;

    } catch (Exception e) {

      TokenErrorType errorType = TokenErrorType.INVALID_TOKEN;

      if (e instanceof ExpiredJwtException) {
        errorType = TokenErrorType.EXPIRED_TOKEN;
      } else if (e instanceof UnsupportedJwtException) {
        errorType = TokenErrorType.UNSUPPORTED_TOKEN_TYPE;
      } else if (e instanceof MalformedJwtException
          || e instanceof io.jsonwebtoken.security.SecurityException) {
        errorType = TokenErrorType.WRONG_SIGNATURE;
      }

      throw new TokenException(errorType);
    }
  }

  protected CachedToken getOverridedCachedToken(CachedToken cachedToken) {
    ExtensionResultHolder<CachedToken> resultHolder = new ExtensionResultHolder<CachedToken>().withResult(
      cachedToken);
    ExtensionResultStatusType resultStatus = extensionManager.getProxy().resultCachedToken(resultHolder);

    if (!resultStatus.equals(ExtensionResultStatusType.NOT_HANDLED)) {
      cachedToken = resultHolder.getResult();
    }
    return cachedToken;
  }

  @Override
  public <T> T getClaimValue(TokenType tokenType, String token, String claimName, Class<T> requiredType) throws TokenException {
    CachedToken claims = parse(tokenType, token);
    return claims.getClaim(claimName, requiredType);
  }

  @Override
  public String getUserId(TokenType tokenType, String token) throws TokenException {
    CachedToken claims = parse(tokenType, token);
    return claims.getUserId();
  }

  private void prohibitMultiLoginIfRequired(String token, Claims claims) throws TokenException {

    String tokenName = claims.getSubject();

    String userId = TokenRequest.getUserIdFromTokenName(tokenName);

    if (userId != null && prohibitMultipleLogin) {
      // 동시 접속을 불가능하게 하려면 토큰값이 REDIS 에 캐싱된 토큰과 동일한지 확인한다.
      if (isCacheEnabled()) {
        Token cachedToken = get(tokenName);
        if (cachedToken == null || !cachedToken.getAccessToken().equals(token)) {
          throw new TokenException(TokenErrorType.INVALID_TOKEN);
        }
      }
    }
  }

  @Override
  public Token createToken(TokenRequest request) {

    String tokenName = request.getTokenName();
    String userId = request.getUserId();

    Map<String, Object> claims = request.getClaims();

    boolean rememberMe = request.isRememberMe();
    if (!request.hasClaims("rememberMe")) {
      request.setClaim("rememberMe", rememberMe);
    }

    long now = (new Date()).getTime();
    Date accessTokenExpiresIn = rememberMe ?
        new Date(now + rememberMeValidity) : new Date(now + accessTokenValidity);
    Date refreshTokenExpiredIn = rememberMe ?
        new Date(now + rememberMeValidity) : new Date(now + refreshTokenValidity);

    Map<String, Object> rememberMeClaims = createRememberMeClaims(rememberMe);

    String refreshToken = Jwts.builder()
        .setSubject(tokenName)
        .claim(AUTHORITIES_KEY, "")
        .setExpiration(refreshTokenExpiredIn)
        .signWith(key, SignatureAlgorithm.HS512)
        // refresh Token 은 rememberMe 외 claims 를 가지지 않는다.
        // refresh 를 할 때는 RefreshTokenRequest 를 가지고 다시 로그인 처리를 해서 정보를 현행화 할 필요가 있다.
        .addClaims(rememberMeClaims)
        .compact();

    CachedToken cachedToken = new CachedToken()
        .withRefreshToken(refreshToken)
        .withAccessTokenExpiry(accessTokenExpiresIn.getTime())
        .withUserId(userId)
        .withRememberMe(rememberMe)
        .withTokenPrefix(request.getTokenPrefix())
        .withClaims(claims);

    String accessToken = createAccessToken(tokenName, userId, claims, accessTokenExpiresIn, rememberMeClaims);

    cachedToken = cachedToken.withAccessToken(accessToken);

    cachedToken = getOverridedCachedToken(cachedToken);

    put(tokenName, cachedToken);

    return cachedToken;
  }

  private String createAccessToken(String tokenName, String userId, Map<String, Object> claims,
      Date accessTokenExpiresIn, Map<String, Object> simpleClaims) {
    String accessToken;

    if (isCacheEnabled() && StringUtils.isNotEmpty(userId)) {
      accessToken = Jwts.builder()
          .setSubject(tokenName)
          .signWith(key, SignatureAlgorithm.HS512)
          .setExpiration(accessTokenExpiresIn)
          // CachedToken 을 사용할 때는 claims 를 모두 캐시에 넣고 token 자체의 크기는 줄여 버린다.
          .addClaims(simpleClaims)
          .compact();

    } else {
      accessToken = Jwts.builder()
          .setSubject(tokenName)
          .signWith(key, SignatureAlgorithm.HS512)
          .setExpiration(accessTokenExpiresIn)
          .addClaims(claims)
          .compact();
    }
    return accessToken;
  }

  private static Map<String, Object> createRememberMeClaims(boolean rememberMe) {
    Map<String, Object> refreshTokenClaims = new HashMap<>();
    refreshTokenClaims.put("rememberMe", rememberMe);
    return refreshTokenClaims;
  }

  /**
   * Refresh Token 에서 사용할 RefreshTokenRequest 생성
   * @param token
   * @return
   * @throws TokenException
   */
  @Override
  public RefreshTokenRequest refreshToken(String token) throws TokenException {

    CachedToken claims = parse(TokenType.REFRESH_TOKEN, token);

    String tokenName = claims.getTokenName();
    String userId = claims.getUserId();

    if (isCacheEnabled() && StringUtils.isNotEmpty(userId)) {
      String cacheKey = tokenName;
      Token cachedToken = get(cacheKey);
      if (cachedToken == null || !cachedToken.getRefreshToken().equals(token)) {
        throw new TokenException(TokenErrorType.INVALID_TOKEN);
      }
    }

    return new RefreshTokenRequest(tokenName).withRememberMe(claims.isRememberMe());
  }

  private Claims parseInternal(String token) {
    return Jwts.parser()
        .verifyWith((SecretKey) key)
        .build()
        .parseSignedClaims(token)
        .getPayload();
  }

  protected boolean isRememberMeClaim(Claims claims) {
    try {
      return claims.get("rememberMe", boolean.class);
    } catch (Exception e) {
      return false;
    }
  }

}
