/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.resolver;

import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.resolver.RequestAttributeResolver;
import io.rchemist.common.web.request.resolver.ResolverOrder;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.service.CachedTokenHelper;
import io.rchemist.module.jwt.service.CachedTokenProvider;
import io.rchemist.module.jwt.service.exception.TokenErrorType;
import io.rchemist.module.jwt.service.exception.TokenException;
import io.rchemist.module.jwt.service.type.TokenType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;

/**
 *
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Service("rcmCachedTokenSecurityContextResolver")
public class CachedTokenSecurityContextResolver implements RequestAttributeResolver<CachedToken> {

  private final CachedTokenProvider tokenProvider;

  private static final String ACCESS_TOKEN_NAME = "Authorization";
  private static final String ACCESS_TOKEN_PREFIX = "Bearer ";

  private static final String UNDEFINED = "undefined";

  public CachedTokenSecurityContextResolver(@Autowired(required = false) CachedTokenProvider tokenProvider) {
    this.tokenProvider = tokenProvider;
  }

  @Override
  public boolean canHandle(Class<CachedToken> clazz) {
    return clazz.equals(CachedToken.class) && tokenProvider != null;
  }

  @Override
  public void resolve(WebRequestContext context) {
    if (tokenProvider == null) {
      return;
    }

    String accessToken = context.getRequest().getHeaders().getFirst(ACCESS_TOKEN_NAME);

    if (StringUtils.isNotEmpty(accessToken)) {

      accessToken = StringUtil.subStringAfter(accessToken, ACCESS_TOKEN_PREFIX);

      RequestUtil.setAttribute(CachedTokenHelper.CONTEXT_TOKEN_EXPIRED, false, RequestAttributes.SCOPE_REQUEST);

      if (StringUtils.isNotEmpty(accessToken) && !accessToken.equals(UNDEFINED)) {
        try {
          CachedToken token = tokenProvider.parse(TokenType.ACCESS_TOKEN, accessToken);

          if (token != null) {
            RequestUtil.setAttribute(CachedTokenHelper.CONTEXT_TOKEN, token, RequestAttributes.SCOPE_REQUEST);
          }

        } catch (TokenException e) {

          if (e.getErrorType().equals(TokenErrorType.EXPIRED_TOKEN)
              || e.getErrorType().equals(TokenErrorType.CACHE_EVICTED)) {
            // accessToken 이 만료됐거나, 캐시가 삭제된 경우

            // refresh token 을 이용하여 accessToken 을 재발급 해야 한다.
            // 이 처리는 front 에서 Auth 에 의한 재요청을 해야 한다.

            throw new RuntimeException(TokenErrorType.EXPIRED_TOKEN.getType());

          }

          e.printStackTrace();
          // nothing to do
        }

      }

    }

  }

  @Override
  public void clearSessionAttribute(ServletServerHttpRequest request) {
    RequestUtil.removeSessionAttribute(request, CachedTokenHelper.CONTEXT_TOKEN);
    RequestUtil.removeSessionAttribute(request, CachedTokenHelper.CONTEXT_TOKEN_EXPIRED);
  }

  @Override
  public int getOrder() {
    return ResolverOrder.SECURITY_CONTEXT_RESOLVER;
  }

}
