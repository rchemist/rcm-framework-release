/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.resolver;

import jakarta.servlet.http.HttpServletRequest;

/**
 * SPI for extracting the raw access token string from an inbound HTTP request.
 *
 * <p>The default implementation {@link BearerTokenHeaderResolver} pulls the token from the
 * {@code Authorization: Bearer <token>} header. Consumers may register an alternative bean
 * (cookie-based, custom header, query parameter, etc.) to override the default.
 */
public interface TokenHeaderResolver {

  /**
   * Resolve the access token from the request.
   *
   * @param request inbound HTTP request, never {@code null}
   * @return the raw token string, or {@code null}/empty when absent
   */
  String resolveAccessToken(HttpServletRequest request);
}
