/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service;

import io.jsonwebtoken.Claims;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.data.RefreshTokenRequest;
import io.rchemist.module.jwt.data.Token;
import io.rchemist.module.jwt.data.TokenRequest;
import io.rchemist.module.jwt.service.exception.TokenException;
import io.rchemist.module.jwt.service.type.TokenType;
import org.springframework.security.core.Authentication;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface TokenProvider {

  /**
   * accessToken 또는 refreshToken 을 가지고 CachedToken을 반환한다.
   *
   * 만약 캐시를 사용한다면, 캐시에 저장된 정보를 반환한다.
   * 캐시를 사용하지 않는다면 토큰을 파싱해 얻은 정보를 반환한다.
   *
   * 그런데 정상 토큰임에도 redis cache 에
   *
   * @param token
   * @return
   * @throws TokenException
   */
  CachedToken parse(TokenType tokenType, String token) throws TokenException;

  <T> T getClaimValue(TokenType tokenType, String token, String claimName, Class<T> requiredType) throws TokenException;

  String getUserId(TokenType tokenType, String token) throws TokenException;

  /**
   * 토큰 생성
   *
   * 만약 CachedTokenProvider 에 Cache 설정이 되어 있다면, accessToken 의 길이는 더 짧아진다.
   * userId 와 rememberMe 를 제외한 모든 정보를 캐시에 넣고 필수 정보만 accessToken 에 넣게 되기 때문이다.
   *
   * @param request
   * @return
   */
  Token createToken(TokenRequest request);

  RefreshTokenRequest refreshToken(String token) throws TokenException;

  /**
   * override validate if required
   * @param claims
   * @throws TokenException
   */
  void validate(Claims claims) throws TokenException;

  Authentication getAuthentication(TokenType tokenType, String token) throws TokenException;

}
