/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service;

import io.rchemist.module.jwt.data.CachedToken;
import java.util.Collections;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

/**
 * Default {@link AuthenticationFactory} producing a vanilla
 * {@link UsernamePasswordAuthenticationToken} carrying the token's {@code userId} as the
 * principal and empty credentials / authorities. Sufficient for consumers that authenticate
 * only on {@code userId} presence; consumers that need authorities or a richer principal
 * should register their own {@link AuthenticationFactory} bean.
 */
public class UsernamePasswordAuthenticationFactory implements AuthenticationFactory {

  @Override
  public Authentication create(CachedToken cachedToken) {
    if (cachedToken == null || StringUtils.isEmpty(cachedToken.getUserId())) {
      return null;
    }
    return new UsernamePasswordAuthenticationToken(
        cachedToken.getUserId(), "", Collections.emptyList());
  }
}
