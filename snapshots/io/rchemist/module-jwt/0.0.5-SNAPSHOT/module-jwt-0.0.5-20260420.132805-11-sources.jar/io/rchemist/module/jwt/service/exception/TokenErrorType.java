/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class TokenErrorType extends EnumType<TokenErrorType> implements ErrorType {

  public static final TokenErrorType EXPIRED_TOKEN = new TokenErrorType("EXPIRED_TOKEN", "Expired Token", 401);
  public static final TokenErrorType WRONG_SIGNATURE = new TokenErrorType("WRONG_SIGNATURE", "Wrong Signature", 401);
  public static final TokenErrorType UNSUPPORTED_TOKEN_TYPE = new TokenErrorType("UNSUPPORTED_TOKEN_TYPE", "Unsupported Token Type", 401);
  public static final TokenErrorType INVALID_TOKEN = new TokenErrorType("INVALID_TOKEN", "Invalid Token", 401);
  public static final TokenErrorType CACHE_EVICTED = new TokenErrorType("CACHE_EVICTED", "Cache evicted", 404);
  public static final TokenErrorType PROHIBIT_MULTI_LOGIN = new TokenErrorType("PROHIBIT_MULTI_LOGIN", "Multi login are not allowed",
      HttpStatus.FORBIDDEN.value());
  public static final TokenErrorType EMPTY_TOKEN = new TokenErrorType("EMPTY_TOKEN", "Empty Token", 401);
  @Getter
  private final int status;

  public TokenErrorType(String type, String friendlyType, int status) {
    super(type, friendlyType);
    this.status = status;
  }
}
