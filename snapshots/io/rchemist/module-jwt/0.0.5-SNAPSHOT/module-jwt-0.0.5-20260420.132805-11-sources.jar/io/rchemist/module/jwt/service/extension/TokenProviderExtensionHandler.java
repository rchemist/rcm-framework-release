/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.extension;

import io.jsonwebtoken.Claims;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.service.exception.TokenException;
import org.springframework.security.core.Authentication;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface TokenProviderExtensionHandler extends ExtensionHandler {

  ExtensionResultStatusType postValidate(ExtensionResultHolder<Claims> holder) throws TokenException;

  /**
   * 토큰 생성
   * @param resultHolder
   * @return
   */
  ExtensionResultStatusType resultCachedToken(ExtensionResultHolder<CachedToken> resultHolder);

  /**
   * 토큰을 통해 Authentication 을 가져온다.
   * @param holder
   * @param cachedToken
   * @return
   */
  ExtensionResultStatusType getAuthentication(ExtensionResultHolder<Authentication> holder, CachedToken cachedToken);
}
