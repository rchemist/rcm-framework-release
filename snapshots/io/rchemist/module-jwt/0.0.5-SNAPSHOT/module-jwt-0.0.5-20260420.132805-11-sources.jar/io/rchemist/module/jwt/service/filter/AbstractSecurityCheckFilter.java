/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.filter;

import io.jsonwebtoken.ExpiredJwtException;
import io.rchemist.common.security.auth.data.PlatformAuthenticationToken;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityErrorType;
import io.rchemist.common.security.auth.service.exception.PlatformSecurityException;
import io.rchemist.common.security.service.PasswordHelper;
import io.rchemist.module.jwt.data.CachedToken;
import io.rchemist.module.jwt.service.CachedTokenProvider;
import io.rchemist.module.jwt.service.exception.TokenException;
import io.rchemist.module.jwt.service.resolver.BearerTokenHeaderResolver;
import io.rchemist.module.jwt.service.resolver.TokenHeaderResolver;
import io.rchemist.module.jwt.service.type.TokenType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import javax.cache.Cache;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.filter.GenericFilterBean;

/**
 * 모든 요청에 대해 토큰을 검증한다.
 *
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class AbstractSecurityCheckFilter extends GenericFilterBean {

  protected final CachedTokenProvider tokenProvider;

  protected final Cache<String, CachedToken> tokenCache;

  /**
   * Resolver used to extract the access token from the inbound request. Defaults to the
   * standard {@code Authorization: Bearer <token>} scheme. Introduced in 0.1.0-M1 to replace
   * the hard-coded {@code JwtTokenHelper.resolveAccessToken} call.
   */
  protected final TokenHeaderResolver tokenHeaderResolver;

  protected final List<SimpleGrantedAuthority> ANONYMOUS_AUTHORITIES = List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));

  /**
   * Legacy constructor (pre-0.1.0-M1). Wires the canonical
   * {@link BearerTokenHeaderResolver#defaultResolver()} for backward compatibility.
   */
  public AbstractSecurityCheckFilter(CachedTokenProvider tokenProvider) {
    this(tokenProvider, BearerTokenHeaderResolver.defaultResolver());
  }

  /**
   * Full constructor introduced in 0.1.0-M1. Consumers override the header extraction strategy
   * (custom header name, cookie, query parameter) by providing a bespoke resolver.
   */
  public AbstractSecurityCheckFilter(CachedTokenProvider tokenProvider,
      TokenHeaderResolver tokenHeaderResolver) {
    this.tokenProvider = tokenProvider;
    this.tokenCache = tokenProvider.getTokenCache();
    this.tokenHeaderResolver = tokenHeaderResolver == null
        ? BearerTokenHeaderResolver.defaultResolver() : tokenHeaderResolver;
  }

  protected String anonymousPassword;

  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
      FilterChain filterChain) throws IOException, ServletException {

    parseAuthentication((HttpServletRequest) servletRequest);

    filterChain.doFilter(servletRequest, servletResponse);

  }

  protected void parseAuthentication(HttpServletRequest servletRequest) {
    HttpServletRequest httpServletRequest = servletRequest;
    String jwt = tokenHeaderResolver.resolveAccessToken(httpServletRequest);

    try{
      if (StringUtils.isNotEmpty(jwt)) {
        Authentication authentication = tokenProvider.getAuthentication(TokenType.ACCESS_TOKEN, jwt);

        if (authentication == null) {
          SecurityContextHolder.getContext().setAuthentication(getAnonymousAuthentication());
        } else {
          if(isCachedAuthentication(authentication)){
            SecurityContextHolder.getContext().setAuthentication(authentication);
          }else{
            // 삭제했거나 탈퇴한 user
            throw new PlatformSecurityException(PlatformSecurityErrorType.TOKEN_MISMATCH);
          }
        }
      } else {
        // 토큰이 없는 경우 익명 사용자로 설정
        SecurityContextHolder.getContext().setAuthentication(getAnonymousAuthentication());
      }

    }catch (ExpiredJwtException e){


    } catch (TokenException e) {
      throw new RuntimeException(e);
    }

  }

  private AnonymousAuthenticationToken getAnonymousAuthentication(){
    User anonymous = new User("anonymous", getAnonymousPassword(), ANONYMOUS_AUTHORITIES);
    return new AnonymousAuthenticationToken(anonymous.getPassword(), anonymous, anonymous.getAuthorities());
  }

  private String getAnonymousPassword(){
    if(StringUtils.isEmpty(this.anonymousPassword)){
      this.anonymousPassword = PasswordHelper.encode("userNotFoundPassword" + LocalDateTime.now().getChronology().toString());
    }
    return this.anonymousPassword;
  }

  protected boolean isCachedAuthentication(Authentication authentication){

    if (tokenCache == null) {
      return true;
    }

    String key = authentication.getName();
    if(authentication instanceof PlatformAuthenticationToken){
      key = ((PlatformAuthenticationToken) authentication).getUserId();
    }

    return tokenCache.get(key) != null;
  }

}
