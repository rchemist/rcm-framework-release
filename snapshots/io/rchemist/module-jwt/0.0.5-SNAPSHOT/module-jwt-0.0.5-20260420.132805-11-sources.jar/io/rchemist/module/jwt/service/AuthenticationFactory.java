/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service;

import io.rchemist.module.jwt.data.CachedToken;
import org.springframework.security.core.Authentication;

/**
 * SPI that converts a parsed {@link CachedToken} into a Spring Security {@link Authentication}.
 *
 * <p>The default implementation {@link UsernamePasswordAuthenticationFactory} produces a
 * vanilla {@code UsernamePasswordAuthenticationToken(userId, "", emptyAuthorities)} so that
 * minimal consumers get a working filter chain out of the box. Advanced consumers can register
 * an alternative bean (or a domain-aware {@code TokenProviderExtensionHandler}) that carries
 * tenant / site / role information.
 *
 * <p>When a factory is absent and no extension handler produces an authentication,
 * {@link CachedTokenProvider#getAuthentication} returns {@code null} as before — preserving
 * pre-0.1.0-M1 behavior for consumers that opt out of auto-configuration.
 */
public interface AuthenticationFactory {

  /**
   * Build an {@link Authentication} from a parsed token. Implementations may return
   * {@code null} to delegate to the next fallback (e.g. extension manager result).
   */
  Authentication create(CachedToken cachedToken);
}
