/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.data;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Setter
public class CachedToken extends Token<CachedToken> {

  private static final String[] EXCEPTED_CLAIMS = {"iss", "sub", "aud", "exp", "nbf", "iat", "jti"};

  private String tokenPrefix;

  private String userId;

  private boolean rememberMe;

  /**
   * BUG-036 (2026-04-19, 0.1.0-M1): internal claim storage switched from
   * {@code new DefaultClaimsBuilder().build()} (immutable) to a plain mutable {@link Map}.
   * The legacy initializer caused {@link UnsupportedOperationException} on the very first
   * {@link #withClaims} / {@link #addClaim} call because the built {@code Claims} is
   * immutable. The bug never surfaced in 0.0.x because {@code module-jwt} had 0 consumers
   * (DEC-017). The on-read {@link #getClaims()} adapter rebuilds an immutable {@link Claims}
   * snapshot so the public getter contract is preserved.
   */
  private Map<String, Object> claimValues = new LinkedHashMap<>();

  public CachedToken withTokenPrefix(String tokenPrefix) {
    this.tokenPrefix = tokenPrefix;
    return this;
  }

  public CachedToken withUserId(String userId) {
    this.userId = userId;
    return this;
  }

  public CachedToken withRememberMe(boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

  public CachedToken withClaims(Map<String, Object> claims) {
    if (this.claimValues == null) {
      this.claimValues = new LinkedHashMap<>();
    }
    if (MapUtils.isNotEmpty(claims)) {
      for (Entry<String, Object> entry : claims.entrySet()) {
        if (isSupportedClaim(entry.getKey())) {
          this.claimValues.put(entry.getKey(), entry.getValue());
        }
      }
    }
    return this;
  }

  public CachedToken addClaim(String key, Object value) {
    if (isSupportedClaim(key)) {
      if (this.claimValues == null) {
        this.claimValues = new LinkedHashMap<>();
      }
      this.claimValues.put(key, value);
    }
    return this;
  }

  /**
   * Returns an immutable {@link Claims} snapshot built from current claim values. The rebuild
   * cost is negligible given typical claim cardinality (5-10 entries).
   */
  public Claims getClaims() {
    if (MapUtils.isEmpty(claimValues)) {
      return Jwts.claims().build();
    }
    return Jwts.claims().add(claimValues).build();
  }

  public String getTokenPrefix() { return tokenPrefix; }
  public String getUserId() { return userId; }
  public boolean isRememberMe() { return rememberMe; }

  /** Direct mutable view (package-private callers only rely on keyed access via helpers). */
  public Map<String, Object> getClaimValues() {
    return claimValues == null ? new HashMap<>() : claimValues;
  }

  public <T> T getClaim(String key, Class<T> type) {
    if (!isSupportedClaim(key) || claimValues == null) {
      return null;
    }
    Object raw = claimValues.get(key);
    if (raw == null || type == null) {
      return type == null ? null : type.cast(raw);
    }
    return type.cast(raw);
  }

  @SuppressWarnings("unchecked")
  public <T> T getClaimValue(String key) {
    if (!isSupportedClaim(key) || claimValues == null) {
      return null;
    }
    return (T) claimValues.get(key);
  }

  private boolean isSupportedClaim(String key) {
    return !ArrayUtils.contains(EXCEPTED_CLAIMS, key);
  }

  public String getTokenName() {
    return tokenPrefix + TokenRequest.TOKEN_NAME_SPLITTER + userId;
  }

}
