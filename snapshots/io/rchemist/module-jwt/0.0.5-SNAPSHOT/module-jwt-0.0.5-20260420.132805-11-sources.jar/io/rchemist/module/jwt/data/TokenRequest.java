/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.data;

import io.rchemist.common.util.NumberUtil;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class TokenRequest implements Serializable {

  private final String userId;

  private final String tokenPrefix;

  private Map<String, Object> claims = new HashMap<>();

  public static final String TOKEN_NAME_SPLITTER = ":::";

  private boolean rememberMe;

  public TokenRequest(String tokenName) {
    String[] tokenNameSplit = splitTokenName(tokenName);
    this.tokenPrefix = tokenNameSplit[0];
    this.userId = tokenNameSplit[1];
  }

  public static String[] splitTokenName(String tokenName) {
    String[] tokenNameSplit = StringUtils.split(tokenName, TOKEN_NAME_SPLITTER);
    if (tokenNameSplit != null && tokenNameSplit.length == 2) {
      return tokenNameSplit;
    }
    throw new IllegalArgumentException("Token name is invalid");
  }

  public TokenRequest(String tokenPrefix, String userId) {
    this.tokenPrefix = tokenPrefix;
    this.userId = userId;
  }



  public TokenRequest(String tokenPrefix, Long userId) {
    this.tokenPrefix = tokenPrefix;
    this.userId = NumberUtil.toString(userId);
  }

  public String getTokenName() {
    return tokenPrefix + TOKEN_NAME_SPLITTER + userId;
  }

  public TokenRequest withClaims(Map<String, Object> claims) {
    this.claims = claims;
    return this;
  }

  public TokenRequest withRememberMe(boolean rememberMe) {
    this.rememberMe = rememberMe;
    return this;
  }

  public TokenRequest addClaims(String key, Object value) {
    this.claims.put(key, value);
    return this;
  }

  public boolean hasClaims(String key) {
    return this.claims.containsKey(key);
  }

  public <T> T getClaims(String key) {
    return (T) this.claims.get(key);
  }

  public void setClaim(String key, boolean value) {
    this.claims.put(key, value);
  }

  public static String getUserIdFromTokenName(String tokenName) {
    if (StringUtils.isEmpty(tokenName))
      return null;
    return StringUtils.substringAfter(tokenName, TOKEN_NAME_SPLITTER);
  }

}
