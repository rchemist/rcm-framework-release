/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.config;

import io.rchemist.common.cache.CacheConfiguration;
import java.time.Duration;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * JWT token provider configuration properties.
 *
 * <p>Consumers override defaults via {@code platform.jwt.*} keys in application configuration.
 * When {@link io.rchemist.module.jwt.config.JwtAutoConfiguration} detects this bean it wires a
 * {@link io.rchemist.module.jwt.data.TokenProviderConfig} accordingly. Absent override, the
 * legacy {@code platform.config.security.*} placeholders on {@code TokenProviderConfig} remain
 * effective for backward compatibility with 0.0.x consumers.
 */
@Getter
@Setter
@ConfigurationProperties(prefix = JwtProperties.PREFIX)
public class JwtProperties {

  public static final String PREFIX = "platform.jwt";

  /**
   * Enable module-jwt auto-configuration. Set to {@code false} to disable default bean wiring
   * and fall back to manual wiring (pre-0.1.0 behavior).
   */
  private boolean enabled = true;

  /** Base64-encoded HMAC secret. Empty value triggers a generated random key at runtime. */
  private String secret = "";

  /** Access token validity. Mapped to {@code TokenProviderConfig#accessTokenValidity} (ms). */
  private Duration accessTokenValidity = Duration.ofHours(1);

  /** Refresh token validity. Mapped to {@code TokenProviderConfig#refreshTokenValidity} (ms). */
  private Duration refreshTokenValidity = Duration.ofDays(7);

  /** Remember-me token validity. Mapped to {@code TokenProviderConfig#rememberMeValidity} (ms). */
  private Duration rememberMeValidity = Duration.ofDays(365);

  /** When true, the provider enforces single active session per user via the cache. */
  private boolean prohibitMultipleLogin = false;

  private final Cache cache = new Cache();

  private final Header header = new Header();

  /** JWT cache configuration. */
  @Getter
  @Setter
  public static class Cache {

    /** Cache region name. Defaults to the legacy {@code jwt-cache-data} region. */
    private String name = "jwt-cache-data";

    /** Maximum cached token entries. */
    private int maxSize = 1000;

    /** Per-entry TTL in seconds. Matches {@link CacheConfiguration#getTtl()} semantics. */
    private int ttlSeconds = 60 * 60 * 24;

    public CacheConfiguration toCacheConfiguration() {
      return new CacheConfiguration(name, maxSize, ttlSeconds);
    }
  }

  /** HTTP authorization header configuration for {@link io.rchemist.module.jwt.service.resolver.TokenHeaderResolver}. */
  @Getter
  @Setter
  public static class Header {

    /** Header carrying the access token. */
    private String authorizationHeader = "Authorization";

    /** Token scheme prefix. Space-separated pairs like {@code Bearer <token>} use this prefix. */
    private String bearerPrefix = "Bearer ";
  }
}
