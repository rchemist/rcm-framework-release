/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.data;

import io.rchemist.common.cache.CacheConfiguration;
import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.module.jwt.config.JwtCacheConfig;
import io.rchemist.module.jwt.config.JwtProperties;
import java.io.Serializable;
import java.security.SecureRandom;
import java.util.Base64;
import javax.cache.Cache;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class TokenProviderConfig implements Serializable {

  private final CommonCacheManager cacheManager;

  private final CacheConfiguration cacheConfiguration;

  @Value("${platform.config.security.token.secret:QU0tbzBqYGIraiM=Qy5WW303ajZyJmlPZ2lzSUM2NDppS31pSFwqXGBEcCpkU3o=aU04dkIxW1slKV5cb0hmUms=UlV7QHpY}")
  private String tokenSecret;

  @Value("${platform.config.security.access-token.validity:3600000}")
  private long accessTokenValidity = 60 * 60 * 1000L;              // 1시간

  @Value("${platform.config.security.refresh-token.validity:604800000}")
  private long refreshTokenValidity = 7 * 24 * 60 * 60 * 1000L;    // 7일

  @Value("${platform.config.security.remember-me.validity:31536000000}")
  private long rememberMeValidity = 365 * 24 * 60 * 60 * 1000L;    // 365일

  @Value("${platform.config.security.prohibit.multi-login:false}")
  private boolean prohibitMultipleLogin = false;

  public boolean isCacheEnabled() {
    return cacheManager != null;
  }

  public TokenProviderConfig(CommonCacheManager cacheManager) {
    this.cacheManager = cacheManager;
    this.cacheConfiguration = JwtCacheConfig.JWT_CACHE;
  }

  public TokenProviderConfig(CommonCacheManager cacheManager,
      CacheConfiguration cacheConfiguration) {
    this.cacheManager = cacheManager;
    this.cacheConfiguration = cacheConfiguration;
  }

  /**
   * 0.1.0-M1: build a {@link TokenProviderConfig} from an externalized {@link JwtProperties}.
   * Used by {@link io.rchemist.module.jwt.config.JwtAutoConfiguration} so Spring Boot consumers
   * can tune behavior via {@code platform.jwt.*} keys without hand-wiring.
   */
  public static TokenProviderConfig fromProperties(CommonCacheManager cacheManager,
      JwtProperties properties) {
    CacheConfiguration cacheConfiguration = properties.getCache().toCacheConfiguration();
    TokenProviderConfig config = new TokenProviderConfig(cacheManager, cacheConfiguration);
    if (StringUtils.isNotEmpty(properties.getSecret())) {
      config.setTokenSecret(properties.getSecret());
    }
    config.setAccessTokenValidity(properties.getAccessTokenValidity().toMillis());
    config.setRefreshTokenValidity(properties.getRefreshTokenValidity().toMillis());
    config.setRememberMeValidity(properties.getRememberMeValidity().toMillis());
    config.setProhibitMultipleLogin(properties.isProhibitMultipleLogin());
    return config;
  }

  public String getTokenSecret() {
    return tokenSecret == null ? getRandomSecureKey() : tokenSecret;
  }

  public TokenProviderConfig withTokenSecret(String tokenSecret) {
    this.tokenSecret = tokenSecret;
    return this;
  }

  public TokenProviderConfig withAccessTokenValidity(long accessTokenValidity) {
    this.accessTokenValidity = accessTokenValidity;
    return this;
  }

  public TokenProviderConfig withRefreshTokenValidity(long refreshTokenValidity) {
    this.refreshTokenValidity = refreshTokenValidity;
    return this;
  }

  public TokenProviderConfig withRememberMeValidity(long rememberMeValidity) {
    this.rememberMeValidity = rememberMeValidity;
    return this;
  }

  public TokenProviderConfig withProhibitMultipleLogin(boolean prohibitMultipleLogin) {
    this.prohibitMultipleLogin = prohibitMultipleLogin;
    return this;
  }

  private String getRandomSecureKey() {
    // 랜덤한 문자열 키 생성
    byte[] keyBytes = new byte[32];
    SecureRandom secureRandom = new SecureRandom();
    secureRandom.nextBytes(keyBytes);

    // Base64 인코딩된 문자열 키 생성
    String encodedKey = Base64.getEncoder().encodeToString(keyBytes);
    return encodedKey;
  }

  public Cache<String, CachedToken> getCache() {
    if (isCacheEnabled()) {
      return cacheManager.getOrCreateCache(cacheConfiguration, CachedToken.class);
    }
    return null;
  }

}
