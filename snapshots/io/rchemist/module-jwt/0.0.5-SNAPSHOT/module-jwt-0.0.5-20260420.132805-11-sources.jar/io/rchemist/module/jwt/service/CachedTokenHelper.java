/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service;

import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.module.jwt.data.CachedToken;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CachedTokenHelper {

  public static final String CONTEXT_TOKEN = "CONTEXT_TOKEN";
  public static final String CONTEXT_TOKEN_EXPIRED = "CONTEXT_TOKEN_EXPIRED";

  public static Long getUserIdAsLong() {
    String userId = getUserId();

    if (userId == null) {
      return null;
    }

    return NumberUtil.getLong(userId, null);

  }

  public static String getUserId() {

    CachedToken cachedToken = getCachedToken();

    return cachedToken == null ? null : cachedToken.getUserId();

  }

  public static CachedToken getCachedToken() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();

    if (context == null) {
      return null;
    }

    CachedToken cachedToken = context.getAttribute(CONTEXT_TOKEN);

    return cachedToken;

  }


  public static boolean isLoggedIn() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    return context != null && context.hasAttribute(CONTEXT_TOKEN);
  }

  public static boolean isTokenExpired() {
    WebRequestContext context = WebRequestContext.getWebRequestContext();
    return context != null && context.hasAttribute(CONTEXT_TOKEN_EXPIRED) && (boolean) context.getAttribute(CONTEXT_TOKEN_EXPIRED);
  }




}
