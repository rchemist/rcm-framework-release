/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.service.resolver;

import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;

/**
 * Default {@link TokenHeaderResolver} reading {@code Authorization: Bearer <token>}.
 *
 * <p>Both the header name and the scheme prefix are configurable to accommodate non-standard
 * deployments (legacy headers, custom schemes). The static {@link #defaultResolver()} provides
 * the canonical {@code Authorization} / {@code Bearer } tuple for programmatic wiring.
 */
public class BearerTokenHeaderResolver implements TokenHeaderResolver {

  public static final String DEFAULT_AUTHORIZATION_HEADER = "Authorization";

  public static final String DEFAULT_BEARER_PREFIX = "Bearer ";

  private final String authorizationHeader;

  private final String bearerPrefix;

  public BearerTokenHeaderResolver() {
    this(DEFAULT_AUTHORIZATION_HEADER, DEFAULT_BEARER_PREFIX);
  }

  public BearerTokenHeaderResolver(String authorizationHeader, String bearerPrefix) {
    this.authorizationHeader = authorizationHeader == null
        ? DEFAULT_AUTHORIZATION_HEADER : authorizationHeader;
    this.bearerPrefix = bearerPrefix == null ? DEFAULT_BEARER_PREFIX : bearerPrefix;
  }

  /** Returns a resolver configured with canonical {@code Authorization} / {@code Bearer } pair. */
  public static BearerTokenHeaderResolver defaultResolver() {
    return new BearerTokenHeaderResolver();
  }

  @Override
  public String resolveAccessToken(HttpServletRequest request) {
    if (request == null) {
      return null;
    }
    String headerValue = request.getHeader(authorizationHeader);
    if (StringUtils.isEmpty(headerValue)) {
      return null;
    }
    if (StringUtils.isEmpty(bearerPrefix)) {
      return headerValue;
    }
    if (headerValue.startsWith(bearerPrefix)) {
      return headerValue.substring(bearerPrefix.length());
    }
    return null;
  }

  public String getAuthorizationHeader() {
    return authorizationHeader;
  }

  public String getBearerPrefix() {
    return bearerPrefix;
  }
}
