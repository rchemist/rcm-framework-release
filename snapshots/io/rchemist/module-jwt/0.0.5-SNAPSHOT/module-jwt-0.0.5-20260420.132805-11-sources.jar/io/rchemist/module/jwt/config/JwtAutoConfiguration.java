/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.config;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.module.jwt.data.TokenProviderConfig;
import io.rchemist.module.jwt.service.AuthenticationFactory;
import io.rchemist.module.jwt.service.CachedTokenProvider;
import io.rchemist.module.jwt.service.UsernamePasswordAuthenticationFactory;
import io.rchemist.module.jwt.service.extension.TokenProviderExtensionManager;
import io.rchemist.module.jwt.service.resolver.BearerTokenHeaderResolver;
import io.rchemist.module.jwt.service.resolver.TokenHeaderResolver;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring Boot auto-configuration for {@code module-jwt} (introduced in 0.1.0-M1).
 *
 * <p>Registered via
 * {@code META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports}.
 * Each bean is provided with {@link ConditionalOnMissingBean} so consumers can override any
 * piece without disabling the rest. Auto-configuration is active by default; set
 * {@code platform.jwt.enabled=false} to opt out and retain pre-0.1.0 manual wiring.
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(JwtProperties.class)
@ConditionalOnProperty(prefix = JwtProperties.PREFIX, name = "enabled", havingValue = "true",
    matchIfMissing = true)
public class JwtAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public TokenHeaderResolver tokenHeaderResolver(JwtProperties properties) {
    return new BearerTokenHeaderResolver(
        properties.getHeader().getAuthorizationHeader(),
        properties.getHeader().getBearerPrefix());
  }

  @Bean
  @ConditionalOnMissingBean
  public AuthenticationFactory authenticationFactory() {
    return new UsernamePasswordAuthenticationFactory();
  }

  /**
   * Default {@link TokenProviderConfig}. A {@link CommonCacheManager} is optional — when
   * absent the provider operates in cacheless mode (valid tokens are re-parsed each call).
   */
  @Bean
  @ConditionalOnMissingBean
  public TokenProviderConfig tokenProviderConfig(JwtProperties properties,
      ObjectProvider<CommonCacheManager> cacheManagerProvider) {
    CommonCacheManager cacheManager = cacheManagerProvider.getIfAvailable();
    return TokenProviderConfig.fromProperties(cacheManager, properties);
  }

  @Bean
  @ConditionalOnMissingBean
  public TokenProviderExtensionManager tokenProviderExtensionManager() {
    return new TokenProviderExtensionManager();
  }

  /**
   * Default {@link CachedTokenProvider} bean. Picks up an optional {@link AuthenticationFactory}
   * so consumers with no custom {@link io.rchemist.module.jwt.service.extension.TokenProviderExtensionHandler}
   * still receive a usable {@code Authentication} from {@link CachedTokenProvider#getAuthentication}.
   */
  @Bean
  @ConditionalOnMissingBean
  public CachedTokenProvider cachedTokenProvider(TokenProviderConfig tokenProviderConfig,
      TokenProviderExtensionManager extensionManager,
      ObjectProvider<AuthenticationFactory> authenticationFactoryProvider) {
    return new CachedTokenProvider(tokenProviderConfig, extensionManager,
        authenticationFactoryProvider.getIfAvailable());
  }
}
