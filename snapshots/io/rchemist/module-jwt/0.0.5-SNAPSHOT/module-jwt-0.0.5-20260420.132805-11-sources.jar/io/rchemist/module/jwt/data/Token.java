/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.jwt.data;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public abstract class Token<T> implements Serializable {

  protected String accessToken;

  protected String refreshToken;

  protected long accessTokenExpiry;

  public T withAccessToken(String accessToken) {
    this.accessToken = accessToken;
    return (T) this;
  }

  public T withRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return (T) this;
  }

  public T withAccessTokenExpiry(long accessTokenExpiry) {
    this.accessTokenExpiry = accessTokenExpiry;
    return (T) this;
  }
}

