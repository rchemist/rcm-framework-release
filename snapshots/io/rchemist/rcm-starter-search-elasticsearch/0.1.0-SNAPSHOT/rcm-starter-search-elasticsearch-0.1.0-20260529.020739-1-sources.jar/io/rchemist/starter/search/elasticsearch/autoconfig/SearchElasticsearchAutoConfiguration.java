/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.autoconfig;

import io.rchemist.core.search.index.outbox.InMemorySearchIndexOutbox;
import io.rchemist.core.search.index.outbox.SearchIndexOutbox;
import io.rchemist.core.search.index.outbox.SearchIndexRetryPolicy;
import io.rchemist.starter.search.elasticsearch.actuator.SearchIndexesEndpoint;
import io.rchemist.starter.search.elasticsearch.analyzer.ElasticsearchAnalyzerSettings;
import io.rchemist.starter.search.elasticsearch.metrics.SearchIndexLagMetrics;
import io.rchemist.starter.search.elasticsearch.reindex.EsBulkReindexer;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * `rcm-starter-search-elasticsearch` autoconfig — Spring Data ES 가 classpath 에 있고
 * {@code platform.search.elasticsearch.enabled=true} (default) 일 때 활성.
 *
 * <p>현재 (#B2-4) 등록 Bean:
 * <ul>
 *   <li>{@link SearchIndexRetryPolicy} = defaults</li>
 *   <li>{@link SearchIndexOutbox} = {@link InMemorySearchIndexOutbox} (consumer override 시
 *       JPA-backed 등 가능)</li>
 * </ul>
 *
 * <p>후속 sub-task 등록 예정:
 * <ul>
 *   <li>#B2-5 — {@code ElasticsearchAnalyzerSettings} (Nori + synonym + user dict)</li>
 *   <li>#B2-6 — {@code ElasticsearchEntityIndexer} (factory) + outbox worker</li>
 *   <li>#B2-7 — {@code EsBulkReindexer} + {@code SearchIndexLagMetrics} + actuator endpoint</li>
 * </ul>
 **/
@AutoConfiguration
@ConditionalOnClass(ElasticsearchOperations.class)
@ConditionalOnProperty(
    prefix = "platform.search.elasticsearch",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true)
@EnableConfigurationProperties(SearchElasticsearchProperties.class)
public class SearchElasticsearchAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public SearchIndexRetryPolicy searchIndexRetryPolicy() {
    return SearchIndexRetryPolicy.defaults();
  }

  @Bean
  @ConditionalOnMissingBean
  public SearchIndexOutbox searchIndexOutbox() {
    return new InMemorySearchIndexOutbox();
  }

  @Bean
  @ConditionalOnMissingBean
  public ElasticsearchAnalyzerSettings elasticsearchAnalyzerSettings(
      SearchElasticsearchProperties properties) {
    return ElasticsearchAnalyzerSettings.from(properties.analyzer());
  }

  @Bean
  @ConditionalOnMissingBean
  public SearchIndexLagMetrics searchIndexLagMetrics() {
    return new SearchIndexLagMetrics();
  }

  @Bean
  @ConditionalOnMissingBean
  public EsBulkReindexer esBulkReindexer(
      SearchIndexLagMetrics metrics, SearchElasticsearchProperties properties) {
    return new EsBulkReindexer(metrics, properties.reindex().batchSize());
  }

  /** /actuator/search-indexes — actuator 가 classpath 에 있을 때만 활성. */
  @Configuration
  @ConditionalOnClass(Endpoint.class)
  static class ActuatorEndpointConfig {

    @Bean
    @ConditionalOnMissingBean
    SearchIndexesEndpoint searchIndexesEndpoint(
        SearchIndexOutbox outbox, SearchIndexLagMetrics metrics) {
      return new SearchIndexesEndpoint(outbox, metrics);
    }
  }
}
