/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.analyzer;

import io.rchemist.starter.search.elasticsearch.autoconfig.SearchElasticsearchProperties;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Elasticsearch 분석기 설정 baseline — Nori (한국어 형태소) + synonym_graph + user_dictionary.
 *
 * <p>{@link #toAnalysisSettings()} 가 ES `_settings` REST API 의 `settings.analysis` 본문 구조를
 * Map 으로 반환. consumer 가 ES Java client (`IndicesClient#create`) 또는 Spring Data ES
 * (`IndexOperations#create`) 호출 시 그대로 인입.
 *
 * <p>구성 요소:
 * <ul>
 *   <li>tokenizer `korean_nori` — `nori_tokenizer` + decompound_mode=mixed +
 *       (선택) user_dictionary</li>
 *   <li>analyzer `korean` — custom + tokenizer korean_nori + filter chain (nori_part_of_speech +
 *       lowercase + (선택) korean_synonyms)</li>
 *   <li>analyzer `korean_search` — search-time variant (동의어 확장 적용)</li>
 *   <li>filter `korean_synonyms` (선택) — synonym_graph + synonyms_path</li>
 * </ul>
 *
 * <p>Nori 비활성화 시 (`nori.enabled=false`) → empty analysis settings 반환 (ES default analyzer
 * 만 사용).
 *
 * @param noriEnabled Nori 한국어 분석기 등록 여부
 * @param synonymPath synonym_graph 사전 경로 (null = 동의어 미적용)
 * @param userDictionaryPath Nori user_dictionary 경로 (null = 미사용)
 **/
public record ElasticsearchAnalyzerSettings(
    boolean noriEnabled, String synonymPath, String userDictionaryPath) {

  public static final String NORI_TOKENIZER = "korean_nori";
  public static final String KOREAN_ANALYZER = "korean";
  public static final String KOREAN_SEARCH_ANALYZER = "korean_search";
  public static final String SYNONYMS_FILTER = "korean_synonyms";

  /** Nori on / synonym off / user dictionary off. */
  public static ElasticsearchAnalyzerSettings defaults() {
    return new ElasticsearchAnalyzerSettings(true, null, null);
  }

  /** {@link SearchElasticsearchProperties.Analyzer} 로부터 매핑. */
  public static ElasticsearchAnalyzerSettings from(SearchElasticsearchProperties.Analyzer props) {
    return new ElasticsearchAnalyzerSettings(
        props.nori().enabled(), props.synonymPath(), props.userDictionaryPath());
  }

  /**
   * `settings.analysis` 본문 — ES `_settings` REST API 의 `analysis` 키 하위 구조.
   *
   * <p>호출 예: {@code Map.of("settings", Map.of("analysis", settings.toAnalysisSettings()))}
   * 으로 감싸면 그대로 ES `IndicesClient.create` body.
   *
   * <p>noriEnabled=false → 빈 Map (consumer 가 그대로 보내도 ES 가 default 분석기만 사용).
   */
  public Map<String, Object> toAnalysisSettings() {
    if (!noriEnabled) {
      return Map.of();
    }

    Map<String, Object> analysis = new LinkedHashMap<>();
    analysis.put("tokenizer", buildTokenizers());
    analysis.put("analyzer", buildAnalyzers());

    if (hasSynonyms()) {
      analysis.put("filter", buildFilters());
    }
    return analysis;
  }

  private Map<String, Object> buildTokenizers() {
    Map<String, Object> nori = new LinkedHashMap<>();
    nori.put("type", "nori_tokenizer");
    nori.put("decompound_mode", "mixed");
    if (userDictionaryPath != null && !userDictionaryPath.isBlank()) {
      nori.put("user_dictionary", userDictionaryPath);
    }
    return Map.of(NORI_TOKENIZER, nori);
  }

  private Map<String, Object> buildAnalyzers() {
    Map<String, Object> analyzers = new LinkedHashMap<>();

    Map<String, Object> indexAnalyzer = new LinkedHashMap<>();
    indexAnalyzer.put("type", "custom");
    indexAnalyzer.put("tokenizer", NORI_TOKENIZER);
    indexAnalyzer.put("filter", List.of("nori_part_of_speech", "lowercase"));
    analyzers.put(KOREAN_ANALYZER, indexAnalyzer);

    if (hasSynonyms()) {
      Map<String, Object> searchAnalyzer = new LinkedHashMap<>();
      searchAnalyzer.put("type", "custom");
      searchAnalyzer.put("tokenizer", NORI_TOKENIZER);
      searchAnalyzer.put("filter", List.of("nori_part_of_speech", "lowercase", SYNONYMS_FILTER));
      analyzers.put(KOREAN_SEARCH_ANALYZER, searchAnalyzer);
    } else {
      analyzers.put(KOREAN_SEARCH_ANALYZER, indexAnalyzer);
    }

    return analyzers;
  }

  private Map<String, Object> buildFilters() {
    Map<String, Object> synonym = new LinkedHashMap<>();
    synonym.put("type", "synonym_graph");
    synonym.put("synonyms_path", synonymPath);
    synonym.put("updateable", true);
    return Map.of(SYNONYMS_FILTER, synonym);
  }

  private boolean hasSynonyms() {
    return synonymPath != null && !synonymPath.isBlank();
  }
}
