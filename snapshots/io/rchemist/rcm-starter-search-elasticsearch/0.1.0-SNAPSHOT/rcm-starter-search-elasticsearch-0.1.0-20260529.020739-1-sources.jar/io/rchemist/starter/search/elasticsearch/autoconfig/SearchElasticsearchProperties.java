/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.autoconfig;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * `rcm-starter-search-elasticsearch` config properties — {@code platform.search.elasticsearch.*}
 * prefix.
 *
 * <p>0.1.x baseline 항목:
 * <ul>
 *   <li>{@code enabled} — autoconfig 토글 (default true)</li>
 *   <li>{@code outbox.enabled} — outbox worker 토글 (default true). false = 단순 sync indexer</li>
 *   <li>{@code outbox.poll-interval} — worker tick 간격 (default 1s)</li>
 *   <li>{@code outbox.batch-size} — 1 tick 당 처리할 entry 수 (default 50)</li>
 *   <li>{@code analyzer.nori.enabled} — Nori (한국어) 분석기 default 등록 (default true)</li>
 *   <li>{@code analyzer.synonym-path} — synonym_graph 사전 경로 (null = 미사용)</li>
 *   <li>{@code analyzer.user-dictionary-path} — Nori user_dictionary (null = 미사용)</li>
 *   <li>{@code reindex.batch-size} — bulk reindex 페이징 크기 (default 500)</li>
 * </ul>
 *
 * <p>모든 항목은 yaml/env override (Spring Boot 표준).
 **/
@ConfigurationProperties(prefix = "platform.search.elasticsearch")
public record SearchElasticsearchProperties(
    @DefaultValue("true") boolean enabled,
    @DefaultValue Outbox outbox,
    @DefaultValue Analyzer analyzer,
    @DefaultValue Reindex reindex) {

  public record Outbox(
      @DefaultValue("true") boolean enabled,
      @DefaultValue("1s") Duration pollInterval,
      @DefaultValue("50") int batchSize) {
  }

  public record Analyzer(
      @DefaultValue Nori nori, String synonymPath, String userDictionaryPath) {

    public record Nori(@DefaultValue("true") boolean enabled) {
    }
  }

  public record Reindex(@DefaultValue("500") int batchSize) {
  }
}
