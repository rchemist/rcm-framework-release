/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.indexer;

import io.rchemist.core.marker.Indexable;
import io.rchemist.core.search.index.EntityIndexer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring Data Elasticsearch 기반 {@link EntityIndexer} 구현 — single-entity / bulk index / delete.
 *
 * <p>idempotency = ES `_doc` upsert (동일 id 두 번 = 동일 결과). delete 는 존재하지 않는 id 도
 * 정상 (no-op).
 *
 * <p>Spring Data ES (`ElasticsearchOperations`) = REST high-level 또는 Java API client (Spring
 * Boot 4 default = ES Java Client) 를 추상화. consumer 가 standard `spring-data-elasticsearch`
 * autoconfig (URL / auth) 에 의존.
 **/
public class ElasticsearchEntityIndexer<E extends Indexable> implements EntityIndexer<E> {

  private final Class<E> entityType;
  private final String indexName;
  private final ElasticsearchOperations operations;

  public ElasticsearchEntityIndexer(
      Class<E> entityType, String indexName, ElasticsearchOperations operations) {
    Objects.requireNonNull(entityType, "entityType required");
    Objects.requireNonNull(operations, "operations required");
    this.entityType = entityType;
    this.indexName = indexName != null && !indexName.isBlank() ? indexName : defaultIndexName(entityType);
    this.operations = operations;
  }

  public ElasticsearchEntityIndexer(Class<E> entityType, ElasticsearchOperations operations) {
    this(entityType, null, operations);
  }

  static String defaultIndexName(Class<?> entityType) {
    return entityType.getSimpleName().toLowerCase(Locale.ROOT);
  }

  @Override
  public Class<E> entityType() {
    return entityType;
  }

  @Override
  public String indexName() {
    return indexName;
  }

  @Override
  public void index(E entity) {
    Objects.requireNonNull(entity, "entity required");
    operations.save(entity, IndexCoordinates.of(indexName));
  }

  @Override
  public void delete(Object id) {
    Objects.requireNonNull(id, "id required");
    operations.delete(String.valueOf(id), IndexCoordinates.of(indexName));
  }

  /** Spring Data ES `save(Iterable, IndexCoordinates)` 가 내부적으로 bulk API 호출. */
  @Override
  public void indexBatch(Collection<E> entities) {
    if (entities == null || entities.isEmpty()) {
      return;
    }
    List<E> list = entities instanceof List<E> ? (List<E>) entities : new ArrayList<>(entities);
    operations.save(list, IndexCoordinates.of(indexName));
  }
}
