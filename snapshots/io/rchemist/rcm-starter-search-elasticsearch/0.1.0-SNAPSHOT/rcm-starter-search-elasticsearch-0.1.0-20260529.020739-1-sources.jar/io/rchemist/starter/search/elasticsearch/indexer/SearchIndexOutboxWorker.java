/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.indexer;

import io.rchemist.core.marker.Indexable;
import io.rchemist.core.search.index.EntityIndexer;
import io.rchemist.core.search.index.EntityIndexerRegistry;
import io.rchemist.core.search.index.outbox.SearchIndexEntry;
import io.rchemist.core.search.index.outbox.SearchIndexEvent;
import io.rchemist.core.search.index.outbox.SearchIndexOperation;
import io.rchemist.core.search.index.outbox.SearchIndexOutbox;
import io.rchemist.core.search.index.outbox.SearchIndexRetryPolicy;
import io.rchemist.starter.search.elasticsearch.metrics.SearchIndexLagMetrics;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Outbox polling worker — outbox 의 PENDING/RETRYING entry 1 건씩 atomic claim 후 ES 색인 시도.
 *
 * <p>호출 패턴 — Spring `@Scheduled` 또는 background ExecutorService 가 일정 주기로 {@link
 * #tick()} 호출. tick = pollNext + 색인 시도 + status 전환. INDEX / DELETE 두 operation 모두 처리.
 *
 * <p>{@code entityResolver} = INDEX 이벤트 처리 시 entity instance 를 Consumer 가 fetch 하는 방법.
 * 일반적으로 JPA repository find-by-id. null 반환 = entity 가 그 사이 삭제된 케이스 → 무시 (INDEXED
 * 마킹). DELETE 이벤트는 resolver 안 부름 (id 만으로 ES 호출).
 *
 * <p>실패 처리:
 * <ul>
 *   <li>예외 발생 + retryPolicy 미소진 → markRetrying + nextAttemptAt = now + backoff</li>
 *   <li>예외 발생 + retryPolicy 소진 → markDead</li>
 * </ul>
 **/
public class SearchIndexOutboxWorker {

  private static final Logger LOG = LoggerFactory.getLogger(SearchIndexOutboxWorker.class);

  private final SearchIndexOutbox outbox;
  private final SearchIndexRetryPolicy retryPolicy;
  private final Function<SearchIndexEvent, Object> entityResolver;
  private final SearchIndexLagMetrics metrics;

  public SearchIndexOutboxWorker(
      SearchIndexOutbox outbox,
      SearchIndexRetryPolicy retryPolicy,
      Function<SearchIndexEvent, Object> entityResolver) {
    this(outbox, retryPolicy, entityResolver, new SearchIndexLagMetrics());
  }

  public SearchIndexOutboxWorker(
      SearchIndexOutbox outbox,
      SearchIndexRetryPolicy retryPolicy,
      Function<SearchIndexEvent, Object> entityResolver,
      SearchIndexLagMetrics metrics) {
    this.outbox = Objects.requireNonNull(outbox, "outbox required");
    this.retryPolicy = Objects.requireNonNull(retryPolicy, "retryPolicy required");
    this.entityResolver = Objects.requireNonNull(entityResolver, "entityResolver required");
    this.metrics = Objects.requireNonNull(metrics, "metrics required");
  }

  /** 단일 tick — pollNext + dispatch. 처리한 entry 반환 (없으면 empty). */
  public Optional<SearchIndexEntry> tick() {
    Optional<SearchIndexEntry> claimed = outbox.pollNext();
    claimed.ifPresent(this::dispatch);
    return claimed;
  }

  private void dispatch(SearchIndexEntry entry) {
    try {
      String indexName = processEntry(entry);
      outbox.markIndexed(entry.id());
      if (indexName != null) {
        metrics.recordIndexed(indexName);
      }
    } catch (Exception ex) {
      handleFailure(entry, ex);
    }
  }

  private String processEntry(SearchIndexEntry entry) {
    SearchIndexEvent event = entry.event();
    EntityIndexer<? extends Indexable> indexer = resolveIndexer(event);

    if (event.operation() == SearchIndexOperation.DELETE) {
      indexer.delete(event.entityId());
      return indexer.indexName();
    }

    Object entity = entityResolver.apply(event);
    if (entity == null) {
      LOG.debug(
          "INDEX event entity not found (likely deleted concurrently): {}/{} — marking INDEXED no-op",
          event.entityType(),
          event.entityId());
      return null; // no-op = metric 안 올림
    }
    invokeIndex(indexer, entity);
    return indexer.indexName();
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  private void invokeIndex(EntityIndexer indexer, Object entity) {
    indexer.index((Indexable) entity);
  }

  private EntityIndexer<? extends Indexable> resolveIndexer(SearchIndexEvent event) {
    Class<?> type = loadClass(event.entityType());
    @SuppressWarnings({"unchecked", "rawtypes"})
    Optional<EntityIndexer<? extends Indexable>> indexer =
        (Optional) EntityIndexerRegistry.find((Class<? extends Indexable>) type);
    return indexer.orElseThrow(
        () ->
            new IllegalStateException(
                "EntityIndexer not registered for entity type: " + event.entityType()));
  }

  private Class<?> loadClass(String fqn) {
    try {
      return Class.forName(fqn);
    } catch (ClassNotFoundException e) {
      throw new IllegalStateException("entity class not on classpath: " + fqn, e);
    }
  }

  private static String simpleNameLowercase(String fqn) {
    int dot = fqn.lastIndexOf('.');
    String simple = dot >= 0 ? fqn.substring(dot + 1) : fqn;
    return simple.toLowerCase(java.util.Locale.ROOT);
  }

  private void handleFailure(SearchIndexEntry entry, Exception ex) {
    int attempts = entry.attempts(); // 이미 markIndexing 으로 +1 된 상태
    String message = ex.getClass().getSimpleName() + ": " + ex.getMessage();
    if (retryPolicy.isExhausted(attempts)) {
      LOG.warn("Search index entry {} exhausted retry — DEAD ({})", entry.id(), message);
      outbox.markDead(entry.id(), message);
      // metric 의 indexName 은 event 의 entityType FQCN 의 simple name lowercase 사용 (registry
      // 미등록 케이스 안전 — Class.forName 시도 안 함).
      String indexName = simpleNameLowercase(entry.event().entityType());
      metrics.recordFailed(indexName);
      return;
    }
    Instant nextAttempt = Instant.now().plus(retryPolicy.nextBackoff(attempts));
    LOG.info(
        "Search index entry {} failed (attempt {}/{}) — retrying at {} ({})",
        entry.id(),
        attempts,
        retryPolicy.maxAttempts(),
        nextAttempt,
        message);
    outbox.markRetrying(entry.id(), message, nextAttempt);
  }
}
