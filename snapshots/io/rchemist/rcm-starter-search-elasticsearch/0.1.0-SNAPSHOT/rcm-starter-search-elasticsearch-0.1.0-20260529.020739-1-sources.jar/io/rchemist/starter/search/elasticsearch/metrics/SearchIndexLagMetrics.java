/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.metrics;

import java.time.Instant;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Search index 운영 metric — per-index 누적 카운터 + 마지막 reindex 시각. lock-free 영역
 * (ConcurrentHashMap + AtomicLong + volatile Instant).
 *
 * <p>{@link #recordIndexed} = worker / indexer 가 색인 1건 성공 시 호출. {@link #recordFailed} =
 * 영구 실패 (DEAD) 마킹 시 호출. {@link #markReindexed} = bulk reindex 완료 시 호출 (운영 trace).
 *
 * <p>{@link io.rchemist.starter.search.elasticsearch.actuator} 의 endpoint 가 snapshot() 노출.
 **/
public final class SearchIndexLagMetrics {

  private final ConcurrentHashMap<String, Counters> byIndex = new ConcurrentHashMap<>();

  public void recordIndexed(String indexName) {
    countersOf(indexName).indexed.incrementAndGet();
  }

  public void recordFailed(String indexName) {
    countersOf(indexName).failed.incrementAndGet();
  }

  public void markReindexed(String indexName, Instant at) {
    countersOf(indexName).lastReindexAt = at;
  }

  public Map<String, Snapshot> snapshot() {
    Map<String, Snapshot> out = new LinkedHashMap<>();
    byIndex.forEach((index, c) -> out.put(index, c.snapshot()));
    return Collections.unmodifiableMap(out);
  }

  public Snapshot snapshotOf(String indexName) {
    Counters c = byIndex.get(indexName);
    return c == null ? Snapshot.empty() : c.snapshot();
  }

  public void clear() {
    byIndex.clear();
  }

  private Counters countersOf(String indexName) {
    return byIndex.computeIfAbsent(indexName, k -> new Counters());
  }

  private static final class Counters {
    final AtomicLong indexed = new AtomicLong();
    final AtomicLong failed = new AtomicLong();
    volatile Instant lastReindexAt;

    Snapshot snapshot() {
      return new Snapshot(indexed.get(), failed.get(), lastReindexAt);
    }
  }

  /** Per-index cumulative snapshot. */
  public record Snapshot(long indexed, long failed, Instant lastReindexAt) {

    public static Snapshot empty() {
      return new Snapshot(0, 0, null);
    }
  }
}
