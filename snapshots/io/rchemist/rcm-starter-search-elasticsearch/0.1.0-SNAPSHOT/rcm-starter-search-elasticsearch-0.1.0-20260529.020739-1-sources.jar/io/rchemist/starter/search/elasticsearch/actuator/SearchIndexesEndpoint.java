/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.actuator;

import io.rchemist.core.search.index.EntityIndexer;
import io.rchemist.core.search.index.EntityIndexerRegistry;
import io.rchemist.core.search.index.outbox.SearchIndexOutbox;
import io.rchemist.starter.search.elasticsearch.metrics.SearchIndexLagMetrics;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * `/actuator/search-indexes` endpoint — 등록된 EntityIndexer + outbox lag + per-index 카운터 노출.
 *
 * <p>응답 본문 구조:
 * <ul>
 *   <li>`outbox.pendingCount` — terminal 아닌 entry (PENDING+INDEXING+RETRYING)</li>
 *   <li>`outbox.size` — 모든 entry (INDEXED / DEAD 포함)</li>
 *   <li>`indexers` — 등록된 indexer 목록 (entityType + indexName + cumulative metrics)</li>
 * </ul>
 *
 * <p>WorkflowsEndpoint 패턴 정합 — 운영자가 lag 를 한눈에 보고 reindex 트리거 결정.
 **/
@Endpoint(id = "search-indexes")
public class SearchIndexesEndpoint {

  private final SearchIndexOutbox outbox;
  private final SearchIndexLagMetrics metrics;

  public SearchIndexesEndpoint(SearchIndexOutbox outbox, SearchIndexLagMetrics metrics) {
    this.outbox = Objects.requireNonNull(outbox, "outbox required");
    this.metrics = Objects.requireNonNull(metrics, "metrics required");
  }

  @ReadOperation
  public Map<String, Object> searchIndexes() {
    Map<String, Object> outboxMap = new LinkedHashMap<>();
    outboxMap.put("pendingCount", outbox.pendingCount());
    outboxMap.put("size", outbox.size());

    Collection<EntityIndexer<?>> all = EntityIndexerRegistry.all();
    List<Map<String, Object>> indexers = all.stream().map(this::describe).toList();

    Map<String, Object> body = new LinkedHashMap<>();
    body.put("outbox", outboxMap);
    body.put("indexers", indexers);
    return body;
  }

  private Map<String, Object> describe(EntityIndexer<?> indexer) {
    SearchIndexLagMetrics.Snapshot snap = metrics.snapshotOf(indexer.indexName());
    Map<String, Object> info = new LinkedHashMap<>();
    info.put("entityType", indexer.entityType().getName());
    info.put("indexName", indexer.indexName());

    Map<String, Object> metricsMap = new LinkedHashMap<>();
    metricsMap.put("indexed", snap.indexed());
    metricsMap.put("failed", snap.failed());
    metricsMap.put("lastReindexAt", snap.lastReindexAt());
    info.put("metrics", metricsMap);
    return info;
  }
}
