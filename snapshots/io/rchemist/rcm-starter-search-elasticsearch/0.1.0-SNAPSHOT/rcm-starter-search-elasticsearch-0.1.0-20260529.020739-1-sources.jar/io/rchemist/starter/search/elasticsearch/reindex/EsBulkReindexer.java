/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.starter.search.elasticsearch.reindex;

import io.rchemist.core.marker.Indexable;
import io.rchemist.core.search.index.EntityIndexer;
import io.rchemist.starter.search.elasticsearch.metrics.SearchIndexLagMetrics;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.function.IntFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Bulk reindexer — 페이지 단위로 entity 를 fetch 해서 ES bulk API 로 색인. 운영 시 인덱스 재생성
 * (mapping 변경 / synonym 사전 갱신 / 데이터 마이그레이션) 단일 진입점.
 *
 * <p>{@code pageFetcher} = page 0-based index 를 받아 해당 페이지 entity list 반환. 빈 list = 끝.
 * consumer 가 JPA `Pageable` 로 wire 하는 것이 일반적 (e.g. {@code page ->
 * repository.findAll(PageRequest.of(page, batchSize)).getContent()}).
 *
 * <p>각 페이지마다 {@link EntityIndexer#indexBatch} 호출 → 1 페이지 = 1 ES bulk request. 카운터
 * 갱신 + log + lag metric reindexAt 기록.
 *
 * <p>실패 정책 = page 1 건 실패 시 RuntimeException 으로 중단 (재시도 = consumer 재호출). bulk 실패
 * 부분 성공 처리는 ES adapter 영역.
 **/
public class EsBulkReindexer {

  private static final Logger LOG = LoggerFactory.getLogger(EsBulkReindexer.class);

  private final SearchIndexLagMetrics metrics;
  private final int defaultBatchSize;

  public EsBulkReindexer(SearchIndexLagMetrics metrics, int defaultBatchSize) {
    this.metrics = Objects.requireNonNull(metrics, "metrics required");
    if (defaultBatchSize < 1) {
      throw new IllegalArgumentException("defaultBatchSize must be >= 1");
    }
    this.defaultBatchSize = defaultBatchSize;
  }

  /** {@link #reindex(EntityIndexer, IntFunction, int)} — default batch 사용. */
  public <E extends Indexable> ReindexReport reindex(
      EntityIndexer<E> indexer, IntFunction<List<E>> pageFetcher) {
    return reindex(indexer, pageFetcher, defaultBatchSize);
  }

  public <E extends Indexable> ReindexReport reindex(
      EntityIndexer<E> indexer, IntFunction<List<E>> pageFetcher, int batchSize) {
    Objects.requireNonNull(indexer, "indexer required");
    Objects.requireNonNull(pageFetcher, "pageFetcher required");
    if (batchSize < 1) {
      throw new IllegalArgumentException("batchSize must be >= 1");
    }
    String indexName = indexer.indexName();
    long total = 0;
    int pages = 0;
    Instant start = Instant.now();
    LOG.info("Bulk reindex start — index={}, batchSize={}", indexName, batchSize);

    while (true) {
      List<E> page = pageFetcher.apply(pages);
      if (page == null || page.isEmpty()) {
        break;
      }
      indexer.indexBatch(page);
      total += page.size();
      pages++;
      for (int i = 0; i < page.size(); i++) {
        metrics.recordIndexed(indexName);
      }
    }

    Instant end = Instant.now();
    metrics.markReindexed(indexName, end);
    LOG.info(
        "Bulk reindex done — index={}, pages={}, total={}, took={}",
        indexName,
        pages,
        total,
        java.time.Duration.between(start, end));
    return new ReindexReport(indexName, total, pages, start, end);
  }

  /** Reindex 1 회 결과 record. */
  public record ReindexReport(
      String indexName, long totalIndexed, int pagesProcessed, Instant startedAt, Instant endedAt) {
  }
}
