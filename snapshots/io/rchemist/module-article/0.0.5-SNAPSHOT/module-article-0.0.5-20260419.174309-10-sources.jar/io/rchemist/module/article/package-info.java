/**
 * {@code module-article} — generic CMS / board content infrastructure.
 *
 * <p>Generalized in 0.1.0 M3 (DEC-017). Attachment handling is now behind the
 * {@link io.rchemist.module.article.spi.AttachmentResolver} SPI (default:
 * no-op), taxonomy is resolved through
 * {@link io.rchemist.module.article.spi.TaxonomyProvider} (default:
 * repository-backed), and tunables are exposed via
 * {@link io.rchemist.module.article.configuration.ArticleSettings}
 * ({@code platform.article.*}). Integration with {@code module-custom-field}
 * (M4) is optional and runtime-only: register a bean implementing
 * {@link io.rchemist.module.article.spi.CustomFieldResolver} named
 * {@code articleCustomFieldResolver}.
 *
 * <p>See {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
package io.rchemist.module.article;
