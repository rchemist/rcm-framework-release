/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.service;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.module.article.data.ArticleCreateForm;
import io.rchemist.module.article.data.ArticleUpdateForm;
import io.rchemist.module.article.data.ArticleView;
import io.rchemist.module.article.domain.Article;
import io.rchemist.module.article.domain.ArticleAsset;
import io.rchemist.module.article.service.exception.ArticleException;
import java.util.List;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ArticleService extends ResponseEntityListService<Article, ArticleView, ArticleCreateForm, ArticleUpdateForm, SearchForm, Long, ArticleException> {

  ArticleView view(Long id, Boolean usePrevNext) throws ArticleException;

  boolean increaseViewCount(Long articleId, Long userId);

  Integer getUnreadCount(String alias, Long userId);

  List<ArticleAsset> getArticleAssets(Long articleId);

  List<ArticleView> getCategorizedArticles(String alias, Integer size) throws ErrorTypeException;

  List<ArticleView> getFeaturedArticles(String alias, Integer size) throws ErrorTypeException;
}
