/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.config;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
public class ArticleCacheRegion {

  public static class Article {
    public static final String ENTITY = "article-entity";
    public static final String ENTITY_COLLECTION = "article-entity-collection";
    public static final String ENTITY_LIST = "article-entity-list";
    public static final String ARTICLE_LIST_CACHE = "article-list-cache";
    public static final String DATA = "article-data";
    public static final String VIEW_COUNT = "article-view-count";
    public static final String UNREAD_COUNT = "article-unread-count";
    public static final String QUERY = "article-query";
    public static final int MAX_ENTRIES = 10000;
    public static final int TTL = 60 * 60 * 24;
    public static final int TTL_HOUR = 60 * 60;
  }

}
