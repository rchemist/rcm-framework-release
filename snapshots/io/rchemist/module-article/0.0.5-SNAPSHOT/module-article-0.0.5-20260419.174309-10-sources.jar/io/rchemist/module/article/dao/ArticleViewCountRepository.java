/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.module.article.domain.ArticleViewCount;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ArticleViewCountRepository extends CommonSearchRepository<ArticleViewCount, Long> {

  @Query("select c from ArticleViewCount c where c.articleId = :articleId and c.userId = :userId")
  ArticleViewCount findArticleViewCount(Long articleId, Long userId);

  @Query(value = "SELECT COUNT(DISTINCT A.ARTICLE_ID) AS unread_count"
      + " FROM T_ARTICLE A"
      + " LEFT JOIN T_ARTICLE_VIEW AVC "
      + " ON A.ARTICLE_ID = AVC.ARTICLE_ID AND AVC.USER_ID = :userId "
      + " WHERE (A.IS_ARCHIVED IS NULL OR A.IS_ARCHIVED = false) "
      + " AND AVC.ARTICLE_ID IS NULL AND A.ALIAS_KEY = :alias ", nativeQuery = true)
  long getUnreadCountByUserId(String alias, Long userId);
}
