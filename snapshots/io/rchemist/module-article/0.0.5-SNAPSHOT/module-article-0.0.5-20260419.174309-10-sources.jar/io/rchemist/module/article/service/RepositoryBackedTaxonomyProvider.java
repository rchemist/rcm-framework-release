/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.service;

import io.rchemist.module.article.dao.ArticleRepository;
import io.rchemist.module.article.spi.TaxonomyProvider;
import java.util.Collections;
import java.util.List;

/**
 * Default {@link TaxonomyProvider} that delegates to the existing
 * {@link ArticleRepository#getFeaturedTopicsByAlias(String)} query.
 *
 * <p>This preserves the pre-M3 behavior where the {@code topic} column on
 * {@code T_ARTICLE} acts as the head-label / subcategory axis.
 */
public class RepositoryBackedTaxonomyProvider implements TaxonomyProvider {

  private final ArticleRepository articleRepository;

  public RepositoryBackedTaxonomyProvider(ArticleRepository articleRepository) {
    this.articleRepository = articleRepository;
  }

  @Override
  public List<String> getFeaturedTopics(String alias) {
    if (alias == null || alias.isEmpty()) {
      return Collections.emptyList();
    }
    List<String> topics = articleRepository.getFeaturedTopicsByAlias(alias);
    return topics != null ? topics : Collections.emptyList();
  }
}
