/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.Historical;
import io.rchemist.module.article.config.ArticleCacheRegion;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "T_ARTICLE_VIEW")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = ArticleCacheRegion.Article.ENTITY)
@Getter
@Setter
@Description(name = "게시물 조회 기록", comment = "게시물 조회수의 중복 증가 방지를 위한 조회 기록")
public class ArticleViewCount implements Historical<ArticleViewCount> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "ARTICLE_ID")
  @IndexField
  @Description(name = "게시물ID", comment = "게시물 ID, 성능을 위해 의도적으로 비정규화")
  protected Long articleId;

  @Column(name = "USER_ID")
  @Description(name = "회원ID")
  @IndexField
  protected Long userId;

  public static ArticleViewCount create(Long articleId, Long userId) {
    ArticleViewCount count = new ArticleViewCount();
    count.setArticleId(articleId);
    count.setUserId(userId);
    return count;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ArticleViewCount that = (ArticleViewCount) o;
    return Objects.equals(id, that.id) && Objects.equals(articleId,
        that.articleId) && Objects.equals(userId, that.userId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, articleId, userId);
  }
}
