/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.util.ClientIpUtil;
import io.rchemist.common.util.LocalDateTimeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.module.article.config.ArticleCacheRegion;
import io.rchemist.module.article.configuration.ArticleSettings;
import io.rchemist.module.article.dao.ArticleDao;
import io.rchemist.module.article.data.ArticleCreateForm;
import io.rchemist.module.article.data.ArticleList;
import io.rchemist.module.article.data.ArticleUpdateForm;
import io.rchemist.module.article.data.ArticleView;
import io.rchemist.module.article.domain.Article;
import io.rchemist.module.article.domain.ArticleAsset;
import io.rchemist.module.article.domain.ArticleViewCount;
import io.rchemist.module.article.service.exception.ArticleErrorType;
import io.rchemist.module.article.service.exception.ArticleException;
import io.rchemist.module.article.spi.TaxonomyProvider;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.cache.Cache;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
public class ArticleServiceImpl implements ArticleService {

  protected final ArticleDao dao;

  protected final ArticleSettings settings;

  protected final TaxonomyProvider taxonomyProvider;

  public ArticleServiceImpl(
      @Qualifier("rcmArticleDao") ArticleDao dao,
      CommonCacheManager cacheManager,
      ArticleSettings settings,
      TaxonomyProvider taxonomyProvider) {
    this.dao = dao;
    this.settings = settings;
    this.taxonomyProvider = taxonomyProvider;
    int ttl = settings.getListCacheTtlSeconds() > 0
        ? settings.getListCacheTtlSeconds()
        : ArticleCacheRegion.Article.TTL;
    int maxEntries = settings.getCacheMaxEntries() > 0
        ? settings.getCacheMaxEntries()
        : 100;
    this.viewCountCache = cacheManager.getOrCreateCache(ArticleCacheRegion.Article.VIEW_COUNT, ttl, maxEntries, Boolean.class);
    this.unreadCountCache = cacheManager.getOrCreateCache(ArticleCacheRegion.Article.UNREAD_COUNT, ttl, maxEntries, Integer.class);
    this.entityCache = cacheManager.getOrCreateCache(ArticleCacheRegion.Article.ENTITY, ttl, maxEntries, ArticleView.class);
    this.searchResultCache = cacheManager.getOrCreateCache(ArticleCacheRegion.Article.ENTITY_LIST, ttl, maxEntries, ResponseListWrapperCache.class);
    this.articleListCache = cacheManager.getOrCreateCache(ArticleCacheRegion.Article.ARTICLE_LIST_CACHE, ttl, maxEntries, ArticleList.class);
  }

  @Getter
  protected final Cache<String, Boolean> viewCountCache;

  @Getter
  protected final Cache<String, ArticleView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  @Getter
  protected final Cache<String, Integer> unreadCountCache;

  @Getter
  protected final Cache<String, ArticleList> articleListCache;

  @Override
  public ArticleView view(Long id, Boolean usePrevNext) throws ArticleException {
    ArticleView view = findViewById(id);

    boolean resolvedPrevNext = usePrevNext != null
        ? usePrevNext
        : settings.isPrevNextEnabled();

    if (resolvedPrevNext) {
      Pageable pageable = PageRequest.of(0, 1);
      LocalDateTime compareDate = LocalDateTimeUtil.getLocalDateTime(view.getCreatedAt());
      List<Article> prev = dao.getArticleRepository().findPrevArticle(id, view.getAlias(), compareDate, pageable);
      List<Article> next = dao.getArticleRepository().findNextArticle(id, view.getAlias(), compareDate, pageable);
      if (CollectionUtils.isNotEmpty(prev)) {
        view.withPrevArticleId(prev.get(0).getId())
            .withPrevArticleTitle(prev.get(0).getTitle());
      }
      if (CollectionUtils.isNotEmpty(next)) {
        view.withNextArticleId(next.get(0).getId())
            .withNextArticleTitle(next.get(0).getTitle());
      }
    }

    return view;
  }

  @Override
  @Transactional
  public boolean increaseViewCount(Long articleId, Long userId) {

    String ipAddress = ClientIpUtil.getClientIp(RequestUtil.getHttpServletRequest());

    String cacheKey = String.valueOf(Objects.hash("article", "view", articleId ,ipAddress));

    if (getViewCountCache().containsKey(cacheKey)) {
      return false;
    }

    Optional<Article> optional = findArticleById(articleId);
    if (optional.isPresent()) {
      if (userId != null) {

        ArticleViewCount count = dao.getArticleViewCountRepository()
            .findArticleViewCount(articleId, userId);
        if (count == null) {
          count = ArticleViewCount.create(articleId, userId);
          dao.getArticleViewCountRepository().save(count);
        }

        // article cache 변경
        String entityCacheKey = getEntityCacheKey(articleId);
        if (getEntityCache().containsKey(entityCacheKey)) {
          ArticleView view = getEntityCache().get(entityCacheKey);
          getEntityCache().put(entityCacheKey, view.withViewCount(NumberUtil.safeAdd(view.getViewCount(), 1)));
        }

        // User의 unread count cache 제거
        getUnreadCountCache().remove(getUnreadCountCacheKey(optional.get().getAlias(), userId));

      } else {
        // 비회원의 경우에는 그냥 증가시킨다.
      }

      Article article = optional.get();
      article.increaseViewCount();
      dao.getArticleRepository().save(article);


      return true;

    } else {
      return false;
    }
  }

  @Override
  public void clearSearchResultCache() {
    try{
      ArticleService.super.clearSearchResultCache();
      getUnreadCountCache().clear();
    }catch (Exception e){
      // nothing to do
    }
  }

  protected String getUnreadCountCacheKey(String alias, Long userId) {
    return String.valueOf(Objects.hash("article", alias, userId));
  }

  @Override
  public Integer getUnreadCount(String alias, Long userId) {
    if (userId != null) {
      String cacheKey = getUnreadCountCacheKey(alias, userId);

      if (getUnreadCountCache().containsKey(cacheKey)) {
        return getUnreadCountCache().get(cacheKey);
      }

      int unreadCount = NumberUtil.getInteger(dao.getArticleViewCountRepository().getUnreadCountByUserId(alias, userId));

      getUnreadCountCache().put(cacheKey, unreadCount);

      return unreadCount;
    }

    return 0;
  }

  @Override
  public List<ArticleAsset> getArticleAssets(Long articleId) {
    return dao.getArticleRepository().getArticleAssets(articleId);
  }

  @Override
  public List<ArticleView> getCategorizedArticles(String alias, Integer size) throws ErrorTypeException {


    size = size == null ? settings.getDefaultFeaturedSize() : size;

    String cacheKey = "categorized_" + alias + "_" + size;

    if (articleListCache.containsKey(cacheKey)) {
      ArticleList articleList = articleListCache.get(cacheKey);
      if (!articleList.isExpired()) {
        return articleList.getList();
      }
      articleListCache.remove(cacheKey);
    }

    Integer count = dao.getArticleRepository().getArticleCountByAliasAndFeatured(alias, true);

    if (count < size){
      // 3개 이하인 경우에는 전체를 가져온다.
      return getCategorizedRecentArticles(alias);
    }

    // Resolve category/topic axis through the TaxonomyProvider SPI so that
    // consumers with a different taxonomy scheme can plug in without forking.
    List<String> topics = taxonomyProvider.getFeaturedTopics(alias);
    if (topics.size() < 2) {
      // 토픽 크기가 하나면 전체를 가져온다.
      return getCategorizedRecentArticles(alias);
    }

    List<ArticleView> list = new ArrayList<>();
    Map<String, List<Article>> map = new HashMap<>();

    for (String topic : topics) {
      List<Article> articleViews = dao.getArticleRepository().getFeaturedArticleByTopic(alias, topic, PageRequest.of(0, size));
      map.put(topic, articleViews);
    }

    while (list.size() < size) {
      for (Map.Entry<String, List<Article>> entry : map.entrySet()) {
        List<Article> articleViews = entry.getValue();
        if (articleViews.size() > 0) {
          list.add(articleViews.remove(0).view());
        }
      }
    }

    articleListCache.put(cacheKey, new ArticleList().withList(list));

    return list;
  }

  @Override
  public List<ArticleView> getFeaturedArticles(String alias, Integer size) throws ErrorTypeException {

    size = size == null ? settings.getDefaultFeaturedSize() : size;

    String cacheKey = "featured_" + alias + "_" + size;

    if (articleListCache.containsKey(cacheKey)) {
      ArticleList articleList = articleListCache.get(cacheKey);
      if (!articleList.isExpired()) {
        return articleList.getList();
      }
      articleListCache.remove(cacheKey);
    }

    List<Article> articles = dao.getArticleRepository().getFeaturedArticle(alias, PageRequest.of(0, size));
    List<ArticleView> list = articles.stream().map(Article::view).collect(Collectors.toList());

    articleListCache.put(cacheKey, new ArticleList().withList(list));

    return list;
  }

  private List<ArticleView> getCategorizedRecentArticles(String alias) throws ErrorTypeException {
    ResponseListData<ArticleView, SearchForm> responseListData = createResponseListData(new SearchForm().filterEquals("alias", alias));
    if (responseListData.isError()) {
      throw new ErrorTypeException(responseListData.getError().getMessage(), responseListData.getError());
    }

    return responseListData.getData();
  }

  private Optional<Article> findArticleById(Long id) {
    return dao.getArticleRepository().findById(id);
  }


  @Override
  public CommonSearchRepository<Article, Long> getRepository() {
    return dao.getArticleRepository();
  }

  @Override
  public ArticleException entityNotFoundException() {
    return new ArticleException(ArticleErrorType.NOT_FOUND);
  }

  @Override
  public Article createEntity(ArticleCreateForm articleCreateForm) throws ArticleException {
    return Article.create(articleCreateForm);
  }

  @Override
  public Article updateEntity(Article entity, ArticleUpdateForm articleUpdateForm) throws ArticleException {
    return entity.update(articleUpdateForm);
  }

  @Override
  public ArticleView getView(Article article, EntityViewType entityViewType) {
    return article.view(entityViewType);
  }

  @Override
  public SearchContext<Article, SearchForm> getSearchContext(SearchForm form) {
    return new CommonSearchContext<>(Article.class, form);
  }


}
