/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.AssetMapping;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.module.article.config.ArticleCacheRegion;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "T_ARTICLE_ASSET")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = ArticleCacheRegion.Article.ENTITY)
@Getter
@Setter
@Description(name = "게시물 첨부 파일", comment = "게시물 첨부 파일")
public class ArticleAsset implements EssentialEntity<ArticleAsset>, AssetMapping<ArticleAsset> {

  @Id
  @IdGenerator
  private Long id;

  @ManyToOne(targetEntity = Article.class, optional = false, cascade = CascadeType.REFRESH)
  @JoinColumn(name = "ARTICLE_ID")
  @IndexField
  @Description(name = "게시물 ID", comment = "게시물 정보")
  private Article article;

  public boolean isSameAsset(AttachAsset asset) {
    return StringUtils.equals(getAssetUrl(), asset.getAssetUrl())
        && StringUtils.equals(getAssetKey(), asset.getAssetKey());
  }

}
