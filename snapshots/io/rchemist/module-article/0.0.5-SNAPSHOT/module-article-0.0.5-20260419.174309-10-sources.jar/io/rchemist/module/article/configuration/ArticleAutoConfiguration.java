/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.configuration;

import io.rchemist.module.article.dao.ArticleRepository;
import io.rchemist.module.article.service.RepositoryBackedTaxonomyProvider;
import io.rchemist.module.article.spi.AttachmentResolver;
import io.rchemist.module.article.spi.CustomFieldResolver;
import io.rchemist.module.article.spi.NoOpAttachmentResolver;
import io.rchemist.module.article.spi.NoOpCustomFieldResolver;
import io.rchemist.module.article.spi.TaxonomyProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Registers default implementations of the article SPIs
 * ({@link AttachmentResolver}, {@link TaxonomyProvider},
 * {@link CustomFieldResolver}) so that the module runs out of the box.
 *
 * <p>Each bean is declared {@code @ConditionalOnMissingBean}, allowing
 * consumers (or sibling modules such as {@code module-custom-field}) to
 * override it without wrestling with bean-definition order.
 *
 * <p>Consumers that want real attachment behavior can provide their own
 * {@link AttachmentResolver} bean — for example, one that delegates to
 * {@code AssetSearchServiceHelper} from {@code module-asset}. The article
 * module itself intentionally stays free of a {@code module-asset} compile
 * dependency.
 *
 * <p>Introduced by the 0.1.0 M3 generalization. See
 * {@code documents/refactor/15c-0.1.0-m3-article-generalization.md}.
 */
@Configuration
public class ArticleAutoConfiguration {

  /**
   * Well-known bean name consumed by {@code module-custom-field} (M4) when it
   * publishes its own {@link CustomFieldResolver} implementation. Declared as
   * a constant so the sibling module can reference it without depending on
   * article internals.
   */
  public static final String CUSTOM_FIELD_RESOLVER_BEAN = "articleCustomFieldResolver";

  @Bean
  @ConditionalOnMissingBean(AttachmentResolver.class)
  public AttachmentResolver defaultArticleAttachmentResolver() {
    return new NoOpAttachmentResolver();
  }

  @Bean
  @ConditionalOnMissingBean(TaxonomyProvider.class)
  public TaxonomyProvider defaultArticleTaxonomyProvider(ArticleRepository articleRepository) {
    return new RepositoryBackedTaxonomyProvider(articleRepository);
  }

  @Bean(CUSTOM_FIELD_RESOLVER_BEAN)
  @ConditionalOnMissingBean(CustomFieldResolver.class)
  public CustomFieldResolver defaultArticleCustomFieldResolver() {
    return new NoOpCustomFieldResolver();
  }
}
