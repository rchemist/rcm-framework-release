/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.dao;

import lombok.Getter;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Repository("rcmArticleDao")
public class ArticleDao {

  @Getter
  private final ArticleRepository articleRepository;

  @Getter
  private final ArticleViewCountRepository articleViewCountRepository;

  public ArticleDao(ArticleRepository articleRepository,
                    ArticleViewCountRepository articleViewCountRepository) {
    this.articleRepository = articleRepository;
    this.articleViewCountRepository = articleViewCountRepository;
  }

}
