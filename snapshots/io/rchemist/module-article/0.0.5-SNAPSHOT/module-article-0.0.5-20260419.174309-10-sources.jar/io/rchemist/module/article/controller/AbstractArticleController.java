/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.controller;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityController;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.module.article.data.ArticleCreateForm;
import io.rchemist.module.article.data.ArticleUpdateForm;
import io.rchemist.module.article.data.ArticleView;
import io.rchemist.module.article.domain.Article;
import io.rchemist.module.article.service.ArticleService;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractArticleController extends ResponseEntityController<Article, ArticleView, ArticleCreateForm, ArticleUpdateForm, SearchForm, Long> {

  protected final ArticleService articleService;

  public AbstractArticleController(ArticleService articleService) {
    this.articleService = articleService;
  }

  public ResponseListData<ArticleView, SearchForm> getSearch(@RequestBody SearchForm form) {
    return articleService.createResponseListData(form);
  }

  public ResponseData<ArticleView> view(@PathVariable Long id, @RequestParam(required = false) Boolean usePrevNext) {
    return ResponseHelper.result(() -> articleService.view(id, usePrevNext));
  }

  @Override
  protected ResponseEntityListService<Article, ArticleView, ArticleCreateForm, ArticleUpdateForm, SearchForm, Long, ? extends ErrorTypeException> getService() {
    return articleService;
  }

  public ResponseData<ArticleView> create(@RequestBody ArticleCreateForm form) {
    return ResponseHelper.result(() -> articleService.create(form));
  }


  public ResponseData<Integer> getUnreadCount(@RequestParam(defaultValue = "notice") String alias, Long userId) {
    return ResponseHelper.result(() -> articleService.getUnreadCount(alias, userId));
  }

  public ResponseData<ArticleView> update(@PathVariable Long id, @RequestBody ArticleUpdateForm form) {
    form.setId(id);
    return ResponseHelper.result(() -> articleService.update(form));
  }

  public ResponseData<Boolean> delete(@PathVariable Long id, @RequestParam(required = false) String revisionEntityName) {
    return ResponseHelper.result(() -> articleService.deleteByForm(new DeleteForm<>(id, revisionEntityName)));
  }

  public ResponseData<Boolean> increaseViewCount(@PathVariable Long id, Long userId) {
    return ResponseHelper.result(() -> articleService.increaseViewCount(id, userId));
  }

  public ResponseData<Integer> deleteAll(@RequestBody DeleteForm<Long> idList) {
    return super.deleteMultiple(idList);
  }

}
