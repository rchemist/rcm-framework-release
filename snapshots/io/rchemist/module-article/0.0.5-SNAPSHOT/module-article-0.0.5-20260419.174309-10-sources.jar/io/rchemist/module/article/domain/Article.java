/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.data.FileInfo;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.jpa.domain.service.AuditUtil;
import io.rchemist.common.persistence.jpa.domain.template.Alias;
import io.rchemist.common.persistence.jpa.domain.template.Contents;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.Hidden;
import io.rchemist.common.persistence.jpa.domain.template.Nickname;
import io.rchemist.common.persistence.jpa.domain.template.SimpleAttributes;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.persistence.jpa.domain.template.TagsMapping;
import io.rchemist.common.persistence.jpa.domain.template.UserId;
import io.rchemist.common.util.FieldHelper;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.module.article.config.ArticleCacheRegion;
import io.rchemist.module.article.data.ArticleCreateForm;
import io.rchemist.module.article.data.ArticleUpdateForm;
import io.rchemist.module.article.data.ArticleView;
import io.rchemist.module.article.service.ArticleServiceHelper;
import io.rchemist.module.article.service.exception.ArticleException;
import io.rchemist.module.article.spi.AttachmentResolverHelper;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by hongin
 **/
@Entity
@Table(name = "T_ARTICLE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = ArticleCacheRegion.Article.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "게시물", comment = "게시물 정보")
public class Article implements EssentialEntity<Article>, SoftDelete<Article>, Alias<Article>
    , UserId<Article>, SimpleAttributes<Article>
    , Nickname<Article>, Contents<Article>, TagsMapping<Article>, Hidden<Article> {

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "TOPIC")
  @KeywordField
  @Description(name = "머리말", comment = "게시물의 머리말 정보. 게시판에서 머리말 정보를 설정할 수 있으며, 이를 게시판 작성시 선택하여 사용할 수 있다. 머리말은 검색과 필터 정보로 사용된다.")
  private String topic;

  // 작성자

  @OneToMany(targetEntity = ArticleAsset.class, mappedBy = "article", cascade = CascadeType.ALL, orphanRemoval = true)
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = ArticleCacheRegion.Article.ENTITY_COLLECTION)
  @BatchSize(size = 20)
  @Description(name = "첨부 파일", comment = "게시물에 등록된 첨부 파일")
  private Set<ArticleAsset> articleAssets = new HashSet<>();

  @Column(name = "VIEW_COUNT")
  @Description(name = "조회수", comment = "게시물 조회수")
  @GenericField
  private Integer viewCount;

  @Column(name = "COVER_IMAGE")
  @Description(name = "커버 이미지", comment = "게시물 커버 이미지")
  private String coverImage;

  @Column(name = "COVERED")
  @Description(name = "추천 게시물 여부", comment = "추천 게시물인 경우에만 커버스토리에 표시된다.")
  @GenericField
  private Boolean featured = false;

  public static Article create(ArticleCreateForm form) throws ArticleException {
    form.validate();
    Article article = new Article();
    article.setNickname(form.getNickname());
    article.setTopic(form.getTopic());
    article.setUserId(form.getUserId());
    article.setTitle(form.getTitle());
    article.setContent(form.getContent());
    article.setTags(form.getTags());
    article.setHidden(form.getHidden());
    article.setAlias(form.getAlias());
    article.setFeatured(form.getFeatured());
    article.setCoverImage(form.getCoverImage());

    if (CollectionUtils.isNotEmpty(form.getNewFiles())) {
      List<ArticleAsset> assets = new ArrayList<>();
      for (AttachAsset attachAsset : CollectionUtils.emptyIfNull(
          AttachmentResolverHelper.resolveNewAttachments(form))) {
        ArticleAsset asset = new ArticleAsset();
        asset.setArticle(article);
        asset.setAsset(attachAsset);
        assets.add(asset);
      }
      article.setArticleAssets(new HashSet<>(assets));
    }

    article.setSimpleAttributes(form.getAttributes());

    return article;
  }

  public ArticleView view() {
    return view(EntityViewType.VIEW);
  }

  public ArticleView view(EntityViewType viewType) {
    ArticleView view = new ArticleView();
    view.setId(getId());
    view.setAlias(getAlias());
    view.setTitle(getTitle());
    view.setNickname(getNickname());
    view.setCoverImage(getCoverImage());
    view.setTopic(getTopic());
    view.setFeatured(getFeatured());

    view.setTags(getTags());
    view.setActive(isActive());
    view.setAudit(AuditUtil.create(this));
    view.setViewCount(getViewCount());
    view.setAttributes(getSimpleAttributes());

    List<ArticleAsset> assets = ArticleServiceHelper.getArticleAssets(getId());

    if(!viewType.equals(EntityViewType.LIST)) {
      view.setContent(getContent());
      for (ArticleAsset asset : CollectionUtils.emptyIfNull(assets)) {
        AttachAsset attachAsset = asset.getAsset();
        FileInfo fileInfo = new FileInfo();
        fileInfo.setUrl(attachAsset.getAssetUrl());
        fileInfo.setId(attachAsset.getAssetKey());
        view.addExistFile(fileInfo);
      }
    }

    view.setAssetUploaded(CollectionUtils.isNotEmpty(assets));

    return view;
  }


  public Article update(ArticleUpdateForm form) throws ArticleException {
    form.validate();

    FieldHelper.updateEntityWithSelectedFields(this, form, form.getModifiedFields());

    if (CollectionUtils.isNotEmpty(getArticleAssets()) && CollectionUtils.isNotEmpty(form.getDeleteFiles())) {
      FILE_CHECK:
      for (FileInfo info : form.getDeleteFiles()) {
        Iterator<ArticleAsset> iterator = this.articleAssets.iterator();
        while (iterator.hasNext()) {
          ArticleAsset asset = iterator.next();
          if (asset.getAssetKey().equals(info.getId())) {
            iterator.remove();
            continue FILE_CHECK;
          }
        }
      }
    }

    if (CollectionUtils.isNotEmpty(form.getNewFiles())) {
      for (AttachAsset asset : CollectionUtils.emptyIfNull(
          AttachmentResolverHelper.resolveNewAttachments(form))) {
        ArticleAsset articleAsset = new ArticleAsset();
        articleAsset.setArticle(this);
        articleAsset.setAsset(asset);
        boolean duplicated = false;
        for (ArticleAsset aa : CollectionUtils.emptyIfNull(this.articleAssets)) {
          if (aa.isSameAsset(articleAsset.getAsset())) {
            duplicated = true;
            break;
          }
        }
        if (!duplicated) {
          this.articleAssets.add(articleAsset);
        }
      }
    }

    updateAttributes(getSimpleAttributes(), "attr", form.getModifiedFields());

    return this;
  }


  public void increaseViewCount() {
    if (this.viewCount == null) {
      this.viewCount = 1;
    } else {
      this.viewCount++;
    }
  }
}
