/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.article.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.module.article.domain.Article;
import io.rchemist.module.article.domain.ArticleAsset;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ArticleRepository extends CommonSearchRepository<Article, Long> {

  @Query("select a from Article a where a.id <> :articleId and a.alias = :alias and (a.active is null or a.active = true) and a.createdAt <= :compareDate order by a.createdAt desc")
  List<Article> findPrevArticle(Long articleId, String alias, LocalDateTime compareDate, Pageable pageable);

  @Query("select a from Article a where a.id <> :articleId and  a.alias = :alias and (a.active is null or a.active = true) and a.createdAt >= :compareDate order by a.createdAt asc")
  List<Article> findNextArticle(Long articleId, String alias, LocalDateTime compareDate, Pageable pageable);

  @Query("select a from ArticleAsset a where a.article.id = :articleId order by a.createdAt asc")
  List<ArticleAsset> getArticleAssets(Long articleId);

  @Query("select count(a) from Article a where a.alias = ?1")
  Integer getArticleCountByAlias(String alias);

  @Query("select count(a) from Article a where a.alias = ?1 and a.featured = ?2")
  Integer getArticleCountByAliasAndFeatured(String alias, Boolean featured);

  @Query("select distinct a.topic from Article a where a.alias = ?1 " +
          " and a.featured = true " +
          " and (a.active is null or a.active = true) and a.topic is not null and a.topic <> '' ")
  List<String> getFeaturedTopicsByAlias(String alias);

  @Query("select a from Article a where a.alias = ?1 " +
          " and a.featured = true " +
          " and a.topic = ?2 and (a.active is null or a.active = true) order by a.createdAt desc")
  List<Article> getFeaturedArticleByTopic(String alias, String topic, Pageable pageable);

  @Query("select a from Article a where a.alias = ?1 " +
          " and a.featured = true " +
          " and (a.active is null or a.active = true) order by a.createdAt desc")
  List<Article> getFeaturedArticle(String alias, Pageable pageable);
}
