/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.asset.staticasset.data.AssetUploadForm;
import io.rchemist.asset.staticasset.data.AssetUploadResult;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.data.RemoveAssetDTO;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.util.CollectionUtil;
import io.rchemist.common.util.RequestUtil;
import io.rchemist.common.util.type.AssetType;
import io.rchemist.common.web.response.ResponseData;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetManageService {

  /**
   * Form 에서 MultipartFile 로 전송된 경우에는 AssetUpload 정보로 바로 받아 온다.
   * @param assetUploadForm
   * @return
   * @throws FileServiceException
   * @throws IOException
   */
  default AssetUploadResult uploadAssetUsingForm(AssetUploadForm<MultipartFile> assetUploadForm) {
    return uploadAssetUsingObject(assetUploadForm);
  }

  /**
   * 압축파일을 풀어서 Asset 으로 만드는 케이스와 같이 MultipartFile 이 아니라 그냥 File 로 처리해야 하는 경우
   * @param assetUploadForm
   * @return
   * @throws FileServiceException
   * @throws IOException
   */
  default AssetUploadResult uploadAssetUsingFile(AssetUploadForm<File> assetUploadForm) {
    return uploadAssetUsingObject(assetUploadForm);
  }

  /**
   * 외부 파일의 URL 을 넘기면 해당 주소로 다운로드 한 후 Asset 으로 만든다.
   * @param assetUploadForm
   * @return
   * @throws FileServiceException
   * @throws IOException
   */
  default AssetUploadResult uploadAssetUsingLink(AssetUploadForm assetUploadForm) {
    return uploadAssetUsingObject(assetUploadForm);
  }

  default AssetUploadResult uploadAssetUsingObject(AssetUploadForm<?> assetUploadForm) {
    if (assetUploadForm.hasFile()) {

      AssetUploadResult result = new AssetUploadResult();

      AssetUploadForm<InputStream> streamAssetUploadForm = new AssetUploadForm<>();
      List<AssetUpload<InputStream>> uploadStreams = new ArrayList<>();
      for (AssetUpload<?> file : assetUploadForm.getFiles()) {

        try {
          AssetUpload<InputStream> stream = file.createInputStreamData();
          uploadStreams.add(stream);
        } catch (IOException e) {
          // error
          UploadFile failedFile = new UploadFile(new ErrorDTO(e))
              .withName(file.getFileName());
          result.addAsset(failedFile);
        }

      }

      if (CollectionUtils.isNotEmpty(uploadStreams)) {
        streamAssetUploadForm.setFiles(uploadStreams);

        var uploadResult = uploadAsset(streamAssetUploadForm);

        if (CollectionUtils.isNotEmpty(uploadResult.getAssets())) {
          result.addAsset((uploadResult.getAssets().toArray(new UploadFile[0])));
        }

      }

      return result;

    } else {

      UploadFile file = new UploadFile();
      file.setError(new ErrorDTO(FileServiceErrorType.FILE_NOT_FOUND));
      AssetUploadResult result = new AssetUploadResult();
      result.setAssets(List.of(file));
      return result;

    }
  }

  /**
   * InputStream 을 직접 전달해 Asset 을 만들 수 있다.
   * @param assetUploadForm
   * @return
   * @throws FileServiceException
   * @throws IOException
   */
  default AssetUploadResult uploadAsset(AssetUploadForm<InputStream> assetUploadForm) {

    AssetUploadResult assetUploadResult = new AssetUploadResult();

    try {
      if (!assetUploadForm.hasFile()) {
        throw new FileServiceException(FileServiceErrorType.NOT_FOUND_ASSET_INFO);
      }

      for (AssetUpload<InputStream> assetUpload : assetUploadForm.getFiles()) {

        UploadFile uploadFile = uploadFile(assetUpload);

        assetUploadResult.addAsset(uploadFile);

      }

    } catch (Exception e) {
      // 결과 자체가 없다.
      e.printStackTrace();
      assetUploadResult = new AssetUploadResult();
    }

    return assetUploadResult;
  }

  UploadFile uploadFile(AssetUpload<InputStream> assetUpload)
      throws Exception;

  /**
   * Asset 정보를 수정할 때 - 단, 파일은 수정할 수 없다.  asset 의 이름이나 설명, 검색 태그와 같은 메타데이터 정보를 수정하는 것이다.
   * 아예 다른 파일로 대체 하고 싶다면 지우고 새로 등록하도록 해야 한다.
   * @param modifyForm
   * @return
   */
  ResponseData<AssetDTO> modifyAsset(AssetModifyForm modifyForm);

  /**
   * Asset 삭제 - 반드시 WebRequestContext 가 존재해야 한다.
   * @param id
   * @return
   */
  ResponseData<Boolean> deleteAsset(String id);

  /**
   * 복수의 Asset 한번에 삭제
   * @param removeAssetDTO
   * @return
   */
  ResponseData<Boolean> deleteAssets(RemoveAssetDTO removeAssetDTO);

  ResponseData<Boolean> deleteAssetByUrl(String tenantAlias, String url);

  default String uploadSingleFile(File file, String tenantAlias, boolean returnId){
    AssetUploadForm<File> files = new AssetUploadForm<>();
    AssetUpload<File> upload = new AssetUpload<>();
    upload.setTenantAlias(tenantAlias);
    upload.setUploadFile(file);
    upload.setAssetType(AssetType.FILE);
    upload.setFileName(file.getName());
    upload.setName(file.getName());
    files.getFiles().add(upload);

    AssetUploadResult result = uploadAssetUsingFile(files);

    try {
      if (result == null || CollectionUtils.isEmpty(result.getAssets())) {
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);
      }

      UploadFile uploadFile = result.getAssets().get(0);

      if(returnId){
        return uploadFile.getId();
      }

      String returnUrl = uploadFile.getUrl() + "?assetKey=" + uploadFile.getId() + "&fileSize="
          + uploadFile.getFileSize();

      return returnUrl;

    } catch (Exception e) {
      return null;
    }

  }

  default String uploadSingleFile(MultipartFile file, String tenantAlias, boolean returnId) {

    try {
      UploadFile uploadFile = uploadSingleFile(file, tenantAlias);

      if(returnId){
        return uploadFile.getId();
      }

      String returnUrl = uploadFile.getUrl() + "?assetKey=" + uploadFile.getId() + "&fileSize="
          + uploadFile.getFileSize();

      List<String> sessionUploaded = CollectionUtil.list(returnUrl);

      RequestUtil.setSessionAttribute("session-upload-file", sessionUploaded);

      return returnUrl;

    } catch (Exception e) {
      return null;
    }
  }

  default UploadFile uploadSingleFile(MultipartFile file, String tenantAlias) throws Exception{
    AssetUploadForm<MultipartFile> files = new AssetUploadForm<>();
    AssetUpload<MultipartFile> upload = new AssetUpload<>();
    upload.setTenantAlias(tenantAlias);
    upload.setUploadFile(file);
    upload.setAssetType(AssetType.FILE);
    upload.setFileName(file.getOriginalFilename());
    upload.setName(file.getName());
    files.getFiles().add(upload);

    AssetUploadResult result = uploadAssetUsingForm(files);

    if (result == null || CollectionUtils.isEmpty(result.getAssets())) {
      throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);
    }

    UploadFile uploadFile = result.getAssets().get(0);

    return uploadFile;
  }

}
