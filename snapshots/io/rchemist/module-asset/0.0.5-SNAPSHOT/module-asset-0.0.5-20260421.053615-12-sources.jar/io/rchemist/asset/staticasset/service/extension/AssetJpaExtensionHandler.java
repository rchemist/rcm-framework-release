/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service.extension;

import io.rchemist.asset.configuration.AssetSettings;
import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.asset.staticasset.data.AssetUploadForm;
import io.rchemist.asset.staticasset.data.AssetUploadResult;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.data.RemoveAssetDTO;
import io.rchemist.asset.staticasset.domain.Asset;
import io.rchemist.asset.staticasset.domain.AssetResize;
import io.rchemist.asset.staticasset.service.AssetManageServiceHelper;
import io.rchemist.asset.staticasset.service.AssetService;
import io.rchemist.asset.staticasset.service.AssetViewDTO;
import io.rchemist.asset.staticasset.service.AssetViewService;
import io.rchemist.asset.staticasset.service.exception.AssetErrorType;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.common.configuration.platform.DataProviderConfig;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.file.data.FileResource;
import io.rchemist.common.file.data.FileUploadResult;
import io.rchemist.common.file.service.FileService;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.TSIDUtil;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.service.data.DeleteForm;
import jakarta.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = AssetServiceExtensionManager.MANAGER, priority = 100)
@Slf4j
public class AssetJpaExtensionHandler extends AbstractAssetExtensionHandler {

  protected final AssetService assetService;

  public AssetJpaExtensionHandler(FileService fileService, AssetService assetService) {
    super(fileService);
    this.assetService = assetService;
  }

  @Override
  public ExtensionResultStatusType getAssetView(HttpServletRequest request,
      String fileName,
      Map<String, String> resizeOptions, ExtensionResultHolder<AssetViewDTO> resultHolder) throws Exception {

    // 2. asset 을 뒤져서 local 파일인지 cdn 파일인지 확인
    Asset asset = assetService.findAssetByUrl(fileName);
    if (asset == null) {
      // url 이 아니라 id 일 수도 있다.
      asset = assetService.findEntityById(fileName);
      if (asset == null) {
        throw new AssetException(AssetErrorType.ASSET_NOT_FOUND);
      }
    }

    AssetViewDTO dto = new AssetViewDTO();

    // local resource 일 때만
    if (asset.isLocalResource() && MapUtils.isNotEmpty(resizeOptions)) {
      String resizeOptionCacheKey = AssetViewService.getResizeOptionValues(resizeOptions);

      // resizeOptionCacheKey 를 가지고 실제 asset 정보를 확인한다.
      AssetResize assetResize = assetService.findByAssetIdAndParameter(asset.getId(), resizeOptionCacheKey);

      if (assetResize != null) {
        // assetResize 가 존재한다면 해당 파일명으로 view 를 덮어 써야 한다.
        String assetId = assetResize.getAlterAssetId();
        asset = assetService.findEntityById(assetId);
      } else {
        // 리사이즈를 새로 해서 이미지를 만들어야 한다는 뜻이다.
        try {
          asset = getResizedAsset(fileName, resizeOptions, asset, resizeOptionCacheKey);
        }catch (Exception e) {
          // silent exception
          log.error(e.getMessage(), e);
        }


      }
    }

    dto.withFilename(fileName)
        .withAbsoluteSource(asset.getAbsoluteSource())
        .withLocalResource(asset.isLocalResource());

    resultHolder.setResult(dto);

    return ExtensionResultStatusType.HANDLED;
  }

  private Asset getResizedAsset(String fileName, Map<String, String> resizeOptions, Asset asset, String resizeOptionCacheKey) throws FileServiceException, IOException, AssetException {
    FileResource resource = fileService.getResourceResource(asset.getAbsoluteSource(), fileName, true);

    if (resource != null && (resource.getFile() != null || resource.getExternalFilePath() != null)) {

      File file = resource.getFile();

      if (!file.exists()) {
        throw new AssetException(AssetErrorType.ASSET_NOT_FOUND);
      }

      String alterFileName = file.getName();
      String fileExt = FileUtil.getFileExtension(alterFileName);
      alterFileName = StringUtils.removeEnd(alterFileName, "." + fileExt);
      alterFileName = alterFileName + AssetViewService.getResizedFileName(resizeOptionCacheKey);
      alterFileName = alterFileName + "." + fileExt;

      // file is image
      // how to resize ?

      // width, height is px value
      Integer width = AssetViewService.getResizeWidth(resizeOptions);
      Integer height = AssetViewService.getResizeHeight(resizeOptions);


      // 원본 파일의 비율을 유지하면서 리사이즈를 해야 한다.
      // 원본 파일의 가로/세로 비율이 1:1 이 아니라면 원본 파일의 가로/세로 비율을 유지하면서 리사이즈 해야 한다.
      // 원본 파일의 가로/세로 비율이 1:1 이라면 그냥 리사이즈 한다.
      // 만약 원본 파일이 320*240 이고 리사이즈 옵션이 100*100 이라면 100*75 로 리사이즈 한다.
      // 만약 원본 파일이 320*380 이고 리사이즈 옵션이 100*100 이라면 (320/380) * 100 을 계산해서 84.2 * 100 으로 리사이즈 한다.
      // 즉, 가로가 크면 가로를 기준으로 리사이즈 하고, 세로가 크면 세로를 기준으로 리사이즈 한다.

      java.awt.image.BufferedImage originalImage = javax.imageio.ImageIO.read(file);
      int originalWidth = originalImage.getWidth();
      int originalHeight = originalImage.getHeight();
      
      double ratio;
      if (originalWidth >= originalHeight) {
        // 가로가 더 길거나 같은 경우 가로를 기준으로 비율 계산
        ratio = (double) originalHeight / originalWidth;
        height = (int) Math.round(width * ratio);
      } else {
        // 세로가 더 긴 경우 세로를 기준으로 비율 계산 
        ratio = (double) originalWidth / originalHeight;
        width = (int) Math.round(height * ratio);
      }
      
      // quality is 1 ~ 100
      Integer quality = AssetViewService.getResizeQuality(resizeOptions);

      File resized = File.createTempFile("resized_", "." + fileExt);
      Thumbnails.of(file)
          .size(width, height)
          .outputQuality(quality / 100.0)
          .toFile(resized);

      AssetUpload<InputStream> fileUpload = new AssetUpload<InputStream>()
          .withDescription(asset.getDescription())
          .withName(asset.getName() + "_RESIZED_"+ resizeOptionCacheKey)
          .withServiceName(asset.getServiceName())
          .withAssetType(asset.getAssetType())
          .withAltText(asset.getAltText())
          .withFileName(alterFileName)
          .withServiceId(asset.getServiceId())
          .withTenantAlias(asset.getTenantAlias())
          .withTags(asset.getTags())
          .withUploadFile(new FileInputStream(resized));

      AssetUploadResult uploadResult = AssetManageServiceHelper.uploadAsset(new AssetUploadForm<InputStream>().addFile(fileUpload));
      UploadFile uploadFile = uploadResult.getAssets().get(0);

      assetService.createAssetResize(asset, uploadFile, resizeOptions);

      asset = assetService.findEntityById(uploadFile.getId());

    }
    return asset;
  }

  @Override
  public ExtensionResultStatusType uploadFile(AssetUpload<InputStream> assetUpload,
      ExtensionResultHolder<UploadFile> resultHolder)
      throws Exception {

    UploadFile uploadFile;

    try {
      if (assetUpload == null) {
        throw new FileServiceException(FileServiceErrorType.NOT_FOUND_ASSET_INFO);
      }

      if (assetUpload.getUploadFile() == null || assetUpload.getUploadFile().available() < 0) {
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);
      }

      TenantHelper.validateTenantAlias(assetUpload.getTenantAlias());

      String tenantAlias = assetUpload.getTenantAlias();

      assetUpload.setTenantAlias(tenantAlias);

      // 여기서는 아직 save 하지 않는다.
      Asset asset = createAsset(assetUpload);

      // 실제 파일이 업로드 되기 전까지 절대!! inputStream 을 소비하면 안 된다.
      FileUploadResult result = fileService.saveInputStreamToFile(assetUpload.getUploadFile(),
          asset.getUrl(), tenantAlias);

      if (result == null) {
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);
      } else {
        String fullUrl = result.getFullUrl();
        if (result.isLocalResource()) {
          // local resource 의 fullUrl 은 파일의 absolutePath 를 그대로 사용한다.
        } else {
          // todo
          // tenantAlias 를 이용해 CDN 정보를 가져와 fullUrl 을 해당 경로로 변경 한다.
        }

        asset.setLocalResource(result.isLocalResource());
        asset.setAbsoluteSource(fullUrl);
        asset.setFileSize(result.getFileSize());
        asset.setMimeType(result.getMimeType());
        asset.setMetadata(result.getAssetMetadata());

        assetService.save(asset);

        uploadFile = new UploadFile(asset.getId(), asset.getName(), asset.getAssetUrl(),
            asset.getMimeType(),
            asset.getAssetType(), asset.getFileSize());

      }

    } catch (IOException e) {
      uploadFile = new UploadFile(new ErrorDTO(e));
    }

    resultHolder.setResult(uploadFile);

    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType modifyAsset(AssetModifyForm modifyForm,
      ExtensionResultHolder<AssetDTO> resultHolder) throws Exception {

    Asset asset = getAsset(modifyForm.getId(), modifyForm.getTenantAlias());

    validateModifyPermission(asset.getCreatedByUserType(), asset.getCreatedBy(),
        modifyForm.getTenantAlias());

    // URL 은 변경하지 않는다.
      /*if (!asset.getUrl().equals(modifyForm.getUrl())) {
        // url 이 변경 됐다면 unique 한 url 로 변경한다.
        String assetUrl = getUniqueAssetUrl(modifyForm.getTenantAlias(), modifyForm.getUrl());
        asset.setUrl(assetUrl);
      }
*/
    asset.setAltText(modifyForm.getAltText());
    asset.setDescription(modifyForm.getDescription());
    asset.setName(modifyForm.getName());
    asset.setTags(modifyForm.getTags());
    asset.setSimpleAttributes(modifyForm.getProperties());

    asset = assetService.save(asset);
    AssetDTO dto = asset.view();

    resultHolder.setResult(dto);

    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType deleteAsset(String id,
      ExtensionResultHolder<Boolean> resultHolder) throws Exception {
    String tenantAlias = TenantHelper.getTenantAliasFromWebRequestContextNotNull();

    Asset asset = getAsset(id, tenantAlias);

    boolean deleted = assetService.delete(asset);

    if (!deleted) {
      throw new AssetException(AssetErrorType.FAILED_TO_DELETE);
    }

    try {
      fileService.removeResource(tenantAlias, asset.getAbsoluteSource(), asset.isLocalResource());
    } catch (Exception e) {
      // just logging
      ExceptionUtil.printStackTrace(e);
    }

    resultHolder.setResult(true);

    return ExtensionResultStatusType.HANDLED;
  }

  protected Asset getAsset(String id, String tenantAlias) throws AssetException {
    Asset asset = assetService.findEntityById(id);

    if (asset == null || !StringUtils.equals(asset.getTenantAlias(), tenantAlias)) {
      throw new AssetException(AssetErrorType.ASSET_NOT_FOUND);
    }
    return asset;
  }

  @Override
  public ExtensionResultStatusType deleteAssets(RemoveAssetDTO removeAssetDTO,
      ExtensionResultHolder<Boolean> resultHolder) throws Exception {

    if (removeAssetDTO.isAvailable()) {
      String tenantAlias = removeAssetDTO.getTenantAlias();
      if (StringUtils.isEmpty(tenantAlias)) {
        tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
      }

      List<String> assetIds = new ArrayList<>();
      List<Asset> assets = new ArrayList<>();

      for (String id : removeAssetDTO.getIds()) {
        Asset asset = getAsset(id, tenantAlias);
        assetIds.add(asset.getId());
        assets.add(asset);
      }

      if (CollectionUtils.isNotEmpty(assetIds)) {

        assetService.deleteAll(new DeleteForm<String>().withIds(assetIds), true);

        resultHolder.setResult(true);
      } else {
        resultHolder.setResult(false);
      }

      /*
       * FileRemoveResource 를 만들어 한번에 처리하도록 추가 처리 필요 (for test)
       */
      try {
        for (Asset asset : CollectionUtils.emptyIfNull(assets)) {
          fileService.removeResource(tenantAlias, asset.getAbsoluteSource(), asset.isLocalResource());
        }
      } catch (Exception e) {
        // just logging
        ExceptionUtil.printStackTrace(e);
      }

    } else {
      throw new AssetException(AssetErrorType.ID_NOT_FOUND);
    }

    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType getSearchResult(SearchForm searchForm,
      ExtensionResultHolder<ResponseListWrapper<AssetDTO, SearchForm>> resultHolder) throws Exception {

    ResponseListWrapper<AssetDTO, SearchForm> result = assetService.createResponseListWrapper(searchForm);

    resultHolder.setResult(result);

    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType getResponseDataByUrl(String tenantAlias, String url,
      ExtensionResultHolder<AssetDTO> resultHolder) throws Exception {

    Asset asset = assetService.findAssetByUrl(url);

    if (asset == null) {
      throw new AssetException(AssetErrorType.ASSET_NOT_FOUND);
    }

    resultHolder.setResult(asset.view());

    return ExtensionResultStatusType.HANDLED;
  }

  @Override
  public ExtensionResultStatusType getResponseDataById(String tenantAlias, String id,
      ExtensionResultHolder<AssetDTO> resultHolder) throws Exception {
    Asset asset = getAsset(id, tenantAlias);

    resultHolder.setResult(asset.view());

    return ExtensionResultStatusType.HANDLED;
  }

  protected Asset createAsset(AssetUpload<?> assetUpload) {

    String assetUrl = assetUpload.getAssetUrl();

    assetUrl = getUniqueAssetUrl(assetUpload.getTenantAlias(), assetUrl);

    return Asset.create(assetUpload, assetUrl);

  }

  /**
   * Check if there are duplicate files. Make a unique url. 중복된 파일이 있는지 확인해 유니크한 url 을 만든다.
   *
   * @param tenantAlias tenantAlias
   * @param assetUrl assetUrl
   * @return unique asset url
   */
  protected String getUniqueAssetUrl(String tenantAlias, String assetUrl) {

    String fileExtension = FileUtil.getFileExtension(assetUrl);

    if (AssetSettings.getAssetSettings().isPreserveFileName()) {
      // filename 을 XXX_NNN 형태로 변경한다.
      String alternativeFileName = AssetSettings.getAssetSettings().getAlternativeFileName();
      String uuid = TSIDUtil.tsId();

      assetUrl = getFullFileName(alternativeFileName + "_" + uuid, fileExtension);

    }

    /*
     * assetUrl 은 반드시 / 로 시작한다.
     */
    if (!StringUtils.startsWith(assetUrl, "/")) {
      assetUrl = "/" + assetUrl;
    }

    Asset asset = assetService.findAssetByUrl(assetUrl);

    // 중복된 파일이 없다면 그냥 리턴한다.
    if (asset == null) {
      return assetUrl;
    }

    int count = 0;
    String compareFileName = FileUtil.sanitizeFilename(FilenameUtils.getBaseName(assetUrl), true);

    String uniqueFileName = compareFileName;

    while (true) {

      String fileName = getFullFileName(uniqueFileName, fileExtension);

      Asset exist = assetService.findAssetByUrl(fileName);
      if (exist == null) {
        break;
      }
      uniqueFileName = compareFileName + "_" + count++;

    }

    if (!StringUtils.startsWith(uniqueFileName, "/")) {
      uniqueFileName = "/" + uniqueFileName;
    }

    return uniqueFileName + "." + fileExtension;

  }

  private String getFullFileName(String baseFileName, String fileExtension) {
    String fileName = baseFileName;
    fileName = StringUtils.isNotEmpty(fileExtension) ? fileName + "." + fileExtension : fileName;
    return fileName;
  }

  @Override
  public boolean isEnabled() {
    return !DataProviderConfig.useMongoDB();
  }
}
