/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.domain.data.FileInfo;
import io.rchemist.common.persistence.domain.embedded.AttachAsset;
import io.rchemist.common.persistence.domain.template.presentation.HasFile;
import io.rchemist.common.persistence.domain.template.presentation.HasFileField;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.response.ResponseData;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AssetSearchServiceHelper {

  private static AssetSearchService assetSearchService;

  protected static AssetSearchService getAssetSearchService() {
    if (assetSearchService == null) {
      assetSearchService = ApplicationContextHolder.getBean(AssetSearchService.class);
    }
    return assetSearchService;
  }

  public static List<AttachAsset> getNewAttachAssets(String tenantAlias, HasFile<?> file) {
    List<AttachAsset> attachAssets = new ArrayList<>();

    tenantAlias = StringUtil.toString(tenantAlias, TenantHelper.getTenantAliasFromWebRequestContext());

    for (FileInfo fileInfo : file.getNewFiles()) {

      try {
        ResponseData<AssetDTO> data = getAssetSearchService().getResponseDataById(tenantAlias, fileInfo.getId());

        AssetDTO asset = data.getData();

        attachAssets.add(new AttachAsset()
            .withAssetKey(asset.getId())
            .withAssetUrl(asset.getUrl())
            .withAssetTags(asset.getTags())
        );

      }catch (Exception e){
        // file 이 누락됨, 무시한다.
      }


    }
    return attachAssets;
  }


  public static List<AttachAsset> getNewAttachAssets(HasFile<?> file) {
    return getNewAttachAssets(null, file);
  }

  public static List<AttachAsset> getNewAttachAssets(HasFileField<?> fileField) {
    return getNewAttachAssets(null, fileField);
  }

  public static List<AttachAsset> getNewAttachAssets(String tenantAlias, HasFileField<?> fileField) {
    tenantAlias = StringUtil.toString(tenantAlias, TenantHelper.getTenantAliasFromWebRequestContext());

    List<AttachAsset> attachAssets = new ArrayList<>();

    for (FileInfo fileInfo : CollectionUtils.emptyIfNull(fileField.getNewFiles())) {
      try {
        ResponseData<AssetDTO> data = getAssetSearchService().getResponseDataById(tenantAlias, fileInfo.getId());

        AssetDTO asset = data.getData();

        attachAssets.add(new AttachAsset()
            .withAssetKey(asset.getId())
            .withAssetUrl(asset.getUrl())
            .withAssetTags(asset.getTags())
        );

      }catch (Exception e){
        // file 이 누락됨, 무시한다.
      }
    }

    return attachAssets;

  }


}
