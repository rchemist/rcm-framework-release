/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.data.AssetUploadForm;
import io.rchemist.asset.staticasset.data.AssetUploadResult;
import io.rchemist.common.configuration.ApplicationContextHolder;
import java.io.InputStream;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class AssetManageServiceHelper {

  private static AssetManageService assetManageService;

  public static AssetManageService getAssetManageService() {
    if (assetManageService == null) {
      assetManageService = ApplicationContextHolder.getBean(AssetManageService.class);
    }
    return assetManageService;
  }

  public static void removeAssetByUrl(String tenantAlias, String url) {
    getAssetManageService().deleteAssetByUrl(tenantAlias, url);
  }

  public static AssetUploadResult uploadAsset(AssetUploadForm<InputStream> assetUploadForm) {
    return getAssetManageService().uploadAsset(assetUploadForm);
  }

}
