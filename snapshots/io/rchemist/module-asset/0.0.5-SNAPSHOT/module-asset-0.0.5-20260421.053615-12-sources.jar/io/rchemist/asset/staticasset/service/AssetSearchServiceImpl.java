/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.asset.staticasset.service.extension.AssetServiceExtensionManager;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListWrapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmAssetSearchService")
public class AssetSearchServiceImpl implements AssetSearchService {

  protected final AssetServiceExtensionManager extensionManager;

  protected final AssetCacheManager cacheManager;

  public AssetSearchServiceImpl(AssetServiceExtensionManager extensionManager,
      AssetCacheManager cacheManager) {
    this.extensionManager = extensionManager;
    this.cacheManager = cacheManager;
  }


  @Override
  public ResponseListWrapper<AssetDTO, SearchForm> getSearchResult(SearchForm searchForm,
      ResponseListWrapper<AssetDTO, SearchForm> result) {

    ExtensionResultHolder<ResponseListWrapper<AssetDTO, SearchForm>> resultHolder = new ExtensionResultHolder<>();
    resultHolder.setResult(result);

    try {
      ExtensionResultStatusType status = extensionManager.getProxy().getSearchResult(searchForm, resultHolder);
      return resultHolder.getResult();
    } catch (Exception e) {
      e.printStackTrace();
      result.setError(new ErrorDTO(e));
      return result;
    }
  }

  @Override
  public ResponseData<AssetDTO> getResponseDataByUrl(String tenantAlias, String url)
      throws AssetException {

    ExtensionResultHolder<AssetDTO> resultHolder = new ExtensionResultHolder<>();

    try{

      String id = cacheManager.getIdFromUrl(url);

      if(StringUtils.isNotEmpty(id) && cacheManager.getCache().containsKey(id)){
        return ResponseHelper.result(cacheManager.getCache().get(id));
      }

      ExtensionResultStatusType status = extensionManager.getProxy().getResponseDataByUrl(tenantAlias, url, resultHolder);

      return ResponseHelper.result(resultHolder.getResult());
    }catch (Exception e){
      return ResponseHelper.result(e);
    }

  }

  @Override
  public ResponseData<AssetDTO> getResponseDataById(String tenantAlias, String id)
      throws AssetException {
    ExtensionResultHolder<AssetDTO> resultHolder = new ExtensionResultHolder<>();

    try{

      if(cacheManager.getCache().containsKey(id)){
        return ResponseHelper.result(cacheManager.getCache().get(id));
      }

      ExtensionResultStatusType status = extensionManager.getProxy().getResponseDataById(tenantAlias, id, resultHolder);

      AssetDTO result = resultHolder.getResult();

      cacheManager.putCache(id, result);

      return ResponseHelper.result(result);
    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }
}
