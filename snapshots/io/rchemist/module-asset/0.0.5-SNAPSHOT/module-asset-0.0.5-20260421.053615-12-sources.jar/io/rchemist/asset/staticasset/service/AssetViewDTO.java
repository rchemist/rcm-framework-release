/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssetViewDTO implements Serializable {

  private String absoluteSource;
  private String filename;
  private String mimeType;
  private boolean localResource;

  private Integer width;
  private Integer height;
  private Boolean restrictProportion;

  public AssetViewDTO withAbsoluteSource(String absoluteSource) {
    this.absoluteSource = absoluteSource;
    return this;
  }

  public AssetViewDTO withFilename(String filename) {
    this.filename = filename;
    return this;
  }

  public AssetViewDTO withLocalResource(boolean localResource) {
    this.localResource = localResource;
    return this;
  }

  public AssetViewDTO withWidth(Integer width) {
    this.width = width;
    return this;
  }

  public AssetViewDTO withHeight(Integer height) {
    this.height = height;
    return this;
  }

  public AssetViewDTO withRestrictProportion(Boolean restrictProportion) {
    this.restrictProportion = restrictProportion;
    return this;
  }
}
