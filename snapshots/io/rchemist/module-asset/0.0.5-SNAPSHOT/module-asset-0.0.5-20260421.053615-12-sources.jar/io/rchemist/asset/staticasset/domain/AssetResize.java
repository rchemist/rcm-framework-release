/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.domain;

import io.rchemist.asset.configuration.AssetCacheRegion;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_ASSET_RESIZE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AssetCacheRegion.Asset.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "파일 리사이즈", comment = "특정 파라미터가 들어왔을 경우 저장된 크기와 품질 정보를 바탕으로 해당 파일을 동적으로 리사이즈를 진행할 수도록 한다.")
public class AssetResize implements EssentialEntity<AssetResize>, TenantAlias<AssetResize> {

  @Id
  @IdGenerator
  private Long id;

  @Column(name = "PARAM")
  @KeywordField
  @IndexField
  @Description(name = "파라미터 이름", comment = "이미지 url 뒤에 ?w=100&h=90&q=30 과 같은 형태로 넘어 오는 파라미터를 AssetViewService#getResizeOptionValues 규칙에 따라 문자열로 만든 것")
  private String parameter;

  @Column(name = "ASSET_ID")
  @IndexField
  @KeywordField
  private String assetId;

  @Column(name = "WIDTH")
  private String width;

  @Column(name = "HEIGHT")
  private String height;

  @Column(name = "QUALITY")
  private String quality;

  @Column(name = "ALTER_ASSET_ID")
  @IndexField
  @Description(name = "대체 ASSET ID", comment = "리사이즈 후 저장된 새 Asset 의 ID")
  private String alterAssetId;

}
