/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetViewService {

  String RESIZE_WIDTH = "w";
  String RESIZE_HEIGHT = "h";
  String RESIZE_QUALITY = "q";
  int DEFAULT_MIN_WIDTH = 30;
  String EQUAL_CHAR = "=";
  String SPLIT_CHAR = "-";
  String DEFAULT_RESIZE_QUALITY = "85";
  String MAX_RESIZE_QUALITY = "100";

  static String getResizeOptionValues(Map<String, String> resizeOptions) {
    return RESIZE_WIDTH + EQUAL_CHAR + StringUtil.toString(resizeOptions.get(RESIZE_WIDTH))
        + SPLIT_CHAR
        + RESIZE_HEIGHT + EQUAL_CHAR + StringUtil.toString(resizeOptions.get(RESIZE_HEIGHT))
        + SPLIT_CHAR
        + RESIZE_QUALITY + EQUAL_CHAR + StringUtil.toString(resizeOptions.get(RESIZE_QUALITY));
  }

  static String getResizedFileName(String resizedOptionValues) {
    return StringUtils.replace(resizedOptionValues, EQUAL_CHAR, SPLIT_CHAR);
  }

  static Integer getResizeWidth(Map<String, String> resizeOptions) {
    return NumberUtil.getInteger(resizeOptions.get(RESIZE_WIDTH));
  }

  static Integer getResizeHeight(Map<String, String> resizeOptions) {
    return NumberUtil.getInteger(resizeOptions.get(RESIZE_HEIGHT));
  }

  static Integer getResizeQuality(Map<String, String> resizeOptions) {
    return resizeOptions.containsKey(RESIZE_QUALITY) ? NumberUtil.getInteger(resizeOptions.get(RESIZE_QUALITY)) : Integer.valueOf(DEFAULT_RESIZE_QUALITY);
  }

  void renderAsset(HttpServletRequest request, HttpServletResponse response)
      throws Exception;
}
