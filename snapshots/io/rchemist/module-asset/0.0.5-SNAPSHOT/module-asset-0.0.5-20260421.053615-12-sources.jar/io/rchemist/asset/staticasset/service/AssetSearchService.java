/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.service.exception.AssetErrorType;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.response.ResponseListWrapper;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetSearchService {

  default ResponseListData<AssetDTO, SearchForm> getAssetSearchResult(SearchForm searchForm){

    ResponseListWrapper<AssetDTO, SearchForm> result = new ResponseListWrapper<>();

    Integer page = searchForm.getPage();
    Integer pageSize = searchForm.getPageSize();

    result.setPage(page);
    result.setPageSize(pageSize);
    result.setSorts(searchForm.getSorts());
    result.setSearchForm(searchForm);

    try{

      String tenantAlias = StringUtil.toString(searchForm.getSearchValue("tenantAlias"), TenantHelper.getTenantAliasFromWebRequestContext());

      TenantHelper.validateTenantAlias(tenantAlias);

      result = getSearchResult(searchForm, result);

    }catch (Exception e){
      result.setError(new ErrorDTO(e));
    }

    return ResponseHelper.resultList(result);

  }

  default ResponseData<AssetDTO> getAsset(String tenantAlias, String id) {

    ResponseData<AssetDTO> result;

    try{

      if(StringUtils.isEmpty(tenantAlias))
        throw new AssetException(AssetErrorType.TENANT_NOT_FOUND);

      if(StringUtils.isEmpty(id))
        throw new AssetException(AssetErrorType.ID_NOT_FOUND);

      result = getResponseDataById(tenantAlias, id);

    }catch (Exception e){
      result = ResponseHelper.result(null, new ErrorDTO(e));
    }

    return result;
  }

  default ResponseData<AssetDTO> getAssetByUrl(String tenantAlias, String url) {

    ResponseData<AssetDTO> result;

    try{

      if(StringUtils.isEmpty(tenantAlias))
        throw new AssetException(AssetErrorType.TENANT_NOT_FOUND);

      if(StringUtils.isEmpty(url))
        throw new AssetException(AssetErrorType.ASSET_NOT_FOUND);

      result = getResponseDataByUrl(tenantAlias, url);

    }catch (Exception e){
      result = ResponseHelper.result(null, new ErrorDTO(e));
    }

    return result;
  }

  ResponseListWrapper<AssetDTO, SearchForm> getSearchResult(SearchForm searchForm,
      ResponseListWrapper<AssetDTO, SearchForm> result);

  ResponseData<AssetDTO> getResponseDataByUrl(String tenantAlias, String url)
      throws AssetException;

  ResponseData<AssetDTO> getResponseDataById(String tenantAlias, String id)
      throws AssetException;
}
