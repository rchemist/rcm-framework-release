/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.security.AssetSecurityConfig;
import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.data.RemoveAssetDTO;
import io.rchemist.asset.staticasset.service.exception.AssetErrorType;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.asset.staticasset.service.extension.AssetServiceExtensionManager;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import java.io.InputStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmAssetManageService")
@Slf4j
public class AssetManageServiceImpl implements AssetManageService {

  protected final AssetServiceExtensionManager extensionManager;

  protected final AssetCacheManager cacheManager;

  public AssetManageServiceImpl(AssetServiceExtensionManager extensionManager,
      AssetCacheManager cacheManager) {
    this.extensionManager = extensionManager;
    this.cacheManager = cacheManager;
  }

  @Override
  @Transactional
  public UploadFile uploadFile(AssetUpload<InputStream> assetUpload)
      throws Exception {

    // 파일명 보안 검증 및 변환
    String originalFileName = assetUpload.getFileName();
    if (StringUtils.isNotEmpty(originalFileName)) {
      // 업로드 가능 여부 확인
      if (!AssetSecurityConfig.isUploadAllowed(originalFileName)) {
        log.warn("Blocked file upload attempt: {}", originalFileName);
        throw new FileServiceException(FileServiceErrorType.INVALID_FILE_TYPE);
      }
      
      // 안전한 파일명으로 변환
      String safeFileName = AssetSecurityConfig.getSafeFileName(originalFileName);
      if (safeFileName == null) {
        log.warn("Failed to create safe filename for: {}", originalFileName);
        throw new FileServiceException(FileServiceErrorType.INVALID_FILE_TYPE);
      }
      
      // 파일명이 변경된 경우 로깅
      if (!safeFileName.equals(originalFileName)) {
        log.info("File renamed for security: {} -> {}", originalFileName, safeFileName);
        assetUpload.setFileName(safeFileName);
      }
    }

    ExtensionResultHolder<UploadFile> resultHolder = new ExtensionResultHolder<>();

    ExtensionResultStatusType status = extensionManager.getProxy().uploadFile(assetUpload, resultHolder);
    return resultHolder.getResult();

  }

  @Override
  @Transactional
  public ResponseData<AssetDTO> modifyAsset(AssetModifyForm modifyForm) {

    ResponseData<AssetDTO> result;

    try {

      ExtensionResultHolder<AssetDTO> resultHolder = new ExtensionResultHolder<>();
      ExtensionResultStatusType status = extensionManager.getProxy().modifyAsset(modifyForm, resultHolder);

      AssetDTO dto = resultHolder.getResult();

      cacheManager.evict(dto.getId());

      result = ResponseHelper.result(dto);

    } catch (Exception e) {
      result = ResponseHelper.result(null, new ErrorDTO(e));
    }

    return result;
  }

  @Override
  @Transactional
  public ResponseData<Boolean> deleteAsset(String id) {

    ExtensionResultHolder<Boolean> resultHolder = new ExtensionResultHolder<>();

    try{

      ExtensionResultStatusType status = extensionManager.getProxy().deleteAsset(id, resultHolder);

      boolean result = resultHolder.getResult();

      if(result){
        cacheManager.evict(id);
      }


      return ResponseHelper.result(result);
    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }

  @Override
  @Transactional
  public ResponseData<Boolean> deleteAssets(RemoveAssetDTO removeAssetDTO) {
    ExtensionResultHolder<Boolean> resultHolder = new ExtensionResultHolder<>();

    try{
      ExtensionResultStatusType status = extensionManager.getProxy().deleteAssets(removeAssetDTO, resultHolder);

      cacheManager.evict(removeAssetDTO.getIds());

      return ResponseHelper.result(resultHolder.getResult());
    }catch (Exception e){
      return ResponseHelper.result(e);
    }
  }

  @Override
  @Transactional
  public ResponseData<Boolean> deleteAssetByUrl(String tenantAlias, String url) {

    try {
      if (StringUtils.isEmpty(tenantAlias)) {
        tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
      }

      if (StringUtils.isEmpty(url))
        throw new AssetException(AssetErrorType.REQUIRED_URL);

      ExtensionResultHolder<AssetDTO> resultHolder = new ExtensionResultHolder<>();

      extensionManager.getProxy().getResponseDataByUrl(tenantAlias, url, resultHolder);

      AssetDTO dto = resultHolder.getResult();

      return deleteAsset(dto.getId());

    }catch (Exception e) {
      return ResponseHelper.result(e);
    }
  }
}
