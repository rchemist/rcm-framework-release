/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service;

import io.rchemist.asset.configuration.AssetCacheRegion.AssetSearch;
import io.rchemist.asset.staticasset.dao.AssetDao;
import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.domain.Asset;
import io.rchemist.asset.staticasset.domain.AssetResize;
import io.rchemist.asset.staticasset.service.exception.AssetErrorType;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.Map;
import javax.cache.Cache;
import lombok.Getter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmAssetService")
public class AssetService implements ResponseEntityListService<Asset, AssetDTO, AssetUpload<?>, AssetModifyForm, SearchForm, String, AssetException> {

  protected final AssetDao assetDao;

  @Getter
  protected final Cache<String, AssetDTO> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  public AssetService(AssetDao assetDao, CommonCacheManager cacheManager) {
    this.assetDao = assetDao;
    this.entityCache = cacheManager.getOrCreateCache(AssetSearch.SEARCH_ENTITY, AssetDTO.class);
    this.searchResultCache = cacheManager.getOrCreateCache(AssetSearch.SEARCH_RESULT, ResponseListWrapperCache.class);
  }

  @Override
  public CommonSearchRepository<Asset, String> getRepository() {
    return assetDao.getRepository();
  }

  @Override
  public AssetException entityNotFoundException() {
    return new AssetException(AssetErrorType.ASSET_NOT_FOUND);
  }

  @Override
  public Asset createEntity(AssetUpload<?> assetUpload) throws AssetException {
    return Asset.create(assetUpload, assetUpload.getAssetUrl());
  }

  @Override
  public Asset updateEntity(Asset entity, AssetModifyForm assetModifyForm) throws AssetException {
    return null;
  }

  @Override
  public AssetDTO getView(Asset entity, EntityViewType viewType) {
    return entity.view();
  }

  @Override
  public SearchContext<Asset, SearchForm> getSearchContext(SearchForm searchForm) {
    return new CommonSearchContext<>(Asset.class, searchForm);
  }

  public Asset findAssetByUrl(String url) {
    return assetDao.getRepository().findAssetByUrl(url);
  }

  public AssetResize findByAssetIdAndParameter(String id, String parameter) {
    return assetDao.getResizeRepository().findByAssetIdAndParameter(id, parameter);
  }

  @Transactional
  public void createAssetResize(Asset originAsset, UploadFile uploadFile, Map<String, String> resizeOptions) {

    String resizeOptionCacheKey = AssetViewService.getResizeOptionValues(resizeOptions);

    AssetResize assetResize = new AssetResize();
    assetResize.setAssetId(originAsset.getId());
    assetResize.setAlterAssetId(uploadFile.getId());
    assetResize.setParameter(resizeOptionCacheKey);
    assetResize.setTenantAlias(originAsset.getTenantAlias());
    assetResize.setWidth(resizeOptions.get(AssetViewService.RESIZE_WIDTH));
    assetResize.setHeight(resizeOptions.get(AssetViewService.RESIZE_HEIGHT));
    assetResize.setQuality(resizeOptions.get(AssetViewService.RESIZE_QUALITY));

    assetDao.getResizeRepository().save(assetResize);
  }
}
