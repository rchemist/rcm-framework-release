/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service.extension;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.data.RemoveAssetDTO;
import io.rchemist.asset.staticasset.service.AssetViewDTO;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapper;
import jakarta.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.Map;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetServiceExtensionHandler extends ExtensionHandler {

  ExtensionResultStatusType getAssetView(HttpServletRequest request,
      String fileName, Map<String, String> resizeOptions, ExtensionResultHolder<AssetViewDTO> resultHolder)
      throws Exception;

  ExtensionResultStatusType uploadFile(AssetUpload<InputStream> assetUpload, ExtensionResultHolder<UploadFile> resultHolder)
      throws Exception;

  ExtensionResultStatusType modifyAsset(AssetModifyForm modifyForm, ExtensionResultHolder<AssetDTO> resultHolder)
      throws Exception;

  ExtensionResultStatusType deleteAsset(String id, ExtensionResultHolder<Boolean> resultHolder)
      throws Exception;

  ExtensionResultStatusType deleteAssets(RemoveAssetDTO removeAssetDTO, ExtensionResultHolder<Boolean> resultHolder)
      throws Exception;

  ExtensionResultStatusType getSearchResult(SearchForm searchForm, ExtensionResultHolder<ResponseListWrapper<AssetDTO, SearchForm>> resultHolder) throws Exception;

  ExtensionResultStatusType getResponseDataByUrl(String tenantAlias, String url,
      ExtensionResultHolder<AssetDTO> resultHolder) throws Exception;

  ExtensionResultStatusType getResponseDataById(String tenantAlias, String id, ExtensionResultHolder<AssetDTO> resultHolder)
      throws Exception;
}
