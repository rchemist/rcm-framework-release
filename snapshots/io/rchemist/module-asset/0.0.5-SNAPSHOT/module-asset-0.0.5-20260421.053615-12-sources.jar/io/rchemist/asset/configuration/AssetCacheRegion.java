/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.configuration;

import io.rchemist.common.cache.CacheConfiguration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class AssetCacheRegion {

  public static final int TTL_ONE_HOUR = 60 * 60;
  public static final int TTL_ONE_DAY = 60 * 60 * 24;

  public static final int MAX_ENTRIES = 10000;

  public static final int SEARCH_MAX_ENTRIES = 100;

  public static class Asset {
    public static final String ENTITY = "asset-entity";
    public static final String DATA = "asset-data";
    public static final String ENTITY_URL = "asset-url-entity";
    public static final String MONGO_ENTITY = "asset-mongo-entity";
    public static final String MONGO_ENTITY_URL = "asset-url-mongo-entity";
    public static final String VIEW = "asset-view";
    public static final String QUERY = "asset-query";
    public static final String RESIZE = "asset-resize";
    public static final String MONGO_RESIZE = "asset-mongo-resize";


  }

  public static class AssetSearch {

    public static final CacheConfiguration SEARCH_RESULT = new CacheConfiguration("asset-search-result", SEARCH_MAX_ENTRIES, TTL_ONE_HOUR);
    public static final CacheConfiguration SEARCH_ENTITY = new CacheConfiguration("asset-search-entity", MAX_ENTRIES * 10, TTL_ONE_DAY);

  }


}
