/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.controller;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetDataExample;
import io.rchemist.asset.staticasset.data.AssetModifyForm;
import io.rchemist.asset.staticasset.data.AssetUploadForm;
import io.rchemist.asset.staticasset.data.AssetUploadResult;
import io.rchemist.asset.staticasset.data.AssetUploadResult.UploadFile;
import io.rchemist.asset.staticasset.data.RemoveAssetDTO;
import io.rchemist.asset.staticasset.service.AssetManageService;
import io.rchemist.asset.staticasset.service.AssetSearchService;
import io.rchemist.common.documentation.Example;
import io.rchemist.common.documentation.RestEndpoint;
import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.file.service.exception.FileServiceErrorType;
import io.rchemist.common.file.service.exception.FileServiceException;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.transformer.ConditionalExcludeScan;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseHelper;
import io.rchemist.common.web.response.ResponseListData;
import jakarta.validation.Valid;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@RestController
@RequestMapping("/asset")
@ConditionalExcludeScan(value = RestController.class)
public class AssetManageController {

  private final AssetSearchService assetSearchService;
  private final AssetManageService assetManageService;

  public AssetManageController(AssetSearchService assetSearchService,
      AssetManageService assetManageService) {
    this.assetSearchService = assetSearchService;
    this.assetManageService = assetManageService;
  }

  @RequestMapping(path = "/own", method = {GET, POST})
  public ResponseListData<AssetDTO, SearchForm> getOwnAssets(@Valid @RequestBody SearchForm searchForm){

    SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();
    String createdBy = authentication != null ? authentication.getUserId() : null;
    searchForm.filterEquals("createdBy", createdBy);

    return assetSearchService.getAssetSearchResult(searchForm);
  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @PostMapping(path = "/upload")
  public ResponseData<AssetUploadResult> uploadAsset(@ModelAttribute AssetUploadForm<MultipartFile> assetUploadForm) {
    AssetUploadResult result = assetManageService.uploadAssetUsingForm(assetUploadForm);

    try {
      if(result == null || CollectionUtils.isEmpty(result.getAssets()))
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);

      return ResponseHelper.result(result);

    } catch (Exception e) {
      return ResponseHelper.result(null, new ErrorDTO(e));
    }

  }

  @PostMapping(value = "/upload-single", produces = "application/text;charset=utf-8")
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 업로드 (시퀀스 ID 또는 URL 응답)", description = "클라이언트에서 파일을 올릴 때 사용. 파일을 올린 후 Parameter 로 들어온 returnId 값에 따라 "
      + "True 일 경우는 Asset 의 시퀀스 ID 가 리턴되며, False 일 경우 /url/file.ext?assetKey=key&fileSize=size 와 같은 형태로 리턴된다. 기본값은 False 이다.")
  public String uploadAsset(@RequestParam(required = false) MultipartFile file, @RequestParam(defaultValue = TenantHelper.DEFAULT_TENANT_ALIAS) String tenantAlias, @RequestParam(defaultValue = "false") Boolean returnId) {
    return assetManageService.uploadSingleFile(file, tenantAlias, returnId);
  }

  @PostMapping(value = "/upload-single-id", produces = "application/text;charset=utf-8")
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 업로드 (시퀀스 ID 응답)", description = "클라이언트에서 파일을 올릴 때 사용. 파일을 올린 후 Asset 의 시퀀스 ID 가 리턴된다.")
  public String uploadAssetSingleId(@RequestParam(required = false) MultipartFile file, @RequestParam(defaultValue = TenantHelper.DEFAULT_TENANT_ALIAS, required = false) String tenantAlias) {
    if(StringUtils.isEmpty(tenantAlias))
      tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
    return assetManageService.uploadSingleFile(file, tenantAlias, true);
  }

  @PostMapping(value = "/upload-file", produces = MediaType.APPLICATION_JSON_VALUE)
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 업로드 (URL 응답)", description = "클라이언트에서 파일을 올릴 때 사용. 파일을 올린 후 /url/file.ext?assetKey=key&fileSize=size 와 같은 형태로 리턴된다.")
  public ResponseEntity<UploadFile> uploadAssetSingleFile(@RequestParam(required = false) MultipartFile file, @RequestParam(defaultValue = TenantHelper.DEFAULT_TENANT_ALIAS, required = false) String tenantAlias) {
    if(StringUtils.isEmpty(tenantAlias))
      tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
    try {
      UploadFile uploadFile = assetManageService.uploadSingleFile(file, tenantAlias);
      return ResponseEntity.ok(uploadFile);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 정보 검색", description = "RequestBody 로 AssetSearchForm 을 전송하여 파일에 대해 검색")
  public ResponseListData<AssetDTO, SearchForm> getAssets(@Valid @RequestBody @Example(AssetDataExample.ASSET_SEARCH_FORM) SearchForm searchForm){
    return assetSearchService.getAssetSearchResult(searchForm);
  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @GetMapping(value = "/{id}")
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 정보 조회 (시퀀스 ID)", description = "Asset 시퀀스 ID 를 전송하여 파일에 대해 검색")
  public ResponseData<AssetDTO> getAsset(@PathVariable String id){
    String tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
    return assetSearchService.getAsset(tenantAlias, id);
  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @GetMapping(value = "/find/{url}")
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 정보 조회 (URL)", description = "Asset Url 을 전송하여 파일에 대해 검색")
  public ResponseData<AssetDTO> getAssetByUrl(@PathVariable String url){
    String tenantAlias = TenantHelper.getTenantAliasFromWebRequestContext();
    return assetSearchService.getAssetByUrl(tenantAlias, url);
  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @DeleteMapping(value = "/delete")
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 삭제 (멀티 파일)", description = "RequestBody 로 RemoveAssetDTO 를 전송하여 파일 삭제 처리. 복수의 파일을 삭제할 때 사용")
  public ResponseData<Boolean> deleteAssets(@RequestBody @Example(AssetDataExample.REMOVE_ASSET_DTO) RemoveAssetDTO removeAssetDTO){
    return assetManageService.deleteAssets(removeAssetDTO);
  }


  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @PutMapping(value = "/{id}")  // 이 end point 는 request body 로 값을 전달해야 한다.
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 정보 수정", description = "Asset 시퀀스 ID 와 RequestBody 로 AssetModifyForm 을 전송하여 파일 정보 수정 처리")
  public ResponseData<AssetDTO> modifyAsset(@PathVariable String id, @Valid @RequestBody @Example(AssetDataExample.ASSET_MODIFY_FORM) AssetModifyForm modifyForm){

    if(!StringUtils.equals(id, modifyForm.getId()))
      modifyForm.setId(id);

    ResponseData<AssetDTO> result = assetManageService.modifyAsset(modifyForm);

    try{
      if(result == null)
        throw new FileServiceException(FileServiceErrorType.FAILED_TO_UPLOAD_FILE);

      return result;
    }catch (Exception e){
      return ResponseHelper.result(null, new ErrorDTO(e));
    }

  }

  @Secured({"ROLE_ADMIN", "ROLE_CMS", "ROLE_ASSET"})    // 나중에 Role hierarchy 처리가 완료되면 이 부분을 ASSET 하나만 남긴다.
  @DeleteMapping(value = "/{id}")  // 이 end point 는 request body 로 값을 전달해야 한다.
  @RestEndpoint(stage = "파일 정보 관리", value = "파일 삭제 (시퀀스 ID)", description = "Asset 시퀀스 ID 를 전송하여 파일 삭제 처리")
  public ResponseData<Boolean> deleteAsset(@PathVariable String id){

    return assetManageService.deleteAsset(id);

  }


}
