/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.configuration;

import io.rchemist.asset.staticasset.controller.AssetView;
import io.rchemist.asset.staticasset.controller.AssetViewController;
import io.rchemist.common.file.service.FileService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Configuration
public class AssetViewHandlerMapping {

  protected final AssetView view;

  public AssetViewHandlerMapping(@Qualifier(value =  AssetView.VIEW_NAME) AssetView view) {
    this.view = view;
  }

  @Bean
  SimpleUrlHandlerMapping staticResourceHandlerMapping(){

    SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
    mapping.setOrder(Integer.MIN_VALUE);

    Map<String, Object> map = new HashMap<>();
    map.put("/"+FileService.getStaticResourcePrefix()+"/**", new AssetViewController(view));
    mapping.setUrlMap(map);

    return mapping;

  }


}
