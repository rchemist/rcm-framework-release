/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.rchemist.asset.configuration.AssetCacheRegion;
import io.rchemist.asset.staticasset.data.AssetDTO;
import io.rchemist.asset.staticasset.data.AssetUpload;
import io.rchemist.common.file.service.FileService;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.service.AuditUtil;
import io.rchemist.common.persistence.jpa.domain.template.EssentialUUIDEntity;
import io.rchemist.common.persistence.jpa.domain.template.NameDescription;
import io.rchemist.common.persistence.jpa.domain.template.SimpleAttributes;
import io.rchemist.common.persistence.jpa.domain.template.TagsMapping;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.util.FileUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.util.data.AssetMetadata;
import io.rchemist.common.util.type.AssetType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.engine.backend.types.Sortable;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_ASSET")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = AssetCacheRegion.Asset.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "파일 관리", comment = "파일 관리")
public class Asset implements EssentialUUIDEntity<Asset>, TenantAlias<Asset>, TagsMapping<Asset>,
    NameDescription<Asset>, SimpleAttributes<Asset> {

  @Id
  @IdGenerator
  private String id;

  @Column(name = "ALT_TEXT")
  @Description(name = "Asset Alt Text", comment = "Alternative Text (대체 문구)로 검색엔진 또는 시각 장애인을 위한 Asset 설명 문구")
  private String altText;

  @Column(name = "ASSET_TYPE")
  @KeywordField
  @Description(name = "ASSET 유형", comment = "ASSET 유형. 파일 또는 링크로 ASSET 을 업로드 한다.")
  private AssetType assetType;

  @Column(name = "SERVICE_NAME")
  @KeywordField
  @Description(name = "서비스 이름", comment = "Asset이 연결된 서비스 이름")
  private String serviceName;

  @Column(name = "SERVICE_ID")
  @KeywordField
  @Description(name = "서비스 엔티티 ID", comment = "Asset을 등록한 서비스의 엔티티 ID")
  private String serviceId;

  @Column(name = "MIME_TYPE")
  @Description(name = "MIME 타입", comment = "MIME 타입")
  private String mimeType;

  @Column(name = "FILE_SIZE")
  @Description(name = "파일 사이즈", comment = "파일 사이즈")
  private Long fileSize;

  @Column(name = "FILE_EXT")
  @KeywordField
  @Description(name = "파일 확장자", comment = "파일 확장자")
  private String fileExtension;

  @Column(name = "IMAGE_WIDTH")
  @Description(name = "파일 가로 크기", comment = "파일의 가로 크기")
  private Integer width;

  @Column(name = "IMAGE_HEIGHT")
  @Description(name = "파일 세로 크기", comment = "파일의 세로 크기")
  private Integer height;

  @Column(name = "IS_LOCAL")
  @Description(name = "로컬 리소스 여부", comment = "cloud 에 적재된 리소스라면 false")
  private Boolean localResource;

  @Column(name = "ABS_SOURCE")
  @Description(name = "파일의 실제 경로", comment = "로컬파일인 경우 파일의 실제 위치, cloud(CDN)의 경우 도메인을 포함한 전체 리소스 url")
  private String absoluteSource;

  @Column(name = "URL")
  @IndexField
  @Description(name = "URL", comment = "Front Site에서 이 정보에 접근할 수 있는 URL 정보")
  @KeywordField(sortable = Sortable.YES)
  protected String url;

  public void setMetadata(AssetMetadata metadata){
    if(metadata != null){
      this.width = metadata.getWidth();
      this.height = metadata.getHeight();
    }
  }

  public boolean isLocalResource(){
    return BooleanUtils.toBoolean(localResource);
  }

  public static Asset create(@Valid @NotNull AssetUpload upload, @Valid @NotNull String assetUrl){

    Asset asset = new Asset();
    asset.setAssetType(upload.getAssetType());
    asset.setName(StringUtil.toString(upload.getName(), upload.getFileName()));
    asset.setDescription(upload.getDescription());
    asset.setAltText(upload.getAltText());
    asset.setServiceName(upload.getServiceName());
    asset.setServiceId(upload.getServiceId());
    asset.setTags(upload.getTags());

    asset.setUrl(assetUrl);
    asset.setTenantAlias(upload.getTenantAlias());
    asset.setFileExtension(FileUtil.getFileExtension(assetUrl));

    return asset;

  }

  @JsonIgnore
  public String getAssetUrl(){
    return FileService.getStaticResourcePrefixWithSeparator() + getUrl();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Asset asset)) {
      return false;
    }
    return Objects.equals(getFileSize(), asset.getFileSize()) && Objects.equals(getId(), asset.getId())
        && Objects.equals(getName(), asset.getName()) && Objects.equals(
        getAssetType(), asset.getAssetType()) && Objects.equals(getServiceName(),
        asset.getServiceName()) && Objects.equals(getUrl(), asset.getUrl())
        && Objects.equals(getMimeType(), asset.getMimeType()) && Objects.equals(
        getAbsoluteSource(), asset.getAbsoluteSource());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getId(), getName(), getAssetType(), getServiceName(), getUrl(),
        getMimeType(),
        getFileSize(), getAbsoluteSource());
  }


  public AssetDTO view() {
    return new AssetDTO()
        .withId(getId())
        .withTenantAlias(getTenantAlias())
        .withUrl(getAssetUrl())
        .withFileExtension(getFileExtension())
        .withFileSize(getFileSize())
        .withHeight(getHeight())
        .withWidth(getWidth())
        .withMimeType(getMimeType())
        .withName(getName())
        .withDescription(getDescription())
        .withAltText(getAltText())
        .withServiceId(getServiceId())
        .withServiceName(getServiceName())
        .withAssetType(getAssetType())
        .withTags(getTags())
        .withProperties(getSimpleAttributes())
        .withAudit(AuditUtil.create(this));
  }

}
