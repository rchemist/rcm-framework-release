/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.dao;

import io.rchemist.asset.staticasset.domain.AssetResize;
import io.rchemist.common.search.data.CommonSearchRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface AssetResizeRepository extends CommonSearchRepository<AssetResize, Long> {

  @Query("select resize from AssetResize resize where resize.assetId = :assetId and resize.parameter = :parameter")
  AssetResize findByAssetIdAndParameter(String assetId, String parameter);
}
