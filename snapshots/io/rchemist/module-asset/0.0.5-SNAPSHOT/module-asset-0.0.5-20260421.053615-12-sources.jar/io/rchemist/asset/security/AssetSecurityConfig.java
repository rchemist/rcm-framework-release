/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.security;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Asset upload security configuration
 * 
 * @author RCM Framework
 */
public class AssetSecurityConfig {
  
  // 완전히 차단할 파일 확장자 (실행 파일 + 모든 스크립트 파일)
  private static final Set<String> BLOCKED_EXTENSIONS = new HashSet<>(Arrays.asList(
    // 실행 파일
    "exe", "com", "bat", "cmd", "sh", "bash", "ps1", "psm1", "msi", 
    "scr", "vbs", "vbe", "ws", "wsf", "wsc", "wsh",
    "jar", "app", "deb", "rpm", "dmg", "pkg", "run", "out",
    "gadget", "application", "msp", "pif", "reg", "scf", "lnk",
    // 서버 스크립트
    "jsp", "jspx", "php", "php3", "php4", "php5", "phtml", "asp", "aspx",
    "asa", "asax", "ascx", "ashx", "asmx", "axd", "cshtml", "vbhtml",
    "cer", "swf", "xap", "pl", "py", "rb", "cgi", "dll", "so",
    // 클라이언트 스크립트
    "html", "htm", "xhtml", "xml", "xsl", "xslt", "svg", "svgz",
    "js", "jsx", "ts", "tsx", "vue", "mjs", "coffee"
  ));
  
  // 안전한 확장자 (화이트리스트)
  private static final Set<String> SAFE_EXTENSIONS = new HashSet<>(Arrays.asList(
    // 이미지
    "jpg", "jpeg", "png", "gif", "bmp", "ico", "webp", "tiff", "tif",
    // 문서
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp",
    "txt", "rtf", "csv", "md", "log",
    // 미디어
    "mp3", "mp4", "avi", "mkv", "mov", "wmv", "flv", "webm", "wav", "flac",
    // 압축
    "zip", "rar", "7z", "tar", "gz", "bz2", "xz",
    // 폰트
    "ttf", "otf", "woff", "woff2", "eot",
    // 데이터
    "json", "yaml", "yml", "ini", "conf", "cfg", "properties"
  ));
  
  /**
   * 파일 확장자가 차단되어야 하는지 확인
   */
  public static boolean isBlockedExtension(String extension) {
    if (extension == null) return false;
    return BLOCKED_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 파일 확장자가 안전한지 확인
   */
  public static boolean isSafeExtension(String extension) {
    if (extension == null) return false;
    return SAFE_EXTENSIONS.contains(extension.toLowerCase());
  }
  
  /**
   * 업로드 가능한 파일인지 확인
   * 
   * @param fileName 파일명
   * @return 업로드 가능 여부
   */
  public static boolean isUploadAllowed(String fileName) {
    if (fileName == null || fileName.isEmpty()) return false;
    
    int dotIndex = fileName.lastIndexOf('.');
    if (dotIndex == -1) return true; // 확장자가 없으면 허용
    
    String extension = fileName.substring(dotIndex + 1);
    
    // 차단 목록에 있으면 차단
    if (isBlockedExtension(extension)) {
      return false;
    }
    
    // 안전 목록에 없으면 차단
    return true;
  }
  
  /**
   * 안전한 파일명 생성 (차단된 파일은 null 반환)
   * 
   * @param originalFileName 원본 파일명
   * @return 안전한 파일명 또는 null
   */
  public static String getSafeFileName(String originalFileName) {
    if (originalFileName == null || originalFileName.isEmpty()) {
      return null;
    }
    
    if (!isUploadAllowed(originalFileName)) {
      return null; // 업로드 차단
    }
    
    return originalFileName; // 허용된 파일은 그대로 사용
  }
}