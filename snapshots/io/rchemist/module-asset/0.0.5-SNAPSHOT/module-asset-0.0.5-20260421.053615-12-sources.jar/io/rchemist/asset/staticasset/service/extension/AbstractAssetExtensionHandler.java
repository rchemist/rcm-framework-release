/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.asset.staticasset.service.extension;

import io.rchemist.asset.staticasset.service.exception.AssetErrorType;
import io.rchemist.asset.staticasset.service.exception.AssetException;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.file.service.FileService;
import io.rchemist.common.persistence.domain.type.AuditUserType;
import io.rchemist.common.security.auth.data.SimpleAuthentication;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.type.SiteType;
import io.rchemist.common.web.request.WebRequestContext;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class AbstractAssetExtensionHandler implements AssetServiceExtensionHandler{

  protected final FileService fileService;

  protected AbstractAssetExtensionHandler(FileService fileService) {
    this.fileService = fileService;
  }

  protected String getResizedFileName(String fileName, String param) {
    return FilenameUtils.removeExtension(fileName)
      + FileService.RESIZE_PREFIX
      + param
      + "."
      + FilenameUtils.getExtension(fileName);
  }

  protected String[] getRequestResizeParameters(
      HttpServletRequest request, Set<String> resizeKeys) {
    String[] params = new String[]{null};

    if(CollectionUtils.isNotEmpty(resizeKeys)){
      request.getParameterNames().asIterator().forEachRemaining(
          p -> {
            if(resizeKeys.contains(p)){
              params[0] = p;
            }
          }
      );
    }
    return params;
  }

  protected void validateModifyPermission(AuditUserType createdByUserType, String createdBy,
      String tenantAlias) throws ErrorTypeException {

    SimpleAuthentication authentication = WebRequestContext.getSimpleAuthentication();

    TenantHelper.validateTenantAlias(tenantAlias);

    if (authentication != null && EnumTypeUtil.equals(authentication.getSiteType(), SiteType.FRONT)) {
      if (authentication.isAnonymous()) {
        throw new AssetException(AssetErrorType.NO_PERMISSION);
      }

      // front 사이트에서 제어하는 것이라면 반드시 user check 을 해야 한다.
      if (createdByUserType != null && createdByUserType.equals(AuditUserType.ADMIN)) {
        throw new AssetException(AssetErrorType.NO_PERMISSION);
      }

      if (createdBy != null && !createdBy.equals(authentication.getUserId())) {
        throw new AssetException(AssetErrorType.NO_PERMISSION);
      }
    }

  }

}
