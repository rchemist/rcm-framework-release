/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import io.rchemist.common.exception.error.ErrorDTO;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.workflow.config.ActivityConfig;
import io.rchemist.workflow.config.ProcessorHolder;
import io.rchemist.workflow.service.WorkflowHelper;
import io.rchemist.workflow.service.exception.WorkflowException;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.core.OrderComparator;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
@Slf4j
@Getter
@Setter
public abstract class AbstractWorkflow<DATA> implements ApplicationListener<ApplicationReadyEvent> {

  protected List<WorkflowActivity<DATA>> activities = new ArrayList<>();

  protected BeanFactory beanFactory;

  protected String workflowName;

  protected ContextFactory<DATA> contextFactory;

  private Boolean enableDocumentation;

  public AbstractWorkflow(String workflowName) {
    this.workflowName = workflowName;// + "_" + UUIDUtil.tsId();
  }

  public Context<DATA> execute(Context<DATA> context) {

    if (log.isDebugEnabled()) {
      log.debug(getWorkflowName() + " workflow is running..");
    }


    List<String> executed = new ArrayList<>();
    Exception activityException = null;

    List<WorkflowActivity<DATA>> activities = getActivities();

    boolean succeed = true;
    for (WorkflowActivity<DATA> activity : activities) {
      if (context.isStopped()) {
        break;
      }

      if (activity.shouldExecute(context)) {
        try {
          activity.execute(context);

          executed.add(activity.getBeanName());

        }catch (WorkflowException e) {
          boolean skipping = e.isPassThroughNoError();

          if (!skipping) {
            activityException = e;
            succeed = false;
            break;
          }

        }

      }

    }

    if (!succeed) {
      handleError(context, activityException, executed, activities);
    }


    return context;
  }

  public Context<DATA> execute(DATA data) {

    if (log.isDebugEnabled()) {
      log.debug(getWorkflowName() + " workflow is prepare context..");
    }

    Context<DATA> context;

    context = createContext(data);

    return execute(context);
  }

  private static <DATA> void handleError(Context<DATA> context,
      Exception activityException, List<String> executed,
      List<WorkflowActivity<DATA>> activities) {
    // rollback needed
    // 역순으로 rollback 을 처리한다.
    log.error("Error occurred while executing workflow: {}", context, activityException);

    if (!context.isError()) {
      context.setError(new ErrorDTO(activityException));
    }

    if (CollectionUtils.isNotEmpty(executed)) {
      for (int i = executed.size() - 1; i >= 0; i--) {
        WorkflowActivity<DATA> activity = activities.get(i);
        try {
          if (activity.getErrorHandler() == null) {
            continue;
          }

          if (log.isDebugEnabled()) {
            log.debug("Handling error for " + activity.getBeanName());
          }

          activity.handleError(context, activityException);
        }catch (Exception e) {
          log.error("Error occurred while handling error: {}", context, e);
        }
      }
    }
  }

  protected Context<DATA> createContext(DATA data) {
    if (contextFactory != null) {
      return contextFactory.createContext(data);
    }
    return new Context<>(data);
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    // onApplicationEvent 는 ApplicationReadyEvent 의 메인 스레드에서 순차 호출된다.
    // 여기서 예외가 바깥으로 새면 Spring SimpleApplicationEventMulticaster 가 뒤의
    // 리스너(다른 Workflow, SyncInitializer 등)를 전부 스킵하고 앱 기동 자체가 실패한다.
    // 특정 Workflow 등록 실패가 다른 Workflow/Listener 로 전파되지 않도록 예외를 삼킨다.
    try {
      // @Activity 어노테이션이 있는 클래스들을 전부 가져와 등록한다.
      setAnnotationBasedActivities(event.getApplicationContext());

      //activities 를 정렬한다.
      if (CollectionUtils.isNotEmpty(activities)) {
        OrderComparator.sort(activities);
      }

      documentProcessorStructure();
    } catch (Exception e) {
      log.error("Failed to register workflow {}, skipping. cause={}",
          getWorkflowName(), e.toString(), e);
    }
  }

  private void documentProcessorStructure() {
    if (enableDocumentation == null) {
      enableDocumentation = WorkflowHelper.isEnableDocumentation();
    }

    if(enableDocumentation) {
      log.info("=================================== WORKFLOW : " + getWorkflowName() + " ===================================");
      if (CollectionUtils.isEmpty(activities)) {
        log.info("        - There is no activities on this workflow.");
      } else {
        for (WorkflowActivity<DATA> activity : activities) {
          log.info("        - " + activity.getBeanName() + " : " + activity.getClass().getName());
          if (activity.getErrorHandler() != null) {
            log.info("            -> ErrorHandler is " + activity.getErrorHandler().getClass().getName());
          }
        }
      }

      log.info("=================================== REGISTERED SUCCESSFULLY ===================================");
    }
  }

  /**
   * RegisterProcessorClassTransformer 에서 자동으로 수집한 액티비티들의 bean 이름을 가지고 자동 등록을 시도한다
   * @param applicationContext
   */
  protected void setAnnotationBasedActivities(ApplicationContext applicationContext){
    List<ActivityConfig> activities = ProcessorHolder.getActivity(getWorkflowName());
    if(CollectionUtils.isNotEmpty(activities)){
      List<WorkflowActivity<DATA>> activityList = new ArrayList<>();

      boolean createBean = activities.size() > 1;

      for(ActivityConfig config : activities){

        Object activity = getBeanObject(applicationContext, config, createBean);

        if(activity instanceof AbstractActivity<?> abstractActivity){
          try{
            // 순서 조정
            abstractActivity.setOrder(config.getPriority());
            // activity 에 등록된 processor name 추가
            abstractActivity.setWorkflowName(getWorkflowName());
            abstractActivity.setActivityName(config.getBeanName());

            if(config.getRollbackHandler() != null){
              try{
                Object rollbackHandler = applicationContext.getBean(config.getRollbackHandler());
                abstractActivity.setErrorHandler((ErrorHandler) rollbackHandler);
              }catch(Exception e){
                log.warn("Error occurred during register rollbackHandler to " + getWorkflowName() + " - " + config.getName());
              }
            }

            // 액티비티 등록
            activityList.add((WorkflowActivity<DATA>) activity);
          }catch(Exception e){
            ExceptionUtil.printStackTrace(e);
          }
        }
      }
      mergeActivities(activityList);
    }
  }

  private Object getBeanObject(ApplicationContext applicationContext, ActivityConfig config, boolean createBean) {

    Object bean = applicationContext.getBean(config.getBeanName());

    if(createBean){

      return applicationContext.getAutowireCapableBeanFactory().createBean(bean.getClass());

    }

    return bean;
  }

  protected void mergeActivities(List<WorkflowActivity<DATA>> activities) {
    if (activities != null) {
      if (CollectionUtils.isNotEmpty(this.activities)) {
        for (WorkflowActivity<DATA> activity : activities) {
          if (!this.activities.contains(activity)) {
            this.activities.add(activity);
          }
        }
        // sort activities
        OrderComparator.sort(this.activities);
      } else {
        this.activities = activities;
      }
    }
  }

}
