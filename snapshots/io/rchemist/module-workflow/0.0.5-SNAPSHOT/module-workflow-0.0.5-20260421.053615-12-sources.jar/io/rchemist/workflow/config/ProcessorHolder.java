/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.config;

import io.rchemist.common.util.MapUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
public class ProcessorHolder implements Serializable {

  protected static Map<String, List<ActivityConfig>> activities = new HashMap<>();

  public static List<ActivityConfig> getActivity(String processor){
    if(MapUtils.isNotEmpty(activities)){
      return activities.get(processor);
    }
    return new ArrayList<>();   // for null safe
  }

  public static void addActivity(String processor, String beanName, String activityName, String description, int priority, String rollbackHandler){
    ActivityConfig config = new ActivityConfig()
        .withName(activityName)
        .withBeanName(beanName)
        .withRollbackHandler(rollbackHandler)
        .withPriority(priority)
        .withDescription(description);
    addActivity(processor, config);
  }

  public static void addActivity(String processor, ActivityConfig config){
    if(activities == null)
      activities = new HashMap<>();

    activities = MapUtil.mergeListHashMap(activities, processor, config, false);
  }

}
