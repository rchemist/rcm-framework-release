/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.service.exception;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class WorkflowException extends ErrorTypeException {

  public WorkflowException(ErrorType errorType){
    super(errorType);
  }

  public WorkflowException(ErrorType errorType, String message) {
    super(errorType, message);
  }

  public WorkflowException(ErrorTypeException exception) {
    super(exception);
  }

  public WorkflowException(String fieldName, ErrorType errorType) {
    super(fieldName, errorType);
  }

  public WorkflowException(String fieldName, String message) {
    super(fieldName, message);
  }

  public static WorkflowException throwException(String message) {
    return new WorkflowException(WorkflowErrorType.SERVER_ERROR, message);
  }

  public static WorkflowException passThroughException(String message) {
    return new WorkflowException(WorkflowErrorType.PASS_THROUGH_NO_ERROR, message);
  }

  public WorkflowErrorType getWorkflowErrorType() {
    if (errorType instanceof WorkflowErrorType type) {
      return type;
    }

    if (errorType != null) {
      return new WorkflowErrorType(errorType.getType(), errorType.getTranslatedType(), errorType.getStatus());
    }

    if (error != null) {
      return new WorkflowErrorType(error.getErrorType(), error.getMessage(), error.getStatus());
    }

    return WorkflowErrorType.SERVER_ERROR;

  }

  public boolean isPassThroughNoError(){
    return getWorkflowErrorType().equals(WorkflowErrorType.PASS_THROUGH_NO_ERROR);
  }

}
