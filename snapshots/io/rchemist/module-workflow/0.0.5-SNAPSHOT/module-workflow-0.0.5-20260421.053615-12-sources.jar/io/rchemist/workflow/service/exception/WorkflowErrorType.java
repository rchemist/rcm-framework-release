/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.service.exception;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.exception.error.ErrorType;
import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * <p>
 * project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
public class WorkflowErrorType extends EnumType<WorkflowErrorType> implements ErrorType {

  public static final WorkflowErrorType SERVER_ERROR = new WorkflowErrorType("SERVER_ERROR", "Server Error",
      HttpStatus.INTERNAL_SERVER_ERROR);

  public static final WorkflowErrorType PASS_THROUGH_NO_ERROR = new WorkflowErrorType("PASS_THROUGH_NO_ERROR", "No error, just skipping.",
      HttpStatus.OK);
  public static final ErrorType FAILED_TO_ROLLBACK = new WorkflowErrorType("FAILED_TO_ROLLBACK", "Failed to rollback",
      HttpStatus.INTERNAL_SERVER_ERROR);

  private final int status;

  public WorkflowErrorType(String type, String friendlyType, int status) {
    super(type, friendlyType);
    this.status = status;
  }
  public WorkflowErrorType(String type, String friendlyType, HttpStatus status) {
    super(type, friendlyType);
    this.status = status.value();
  }
}
