/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.exception.error.ErrorDTO;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Slf4j
public class Context<DATA> {

  public Context(DATA data) {
    this.data = data;
  }

  protected DATA data;

  protected ErrorDTO error;

  protected Object result;

  /**
   * 해당 워크플로우의 액티비티들끼리 공유하기 위한 정보
   */
  protected Map<String, Object> attributes = new HashMap<>();

  /**
   * activity id, 해당 액티비티를 롤백하기 위한 데이터
   * 기본적으로 attributes 와 동일한 방식으로 데이터를 처리하지만, 변수를 별도로 분리한다.
   */
  protected Map<String, Object> rollbackState = new HashMap<>();

  @Getter
  protected boolean stopped = false;

  public boolean isError() {
    return error != null && error.isError();
  }

  public void stop() {
    this.stopped = true;
  }

  public void addAttribute(String key, Object value) {
    this.attributes.put(key, value);
  }

  public void removeAttribute(String key) {
    this.attributes.remove(key);
  }

  public void addRollbackState(String activityId, Object value) {
    this.rollbackState.put(activityId, value);
  }

  public <T> T getRollbackState(String activityId) {
    try {
      if (this.rollbackState.containsKey(activityId)) {
        return (T) this.rollbackState.get(activityId);
      }
      return null;
    }catch (Exception e) {
      // silent
      log.error("Cannot cast rollbackState value");
      return null;
    }
  }

  public void removeRollbackState(String activityId) {
    this.rollbackState.remove(activityId);
  }

  public <T> T getAttribute(String key) {
    try {
      if (this.attributes.containsKey(key)) {
        return (T) this.attributes.get(key);
      }
      return null;
    }catch (Exception e) {
      // silent
      log.error("Cannot cast attribute value");
      return null;
    }
  }

  public <R> R getResult() throws ErrorTypeException {
    if (isError()) {
      throw new ErrorTypeException(error.getMessage(), error);
    }

    return (R) this.result;
  }

}
