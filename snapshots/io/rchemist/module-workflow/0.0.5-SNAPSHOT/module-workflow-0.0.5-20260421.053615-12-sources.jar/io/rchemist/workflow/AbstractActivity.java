/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import io.rchemist.common.util.TSIDUtil;
import io.rchemist.workflow.service.exception.WorkflowException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@Slf4j
public abstract class AbstractActivity<DATA> implements WorkflowActivity<DATA> {

  protected String activityName;

  protected int order;

  protected String workflowName;

  protected ErrorHandler<DATA> errorHandler;

  public AbstractActivity<DATA> withErrorHandler(
      ErrorHandler<DATA> errorHandler) {
    this.errorHandler = errorHandler;
    return this;
  }

  @Override
  public boolean shouldExecute(Context<DATA> context) {
    // 필요한 경우 override 해서 조건을 추가한다. 기본적으로는 일단 true 를 리턴한다.
    return true;
  }

  protected abstract void process(Context<DATA> context) throws WorkflowException;

  protected void setCurrentRollbackState(Context<DATA> context) {
    // Activity 가 수행된 후 롤백이 필요한 경우를 대비해 현재의 롤백 상태를 저장한다.
    // 해당 Activity 단계에서 저장한 데이터를 기록해 롤백 핸들러에서 해당 데이터를 삭제하거나, 원래대로 되돌릴 때
    // 저장된 롤백 정보를 이용한다.
  }

  @Override
  public void execute(Context<DATA> context) throws WorkflowException {
    if (context.isStopped()) {
      return;
    }

    try {
      process(context);

      // 현재 상태를 저장하기
      setCurrentRollbackState(context);

    } catch (WorkflowException e) {
      log.error(e.getMessage(), e);
      if (!e.isPassThroughNoError() && errorHandler != null) {
        try {
          errorHandler.handleError(getActivityName(), context, e);
        } catch (Exception ee) {
          // silent
        }
      }
      throw e;
    }

  }

  public String getActivityName() {
    if (this.activityName == null) {
      this.activityName = getClass().getSimpleName() + TSIDUtil.tsId();
    }
    return this.activityName;
  }

  @Override
  public String getBeanName() {
    return activityName;
  }

  public void setBeanName(@SuppressWarnings("NullableProblems") String name) {
    this.activityName = name;
  }

}
