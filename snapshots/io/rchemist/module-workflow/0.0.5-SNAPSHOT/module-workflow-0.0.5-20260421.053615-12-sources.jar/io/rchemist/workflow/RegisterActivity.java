/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component
public @interface RegisterActivity {

  /**
   * @Component 로 regist 되는 activity 의 beanName
   * @return
   */
  @AliasFor(annotation = Component.class)
  String value();

  // Documentation 자동화를 위한 Activity 이름
  String name() default "";

  // Documentation 자동화를 위한 Activity 에 대한 설명
  String description() default "";

  Activity[] activities();

  @Target(ElementType.ANNOTATION_TYPE)
  @interface Activity {

    String processor();

    int priority();

    String rollbackHandler() default "";

  }

}
