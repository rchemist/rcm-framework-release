/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import io.rchemist.common.util.BytecodeUtil;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.workflow.config.ProcessorHolder;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationMemberValue;
import javassist.bytecode.annotation.ArrayMemberValue;
import javassist.bytecode.annotation.MemberValue;
import lombok.extern.slf4j.Slf4j;
import org.reflections.Reflections;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
@Slf4j
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RegisterActivityAnnotation implements SmartInitializingSingleton {

  @Value("${platform.config.common.workflow.packages:io.rchemist}")
  protected String[] packagesToScan;

  private static final Set<String> loadedActivities = new HashSet<>();

  private static final String REGISTER_ACTIVITY_ANNOTATION = RegisterActivity.class.getName();

  @Override
  public void afterSingletonsInstantiated() {
    log.info("Starting workflow activities registration...");
    long startTime = System.currentTimeMillis();
    
    try {
      Reflections reflections = new Reflections((Object[]) packagesToScan);
      @SuppressWarnings("rawtypes")
      Set<Class<? extends WorkflowActivity>> activities = reflections.getSubTypesOf(WorkflowActivity.class);
      
      log.info("Found {} workflow activities to register", activities.size());
      @SuppressWarnings("unchecked")
      Set<Class<? extends WorkflowActivity<?>>> typedActivities = (Set<Class<? extends WorkflowActivity<?>>>) (Set<?>) activities;
      initializeActivityConfigurations(typedActivities);
      
      long endTime = System.currentTimeMillis();
      log.info("Workflow activities registration completed in {}ms", (endTime - startTime));
    } catch (Exception e) {
      log.error("Failed to register workflow activities", e);
      throw new RuntimeException("Failed to initialize workflow activities", e);
    }
  }

  private void initializeActivityConfigurations(
      Set<Class<? extends WorkflowActivity<?>>> activityClasses) {
    for(Class<? extends WorkflowActivity<?>> activityClass : activityClasses){
      configureActivity(activityClass);
    }
  }

  private void configureActivity(Class<? extends WorkflowActivity<?>> activityClass){
    try {
      if(!loadedActivities.contains(activityClass.getName())){
        CtClass ctClass = BytecodeUtil.getDefrostedCtClass(ClassPool.getDefault(), activityClass.getName());
        ClassFile classFile = BytecodeUtil.getClassFileSafety(ctClass);

        Annotation activity = getActivityAnnotation(classFile);

        if(activity != null){
          addActivityToProcessorHolder(activity);
        }

        loadedActivities.add(activityClass.getName());

      }
    } catch (Exception e) {
      log.error("Failed to register activity: {}", activityClass.getName(), e);
      // do nothing
    }

  }

  private Annotation getActivityAnnotation(ClassFile targetClassFile){
    List<?> attributes = targetClassFile.getAttributes();
    for (Object object : attributes) {

      if (AnnotationsAttribute.class.isAssignableFrom(object.getClass())) {
        // Type 어노테이션으로 @RegisterActivity 가 붙은 모든 클래스를 대상으로 한다
        return BytecodeUtil.getDeclaredAnnotationOnType(targetClassFile, REGISTER_ACTIVITY_ANNOTATION);
      }
    }
    return null;
  }

  private void addActivityToProcessorHolder(Annotation activityAnnotation){
    String beanName = StringUtil.toString(BytecodeUtil.getStringValue(activityAnnotation, "value"), String.valueOf(
        UUID.randomUUID()));
    String name = StringUtil.toString(BytecodeUtil.getStringValue(activityAnnotation, "name"), beanName);
    String description = StringUtil.toString(BytecodeUtil.getStringValue(activityAnnotation, "description"));

    MemberValue member = activityAnnotation.getMemberValue("activities");
    if(member instanceof ArrayMemberValue){
      ArrayMemberValue activities = (ArrayMemberValue) activityAnnotation.getMemberValue("activities");
      for(MemberValue value : activities.getValue()) {
        AnnotationMemberValue annotationValue = (AnnotationMemberValue) value;
        Annotation activity = annotationValue.getValue();
        String processor = BytecodeUtil.getStringValue(activity, "processor");
        Integer priority = NumberUtil.getInteger(BytecodeUtil.getIntegerValue(activity, "priority"), 100);
        String rollbackHandler = BytecodeUtil.getStringValue(activity, "rollbackHandler");

        // 자동 등록을 위한 환경설정
        ProcessorHolder.addActivity(processor, beanName, name, description, priority, rollbackHandler);
      }
    }
  }

}
