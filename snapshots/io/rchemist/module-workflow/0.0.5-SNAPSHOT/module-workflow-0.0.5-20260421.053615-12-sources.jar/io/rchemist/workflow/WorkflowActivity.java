/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow;

import io.rchemist.workflow.service.exception.WorkflowException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.core.Ordered;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
public interface WorkflowActivity<DATA> extends BeanNameAware, Ordered {

  boolean shouldExecute(Context<DATA> context);

  void execute(Context<DATA> context) throws WorkflowException;

  ErrorHandler<DATA> getErrorHandler();
  void setErrorHandler(ErrorHandler<DATA> errorHandler);

  String getBeanName();

  default void handleError(Context<DATA> context, Exception activityException) {
    if (getErrorHandler() != null) {
      getErrorHandler().handleError(getBeanName(), context, activityException);
    }
  }
}
