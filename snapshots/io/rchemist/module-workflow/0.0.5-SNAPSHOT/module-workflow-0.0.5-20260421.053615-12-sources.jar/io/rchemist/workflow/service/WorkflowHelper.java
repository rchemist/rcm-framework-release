/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.workflow.Context;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * <p>
 * project : rcm-commerce
 * <p>
 * Created by kunner
 **/
@Service("rcmWorkflowHelper")
public class WorkflowHelper {

  private static WorkflowHelper helper;

  private static WorkflowHelper getInstance() {
    if (helper == null) {
      helper = ApplicationContextHolder.getBean(WorkflowHelper.class);
    }
    return helper;
  }

  @Value("${platform.config.workflow.enable.documentation:false}")
  private boolean enableDocumentation = false;

  public static boolean isEnableDocumentation() {
    try {
      return getInstance().enableDocumentation;
    }catch (Exception e){
      return false;
    }
  }

  public static void throwsExceptionIfError(Context<?> context) throws ErrorTypeException {
    if (context.isError()) {
      throw new ErrorTypeException(context.getError().getServiceErrorType(), context.getError().getMessage());
    }
  }

  public static <T> T getResult(Context<?> context, T result) throws ErrorTypeException {
    throwsExceptionIfError(context);
    return result;
  }


}
