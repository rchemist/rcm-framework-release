/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.config;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by kunner
 **/
@Getter
@Setter
@EqualsAndHashCode
public class ActivityConfig {

  protected String beanName;
  protected String name;
  protected String description;
  protected int priority;
  protected String rollbackHandler;

  public ActivityConfig withBeanName(String beanName) {
    this.beanName = beanName;
    return this;
  }

  public ActivityConfig withName(String name) {
    this.name = name;
    return this;
  }

  public ActivityConfig withDescription(String description) {
    this.description = description;
    return this;
  }

  public ActivityConfig withPriority(int priority) {
    this.priority = priority;
    return this;
  }

  public ActivityConfig withRollbackHandler(String rollbackHandler) {
    this.rollbackHandler = rollbackHandler;
    return this;
  }
}
