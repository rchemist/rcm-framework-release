/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.config;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class ActivitySpecDTO implements Serializable {

  protected String beanName;

  protected String name;

  protected String description;

  protected Integer priority;

  protected Class activityClass;

  protected Class rollbackHandlerClass;

  public String getName() {
    return StringUtil.toString(name, beanName);
  }

  public ActivitySpecDTO withName(String name) {
    this.name = name;
    return this;
  }

  public ActivitySpecDTO withBeanName(String beanName) {
    this.beanName = beanName;
    return this;
  }

  public ActivitySpecDTO withDescription(String description) {
    this.description = description;
    return this;
  }

  public ActivitySpecDTO withPriority(Integer priority) {
    this.priority = priority;
    return this;
  }

  public ActivitySpecDTO withActivityClass(Class activityClass) {
    this.activityClass = activityClass;
    return this;
  }

  public ActivitySpecDTO withRollbackHandlerClass(Class rollbackHandlerClass) {
    this.rollbackHandlerClass = rollbackHandlerClass;
    return this;
  }

}
