/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.workflow.config;

import io.rchemist.common.util.StringUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
public class ProcessorSpecDTO implements Serializable {

  protected String processorName;

  protected String workflowName;

  protected String description;

  protected Class contextFactoryClass;

  protected List<ActivitySpecDTO> activities = new ArrayList<>();

  public ProcessorSpecDTO withProcessorName(String processorName) {
    this.processorName = processorName;
    return this;
  }

  public ProcessorSpecDTO withWorkflowName(String workflowName) {
    this.workflowName = workflowName;
    return this;
  }

  public ProcessorSpecDTO withContextFactoryClass(Class contextFactoryClass) {
    this.contextFactoryClass = contextFactoryClass;
    return this;
  }

  public ProcessorSpecDTO withActivities(List<ActivitySpecDTO> activities) {
    this.activities = activities;
    return this;
  }

  public ProcessorSpecDTO addActivity(ActivitySpecDTO activity){
    this.activities.add(activity);
    return this;
  }

  public ProcessorSpecDTO addActivity(String beanName, String name, String description, Integer priority, Class activityClass, Class rollbackHandlerClass){
    ActivitySpecDTO activity = new ActivitySpecDTO()
        .withName(name)
        .withBeanName(beanName)
        .withDescription(description)
        .withPriority(priority)
        .withActivityClass(activityClass)
        .withRollbackHandlerClass(rollbackHandlerClass);
    return addActivity(activity);
  }

  public ProcessorSpecDTO withDescription(String description) {
    this.description = description;
    return this;
  }

  public ProcessorSpecDTO sortActivities(){
    if(CollectionUtils.isNotEmpty(activities)){
      Collections.sort(activities, new BeanComparator<>("priority"));
    }
    return this;
  }

  @Override
  public String toString() {
    return "ProcessorSpecDTO{" +
        "workflowName='" + workflowName + '\'' +
        ", contextFactoryClass=" + contextFactoryClass +
        ", activities=" + activities +
        '}';
  }

  public String getWorkflowName() {
    return StringUtil.toString(workflowName, processorName);
  }

  public String getDescription() {
    return StringUtil.toString(description);
  }

  public String print(){
    StringBuilder sb = new StringBuilder();

    sb.append("[#extending-workflow-").append(processorName).append("]");
    sb.append("==== ").append(getWorkflowName());
    sb.append(".이름");
    sb.append(getWorkflowName());
    sb.append("\n\n");
    sb.append(".Bean Name");
    sb.append(processorName).append("\n\n");
    sb.append(".설명");
    sb.append(getDescription()).append("\n\n");
    sb.append(".SeedData");
    sb.append("data" + "\n\n");
    sb.append(".Activities");
    for(ActivitySpecDTO activity : CollectionUtils.emptyIfNull(activities)){
      sb.append("1. ").append(activity.getBeanName());
      if(activity.getRollbackHandlerClass() != null){
        sb.append("\tRollbackHandler: ").append(activity.getRollbackHandlerClass().getName());
      }
    }
    sb.append("{empty}");
    sb.append("{empty}");
    sb.append("\n\n");

    return sb.toString();
  }


}
