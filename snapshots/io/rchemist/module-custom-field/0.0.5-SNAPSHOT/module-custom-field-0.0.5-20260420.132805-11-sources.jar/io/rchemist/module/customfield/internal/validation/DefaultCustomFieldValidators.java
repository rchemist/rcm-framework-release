/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.validation;

import io.rchemist.module.customfield.spi.CustomFieldDescriptor;
import io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry;
import io.rchemist.module.customfield.spi.type.CustomFieldValueCoercer;
import io.rchemist.module.customfield.spi.type.CustomFieldValueType;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidationResult;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidator;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Default validators covering the four legacy checks (required, length,
 * regex, enumeration) plus a type-coercion probe. Ordered numerically so
 * that required runs before regex.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class DefaultCustomFieldValidators {

  private DefaultCustomFieldValidators() {
    // static
  }

  public static List<CustomFieldValidator> pipeline(CustomFieldTypeRegistry registry) {
    List<CustomFieldValidator> list = new ArrayList<>();
    list.add(new Required());
    list.add(new Length());
    list.add(new Regex());
    list.add(new Enumeration());
    list.add(new TypeCoercion(registry));
    return list;
  }

  public static final class Required implements CustomFieldValidator {
    @Override
    public int order() { return 100; }

    @Override
    public void validate(CustomFieldDescriptor d, String raw, CustomFieldValidationResult r) {
      if (d.isRequired() && (raw == null || raw.isEmpty())) {
        r.reject("required", "property '" + d.getPropertyName() + "' is required");
      }
    }
  }

  public static final class Length implements CustomFieldValidator {
    @Override
    public int order() { return 200; }

    @Override
    public void validate(CustomFieldDescriptor d, String raw, CustomFieldValidationResult r) {
      if (raw == null || raw.isEmpty()) return;
      String typeId = d.getTypeId();
      boolean numeric = "NUMBER".equals(typeId) || "DECIMAL".equals(typeId) || "MONEY".equals(typeId);
      if (numeric) {
        BigDecimal value;
        try {
          value = new BigDecimal(raw.trim());
        } catch (NumberFormatException e) {
          return; // TypeCoercion will flag this
        }
        BigDecimal min = parseDecimal(d.getMinLength());
        BigDecimal max = parseDecimal(d.getMaxLength());
        if (min != null && value.compareTo(min) < 0) {
          r.reject("min", "property '" + d.getPropertyName() + "' is less than " + min);
        }
        if (max != null && value.compareTo(max) > 0) {
          r.reject("max", "property '" + d.getPropertyName() + "' is greater than " + max);
        }
      } else {
        Integer min = parseInt(d.getMinLength());
        Integer max = parseInt(d.getMaxLength());
        int len = raw.length();
        if (min != null && len < min) {
          r.reject("minLength",
              "property '" + d.getPropertyName() + "' must be at least " + min + " characters");
        }
        if (max != null && len > max) {
          r.reject("maxLength",
              "property '" + d.getPropertyName() + "' must be at most " + max + " characters");
        }
      }
    }

    private static Integer parseInt(String s) {
      if (s == null || s.isEmpty()) return null;
      try { return Integer.valueOf(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static BigDecimal parseDecimal(String s) {
      if (s == null || s.isEmpty()) return null;
      try { return new BigDecimal(s.trim()); } catch (NumberFormatException e) { return null; }
    }
  }

  public static final class Regex implements CustomFieldValidator {
    @Override
    public int order() { return 300; }

    @Override
    public void validate(CustomFieldDescriptor d, String raw, CustomFieldValidationResult r) {
      if (raw == null || raw.isEmpty()) return;
      String pattern = d.getRegexValidation();
      if (pattern == null || pattern.isEmpty()) return;
      try {
        if (!Pattern.compile(pattern).matcher(raw).matches()) {
          String msg = d.getErrorMessage();
          r.reject("regex", msg == null || msg.isEmpty()
              ? "property '" + d.getPropertyName() + "' failed pattern validation"
              : msg);
        }
      } catch (PatternSyntaxException e) {
        r.reject("regex.pattern", "invalid regex on property '" + d.getPropertyName() + "'");
      }
    }
  }

  public static final class Enumeration implements CustomFieldValidator {
    @Override
    public int order() { return 400; }

    @Override
    public void validate(CustomFieldDescriptor d, String raw, CustomFieldValidationResult r) {
      if (raw == null || raw.isEmpty()) return;
      List<String> options = d.getEnumerationOptions();
      if (options == null || options.isEmpty()) return;
      if (!options.contains(raw)) {
        r.reject("enumeration",
            "property '" + d.getPropertyName() + "' must be one of " + options);
      }
    }
  }

  public static final class TypeCoercion implements CustomFieldValidator {
    private final CustomFieldTypeRegistry registry;

    public TypeCoercion(CustomFieldTypeRegistry registry) {
      this.registry = registry;
    }

    @Override
    public int order() { return 500; }

    @Override
    public void validate(CustomFieldDescriptor d, String raw, CustomFieldValidationResult r) {
      if (raw == null || raw.isEmpty()) return;
      String typeId = d.getTypeId();
      if (typeId == null) return;
      CustomFieldValueType type = registry.find(typeId).orElse(null);
      if (type == null) {
        r.reject("type.unknown", "Unknown type id: " + typeId);
        return;
      }
      try {
        type.coercer().toValue(raw);
      } catch (CustomFieldValueCoercer.CoercionException e) {
        r.reject("type.coercion", e.getMessage());
      }
    }
  }
}
