/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.dao;

import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.module.customfield.domain.CustomField;
import java.util.List;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface CustomFieldRepository extends CommonSearchRepository<CustomField, Long> {

    @Query("select cf from CustomField cf where cf.targetEntityClass = ?1")
    List<CustomField> findCustomFieldByClassName(String className);

    @Query("select cf from CustomField cf where cf.targetEntityClass = ?1 and (cf.active is not null and cf.active = ?2)")
    List<CustomField> findCustomFieldByClassName(String className, Boolean active);

}
