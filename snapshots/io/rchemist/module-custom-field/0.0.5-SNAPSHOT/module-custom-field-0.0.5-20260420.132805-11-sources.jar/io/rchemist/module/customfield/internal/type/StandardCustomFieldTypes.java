/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.type;

import io.rchemist.module.customfield.spi.type.CustomFieldValueCoercer;
import io.rchemist.module.customfield.spi.type.CustomFieldValueCoercer.CoercionException;
import io.rchemist.module.customfield.spi.type.CustomFieldValueType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Built-in {@link CustomFieldValueType} catalogue. These mirror the legacy
 * {@code io.rchemist.common.presentation.type.CustomFieldType} constants so
 * that descriptors migrated from the old Enum keep working by id.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class StandardCustomFieldTypes {

  private StandardCustomFieldTypes() {
    // static
  }

  // ----- coercers first (static-init order matters: each type captures a
  // reference to its coercer, so the coercer must be initialised before the
  // types below reference it).
  private static final CustomFieldValueCoercer INTEGER_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      try {
        return Long.parseLong(raw.trim());
      } catch (NumberFormatException e) {
        throw new CoercionException("Not a number: " + raw, e);
      }
    }

    @Override
    public String toString(Object value) {
      return value == null ? null : value.toString();
    }
  };

  private static final CustomFieldValueCoercer DECIMAL_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      try {
        return new BigDecimal(raw.trim());
      } catch (NumberFormatException e) {
        throw new CoercionException("Not a decimal: " + raw, e);
      }
    }

    @Override
    public String toString(Object value) {
      if (value == null) return null;
      if (value instanceof BigDecimal bd) return bd.toPlainString();
      return value.toString();
    }
  };

  private static final CustomFieldValueCoercer BOOLEAN_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      String t = raw.trim().toLowerCase();
      return switch (t) {
        case "true", "1", "yes", "on", "y" -> Boolean.TRUE;
        case "false", "0", "no", "off", "n" -> Boolean.FALSE;
        default -> throw new CoercionException("Not a boolean: " + raw);
      };
    }

    @Override
    public String toString(Object value) {
      return value == null ? null : value.toString();
    }
  };

  private static final CustomFieldValueCoercer DATE_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      try {
        return LocalDate.parse(raw.trim());
      } catch (DateTimeParseException e) {
        throw new CoercionException("Not an ISO date: " + raw, e);
      }
    }

    @Override
    public String toString(Object value) {
      return value == null ? null : value.toString();
    }
  };

  private static final CustomFieldValueCoercer DATETIME_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      try {
        return LocalDateTime.parse(raw.trim());
      } catch (DateTimeParseException e) {
        throw new CoercionException("Not an ISO datetime: " + raw, e);
      }
    }

    @Override
    public String toString(Object value) {
      return value == null ? null : value.toString();
    }
  };

  private static final CustomFieldValueCoercer STRING_LIST_COERCER = new CustomFieldValueCoercer() {
    @Override
    public Object toValue(String raw) {
      if (raw == null || raw.isEmpty()) return null;
      List<String> parts = new ArrayList<>();
      for (String part : raw.split(",", -1)) {
        parts.add(part.trim());
      }
      return parts;
    }

    @Override
    public String toString(Object value) {
      if (value == null) return null;
      if (value instanceof List<?> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
          if (i > 0) sb.append(',');
          sb.append(list.get(i) == null ? "" : list.get(i).toString());
        }
        return sb.toString();
      }
      return value.toString();
    }
  };

  // ----- now the types (each captures a ready coercer)
  public static final CustomFieldValueType STRING = simple("STRING", "String", 1);
  public static final CustomFieldValueType NUMBER = integer("NUMBER", "Number", 100);
  public static final CustomFieldValueType BOOLEAN = bool("BOOLEAN", "Boolean", 200);
  public static final CustomFieldValueType STRING_LIST = stringList("STRING_LIST", "StringList", 300);
  public static final CustomFieldValueType TEXT = simple("TEXT", "Text", 400);
  public static final CustomFieldValueType HTML = simple("HTML", "Html", 500);
  public static final CustomFieldValueType EMAIL = simple("EMAIL", "Email", 600);
  public static final CustomFieldValueType DATE = date("DATE", "Date", 700);
  public static final CustomFieldValueType DATETIME = dateTime("DATETIME", "DateTime", 800);
  public static final CustomFieldValueType DECIMAL = decimal("DECIMAL", "Decimal", 900);
  public static final CustomFieldValueType ENUMERATION = simple("ENUMERATION", "Enumeration", 1000);
  public static final CustomFieldValueType ENUMERATION_DB = simple("ENUMERATION_DB", "ENUMERATION_DB", 1050);
  public static final CustomFieldValueType MONEY = decimal("MONEY", "Money", 1100);
  public static final CustomFieldValueType IMAGE = simple("IMAGE", "Image", 1200);
  public static final CustomFieldValueType UPLOAD = simple("UPLOAD", "Upload", 1300);

  /** All built-in types in registration order. */
  public static List<CustomFieldValueType> all() {
    List<CustomFieldValueType> list = new ArrayList<>();
    list.add(STRING);
    list.add(NUMBER);
    list.add(BOOLEAN);
    list.add(STRING_LIST);
    list.add(TEXT);
    list.add(HTML);
    list.add(EMAIL);
    list.add(DATE);
    list.add(DATETIME);
    list.add(DECIMAL);
    list.add(ENUMERATION);
    list.add(ENUMERATION_DB);
    list.add(MONEY);
    list.add(IMAGE);
    list.add(UPLOAD);
    return list;
  }

  private static CustomFieldValueType simple(String id, String display, int order) {
    return new SimpleType(id, display, order, CustomFieldValueCoercer.STRING_PASSTHROUGH);
  }

  private static CustomFieldValueType integer(String id, String display, int order) {
    return new SimpleType(id, display, order, INTEGER_COERCER);
  }

  private static CustomFieldValueType decimal(String id, String display, int order) {
    return new SimpleType(id, display, order, DECIMAL_COERCER);
  }

  private static CustomFieldValueType bool(String id, String display, int order) {
    return new SimpleType(id, display, order, BOOLEAN_COERCER);
  }

  private static CustomFieldValueType date(String id, String display, int order) {
    return new SimpleType(id, display, order, DATE_COERCER);
  }

  private static CustomFieldValueType dateTime(String id, String display, int order) {
    return new SimpleType(id, display, order, DATETIME_COERCER);
  }

  private static CustomFieldValueType stringList(String id, String display, int order) {
    return new SimpleType(id, display, order, STRING_LIST_COERCER);
  }

  private static final class SimpleType implements CustomFieldValueType {
    private final String id;
    private final String displayName;
    private final int order;
    private final CustomFieldValueCoercer coercer;

    SimpleType(String id, String displayName, int order, CustomFieldValueCoercer coercer) {
      this.id = id;
      this.displayName = displayName;
      this.order = order;
      this.coercer = coercer;
    }

    @Override public String id() { return id; }
    @Override public String displayName() { return displayName; }
    @Override public int order() { return order; }
    @Override public CustomFieldValueCoercer coercer() { return coercer; }
  }

}
