/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.presentation.annotation.AdminEntity;
import io.rchemist.common.transformer.PlatformClassTransformHelper;
import java.io.Serializable;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service
@Slf4j
public class CustomFieldLoader implements ApplicationListener<ApplicationReadyEvent> {

  private static final Map<String, String> TARGET_ENTITIES = new LinkedHashMap<>();
  private static final Set<String> SIMPLE_CUSTOM_FIELDS = new HashSet<>();
  private static final Map<String, CustomFieldConfig> CUSTOM_FIELD_CONFIGS = new LinkedHashMap<>();

  public static LinkedHashMap<String, String> getTargetEntities() {
    return new LinkedHashMap<>(TARGET_ENTITIES);
  }

  public static LinkedHashMap<String, CustomFieldConfig> getCustomFieldConfigs() {
    return new LinkedHashMap<>(CUSTOM_FIELD_CONFIGS);
  }

  public static Set<String> getSimpleCustomFields(){
    return new HashSet<>(SIMPLE_CUSTOM_FIELDS);
  }

  public static boolean isSimpleCustomField(String className){
    return SIMPLE_CUSTOM_FIELDS.contains(className);
  }

  public static Entry<String, String> getTargetEntity(String className) {
    if (TARGET_ENTITIES.containsKey(className)) {
      for (Entry<String, String> entry : TARGET_ENTITIES.entrySet()) {
        if (entry.getKey().equals(className)) {
          return entry;
        }
      }
    }
    return null;
  }

  public static Entry<String, CustomFieldConfig> getCustomFieldConfig(String className) {
    if (CUSTOM_FIELD_CONFIGS.containsKey(className)) {
      for (Entry<String, CustomFieldConfig> entry : CUSTOM_FIELD_CONFIGS.entrySet()) {
        if (entry.getKey().equals(className)) {
          return entry;
        }
      }
    }
    return null;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent event) {
    String[] packages = PlatformClassTransformHelper.getDefaultApplicationPackages();

    Reflections reflections = new Reflections(packages);
    Set<Class<?>> classes = reflections.getTypesAnnotatedWith(AdminEntity.class, false);

    if (CollectionUtils.isNotEmpty(classes)) {
      classes.forEach(clazz -> {
        try {
          AdminEntity entity = clazz.getDeclaredAnnotation(AdminEntity.class);
          if (entity.customField() != null && StringUtils.isNotEmpty(
              entity.customField().value())) {

            CustomFieldConfig config = new CustomFieldConfig()
                .withEntityClassName(clazz.getName())
                .withEntityName(entity.name())
                .withAttributes(entity.customField().value())
                .withParentId(entity.customField().parentId())
                .withSimpleAttribute(entity.customField().simpleAttribute());

            TARGET_ENTITIES.put(config.getEntityClassName(), config.getEntityName());
            CUSTOM_FIELD_CONFIGS.put(config.getEntityClassName(), config);

            if(config.isSimpleAttribute()){
              SIMPLE_CUSTOM_FIELDS.add(config.getEntityClassName());
            }

          }
        } catch (Exception e) {
          log.error(e.getMessage());
        }
      });
    }

  }

  @Data
  public static class CustomFieldConfig implements Serializable {

    protected String entityClassName;

    protected String entityName;

    protected String attributes;

    protected String parentId;

    protected boolean simpleAttribute;

    public CustomFieldConfig withEntityClassName(String entityClassName) {
      this.entityClassName = entityClassName;
      return this;
    }

    public CustomFieldConfig withEntityName(String entityName) {
      this.entityName = entityName;
      return this;
    }

    public CustomFieldConfig withAttributes(String attributes) {
      this.attributes = attributes;
      return this;
    }

    public CustomFieldConfig withParentId(String parentId) {
      this.parentId = parentId;
      return this;
    }

    public CustomFieldConfig withSimpleAttribute(boolean simpleAttribute) {
      this.simpleAttribute = simpleAttribute;
      return this;
    }
  }

}
