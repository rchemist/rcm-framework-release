/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.config;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * {@code platform.custom-field.*} configuration.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "platform.custom-field")
public class CustomFieldProperties {

  /** Master switch. Set to {@code false} to disable all auto-config. */
  private boolean enabled = true;

  /**
   * Preferred storage adapter id. Accepted values are
   * {@code auto} (pick JPA if available, otherwise in-memory),
   * {@code jpa} (force JPA, fail if repository absent),
   * {@code in-memory} (force the Map-backed adapter).
   */
  private String storage = "auto";

  /** Cache tunables (descriptor cache wiring — mirrors legacy behaviour). */
  private Cache cache = new Cache();

  /**
   * Additional {@link io.rchemist.module.customfield.spi.type.CustomFieldValueType}
   * bean names to register after the standard catalogue. Empty by default;
   * consumers typically add beans directly, but this provides a config-only
   * registration path for dynamic scenarios.
   */
  private List<String> additionalTypeBeans = new ArrayList<>();

  @Getter
  @Setter
  public static class Cache {
    private boolean enabled = true;
    private long ttlSeconds = 86400L;
  }
}
