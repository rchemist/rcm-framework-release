/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.jpa.domain.template.Alias;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.search.config.SearchAnalyzerSetting;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.data.CustomOptionCreateForm;
import io.rchemist.module.customfield.data.CustomOptionDTO;
import io.rchemist.module.customfield.data.CustomOptionUpdateForm;
import io.rchemist.module.customfield.data.CustomOptionValueDTO;
import io.rchemist.module.customfield.service.CustomOptionServiceHelper;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.MapKey;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.BooleanUtils;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.engine.backend.types.ObjectStructure;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexedEmbedded;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_CUSTOM_OPTION")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = CustomFieldCacheRegion.CustomOption.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "사용자 정의 옵션", comment = "사용자가 정의한 옵션. 시스템에서 미리 정의된 옵션들도 존재하지만, 탈퇴사유, 프로필 관심 키워드 등과 같이 사용자가 직접 옵션값을 작성하여 옵션을 만들 수 있다.")
public class CustomOption implements EssentialEntity<CustomOption>, SoftDelete<CustomOption>,
    TenantAlias<CustomOption>, Alias<CustomOption> {

  protected CustomOption(){

  }

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "NAME")
  @FullTextField(analyzer = SearchAnalyzerSetting.SIMPLE_STRING)
  @Description(name = "이름", comment = "관리자도구에 노출되는 옵션 이름")
  protected String name;

  @Column(name = "DESCRIPTION")
  @Text
  @Description(name = "설명", comment = "관리자도구에 노출되는 옵션에 대한 설명")
  protected String description;

  @OneToMany(targetEntity = CustomOptionValue.class, mappedBy = "customOption", cascade = CascadeType.ALL, orphanRemoval = true)
  @Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = CustomFieldCacheRegion.CustomOption.ENTITY)
  @BatchSize(size = 20)
  @MapKey(name = "name")
  @IndexedEmbedded(structure = ObjectStructure.NESTED)
  @Description(name = "옵션값", comment = "사용자 정의 옵션에서 사용되는 옵션값")
  protected List<CustomOptionValue> values = new ArrayList<>();

  @Column(name = "IS_SYSTEM_OPTION")
  @Description(name = "시스템 옵션 여부", comment = "시스템에서 사용되는 옵션값인지 여부")
  protected Boolean systemOption;

  /**
   * 목록 노출을 위한 임시 field
   */
  @Transient
  protected Integer optionSize;

  public static CustomOption create(CustomOptionCreateForm form) throws CustomOptionException {

    form.validate(BooleanUtils.toBoolean(form.getSystemOption()));

    CustomOption customOption = new CustomOption();
    customOption.setTenantAlias(form.getTenantAlias());
    customOption.setName(form.getName());
    customOption.setAlias(form.getAlias());
    customOption.setDescription(form.getDescription());

    for(String key : form.getValues().keySet()){
      String optionValue = form.getValues().get(key);
      CustomOptionValue value = new CustomOptionValue();
      value.setCustomOption(customOption);
      value.setAlias(key);
      value.setName(optionValue);
      customOption.getValues().add(value);
    }

    return customOption;
  }

  public Integer getOptionSize() {
    return values.size();
  }

  public void createOrUpdateValues(List<CustomOptionValueDTO> values) {
    List<CustomOptionValue> newValues = new ArrayList<>();

    for(CustomOptionValueDTO dto : values){
      CustomOptionValue value = null;
      if(dto.getId() == null) {
        value = CustomOptionServiceHelper.findCustomOptionValueByCustomOptionIdAndAlias(getId(), dto.getAlias());
      }else {
        Optional<CustomOptionValue> optional = CustomOptionServiceHelper.findCustomOptionValueById(dto.getId());
        if(optional.isPresent()) {
          value = optional.get();
        }
      }

      if(value == null) {
        value = CustomOptionValue.create(this, dto);
      }else {
        value.setName(dto.getName());
        value.setAlias(dto.getAlias());
        value.setValue(dto.getValue());
        value.setPriority(dto.getPriority());
      }
      newValues.add(value);
    }

    this.values.clear();
    this.values.addAll(newValues);
  }

  public boolean isSystemOption(){
    return BooleanUtils.toBoolean(systemOption);
  }

  public CustomOption update(CustomOptionUpdateForm form) throws CustomOptionException {
    form.validate();
    setName(form.getName());
    setDescription(form.getDescription());
    createOrUpdateValues(form.getValues());
    return this;
  }

  public CustomOptionDTO view() {
      return CustomOptionServiceHelper.build(this, true);
  }
}

