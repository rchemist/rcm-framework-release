/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.type;

import io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry;
import io.rchemist.module.customfield.spi.type.CustomFieldValueType;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Default in-process registry. Thread-safe via a read/write lock to keep
 * iteration (used by the facade on every snapshot) wait-free when no writers
 * are active.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class DefaultCustomFieldTypeRegistry implements CustomFieldTypeRegistry {

  private final Map<String, CustomFieldValueType> byId = new LinkedHashMap<>();
  private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

  public DefaultCustomFieldTypeRegistry() {
    // empty — callers seed via register() (auto-config seeds Standard types)
  }

  public DefaultCustomFieldTypeRegistry(Iterable<? extends CustomFieldValueType> seed) {
    if (seed != null) {
      for (CustomFieldValueType t : seed) {
        if (t != null) register(t, true);
      }
    }
  }

  @Override
  public void register(CustomFieldValueType type, boolean overwrite) {
    Objects.requireNonNull(type, "type");
    Objects.requireNonNull(type.id(), "type.id()");
    lock.writeLock().lock();
    try {
      if (!overwrite && byId.containsKey(type.id())) {
        throw new IllegalArgumentException("CustomFieldValueType already registered: " + type.id());
      }
      byId.put(type.id(), type);
    } finally {
      lock.writeLock().unlock();
    }
  }

  @Override
  public boolean unregister(String id) {
    if (id == null) return false;
    lock.writeLock().lock();
    try {
      return byId.remove(id) != null;
    } finally {
      lock.writeLock().unlock();
    }
  }

  @Override
  public Optional<CustomFieldValueType> find(String id) {
    if (id == null) return Optional.empty();
    lock.readLock().lock();
    try {
      return Optional.ofNullable(byId.get(id));
    } finally {
      lock.readLock().unlock();
    }
  }

  @Override
  public Collection<CustomFieldValueType> all() {
    lock.readLock().lock();
    try {
      // snapshot — safe for iteration after lock release
      return Collections.unmodifiableCollection(new java.util.ArrayList<>(byId.values()));
    } finally {
      lock.readLock().unlock();
    }
  }
}
