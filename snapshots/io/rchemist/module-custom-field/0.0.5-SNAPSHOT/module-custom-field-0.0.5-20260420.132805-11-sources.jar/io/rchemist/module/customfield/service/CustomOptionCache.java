/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.cache.data.CacheData;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.data.CustomOptionDTO;
import io.rchemist.module.customfield.domain.CustomOption;
import io.rchemist.module.customfield.service.exception.CustomOptionErrorType;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import javax.cache.Cache;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class CustomOptionCache extends CacheData {

  private CustomOptionCache(){
    super(CustomFieldCacheRegion.CustomOption.TTL / 60);
  }

  public CustomOptionCache(String tenantAlias, String alias) {
    super(CustomFieldCacheRegion.CustomOption.TTL / 60);
    this.tenantAlias = tenantAlias;
    this.alias = alias;
  }

  @Setter(AccessLevel.PRIVATE)
  protected String alias;

  @Setter(AccessLevel.PRIVATE)
  protected String tenantAlias;

  protected CustomOptionDTO option;

  private static Cache<String, CustomOptionCache> getCache() {
    CommonCacheManager redisCacheManager = ApplicationContextHolder.getBean(CommonCacheManager.class);
    Cache cache = redisCacheManager.getCache(CustomFieldCacheRegion.CustomOption.DATA);
    return cache;
  }

  public static boolean isExpired(String alias, String versionId, boolean refreshIfExpired) throws CustomOptionException {
    return isExpired(TenantHelper.getTenantAliasFromWebRequestContext(), alias, versionId, refreshIfExpired);
  }

  public static boolean isExpired(String tenantAlias, String alias, String versionId, boolean refreshIfExpired) throws CustomOptionException {

    CustomOptionCache cache = getCache(tenantAlias, alias);

    if(cache == null)
      throw new CustomOptionException(CustomOptionErrorType.CACHE_NOT_FOUND);

    if(cache.isExpired()){
      if(refreshIfExpired){
        cache = createOrResetCacheItem(tenantAlias, alias);
      }
      return true;
    }else{

      if(!StringUtils.equals(cache.getVersionId(), versionId)){
        return false;
      }

    }

    return true;
  }



  public static CustomOptionCache getCache(String alias){
    return getCache(TenantHelper.getTenantAliasFromWebRequestContext(), alias);
  }

  public static CustomOptionCache getCache(String tenantAlias, String alias){
    String cacheKey = createCacheKey(tenantAlias, alias);
    return getCache().get(cacheKey);
  }

  public static CustomOptionDTO getCacheData(String alias){
    return getCacheData(alias, false);
  }

  public static CustomOptionDTO getCacheData(String alias, boolean forceRefresh){
    CustomOptionCache cache = null;

    String cacheKey = createCacheKey(TenantHelper.getTenantAliasFromWebRequestContext(), alias);

    if(!forceRefresh){
      cache = getCache(cacheKey);
    }

    if(cache != null){
      if(cache.isExpired()){
        cache = createOrResetCacheItem(alias);
      }

      return cache.getOption();
    }else{
      cache = createOrResetCacheItem(alias);
    }

    return cache.getOption();

  }

  public static CustomOptionCache createOrResetCacheItem(String alias) {
    // active 한 필드만 표시
    return createOrResetCacheItem(TenantHelper.getTenantAliasFromWebRequestContext(), alias);
  }

  public static CustomOptionCache createOrResetCacheItem(String tenantAlias, String alias){

    CustomOption option = CustomOptionServiceHelper.getCustomOptionService().findCustomOptionByAlias(
        tenantAlias, alias);

    if(option == null){
      CustomOptionCache cache = new CustomOptionCache(tenantAlias, alias);
      getCache().put(createCacheKey(tenantAlias, alias), cache);
      return cache;
    }else{
      return createCacheItem(option);
    }

  }

  public static CustomOptionCache createCacheItem(CustomOption option){
    if(option != null){
      CustomOptionCache cache = new CustomOptionCache(option.getTenantAlias(), option.getAlias());
      if(option != null){
        cache.setOption(CustomOptionServiceHelper.build(option, true));
      }

      getCache().put(createCacheKey(option.getTenantAlias(), option.getAlias()), cache);
      return cache;
    }
    return null;
  }


  private static String createCacheKey(String tenantAlias, String alias){
    return tenantAlias + "_" + alias;
  }

  public static void remove(String... aliases) {
    for(String alias : aliases){
      getCache().remove(alias);
    }
  }
}
