/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.storage;

import io.rchemist.module.customfield.spi.CustomFieldValue;
import io.rchemist.module.customfield.spi.storage.CustomFieldValueStorage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Map-backed {@link CustomFieldValueStorage}. Key = (namespace, ownerId,
 * propertyName). Proves storage-agnostic design.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class InMemoryCustomFieldValueStorage implements CustomFieldValueStorage {

  public static final String ADAPTER_ID = "in-memory";

  private final Map<Key, CustomFieldValue> store = new LinkedHashMap<>();
  private final Object mutex = new Object();

  @Override
  public CustomFieldValue put(CustomFieldValue value) {
    Objects.requireNonNull(value, "value");
    synchronized (mutex) {
      store.put(keyOf(value), value);
      return value;
    }
  }

  @Override
  public Optional<CustomFieldValue> get(String namespace, Object ownerId, String propertyName) {
    synchronized (mutex) {
      return Optional.ofNullable(store.get(new Key(namespace, ownerId, propertyName)));
    }
  }

  @Override
  public Collection<CustomFieldValue> list(String namespace, Object ownerId) {
    List<CustomFieldValue> hits = new ArrayList<>();
    synchronized (mutex) {
      for (Map.Entry<Key, CustomFieldValue> e : store.entrySet()) {
        Key k = e.getKey();
        if (Objects.equals(k.namespace, namespace) && Objects.equals(k.ownerId, ownerId)) {
          hits.add(e.getValue());
        }
      }
    }
    return Collections.unmodifiableList(hits);
  }

  @Override
  public boolean delete(String namespace, Object ownerId, String propertyName) {
    synchronized (mutex) {
      return store.remove(new Key(namespace, ownerId, propertyName)) != null;
    }
  }

  @Override
  public int deleteAll(String namespace, Object ownerId) {
    int removed = 0;
    synchronized (mutex) {
      java.util.Iterator<Key> it = store.keySet().iterator();
      while (it.hasNext()) {
        Key k = it.next();
        if (Objects.equals(k.namespace, namespace) && Objects.equals(k.ownerId, ownerId)) {
          it.remove();
          removed++;
        }
      }
    }
    return removed;
  }

  @Override
  public String adapterId() {
    return ADAPTER_ID;
  }

  private static Key keyOf(CustomFieldValue v) {
    return new Key(v.getNamespace(), v.getOwnerId(), v.getPropertyName());
  }

  private record Key(String namespace, Object ownerId, String propertyName) {
  }
}
