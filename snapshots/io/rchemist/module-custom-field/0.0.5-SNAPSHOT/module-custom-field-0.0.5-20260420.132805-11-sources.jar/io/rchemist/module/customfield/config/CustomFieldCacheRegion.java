/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.config;

import io.rchemist.common.cache.CacheConfiguration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomFieldCacheRegion {

  public static final int TTL_HOUR = 60 * 60;

  public static final int MAX_ENTRIES = 10000;

  public static class CustomField {
    public static final String ENTITY = "customField-entity";
    public static final String DATA = "customField-data";
    public static final String QUERY = "customField-query";
    public static final String TEMP = "customField-temp";
    public static final int MAX_ENTRIES = 10000;
    public static final int TTL = 86400;

    public static final CacheConfiguration ENTITY_CACHE = new CacheConfiguration("custom-field-entity", MAX_ENTRIES, TTL);
    public static final CacheConfiguration SEARCH_CACHE = new CacheConfiguration("custom-field-search", 100, TTL_HOUR);
  }

  public static class CustomOption {
    public static final String ENTITY = "customField-entity";
    public static final String DATA = "customField-data";
    public static final String QUERY = "customField-query";
    public static final String TEMP = "customField-temp";
    public static final int MAX_ENTRIES = 10000;
    public static final int TTL = 86400;

    public static final CacheConfiguration ENTITY_CACHE = new CacheConfiguration("custom-option-entity", MAX_ENTRIES, TTL);
    public static final CacheConfiguration SEARCH_CACHE = new CacheConfiguration("custom-option-search", 100, TTL_HOUR);

  }


}
