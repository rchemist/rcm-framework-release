/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.module.customfield.data.CustomOptionCreateForm;
import io.rchemist.module.customfield.data.CustomOptionDTO;
import io.rchemist.module.customfield.data.CustomOptionUpdateForm;
import io.rchemist.module.customfield.domain.CustomOption;
import io.rchemist.module.customfield.domain.CustomOptionValue;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface CustomOptionService extends ResponseEntityListService<CustomOption, CustomOptionDTO, CustomOptionCreateForm, CustomOptionUpdateForm, SearchForm, Long, CustomOptionException> {
    CustomOption findCustomOptionByAlias(String tenantAlias, String alias);

    Optional<CustomOptionValue> findCustomOptionValueById(Long id);

    CustomOptionValue findCustomOptionValueByCustomOptionIdAndAlias(Long id, String alias);

    List<CustomOptionValue> getCustomOptionValues(Long id);
}
