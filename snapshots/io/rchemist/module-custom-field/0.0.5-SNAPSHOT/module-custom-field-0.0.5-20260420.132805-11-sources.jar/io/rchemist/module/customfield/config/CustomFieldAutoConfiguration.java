/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.config;

import io.rchemist.module.customfield.dao.CustomFieldRepository;
import io.rchemist.module.customfield.internal.DefaultCustomFieldFacade;
import io.rchemist.module.customfield.internal.storage.InMemoryCustomFieldDescriptorStorage;
import io.rchemist.module.customfield.internal.storage.InMemoryCustomFieldValueStorage;
import io.rchemist.module.customfield.internal.storage.JpaCustomFieldDescriptorStorage;
import io.rchemist.module.customfield.internal.type.DefaultCustomFieldTypeRegistry;
import io.rchemist.module.customfield.internal.type.StandardCustomFieldTypes;
import io.rchemist.module.customfield.internal.validation.DefaultCustomFieldValidators;
import io.rchemist.module.customfield.spi.CustomFieldFacade;
import io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage;
import io.rchemist.module.customfield.spi.storage.CustomFieldValueStorage;
import io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry;
import io.rchemist.module.customfield.spi.type.CustomFieldValueType;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidator;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Auto-wiring for the custom-field SPI. Consumers receive a ready
 * {@link CustomFieldFacade} that picks the JPA adapter when a repository is
 * present and falls back to the in-memory map otherwise, unless
 * {@code platform.custom-field.storage} pins an adapter explicitly.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(CustomFieldProperties.class)
@ConditionalOnProperty(prefix = "platform.custom-field", name = "enabled",
    havingValue = "true", matchIfMissing = true)
public class CustomFieldAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public CustomFieldTypeRegistry customFieldTypeRegistry(
      ObjectProvider<CustomFieldValueType> contributed) {
    DefaultCustomFieldTypeRegistry registry = new DefaultCustomFieldTypeRegistry(
        StandardCustomFieldTypes.all());
    contributed.orderedStream().forEach(t -> {
      if (t != null) registry.register(t, true);
    });
    return registry;
  }

  @Bean
  @ConditionalOnMissingBean
  public CustomFieldDescriptorStorage customFieldDescriptorStorage(
      CustomFieldProperties properties,
      ObjectProvider<CustomFieldRepository> repositoryProvider) {
    String pref = properties.getStorage() == null ? "auto"
        : properties.getStorage().toLowerCase();
    CustomFieldRepository repo = repositoryProvider.getIfAvailable();
    return switch (pref) {
      case "jpa" -> {
        if (repo == null) {
          throw new IllegalStateException(
              "platform.custom-field.storage=jpa but CustomFieldRepository is not available");
        }
        yield new JpaCustomFieldDescriptorStorage(repo);
      }
      case "in-memory" -> new InMemoryCustomFieldDescriptorStorage();
      default -> repo != null
          ? new JpaCustomFieldDescriptorStorage(repo)
          : new InMemoryCustomFieldDescriptorStorage();
    };
  }

  @Bean
  @ConditionalOnMissingBean
  public CustomFieldValueStorage customFieldValueStorage() {
    // No legacy JPA table for values; shipped default is the in-memory map.
    // Consumers wanting JPA values write their own adapter and declare a bean.
    return new InMemoryCustomFieldValueStorage();
  }

  @Bean
  @ConditionalOnMissingBean(name = "defaultCustomFieldValidators")
  public List<CustomFieldValidator> defaultCustomFieldValidators(
      CustomFieldTypeRegistry registry) {
    return DefaultCustomFieldValidators.pipeline(registry);
  }

  @Bean
  @ConditionalOnMissingBean
  public CustomFieldFacade customFieldFacade(
      CustomFieldTypeRegistry registry,
      CustomFieldDescriptorStorage descriptors,
      CustomFieldValueStorage values,
      ObjectProvider<CustomFieldValidator> contributed,
      List<CustomFieldValidator> defaultValidators) {
    // merge default + contributed (bean-contributed ones follow defaults)
    java.util.List<CustomFieldValidator> merged = new java.util.ArrayList<>(defaultValidators);
    contributed.orderedStream().forEach(v -> {
      if (v != null && !merged.contains(v)) merged.add(v);
    });
    return new DefaultCustomFieldFacade(registry, descriptors, values, merged);
  }
}
