/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.presentation.type.CustomFieldType;
import io.rchemist.common.search.bridge.CustomFieldTypeValueBridge;
import io.rchemist.common.search.config.SearchAnalyzerSetting;
import io.rchemist.common.util.FieldHelper;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.data.CustomFieldCreateForm;
import io.rchemist.module.customfield.data.CustomFieldDTO;
import io.rchemist.module.customfield.data.CustomFieldUpdateForm;
import io.rchemist.module.customfield.service.exception.CustomFieldException;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.bridge.mapping.annotation.ValueBridgeRef;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_CUSTOM_FIELD")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = CustomFieldCacheRegion.CustomField.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "커스텀 필드", comment = "플랫폼에서 제공되는 엔티티의 필드이외에 서비스(사이트)에서 추가적인 필드가 필요할 때, 엔티티를 수정하지 않고 관리자도구를 통해 필드를 추가할 수 있다. 추가된 필드의 정보를 관리하기 위해 사용된다.")
public class CustomField implements EssentialEntity<CustomField>, SoftDelete<CustomField>,
    TenantAlias<CustomField> {

  public CustomField() {

  }

  @Id
  @IdGenerator
  protected Long id;

  @Column(name = "NAME")
  @FullTextField(analyzer = SearchAnalyzerSetting.SIMPLE_STRING)
  @Description(name = "이름", comment = "관리자도구에 노출되는 필드 이름")
  protected String name;

  @Column(name = "DESCRIPTION")
  @Text
  @Description(name = "설명", comment = "관리자도구에 노출되는 필드에 대한 설명")
  protected String description;

  @Column(name = "TARGET_ENTITY_CLASS")
  @GenericField
  @IndexField
  @Description(name = "타겟 엔티티 클래스 이름", comment = "필드를 추가할 엔티티 클래스 이름")
  protected String targetEntityClass;

  @Column(name = "PROPERTY_NAME")
  @GenericField
  @IndexField
  @Description(name = "속성 이름", comment = "프로그램에서 사용되는 속성 이름")
  protected String propertyName;

  @Column(name = "CUSTOM_FIELD_TYPE")
  @KeywordField(valueBridge = @ValueBridgeRef(type = CustomFieldTypeValueBridge.class))
  @Description(name = "유형", comment = "필드 유형. STRING, NUMBER, BOOLEAN, DATE, IMAGE 등과 같이 필드의 유형을 나타낸다. 필드 유형은 CustomFieldType 에서 확인할 수 있다.")
  protected CustomFieldType fieldType;

  @Column(name = "DEFAULT_VALUE")
  @Description(name = "기본값", comment = "기본값")
  protected String defaultValue;

  @Column(name = "ENUM_OPTIONS")
  @Description(name = "선택 옵션", comment = "필드 유형이 ENUMERATION(옵션 선택) 일 때 보여 줄 옵션 정보")
  protected String[] enumerationOptions;

  @Column(name = "ENUM_DATA")
  @Description(name = "사용자 정의 옵션 Key", comment = "필드 유형이 ENUMERATION_DB(사용자정의 옵션 선택) 일 경우 대상 옵션의 Key 를 입력합니다.")
  protected String enumerationData;

  @Column(name = "MODIFIABLE_TYPE")
  @Description(name = "입력폼 표시 방법", comment = "필드를 항상 표시할지, 입력시 표시할지, 조회할 경우에만 표시할지, 안보여줄지 등의 정보")
  protected String modifiableType;

  @Column(name = "PLACE_HOLDER")
  @Description(name = "입력폼 안내 문구", comment = "입력폼에 대한 안내 문구")
  protected String placeHolder;

  @Column(name = "HELP_TEXT")
  @Description(name = "입력폼 설명", comment = "입력폼에 대한 설명")
  protected String helpText;

  @Column(name = "VIEW_TAB")
  @Description(name = "탭 위치", comment = "탭의 위치를 지정할 수 있으며, TabEnumType 에서 설정된 이름과 순서를 사용하게 된다. 선택하지 않는다면 기본 정보 탭에 노출된다.")
  protected String viewTab;

  @Column(name = "VIEW_GROUP")
  @Description(name = "그룹 위치", comment = "그룹의 위치를 지정할 수 있으며, GroupEnumType 에서 설정된 이름과 순서를 사용하게 된다. 선택하지 않는다면 기본 정보에 노출된다.")
  protected String viewGroup;

  @Column(name = "FIELD_ORDER")
  @Description(name = "필드 순서", comment = "탭, 그룹이 지정되면 필드의 순서를 지정한다. 기본값은 1000 이며, 값이 낮을 수록 먼저 노출된다.")
  protected Integer order;

  @Column(name = "HEADER_FIELD")
  @Description(name = "목록 노출 여부", comment = "해당 필드를 목록에 노출시킬지 여부")
  protected Boolean headerField;

  @Column(name = "HEADER_FIELD_ORDER")
  @Description(name = "목록 노출 순서", comment = "목록 노출 여부를 True 로 선택했을 경우, 목록의 노출 순서를 정의할 수 있다.")
  protected Integer headerFieldOrder;

  @Column(name = "IS_SEARCHABLE")
  @Description(name = "검색 가능 여부", comment = "목록 내 상세 검색에서 검색을 가능하게 할지 여부")
  protected Boolean searchable;

  @Column(name = "IS_SORTABLE")
  @Description(name = "정렬 가능 여부", comment = "목록 내 정렬을 가능하게 할지 여부")
  protected Boolean sortable;

  @Column(name = "IS_REQUIRED")
  @Description(name = "필수값 여부", comment = "필수값 여부")
  protected Boolean required;

  @Column(name = "MIN_LENGTH")
  @Description(name = "최소값", comment = "필드 유형이 정수나 실수형인 경우 입력할 수 있는 최소값을 의미한다. 단, 필드 유형이 문자열인 경우 입력해야 하는 문자열의 길이로 사용된다.")
  protected String minLength;

  @Column(name = "MAX_LENGTH")
  @Description(name = "최소값", comment = "필드 유형이 정수나 실수형인 경우 입력할 수 있는 최소값을 의미한다. 단, 필드 유형이 문자열인 경우 입력해야 하는 문자열의 길이로 사용된다.")
  protected String maxLength;

  @Column(name = "REGEX_VALIDATION")
  @Description(name = "입력 값 검증용 정규식", comment = "이 필드에 입력된 값을 정규식으로 검증할때 사용되는 정규표현식")
  protected String regexValidation;

  @Column(name = "ERROR_MESSAGE")
  @Description(name = "입력 값 오류 메시지", comment = "입력된 정규식 검증에 실패했을 경우 나타내는 오류 메세지")
  protected String errorMessage;


  @Override
  public CustomField withId(Long id) {
    this.id = id;
    return this;
  }

  public CustomField withName(String name) {
    this.name = name;
    return this;
  }

  public CustomField withDescription(String description) {
    this.description = description;
    return this;
  }

  public CustomField withTargetEntityClass(String targetEntityClass) {
    this.targetEntityClass = targetEntityClass;
    return this;
  }

  public CustomField withPropertyName(String propertyName) {
    this.propertyName = propertyName;
    return this;
  }

  public CustomField withPlaceHolder(String placeHolder) {
    this.placeHolder = placeHolder;
    return this;
  }

  public CustomField withHelpText(String helpText) {
    this.helpText = helpText;
    return this;
  }

  public CustomField withFieldType(CustomFieldType fieldType) {
    this.fieldType = fieldType;
    return this;
  }

  public CustomField withEnumerationOptions(String[] enumerationOptions) {
    this.enumerationOptions = enumerationOptions;
    return this;
  }

  public CustomField withEnumerationData(String enumerationData) {
    this.enumerationData = enumerationData;
    return this;
  }

  public CustomField withRegexValidation(String regexValidation) {
    this.regexValidation = regexValidation;
    return this;
  }

  public CustomField withErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

  public CustomField withViewTab(String viewTab) {
    this.viewTab = viewTab;
    return this;
  }

  public CustomField withViewGroup(String viewGroup) {
    this.viewGroup = viewGroup;
    return this;
  }

  public CustomField withHeaderField(Boolean headerField) {
    this.headerField = headerField;
    return this;
  }

  public CustomField withHeaderFieldOrder(Integer headerFieldOrder) {
    this.headerFieldOrder = headerFieldOrder;
    return this;
  }

  public CustomField withSearchable(Boolean searchable) {
    this.searchable = searchable;
    return this;
  }

  public CustomField withSortable(Boolean sortable) {
    this.sortable = sortable;
    return this;
  }

  public CustomField withDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }

  public CustomField withRequired(Boolean required) {
    this.required = required;
    return this;
  }

  public CustomField withModifiableType(String modifiableType) {
    this.modifiableType = modifiableType;
    return this;
  }

  public CustomField withMinLength(String minLength) {
    this.minLength = minLength;
    return this;
  }

  public CustomField withMaxLength(String maxLength) {
    this.maxLength = maxLength;
    return this;
  }

  public CustomField withOrder(Integer order) {
    this.order = order;
    return this;
  }

  public static CustomField create(CustomFieldCreateForm form) throws CustomFieldException {

    form.validate();

    return new CustomField()
        .withName(form.getName())
        .withDescription(form.getDescription())
        .withTargetEntityClass(form.getTargetEntityClass())
        .withPropertyName(form.getPropertyName())
        .withFieldType(form.getFieldType())
        .withDefaultValue(form.getDefaultValue())
        .withEnumerationOptions(form.getEnumerationOptions())
        .withEnumerationData(form.getEnumerationData())
        .withModifiableType(form.getModifiableType().name())
        .withPlaceHolder(form.getPlaceHolder())
        .withHelpText(form.getHelpText())
        .withViewTab(form.getViewTab())
        .withViewGroup(form.getViewGroup())
        .withOrder(form.getOrder())
        .withHeaderField(form.getHeaderField())
        .withHeaderFieldOrder(form.getHeaderFieldOrder())
        .withSearchable(form.getSearchable())
        .withSortable(form.getSortable())
        .withRequired(form.getRequired())
        .withMinLength(form.getMinLength())
        .withMaxLength(form.getMaxLength())
        .withRegexValidation(form.getRegexValidation())
        .withErrorMessage(form.getErrorMessage());

  }


  public CustomFieldDTO view() {
    return new CustomFieldDTO()
            .withId(getId())
            .withTenantAlias(getTenantAlias())
            .withName(getName())
            .withDescription(getDescription())
            .withTargetEntityClass(getTargetEntityClass())
            .withPropertyName(getPropertyName())
            .withFieldType(getFieldType())
            .withDefaultValue(getDefaultValue())
            .withEnumerationOptions(getEnumerationOptions())
            .withEnumerationData(getEnumerationData())
            .withPlaceHolder(getPlaceHolder())
            .withHelpText(getHelpText())
            .withViewTab(getViewTab())
            .withViewGroup(getViewGroup())
            .withModifiableType(getModifiableType())
            .withHeaderField(getHeaderField())
            .withHeaderFieldOrder(getHeaderFieldOrder())
            .withOrder(getOrder())
            .withSearchable(getSearchable())
            .withSortable(getSortable())
            .withRequired(getRequired())
            .withRegexValidation(getRegexValidation())
            .withErrorMessage(getErrorMessage())
            .withCreatedAt(getCreatedAt())
            .withUpdatedAt(getUpdatedAt())
            .withMinLength(getMinLength())
            .withMaxLength(getMaxLength())
            ;
  }

  public CustomField update(CustomFieldUpdateForm form) throws CustomFieldException {
    form.validate();
    FieldHelper.updateEntityWithSelectedFields(this, form, form.getModifiedFields());
    return this;
  }
}
