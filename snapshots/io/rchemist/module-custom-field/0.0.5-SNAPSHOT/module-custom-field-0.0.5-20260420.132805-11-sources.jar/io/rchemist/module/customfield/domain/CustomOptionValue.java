/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.domain;

import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.jpa.domain.template.Alias;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.NameValue;
import io.rchemist.common.persistence.jpa.domain.template.Priority;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.data.CustomOptionValueDTO;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.IndexingDependency;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.ObjectPath;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.PropertyValue;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Entity
@Table(name = "T_CUSTOM_OPTION_VALUE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = CustomFieldCacheRegion.CustomOption.ENTITY)
@Getter
@Setter
@Indexed
@Description(name = "사용자 정의 옵션값", comment = "사용자가 정의한 옵션에 대한 옵션값 정보")
public class CustomOptionValue implements EssentialEntity<CustomOptionValue>, Priority<CustomOptionValue>,
  NameValue<CustomOptionValue>, Alias<CustomOptionValue> {

  @Id
  @IdGenerator
  protected Long id;

  @ManyToOne(targetEntity = CustomOption.class, optional = false, cascade = CascadeType.REFRESH)
  @JoinColumn(name = "OPTION_ID")
  @Description(name = "옵션 ID", comment = "매핑된 커스텀 옵션 ID")
  protected CustomOption customOption;

  @GenericField(name = "customOptionId")
  @IndexingDependency(derivedFrom = @ObjectPath(@PropertyValue(propertyName = "customOption")))
  protected Long getCustomOptionId(){
    return customOption == null ? null : customOption.getId();
  }

  public static CustomOptionValue create(CustomOption customOption, CustomOptionValueDTO dto) {
    CustomOptionValue value = new CustomOptionValue();
    value.setAlias(dto.getAlias());
    value.setName(dto.getName());
    value.setValue(dto.getValue());
    value.setCustomOption(customOption);
    return value;
  }

}
