/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.dao.CustomFieldDao;
import io.rchemist.module.customfield.data.CustomFieldCreateForm;
import io.rchemist.module.customfield.data.CustomFieldDTO;
import io.rchemist.module.customfield.data.CustomFieldUpdateForm;
import io.rchemist.module.customfield.domain.CustomField;
import io.rchemist.module.customfield.service.exception.CustomFieldErrorType;
import io.rchemist.module.customfield.service.exception.CustomFieldException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;
import javax.cache.Cache;
import lombok.Getter;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmCustomFieldService")
public class CustomFieldServiceImpl implements CustomFieldService {

    protected final CustomFieldDao dao;

    @Getter
    protected final Cache<String, CustomFieldDTO> entityCache;

    @Getter
    protected final Cache<String, ResponseListWrapper> searchCache;

    @Getter
    @PersistenceContext
    protected EntityManager entityManager;

    public CustomFieldServiceImpl(CustomFieldDao dao, CommonCacheManager cacheManager) {
        this.dao = dao;
        this.entityCache = cacheManager.getOrCreateCache(CustomFieldCacheRegion.CustomField.ENTITY_CACHE, CustomFieldDTO.class);
        this.searchCache = cacheManager.getOrCreateCache(CustomFieldCacheRegion.CustomField.SEARCH_CACHE, ResponseListWrapper.class);
    }


    @Override
    public List<CustomFieldDTO> getCustomFields(String className) {

        List<CustomField> fields = dao.getCustomFieldRepository().findCustomFieldByClassName(className);

        return getCustomFieldDTOS(fields);
    }

    @Override
    public List<CustomFieldDTO> getCustomFields(String className, Boolean active) {
        List<CustomField> fields = dao.getCustomFieldRepository().findCustomFieldByClassName(className, active);

        return getCustomFieldDTOS(fields);
    }

    protected static List<CustomFieldDTO> getCustomFieldDTOS(List<CustomField> fields) {
        if (CollectionUtils.isEmpty(fields))
            return null;

        List<CustomFieldDTO> list = new ArrayList<>();
        for (CustomField field : fields) {
            try {
                list.add(field.view());
            }catch (Exception e) {
                // nothing to do
            }
        }

        return list;
    }

    @Override
    public CommonSearchRepository<CustomField, Long> getRepository() {
        return dao.getCustomFieldRepository();
    }

    @Override
    public CustomFieldException entityNotFoundException() {
        return new CustomFieldException(CustomFieldErrorType.CUSTOMFIELD_NOT_FOUND);
    }

    @Override
    public CustomField createEntity(CustomFieldCreateForm customFieldCreateForm) throws CustomFieldException {
        return CustomField.create(customFieldCreateForm);
    }

    @Override
    public CustomField updateEntity(CustomField entity, CustomFieldUpdateForm customFieldUpdateForm) throws CustomFieldException {
        return entity.update(customFieldUpdateForm);
    }

    @Override
    public CustomFieldDTO getView(CustomField entity, EntityViewType viewType) {
        return entity.view();
    }

    @Override
    public SearchContext<CustomField, SearchForm> getSearchContext(SearchForm searchForm) {
        return new CommonSearchContext<>(CustomField.class, searchForm);
    }
}
