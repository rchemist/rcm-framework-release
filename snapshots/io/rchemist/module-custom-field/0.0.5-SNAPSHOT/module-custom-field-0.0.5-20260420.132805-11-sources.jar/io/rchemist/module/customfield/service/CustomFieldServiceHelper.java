/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.module.customfield.data.CustomFieldDTO;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomFieldServiceHelper {

  private static CustomFieldService customFieldService;

  public static CustomFieldService getCustomFieldService(){
    if(customFieldService == null){
      customFieldService = ApplicationContextHolder.getBean(CustomFieldService.class);
    }
    return customFieldService;
  }

  public static List<CustomFieldDTO> getCustomFields(String className){

    List<CustomFieldDTO> cachedData = CustomFieldCache.getCacheData(className);

    // 캐시 된 적이 없거나 만료된 경우
    if(cachedData == null){
      List<CustomFieldDTO> fields = getCustomFieldService().getCustomFields(className);
      CustomFieldCache.add(fields.toArray(new CustomFieldDTO[0]));

      return CustomFieldCache.getCacheData(className);

    }else{
      return cachedData;
    }
  }


}
