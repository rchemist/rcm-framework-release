/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.storage;

import io.rchemist.common.presentation.type.CustomFieldType;
import io.rchemist.module.customfield.dao.CustomFieldRepository;
import io.rchemist.module.customfield.domain.CustomField;
import io.rchemist.module.customfield.spi.CustomFieldDescriptor;
import io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * JPA adapter that reuses the existing {@link CustomField} entity. The
 * adapter is deliberately loose about the legacy multi-column model: it
 * translates only the overlapping fields. Fields present on the entity but
 * not on the SPI descriptor (view tab / group / cache TTL etc.) are preserved
 * round-trip via {@link CustomFieldDescriptor#getConstraints()} so that
 * subsequent saves do not silently drop them.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class JpaCustomFieldDescriptorStorage implements CustomFieldDescriptorStorage {

  public static final String ADAPTER_ID = "jpa";

  static final String C_VIEW_TAB = "jpa.viewTab";
  static final String C_VIEW_GROUP = "jpa.viewGroup";
  static final String C_MODIFIABLE = "jpa.modifiableType";
  static final String C_PLACE_HOLDER = "jpa.placeHolder";
  static final String C_HELP_TEXT = "jpa.helpText";
  static final String C_HEADER_FIELD = "jpa.headerField";
  static final String C_HEADER_ORDER = "jpa.headerFieldOrder";
  static final String C_SEARCHABLE = "jpa.searchable";
  static final String C_SORTABLE = "jpa.sortable";

  private final CustomFieldRepository repository;

  public JpaCustomFieldDescriptorStorage(CustomFieldRepository repository) {
    this.repository = Objects.requireNonNull(repository, "repository");
  }

  @Override
  public CustomFieldDescriptor save(CustomFieldDescriptor descriptor) {
    Objects.requireNonNull(descriptor, "descriptor");
    CustomField entity;
    if (descriptor.getId() instanceof Long longId) {
      entity = repository.findById(longId).orElseGet(CustomField::new);
    } else {
      entity = new CustomField();
    }
    applyToEntity(descriptor, entity);
    CustomField saved = repository.save(entity);
    descriptor.setId(saved.getId());
    return toDescriptor(saved);
  }

  @Override
  public Optional<CustomFieldDescriptor> findById(Object id) {
    if (!(id instanceof Long longId)) return Optional.empty();
    return repository.findById(longId).map(JpaCustomFieldDescriptorStorage::toDescriptor);
  }

  @Override
  public Collection<CustomFieldDescriptor> findByNamespace(String namespace) {
    List<CustomField> found = repository.findCustomFieldByClassName(namespace);
    if (found == null || found.isEmpty()) return Collections.emptyList();
    List<CustomFieldDescriptor> out = new ArrayList<>(found.size());
    for (CustomField f : found) {
      out.add(toDescriptor(f));
    }
    return Collections.unmodifiableList(out);
  }

  @Override
  public Collection<CustomFieldDescriptor> findAll() {
    List<CustomFieldDescriptor> out = new ArrayList<>();
    for (CustomField f : repository.findAll()) {
      out.add(toDescriptor(f));
    }
    return Collections.unmodifiableList(out);
  }

  @Override
  public boolean deleteById(Object id) {
    if (!(id instanceof Long longId)) return false;
    if (!repository.existsById(longId)) return false;
    repository.deleteById(longId);
    return true;
  }

  @Override
  public String adapterId() {
    return ADAPTER_ID;
  }

  /** Entity -> descriptor. Visible for tests. */
  public static CustomFieldDescriptor toDescriptor(CustomField entity) {
    if (entity == null) return null;
    CustomFieldDescriptor d = new CustomFieldDescriptor()
        .setId(entity.getId())
        .setTenantAlias(entity.getTenantAlias())
        .setNamespace(entity.getTargetEntityClass())
        .setPropertyName(entity.getPropertyName())
        .setTypeId(entity.getFieldType() == null ? null : entity.getFieldType().getType())
        .setDisplayName(entity.getName())
        .setDescription(entity.getDescription())
        .setDefaultValue(entity.getDefaultValue())
        .setRequired(Boolean.TRUE.equals(entity.getRequired()))
        .setEnumerationReference(entity.getEnumerationData())
        .setRegexValidation(entity.getRegexValidation())
        .setErrorMessage(entity.getErrorMessage())
        .setMinLength(entity.getMinLength())
        .setMaxLength(entity.getMaxLength())
        .setOrder(entity.getOrder());
    String[] opts = entity.getEnumerationOptions();
    if (opts != null && opts.length > 0) {
      d.setEnumerationOptions(Arrays.asList(opts));
    }
    // Preserve legacy-only columns as constraints so subsequent saves are
    // lossless round-trips.
    putIfNonNull(d, C_VIEW_TAB, entity.getViewTab());
    putIfNonNull(d, C_VIEW_GROUP, entity.getViewGroup());
    putIfNonNull(d, C_MODIFIABLE, entity.getModifiableType());
    putIfNonNull(d, C_PLACE_HOLDER, entity.getPlaceHolder());
    putIfNonNull(d, C_HELP_TEXT, entity.getHelpText());
    putIfNonNull(d, C_HEADER_FIELD, entity.getHeaderField());
    putIfNonNull(d, C_HEADER_ORDER, entity.getHeaderFieldOrder());
    putIfNonNull(d, C_SEARCHABLE, entity.getSearchable());
    putIfNonNull(d, C_SORTABLE, entity.getSortable());
    return d;
  }

  /** Descriptor -> entity (in place). Visible for tests. */
  public static void applyToEntity(CustomFieldDescriptor d, CustomField entity) {
    entity.setTenantAlias(d.getTenantAlias());
    entity.setName(d.getDisplayName());
    entity.setDescription(d.getDescription());
    entity.setTargetEntityClass(d.getNamespace());
    entity.setPropertyName(d.getPropertyName());
    entity.setFieldType(resolveLegacyType(d.getTypeId()));
    entity.setDefaultValue(d.getDefaultValue());
    entity.setRequired(d.isRequired());
    entity.setEnumerationData(d.getEnumerationReference());
    List<String> opts = d.getEnumerationOptions();
    entity.setEnumerationOptions(opts == null || opts.isEmpty()
        ? null : opts.toArray(new String[0]));
    entity.setRegexValidation(d.getRegexValidation());
    entity.setErrorMessage(d.getErrorMessage());
    entity.setMinLength(d.getMinLength());
    entity.setMaxLength(d.getMaxLength());
    entity.setOrder(d.getOrder());
    entity.setViewTab(asString(d.getConstraints().get(C_VIEW_TAB)));
    entity.setViewGroup(asString(d.getConstraints().get(C_VIEW_GROUP)));
    entity.setModifiableType(asString(d.getConstraints().get(C_MODIFIABLE)));
    entity.setPlaceHolder(asString(d.getConstraints().get(C_PLACE_HOLDER)));
    entity.setHelpText(asString(d.getConstraints().get(C_HELP_TEXT)));
    entity.setHeaderField(asBoolean(d.getConstraints().get(C_HEADER_FIELD)));
    entity.setHeaderFieldOrder(asInteger(d.getConstraints().get(C_HEADER_ORDER)));
    entity.setSearchable(asBoolean(d.getConstraints().get(C_SEARCHABLE)));
    entity.setSortable(asBoolean(d.getConstraints().get(C_SORTABLE)));
  }

  private static CustomFieldType resolveLegacyType(String typeId) {
    if (typeId == null) return null;
    // Legacy enum constants are resolvable by static-field reflection; a
    // straightforward switch over the well-known ids keeps us free of
    // reflection at runtime.
    return switch (typeId) {
      case "STRING" -> CustomFieldType.STRING;
      case "NUMBER" -> CustomFieldType.NUMBER;
      case "BOOLEAN" -> CustomFieldType.BOOLEAN;
      case "STRING_LIST" -> CustomFieldType.STRING_LIST;
      case "TEXT" -> CustomFieldType.TEXT;
      case "HTML" -> CustomFieldType.HTML;
      case "EMAIL" -> CustomFieldType.EMAIL;
      case "DATE" -> CustomFieldType.DATE;
      case "DATETIME" -> CustomFieldType.DATETIME;
      case "DECIMAL" -> CustomFieldType.DECIMAL;
      case "ENUMERATION" -> CustomFieldType.ENUMERATION;
      case "ENUMERATION_DB" -> CustomFieldType.ENUMERATION_DB;
      case "MONEY" -> CustomFieldType.MONEY;
      case "IMAGE" -> CustomFieldType.IMAGE;
      case "UPLOAD" -> CustomFieldType.UPLOAD;
      default -> null; // Custom types have no legacy entity representation
    };
  }

  private static void putIfNonNull(CustomFieldDescriptor d, String key, Object value) {
    if (value != null) d.getConstraints().put(key, value);
  }

  private static String asString(Object v) {
    return v == null ? null : v.toString();
  }

  private static Boolean asBoolean(Object v) {
    if (v == null) return null;
    if (v instanceof Boolean b) return b;
    return Boolean.parseBoolean(v.toString());
  }

  private static Integer asInteger(Object v) {
    if (v == null) return null;
    if (v instanceof Integer i) return i;
    try {
      return Integer.valueOf(v.toString());
    } catch (NumberFormatException e) {
      return null;
    }
  }
}
