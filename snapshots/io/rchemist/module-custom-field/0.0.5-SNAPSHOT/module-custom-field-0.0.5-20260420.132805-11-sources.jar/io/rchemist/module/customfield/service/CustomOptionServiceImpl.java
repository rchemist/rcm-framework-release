/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapper;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.dao.CustomOptionDao;
import io.rchemist.module.customfield.data.CustomOptionCreateForm;
import io.rchemist.module.customfield.data.CustomOptionDTO;
import io.rchemist.module.customfield.data.CustomOptionUpdateForm;
import io.rchemist.module.customfield.domain.CustomOption;
import io.rchemist.module.customfield.domain.CustomOptionValue;
import io.rchemist.module.customfield.service.exception.CustomOptionErrorType;
import io.rchemist.module.customfield.service.exception.CustomOptionException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.Optional;
import javax.cache.Cache;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmCustomOptionService")
public class CustomOptionServiceImpl implements CustomOptionService {

    protected final CustomOptionDao dao;

    protected final Cache<String, CustomOptionDTO> entityCache;

    protected final Cache<String, ResponseListWrapper> searchCache;

    @Getter
    @PersistenceContext
    protected EntityManager entityManager;

    public CustomOptionServiceImpl(CustomOptionDao dao, CommonCacheManager cacheManager) {
        this.dao = dao;
        this.entityCache = cacheManager.getOrCreateCache(CustomFieldCacheRegion.CustomOption.ENTITY_CACHE, CustomOptionDTO.class);
        this.searchCache = cacheManager.getOrCreateCache(CustomFieldCacheRegion.CustomOption.SEARCH_CACHE, ResponseListWrapper.class);
    }

    @Override
    public CommonSearchRepository<CustomOption, Long> getRepository() {
        return dao.getCustomOptionRepository();
    }

    @Override
    public CustomOptionException entityNotFoundException() {
        return new CustomOptionException(CustomOptionErrorType.OPTION_NOT_FOUND);
    }

    @Override
    public CustomOption createEntity(CustomOptionCreateForm customOptionCreateForm) throws CustomOptionException {
        return CustomOption.create(customOptionCreateForm);
    }

    @Override
    public CustomOption updateEntity(CustomOption entity, CustomOptionUpdateForm customOptionUpdateForm) throws CustomOptionException {
        return entity.update(customOptionUpdateForm);
    }

    @Override
    public CustomOptionDTO getView(CustomOption entity, EntityViewType viewType) {
        return entity.view();
    }

    @Override
    public SearchContext<CustomOption, SearchForm> getSearchContext(SearchForm searchForm) {
        return new CommonSearchContext<>(CustomOption.class, searchForm);
    }

    @Override
    public CustomOption findCustomOptionByAlias(String tenantAlias, String alias) {
        return (StringUtils.isEmpty(tenantAlias)) ?
                dao.getCustomOptionRepository().findCustomOptionByAlias(alias)
                : dao.getCustomOptionRepository().findCustomOptionByAlias(tenantAlias, alias);
    }

    @Override
    public Optional<CustomOptionValue> findCustomOptionValueById(Long id) {
        return dao.getCustomOptionValueRepository().findById(id);
    }

    @Override
    public CustomOptionValue findCustomOptionValueByCustomOptionIdAndAlias(Long id, String alias) {
        return dao.getCustomOptionValueRepository().findCustomOptionValueByCustomOptionIdAndAlias(id, alias);
    }

    @Override
    public List<CustomOptionValue> getCustomOptionValues(Long id) {
        return dao.getCustomOptionValueRepository().findAllByCustomOptionId(id);
    }
}
