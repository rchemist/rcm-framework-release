/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal.storage;

import io.rchemist.module.customfield.spi.CustomFieldDescriptor;
import io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Map-backed {@link CustomFieldDescriptorStorage}. Proves storage-agnostic
 * design and serves as the default when no JPA adapter is present (e.g.
 * tests, non-JPA deployments, Mongo-only consumers).
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class InMemoryCustomFieldDescriptorStorage implements CustomFieldDescriptorStorage {

  public static final String ADAPTER_ID = "in-memory";

  private final Map<Object, CustomFieldDescriptor> byId = new LinkedHashMap<>();
  private final AtomicLong ids = new AtomicLong(0);
  private final Object mutex = new Object();

  @Override
  public CustomFieldDescriptor save(CustomFieldDescriptor descriptor) {
    if (descriptor == null) {
      throw new IllegalArgumentException("descriptor");
    }
    synchronized (mutex) {
      if (descriptor.getId() == null) {
        descriptor.setId(ids.incrementAndGet());
      }
      byId.put(descriptor.getId(), descriptor);
      return descriptor;
    }
  }

  @Override
  public Optional<CustomFieldDescriptor> findById(Object id) {
    if (id == null) return Optional.empty();
    synchronized (mutex) {
      return Optional.ofNullable(byId.get(id));
    }
  }

  @Override
  public Collection<CustomFieldDescriptor> findByNamespace(String namespace) {
    List<CustomFieldDescriptor> hits = new ArrayList<>();
    synchronized (mutex) {
      for (CustomFieldDescriptor d : byId.values()) {
        if (namespace == null ? d.getNamespace() == null : namespace.equals(d.getNamespace())) {
          hits.add(d);
        }
      }
    }
    return Collections.unmodifiableList(hits);
  }

  @Override
  public Collection<CustomFieldDescriptor> findAll() {
    synchronized (mutex) {
      return Collections.unmodifiableList(new ArrayList<>(byId.values()));
    }
  }

  @Override
  public boolean deleteById(Object id) {
    if (id == null) return false;
    synchronized (mutex) {
      return byId.remove(id) != null;
    }
  }

  @Override
  public String adapterId() {
    return ADAPTER_ID;
  }
}
