/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.internal;

import io.rchemist.module.customfield.spi.CustomFieldDescriptor;
import io.rchemist.module.customfield.spi.CustomFieldFacade;
import io.rchemist.module.customfield.spi.CustomFieldValue;
import io.rchemist.module.customfield.spi.storage.CustomFieldDescriptorStorage;
import io.rchemist.module.customfield.spi.storage.CustomFieldValueStorage;
import io.rchemist.module.customfield.spi.type.CustomFieldTypeRegistry;
import io.rchemist.module.customfield.spi.type.CustomFieldValueType;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidationResult;
import io.rchemist.module.customfield.spi.validation.CustomFieldValidator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Default {@link CustomFieldFacade} wiring. Stateless except for its
 * collaborators.
 *
 * <p>Project : Rchemist Commerce Platform
 * Created by kunner
 */
public final class DefaultCustomFieldFacade implements CustomFieldFacade {

  private final CustomFieldTypeRegistry types;
  private final CustomFieldDescriptorStorage descriptors;
  private final CustomFieldValueStorage values;
  private final List<CustomFieldValidator> validators;

  public DefaultCustomFieldFacade(
      CustomFieldTypeRegistry types,
      CustomFieldDescriptorStorage descriptors,
      CustomFieldValueStorage values,
      List<CustomFieldValidator> validators) {
    this.types = Objects.requireNonNull(types, "types");
    this.descriptors = Objects.requireNonNull(descriptors, "descriptors");
    this.values = Objects.requireNonNull(values, "values");
    List<CustomFieldValidator> sorted = new ArrayList<>(validators == null ? List.of() : validators);
    sorted.sort(Comparator.comparingInt(CustomFieldValidator::order));
    this.validators = List.copyOf(sorted);
  }

  @Override
  public CustomFieldTypeRegistry types() {
    return types;
  }

  @Override
  public CustomFieldDescriptorStorage descriptors() {
    return descriptors;
  }

  @Override
  public CustomFieldValueStorage values() {
    return values;
  }

  @Override
  public CustomFieldValidationResult validate(CustomFieldDescriptor descriptor, String rawValue) {
    Objects.requireNonNull(descriptor, "descriptor");
    CustomFieldValidationResult result = new CustomFieldValidationResult();
    for (CustomFieldValidator v : validators) {
      v.validate(descriptor, rawValue, result);
    }
    return result;
  }

  @Override
  public Collection<CustomFieldDescriptor> describeNamespace(String namespace) {
    return descriptors.findByNamespace(namespace);
  }

  @Override
  public Map<String, String> snapshot(String namespace, Object ownerId) {
    Collection<CustomFieldValue> all = values.list(namespace, ownerId);
    Map<String, String> out = new LinkedHashMap<>();
    for (CustomFieldValue v : all) {
      out.put(v.getPropertyName(), v.getRawValue());
    }
    return out;
  }

  @Override
  public Optional<Object> readTyped(String namespace, Object ownerId, String propertyName) {
    Optional<CustomFieldValue> raw = values.get(namespace, ownerId, propertyName);
    if (raw.isEmpty()) return Optional.empty();
    CustomFieldValue v = raw.get();
    CustomFieldDescriptor descriptor = findDescriptor(namespace, propertyName);
    if (descriptor == null) return Optional.ofNullable(v.getRawValue());
    CustomFieldValueType type = types.find(descriptor.getTypeId()).orElse(null);
    if (type == null) return Optional.ofNullable(v.getRawValue());
    Object typed = type.coercer().toValue(v.getRawValue());
    return Optional.ofNullable(typed);
  }

  private CustomFieldDescriptor findDescriptor(String namespace, String propertyName) {
    for (CustomFieldDescriptor d : descriptors.findByNamespace(namespace)) {
      if (propertyName.equals(d.getPropertyName())) return d;
    }
    return null;
  }
}
