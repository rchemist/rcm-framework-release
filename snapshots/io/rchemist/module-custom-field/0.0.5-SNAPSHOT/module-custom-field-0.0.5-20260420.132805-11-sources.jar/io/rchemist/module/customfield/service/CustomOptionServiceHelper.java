/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.util.NumberUtil;
import io.rchemist.module.customfield.data.CustomOptionDTO;
import io.rchemist.module.customfield.data.CustomOptionValueDTO;
import io.rchemist.module.customfield.domain.CustomOption;
import io.rchemist.module.customfield.domain.CustomOptionValue;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class CustomOptionServiceHelper {

  private static CustomOptionService customOptionService;

  public static CustomOptionService getCustomOptionService(){
    if(customOptionService == null){
      customOptionService = ApplicationContextHolder.getBean(CustomOptionService.class);
    }
    return customOptionService;
  }

  public static CustomOptionDTO build(CustomOption option, boolean includeValues) {

    CustomOptionDTO dto = new CustomOptionDTO()
        .withId(option.getId())
        .withName(option.getName())
        .withDescription(option.getDescription())
        .withAlias(option.getAlias())
        .withTenantAlias(option.getTenantAlias())
        .withCreatedAt(option.getCreatedAt())
        .withUpdatedAt(option.getUpdatedAt())
        .withActive(option.isActive());

    if(includeValues){
      List<CustomOptionValue> values = getCustomOptionService().getCustomOptionValues(option.getId());

      List<CustomOptionValueDTO> dtos = new ArrayList<>();
      for(CustomOptionValue value : values){
        dtos.add(buildValue(value));
      }

      dto.setValues(dtos);
    }

    return dto;

  }

  private static CustomOptionValueDTO buildValue(CustomOptionValue value) {
    CustomOptionValueDTO dto = new CustomOptionValueDTO()
        .withId(value.getId())
        .withName(value.getName())
        .withValue(value.getValue())
        .withAlias(value.getAlias())
        .withPriority(NumberUtil.getInteger(value.getPriority()))
        .withCreatedAt(value.getCreatedAt())
        .withUpdatedAt(value.getUpdatedAt());
    return dto;
  }

  public static Optional<CustomOptionValue> findCustomOptionValueById(Long id) {
    return getCustomOptionService().findCustomOptionValueById(id);
  }

  public static CustomOptionValue findCustomOptionValueByCustomOptionIdAndAlias(Long id, String alias) {
    return getCustomOptionService().findCustomOptionValueByCustomOptionIdAndAlias(id, alias);
  }

  public static List<CustomOptionValueDTO> getCustomOptionValues(String tenantAlias, String alias) {

    CustomOptionCache cache = CustomOptionCache.getCache(tenantAlias, alias);
    if(cache == null || cache.isExpired())
      cache = CustomOptionCache.createOrResetCacheItem(tenantAlias, alias);

    if(cache != null && cache.getOption() != null){
      return cache.getOption().getValues();
    }

    return new ArrayList<>();

  }

}
