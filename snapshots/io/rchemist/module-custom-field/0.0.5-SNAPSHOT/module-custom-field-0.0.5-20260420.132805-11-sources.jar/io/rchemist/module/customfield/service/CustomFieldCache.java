/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.module.customfield.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.cache.data.CacheData;
import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.module.customfield.config.CustomFieldCacheRegion;
import io.rchemist.module.customfield.data.CustomFieldDTO;
import io.rchemist.module.customfield.service.exception.CustomFieldErrorType;
import io.rchemist.module.customfield.service.exception.CustomFieldException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import javax.cache.Cache;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class CustomFieldCache extends CacheData {

  private CustomFieldCache(){
    super(CustomFieldCacheRegion.CustomField.TTL / 60);
  }

  public CustomFieldCache(String targetEntityClass) {
    super(CustomFieldCacheRegion.CustomField.TTL / 60 );
    this.targetEntityClass = targetEntityClass;
  }

  @Setter(AccessLevel.PRIVATE)
  protected String targetEntityClass;

  protected List<CustomFieldDTO> fields = new ArrayList<>();

  public CustomFieldCache withFields(List<CustomFieldDTO> fields) {
    this.fields = fields;
    return this;
  }

  public CustomFieldCache addFields(CustomFieldDTO... dtos){
    if(ArrayUtils.isNotEmpty(dtos)){
      Set<CustomFieldDTO> set = new HashSet<>(fields);
      set.addAll(Arrays.asList(dtos));
      this.fields = new ArrayList<>(set);
    }
    return this;
  }

  public boolean removeFields(String... propertyNames) {
    boolean result = false;
    if(ArrayUtils.isNotEmpty(propertyNames)){
      if(CollectionUtils.isNotEmpty(this.fields)){
        ListIterator<CustomFieldDTO> iterator = this.fields.listIterator();
        while(iterator.hasNext()){

          CustomFieldDTO dto = iterator.next();

          if(ArrayUtils.contains(propertyNames, dto.getPropertyName())){
            result = true;
            iterator.remove();
          }

        }
      }
    }
    return result;

  }

  public static void add(CustomFieldDTO... customFields){
    if(ArrayUtils.isNotEmpty(customFields)){
      for(CustomFieldDTO customField : customFields){
        if(customField != null){
          String targetEntityClass = customField.getTargetEntityClass();

          Cache cache = getCache();

          CustomFieldCache fieldCache = getCache(targetEntityClass);

          if(fieldCache == null){
            fieldCache = new CustomFieldCache(targetEntityClass);
          }

          fieldCache.addFields(customField);

          cache.put(targetEntityClass, fieldCache);
        }
      }
    }

  }

  private static Cache<String, CustomFieldCache> getCache() {
    CommonCacheManager redisCacheManager = ApplicationContextHolder.getBean(CommonCacheManager.class);
    Cache cache = redisCacheManager.getCache(CustomFieldCacheRegion.CustomField.DATA);
    return cache;
  }

  public static void add(Long id) {
    CustomFieldDTO customField = null;
    try {
      customField = CustomFieldServiceHelper.getCustomFieldService().findViewById(id);

      if(customField != null){
        add(customField);
      }

    } catch (CustomFieldException e) {
      // do nothing
      return;
    }

  }

  public static void remove(String targetEntityClass, String propertyName){
    removeFields(targetEntityClass, new HashSet<>(Arrays.asList(propertyName)));
  }

  public static void removeFields(String targetEntityClass, Set<String> propertyNames){
    CustomFieldCache cache = getCache(targetEntityClass);

    if(cache != null){
      boolean result = cache.removeFields(propertyNames.toArray(new String[0]));

      if(result){
        getCache().put(targetEntityClass, cache);
      }
    }
  }

  public static boolean isExpired(String targetEntityClass, String versionId, boolean refreshIfExpired) throws CustomFieldException {
    return isExpired(TenantHelper.getTenantAliasFromWebRequestContext(), targetEntityClass, versionId, refreshIfExpired);
  }

  public static boolean isExpired(String tenantAlias, String targetEntityClass, String versionId, boolean refreshIfExpired) throws CustomFieldException {

    CustomFieldCache cache = getCache(tenantAlias, targetEntityClass);

    if(cache == null)
      throw new CustomFieldException(CustomFieldErrorType.CACHE_NOT_FOUND);

    if(cache.isExpired()){
      if(refreshIfExpired){
        cache = createOrResetCacheItem(tenantAlias, targetEntityClass);
      }
      return true;
    }else{

      if(!StringUtils.equals(cache.getVersionId(), versionId)){
        return false;
      }

    }

    return true;
  }


  public static CustomFieldCache getCache(String targetEntityClass){
    return getCache(TenantHelper.getTenantAliasFromWebRequestContext(), targetEntityClass);
  }

  public static CustomFieldCache getCache(String tenantAlias, String targetEntityClass){
    String cacheKey = createCacheKey(tenantAlias, targetEntityClass);
    return getCache().get(cacheKey);
  }

  public static List<CustomFieldDTO> getCacheData(String targetEntityClass){
    return getCacheData(targetEntityClass, false);
  }

  public static List<CustomFieldDTO> getCacheData(String targetEntityClass, boolean forceRefresh){
    return getCacheData(TenantHelper.getTenantAliasFromWebRequestContext(), targetEntityClass, forceRefresh);
  }

  public static List<CustomFieldDTO> getCacheData(String tenantAlias, String targetEntityClass, boolean forceRefresh){
    CustomFieldCache cache = null;

    String cacheKey = createCacheKey(tenantAlias, targetEntityClass);

    if(!forceRefresh){
      cache = getCache(cacheKey);
    }

    if(cache != null){
      if(cache.isExpired()){
        cache = createOrResetCacheItem(tenantAlias, targetEntityClass);
      }
    }else{
      cache = createOrResetCacheItem(tenantAlias, targetEntityClass);
    }

    return cache.getFields();

  }

  public static CustomFieldCache createOrResetCacheItem(String targetEntityClass) {

    return createOrResetCacheItem(TenantHelper.getTenantAliasFromWebRequestContext(), targetEntityClass);
  }

  public static CustomFieldCache createOrResetCacheItem(String tenantAlias, String targetEntityClass) {

    CustomFieldCache cache = new CustomFieldCache(targetEntityClass);
    // active 한 필드만 표시
    List<CustomFieldDTO> fields = CustomFieldServiceHelper.getCustomFieldService().getCustomFields(targetEntityClass, true);

    if(CollectionUtils.isNotEmpty(fields)){
      cache.addFields(
          fields.toArray(new CustomFieldDTO[0])
      );
    }

    getCache().put(createCacheKey(tenantAlias, targetEntityClass), cache);
    return cache;
  }


  private static String createCacheKey(String tenantAlias, String targetEntityClass){
    return tenantAlias + "_" + targetEntityClass;
  }




}
