/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.extension;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections4.CollectionUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public abstract class ExtensionManager<T extends ExtensionHandler> implements InvocationHandler {

  protected static String LOCK_OBJECT = "EM_LOCK";
  protected boolean handlersSorted = false;
  protected T extensionHandler;

  protected Class<?> extensionHandlerClass;
  private final List<ProxyHandlerRegistered<T>> registeredHandlers = new ArrayList<>();

  public ExtensionManager(Class<T> _clazz) {
    this.extensionHandler = (T) Proxy.newProxyInstance(_clazz.getClassLoader(),
        new Class[]{_clazz},
        this);
    this.extensionHandlerClass = _clazz;
  }

  public T getProxy() {
    return extensionHandler;
  }

  protected void sortHandlers() {
    if (!handlersSorted) {
      Comparator fieldCompare = new BeanComparator("priority");
      Collections.sort(registeredHandlers, fieldCompare);
      handlersSorted = true;
    }
  }

  @Override
  public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    boolean notHandled = true;
    int totalCount = getRegisteredHandlers().size();
    int currentIndex = 0;
    for (ProxyHandlerRegistered registered : getRegisteredHandlers()) {
      currentIndex++;
      try {
        ExtensionHandler handler = registered.getHandler();

        if (handler.isEnabled()) {
          ExtensionResultStatusType result = (ExtensionResultStatusType) method.invoke(handler, args);
          if (!ExtensionResultStatusType.NOT_HANDLED.equals(result)) {
            notHandled = false;
          }
          if (!shouldContinue(result, handler, method, args)) {
            break;
          }
        }
      } catch (InvocationTargetException e) {

        if (continueOnException()) {
          if (currentIndex == totalCount) {
            // 맨 마지막인 경우에는 그냥 throw 한다.
            throw e.getCause();
          }

          System.out.println("Execute extensionHandler " + registered.getHandlerClass().getSimpleName() + " was failed. ContinueOnException is true, go ahead without throw exception.");
          e.printStackTrace();

          continue;
        }

        throw e.getCause();
      }

    }

    if (notHandled) {
      return ExtensionResultStatusType.NOT_HANDLED;
    } else {
      return ExtensionResultStatusType.HANDLED;
    }
  }

  public boolean registerHandler(T handler) {
    return registerHandler(handler, Integer.MAX_VALUE);
  }

  public boolean registerHandler(T handler, int priority) {
    synchronized (LOCK_OBJECT) {
      boolean add = true;

      if (!this.extensionHandlerClass.isAssignableFrom(handler.getClass())) {
        throw new IllegalArgumentException("ExtensionHandler " + handler.getClass() + " cannot extend " + this.extensionHandlerClass);
      }

      for (ProxyHandlerRegistered registered : registeredHandlers) {
        if (registered.getHandlerClass().equals(handler.getClass())) {
          add = false;
          break;
        }
      }

      if (add) {
        this.registeredHandlers.add(new ProxyHandlerRegistered<>(priority, handler));
        handlersSorted = false;
      }

      return add;
    }
  }

  public boolean shouldContinue(ExtensionResultStatusType result, ExtensionHandler handler,
      Method method, Object[] args) {
    if (result != null) {
      if (ExtensionResultStatusType.HANDLED_STOP.equals(result)) {
        return false;
      }

      return !ExtensionResultStatusType.HANDLED.equals(result) || continueOnHandled();
    }
    return true;
  }

  public boolean continueOnHandled() {
    return false;
  }

  public int getPriority() {
    throw new UnsupportedOperationException();
  }

  public List<T> getHandlers(){
    return CollectionUtils.emptyIfNull(registeredHandlers).stream().map(ProxyHandlerRegistered::getHandler).collect(
        Collectors.toList());
  }

  protected ExtensionResultStatusType execute(ExtensionManagerOperation operation, Object... params) {
    boolean notHandled = true;
    for (ProxyHandlerRegistered registeredHandler : getRegisteredHandlers()) {
      ExtensionHandler handler = registeredHandler.getHandler();
      if (handler.isEnabled()) {
        ExtensionResultStatusType result = operation.execute(handler, params);
        if (!ExtensionResultStatusType.NOT_HANDLED.equals(result)) {
          notHandled = false;
        }
        if (!shouldContinue(result, handler, null, null)) {
          break;
        }
      }
    }
    if (notHandled) {
      return ExtensionResultStatusType.NOT_HANDLED;
    } else {
      return ExtensionResultStatusType.HANDLED;
    }
  }

  public List<ProxyHandlerRegistered<T>> getRegisteredHandlers() {
    synchronized (LOCK_OBJECT) {
      if (!handlersSorted) {
        sortHandlers();
        handlersSorted = true;
      }
      return this.registeredHandlers;
    }
  }

  public static boolean hasExtensionResult(ExtensionResultStatusType status, ExtensionResultHolder<?> resultHolder) {
    return !status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder != null
        && resultHolder.hasResult();
  }

  // exception 이 발생했을 때 어떻게 할 것인지 정의한다. 이 값이 true 가 되면 핸들러 execute 를 하다 에러가 나도 다음 핸들러를 동작 시킨다.
  // 하지만 다음 핸들러가 없으면 exception 을 그대로 throw 한다.
  protected boolean continueOnException() {
    return false;
  }


}
