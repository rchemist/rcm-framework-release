/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.extension;


import java.lang.annotation.Annotation;
import java.util.Map;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.annotation.AnnotationUtils;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface ExtensionHandler extends BeanPostProcessor, ApplicationContextAware {

  Log LOG = LogFactory.getLog(ExtensionHandler.class);

  /**
   * Determines the priority of this extension handler.
   *
   * @return
   */
  default int getPriority() {
    return Integer.MAX_VALUE;
  }

  default void setApplicationContext(ApplicationContext applicationContext) {
    init(applicationContext);
  }

  /**
   * If false, the ExtensionManager should skip this Handler.
   *
   * @return
   */
  default boolean isEnabled() {
    return true;
  }

  default void init(ApplicationContext applicationContext) {
    if (this.getClass().isAnnotationPresent(RegisterExtensionHandler.class)) {
      Annotation annotation = this.getClass().getAnnotation(RegisterExtensionHandler.class);
      Map<String, Object> annotationAttrs = AnnotationUtils.getAnnotationAttributes(annotation);
      String managerBean = MapUtils.getString(annotationAttrs, "manager");
      Integer priority = MapUtils.getInteger(annotationAttrs, "priority");

      ExtensionManager manager = applicationContext.getBean(managerBean, ExtensionManager.class);
      manager.registerHandler(this, priority);

      if (!LOG.isDebugEnabled()) {
        for (Object registered : manager.getRegisteredHandlers()) {
          LOG.debug("registered handler info :: priority - " + ((ProxyHandlerRegistered) registered).getPriority()
              + " || class - " + ((ProxyHandlerRegistered) registered).getHandlerClass()
          );
        }
      }
    }

  }


}
