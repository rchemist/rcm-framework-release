/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.extension;

import lombok.Getter;

/**
 * <p>
 * Project : rchemist <br />
 * Created by kunner <br />
 * DateTime : 2019-04-10 / 00 : 37 <br />
 * </p>
 * <p>
 * Comment <br />
 *
 * ProxyManager 에 등록된 ProxyHandler 를 priority 별로 관리할 수 있도록
 * ProxyManager 에서 List<ProxyHandler> 가 아니라 List<ProxyHandlerRegistered> 로 저장한다.
 * 여기서 관리되는 Integer priority 로 ProxyManager.sortHandler() 메소드가 실행될 때 우선순위에 따라 정렬될 것이다.
 *
 * ProxyHandler의 등록은 가급적 @RegisterProxy 어노테이션을 사용하며, 이때 priority 는 어노테이션의 필드로 관리된다.
 * 만약 ProxyHandler를 직접 등록하고자 한다면 ProxyManager.registerHandler(Integer priority, T handler) 메소드를 이용한다.
 *
 *
 * </p>
 * <p>
 * Revision History <br />
 * 1. 2019-04-10 : Created <!-- 주요 변경 정보 -->
 * </p>
 **/
@Getter
public class ProxyHandlerRegistered<T extends ExtensionHandler> {

    private final Integer priority;           // 우선순위 : ProxyManager.registerHandler() 로 넘어 온 priority 파라미터 값
    private final T handler;                  // 등록된 핸들러 : ProxyManager.registerHandler() 로 넘어 온 T handler 파라미터 값

    public ProxyHandlerRegistered(Integer priority, T handler){
        this.priority = priority;
        this.handler = handler;
    }

    /**
     * 핸들러의 클래스가 같은지 다른지에 따라 핸들러를 ProxyManager에 등록할지 말지를 결정한다.
     * @return
     */
    public Class<?> getHandlerClass(){
        return handler.getClass();
    }

}
