/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.common.extension;

import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ExtensionResultHolder<T> {

  protected T result;
  protected Throwable throwable;
  protected Map<String, Object> contextMap = new HashMap<>();

  public boolean hasResult() {
    return result != null;
  }

  public ExtensionResultHolder<T> addContext(String key, Object value){
    if(contextMap == null)
      contextMap = new HashMap<>();

    contextMap.put(key, value);
    return this;
  }

  public ExtensionResultHolder<T> withResult(T result) {
    this.result = result;
    return this;
  }

  public ExtensionResultHolder<T> withThrowable(Throwable throwable) {
    this.throwable = throwable;
    return this;
  }

  public ExtensionResultHolder<T> withContextMap(Map<String, Object> contextMap) {
    this.contextMap = contextMap;
    return this;
  }
}
