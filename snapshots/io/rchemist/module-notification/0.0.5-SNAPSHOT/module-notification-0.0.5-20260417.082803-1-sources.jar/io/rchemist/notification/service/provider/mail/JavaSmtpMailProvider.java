/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.mail;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * <p>
 * project : rcm-framework
 * SMTP 를 직접 정의해 Java Mail Sender 를 이용하는 방식
 * 반드시 spring boot message properties 에
 * <p>
 * Created by kunner
 **/
@Slf4j
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 70000)
public class JavaSmtpMailProvider extends AbstractNotifyProvider {

  private static final String PROVIDER_NAME = "JavaMail";
  private static final String PROVIDER_ALIAS = "JAVAMAIL";
  private static final String[] ATTRIBUTES = ArrayUtil.make("host", "port", "username", "password", "protocol", "auth", "starttls");

  // 테넌트가 1000 개 쯤 된다면 충분하겠지
  private static final Map<String, JavaMailSender> mailSenders = new ConcurrentHashMap<>(1000);
  
  public JavaSmtpMailProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  private JavaMailSender getMailSender(String tenantAlias, Map<String, String> properties) {
    if (mailSenders.containsKey(tenantAlias)) {
      return mailSenders.get(tenantAlias);
    }

    String host = StringUtil.toString(properties.get("host"));
    String port = StringUtil.toString(properties.get("port"));
    String username = StringUtil.toString(properties.get("username"));
    String password = StringUtil.toString(properties.get("password"));
    String sslTrust = StringUtil.toString(properties.get("ssl-trust"));
    boolean auth = BooleanUtils.toBooleanObject(StringUtil.toString(properties.get("auth"), "true").toLowerCase());
    boolean starttls = BooleanUtils.toBooleanObject(StringUtil.toString(properties.get("starttls"), "true").toLowerCase());

    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

    mailSender.setHost(host);
    mailSender.setPort(Integer.parseInt(port));
    mailSender.setUsername(username);
    mailSender.setPassword(password);

    Properties props = mailSender.getJavaMailProperties();
    props.put("mail.smtp.auth", auth);
    props.put("mail.smtp.starttls.enable", starttls);
    props.put("mail.smtp.starttls.required", starttls);
    props.put("mail.smtp.ssl.trust", sslTrust);

    mailSenders.put(tenantAlias, mailSender);

    return mailSender;
  }

  /**
   * Mailgun 발송,
   *
   * @param provider
   * @param notificationQueue
   * @return
   */
  private void sendJavaMail(NotificationProvider provider, NotificationQueue notificationQueue) throws MessagingException{

    Map<String, String> properties = getProviderAttributes(provider);
    if(!properties.containsKey("host") || !properties.containsKey("port") || !properties.containsKey("username") || !properties.containsKey("password")){
      throw new MessagingException("There is no valid SMTP config.");
    }

    String senderAddress = StringUtil.toString(notificationQueue.getSenderNameAddress(), provider.getSenderNameAddress());

    final JavaMailSender mailSender = getMailSender(provider.getTenantAlias(), properties);

    if (mailSender == null)
      throw new MessagingException("There is no valid SMTP config.");


    final MimeMessage message = mailSender.createMimeMessage();

    int loop = 0;
    for(TargetDTO target : notificationQueue.getToList()){

      final MimeMessageHelper helper = new MimeMessageHelper(message, "UTF-8");

      helper.setFrom(senderAddress);
      helper.setTo(target.getNameAddress());
      helper.setSubject(notificationQueue.getTitle());
      helper.setText(notificationQueue.getContent(), true);

      if (loop == 0) {
        String cc = notificationQueue.getCcListToString();
        if (StringUtils.isNotEmpty(cc)) {
          helper.addCc(cc);
        }
        String bcc = notificationQueue.getBccListToString();
        if (StringUtils.isNotEmpty(bcc)) {
          helper.addBcc(bcc);
        }
      }

      mailSender.send(message);

      loop++;
    }
  }

  @Override
  public NotificationType getNotificationType() { return NotificationType.EMAIL; }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return ATTRIBUTES;
  }

  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh, NotificationProvider provider, NotificationQueue notificationQueue) {
    // 결과
    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try {
      sendJavaMail(provider, notificationQueue);
    } catch(Exception e) {
      resultMessage = e.getMessage();
    } finally {
      erh.setResult(new NotifyResult(result, resultMessage));

      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

    }
  }

}
