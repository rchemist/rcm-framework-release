/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NotifyProvider extends ExtensionHandler {

  /**
   * provider 의 alias - 실제 등록된 alias 와 동일해야 한다.
   * @return
   */
  String getProviderAlias();

  /**
   * 관리자도구에 보여 줄 이름
   * @return
   */
  String getProviderName();

  /**
   * 관리자도구에서 이 프로바이더를 등록할 때 반드시 입력해야 하는 추가 정보
   * @return
   */
  String[] getRequiredAttributes();

  /**
   * Provider 의 NotificationType
   * @return
   */
  NotificationType getNotificationType();

  /**
   * 발송 처리
   * @param erh
   * @param provider
   * @param notificationQueue
   * @return
   */
  ExtensionResultStatusType notify(ExtensionResultHolder<NotifyResult> erh, NotificationProvider provider, NotificationQueue notificationQueue);


  @Getter
  @AllArgsConstructor
  class NotifyResult implements Serializable {
    private boolean result;
    private String message;
  }

}
