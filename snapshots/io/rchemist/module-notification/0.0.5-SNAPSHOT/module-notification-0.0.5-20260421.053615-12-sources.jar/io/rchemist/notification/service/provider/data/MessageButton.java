/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.data;

import java.io.Serializable;
import lombok.Data;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
public class MessageButton implements Serializable {

  private Integer ordering;
  private String chatExtra;
  private String chatEvent;
  private String target;

  public MessageButton withOrdering(Integer ordering) {
    this.ordering = ordering;
    return this;
  }

  public MessageButton withChatExtra(String chatExtra) {
    this.chatExtra = chatExtra;
    return this;
  }

  public MessageButton withChatEvent(String chatEvent) {
    this.chatEvent = chatEvent;
    return this;
  }

  public MessageButton withTarget(String target) {
    this.target = target;
    return this;
  }
}
