/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.extension;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.HibernateSearchContext;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.data.NotificationTemplateCreateForm;
import io.rchemist.notification.data.NotificationTemplateResult;
import io.rchemist.notification.data.NotificationTemplateUpdateForm;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.data.ParseNotificationTemplateRequest;
import io.rchemist.notification.domain.NotificationTemplate;
import io.rchemist.notification.service.exception.NotificationTemplateServiceException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NotificationTemplateServiceExtensionHandler extends ExtensionHandler {

    /**
    * Entity 를 새로 생성하기 전 CreateForm 을 Validation 하거나 CreateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preCreate(ExtensionResultHolder<NotificationTemplateCreateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 새로 생성한 직후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postCreate(NotificationTemplateCreateForm createForm, ExtensionResultHolder<NotificationTemplate> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 Update 하기 전 UpdateForm 을 Validation 하거나 UpdateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preUpdate(NotificationTemplate entity, ExtensionResultHolder<NotificationTemplateUpdateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 수정한 후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postUpdate(NotificationTemplateUpdateForm updateForm, ExtensionResultHolder<NotificationTemplate> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    default ExtensionResultStatusType preView(NotificationTemplate entity, EntityViewType viewType, ExtensionResultHolder<NotificationTemplateView> resultHolder) throws NotificationTemplateServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 View 로 변환할 때 확장 로직
    * @return
    */
    default ExtensionResultStatusType postView(NotificationTemplate entity, EntityViewType viewType, ExtensionResultHolder<NotificationTemplateView> resultHolder) throws NotificationTemplateServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 의 목록을 조회할 때 SearchContext 를 확장하는 로직
    * @return
    */
    default ExtensionResultStatusType overrideSearchContext(SearchForm searchForm, ExtensionResultHolder<SearchContext<NotificationTemplate, SearchForm>> resultHolder) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
   * Entity 의 목록을 조회할 때 HibernateSearchContext 를 확장하는 로직
   * @return
   */
  default ExtensionResultStatusType overrideHibernateSearchContext(SearchForm searchForm, ExtensionResultHolder<HibernateSearchContext<NotificationTemplate, SearchForm>> resultHolder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  /**
   * 실제 템플릿을 템플릿 엔진으로 parsing 한 결과를 resultHolder 에 담는다.
   * <p>
   * 이 부분은 이 모듈을 사용하는 각 서비스에서 직접 구현해야 한다.
   *
   * @param request
   * @param view
   * @param erh
   * @return
   */
  default ExtensionResultStatusType generateNotificationTemplateResult(NotificationTemplateView view, ParseNotificationTemplateRequest request, ExtensionResultHolder<NotificationTemplateResult> erh) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }
}
