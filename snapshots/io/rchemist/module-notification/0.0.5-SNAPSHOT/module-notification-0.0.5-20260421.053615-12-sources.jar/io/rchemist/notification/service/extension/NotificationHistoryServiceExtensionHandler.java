/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.extension;

import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.HibernateSearchContext;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.data.NotificationHistoryView;
import io.rchemist.notification.domain.NotificationHistory;
import io.rchemist.notification.service.exception.NotificationHistoryServiceException;

/**
 * <p>
 * Project : Rchemist Platform
 * <p>
 * Created by kunner
 **/
public interface NotificationHistoryServiceExtensionHandler extends ExtensionHandler {

    default ExtensionResultStatusType preView(NotificationHistory entity, EntityViewType viewType, ExtensionResultHolder<NotificationHistoryView> resultHolder) throws NotificationHistoryServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 View 로 변환할 때 확장 로직
    * @return
    */
    default ExtensionResultStatusType postView(NotificationHistory entity, EntityViewType viewType, ExtensionResultHolder<NotificationHistoryView> resultHolder) throws NotificationHistoryServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 의 목록을 조회할 때 SearchContext 를 확장하는 로직
    * @return
    */
    default ExtensionResultStatusType overrideSearchContext(SearchForm searchForm, ExtensionResultHolder<SearchContext<NotificationHistory, SearchForm>> resultHolder) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
   * Entity 의 목록을 조회할 때 HibernateSearchContext 를 확장하는 로직
   * @return
   */
  default ExtensionResultStatusType overrideHibernateSearchContext(SearchForm searchForm, ExtensionResultHolder<HibernateSearchContext<NotificationHistory, SearchForm>> resultHolder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
