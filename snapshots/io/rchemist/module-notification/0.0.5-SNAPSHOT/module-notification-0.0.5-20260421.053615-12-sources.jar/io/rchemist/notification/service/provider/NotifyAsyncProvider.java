/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.helper.NotificationProviderServiceHelper;
import io.rchemist.notification.service.provider.NotifyProvider.NotifyResult;
import io.rchemist.notification.service.type.NotificationProviderType;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Service("rcmNotifyAsyncProvider")
public class NotifyAsyncProvider {

  protected final NotifyProviderManager notifyProviderManager;

  public NotifyAsyncProvider(NotifyProviderManager notifyProviderManager) {
    this.notifyProviderManager = notifyProviderManager;
  }

  @Async
  public void sendAsync(NotificationProvider provider, NotificationQueue notificationQueue) {
    ExtensionResultHolder<NotifyResult> erh = new ExtensionResultHolder<>();
    notifyProviderManager.getProxy().notify(erh, provider, notificationQueue);
  }

  @Async
  public void sendAsync(NotificationQueue notificationQueue) {
    sendAsync(getNotificationProvider(notificationQueue), notificationQueue);
  }

  protected NotificationProvider getNotificationProvider(NotificationQueue notificationQueue) {

    String tenantAlias = notificationQueue.getTenantAlias();

    if(StringUtils.isNotEmpty(notificationQueue.getNotificationProviderType())){
      NotificationProviderType providerType = EnumTypeUtil.getEnumType(NotificationProviderType.class, notificationQueue.getNotificationProviderType());
      if(providerType != null){
        return NotificationProviderServiceHelper.findNotificationProviderByAlias(
            tenantAlias, providerType.getType());
      }
    }

    NotificationType notificationType = notificationQueue.getNotificationType();
    List<NotificationProvider> providers = NotificationProviderServiceHelper.getNotificationProviderByTenantAliasAndNotificationType(tenantAlias, notificationType);

    if(CollectionUtils.isNotEmpty(providers)){
      for(NotificationProvider provider : providers){
        if(provider.isActive()){
          return provider;
        }
      }
    }

    return null;

  }
}
