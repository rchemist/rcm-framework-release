/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.search;

import io.rchemist.common.enumeration.EnumType;
import io.rchemist.common.search.bridge.EnumTypeValueBridge;
import io.rchemist.notification.service.type.NotificationProviderType;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
public class NotificationProviderTypeValueBridge extends EnumTypeValueBridge<NotificationProviderType> {

  @Override
  protected Class<? extends EnumType<?>> getEnumType() {
    return NotificationProviderType.class;
  }
}
