/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.domain.NotificationTemplate;
import io.rchemist.notification.service.NotificationTemplateService;
import io.rchemist.notification.service.exception.NotificationTemplateServiceException;
import io.rchemist.notification.service.type.NotificationTemplateType;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationTemplateServiceHelper {

  private static NotificationTemplateService service;
  
  private static NotificationTemplateService getService() {
  
    if (service == null) {
      service = ApplicationContextHolder.getBean(NotificationTemplateService.class);
    }
    
    return service;
  }
  
  public static NotificationTemplate findEntityById(Long id) throws NotificationTemplateServiceException {
    return getService().findEntityById(id);
  }
  
  public static NotificationTemplateView findViewById(Long id) throws NotificationTemplateServiceException {
    return getService().findViewById(id);
  }
  
  public static List<NotificationTemplate> findAllById(List<Long> ids) {
    return getService().findAllById(ids);
  }


  public static NotificationTemplate findByExternalId(String externalId) {
    return getService().findByExternalId(externalId);
  }

  public static NotificationTemplate findByNotificationTypeAndTemplateType(NotificationType notificationType, NotificationTemplateType notificationTemplateType) {
    return getService().findByNotificationTypeAndTemplateType(notificationType, notificationTemplateType);
  }

  public static NotificationTemplate findByNotificationTypeAndCustomAlias(NotificationType notificationType, String customAlias) {
    return getService().findByNotificationTypeAndCustomAlias(notificationType, customAlias);
  }
}
