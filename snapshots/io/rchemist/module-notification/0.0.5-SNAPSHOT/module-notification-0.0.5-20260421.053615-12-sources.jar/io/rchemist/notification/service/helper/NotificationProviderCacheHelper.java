/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.notification.configuration.NotificationCacheRegion.Notification;
import io.rchemist.notification.configuration.NotificationRedisCacheManager;
import io.rchemist.notification.data.NotificationProviderCache;
import io.rchemist.notification.data.NotificationProviderCache.ProviderCacheItem;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationProviderCacheHelper {

  private static NotificationProviderCache cache;

  private static CacheManager cacheManager;

  private static Cache getCache(String cacheName){
    if(cacheManager == null){
      cacheManager = ApplicationContextHolder.getBean(NotificationRedisCacheManager.CACHE_MANAGER, CacheManager.class);
    }
    return cacheManager.getCache(cacheName);
  }

  private static NotificationProviderCache getCache() {
    NotificationProviderCache data = getCache(Notification.PROVIDERS).get(
        NotificationProviderCache.CACHE_NAME, NotificationProviderCache.class);
    if(data == null && cache != null){
      getCache(Notification.PROVIDERS).put(NotificationProviderCache.CACHE_NAME, cache);
    }
    return data == null ? cache : data;
  }

  public static ProviderCacheItem getCachedProviderInformation(String alias){
    NotificationProviderCache cache = getCache();
    for(ProviderCacheItem dto : cache.getProviders()){
      if(dto.getAlias().equals(alias)){
        return dto;
      }
    }
    return null;
  }

  public static void putProviderCache(NotificationProviderCache providerCache) {
    getCache(Notification.PROVIDERS).put(NotificationProviderCache.CACHE_NAME, providerCache);
    cache = providerCache;
  }
}
