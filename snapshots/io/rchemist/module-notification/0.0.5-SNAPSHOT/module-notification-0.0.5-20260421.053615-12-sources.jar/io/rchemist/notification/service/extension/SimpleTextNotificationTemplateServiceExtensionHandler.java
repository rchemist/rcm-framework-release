/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.extension;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.notification.data.NotificationTemplateResult;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.data.ParseNotificationTemplateRequest;

/**
 * <p>
 * project : rcm-framework
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotificationTemplateServiceExtensionManager.BEAN_NAME, priority = Integer.MIN_VALUE)
public class SimpleTextNotificationTemplateServiceExtensionHandler implements NotificationTemplateServiceExtensionHandler{

  @Override
  public ExtensionResultStatusType generateNotificationTemplateResult(NotificationTemplateView view, ParseNotificationTemplateRequest request, ExtensionResultHolder<NotificationTemplateResult> erh) {

    if (!view.getNotificationType().isShouldParseTemplate()) {

      String title = view.getTitle();
      String content = view.getSourceCode();

      erh.setResult(new NotificationTemplateResult().withTitle(title).withContent(content).withAttributes(view.getAttributes()));

      return ExtensionResultStatusType.HANDLED_STOP;
    }

    return ExtensionResultStatusType.NOT_HANDLED;

  }
}
