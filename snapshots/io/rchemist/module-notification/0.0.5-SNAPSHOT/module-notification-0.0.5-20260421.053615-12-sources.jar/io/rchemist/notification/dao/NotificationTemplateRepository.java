/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.dao;

import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.notification.domain.NotificationTemplate;
import io.rchemist.notification.service.type.NotificationTemplateType;
import org.springframework.data.jpa.repository.Query;




/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NotificationTemplateRepository extends CommonSearchRepository<NotificationTemplate, Long> {

  @Query("SELECT t from NotificationTemplate t where t.externalId = :externalId")
  NotificationTemplate findByExternalId(String externalId);

  @Query("SELECT t from NotificationTemplate t where t.notificationType = :notificationType and t.notificationTemplateType = :notificationTemplateType")
  NotificationTemplate findByNotificationTypeAndTemplateType(NotificationType notificationType, NotificationTemplateType notificationTemplateType);

  @Query("SELECT t from NotificationTemplate t where t.notificationType = :notificationType and t.customAlias = :customAlias")
  NotificationTemplate findByNotificationTypeAndCustomAlias(NotificationType notificationType, String customAlias);
}
  
