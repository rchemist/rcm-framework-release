/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 *
 * @author kunner NotifyProvider 추가
 **/
@Slf4j
public abstract class AbstractNotifyProvider implements NotifyProvider {

  protected final NotifyProviderManager extensionManager;

  protected static final String DEFAULT_SUCCESS_RESULT_MESSAGE = "Message has been sent successfully";

  protected AbstractNotifyProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager, NotificationHistoryService notificationHistoryService,
      NotificationProviderService notificationProviderService) {
    this.extensionManager = extensionManager;
    this.notificationHistoryService = notificationHistoryService;
    this.notificationProviderService = notificationProviderService;
  }
  
  protected final NotificationHistoryService notificationHistoryService;
  
  protected final NotificationProviderService notificationProviderService;

  @Override
  public boolean isEnabled() {
    return true;
  }

  /**
   * 실제 발송 처리 부분
   * @param erh
   * @param provider
   * @param notificationQueue
   * @return
   */
  protected abstract ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh, NotificationProvider provider,
      NotificationQueue notificationQueue);

  @Override
  public ExtensionResultStatusType notify(ExtensionResultHolder<NotifyResult> erh, NotificationProvider provider, NotificationQueue notificationQueue) {
    if(isApplicable(provider)){
      ExtensionResultStatusType statusType = notifyProcess(erh, provider, notificationQueue);

      // 결과 저장
      NotifyResult result = erh.getResult();
      notificationHistoryService.createHistory(notificationQueue, getProviderAlias(), result.isResult(), result.getMessage());

      return statusType;

    }
    return ExtensionResultStatusType.NOT_HANDLED;
  }

  protected boolean isApplicable(NotificationProvider provider){
    // provider 가 특정된 경우
    if(provider == null){
      log.warn("There is no notification provider.");
      return false;
    }
    // 정확히 일치하는 provider 만 대상으로 한다.
    return provider.isActive() && provider.getNotificationType().equals(getNotificationType())
        && StringUtils.equals(EnumTypeUtil.getType(provider.getNotificationProviderType()), getProviderAlias());
  }

  protected Map<String, String> getProviderAttributes(NotificationProvider provider) {
    Map<String, String> properties;
    try {
      properties = notificationProviderService.getNotificationProviderAttributes(provider.getId());
    } catch (NotificationProviderServiceException e) {
      throw new RuntimeException(e.getMessage(), e);
    }
    return properties;
  }
  

}
