/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.data.NotificationProviderView;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationProviderServiceHelper {

  private static NotificationProviderService service;
  
  private static NotificationProviderService getService() {
  
    if (service == null) {
      service = ApplicationContextHolder.getBean(NotificationProviderService.class);
    }
    
    return service;
  }
  
  public static NotificationProvider findEntityById(Long id) throws NotificationProviderServiceException {
    return getService().findEntityById(id);
  }
  
  public static NotificationProviderView findViewById(Long id) throws NotificationProviderServiceException {
    return getService().findViewById(id);
  }
  
  public static List<NotificationProvider> findAllById(List<Long> ids) {
    return getService().findAllById(ids);
  }


  public static NotificationProvider findNotificationProviderByAlias(String tenantAlias, String alias) {
    return getService().findNotificationProviderByAlias(tenantAlias, alias);
  }

  public static List<NotificationProvider> getNotificationProviderByTenantAliasAndNotificationType(String tenantAlias, NotificationType notificationType) {
    return getService().getNotificationProviderByTenantAliasAndNotificationType(tenantAlias, notificationType);
  }
}
