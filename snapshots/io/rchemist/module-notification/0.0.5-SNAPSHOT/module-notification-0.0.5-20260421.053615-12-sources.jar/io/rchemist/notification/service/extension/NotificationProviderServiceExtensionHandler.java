/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.extension;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.extension.ExtensionHandler;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.HibernateSearchContext;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.data.NotificationProviderCreateForm;
import io.rchemist.notification.data.NotificationProviderUpdateForm;
import io.rchemist.notification.data.NotificationProviderView;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NotificationProviderServiceExtensionHandler extends ExtensionHandler {

    /**
    * Entity 를 새로 생성하기 전 CreateForm 을 Validation 하거나 CreateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preCreate(ExtensionResultHolder<NotificationProviderCreateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 새로 생성한 직후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postCreate(NotificationProviderCreateForm createForm, ExtensionResultHolder<NotificationProvider> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 Update 하기 전 UpdateForm 을 Validation 하거나 UpdateForm 의 값을 재조정하는 확장 로직
    * @return
    */
    default ExtensionResultStatusType preUpdate(NotificationProvider entity, ExtensionResultHolder<NotificationProviderUpdateForm> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 수정한 후 확장 로직
    * @return
    */
    default ExtensionResultStatusType postUpdate(NotificationProviderUpdateForm updateForm, ExtensionResultHolder<NotificationProvider> resultHolder) throws ErrorTypeException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    default ExtensionResultStatusType preView(NotificationProvider entity, EntityViewType viewType, ExtensionResultHolder<NotificationProviderView> resultHolder) throws NotificationProviderServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 를 View 로 변환할 때 확장 로직
    * @return
    */
    default ExtensionResultStatusType postView(NotificationProvider entity, EntityViewType viewType, ExtensionResultHolder<NotificationProviderView> resultHolder) throws NotificationProviderServiceException {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
    * Entity 의 목록을 조회할 때 SearchContext 를 확장하는 로직
    * @return
    */
    default ExtensionResultStatusType overrideSearchContext(SearchForm searchForm, ExtensionResultHolder<SearchContext<NotificationProvider, SearchForm>> resultHolder) {
      return ExtensionResultStatusType.NOT_HANDLED;
    }
    
    /**
   * Entity 의 목록을 조회할 때 HibernateSearchContext 를 확장하는 로직
   * @return
   */
  default ExtensionResultStatusType overrideHibernateSearchContext(SearchForm searchForm, ExtensionResultHolder<HibernateSearchContext<NotificationProvider, SearchForm>> resultHolder) {
    return ExtensionResultStatusType.NOT_HANDLED;
  }

}
