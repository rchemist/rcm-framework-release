/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.configuration;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.configuration.CommonSettings;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Setter
@Getter
@Component("rcmNotificationSettings")
public class NotificationSettings {

  private static NotificationSettings eventSettings;

  /**
   * 기본 사이트 이름 - Message provider 에서 사용한다.
   */
  @Value("${platform.config.event.message.site-name:}")
  protected String messageSiteName;

  public String getMessageSiteName() {
    return StringUtils.defaultIfBlank(messageSiteName, CommonSettings.getCommonSettings().getSiteName());
  }

  public static NotificationSettings getSetting(){
    if(eventSettings == null){
      eventSettings = ApplicationContextHolder.getBean(NotificationSettings.class);
    }
    return eventSettings;
  }
  
}
