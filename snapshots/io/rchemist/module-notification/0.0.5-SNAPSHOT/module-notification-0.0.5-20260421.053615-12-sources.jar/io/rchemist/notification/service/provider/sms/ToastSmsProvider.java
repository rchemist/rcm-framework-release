/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.sms;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.StringUtil;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kong.unirest.core.HttpResponse;
import kong.unirest.core.JsonNode;
import kong.unirest.core.Unirest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 300)
@Slf4j
public class ToastSmsProvider extends AbstractNotifyProvider {

  private Gson gson = new Gson();
  private PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
  private String region = Locale.getDefault().getCountry();

  private static final String PROVIDER_NAME = "ToastSms";
  private static final String PROVIDER_ALIAS = "TOASTSMS";
  private static final String POST_URL = "https://api-sms.cloud.toast.com//sms/v3.0/appKeys/";
  private static final String POST_URL_POSTFIX_SMS = "/sender/sms";
  private static final String POST_URL_POSTFIX_MMS = "/sender/mms";

  public ToastSmsProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  public static class ToastSmsBody implements Serializable{
    protected String title;
    protected String body;
    protected String sendNo;
    protected List<SmsReceiver> recipientList = new ArrayList<>();

    public ToastSmsBody withTitle(String title) {
      this.title = title;
      return this;
    }

    public ToastSmsBody withBody(String body) {
      this.body = body;
      return this;
    }

    public ToastSmsBody withSendNo(String sendNo) {
      this.sendNo = sendNo;
      return this;
    }

    public ToastSmsBody withRecipientList(
        List<SmsReceiver> recipientList) {
      this.recipientList = recipientList;
      return this;
    }

    public ToastSmsBody addRecipient(SmsReceiver... receivers){
      this.recipientList.addAll(Arrays.asList(receivers));
      return this;
    }

  }


  public static class SmsReceiver implements Serializable{

    public SmsReceiver(String internationalRecipientNo) {
      this.internationalRecipientNo = internationalRecipientNo;
    }

    public SmsReceiver(String countryCode, String recipientNo) {
      this.countryCode = countryCode;
      this.recipientNo = recipientNo;
    }

    protected String countryCode;
    protected String recipientNo;
    protected String internationalRecipientNo;

  }


  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh,
      NotificationProvider provider, NotificationQueue notificationQueue) {

    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try {

      Map<String, String> headers = new HashMap<>();
      headers.put("Content-Type", "application/json;charset=UTF-8");
      headers.put("X-Secret-Key", provider.getApiSecret());

      ToastSmsBody body = new ToastSmsBody()
          .withBody(notificationQueue.getContent())
          .withSendNo(notificationQueue.getSenderAddress())
          ;

      int contentLength = notificationQueue.getContent().getBytes(
          StandardCharsets.UTF_8).length;
      boolean mms = contentLength > 90;
      String url = getPostUrl(provider.getApiKey(), mms);

      if(mms){
        String title = notificationQueue.getTitle();
        if(title.getBytes(StandardCharsets.UTF_8).length > 40){
          title = StringUtil.trimBytes(title, 40);
        }
        body.withTitle(title);
      }

      for(TargetDTO to : notificationQueue.getToList()){
        String number = to.getAddress();

        PhoneNumber phone = phoneNumberUtil.parse(number, region);

        int country = phone.getCountryCode();
        long phoneNumber = phone.getNationalNumber();

        body.addRecipient(new SmsReceiver(String.valueOf(country), String.valueOf(phoneNumber)));

      }

      JsonElement jsonElement = gson.toJsonTree(body);

      HttpResponse<JsonNode> request = Unirest.post(url)
          .headers(headers)
          .body(jsonElement).asJson();

      result = request.isSuccess();
      resultMessage = request.getStatusText();

    }catch (Exception e){
      e.printStackTrace();
      resultMessage = e.getMessage();
    }finally {
      erh.setResult(new NotifyResult(result, resultMessage));

      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

    }

  }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return null;
  }

  @Override
  public NotificationType getNotificationType() {
    return NotificationType.SMS;
  }

  protected String getPostUrl(String apiKey, boolean mms){
    if(mms){
      return POST_URL + apiKey + POST_URL_POSTFIX_MMS;
    }else{
      return POST_URL + apiKey + POST_URL_POSTFIX_SMS;
    }
  }

}

