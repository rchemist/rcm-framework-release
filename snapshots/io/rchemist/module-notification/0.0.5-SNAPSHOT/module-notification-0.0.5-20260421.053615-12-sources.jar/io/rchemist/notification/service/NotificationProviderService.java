/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.dao.NotificationProviderRepository;
import io.rchemist.notification.data.NotificationProviderCreateForm;
import io.rchemist.notification.data.NotificationProviderUpdateForm;
import io.rchemist.notification.data.NotificationProviderView;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.exception.NotificationProviderServiceErrorType;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;
import io.rchemist.notification.service.extension.NotificationProviderServiceExtensionManager;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;
import javax.cache.Cache;
import lombok.Getter;
import org.springframework.stereotype.Service;



/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmNotificationProviderService")
public class NotificationProviderService implements ResponseEntityListService<NotificationProvider, NotificationProviderView, NotificationProviderCreateForm, NotificationProviderUpdateForm, SearchForm, Long, NotificationProviderServiceException> {

  @Getter
  protected final Cache<String, NotificationProviderView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  protected final NotificationProviderRepository repository;
  
  protected final NotificationProviderServiceExtensionManager extensionManager;

  public NotificationProviderService(NotificationProviderRepository repository, CommonCacheManager cacheManager, NotificationProviderServiceExtensionManager extensionManager) {
    this.repository = repository;
    this.entityCache = cacheManager.getOrCreateCache("NotificationProvider_entity_cache", 60 * 60 * 24, 1000, NotificationProviderView.class);
    this.searchResultCache = cacheManager.getOrCreateCache("NotificationProvider_search_list_cache", 60 * 60, 100, ResponseListWrapperCache.class);
    this.extensionManager = extensionManager;
  }

  @Override
  public CommonSearchRepository<NotificationProvider, Long> getRepository() {
    return repository;
  }

  @Override
  public NotificationProviderServiceException entityNotFoundException() {
    return new NotificationProviderServiceException(NotificationProviderServiceErrorType.NOT_FOUND);
  }

  @Override
  public NotificationProvider createEntity(NotificationProviderCreateForm createForm) throws NotificationProviderServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<NotificationProviderCreateForm> resultHolder = new ExtensionResultHolder<NotificationProviderCreateForm>().withResult(createForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preCreate(resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        createForm = resultHolder.getResult();
      }
    
      NotificationProvider entity = NotificationProvider.create(createForm);
      
      ExtensionResultHolder<NotificationProvider> postResultHolder = new ExtensionResultHolder<NotificationProvider>().withResult(entity);
      status = extensionManager.getProxy().postCreate(createForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
      
    } catch (Exception e) {
      throw new NotificationProviderServiceException(e);
    }
  }

  @Override
  public NotificationProvider updateEntity(NotificationProvider entity, NotificationProviderUpdateForm updateForm) throws NotificationProviderServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<NotificationProviderUpdateForm> resultHolder = new ExtensionResultHolder<NotificationProviderUpdateForm>().withResult(updateForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preUpdate(entity, resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        updateForm = resultHolder.getResult();
      }
    
      entity = entity.update(updateForm);
      
      ExtensionResultHolder<NotificationProvider> postResultHolder = new ExtensionResultHolder<NotificationProvider>().withResult(entity);
      status = extensionManager.getProxy().postUpdate(updateForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
    } catch (Exception e) {
      throw new NotificationProviderServiceException(e);
    }
  }

  @Override
  public NotificationProviderView getView(NotificationProvider entity, EntityViewType viewType) throws NotificationProviderServiceException {

    NotificationProviderView view = null;

    ExtensionResultHolder<NotificationProviderView> resultHolder = new ExtensionResultHolder<NotificationProviderView>();
    ExtensionResultStatusType status = extensionManager.getProxy().preView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    String cacheKey = getEntityCacheKey(entity.getId(), viewType);
    if (view == null) {
    
      if (null != getEntityCache()) {
        view = getEntityCache().get(cacheKey); 
      }
  
      if (null == view) {
        view = entity.view(viewType);    
      }
    }
    
    resultHolder = new ExtensionResultHolder<NotificationProviderView>().withResult(view);
    status = extensionManager.getProxy().postView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    if (null != getEntityCache()) {
      getEntityCache().put(cacheKey, view);
    }
    
    return view;
  }

  @Override
  public SearchContext<NotificationProvider, SearchForm> getSearchContext(SearchForm searchForm) {
    
    ExtensionResultHolder<SearchContext<NotificationProvider, SearchForm>> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().overrideSearchContext(searchForm, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return new CommonSearchContext<>(NotificationProvider.class, searchForm);
  }
  
  public List<NotificationProvider> findAllById(List<Long> ids) {
    return repository.findAllById(ids);
  }

  public Map<String, String> getNotificationProviderAttributes(Long id) throws NotificationProviderServiceException {
    NotificationProvider provider = findEntityById(id);
    return provider.getSimpleAttributes();
  }

  public NotificationProvider findNotificationProviderByAlias(String tenantAlias, String alias) {
    return repository.findNotificationProviderByAlias(tenantAlias, alias);
  }

  public List<NotificationProvider> getNotificationProviderByTenantAliasAndNotificationType(String tenantAlias, NotificationType notificationType) {
    return repository.getNotificationProviderByTenantAliasAndNotificationType(tenantAlias, notificationType);
  }
}
