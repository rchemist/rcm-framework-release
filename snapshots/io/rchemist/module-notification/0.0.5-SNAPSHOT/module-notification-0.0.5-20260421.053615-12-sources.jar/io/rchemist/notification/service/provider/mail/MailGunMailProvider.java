/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.mail;


import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import java.util.Map;
import kong.unirest.core.HttpResponse;
import kong.unirest.core.JsonNode;
import kong.unirest.core.MultipartBody;
import kong.unirest.core.Unirest;
import kong.unirest.core.UnirestException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * Created by hongin
 *
 * @author kunner NotifyProvider 추가
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 100000)
@Slf4j
public class MailGunMailProvider extends AbstractNotifyProvider {

  private static final String PROVIDER_NAME = "Mailgun";
  private static final String PROVIDER_ALIAS = "MAILGUN";
  private static final String[] ATTRIBUTES = ArrayUtil.make("baseUrl");

  public MailGunMailProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  /**
   * Mailgun 발송,
   *
   * @param provider
   * @param notificationQueue
   * @return
   */
  private HttpResponse<JsonNode> sendMailgun(NotificationProvider provider, NotificationQueue notificationQueue) throws UnirestException {

    Map<String, String> properties = getProviderAttributes(provider);
    if(!properties.containsKey("baseUrl")){
      log.warn("There is no baseUrl value. Please confirm your mailgun provider setting");
    }

    String senderAddress = StringUtil.toString(notificationQueue.getSenderNameAddress(), provider.getSenderNameAddress());

    int loop = 0;
    HttpResponse<JsonNode> request = null;
    for(TargetDTO target : notificationQueue.getToList()){
      MultipartBody multipartbody = Unirest.post(properties.get("baseUrl") + "/messages")
          .basicAuth("api", provider.getApiKey())
          .field("from", senderAddress)
          .field("to", target.getNameAddress())
          .field("subject", notificationQueue.getTitle())
          .field("html", notificationQueue.getContent());

      if(loop == 0){
        String cc = notificationQueue.getCcListToString();
        String bcc = notificationQueue.getBccListToString();

        if (StringUtils.isNotEmpty(cc)) {
          multipartbody.field("cc", cc);
        }

        if (StringUtils.isNotEmpty(bcc)) {
          multipartbody.field("ccc", bcc);
        }

      }

      request = multipartbody.asJson();

      loop++;
    }


    return request;
  }

  @Override
  public NotificationType getNotificationType() { return NotificationType.EMAIL; }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return ATTRIBUTES;
  }

  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh, NotificationProvider provider, NotificationQueue notificationQueue) {
    // 결과
    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try {
      HttpResponse<JsonNode> response = sendMailgun(provider, notificationQueue);

      if(response == null)
        return ExtensionResultStatusType.HANDLED;

      if(response.getStatus() == 200) {
        result = true;
      } else {
        resultMessage = response.getStatusText();
      }
    } catch(Exception e) {
      resultMessage = e.getMessage();

    } finally {
      erh.setResult(new NotifyResult(result, resultMessage));

      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

    }
  }

}
