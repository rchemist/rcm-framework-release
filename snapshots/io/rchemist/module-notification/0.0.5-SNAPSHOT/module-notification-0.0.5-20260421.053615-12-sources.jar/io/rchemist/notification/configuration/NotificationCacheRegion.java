/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.configuration;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public class NotificationCacheRegion {

  public static class Notification {
    public static final String ENTITY = "notification-entity";
    public static final String PROVIDERS = "notification-providers";
    public static final String HISTORY = "notification-history";
    public static final String EMAIL = "notification-email";
    public static final String SMS = "notification-sms";
    public static final String PUSH = "notification-push";
    public static final String KAKAO = "notification-kakao";
    public static final String QUERY = "query-notification";
    public static final int MAX_ENTRIES = 10000;
    public static final int TTL = 86400;
  }

  public static class NotificationTemplateCache {
    public static final String ENTITY = "notification-template-entity";
    public static final String DATA = "notification-template-data";
    public static final String MONGO_ENTITY = "notification-template-mongo-entity";
    public static final String MONGO_DATA = "notification-template-data";
    public static final String QUERY = "notification-template-query";
    public static final int MAX_ENTRIES = 10000;
    public static final long TTL_ONE_HOUR = 60 * 60;
    public static final long TTL_ONE_DAY = 60 * 60 * 24;
  }

}
