/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.configuration;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.rchemist.notification.configuration.NotificationCacheRegion.Notification;
import io.rchemist.notification.configuration.NotificationCacheRegion.NotificationTemplateCache;
import java.time.Duration;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/

@Configuration
public class NotificationRedisCacheManager {

  public static final String CACHE_MANAGER = "rcmNotificationRedisCacheManager";

  protected final RedisConnectionFactory redisConnectionFactory;

  protected final ObjectMapper objectMapper;

  public NotificationRedisCacheManager(RedisConnectionFactory redisConnectionFactory,
      ObjectMapper objectMapper) {
    this.redisConnectionFactory = redisConnectionFactory;
    this.objectMapper = objectMapper;
  }

  @Bean(CACHE_MANAGER)
  public CacheManager redisCacheManager(){
    RedisCacheConfiguration redisCacheConfiguration = getDefaultRedisCacheConfiguration();

    RedisCacheManager redisCacheManager = RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(redisConnectionFactory)
        .transactionAware()
        .cacheDefaults(redisCacheConfiguration)
        .withCacheConfiguration(Notification.ENTITY, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Notification.ENTITY, getDefaultRedisCacheConfiguration().entryTtl(Duration.ofDays(365)))
        .withCacheConfiguration(Notification.HISTORY, getDefaultRedisCacheConfiguration().entryTtl(Duration.ofDays(7)))
        .withCacheConfiguration(Notification.EMAIL, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Notification.SMS, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Notification.PUSH, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Notification.KAKAO, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(Notification.QUERY,
            getDefaultRedisCacheConfiguration())

        .withCacheConfiguration(NotificationTemplateCache.ENTITY, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(NotificationTemplateCache.DATA, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(NotificationTemplateCache.MONGO_ENTITY, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(NotificationTemplateCache.MONGO_DATA, getDefaultRedisCacheConfiguration())
        .withCacheConfiguration(NotificationTemplateCache.QUERY, getDefaultRedisCacheConfiguration())

        .build();

    return redisCacheManager;
  }

  private RedisCacheConfiguration getDefaultRedisCacheConfiguration() {

    ObjectMapper objectMapper = this.objectMapper.copy();
    objectMapper = objectMapper.activateDefaultTyping(objectMapper.getPolymorphicTypeValidator(), ObjectMapper.DefaultTyping.NON_FINAL, JsonTypeInfo.As.PROPERTY);

    RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
        .serializeKeysWith(
            RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
        .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer(objectMapper)))
        .entryTtl(Duration.ofSeconds(Notification.TTL));
    return redisCacheConfiguration;
  }

}
