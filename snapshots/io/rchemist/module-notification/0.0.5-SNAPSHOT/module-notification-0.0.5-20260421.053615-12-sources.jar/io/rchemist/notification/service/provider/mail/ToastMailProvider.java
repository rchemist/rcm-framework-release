/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.mail;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kong.unirest.core.HttpResponse;
import kong.unirest.core.JsonNode;
import kong.unirest.core.Unirest;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 200)
@Slf4j
public class ToastMailProvider extends AbstractNotifyProvider {

  private Gson gson = new Gson();
  private static final String PROVIDER_NAME = "ToastMail";
  private static final String PROVIDER_ALIAS = "TOASTMAIL";
  private static final String POST_URL = "https://api-mail.cloud.toast.com/email/v2.0/appKeys/";
  private static final String POST_URL_POSTFIX = "/sender/mail";

  public ToastMailProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  // 토스트에서 사용하는 수신자 구분
  public enum ReceiveType{
    TO("MRT0"), CC("MRT1"), BCC("MRT2");

    @Getter
    private final String mrt;

    ReceiveType(String mrt) {
      this.mrt = mrt;
    }
  }

  public static class Receiver implements Serializable {

    public Receiver(ReceiveType receiveType, String receiveName, String receiveMailAddr) {
      this.receiveMailAddr = receiveMailAddr;
      this.receiveName = receiveName;
      this.receiveType = receiveType.getMrt();
    }

    protected String receiveMailAddr;
    protected String receiveName;
    protected String receiveType;

  }

  public static class ToastMailBody implements Serializable{
    protected String senderAddress;
    protected String senderName;
    protected String title;
    protected String body;
    protected List<Receiver> receiverList = new ArrayList<>();

    public ToastMailBody withSenderAddress(String senderAddress) {
      this.senderAddress = senderAddress;
      return this;
    }

    public ToastMailBody withSenderName(String senderName) {
      this.senderName = senderName;
      return this;
    }

    public ToastMailBody withTitle(String title) {
      this.title = title;
      return this;
    }

    public ToastMailBody withBody(String body) {
      this.body = body;
      return this;
    }

    public ToastMailBody withReceiverList(
        List<Receiver> receiverList) {
      this.receiverList = receiverList;
      return this;
    }

    public ToastMailBody addReceiver(Receiver... receivers){
      this.receiverList.addAll(Arrays.asList(receivers));
      return this;
    }

  }


  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh,
      NotificationProvider provider, NotificationQueue notificationQueue) {

    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try {
      String url = getPostUrl(provider.getApiKey());

      Map<String, String> headers = new HashMap<>();
      headers.put("Content-Type", "application/json;charset=UTF-8");
      headers.put("X-Secret-Key", provider.getApiSecret());

      ToastMailBody body = new ToastMailBody()
          .withSenderName(provider.getSenderName())
          .withSenderAddress(provider.getSenderAddress())
          .withTitle(notificationQueue.getTitle())
          .withBody(notificationQueue.getContent());

      for(TargetDTO to : CollectionUtils.emptyIfNull(notificationQueue.getToList())){
        body.addReceiver(new Receiver(ReceiveType.TO, to.getName(), to.getAddress()));
      }

      for(TargetDTO to : CollectionUtils.emptyIfNull(notificationQueue.getCcList())){
        body.addReceiver(new Receiver(ReceiveType.CC, to.getName(), to.getAddress()));
      }

      for(TargetDTO to : CollectionUtils.emptyIfNull(notificationQueue.getBccList())){
        body.addReceiver(new Receiver(ReceiveType.BCC, to.getName(), to.getAddress()));
      }


      JsonElement jsonElement = gson.toJsonTree(body);

      HttpResponse<JsonNode> request = Unirest.post(url)
          .headers(headers)
          .body(jsonElement).asJson();

      result = request.isSuccess();
      resultMessage = request.getStatusText();

    }catch (Exception e){
      e.printStackTrace();
      resultMessage = e.getMessage();
    }finally {
      erh.setResult(new NotifyResult(result, resultMessage));

      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

    }

  }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return null;
  }

  @Override
  public NotificationType getNotificationType() {
    return NotificationType.EMAIL;
  }

  protected String getPostUrl(String apiKey){
    return POST_URL + apiKey + POST_URL_POSTFIX;
  }

}

