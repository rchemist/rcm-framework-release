/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.extension;

import io.rchemist.common.extension.ExtensionManager;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Project : Rchemist Platform
 * <p>
 * Created by kunner
 **/
@Service(NotificationHistoryServiceExtensionManager.BEAN_NAME)
public class NotificationHistoryServiceExtensionManager extends ExtensionManager<NotificationHistoryServiceExtensionHandler> {
  
  public static final String BEAN_NAME = "rcmNotificationHistoryServiceExtensionManager";
  
  public NotificationHistoryServiceExtensionManager() {
    super(NotificationHistoryServiceExtensionHandler.class);
  }
  
}
