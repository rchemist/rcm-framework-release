/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.web.request.WebRequestContext;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.data.NotificationTemplateResult;
import io.rchemist.notification.data.ParseNotificationTemplateRequest;
import io.rchemist.notification.service.NotificationTemplateService;
import io.rchemist.notification.service.exception.NotificationTemplateServiceException;
import io.rchemist.notification.service.provider.NotifyAsyncProvider;
import io.rchemist.notification.service.type.NotificationTemplateType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
public class NotificationServiceHelper {

  private static NotifyAsyncProvider notifyAsyncProvider;

  private static NotifyAsyncProvider getNotifyAsyncProvider() {
    if (notifyAsyncProvider == null) {
      notifyAsyncProvider = ApplicationContextHolder.getBean(NotifyAsyncProvider.class);
    }
    return notifyAsyncProvider;
  }

  private static NotificationTemplateService notificationTemplateService;

  private static NotificationTemplateService getNotificationTemplateService() {
    if (notificationTemplateService == null) {
      notificationTemplateService = ApplicationContextHolder.getBean(NotificationTemplateService.class);
    }
    return notificationTemplateService;
  }

  public static void sendMessage(NotificationQueue queue){
    getNotifyAsyncProvider().sendAsync(queue);
  }

  public static void sendTemplateMessage(String tenantAlias, NotificationType notificationType
      , NotificationTemplateType notificationTemplateType, Map<String, Object> modelMap, TargetDTO... targets) {

    sendTemplateMessage(tenantAlias, null, notificationType, notificationTemplateType, null, modelMap, targets);

  }

  public static void sendTemplateMessage(String tenantAlias, String userId, NotificationType notificationType
      , NotificationTemplateType notificationTemplateType
      , String customAlias
      , Map<String, Object> modelMap, TargetDTO... targets) {

    ParseNotificationTemplateRequest request = new ParseNotificationTemplateRequest(tenantAlias,
        notificationType, notificationTemplateType)
        .withModelMap(modelMap)
        .withCustomAlias(customAlias);

    try {
      NotificationTemplateResult template = getNotificationTemplateService().parseNotificationTemplate(request);

      String title = template.getTitle();
      String content = template.getContent();

      NotificationQueue queue;

      if (notificationType.equals(NotificationType.SMS)) {
        List<String> addresses = new ArrayList<>();
        for (TargetDTO target : targets) {
          addresses.add(target.getAddress());
        }
        queue = NotificationQueue.createMmsQueueByAdmin(tenantAlias, title, content,
            addresses.toArray(new String[0]));
      } else {
        queue = new NotificationQueue(tenantAlias, notificationType, title, content, targets);
      }

      Map<String, String> attributes = modifyTemplateAttributes(modelMap, template);

      queue.withNotificationTemplateType(notificationTemplateType)
          .withMessageKey(template.getAttributes().get("messageKey"))
          .withUserId(userId)
          .withModelMap(modelMap)
          .withAttributes(attributes);

      sendMessage(queue);

    } catch (NotificationTemplateServiceException e) {
      log.error("Failed to send a message to the queue", e);
    }


  }

  /**
   * 반드시 들어가야 할 attributes 정보
   * @param modelMap
   * @param template
   * @return
   */
  private static Map<String, String> modifyTemplateAttributes(Map<String, Object> modelMap,
      NotificationTemplateResult template) {
    Map<String, String> attributes = template.getAttributes();

    if(modelMap.containsKey("user")){
      if(!attributes.containsKey("loginName")){
        attributes.put("loginName", WebRequestContext.getSimpleAuthentication().getLoginName());
      }

      if(!attributes.containsKey("userName")){
        attributes.put("userName", WebRequestContext.getSimpleAuthentication().getUserName());
      }
    }
    return attributes;
  }

}
