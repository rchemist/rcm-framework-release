/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class KakaoMessageRequest implements Serializable {

  public KakaoMessageRequest(String senderKey, String templateCode) {
    this.senderKey = senderKey;
    this.templateCode = templateCode;
  }

  protected String senderKey;
  protected String templateCode;

  protected List<Recipient> recipientList = new ArrayList<>();

  public KakaoMessageRequest addRecipient(String recipientNo, Map<String, String> templateParameters){
    this.recipientList.add(new Recipient(recipientNo, templateParameters));
    return this;
  }

  public KakaoMessageRequest addRecipient(Recipient... recipients){
    for(Recipient recipient : recipients){
      this.recipientList.add(recipient);
    }
    return this;
  }


}
