/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.mail;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.amazonaws.services.simpleemail.model.SendEmailResult;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.exception.NotifyServiceErrorType;
import io.rchemist.notification.service.exception.NotifyServiceException;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 80000)
public class AwsSesMailProvider extends AbstractNotifyProvider {

  private static final String PROVIDER_ALIAS = "AWS_SES";
  private static final String PROVIDER_NAME = "AmazonSES";

  protected AmazonSimpleEmailService amazonSimpleEmailService;

  public AwsSesMailProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  protected AmazonSimpleEmailService getAmazonSimpleEmailService(NotificationProvider provider)
      throws NotifyServiceException {
    if(amazonSimpleEmailService == null){

      String accessKey = provider.getApiKey();
      String secretKey = provider.getApiSecret();
      String region = provider.getSimpleAttributeValue("region");

      if(StringUtil.isBlankAtLeastOne(accessKey, secretKey, region))
        throw new NotifyServiceException(NotifyServiceErrorType.AWS_SES_SETTING_ERROR);

      final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
      final AWSStaticCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);

      return AmazonSimpleEmailServiceClientBuilder.standard()
          .withCredentials(credentialsProvider)
          .withRegion(region)
          .build();

    }
    return amazonSimpleEmailService;
  }

  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh,
      NotificationProvider provider, NotificationQueue notificationQueue) {

    try {
      AmazonSimpleEmailService service = getAmazonSimpleEmailService(provider);

      if(service != null){

        SendEmailRequest request = create(notificationQueue);

        SendEmailResult sendMailResult = service.sendEmail(request);

        int resultCode = sendMailResult.getSdkHttpMetadata().getHttpStatusCode();

        String resultMessage;

        boolean success = resultCode == 200;

        if(success){
          resultMessage = String.valueOf(resultCode);
        }else{
          resultMessage = sendMailResult.getSdkHttpMetadata().toString();
        }

        NotifyResult result = new NotifyResult(success, resultMessage);
        erh.setResult(result);

        return (success) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

      }

    } catch (NotifyServiceException e) {
      e.printStackTrace();
    }

    return ExtensionResultStatusType.NOT_HANDLED;
  }

  protected SendEmailRequest create(NotificationQueue queue){

    final Destination destination = new Destination()
        .withToAddresses(queue.collectToList())
        .withCcAddresses(queue.collectCcList())
        .withBccAddresses(queue.collectBccList());

    final Message message = new Message()
        .withSubject(createContent(queue.getTitle()))
        .withBody(new Body()
            .withHtml(createContent(queue.getContent())));

    return new SendEmailRequest()
        .withSource(queue.getSenderNameAddress())
        .withDestination(destination)
        .withMessage(message);
  }


  protected Content createContent(final String text){
    return new Content()
        .withCharset("UTF-8")
        .withData(text);
  }



  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return ArrayUtil.make("region");
  }

  @Override
  public NotificationType getNotificationType() {
    return NotificationType.EMAIL;
  }
}
