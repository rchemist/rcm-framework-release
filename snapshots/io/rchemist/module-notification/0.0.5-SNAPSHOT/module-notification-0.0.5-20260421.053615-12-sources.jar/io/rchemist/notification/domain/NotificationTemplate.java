/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.domain;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.annotation.Text;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.ExternalId;
import io.rchemist.common.persistence.jpa.domain.template.NameDescription;
import io.rchemist.common.persistence.jpa.domain.template.SimpleAttributes;
import io.rchemist.common.persistence.jpa.domain.template.TagsMapping;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.search.bridge.NotificationTypeValueBridge;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.data.NotificationTemplateCreateForm;
import io.rchemist.notification.data.NotificationTemplateUpdateForm;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.service.exception.NotificationTemplateServiceErrorType;
import io.rchemist.notification.service.exception.NotificationTemplateServiceException;
import io.rchemist.notification.service.helper.NotificationTemplateServiceHelper;
import io.rchemist.notification.service.search.NotificationTemplateTypeValueBridge;
import io.rchemist.notification.service.type.NotificationTemplateType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serial;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.bridge.mapping.annotation.ValueBridgeRef;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Entity
@Table(name = "T_NOTIFICATION_TEMPLATE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "ENTITY_NOTIFICATION_TEMPLATE")
@Getter
@Setter
@Indexed
@Description(name = "알림 템플릿", comment = "알림 템플릿 정보. 알림이 발송될 때 사용하는 템플릿 정보.")
public class NotificationTemplate implements EssentialEntity<NotificationTemplate>, ExternalId<NotificationTemplate>, NameDescription<NotificationTemplate>, SimpleAttributes<NotificationTemplate>,
    TenantAlias<NotificationTemplate>, TagsMapping<NotificationTemplate> {

  @Serial
  private static final long serialVersionUID = 1L;

  @Id
  @IdGenerator
  protected Long id;


  @Column(name = "TITLE")
  @Description(name = "제목", comment = "제목")
  protected String title;

  @Column(name = "SOURCE_CODE")
  @Text
  @Description(name = "템플릿 내용", comment = "템플릿 내용. 기본적으로 Thymeleaf Code 를 지원한다.")
  protected String sourceCode;

  @Column(name = "CUSTOM_ALIAS")
  @IndexField
  @KeywordField
  @Description(name = "사용자 정의 발송 시점", comment = "메시지 발송 시점이 사용자정의 타입인 경우, 사용자 정의 발송 시점을 식별할 수 있는 Alias 를 영문, 숫자로 입력해 주세요")
  protected String customAlias;

  @Column(name = "NOTIFICATION_TEMPLATE_TYPE")
  @IndexField
  @KeywordField(valueBridge = @ValueBridgeRef(type = NotificationTemplateTypeValueBridge.class))
  @Description(name = "메세지 발송 시점", comment = "해당 템플릿을 사용할 시점. 메시지를 발송할 때, 지정한 메시지 유형과 메시지 발송 시점에 따라 메시지를 발송할 템플릿이 결정된다.")
  protected NotificationTemplateType notificationTemplateType;

  @Column(name = "NOTIFICATION_TYPE")
  @IndexField
  @KeywordField(valueBridge = @ValueBridgeRef(type = NotificationTypeValueBridge.class))
  @Description(name = "메시지 유형", comment = "메시지 유형. EMAIL, SMS, KAKAO 등과 어떤 유형으로 메시지를 보냈는지에 대한 정보. NotificationType 참고")
  protected NotificationType notificationType;


  /**
   * Form을 이용해 NotificationTemplate 엔티티를 생성한다. 이 결과로 실제 DB에 저장된 것은 아니며 Entity Object 가 생성된 상태.
   *
   * @param form 업데이트 폼
   * @return 생성된 NotificationTemplate 엔티티
   */
  public static NotificationTemplate create(NotificationTemplateCreateForm form) throws ErrorTypeException {
    form.validate();

    if (StringUtils.isNotEmpty(form.getExternalId())) {
      NotificationTemplate template = NotificationTemplateServiceHelper.findByExternalId(form.getExternalId());
      if (template != null) {
        throw new NotificationTemplateServiceException("externalId", NotificationTemplateServiceErrorType.DUPLICATED_NAME);
      }
    }

    // 동일한 유형의 템플릿이 등록되어 있는지 확인한다.
    if (form.getNotificationTemplateType().equals(NotificationTemplateType.CUSTOM)) {
      // 동일한 타입 + 사용자정의 템플릿 alias 로 이미 등록된 템플릿이 있다면 에러
      NotificationTemplate template = NotificationTemplateServiceHelper.findByNotificationTypeAndCustomAlias(form.getNotificationType(), form.getCustomAlias());
      if (template != null)
        throw new NotificationTemplateServiceException("notificationType", NotificationTemplateServiceErrorType.DUPLICATED_TYPE);
    } else {
      // 동일한 타입 + 템플릿 타입으로 이미 등록된 템플릿이 있다면 에러
      NotificationTemplate template = NotificationTemplateServiceHelper.findByNotificationTypeAndTemplateType(form.getNotificationType(), form.getNotificationTemplateType());
      if (template != null)
        throw new NotificationTemplateServiceException("notificationType", NotificationTemplateServiceErrorType.DUPLICATED_TYPE);
    }

    NotificationTemplate entity = new NotificationTemplate();
    entity.setExternalId(form.getExternalId());
    entity.setName(form.getName());
    entity.setDescription(form.getDescription());
    entity.setTenantAlias(TenantHelper.getTenantAliasFromWebRequestContext());
    entity.setTitle(form.getTitle());
    entity.setSourceCode(form.getSourceCode());
    entity.setCustomAlias(form.getCustomAlias());
    entity.setNotificationTemplateType(form.getNotificationTemplateType());
    entity.setNotificationType(form.getNotificationType());
    entity.setTags(form.getTags());
    return entity;
  }

  /**
   * Form을 이용해 NotificationTemplate 엔티티를 업데이트한다.
   *
   * @param form 업데이트 폼
   * @return 업데이트된 NotificationTemplate 엔티티
   */
  public NotificationTemplate update(NotificationTemplateUpdateForm form) throws ErrorTypeException {
    form.validate();
    if (form.isUpdateTargetField("externalId")) {
      if (StringUtils.isNotEmpty(form.getExternalId())) {
        NotificationTemplate template = NotificationTemplateServiceHelper.findByExternalId(form.getExternalId());
        if (template != null && !template.getId().equals(getId())) {
          throw new NotificationTemplateServiceException("externalId", NotificationTemplateServiceErrorType.DUPLICATED_NAME);
        }
      }
      this.setExternalId(form.getExternalId());
    }
    if (form.isUpdateTargetField("name")) {
      this.setName(form.getName());
    }
    if (form.isUpdateTargetField("description")) {
      this.setDescription(form.getDescription());
    }
    if (form.isUpdateTargetField("title")) {
      this.setTitle(form.getTitle());
    }
    if (form.isUpdateTargetField("sourceCode")) {
      this.setSourceCode(form.getSourceCode());
    }
    if (form.isUpdateTargetField("customAlias")) {
      if (getNotificationTemplateType().equals(NotificationTemplateType.CUSTOM)) {
        // 템플릿 유형이 CUSTOM 일 때만 customAlias 를 설정한다.

        // 이미 등록된 alias 인지 확인한다.
        NotificationTemplate template = NotificationTemplateServiceHelper.findByNotificationTypeAndCustomAlias(form.getNotificationType(), form.getCustomAlias());
        if (template != null && !template.getId().equals(getId()))
          throw new NotificationTemplateServiceException("notificationType", NotificationTemplateServiceErrorType.DUPLICATED_TYPE);

        this.setCustomAlias(form.getCustomAlias());
      } else {
        this.setCustomAlias(null);
      }
    }

    if (form.isUpdateTargetField("tags")) {
      this.setTags(form.getTags());
    }

    return this;
  }

  /**
   * NotificationTemplate 엔티티를 조회용 DTO로 변환한다.
   *
   * @return NotificationTemplate의 조회용 DTO
   */
  public NotificationTemplateView view(EntityViewType viewType) throws NotificationTemplateServiceException {
    NotificationTemplateView view = new NotificationTemplateView();
    view.setId(this.getId());

    view.setCreatedBy(this.getCreatedBy());
    view.setCreatedAt(this.getCreatedAt());
    view.setUpdatedBy(this.getUpdatedBy());
    view.setUpdatedAt(this.getUpdatedAt());
    view.setExternalId(this.getExternalId());
    view.setName(this.getName());
    view.setDescription(this.getDescription());
    view.setTenantAlias(this.getTenantAlias());
    view.setTitle(this.getTitle());
    view.setAttributes(this.getSimpleAttributes());
    view.setSourceCode(this.getSourceCode());
    view.setCustomAlias(this.getCustomAlias());
    view.setNotificationTemplateType(this.getNotificationTemplateType());
    view.setNotificationType(this.getNotificationType());
    view.setTags(this.getTags());

    return view;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }

    NotificationTemplate that = (NotificationTemplate) o;

    return new EqualsBuilder()
        .append(getCreatedBy(), that.getCreatedBy())
        .append(getCreatedAt(), that.getCreatedAt())
        .append(getUpdatedBy(), that.getUpdatedBy())
        .append(getUpdatedAt(), that.getUpdatedAt())
        .append(getExternalId(), that.getExternalId())
        .append(getName(), that.getName())
        .append(getDescription(), that.getDescription())
        .append(getSimpleAttributes(), that.getSimpleAttributes())
        .append(getTenantAlias(), that.getTenantAlias())
        .append(getTitle(), that.getTitle())
        .append(getSourceCode(), that.getSourceCode())
        .append(getCustomAlias(), that.getCustomAlias())
        .append(getNotificationTemplateType(), that.getNotificationTemplateType())
        .append(getNotificationType(), that.getNotificationType())
        .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
        .append(getId())
        .append(getCreatedBy())
        .append(getCreatedAt())
        .append(getUpdatedBy())
        .append(getUpdatedAt())
        .append(getExternalId())
        .append(getName())
        .append(getDescription())
        .append(getSimpleAttributes())
        .append(getTenantAlias())
        .append(getTitle())
        .append(getSourceCode())
        .append(getCustomAlias())
        .append(getNotificationTemplateType())
        .append(getNotificationType())
        .toHashCode();
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
        .append("id", getId())
        .append("createdBy", getCreatedBy())
        .append("createdAt", getCreatedAt())
        .append("updatedBy", getUpdatedBy())
        .append("updatedAt", getUpdatedAt())
        .append("externalId", getExternalId())
        .append("name", getName())
        .append("description", getDescription())
        .append("simpleAttributes", getSimpleAttributes())
        .append("tenantAlias", getTenantAlias())
        .append("title", getTitle())
        .append("sourceCode", getSourceCode())
        .append("customAlias", getCustomAlias())
        .append("notificationTemplateType", getNotificationTemplateType())
        .append("notificationType", getNotificationType())
        .toString();
  }
}