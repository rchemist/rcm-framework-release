/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.dao.NotificationTemplateRepository;
import io.rchemist.notification.data.NotificationTemplateCreateForm;
import io.rchemist.notification.data.NotificationTemplateResult;
import io.rchemist.notification.data.NotificationTemplateUpdateForm;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.data.ParseNotificationTemplateRequest;
import io.rchemist.notification.domain.NotificationTemplate;
import io.rchemist.notification.service.exception.NotificationTemplateServiceErrorType;
import io.rchemist.notification.service.exception.NotificationTemplateServiceException;
import io.rchemist.notification.service.extension.NotificationTemplateServiceExtensionManager;
import io.rchemist.notification.service.type.NotificationTemplateType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import javax.cache.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Slf4j
@Service("rcmNotificationTemplateService")
public class NotificationTemplateService implements ResponseEntityListService<NotificationTemplate, NotificationTemplateView, NotificationTemplateCreateForm, NotificationTemplateUpdateForm, SearchForm, Long, NotificationTemplateServiceException> {

  public static final String RAW_TEXT_PREFIX = "RAW_TEXT::";

  @Getter
  protected final Cache<String, NotificationTemplateView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  protected final NotificationTemplateRepository repository;
  
  protected final NotificationTemplateServiceExtensionManager extensionManager;

  public NotificationTemplateService(NotificationTemplateRepository repository, CommonCacheManager cacheManager, NotificationTemplateServiceExtensionManager extensionManager) {
    this.repository = repository;
    this.entityCache = cacheManager.getOrCreateCache("NotificationTemplate_entity_cache", 60 * 60 * 24, 1000, NotificationTemplateView.class);
    this.searchResultCache = cacheManager.getOrCreateCache("NotificationTemplate_search_list_cache", 60 * 60, 100, ResponseListWrapperCache.class);
    this.extensionManager = extensionManager;
  }

  @Override
  public CommonSearchRepository<NotificationTemplate, Long> getRepository() {
    return repository;
  }

  @Override
  public NotificationTemplateServiceException entityNotFoundException() {
    return new NotificationTemplateServiceException(NotificationTemplateServiceErrorType.NOT_FOUND);
  }

  @Override
  public NotificationTemplate createEntity(NotificationTemplateCreateForm createForm) throws NotificationTemplateServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<NotificationTemplateCreateForm> resultHolder = new ExtensionResultHolder<NotificationTemplateCreateForm>().withResult(createForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preCreate(resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        createForm = resultHolder.getResult();
      }
    
      NotificationTemplate entity = NotificationTemplate.create(createForm);
      
      ExtensionResultHolder<NotificationTemplate> postResultHolder = new ExtensionResultHolder<NotificationTemplate>().withResult(entity);
      status = extensionManager.getProxy().postCreate(createForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
      
    } catch (Exception e) {
      throw new NotificationTemplateServiceException(e);
    }
  }

  @Override
  public NotificationTemplate updateEntity(NotificationTemplate entity, NotificationTemplateUpdateForm updateForm) throws NotificationTemplateServiceException {
    // do override if needed
    try {
    
      ExtensionResultHolder<NotificationTemplateUpdateForm> resultHolder = new ExtensionResultHolder<NotificationTemplateUpdateForm>().withResult(updateForm);
      ExtensionResultStatusType status = extensionManager.getProxy().preUpdate(entity, resultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
        updateForm = resultHolder.getResult();
      }
    
      entity = entity.update(updateForm);
      
      ExtensionResultHolder<NotificationTemplate> postResultHolder = new ExtensionResultHolder<NotificationTemplate>().withResult(entity);
      status = extensionManager.getProxy().postUpdate(updateForm, postResultHolder);
      
      if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && postResultHolder.hasResult()) {
        entity = postResultHolder.getResult();
      }
      
      return entity;
    } catch (Exception e) {
      throw new NotificationTemplateServiceException(e);
    }
  }

  @Override
  public NotificationTemplateView getView(NotificationTemplate entity, EntityViewType viewType) throws NotificationTemplateServiceException {

    NotificationTemplateView view = null;

    ExtensionResultHolder<NotificationTemplateView> resultHolder = new ExtensionResultHolder<NotificationTemplateView>();
    ExtensionResultStatusType status = extensionManager.getProxy().preView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    String cacheKey = getEntityCacheKey(entity.getId(), viewType);
    if (view == null) {
    
      if (null != getEntityCache()) {
        view = getEntityCache().get(cacheKey); 
      }
  
      if (null == view) {
        view = entity.view(viewType);    
      }
    }
    
    resultHolder = new ExtensionResultHolder<NotificationTemplateView>().withResult(view);
    status = extensionManager.getProxy().postView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    if (null != getEntityCache()) {
      getEntityCache().put(cacheKey, view);
    }
    
    return view;
  }

  @Override
  public SearchContext<NotificationTemplate, SearchForm> getSearchContext(SearchForm searchForm) {
    
    ExtensionResultHolder<SearchContext<NotificationTemplate, SearchForm>> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().overrideSearchContext(searchForm, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return new CommonSearchContext<>(NotificationTemplate.class, searchForm);
  }
  
  public List<NotificationTemplate> findAllById(List<Long> ids) {
    return repository.findAllById(ids);
  }

  public NotificationTemplate findByExternalId(String externalId) {
    return repository.findByExternalId(externalId);
  }

  public NotificationTemplate findByNotificationTypeAndTemplateType(NotificationType notificationType, NotificationTemplateType notificationTemplateType) {
    return repository.findByNotificationTypeAndTemplateType(notificationType, notificationTemplateType);
  }

  public NotificationTemplate findByNotificationTypeAndCustomAlias(NotificationType notificationType, String customAlias) {
    return repository.findByNotificationTypeAndCustomAlias(notificationType, customAlias);
  }

  public NotificationTemplateResult parseNotificationTemplate(ParseNotificationTemplateRequest request) throws NotificationTemplateServiceException {
    String tenantAlias = request.getTenantAlias();
    NotificationType notificationType = request.getNotificationType();
    NotificationTemplateType notificationTemplateType = request.getNotificationTemplateType();

    NotificationTemplate template;
    if(request.getNotificationTemplateType().equals(NotificationTemplateType.CUSTOM)){
      template = findNotificationTemplateUsingCustomAlias(tenantAlias, notificationType, notificationTemplateType, request.getCustomAlias());
    }else{
      template = findNotificationTemplate(tenantAlias, notificationType, notificationTemplateType);
    }

    if (template == null)
      throw new NotificationTemplateServiceException(NotificationTemplateServiceErrorType.TEMPLATE_NOT_FOUND);

    request.withMessageKey(template.getExternalId());

    // 실제 템플릿 엔진을 이용해 템플릿을 파싱하는 로직은 각 서비스에서 핸들러로 처리한다.
    // 각 서비스가 어떤 템플릿 엔진을 쓰는지 제약하고 싶지 않기 때문이다.
    ExtensionResultHolder<NotificationTemplateResult> erh = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().generateNotificationTemplateResult(template.view(EntityViewType.DETAIL), request, erh);

    if(!status.equals(ExtensionResultStatusType.NOT_HANDLED) && erh.getResult() != null){
      return erh.getResult();
    }

    throw new NotificationTemplateServiceException(NotificationTemplateServiceErrorType.TEMPLATE_NOT_FOUND);

  }

  private NotificationTemplate findNotificationTemplate(String tenantAlias, NotificationType notificationType, NotificationTemplateType notificationTemplateType) {
    return null;
  }

  private NotificationTemplate findNotificationTemplateUsingCustomAlias(String tenantAlias, NotificationType notificationType, NotificationTemplateType notificationTemplateType, String customAlias) {
    return null;
  }
}
