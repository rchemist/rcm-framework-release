/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.kakao;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.ArrayUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import io.rchemist.notification.service.provider.data.KakaoMessageRequest;
import io.rchemist.notification.service.provider.data.Recipient;
import java.util.HashMap;
import java.util.Map;
import kong.unirest.core.HttpResponse;
import kong.unirest.core.JsonNode;
import kong.unirest.core.Unirest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 300)
@Slf4j
public class KakaoTalkProvider extends AbstractNotifyProvider {

  private static final String PROVIDER_ALIAS = "KAKAO_TALK_TOAST";
  private static final String PROVIDER_NAME = "KAKAO_TALK_TOAST";
  private static final String[] REQUIRED_ATTRIBUTES = ArrayUtil.make("resendSendNo", "senderKey");
  private static final String POST_URL = "https://api-alimtalk.cloud.toast.com/alimtalk/v2.2/appkeys/";
  private static final String POST_URL_POSTFIX = "/messages";
  public static final String TEMPLATE_PARAMETER_PREFIX = "#";
  private static final Gson gson = new Gson();

  public KakaoTalkProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh,
      NotificationProvider provider, NotificationQueue notificationQueue) {

    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try{
      String apiKey = provider.getApiKey();
      String secretKey = provider.getApiSecret();
      String senderKey = provider.getSimpleAttributeValue("senderKey");

      if(StringUtil.isBlankAtLeastOne(apiKey, secretKey)){
        logConfigPropertiesError(apiKey, secretKey);
        return ExtensionResultStatusType.NOT_HANDLED;
      }

      Map<String, String> headers = new HashMap<>();
      headers.put("Content-Type", "application/json;charset=UTF-8");
      headers.put("X-Secret-Key", secretKey);

      String url = getPostUrl(apiKey);

      Map<String, String> attributes = notificationQueue.getAttributes();

      Map<String, String> templateParameters = new HashMap<>();
      if(MapUtils.isNotEmpty(attributes)){
        for(String key : attributes.keySet()){
          if(key.startsWith(TEMPLATE_PARAMETER_PREFIX)){
            String templateKey = StringUtil.subStringAfter(key, TEMPLATE_PARAMETER_PREFIX);
            String value = attributes.get(key);
            templateParameters.put(templateKey, value);
          }
        }
      }

      KakaoMessageRequest messageRequest = new KakaoMessageRequest(senderKey, notificationQueue.getMessageKey());

      notificationQueue.getToList().forEach(t -> {
        String address = t.getAddress();
        messageRequest.addRecipient(new Recipient(address, templateParameters));
      });

      JsonElement jsonElement = gson.toJsonTree(messageRequest);

      HttpResponse<JsonNode> request = Unirest.post(url)
          .headers(headers)
          .body(jsonElement).asJson();

      result = request.isSuccess();
      resultMessage = request.getStatusText();
    }catch (Exception e){
      e.printStackTrace();
      resultMessage = e.getMessage();
    }finally {
      erh.setResult(new NotifyResult(result, resultMessage));

      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;

    }
  }

  private void logConfigPropertiesError(String accessKey, String secretKey) {
    log.warn("There is an error in the configuration information.");
    log.warn("###############################");
    log.warn("accessKey:" + accessKey);
    log.warn("secretKey:" + secretKey);
    log.warn("###############################");
  }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return REQUIRED_ATTRIBUTES;
  }

  @Override
  public NotificationType getNotificationType() {
    return NotificationType.KAKAO;
  }

  protected String getPostUrl(String apiKey){
    return POST_URL + apiKey + POST_URL_POSTFIX;
  }

}
