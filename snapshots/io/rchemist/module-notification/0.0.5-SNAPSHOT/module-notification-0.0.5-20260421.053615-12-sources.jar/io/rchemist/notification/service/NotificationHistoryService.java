/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service;

import io.rchemist.common.cache.CommonCacheManager;
import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.search.data.CommonSearchContext;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.common.search.data.SearchContext;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseListWrapperCache;
import io.rchemist.common.web.service.ResponseEntityListService;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.dao.NotificationHistoryRepository;
import io.rchemist.notification.data.NotificationHistoryCreateForm;
import io.rchemist.notification.data.NotificationHistoryUpdateForm;
import io.rchemist.notification.data.NotificationHistoryView;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationHistory;
import io.rchemist.notification.service.exception.NotificationHistoryServiceErrorType;
import io.rchemist.notification.service.exception.NotificationHistoryServiceException;
import io.rchemist.notification.service.extension.NotificationHistoryServiceExtensionManager;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import javax.cache.Cache;
import lombok.Getter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * <p>
 * Project : Rchemist Platform
 * <p>
 * Created by kunner
 **/
@Service("rcmNotificationHistoryService")
public class NotificationHistoryService implements ResponseEntityListService<NotificationHistory, NotificationHistoryView, NotificationHistoryCreateForm, NotificationHistoryUpdateForm, SearchForm, Long, NotificationHistoryServiceException> {

  @Getter
  protected final Cache<String, NotificationHistoryView> entityCache;

  @Getter
  protected final Cache<String, ResponseListWrapperCache> searchResultCache;

  @Getter
  @PersistenceContext
  protected EntityManager entityManager;

  protected final NotificationHistoryRepository repository;
  
  protected final NotificationHistoryServiceExtensionManager extensionManager;

  public NotificationHistoryService(NotificationHistoryRepository repository, CommonCacheManager cacheManager, NotificationHistoryServiceExtensionManager extensionManager) {
    this.repository = repository;
    this.entityCache = cacheManager.getOrCreateCache("NotificationHistory_entity_cache", 60 * 60 * 24, 1000, NotificationHistoryView.class);
    this.searchResultCache = cacheManager.getOrCreateCache("NotificationHistory_search_list_cache", 60 * 60, 100, ResponseListWrapperCache.class);
    this.extensionManager = extensionManager;
  }

  @Override
  public CommonSearchRepository<NotificationHistory, Long> getRepository() {
    return repository;
  }

  @Override
  public NotificationHistoryServiceException entityNotFoundException() {
    return new NotificationHistoryServiceException(NotificationHistoryServiceErrorType.NOT_FOUND);
  }

  @Override
  public NotificationHistory createEntity(NotificationHistoryCreateForm createForm) throws NotificationHistoryServiceException {
    throw new RuntimeException("not implemented");
  }

  @Override
  public NotificationHistory updateEntity(NotificationHistory entity, NotificationHistoryUpdateForm updateForm) throws NotificationHistoryServiceException {
    throw new RuntimeException("not implemented");
  }

  @Override
  public NotificationHistoryView getView(NotificationHistory entity, EntityViewType viewType) throws NotificationHistoryServiceException {

    NotificationHistoryView view = null;

    ExtensionResultHolder<NotificationHistoryView> resultHolder = new ExtensionResultHolder<NotificationHistoryView>();
    ExtensionResultStatusType status = extensionManager.getProxy().preView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    String cacheKey = getEntityCacheKey(entity.getId(), viewType);
    if (view == null) {
    
      if (null != getEntityCache()) {
        view = getEntityCache().get(cacheKey); 
      }
  
      if (null == view) {
        view = entity.view(viewType);    
      }
    }
    
    resultHolder = new ExtensionResultHolder<NotificationHistoryView>().withResult(view);
    status = extensionManager.getProxy().postView(entity, viewType, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      view = resultHolder.getResult();
    }
    
    if (null != getEntityCache()) {
      getEntityCache().put(cacheKey, view);
    }
    
    return view;
  }

  @Override
  public SearchContext<NotificationHistory, SearchForm> getSearchContext(SearchForm searchForm) {
    
    ExtensionResultHolder<SearchContext<NotificationHistory, SearchForm>> resultHolder = new ExtensionResultHolder<>();
    ExtensionResultStatusType status = extensionManager.getProxy().overrideSearchContext(searchForm, resultHolder);
    
    if (!status.equals(ExtensionResultStatusType.NOT_HANDLED) && resultHolder.hasResult()) {
      return resultHolder.getResult();
    }
    
    return new CommonSearchContext<>(NotificationHistory.class, searchForm);
  }
  
  public List<NotificationHistory> findAllById(List<Long> ids) {
    return repository.findAllById(ids);
  }


  @Transactional
  public void createHistory(NotificationQueue queue, String providerAlias, boolean result, String message) {
    NotificationHistory history = new NotificationHistory();
    history.addToTarget(queue.getToList());
    history.addCcTarget(queue.getCcList());
    history.addBccTarget(queue.getBccList());
    history.setNotificationType(queue.getNotificationType());
    history.setSuccess(result);
    history.setFrom(queue.getSenderNameAddress());
    history.setTitle(queue.getTitle());
    history.setContent(queue.getContent());
    history.setUserId(queue.getUserId());
    history.setProviderAlias(providerAlias);
    history.setTenantAlias(TenantHelper.getTenantAliasFromWebRequestContext());
    save(history);
  }
}
