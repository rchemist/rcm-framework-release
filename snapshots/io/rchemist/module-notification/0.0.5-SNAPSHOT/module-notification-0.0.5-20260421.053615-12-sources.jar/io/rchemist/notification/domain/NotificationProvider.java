/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.domain;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.Alias;
import io.rchemist.common.persistence.jpa.domain.template.EssentialEntity;
import io.rchemist.common.persistence.jpa.domain.template.SimpleAttributes;
import io.rchemist.common.persistence.jpa.domain.template.SoftDelete;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.search.bridge.NotificationTypeValueBridge;
import io.rchemist.common.tenant.TenantHelper;
import io.rchemist.common.util.EncryptionUtil;
import io.rchemist.common.util.EnumTypeUtil;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.data.NotificationProviderCache.ProviderCacheItem;
import io.rchemist.notification.data.NotificationProviderCreateForm;
import io.rchemist.notification.data.NotificationProviderUpdateForm;
import io.rchemist.notification.data.NotificationProviderView;
import io.rchemist.notification.service.exception.NotificationProviderServiceErrorType;
import io.rchemist.notification.service.exception.NotificationProviderServiceException;
import io.rchemist.notification.service.helper.NotificationProviderCacheHelper;
import io.rchemist.notification.service.search.NotificationProviderTypeValueBridge;
import io.rchemist.notification.service.type.NotificationProviderType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serial;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.search.mapper.pojo.bridge.mapping.annotation.ValueBridgeRef;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.KeywordField;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * </p>
 * Created by kunner
 **/

@Entity
@Table(name = "T_NOTIFICATION_PROVIDER")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "ENTITY_NOTIFICATION_PROVIDER")
@Getter
@Setter
@Indexed
@Description(name = "메시지 프로바이더", comment = "메시지 프로바이더 정보. 메시지 프로바이더는 메시지 유형에 따라 실제 메시지 처리를 하는 일을 한다. 기본으로 제공되는 프로바이더는 EMAIL 프로바이더인 SendInBlueMailProvider, MailGunMailProvider, SendInBlueMailProvider, ToastMailProvider 가 있으며, SMS 프로바이더인 ToastSmsProvider, KAKAO 프로바이더인 KakaoTalkProvider 가 있다. 구현된 프로바이더에서 사용되는 대표 발신자, 연동키, 연동비밀키 등과 같은 정보를 관리한다.")
public class NotificationProvider implements Alias<NotificationProvider>, EssentialEntity<NotificationProvider>, SimpleAttributes<NotificationProvider>, SoftDelete<NotificationProvider>,
    TenantAlias<NotificationProvider> {

  @Serial
  private static final long serialVersionUID = 1L;

  @Id
  @IdGenerator
  protected Long id;

  @IndexField
  @GenericField
  @Column(name = "PROVIDER_NAME")
  @Description(name = "이름", comment = "프로바이더 이름")
  protected String name;

  @IndexField
  @Column(name = "NOTIFICATION_PROVIDER_TYPE")
  @KeywordField(valueBridge = @ValueBridgeRef(type = NotificationProviderTypeValueBridge.class))
  @Description(name = "프로바이더 유형", comment = "프로바이더 유형")
  protected NotificationProviderType notificationProviderType;

  @IndexField
  @Column(name = "NOTIFICATION_TYPE")
  @KeywordField(valueBridge = @ValueBridgeRef(type = NotificationTypeValueBridge.class))
  @Description(name = "메시지 유형", comment = "메시지 유형. EMAIL, SMS, KAKAO 등과 어떤 유형으로 메시지를 보냈는지에 대한 정보. NotificationType 참고")
  protected NotificationType notificationType;

  @IndexField
  @Column(name = "API_KEY")
  @Description(name = "API Key", comment = "API Key")
  protected String apiKey;

  @IndexField
  @Column(name = "API_SECRET")
  @Description(name = "API Secret", comment = "API Secret, AES256 암호화되어 있음")
  protected String apiSecret;

  @IndexField
  @Column(name = "SENDER_NAME")
  @Description(name = "발신자 이름", comment = "발신자 이름")
  protected String senderName;

  @IndexField
  @Column(name = "SENDER_ADDRESS")
  @Description(name = "발신자 주소", comment = "발신자 주소")
  protected String senderAddress;


  public String getSenderNameAddress() {
    if (StringUtils.isBlank(senderName)) {
      return senderAddress;
    }
    return senderName + "<" + senderAddress + ">";
  }

  /**
   * Form을 이용해 NotificationProvider 엔티티를 생성한다. 이 결과로 실제 DB에 저장된 것은 아니며 Entity Object 가 생성된 상태.
   *
   * @param form 업데이트 폼
   * @return 생성된 NotificationProvider 엔티티
   */
  public static NotificationProvider create(NotificationProviderCreateForm form) throws ErrorTypeException {
    form.validate();

    // 다른 엔티티와 달리 alias 가 사용자정의 식별키가 아니다.
    // NotifyProviderManager 에서 NotifyProvider 를 자동 등록 하는 구조이기 때문에, 거기에 등록된 alias 가 여기서 얘기하는 alias 가 된다.
    // 따라서 관리자도구 에서는 이름을 입력하고 alias 를 입력하게 하는 것이 아니라
    // 지원할 Provider 의 SelectBox 의 property name 을 alias 라고 해야 한다.
    // NotifyProviderManager 에서 서비스가 bootstrap 되고 난 후 등록된 ProviderCacheItem 을 조회한 결과를 NotificationProvider 에 저장한다.
    ProviderCacheItem providerCache = NotificationProviderCacheHelper.getCachedProviderInformation(form.getAlias());

    if (providerCache == null)
      throw new NotificationProviderServiceException(NotificationProviderServiceErrorType.INVALID_ALIAS);

    String alias = providerCache.getAlias();
    String name = providerCache.getName();

    // 마찬가지로 NotificationType 과 NotificationProviderType 역시 Front 에서 지정하지 않는다.
    NotificationProviderType providerType = EnumTypeUtil.getEnumType(NotificationProviderType.class, alias);

    NotificationProvider entity = new NotificationProvider();
    entity.setAlias(alias);
    entity.setName(name);

    entity.setNotificationProviderType(providerType);
    entity.setNotificationType(providerType.getNotificationType());

    entity.setApiKey(form.getApiKey());
    entity.setTenantAlias(TenantHelper.getTenantAliasFromWebRequestContext());

    String apiSecret = form.getApiSecret();
    if (StringUtils.isNotEmpty(apiSecret)) {
      try {
        form.setApiSecret(EncryptionUtil.encryptAES256(apiSecret));
      } catch (Exception e) {
        form.setApiSecret(apiSecret);
      }
    }

    entity.setSenderName(form.getSenderName());
    entity.setSenderAddress(form.getSenderAddress());

    if (MapUtils.isNotEmpty(form.getAttributes())) {
      Map<String, String> values = new LinkedHashMap<>();
      for (Entry<String, String> entry : form.getAttributes().entrySet()) {
        String value = entry.getValue();
        if (StringUtil.containsAny(entry.getKey(), "password", "key", "token")) {
          try {
            value = EncryptionUtil.encryptAES256(value);
          } catch (Exception e) {
            // silent ignore
          }
        }

        values.put(entry.getKey(), value);
      }
      entity.setSimpleAttributes(values);
    }
    // 처음 등록한 다음에는 무조건 비활성화로 시작한다.
    entity.setActive(false);

    return entity;
  }

  /**
   * Form을 이용해 NotificationProvider 엔티티를 업데이트한다.
   *
   * @param form 업데이트 폼
   * @return 업데이트된 NotificationProvider 엔티티
   */
  public NotificationProvider update(NotificationProviderUpdateForm form) throws ErrorTypeException {
    form.validate();
    if (form.isUpdateTargetField("apiKey")) {
      // apiKey 를 사용하지 않는 provider 도 있을 수 있다.
      this.setApiKey(form.getApiKey());
    }
    if (form.isUpdateTargetField("apiSecret")) {
      // apiSecret 을 사용하지 않는 provider 도 있을 수 있다.
      String apiSecret = form.getApiSecret();
      if (StringUtils.isNotEmpty(apiSecret)) {
        try {
          form.setApiSecret(EncryptionUtil.encryptAES256(apiSecret));
        } catch (Exception e) {
          form.setApiSecret(apiSecret);
        }
      } else {
        form.setApiSecret(apiSecret);
      }
    }
    if (form.isUpdateTargetField("senderName")) {
      // sender 정보를 사용하지 않는 provider 도 있을 수 있다.
      this.setSenderName(form.getSenderName());
    }
    if (form.isUpdateTargetField("senderAddress")) {
      // sender 정보를 사용하지 않는 provider 도 있을 수 있다.
      this.setSenderAddress(form.getSenderAddress());
    }
    if (form.isUpdateTargetField("attributes")) {
      if (MapUtils.isNotEmpty(form.getAttributes())) {
        Map<String, String> values = new LinkedHashMap<>();
        for (Entry<String, String> entry : form.getAttributes().entrySet()) {
          String value = entry.getValue();
          if (StringUtil.containsAny(entry.getKey(), "password", "key", "token")) {
            try {
              value = EncryptionUtil.encryptAES256(value);
            } catch (Exception e) {
              // silent ignore
            }
          }

          values.put(entry.getKey(), value);
        }
        this.setSimpleAttributes(values);
      } else {
        this.setSimpleAttributes(new LinkedHashMap<>());
      }
    }

    if (form.isUpdateTargetField("active")) {
      this.setActive(form.isActive());
    }

    return this;
  }

  /**
   * NotificationProvider 엔티티를 조회용 DTO로 변환한다.
   *
   * @return NotificationProvider의 조회용 DTO
   */
  public NotificationProviderView view(EntityViewType viewType) throws NotificationProviderServiceException {
    NotificationProviderView view = new NotificationProviderView();
    view.setId(this.getId());

    view.setAlias(this.getAlias());
    view.setCreatedBy(this.getCreatedBy());
    view.setCreatedAt(this.getCreatedAt());
    view.setUpdatedBy(this.getUpdatedBy());
    view.setUpdatedAt(this.getUpdatedAt());
    view.setActive(this.getActive());
    view.setTenantAlias(this.getTenantAlias());
    view.setName(this.getName());
    view.setNotificationProviderType(this.getNotificationProviderType());
    view.setNotificationType(this.getNotificationType());
    view.setApiKey(this.getApiKey());
    view.setApiSecret(this.getApiSecret());
    view.setSenderName(this.getSenderName());
    view.setSenderAddress(this.getSenderAddress());

    return view;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }

    NotificationProvider that = (NotificationProvider) o;

    return new EqualsBuilder()
        .append(getAlias(), that.getAlias())
        .append(getCreatedBy(), that.getCreatedBy())
        .append(getCreatedAt(), that.getCreatedAt())
        .append(getUpdatedBy(), that.getUpdatedBy())
        .append(getUpdatedAt(), that.getUpdatedAt())
        .append(getSimpleAttributes(), that.getSimpleAttributes())
        .append(getActive(), that.getActive())
        .append(getTenantAlias(), that.getTenantAlias())
        .append(getName(), that.getName())
        .append(getNotificationProviderType(), that.getNotificationProviderType())
        .append(getNotificationType(), that.getNotificationType())
        .append(getApiKey(), that.getApiKey())
        .append(getApiSecret(), that.getApiSecret())
        .append(getSenderName(), that.getSenderName())
        .append(getSenderAddress(), that.getSenderAddress())
        .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
        .append(getId())
        .append(getAlias())
        .append(getCreatedBy())
        .append(getCreatedAt())
        .append(getUpdatedBy())
        .append(getUpdatedAt())
        .append(getSimpleAttributes())
        .append(getActive())
        .append(getTenantAlias())
        .append(getName())
        .append(getNotificationProviderType())
        .append(getNotificationType())
        .append(getApiKey())
        .append(getApiSecret())
        .append(getSenderName())
        .append(getSenderAddress())
        .toHashCode();
  }

  @Override
  public String toString() {
    return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
        .append("id", getId())
        .append("alias", getAlias())
        .append("createdBy", getCreatedBy())
        .append("createdAt", getCreatedAt())
        .append("updatedBy", getUpdatedBy())
        .append("updatedAt", getUpdatedAt())
        .append("simpleAttributes", getSimpleAttributes())
        .append("active", getActive())
        .append("tenantAlias", getTenantAlias())
        .append("name", getName())
        .append("notificationProviderType", getNotificationProviderType())
        .append("notificationType", getNotificationType())
        .append("apiKey", getApiKey())
        .append("apiSecret", getApiSecret())
        .append("senderName", getSenderName())
        .append("senderAddress", getSenderAddress())
        .toString();
  }
}