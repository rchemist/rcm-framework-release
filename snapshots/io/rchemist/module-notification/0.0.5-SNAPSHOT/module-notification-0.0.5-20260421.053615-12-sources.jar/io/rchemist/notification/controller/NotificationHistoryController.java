/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.controller;
  
import io.rchemist.common.documentation.RestDocument;
import io.rchemist.common.transformer.ConditionalExcludeScan;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityController;
import io.rchemist.notification.data.NotificationHistoryCreateForm;
import io.rchemist.notification.data.NotificationHistoryUpdateForm;
import io.rchemist.notification.data.NotificationHistoryView;
import io.rchemist.notification.domain.NotificationHistory;
import io.rchemist.notification.service.NotificationHistoryService;
import lombok.Getter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * <p>
 * Project : Rchemist Platform
 * <p>
 * Created by kunner
 **/
@Getter
@RestController(value = "rcmNotificationHistoryController")
@RestDocument(project = "rcm", value = "NotificationHistoryController")
@RequestMapping(NotificationHistoryController.API_URL)
@ConditionalExcludeScan(RestController.class)
public class NotificationHistoryController extends ResponseEntityController<NotificationHistory, NotificationHistoryView, NotificationHistoryCreateForm, NotificationHistoryUpdateForm, SearchForm, Long> {

  public static final String API_URL = "/api/v1/notification-history";

  protected final NotificationHistoryService service;

  public NotificationHistoryController(NotificationHistoryService service) {
    this.service = service;
  }

  @Override
  @PostMapping("/count")
  public ResponseData<Long> count(@RequestBody final SearchForm searchForm) {
    return super.count(searchForm);
  }

  @Override
  @PostMapping
  public ResponseListData<NotificationHistoryView, SearchForm> search(@RequestBody SearchForm searchForm) {
    return super.search(searchForm);
  }

  @Override
  @GetMapping("/{id}")
  public ResponseData<NotificationHistoryView> view(@PathVariable Long id) {
    return super.view(id);
  }
  
}
  