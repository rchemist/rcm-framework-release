/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider;

import io.rchemist.common.extension.ExtensionManager;
import io.rchemist.common.extension.ProxyHandlerRegistered;
import io.rchemist.notification.data.NotificationProviderCache;
import io.rchemist.notification.service.helper.NotificationProviderCacheHelper;
import io.rchemist.notification.service.type.NotificationProviderType;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Component(NotifyProviderManager.NAME)
@Slf4j
public class NotifyProviderManager extends ExtensionManager<NotifyProvider> implements ApplicationListener<ApplicationReadyEvent> {

  public static final String NAME = "rcmNotifyProviderManager";

  public NotifyProviderManager() {
    super(NotifyProvider.class);
  }

  /**
   * provider 중 하나라도 성공하면 나머지는 반드시 skip 해야 한다.
   * 안 그러면 중복 발송이 될 수 있다.
   * @return
   */
  @Override
  public boolean continueOnHandled() {
    return false;
  }

  @Override
  public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
    List<ProxyHandlerRegistered<NotifyProvider>> handlers = getRegisteredHandlers();
    if(CollectionUtils.isNotEmpty(handlers)){
      NotificationProviderCache providerCache = new NotificationProviderCache();
      for(ProxyHandlerRegistered<NotifyProvider> handler : handlers){

        int priority = handler.getPriority();

        NotifyProvider provider = handler.getHandler();

        NotificationProviderType type = NotificationProviderType.create(priority, provider.getProviderAlias(), provider.getProviderName(), provider.getNotificationType(), provider.getRequiredAttributes());
        log.debug("NotificationProviderType - " + type.getType() + " has registered.");

        providerCache.addProvider(priority, provider.getProviderName(), provider.getProviderAlias(), type);

      }
      NotificationProviderCacheHelper.putProviderCache(providerCache);
    }
  }
}
