/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.dao;

import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.search.data.CommonSearchRepository;
import io.rchemist.notification.domain.NotificationProvider;
import java.util.List;
import org.springframework.data.jpa.repository.Query;




/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
public interface NotificationProviderRepository extends CommonSearchRepository<NotificationProvider, Long> {

  @Query("select p from NotificationProvider p where p.tenantAlias = :tenantAlias and p.alias = :alias")
  NotificationProvider findNotificationProviderByAlias(String tenantAlias, String alias);

  @Query("select p from NotificationProvider p where p.tenantAlias = :tenantAlias")
  List<NotificationProvider> getNotificationProviders(String tenantAlias);

  // tenantAlias 와 관계 없이 모든 데이터를 조회하기 위해 일부러 tenantAlias 에 무의미한 조건을 설정한다.
  @Query("select p from NotificationProvider p where (p.tenantAlias is null or p.tenantAlias is not null) and p.alias = :providerAlias")
  List<NotificationProvider> getNotificationProvidersByAlias(String providerAlias);

  @Query("select p from NotificationProvider p where (p.tenantAlias is null or p.tenantAlias = :tenantAlias) and p.notificationType = :notificationType")
  List<NotificationProvider> getNotificationProviderByTenantAliasAndNotificationType(String tenantAlias, NotificationType notificationType);

}
  
