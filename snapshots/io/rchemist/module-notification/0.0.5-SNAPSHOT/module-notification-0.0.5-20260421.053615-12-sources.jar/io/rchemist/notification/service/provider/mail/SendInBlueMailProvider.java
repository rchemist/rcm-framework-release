/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.mail;

import io.rchemist.common.extension.ExtensionResultHolder;
import io.rchemist.common.extension.ExtensionResultStatusType;
import io.rchemist.common.extension.RegisterExtensionHandler;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.util.ExceptionUtil;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationQueue;
import io.rchemist.notification.domain.NotificationProvider;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.NotificationProviderService;
import io.rchemist.notification.service.provider.AbstractNotifyProvider;
import io.rchemist.notification.service.provider.NotifyProviderManager;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import sendinblue.ApiClient;
import sendinblue.ApiException;
import sibApi.TransactionalEmailsApi;
import sibModel.CreateSmtpEmail;
import sibModel.SendSmtpEmail;
import sibModel.SendSmtpEmailBcc;
import sibModel.SendSmtpEmailCc;
import sibModel.SendSmtpEmailSender;
import sibModel.SendSmtpEmailTo;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@RegisterExtensionHandler(manager = NotifyProviderManager.NAME, priority = 90000)
@Slf4j
public class SendInBlueMailProvider extends AbstractNotifyProvider {

  public static final String PROVIDER_ALIAS = "SEND_IN_BLUE";
  public static final String PROVIDER_NAME = "SendInBlue";

  public SendInBlueMailProvider(@Qualifier(value =  NotifyProviderManager.NAME) NotifyProviderManager extensionManager,
      NotificationHistoryService notificationHistoryService, NotificationProviderService notificationProviderService) {
    super(extensionManager, notificationHistoryService, notificationProviderService);
  }

  @Override
  public NotificationType getNotificationType() {
    return NotificationType.EMAIL;
  }

  @Override
  public String getProviderAlias() {
    return PROVIDER_ALIAS;
  }

  @Override
  public String getProviderName() {
    return PROVIDER_NAME;
  }

  @Override
  public String[] getRequiredAttributes() {
    return null;
  }

  @Override
  protected ExtensionResultStatusType notifyProcess(ExtensionResultHolder<NotifyResult> erh,
      NotificationProvider provider, NotificationQueue queue) {

    ApiClient client = new ApiClient();
    client.setApiKey(provider.getApiKey());
    TransactionalEmailsApi api = new TransactionalEmailsApi(client);

    String senderName = queue.getSenderName();
    String senderAddress = queue.getSenderAddress();

    if(StringUtils.isBlank(senderAddress)){
      senderName = provider.getSenderName();
      senderAddress = provider.getSenderAddress();
    }

    SendSmtpEmailSender sender = new SendSmtpEmailSender().email(senderAddress);
    if(StringUtils.isNotBlank(senderName)){
      sender.name(senderName);
    }

    // 결과
    boolean result = false;
    String resultMessage = DEFAULT_SUCCESS_RESULT_MESSAGE;

    try {

      int loop = 0;
      for (TargetDTO target : queue.getToList()) {
        SendSmtpEmailTo to = new SendSmtpEmailTo().email(target.getAddress());
        if (StringUtils.isNotEmpty(target.getName())) {
          to.setName(target.getName());
        }

        SendSmtpEmail sendSmtpEmail = new SendSmtpEmail()
            .sender(sender)
            .addToItem(to)
            .subject(queue.getTitle())
            .htmlContent(queue.getContent());

        if(loop++ == 0){
          if(CollectionUtils.isNotEmpty(queue.getCcList())){
            List<SendSmtpEmailCc> ccList = getSendSmtpEmailCcs(queue.getCcList());
            sendSmtpEmail.cc(ccList);
          }
          if(CollectionUtils.isNotEmpty(queue.getBccList())){
            List<SendSmtpEmailBcc> ccList = getSendSmtpEmailBcc(queue.getBccList());
            sendSmtpEmail.bcc(ccList);
          }
        }

        CreateSmtpEmail response = api.sendTransacEmail(sendSmtpEmail);
        log.debug("Succeed to send email via SendInBlue. Results are below.");
        log.debug(response.toString());

      }
      // BUG-048: sibling of BUG-046/047. Loop completed without ApiException
      // so every recipient received the email; previous version still
      // reported result=false and HANDLED. Mark success outside the loop.
      result = true;

    } catch (ApiException e) {
      ExceptionUtil.printStackTrace(e);
      resultMessage = e.getMessage();
    } finally {
      erh.setResult(new NotifyResult(result, resultMessage));
      return (result) ? ExtensionResultStatusType.HANDLED_STOP : ExtensionResultStatusType.HANDLED;
    }

  }

  private List<SendSmtpEmailBcc> getSendSmtpEmailBcc(List<TargetDTO> list) {
    List<SendSmtpEmailBcc> ccList = new ArrayList<>();
    for(TargetDTO targetCc : list){
      SendSmtpEmailBcc emailCc = new SendSmtpEmailBcc()
          .name(targetCc.getName())
          .email(targetCc.getAddress());
      ccList.add(emailCc);
    }
    return ccList;
  }

  private List<SendSmtpEmailCc> getSendSmtpEmailCcs(List<TargetDTO> list) {
    List<SendSmtpEmailCc> ccList = new ArrayList<>();
    for(TargetDTO targetCc : list){
      SendSmtpEmailCc emailCc = new SendSmtpEmailCc()
          .name(targetCc.getName())
          .email(targetCc.getAddress());
      ccList.add(emailCc);
    }
    return ccList;
  }
}
