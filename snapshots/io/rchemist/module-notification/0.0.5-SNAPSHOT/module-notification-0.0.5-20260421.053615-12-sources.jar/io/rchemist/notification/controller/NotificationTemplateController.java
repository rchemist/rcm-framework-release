/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.controller;

import io.rchemist.common.documentation.RestDocument;
import io.rchemist.common.transformer.ConditionalExcludeScan;
import io.rchemist.common.web.request.data.SearchForm;
import io.rchemist.common.web.response.ResponseData;
import io.rchemist.common.web.response.ResponseListData;
import io.rchemist.common.web.service.ResponseEntityController;
import io.rchemist.common.web.service.data.DeleteForm;
import io.rchemist.notification.data.NotificationTemplateCreateForm;
import io.rchemist.notification.data.NotificationTemplateUpdateForm;
import io.rchemist.notification.data.NotificationTemplateView;
import io.rchemist.notification.domain.NotificationTemplate;
import io.rchemist.notification.service.NotificationTemplateService;
import lombok.Getter;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Getter
@RestController(value = "rcmNotificationTemplateController")
@RestDocument(project = "rcm", value = "NotificationTemplateController")
@RequestMapping(NotificationTemplateController.API_URL)
@ConditionalExcludeScan(RestController.class)
public class NotificationTemplateController extends ResponseEntityController<NotificationTemplate, NotificationTemplateView, NotificationTemplateCreateForm, NotificationTemplateUpdateForm, SearchForm, Long> {

  public static final String API_URL = "/api/v1/notification-template";

  protected final NotificationTemplateService service;

  public NotificationTemplateController(NotificationTemplateService service) {
    this.service = service;
  }

  @Override
  @PostMapping("/count")
  public ResponseData<Long> count(@RequestBody final SearchForm searchForm) {
    return super.count(searchForm);
  }

  @Override
  @PostMapping
  public ResponseListData<NotificationTemplateView, SearchForm> search(@RequestBody SearchForm searchForm) {
    return super.search(searchForm);
  }

  @Override
  @PostMapping("/add")
  public ResponseData<NotificationTemplateView> create(@RequestBody NotificationTemplateCreateForm form) {
    return super.create(form);
  }

  @PutMapping("/{id}")
  public ResponseData<NotificationTemplateView> update(@PathVariable Long id, @RequestBody NotificationTemplateUpdateForm form) {
    form.setId(id);
    return super.update(form);
  }

  @Override
  @DeleteMapping("/{id}")
  public ResponseData<Boolean> delete(@PathVariable Long id, @RequestParam(required = false) String revisionEntityName) {
    return super.delete(id, revisionEntityName);
  }

  @Override
  @GetMapping("/{id}")
  public ResponseData<NotificationTemplateView> view(@PathVariable Long id) {
    return super.view(id);
  }

  @Override
  @DeleteMapping("/delete")
  public ResponseData<Integer> deleteMultiple(@RequestBody DeleteForm<Long> form) {
    return super.deleteMultiple(form);
  }
  
  
  
}
  