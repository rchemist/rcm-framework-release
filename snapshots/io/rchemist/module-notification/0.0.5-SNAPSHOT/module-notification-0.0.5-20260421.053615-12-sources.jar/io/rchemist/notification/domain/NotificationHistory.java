/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.domain;

import io.rchemist.common.exception.ErrorTypeException;
import io.rchemist.common.persistence.domain.annotation.Description;
import io.rchemist.common.persistence.domain.annotation.IdGenerator;
import io.rchemist.common.persistence.domain.type.NotificationType;
import io.rchemist.common.persistence.jpa.domain.annotation.IndexField;
import io.rchemist.common.persistence.jpa.domain.template.Contents;
import io.rchemist.common.persistence.jpa.domain.template.Historical;
import io.rchemist.common.persistence.jpa.domain.template.SimpleAttributes;
import io.rchemist.common.persistence.jpa.domain.template.TenantAlias;
import io.rchemist.common.persistence.jpa.domain.template.UserUUId;
import io.rchemist.common.util.StringUtil;
import io.rchemist.common.web.service.type.EntityViewType;
import io.rchemist.notification.TargetDTO;
import io.rchemist.notification.data.NotificationHistoryCreateForm;
import io.rchemist.notification.data.NotificationHistoryUpdateForm;
import io.rchemist.notification.data.NotificationHistoryView;
import io.rchemist.notification.service.exception.NotificationHistoryServiceException;
import io.rchemist.notification.service.type.NotificationTargetType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.io.Serial;
import java.util.ArrayList;
import java.util.List;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * <p>
 * Project : Rchemist Platform
 * </p>
 * Created by kunner
 **/

@Entity
@Table(name = "T_NOTIFICATION_HISTORY")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE, region = "ENTITY_NOTIFICATION_HISTORY")
@Getter
@Setter
public class NotificationHistory implements Historical<NotificationHistory>, UserUUId<NotificationHistory>,
    TenantAlias<NotificationHistory>, Contents<NotificationHistory>, SimpleAttributes<NotificationHistory> {

  @Serial
  private static final long serialVersionUID = 1L;

  @Id
  @IdGenerator
  protected Long id;


  @Column(name = "NOTIFICATION_TYPE")
  @IndexField
  @Description(name = "메시지 유형", comment = "메시지 유형. EMAIL, SMS, KAKAO 등과 어떤 유형으로 메시지를 보냈는지에 대한 정보. NotificationType 참고")
  protected NotificationType notificationType;

  @Column(name = "FROM_ADDRESS")
  @Description(name = "발신자 정보", comment = "발신자 정보")
  protected String from;

  @Column(name = "TARGET_TO", length = 2000)
  @Description(name = "수신자 정보", comment = "수신자 정보")
  protected String[] to;

  @Column(name = "TARGET_CC", length = 2000)
  @Description(name = "참조 정보", comment = "참조 정보")
  protected String[] cc;

  @Column(name = "TARGET_BCC", length = 2000)
  @Description(name = "숨은 참조 정보", comment = "숨은 참조 정보")
  protected String[] bcc;

  @Column(name = "FILES", length = 2000)
  @Description(name = "파일 정보", comment = "파일 정보")
  protected String[] files;

  @Column(name = "PROVIDER_ALIAS")
  @Description(name = "사용된 provider")
  protected String providerAlias;

  @Column(name = "IS_SUCCESS")
  @Description(name = "성공 여부", comment = "성공 여부")
  protected Boolean success;

  @Transient
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  protected List<TargetDTO> toList;

  @Transient
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  protected List<TargetDTO> ccList;

  @Transient
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  protected List<TargetDTO> bccList;

  private String mergeTarget(String name, String address){
    return name+"::"+address;
  }
  
  public NotificationHistory addTo(String name, String address){
    String target = mergeTarget(name, address);
    if(this.to == null){
      this.to = new String[]{target};
    }else{
      this.to = ArrayUtils.add(this.to, target);
    }
    return this;
  }

  public NotificationHistory addCc(String name, String address){
    String target = mergeTarget(name, address);
    if(this.cc == null){
      this.cc = new String[]{target};
    }else{
      this.cc = ArrayUtils.add(this.cc, target);
    }
    return this;
  }

  public NotificationHistory addBcc(String name, String address){
    String target = mergeTarget(name, address);
    if(this.bcc == null){
      this.bcc = new String[]{target};
    }else{
      this.bcc = ArrayUtils.add(this.bcc, target);
    }
    return this;
  }

  public NotificationHistory addToTarget(List<TargetDTO> dtos){
    String[] array = getTargetStringArrays(dtos);
    this.to = array;
    return this;
  }
  public NotificationHistory addCcTarget(List<TargetDTO> dtos){
    String[] array = getTargetStringArrays(dtos);
    this.cc = array;
    return this;
  }
  public NotificationHistory addBccTarget(List<TargetDTO> dtos){
    String[] array = getTargetStringArrays(dtos);
    this.bcc = array;
    return this;
  }

  private String[] getTargetStringArrays(List<TargetDTO> dtos) {
    String[] array;
    if(CollectionUtils.isNotEmpty(dtos)){
      List<String> values = new ArrayList<>();
      for(TargetDTO dto : dtos){
        String value = dto.toString();
        values.add(value);
      }
      array = values.toArray(new String[0]);
    }else{
      array = null;
    }
    return array;
  }


  public NotificationHistory addTarget(NotificationTargetType targetType, String name, String address){
    switch (targetType){
      case CC:{
        return addCc(name, address);
      }
      case BCC:{
        return addBcc(name, address);
      }
      default:{
        return addTo(name, address);
      }
    }
  }

  public List<TargetDTO> getTargetList(NotificationTargetType targetType){
    switch (targetType){
      case CC:{return getCcList();}
      case BCC:{return getBccList();}
      default: {
        return getToList();
      }
    }
  }

  public List<TargetDTO> getToList(){
    if(this.toList == null){
      if(ArrayUtils.isEmpty(this.to)){
        return new ArrayList<>();
      }else{
        List<TargetDTO> list = getTargetList(this.to);
        this.toList = list;
      }
    }
    return this.toList;
  }

  public List<TargetDTO> getCcList(){
    if(this.ccList == null){
      if(ArrayUtils.isEmpty(this.cc)){
        return new ArrayList<>();
      }else{
        List<TargetDTO> list = getTargetList(this.cc);
        this.ccList = list;
      }
    }
    return this.ccList;
  }

  public List<TargetDTO> getBccList(){
    if(this.bccList == null){
      if(ArrayUtils.isEmpty(this.bcc)){
        return new ArrayList<>();
      }else{
        List<TargetDTO> list = getTargetList(this.bcc);
        this.bccList = list;
      }
    }
    return this.bccList;
  }

  private List<TargetDTO> getTargetList(String[] array) {
    List<TargetDTO> list = new ArrayList<>();
    for(String t : array){
      List<String> targets = StringUtil.split(t, "::");
      TargetDTO dto = new TargetDTO();
      if(targets.size() == 1){
        // 주소만으로 이루어진 경우
        dto.setAddress(t);
      }else{
        // name :: address
        dto.setName(targets.get(0));
        dto.setAddress(targets.get(1));
      }
      list.add(dto);
    }
    return list;
  }


  /**
   * NotificationHistory 를 CreateForm 을 통해 처리하지 않는다.
   * @param form 업데이트 폼
   * @return 생성된 NotificationHistory 엔티티
   */
  public static NotificationHistory create(NotificationHistoryCreateForm form) throws ErrorTypeException {
    throw new RuntimeException("Not implemented");
  }

  /**
   * NotificationHistory 를 CreateForm 을 update 하지 않는다.
   * @param form 업데이트 폼
   * @return 업데이트된 NotificationHistory 엔티티
   */
  public NotificationHistory update(NotificationHistoryUpdateForm form) throws ErrorTypeException {
    throw new RuntimeException("Not implemented");
  }

  /**
   * NotificationHistory 엔티티를 조회용 DTO로 변환한다.
   * @return NotificationHistory의 조회용 DTO
   */
  public NotificationHistoryView view(EntityViewType viewType) throws NotificationHistoryServiceException {
    NotificationHistoryView view = new NotificationHistoryView();
    view.setId(this.getId());
    
    view.setTitle(this.getTitle());
    view.setContent(this.getContent());
    view.setCreatedBy(this.getCreatedBy());
    view.setCreatedAt(this.getCreatedAt());
    view.setTenantAlias(this.getTenantAlias());
    view.setNotificationType(this.getNotificationType());
    view.setFrom(this.getFrom());
    view.setSuccess(this.getSuccess());
    view.withToList(getToList())
        .withCcList(getCcList())
        .withBccList(getBccList());

    return view;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o == null || o.getClass() != getClass()) {
      return false;
    }
    
    NotificationHistory that = (NotificationHistory) o;
  
    return new EqualsBuilder()
      .append(getTitle(), that.getTitle())
      .append(getContent(), that.getContent())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getCreatedBy(), that.getCreatedBy())
      .append(getCreatedAt(), that.getCreatedAt())
      .append(getSimpleAttributes(), that.getSimpleAttributes())
      .append(getTenantAlias(), that.getTenantAlias())
      .append(getNotificationType(), that.getNotificationType())
      .append(getFrom(), that.getFrom())
      .append(getSuccess(), that.getSuccess())
      .append(getUserId(), that.getUserId())
      .isEquals();
  }
  
  @Override
  public int hashCode() {
    return new HashCodeBuilder(17, 37)
      .append(getId())
      .append(getTitle())
      .append(getContent())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getCreatedBy())
      .append(getCreatedAt())
      .append(getSimpleAttributes())
      .append(getTenantAlias())
      .append(getNotificationType())
      .append(getFrom())
      .append(getSuccess())
      .append(getUserId())
      .toHashCode();
  }

  @Override
  public String toString() {
  return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
      .append("id", getId())
      .append("title", getTitle())
      .append("content", getContent())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("createdBy", getCreatedBy())
      .append("createdAt", getCreatedAt())
      .append("simpleAttributes", getSimpleAttributes())
      .append("tenantAlias", getTenantAlias())
      .append("notificationType", getNotificationType())
      .append("from", getFrom())
      .append("success", getSuccess())
      .append("userId", getUserId())
      .toString();
  }
}