/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.helper;

import io.rchemist.common.configuration.ApplicationContextHolder;
import io.rchemist.notification.data.NotificationHistoryView;
import io.rchemist.notification.domain.NotificationHistory;
import io.rchemist.notification.service.NotificationHistoryService;
import io.rchemist.notification.service.exception.NotificationHistoryServiceException;
import java.util.List;

/**
 * <p>
 * Project : Rchemist Platform
 * <p>
 * Created by kunner
 **/
public class NotificationHistoryServiceHelper {

  private static NotificationHistoryService service;
  
  private static NotificationHistoryService getService() {
  
    if (service == null) {
      service = ApplicationContextHolder.getBean(NotificationHistoryService.class);
    }
    
    return service;
  }
  
  public static NotificationHistory findEntityById(Long id) throws NotificationHistoryServiceException {
    return getService().findEntityById(id);
  }
  
  public static NotificationHistoryView findViewById(Long id) throws NotificationHistoryServiceException {
    return getService().findViewById(id);
  }
  
  public static List<NotificationHistory> findAllById(List<Long> ids) {
    return getService().findAllById(ids);
  }
  
  

}
