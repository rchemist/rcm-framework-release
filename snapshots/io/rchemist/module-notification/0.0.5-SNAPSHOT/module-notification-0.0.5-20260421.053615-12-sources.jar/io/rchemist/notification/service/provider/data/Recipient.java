/*
 *  Copyright (c) "2025". rchemist.io by Rchemist
 *  Licensed under the Rchemist Common License, Version 1.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License under controlled by Rchemist
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package io.rchemist.notification.service.provider.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * Project : Rchemist Commerce Platform
 * <p>
 * Created by kunner
 **/
@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Recipient implements Serializable {

  public Recipient(String recipientNo,
      Map<String, String> templateParameter) {
    this.recipientNo = recipientNo;
    this.templateParameter = templateParameter;
  }

  protected String recipientNo;
  protected Map<String, String> templateParameter = new HashMap<>();
  protected ResendParameter resendParameter;
  protected List<MessageButton> buttons;

  public Recipient withRecipientNo(String recipientNo) {
    this.recipientNo = recipientNo;
    return this;
  }

  public Recipient withTemplateParameter(
      Map<String, String> templateParameter) {
    this.templateParameter = templateParameter;
    return this;
  }

  public Recipient withResendParameter(
      ResendParameter resendParameter) {
    this.resendParameter = resendParameter;
    return this;
  }

  public Recipient withButtons(List<MessageButton> buttons) {
    this.buttons = buttons;
    return this;
  }
}
