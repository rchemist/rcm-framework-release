/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Stereotype meta-annotation — {@code @Component} 영역. 부착 시 Spring scan 이 bean 으로 발견 + 자기
 * 자신을 {@link #manager()} 에 자동 등록 ({@link ExtensionHandler#init} 영역).
 *
 * <p>Modernize 2 (사용자 결정 2026-05-06) — 0.0.5 의 {@code String manager()} (bean 이름 문자열) 대신
 * {@code Class<? extends ExtensionManager> manager()} (class type-safe). typo 회피 + IDE refactor friendly +
 * Spring 7 정합.
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component
public @interface RegisterExtensionHandler {

    /** Spring bean 이름. default {@code ""} 면 class 이름 lowerCamelCase. */
    @AliasFor(annotation = Component.class)
    String value() default "";

    /** 등록 대상 manager class. {@link ExtensionHandler#init} 가 ApplicationContext 에서 lookup. */
    Class<? extends ExtensionManager<?>> manager();

    /** chain 호출 순서. 낮은 값이 먼저. default 100. */
    int priority() default 100;
}
