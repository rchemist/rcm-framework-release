/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link ExtensionManager} chain 에서 각 {@link ExtensionHandler} 가 반환하는 처리 결과 status.
 *
 * <ul>
 *   <li>{@link #HANDLED} — 처리 완료 + chain 정지 (default 동작). {@link ExtensionManager#continueOnHandled()}
 *       가 {@code true} 면 chain 지속.</li>
 *   <li>{@link #HANDLED_CONTINUE} — 처리 완료 + chain 지속 (다음 handler 도 호출). 여러 handler 가 동일 hook 에
 *       부분적 처리할 때.</li>
 *   <li>{@link #HANDLED_STOP} — 처리 완료 + chain 강제 정지 ({@code continueOnHandled} 무시). 단독 처리 보장.</li>
 *   <li>{@link #NOT_HANDLED} — 본 handler 가 처리 영역 아님. chain 다음 handler 로. 모든 handler 가 NOT_HANDLED 면
 *       manager 도 NOT_HANDLED 반환.</li>
 * </ul>
 **/
public enum ExtensionResultStatusType {
    HANDLED,
    HANDLED_CONTINUE,
    HANDLED_STOP,
    NOT_HANDLED
}
