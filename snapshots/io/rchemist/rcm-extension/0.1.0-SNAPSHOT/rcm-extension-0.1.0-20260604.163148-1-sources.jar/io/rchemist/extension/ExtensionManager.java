/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Chain of Responsibility + Plugin pattern dispatcher (Decision #6). Lambda-based dispatch —
 * Consumer 가 {@code manager.dispatch(h -> h.handlerMethod(args))} 호출 시 등록된 모든 handler 를 priority
 * 순으로 chain invoke 하면서 {@link ExtensionResultStatusType} 기반 chain control.
 *
 * <p>{@code @ExtensionPoint} annotation (interface metadata + actuator endpoint 노출) 와 별개 영역.
 *
 * <p>Modernize 3 (Charter §1 원칙 7 정합 — 런타임 reflection 0) — 0.0.5 의 Java Dynamic Proxy + 인터페이스
 * 메서드 reflection invoke 영역 모두 폐기. lambda dispatch 로 동일 chain control 영역 제공 + reflection 0
 * (GraalVM AOT / `-Xshare:on` / future-proof Java idioms 정합).
 *
 * <p>사용 패턴:
 * <pre>{@code
 * @Service
 * public class XxxServiceExtensionManager extends ExtensionManager<XxxServiceExtensionHandler> {
 *     public XxxServiceExtensionManager() {
 *         super(XxxServiceExtensionHandler.class);
 *     }
 * }
 *
 * // Consumer
 * extensionManager.dispatch(h -> h.preCreate(formHolder));
 * }</pre>
 *
 * @param <T> handler interface (extends {@link ExtensionHandler})
 **/
public abstract class ExtensionManager<T extends ExtensionHandler> {

    private static final Logger LOG = LoggerFactory.getLogger(ExtensionManager.class);
    private static final Object LOCK = new Object();

    private final Class<T> handlerInterface;
    private final List<ProxyHandlerRegistered<T>> registeredHandlers = new ArrayList<>();

    private volatile boolean handlersSorted = false;

    protected ExtensionManager(Class<T> handlerInterface) {
        this.handlerInterface = handlerInterface;
    }

    /**
     * Lambda-based chain dispatch. 등록된 모든 handler 를 priority 순으로 iterate, 각 handler 의 isEnabled
     * 검사 후 {@code operation.apply(handler)} 호출. {@link ExtensionResultStatusType} 기반 chain
     * control ({@link #shouldContinue} + {@link #continueOnException}).
     *
     * <p>Charter §1 원칙 7 정합 — Java Dynamic Proxy / {@code Method#invoke} 모두 미사용. 런타임 reflection 0.
     *
     * @param operation 각 handler 에 적용할 lambda. 보통 {@code h -> h.someMethod(args)} 형태.
     * @return chain 결과 — 1 hit 이상이면 {@link ExtensionResultStatusType#HANDLED}, 모두
     *     {@link ExtensionResultStatusType#NOT_HANDLED} 면 NOT_HANDLED.
     */
    public ExtensionResultStatusType dispatch(Function<T, ExtensionResultStatusType> operation) {
        boolean notHandled = true;
        List<ProxyHandlerRegistered<T>> handlers = getRegisteredHandlers();
        int total = handlers.size();
        int currentIndex = 0;
        for (ProxyHandlerRegistered<T> registered : handlers) {
            currentIndex++;
            try {
                T handler = registered.getHandler();
                if (handler.isEnabled()) {
                    ExtensionResultStatusType result = operation.apply(handler);
                    if (!ExtensionResultStatusType.NOT_HANDLED.equals(result)) {
                        notHandled = false;
                    }
                    if (!shouldContinue(result)) {
                        break;
                    }
                }
            }
            catch (RuntimeException e) {
                if (continueOnException()) {
                    if (currentIndex == total) {
                        throw e;
                    }
                    LOG.warn("ExtensionHandler {} failed; continueOnException=true → 다음 handler 진행",
                            registered.getHandlerClass().getSimpleName(), e);
                    continue;
                }
                throw e;
            }
        }
        return notHandled ? ExtensionResultStatusType.NOT_HANDLED : ExtensionResultStatusType.HANDLED;
    }

    /** Handler 등록. priority = {@link Integer#MAX_VALUE} (가장 마지막). */
    public boolean registerHandler(T handler) {
        return registerHandler(handler, Integer.MAX_VALUE);
    }

    /**
     * Handler + priority 등록. 동일 instance 중복 등록 방지 (Modernize 1 — BPP 제거 후 setApplicationContext
     * 가 bean 당 1 회 호출이라 instance 동등성 검사로 충분 + 정확).
     */
    public boolean registerHandler(T handler, int priority) {
        synchronized (LOCK) {
            if (!handlerInterface.isAssignableFrom(handler.getClass())) {
                throw new IllegalArgumentException(
                        "ExtensionHandler " + handler.getClass()
                                + " 는 " + handlerInterface + " 의 하위 타입이 아닙니다.");
            }
            for (ProxyHandlerRegistered<T> registered : registeredHandlers) {
                if (registered.getHandler() == handler) {
                    return false;
                }
            }
            registeredHandlers.add(new ProxyHandlerRegistered<>(priority, handler));
            handlersSorted = false;
            return true;
        }
    }

    /** 등록된 모든 handler — priority 순. */
    public List<T> getHandlers() {
        return getRegisteredHandlers().stream()
                .map(ProxyHandlerRegistered::getHandler)
                .collect(Collectors.toList());
    }

    /** 등록된 priority wrapper list — chain 호출 직전 sort 보장. */
    public List<ProxyHandlerRegistered<T>> getRegisteredHandlers() {
        synchronized (LOCK) {
            if (!handlersSorted) {
                registeredHandlers.sort(Comparator.comparingInt(ProxyHandlerRegistered::getPriority));
                handlersSorted = true;
            }
            return registeredHandlers;
        }
    }

    /**
     * Chain 지속 여부 결정.
     *
     * <ul>
     *   <li>{@link ExtensionResultStatusType#HANDLED_STOP} — 강제 정지 (continueOnHandled 무시)</li>
     *   <li>{@link ExtensionResultStatusType#HANDLED} — {@link #continueOnHandled()} 따름 (default false → 정지)</li>
     *   <li>{@link ExtensionResultStatusType#HANDLED_CONTINUE} — 지속</li>
     *   <li>{@link ExtensionResultStatusType#NOT_HANDLED} — 지속</li>
     * </ul>
     */
    protected boolean shouldContinue(ExtensionResultStatusType result) {
        if (result == null) {
            return true;
        }
        if (ExtensionResultStatusType.HANDLED_STOP.equals(result)) {
            return false;
        }
        return !ExtensionResultStatusType.HANDLED.equals(result) || continueOnHandled();
    }

    /** Override 영역 — {@code true} 면 HANDLED 반환 후에도 chain 지속. default {@code false} (단일 처리 정지). */
    protected boolean continueOnHandled() {
        return false;
    }

    /** Override 영역 — {@code true} 면 RuntimeException 발생 시 다음 handler 로 진행. default {@code false}. */
    protected boolean continueOnException() {
        return false;
    }

    /** Helper — handler 가 처리 + ResultHolder.result 갱신 했는지 확인. */
    public static boolean hasExtensionResult(ExtensionResultStatusType status,
                                              ExtensionResultHolder<?> resultHolder) {
        return !ExtensionResultStatusType.NOT_HANDLED.equals(status)
                && resultHolder != null
                && resultHolder.hasResult();
    }
}
