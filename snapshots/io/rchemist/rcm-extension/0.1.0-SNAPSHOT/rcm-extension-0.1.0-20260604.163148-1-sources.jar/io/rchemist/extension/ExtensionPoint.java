/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Strategy pattern 영역 — interface metadata + actuator endpoint 노출. {@link ExtensionRegistry} /
 * {@link ExtensionsEndpoint} 가 부착된 interface 를 자동 발견. value() 는 사람이 읽는 description.
 *
 * <p><b>Chain dispatcher 와 별개 영역</b> — {@link ExtensionManager} 가 chain control + priority +
 * ResultHolder 영역. 두 영역 함께 보존:
 *
 * <ul>
 *   <li>{@link ExtensionPoint} — 사용자 1 strategy 선택 (예: PriceCalculator 의 다중 구현 중 1).
 *       Spring native 의존 주입 + actuator metadata.</li>
 *   <li>{@link ExtensionManager} — 모든 handler 자동 chain 통과 (예: ArticleService 의 preCreate /
 *       postCreate hooks 에 sanitize + audit + analytics handler chain). priority + ResultHolder +
 *       continueOnHandled / continueOnException 영역.</li>
 * </ul>
 **/
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ExtensionPoint {

    String value() default "";
}
