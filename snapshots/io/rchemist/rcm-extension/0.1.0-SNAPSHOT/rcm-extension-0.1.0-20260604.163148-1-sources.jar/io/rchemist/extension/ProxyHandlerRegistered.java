/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link ExtensionManager} 의 priority 보존 wrapper. handler 와 priority 를 함께 저장 — sortHandlers
 * 시점에 priority 오름차순 정렬.
 *
 * @param priority chain 호출 순서 (낮은 값이 먼저). default = {@link Integer#MAX_VALUE}
 * @param handler  실제 등록된 ExtensionHandler 인스턴스 (Spring bean)
 **/
public record ProxyHandlerRegistered<T extends ExtensionHandler>(int priority, T handler) {

    public Class<?> handlerClass() {
        return handler.getClass();
    }

    public T getHandler() {
        return handler;
    }

    public Class<?> getHandlerClass() {
        return handler.getClass();
    }

    public int getPriority() {
        return priority;
    }
}
