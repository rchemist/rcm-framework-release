/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * {@link ExtensionManager} chain 에서 handler 들이 공유하는 mutable result wrapper.
 *
 * <p>handler 사이에 result / throwable / context 를 전달. fluent API
 * ({@link #withResult} / {@link #withThrowable} / {@link #addContext}).
 *
 * <p>{@code mutable POJO} 라 Records 부적합 — Decision #28 의 Lombok 정책 영역 (Records 가 아니면 Lombok).
 **/
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ExtensionResultHolder<T> {

    protected T result;
    protected Throwable throwable;
    protected Map<String, Object> contextMap = new HashMap<>();

    public boolean hasResult() {
        return result != null;
    }

    public ExtensionResultHolder<T> addContext(String key, Object value) {
        if (contextMap == null) {
            contextMap = new HashMap<>();
        }
        contextMap.put(key, value);
        return this;
    }

    public ExtensionResultHolder<T> withResult(T result) {
        this.result = result;
        return this;
    }

    public ExtensionResultHolder<T> withThrowable(Throwable throwable) {
        this.throwable = throwable;
        return this;
    }

    public ExtensionResultHolder<T> withContextMap(Map<String, Object> contextMap) {
        this.contextMap = contextMap;
        return this;
    }
}
