/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.context.ApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.Order;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Spring Boot Actuator endpoint — /actuator/extensions 로 모든 ExtensionPoint 와
 * 구현체 (bean / class / order) 를 노출. Phase 1 task #6 적용.
 **/
@Endpoint(id = "extensions")
public class ExtensionsEndpoint {

    private final ApplicationContext context;

    public ExtensionsEndpoint(ApplicationContext context) {
        this.context = Objects.requireNonNull(context, "context");
    }

    @ReadOperation
    public Map<String, Object> extensions() {
        Map<Class<?>, List<BeanInfo>> byPoint = new LinkedHashMap<>();
        for (String name : context.getBeanDefinitionNames()) {
            Object bean;
            try {
                bean = context.getBean(name);
            } catch (Exception ignored) {
                continue;
            }
            collectExtensionPoints(bean.getClass(), name, bean, byPoint);
        }

        List<Map<String, Object>> points = new ArrayList<>();
        for (Map.Entry<Class<?>, List<BeanInfo>> entry : byPoint.entrySet()) {
            Class<?> pointType = entry.getKey();
            ExtensionPoint annotation = AnnotationUtils.findAnnotation(pointType, ExtensionPoint.class);
            List<BeanInfo> infos = entry.getValue();
            infos.sort((a, b) -> Integer.compare(orderOf(a.bean()), orderOf(b.bean())));

            List<Map<String, Object>> implementations = new ArrayList<>();
            for (BeanInfo info : infos) {
                implementations.add(Map.of(
                    "bean", info.name(),
                    "class", info.bean().getClass().getName(),
                    "order", orderOf(info.bean())));
            }

            Map<String, Object> pointInfo = new LinkedHashMap<>();
            pointInfo.put("point", pointType.getName());
            pointInfo.put("description", annotation == null ? "" : annotation.value());
            pointInfo.put("count", implementations.size());
            pointInfo.put("implementations", implementations);
            points.add(pointInfo);
        }
        return Map.of("extensions", points);
    }

    private static void collectExtensionPoints(
            Class<?> type, String beanName, Object bean,
            Map<Class<?>, List<BeanInfo>> byPoint) {
        if (type == null || type == Object.class) {
            return;
        }
        if (type.isAnnotationPresent(ExtensionPoint.class)) {
            byPoint.computeIfAbsent(type, k -> new ArrayList<>()).add(new BeanInfo(beanName, bean));
        }
        for (Class<?> iface : type.getInterfaces()) {
            collectExtensionPoints(iface, beanName, bean, byPoint);
        }
        collectExtensionPoints(type.getSuperclass(), beanName, bean, byPoint);
    }

    private static int orderOf(Object bean) {
        if (bean instanceof Ordered ordered) {
            return ordered.getOrder();
        }
        Order order = AnnotationUtils.findAnnotation(bean.getClass(), Order.class);
        return order != null ? order.value() : Ordered.LOWEST_PRECEDENCE;
    }

    private record BeanInfo(String name, Object bean) {}
}
