/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * Chain of Responsibility (Decision #6) base interface — Spring bean 으로 등록되는 모든 handler 의 공통.
 * {@link RegisterExtensionHandler} annotation 부착 시 ApplicationContext 영역에서 자동 발견 + manager 에
 * 자동 등록.
 *
 * <p>Modernize 1 (사용자 결정 2026-05-06) — 0.0.5 의 {@code extends BeanPostProcessor} 제거. 0.0.5 가
 * BPP 를 *자기 자신의 setApplicationContext* 만 사용 (다른 bean lifecycle hook 영역 안 씀) — BPP 는
 * 목적 외 사용. {@link ApplicationContextAware} 만으로 동일 동작 (자기 등록 logic 의 진입점 충분).
 **/
public interface ExtensionHandler extends ApplicationContextAware {

    Logger LOG = LoggerFactory.getLogger(ExtensionHandler.class);

    /** Chain 호출 순서. 낮은 값이 먼저. default {@link Integer#MAX_VALUE} (가장 마지막). */
    default int getPriority() {
        return Integer.MAX_VALUE;
    }

    /** {@code false} 면 {@link ExtensionManager} chain 이 본 handler skip. */
    default boolean isEnabled() {
        return true;
    }

    @Override
    default void setApplicationContext(ApplicationContext applicationContext) {
        init(applicationContext);
    }

    /**
     * {@link RegisterExtensionHandler} annotation 인식 + 대상 manager bean lookup + 자기 자신 등록.
     *
     * <p>Modernize 2 — 0.0.5 의 문자열 bean 이름 lookup 대신 class type 기반 lookup
     * ({@link ApplicationContext#getBean(Class)}). typo 회피 + IDE refactor friendly.
     */
    default void init(ApplicationContext applicationContext) {
        if (!getClass().isAnnotationPresent(RegisterExtensionHandler.class)) {
            return;
        }
        RegisterExtensionHandler annotation = getClass().getAnnotation(RegisterExtensionHandler.class);
        Class<? extends ExtensionManager<?>> managerClass = annotation.manager();
        int priority = annotation.priority();

        @SuppressWarnings({"rawtypes", "unchecked"})
        ExtensionManager manager = applicationContext.getBean(managerClass);
        manager.registerHandler(this, priority);

        if (LOG.isDebugEnabled()) {
            for (Object registered : manager.getRegisteredHandlers()) {
                ProxyHandlerRegistered<?> proxy = (ProxyHandlerRegistered<?>) registered;
                LOG.debug("registered handler info :: priority - {} || class - {}",
                        proxy.getPriority(), proxy.getHandlerClass());
            }
        }
    }
}
