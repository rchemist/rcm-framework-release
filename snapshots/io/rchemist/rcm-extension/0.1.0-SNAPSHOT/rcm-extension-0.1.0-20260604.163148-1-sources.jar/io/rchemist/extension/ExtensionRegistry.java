/*
 * Copyright (c) 2026. rchemist.io by Rchemist
 * Licensed under the Rchemist Common License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License under controlled by Rchemist
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.rchemist.extension;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;

/**
 * <p>
 * project : rcm-backend-framework
 * <p>
 * Created by kunner
 * ExtensionRegistry — ApplicationContext 기반 ExtensionPoint 구현체 lookup. @Order 정렬 +
 * ObjectProvider lazy 접근 helper. 0.0.5 시대 ExtensionManager static service-locator 폐기.
 **/
public class ExtensionRegistry {

    private final ApplicationContext context;

    public ExtensionRegistry(ApplicationContext context) {
        this.context = Objects.requireNonNull(context, "context");
    }

    public <T> List<T> getExtensions(Class<T> extensionType) {
        Objects.requireNonNull(extensionType, "extensionType");
        List<T> beans = new ArrayList<>(context.getBeansOfType(extensionType).values());
        beans.sort(AnnotationAwareOrderComparator.INSTANCE);
        return List.copyOf(beans);
    }

    public <T> ObjectProvider<T> objectProvider(Class<T> extensionType) {
        Objects.requireNonNull(extensionType, "extensionType");
        return context.getBeanProvider(extensionType);
    }
}
